# Provenance and licensing

This private local package combines affectUI's publicly loaded browser previews with its official free-source repository. It is not an official affectUI release.

The 23 free components listed in `config/type-coverage.json` derive from the official TSX implementation in `packages/react/src/components/<slug>/index.tsx` and `clean.tsx`. The corresponding MIT notice, Copyright 2026 Florian Höller (adfects), is preserved in `licenses/affectui-MIT.txt`.

The remaining 67 component implementations were reconstructed from publicly loaded browser code. Their upstream ownership and licensing status remain unchanged. The free-source MIT notice does not grant a license for the entire recovered library. This repository contains no Pro access keys or authenticated Pro source downloads.

Public TypeScript contracts combine preserved free-source declarations and interfaces reconstructed from public APIs and runtime behavior. Semantically refactored components use explicit internal types; remaining reconstructed resource previews retain a documented private dynamic-type boundary. They are not represented as the original Pro TypeScript source. See `docs/type-migration.md` in the source repository.

The additional screens, blocks, illustrations and motion resources follow the same provenance distinction. Official free implementations are marked in config/resources.json; remaining entries expose reconstructed public previews, including demo data, rather than authenticated Pro source.

Local modifications on 2026-11-12 include accessibility semantics, labels, keyboard-reachable scrolling, and light-theme text/contrast corrections. These changes retain the original provenance and notices.
