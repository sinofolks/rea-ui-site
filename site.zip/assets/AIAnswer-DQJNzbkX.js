const n=`.ui-ans {
  --ui-ans-tray: #f0f0f0;
  --ui-ans-card: #ffffff;
  --ui-ans-line: #ececec;
  --ui-ans-ink: #171717;
  --ui-ans-text: #404040;
  --ui-ans-muted: #626873;
  --ui-ans-faint: #6b6b6b;
  --ui-ans-chip: #f4f4f5;
  --ui-ans-chip-hover: #ebebec;
  --ui-ans-hover: #e4e4e5;
  --ui-ans-lit: #171717;
  --ui-ans-lit-text: #ffffff;
  --ui-ans-lit-ring: #cfcfd3;
  --ui-ans-shine: rgba(255, 255, 255, 0.82);
  --ui-ans-ok: #1f8a4c;
  --ui-ans-focus: rgba(0, 96, 226, 0.7);
  --ui-ans-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 640px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 1.5;
  color: var(--ui-ans-text);
  -webkit-font-smoothing: antialiased;
}
.ui-ans *,
.ui-ans *::before,
.ui-ans *::after {
  box-sizing: border-box;
}
:where(.ui-ans) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-ans) svg {
  display: block;
  flex: none;
}
.ui-ans button:focus-visible,
.ui-ans a:focus-visible {
  outline: 2px solid var(--ui-ans-focus);
  outline-offset: 2px;
}
.ui-ans__card {
  overflow: visible clip;
  margin: -4px 0;
  transition: height 360ms var(--ui-ans-ease);
}
.ui-ans__inner {
  display: flow-root;
  padding: 4px 0;
}
.ui-ans[data-framed] {
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ans-tray);
}
.ui-ans[data-framed] .ui-ans__card {
  overflow: hidden;
  margin: 0;
  border-radius: 16px;
  background: var(--ui-ans-card);
  box-shadow:
    0 0 0 1px var(--ui-ans-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-ans[data-framed] .ui-ans__inner {
  padding: 22px 24px 20px;
}
.ui-ans__question {
  margin: 0 0 16px;
  font-size: 18px;
  font-weight: 600;
  line-height: 1.35;
  letter-spacing: -0.012em;
  color: var(--ui-ans-ink);
  overflow-wrap: anywhere;
}
.ui-ans__sources {
  --ui-ans-shown: 3;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}
.ui-ans__sources[data-more] {
  grid-template-columns: repeat(3, minmax(0, 1fr)) auto;
}
.ui-ans__source-wrap {
  display: flex;
  min-width: 0;
}
.ui-ans__sources:not([data-more]) > .ui-ans__rest-wrap {
  display: none;
}
.ui-ans__source {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-ans-chip);
  color: inherit;
  text-decoration: none;
  transition:
    background-color 160ms ease,
    box-shadow 200ms ease;
  animation: ui-ans-card 460ms var(--ui-ans-ease) both;
}
a.ui-ans__source:hover {
  background: var(--ui-ans-chip-hover);
}
.ui-ans__source[data-lit] {
  box-shadow: inset 0 0 0 1.5px var(--ui-ans-lit-ring);
}
.ui-ans__site {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  color: var(--ui-ans-muted);
}
.ui-ans__site-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ans__num {
  flex: none;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ans-faint);
}
.ui-ans__favicon {
  display: grid;
  flex: none;
  width: 16px;
  height: 16px;
  overflow: hidden;
  border-radius: 4px;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.06);
}
.ui-ans__favicon[hidden] {
  display: none;
}
.ui-ans__favicon > * {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.ui-ans__rest {
  justify-content: space-between;
  min-width: 52px;
}
.ui-ans__rest-count {
  font-size: 12.5px;
  font-weight: 600;
  line-height: 1.4;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ans-ink);
  white-space: nowrap;
}
.ui-ans__rest-count [data-narrow] {
  display: none;
}
.ui-ans__rest-label {
  font-size: 12px;
  color: var(--ui-ans-muted);
}
.ui-ans__title {
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  font-size: 12.5px;
  line-height: 1.4;
  color: var(--ui-ans-ink);
}
.ui-ans__label {
  display: flex;
  align-items: center;
  gap: 8px;
  margin: 20px 0 10px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ans-ink);
}
.ui-ans__mark {
  width: 27px;
  height: 24px;
  margin: -3px -1px -3px -2px;
  overflow: visible;
}
.ui-ans__mark {
  --ui-ans-mark-top: #7ccbff;
  --ui-ans-mark-bottom: #2f8fea;
  --ui-ans-mark-glow: #ffffff;
  --ui-ans-mark-edge: #b3dcff;
  --ui-ans-mark-eye-top: #ffffff;
  --ui-ans-mark-eye-bottom: #d6f0ff;
  --ui-ans-mark-eye-shade: rgba(30, 140, 230, 0.3);
}
.ui-ans__mark-edge {
  fill: var(--ui-ans-mark-edge);
}
.ui-ans__mark-eye-shade {
  stroke: var(--ui-ans-mark-eye-shade);
}
.ui-ans__eyes {
  animation: ui-ans-look 7s ease-in-out infinite;
}
.ui-ans__eye {
  transform-box: fill-box;
  transform-origin: center;
  animation: ui-ans-blink 7s ease-in-out infinite;
}
.ui-ans__eye-r {
  animation-name: ui-ans-blink-r;
}
.ui-ans[data-phase="reading"] .ui-ans__eyes {
  animation: ui-ans-scan 1.4s ease-in-out infinite;
}
.ui-ans[data-phase="writing"] .ui-ans__eyes {
  animation: ui-ans-follow 1.9s cubic-bezier(0.45, 0, 0.55, 1) infinite;
}
@keyframes ui-ans-look {
  0%,
  26% {
    transform: none;
  }
  32%,
  44% {
    transform: translate(-12px, 1px);
  }
  50%,
  62% {
    transform: translate(12px, -2px);
  }
  68%,
  100% {
    transform: none;
  }
}
@keyframes ui-ans-blink {
  0%,
  16%,
  21%,
  100% {
    transform: none;
  }
  18.5% {
    transform: scaleY(0.1);
  }
}
@keyframes ui-ans-blink-r {
  0%,
  16%,
  21%,
  84%,
  93%,
  100% {
    transform: none;
  }
  18.5% {
    transform: scaleY(0.1);
  }
  87%,
  90% {
    transform: scaleY(0.1);
  }
}
@keyframes ui-ans-scan {
  0%,
  100% {
    transform: translate(-11px, 1px);
  }
  50% {
    transform: translate(11px, 1px);
  }
}
@keyframes ui-ans-follow {
  0% {
    transform: translate(-10px, 5px);
  }
  82% {
    transform: translate(10px, 5px);
  }
  100% {
    transform: translate(-10px, 5px);
  }
}
.ui-ans__label-text {
  position: relative;
  animation: ui-ans-fade 320ms var(--ui-ans-ease) both;
}
.ui-ans[data-phase="reading"] .ui-ans__label-text,
.ui-ans[data-phase="writing"] .ui-ans__label-text {
  color: var(--ui-ans-muted);
}
.ui-ans__answer {
  font-size: 15px;
  line-height: 1.65;
  color: var(--ui-ans-text);
  overflow-wrap: anywhere;
}
.ui-ans__answer p {
  margin: 0 0 12px;
}
.ui-ans__answer ul {
  margin: 0 0 12px;
  padding: 0 0 0 20px;
}
.ui-ans__answer li {
  margin: 0 0 6px;
  padding-left: 2px;
}
.ui-ans__answer li::marker {
  color: var(--ui-ans-faint);
}
.ui-ans__answer > :last-child {
  margin-bottom: 0;
}
.ui-ans__empty {
  color: var(--ui-ans-muted);
}
.ui-ans__w {
  animation: ui-ans-word 420ms var(--ui-ans-ease) both;
}
.ui-ans__w[data-bold] {
  font-weight: 600;
  color: var(--ui-ans-ink);
}
.ui-ans__caret {
  display: inline-block;
  width: 8px;
  height: 8px;
  margin-left: 4px;
  border-radius: 50%;
  background: var(--ui-ans-ink);
  vertical-align: 0.05em;
  animation: ui-ans-pulse 1s ease-in-out infinite;
}
.ui-ans__cite {
  display: inline-flex;
  max-width: 100%;
  align-items: center;
  gap: 3px;
  height: 20px;
  margin: 0 1px 0 3px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-ans-chip);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-ans-muted);
  vertical-align: 0.12em;
  transition:
    background-color 160ms ease,
    color 160ms ease;
  animation: ui-ans-chip 380ms var(--ui-ans-ease) both;
}
.ui-ans__cite:hover {
  background: var(--ui-ans-chip-hover);
  color: var(--ui-ans-ink);
}
.ui-ans__cite[data-lit] {
  background: var(--ui-ans-lit);
  color: var(--ui-ans-lit-text);
}
.ui-ans__cite-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ans__more {
  flex: none;
  opacity: 0.7;
}
.ui-ans__pop {
  position: absolute;
  z-index: 5;
  display: grid;
  gap: 2px;
  padding: 6px;
  border-radius: 14px;
  background: var(--ui-ans-card);
  box-shadow:
    0 0 0 1px var(--ui-ans-line),
    0 12px 32px -10px rgba(0, 0, 0, 0.2),
    0 2px 6px rgba(0, 0, 0, 0.04);
  animation: ui-ans-pop 200ms var(--ui-ans-ease) both;
}
.ui-ans__pop-item {
  display: grid;
  gap: 4px;
  padding: 8px 10px 10px;
  border-radius: 9px;
  color: inherit;
  text-decoration: none;
  transition: background-color 140ms ease;
}
.ui-ans__pop-item[href]:hover {
  background: var(--ui-ans-chip);
}
.ui-ans__pop-title {
  font-size: 13px;
  font-weight: 500;
  line-height: 1.4;
  color: var(--ui-ans-ink);
  overflow-wrap: anywhere;
}
.ui-ans__snippet {
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  font-size: 12.5px;
  line-height: 1.5;
  color: var(--ui-ans-muted);
}
.ui-ans__follow {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  margin-top: 20px;
  padding-top: 14px;
  border-top: 1px solid var(--ui-ans-line);
}
.ui-ans__follow-label {
  padding-bottom: 4px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-ans-faint);
  animation: ui-ans-fade 320ms var(--ui-ans-ease) both;
}
.ui-ans__follow-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 40px;
  padding: 8px 0;
  border-bottom: 1px solid var(--ui-ans-line);
  text-align: left;
  color: var(--ui-ans-ink);
  animation: ui-ans-fade 380ms var(--ui-ans-ease) both;
}
.ui-ans__follow-item:last-child {
  border-bottom: 0;
  padding-bottom: 0;
}
.ui-ans__follow-item > span {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-ans__follow-item .ui-ans__glyph {
  color: var(--ui-ans-faint);
  transition:
    transform 220ms var(--ui-ans-ease),
    color 160ms ease;
}
.ui-ans__follow-item:hover .ui-ans__glyph {
  color: var(--ui-ans-ink);
  transform: translateX(3px);
}
.ui-ans__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 42px;
  margin-top: 8px;
}
.ui-ans[data-framed] .ui-ans__foot {
  margin-top: 0;
  padding: 0 8px 0 6px;
}
.ui-ans__actions {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-ans__action {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  color: var(--ui-ans-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
  animation: ui-ans-fade 320ms var(--ui-ans-ease) both;
}
.ui-ans__action:nth-child(2) {
  animation-delay: 40ms;
}
.ui-ans__action:nth-child(3) {
  animation-delay: 80ms;
}
.ui-ans__action:nth-child(4) {
  animation-delay: 120ms;
}
.ui-ans__action:hover {
  background: var(--ui-ans-hover);
  color: var(--ui-ans-ink);
}
.ui-ans__action[aria-pressed="true"] {
  color: var(--ui-ans-ink);
}
.ui-ans__action[aria-pressed="true"] .ui-ans__glyph {
  fill: currentColor;
  fill-opacity: 0.12;
}
.ui-ans__glyph {
  width: 17px;
  height: 17px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ans__down .ui-ans__glyph {
  transform: scaleY(-1);
}
.ui-ans__redo:active .ui-ans__glyph {
  transform: rotate(120deg);
  transition: transform 300ms var(--ui-ans-ease);
}
.ui-ans__ok {
  stroke: var(--ui-ans-ok) !important;
  stroke-width: 2.2 !important;
  animation: ui-ans-chip 260ms var(--ui-ans-ease) both;
}
.ui-ans__status {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 12.5px;
  white-space: nowrap;
  color: var(--ui-ans-muted);
  animation: ui-ans-fade 260ms var(--ui-ans-ease) both;
}
@container (max-width: 330px) {
  .ui-ans__status-lead {
    display: none;
  }
}
.ui-ans__stop {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 12px 0 10px;
  border-radius: 9px;
  font-size: 13px;
  color: var(--ui-ans-text);
  transition: background-color 160ms ease;
  animation: ui-ans-fade 260ms var(--ui-ans-ease) both;
}
.ui-ans__stop:hover {
  background: var(--ui-ans-hover);
}
.ui-ans__stop-icon {
  width: 9px;
  height: 9px;
  border-radius: 2px;
  background: var(--ui-ans-ink);
}
.ui-ans__reasons {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 320ms var(--ui-ans-ease),
    opacity 200ms ease;
}
.ui-ans__reasons[data-open="true"] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-ans__reasons > div {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  min-height: 0;
  overflow: visible clip;
  margin-top: -4px;
  padding: 4px 0 0;
}
.ui-ans__reasons[data-open="true"] > div {
  padding-bottom: 8px;
}
.ui-ans[data-framed] .ui-ans__reasons > div {
  overflow: hidden;
  padding: 4px 6px 0;
}
.ui-ans__reasons button {
  min-height: 30px;
  max-width: 100%;
  padding: 4px 11px;
  overflow-wrap: anywhere;
  text-align: start;
  border-radius: 9px;
  background: var(--ui-ans-card);
  box-shadow: 0 0 0 1px var(--ui-ans-line);
  font-size: 12.5px;
  color: var(--ui-ans-text);
  transition:
    color 140ms ease,
    box-shadow 140ms ease;
}
.ui-ans__reasons button:hover {
  color: var(--ui-ans-ink);
  box-shadow: 0 0 0 1px var(--ui-ans-faint);
}
.ui-ans__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-ans-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-ans-sweep 1.6s linear infinite;
  pointer-events: none;
}
@keyframes ui-ans-word {
  from {
    opacity: 0;
    filter: blur(3px);
  }
  to {
    opacity: 1;
    filter: none;
  }
}
@keyframes ui-ans-card {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.96);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ans-chip {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ans-fade {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ans-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ans-pulse {
  50% {
    transform: scale(0.6);
    opacity: 0.45;
  }
}
@keyframes ui-ans-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 480px) {
  .ui-ans[data-framed] .ui-ans__inner {
    padding: 18px 18px 16px;
  }
  .ui-ans__question {
    font-size: 16.5px;
  }
  .ui-ans__answer {
    font-size: 14.5px;
  }
  .ui-ans__sources {
    --ui-ans-shown: 2;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .ui-ans__sources[data-more-narrow] {
    grid-template-columns: repeat(2, minmax(0, 1fr)) auto;
  }
  .ui-ans__sources[data-more-narrow] > :nth-child(3) {
    display: none;
  }
  .ui-ans__sources[data-more-narrow] > .ui-ans__rest-wrap {
    display: flex;
  }
  .ui-ans__rest-count [data-wide] {
    display: none;
  }
  .ui-ans__rest-count [data-narrow] {
    display: inline;
  }
  .ui-ans__rest[data-lit-narrow] {
    box-shadow: inset 0 0 0 1.5px var(--ui-ans-lit-ring);
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-ans__action {
    width: 40px;
    height: 40px;
    border-radius: 10px;
  }
  .ui-ans__foot {
    height: 48px;
  }
  .ui-ans__stop {
    height: 36px;
  }
  .ui-ans__reasons button {
    min-height: 36px;
    padding: 4px 13px;
  }
  .ui-ans__follow-item {
    min-height: 46px;
  }
  .ui-ans__cite {
    position: relative;
  }
  .ui-ans__cite::after {
    content: "";
    position: absolute;
    inset: -10px -4px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ans *,
  .ui-ans *::before,
  .ui-ans *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ans {
  --ui-ans-tray: #111113;
  --ui-ans-card: #19191b;
  --ui-ans-line: #2a2a2e;
  --ui-ans-ink: #ededed;
  --ui-ans-text: #c8c8cc;
  --ui-ans-muted: #8b8b92;
  --ui-ans-faint: #5c5c63;
  --ui-ans-chip: #232326;
  --ui-ans-chip-hover: #2b2b2f;
  --ui-ans-hover: #222225;
  --ui-ans-lit: #ededed;
  --ui-ans-lit-text: #19191b;
  --ui-ans-lit-ring: #4a4a50;
  --ui-ans-shine: rgba(255, 255, 255, 0.95);
  --ui-ans-ok: #3ec27a;
  --ui-ans-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ans__mark {
  --ui-ans-mark-top: #1a4f9e;
  --ui-ans-mark-bottom: #3d9cf0;
  --ui-ans-mark-glow: #081a36;
  --ui-ans-mark-edge: #173866;
}
:where(.dark, [data-theme="dark"]) .ui-ans__favicon {
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.08);
}
`;export{n as default};
