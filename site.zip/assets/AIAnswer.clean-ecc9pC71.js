const n=`.ui-ansc {
  --ui-ansc-card: #ffffff;
  --ui-ansc-ink: rgba(0, 0, 0, 0.88);
  --ui-ansc-strong: #000000;
  --ui-ansc-text: rgba(0, 0, 0, 0.65);
  --ui-ansc-muted: rgba(0, 0, 0, 0.65);
  --ui-ansc-faint: rgba(0, 0, 0, 0.65);
  --ui-ansc-icon: rgba(0, 0, 0, 0.65);
  --ui-ansc-line: rgba(0, 0, 0, 0.06);
  --ui-ansc-fill: rgba(0, 0, 0, 0.06);
  --ui-ansc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-ansc-wash: rgba(0, 0, 0, 0.015);
  --ui-ansc-accent: rgba(0, 96, 226, 0.765);
  --ui-ansc-ok: #0f783c;
  --ui-ansc-shine: rgba(255, 255, 255, 0.82);
  --ui-ansc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ansc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ansc-focus: rgba(0, 96, 226, 0.7);
  --ui-ansc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 640px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-ansc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-ansc *,
.ui-ansc *::before,
.ui-ansc *::after {
  box-sizing: border-box;
}
:where(.ui-ansc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-ansc) svg {
  display: block;
  flex: none;
}
.ui-ansc button:focus-visible,
.ui-ansc a:focus-visible {
  outline: 2px solid var(--ui-ansc-focus);
  outline-offset: 2px;
}
.ui-ansc__body {
  overflow: visible clip;
  margin: -4px 0;
  transition: height 360ms var(--ui-ansc-ease);
}
.ui-ansc__inner {
  display: flow-root;
  padding: 4px 0;
}
.ui-ansc[data-framed] .ui-ansc__card {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-ansc-card);
  box-shadow: var(--ui-ansc-shadow);
}
.ui-ansc[data-framed] .ui-ansc__body {
  overflow: hidden;
  margin: 0;
}
.ui-ansc[data-framed] .ui-ansc__inner {
  padding: 20px 20px 16px;
}
.ui-ansc__question {
  margin: 0 0 14px;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-ansc-strong);
  overflow-wrap: anywhere;
}
.ui-ansc__sources {
  --ui-ansc-shown: 3;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
}
.ui-ansc__sources[data-more] {
  grid-template-columns: repeat(3, minmax(0, 1fr)) auto;
}
.ui-ansc__source-wrap {
  display: flex;
  min-width: 0;
}
.ui-ansc__sources:not([data-more]) > .ui-ansc__rest-wrap {
  display: none;
}
.ui-ansc__source {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 4px;
  min-width: 0;
  padding: 8px 10px 9px;
  border-radius: 8px;
  background: var(--ui-ansc-card);
  box-shadow: var(--ui-ansc-shadow);
  color: inherit;
  text-decoration: none;
  transition:
    background-color 160ms ease,
    box-shadow 200ms ease;
  animation: ui-ansc-card 460ms var(--ui-ansc-ease) both;
}
a.ui-ansc__source:hover {
  background: var(--ui-ansc-wash);
}
.ui-ansc__source[data-lit] {
  background: var(--ui-ansc-wash);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
}
.ui-ansc__site {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ansc-text);
}
.ui-ansc__site-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ansc__num {
  flex: none;
  font-size: 10px;
  line-height: 16px;
  font-weight: 500;
  letter-spacing: 0.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ansc-faint);
}
.ui-ansc__favicon {
  display: grid;
  flex: none;
  width: 14px;
  height: 14px;
  overflow: hidden;
  border-radius: 4px;
  box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.1);
}
.ui-ansc__favicon[hidden] {
  display: none;
}
.ui-ansc__favicon > * {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.ui-ansc__rest {
  justify-content: space-between;
  min-width: 52px;
}
.ui-ansc__rest-count {
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ansc-strong);
  white-space: nowrap;
}
.ui-ansc__rest-count [data-narrow] {
  display: none;
}
.ui-ansc__rest-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ansc-text);
}
.ui-ansc__title {
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-ansc-strong);
}
.ui-ansc__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 16px 0 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ansc-text);
}
.ui-ansc__mark {
  width: 16px;
  height: 16px;
  fill: var(--ui-ansc-accent);
  overflow: visible;
}
.ui-ansc__mark path {
  transform-box: fill-box;
  transform-origin: center;
}
.ui-ansc[data-phase="reading"] .ui-ansc__mark-big,
.ui-ansc[data-phase="writing"] .ui-ansc__mark-big {
  animation: ui-ansc-breathe 1.4s ease-in-out infinite;
}
.ui-ansc[data-phase="reading"] .ui-ansc__mark-small,
.ui-ansc[data-phase="writing"] .ui-ansc__mark-small {
  animation: ui-ansc-twinkle 1.4s ease-in-out infinite;
}
.ui-ansc__label-text {
  position: relative;
  animation: ui-ansc-fade 320ms var(--ui-ansc-ease) both;
}
.ui-ansc[data-phase="done"] .ui-ansc__label-text,
.ui-ansc[data-phase="stopped"] .ui-ansc__label-text {
  color: var(--ui-ansc-text);
}
.ui-ansc__answer {
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ansc-ink);
  overflow-wrap: anywhere;
}
.ui-ansc__answer p {
  margin: 0 0 8px;
}
.ui-ansc__answer ul {
  margin: 0 0 8px;
  padding: 0 0 0 18px;
}
.ui-ansc__answer li {
  margin: 0 0 4px;
  padding-left: 2px;
}
.ui-ansc__answer li::marker {
  color: var(--ui-ansc-faint);
}
.ui-ansc__answer > :last-child {
  margin-bottom: 0;
}
.ui-ansc__empty {
  color: var(--ui-ansc-muted);
}
.ui-ansc__w {
  animation: ui-ansc-word 420ms var(--ui-ansc-ease) both;
}
.ui-ansc__w[data-bold] {
  font-weight: 500;
  color: var(--ui-ansc-strong);
}
.ui-ansc__caret {
  display: inline-block;
  width: 6px;
  height: 6px;
  margin-left: 4px;
  border-radius: 1.5px;
  background: var(--ui-ansc-accent);
  vertical-align: 0.1em;
  animation: ui-ansc-pulse 1s ease-in-out infinite;
}
.ui-ansc__cite {
  display: inline-flex;
  max-width: 100%;
  align-items: center;
  gap: 3px;
  height: 18px;
  margin: 0 1px 0 3px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-ansc-fill);
  box-shadow: inset 0 0 0 0.5px var(--ui-ansc-line);
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-ansc-text);
  vertical-align: 0.1em;
  transition:
    background-color 160ms ease,
    color 160ms ease;
  animation: ui-ansc-chip 380ms var(--ui-ansc-ease) both;
}
.ui-ansc__cite:hover,
.ui-ansc__cite[data-lit] {
  background: var(--ui-ansc-fill-strong);
  color: var(--ui-ansc-ink);
}
.ui-ansc__cite-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ansc__more {
  flex: none;
  opacity: 0.7;
}
.ui-ansc__pop {
  position: absolute;
  z-index: 5;
  display: grid;
  gap: 2px;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-ansc-card);
  box-shadow: var(--ui-ansc-shadow-pop);
  animation: ui-ansc-pop 200ms var(--ui-ansc-ease) both;
}
.ui-ansc__pop-item {
  display: grid;
  gap: 2px;
  padding: 8px 10px 9px;
  border-radius: 6px;
  color: inherit;
  text-decoration: none;
  transition: background-color 140ms ease;
}
.ui-ansc__pop-item[href]:hover {
  background: var(--ui-ansc-wash);
}
.ui-ansc__pop-title {
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-ansc-strong);
  overflow-wrap: anywhere;
}
.ui-ansc__snippet {
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ansc-text);
}
.ui-ansc__follow {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  margin-top: 16px;
}
.ui-ansc__follow-label {
  padding-bottom: 4px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-ansc-muted);
  animation: ui-ansc-fade 320ms var(--ui-ansc-ease) both;
}
.ui-ansc__follow-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 32px;
  padding: 6px 0;
  border-top: 0.5px solid var(--ui-ansc-line);
  text-align: left;
  color: var(--ui-ansc-ink);
  animation: ui-ansc-fade 380ms var(--ui-ansc-ease) both;
}
.ui-ansc__follow-item > span {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-ansc__follow-item .ui-ansc__glyph {
  color: var(--ui-ansc-faint);
  transition:
    transform 220ms var(--ui-ansc-ease),
    color 160ms ease;
}
.ui-ansc__follow-item:hover .ui-ansc__glyph {
  color: var(--ui-ansc-ink);
  transform: translateX(2px);
}
.ui-ansc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 44px;
  margin-top: 4px;
}
.ui-ansc[data-framed] .ui-ansc__foot {
  margin-top: 0;
  padding: 0 12px 0 8px;
  border-top: 0.5px solid var(--ui-ansc-line);
}
.ui-ansc__actions {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-ansc__action {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-ansc-icon);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
  animation: ui-ansc-fade 320ms var(--ui-ansc-ease) both;
}
.ui-ansc__action:nth-child(2) {
  animation-delay: 40ms;
}
.ui-ansc__action:nth-child(3) {
  animation-delay: 80ms;
}
.ui-ansc__action:nth-child(4) {
  animation-delay: 120ms;
}
.ui-ansc__action:hover {
  background: var(--ui-ansc-wash);
  color: var(--ui-ansc-ink);
}
.ui-ansc__action[aria-pressed="true"] {
  background: var(--ui-ansc-fill);
  box-shadow: inset 0 0 0 0.5px var(--ui-ansc-line);
  color: var(--ui-ansc-ink);
}
.ui-ansc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ansc__glyph[data-solid] {
  fill: currentColor;
  stroke: none;
}
.ui-ansc__down .ui-ansc__glyph {
  transform: scaleY(-1);
}
.ui-ansc__redo:active .ui-ansc__glyph {
  transform: rotate(120deg);
  transition: transform 300ms var(--ui-ansc-ease);
}
.ui-ansc__ok {
  color: var(--ui-ansc-ok);
  animation: ui-ansc-chip 260ms var(--ui-ansc-ease) both;
}
.ui-ansc__action:has(.ui-ansc__ok) {
  color: var(--ui-ansc-ok);
}
.ui-ansc__status {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  color: var(--ui-ansc-muted);
  animation: ui-ansc-fade 260ms var(--ui-ansc-ease) both;
}
@container (max-width: 330px) {
  .ui-ansc__status-lead {
    display: none;
  }
}
.ui-ansc__stop {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  background: var(--ui-ansc-card);
  box-shadow: var(--ui-ansc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ansc-strong);
  transition: background-color 160ms ease;
  animation: ui-ansc-fade 260ms var(--ui-ansc-ease) both;
}
.ui-ansc__stop:hover {
  background: #fafafa;
}
.ui-ansc__stop-icon {
  width: 8px;
  height: 8px;
  margin: 0 2px;
  border-radius: 2px;
  background: var(--ui-ansc-ink);
}
.ui-ansc__reasons {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 320ms var(--ui-ansc-ease),
    opacity 200ms ease;
}
.ui-ansc__reasons[data-open="true"] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-ansc__reasons > div {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  min-height: 0;
  overflow: visible clip;
  margin-top: -4px;
  padding: 4px 0 0;
}
.ui-ansc__reasons[data-open="true"] > div {
  padding-bottom: 4px;
}
.ui-ansc[data-framed] .ui-ansc__reasons > div {
  overflow: hidden;
  padding: 4px 12px 0;
}
.ui-ansc[data-framed] .ui-ansc__reasons[data-open="true"] > div {
  padding-bottom: 12px;
}
.ui-ansc__reasons button {
  min-height: 28px;
  max-width: 100%;
  padding: 4px 10px;
  overflow-wrap: anywhere;
  text-align: start;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-ansc-line);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ansc-text);
  transition:
    color 140ms ease,
    background-color 140ms ease;
}
.ui-ansc__reasons button:hover {
  color: var(--ui-ansc-ink);
  background: var(--ui-ansc-fill);
}
.ui-ansc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-ansc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-ansc-sweep 1.6s linear infinite;
  pointer-events: none;
}
@keyframes ui-ansc-word {
  from {
    opacity: 0;
    filter: blur(3px);
  }
  to {
    opacity: 1;
    filter: none;
  }
}
@keyframes ui-ansc-card {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.97);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ansc-chip {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ansc-fade {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ansc-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ansc-pulse {
  50% {
    opacity: 0.3;
  }
}
@keyframes ui-ansc-breathe {
  50% {
    transform: scale(0.86);
  }
}
@keyframes ui-ansc-twinkle {
  0%,
  100% {
    opacity: 1;
    transform: none;
  }
  50% {
    opacity: 0.3;
    transform: scale(0.6) rotate(45deg);
  }
}
@keyframes ui-ansc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 480px) {
  .ui-ansc[data-framed] .ui-ansc__inner {
    padding: 16px 16px 14px;
  }
  .ui-ansc__sources {
    --ui-ansc-shown: 2;
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .ui-ansc__sources[data-more-narrow] {
    grid-template-columns: repeat(2, minmax(0, 1fr)) auto;
  }
  .ui-ansc__sources[data-more-narrow] > :nth-child(3) {
    display: none;
  }
  .ui-ansc__sources[data-more-narrow] > .ui-ansc__rest-wrap {
    display: flex;
  }
  .ui-ansc__rest-count [data-wide] {
    display: none;
  }
  .ui-ansc__rest-count [data-narrow] {
    display: inline;
  }
  .ui-ansc__rest[data-lit-narrow] {
    background: var(--ui-ansc-wash);
    box-shadow:
      0 0 0 0.5px rgba(0, 0, 0, 0.1),
      0 1px 1px -1px rgba(0, 0, 0, 0.1),
      0 1px 2px 0 rgba(0, 0, 0, 0.05);
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-ansc__action {
    width: 36px;
    height: 36px;
  }
  .ui-ansc__foot {
    height: 52px;
  }
  .ui-ansc__stop {
    height: 34px;
  }
  .ui-ansc__reasons button {
    min-height: 34px;
    padding: 4px 12px;
  }
  .ui-ansc__follow-item {
    min-height: 44px;
  }
  .ui-ansc__cite {
    position: relative;
  }
  .ui-ansc__cite::after {
    content: "";
    position: absolute;
    inset: -10px -4px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ansc *,
  .ui-ansc *::before,
  .ui-ansc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ansc {
  --ui-ansc-card: #1c1c1e;
  --ui-ansc-ink: rgba(255, 255, 255, 0.9);
  --ui-ansc-strong: #ffffff;
  --ui-ansc-text: rgba(255, 255, 255, 0.62);
  --ui-ansc-muted: rgba(255, 255, 255, 0.46);
  --ui-ansc-faint: rgba(255, 255, 255, 0.28);
  --ui-ansc-icon: rgba(255, 255, 255, 0.5);
  --ui-ansc-line: rgba(255, 255, 255, 0.08);
  --ui-ansc-fill: rgba(255, 255, 255, 0.08);
  --ui-ansc-fill-strong: rgba(255, 255, 255, 0.13);
  --ui-ansc-wash: rgba(255, 255, 255, 0.025);
  --ui-ansc-accent: #4d8dff;
  --ui-ansc-ok: #3ec27a;
  --ui-ansc-shine: #ffffff;
  --ui-ansc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-ansc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-ansc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ansc__source[data-lit] {
  box-shadow: 0 0 0 0.5px rgba(255, 255, 255, 0.16);
}
@container (max-width: 480px) {
  :where(.dark, [data-theme="dark"]) .ui-ansc__rest[data-lit-narrow] {
    box-shadow: 0 0 0 0.5px rgba(255, 255, 255, 0.16);
  }
}
:where(.dark, [data-theme="dark"]) .ui-ansc__stop:hover {
  background: #232326;
}
:where(.dark, [data-theme="dark"]) .ui-ansc__favicon {
  box-shadow: 0 0 0 0.5px rgba(255, 255, 255, 0.14);
}
`;export{n as default};
