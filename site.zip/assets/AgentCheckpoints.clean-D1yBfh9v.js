const n=`.ui-ackc {
  --ui-ackc-card: #ffffff;
  --ui-ackc-strong: #000000;
  --ui-ackc-ink: rgba(0, 0, 0, 0.88);
  --ui-ackc-text: rgba(0, 0, 0, 0.65);
  --ui-ackc-muted: rgba(0, 0, 0, 0.65);
  --ui-ackc-faint: rgba(0, 0, 0, 0.65);
  --ui-ackc-line: rgba(0, 0, 0, 0.06);
  --ui-ackc-hover: rgba(0, 0, 0, 0.025);
  --ui-ackc-chip: rgba(0, 0, 0, 0.05);
  --ui-ackc-link: #82bcff;
  --ui-ackc-rail: rgba(0, 0, 0, 0.12);
  --ui-ackc-dot: #82bcff;
  --ui-ackc-head: #0060e2;
  --ui-ackc-failed-bg: rgba(215, 36, 0, 0.08);
  --ui-ackc-failed-ink: #c42b0e;
  --ui-ackc-focus: rgba(0, 96, 226, 0.7);
  --ui-ackc-dim: 0.5;
  --ui-ackc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ackc-row: 30px;
  --ui-ackc-max: 420px;
  --ui-ackc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  border-radius: 12px;
  background: var(--ui-ackc-card);
  box-shadow: var(--ui-ackc-shadow);
  container: ui-ackc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-ackc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ackc *,
.ui-ackc *::before,
.ui-ackc *::after {
  box-sizing: border-box;
}
.ui-ackc svg {
  display: block;
  flex: none;
}
.ui-ackc__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 12px 16px 6px 14px;
}
.ui-ackc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-ackc-muted);
}
.ui-ackc__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-ackc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ackc__task {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ackc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ackc__sum {
  flex: none;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ackc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-ackc__empty {
  margin: 0;
  padding: 28px 16px;
  text-align: center;
  color: var(--ui-ackc-muted);
}
.ui-ackc__list {
  position: relative;
  height: calc(var(--ui-ackc-rows) * var(--ui-ackc-row) + 10px);
  max-height: var(--ui-ackc-max);
  transition: height 220ms var(--ui-ackc-ease);
  margin: 0;
  padding: 0 0 10px;
  overflow: hidden;
  overscroll-behavior: contain;
  list-style: none;
  scrollbar-width: thin;
}
.ui-ackc__list[data-scrolls] {
  overflow-y: auto;
}
.ui-ackc__list:focus {
  outline: none;
}
.ui-ackc__rail {
  position: absolute;
  top: 0;
  left: 0;
  overflow: visible;
  pointer-events: none;
}
.ui-ackc__line {
  fill: none;
  stroke: var(--ui-ackc-rail);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-dasharray: 1;
  stroke-dashoffset: 0;
  transition: stroke 200ms ease;
  animation: ui-ackc-draw 220ms var(--ui-ackc-ease) both;
}
.ui-ackc__line[data-live] {
  stroke: var(--ui-ackc-link);
}
.ui-ackc__line[data-fork] {
  animation-duration: 380ms;
}
.ui-ackc__dot circle {
  fill: var(--ui-ackc-card);
  stroke: var(--ui-ackc-rail);
  stroke-width: 1.5;
  transition:
    fill 200ms ease,
    stroke 200ms ease;
}
.ui-ackc__dot[data-live] circle {
  fill: var(--ui-ackc-dot);
  stroke: var(--ui-ackc-card);
}
.ui-ackc__dot[data-head] circle {
  fill: var(--ui-ackc-head);
  stroke: var(--ui-ackc-card);
}
.ui-ackc__dot {
  animation: ui-ackc-pop 180ms var(--ui-ackc-ease) both;
  transform-box: fill-box;
  transform-origin: center;
}
.ui-ackc__glint {
  transform-box: fill-box;
  transform-origin: center;
  animation: ui-ackc-glint 700ms 120ms ease-in-out both;
}
.ui-ackc__row {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  height: var(--ui-ackc-row);
  padding: 0 14px 0 var(--ui-ackc-gutter);
  outline: none;
  color: var(--ui-ackc-ink);
  transition: padding-left 240ms var(--ui-ackc-ease);
  animation: ui-ackc-rise 180ms var(--ui-ackc-ease) both;
}
.ui-ackc__row::before {
  content: "";
  position: absolute;
  inset: 2px 6px;
  z-index: -1;
  border-radius: 7px;
  background: var(--ui-ackc-hover);
  opacity: 0;
  transition: opacity 150ms ease;
}
.ui-ackc__row:hover::before,
.ui-ackc__row:focus-visible::before {
  opacity: 1;
}
.ui-ackc__row:focus-visible::before {
  outline: 2px solid var(--ui-ackc-focus);
  outline-offset: -2px;
}
.ui-ackc__list {
  isolation: isolate;
}
.ui-ackc__row:not([data-live]) > :not(.ui-ackc__rewind) {
  opacity: var(--ui-ackc-dim);
  transition: opacity 200ms ease;
}
.ui-ackc__row:not([data-live]):is(:hover, :focus-visible)
  > :not(.ui-ackc__rewind) {
  opacity: 0.8;
}
.ui-ackc__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  margin-right: -1px;
  border-radius: 5px;
  background: var(--ui-ackc-card);
  box-shadow: var(--ui-ackc-shadow);
}
.ui-ackc__icon > svg {
  width: 11px;
  height: 11px;
}
.ui-ackc__name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: opacity 200ms ease;
}
.ui-ackc__row[data-status="running"] .ui-ackc__name {
  background: linear-gradient(
      90deg,
      var(--ui-ackc-ink) 0 40%,
      var(--ui-ackc-faint) 50%,
      var(--ui-ackc-ink) 60% 100%
    )
    0 0 / 250% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-ackc-shine 800ms linear infinite;
}
.ui-ackc__row[data-status="stopped"] .ui-ackc__name {
  color: var(--ui-ackc-muted);
}
.ui-ackc__attempt,
.ui-ackc__badge {
  flex: none;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-ackc-chip);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-ackc-text);
  white-space: nowrap;
}
.ui-ackc__badge {
  background: var(--ui-ackc-failed-bg);
  color: var(--ui-ackc-failed-ink);
}
.ui-ackc__meta {
  display: flex;
  flex: none;
  align-items: center;
  gap: 10px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ackc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  transition: opacity 150ms ease;
}
.ui-ackc__time {
  min-width: 30px;
  text-align: right;
}
.ui-ackc__files,
.ui-ackc__stopped {
  color: var(--ui-ackc-faint);
}
.ui-ackc__files {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  width: 58px;
}
.ui-ackc__files svg {
  color: var(--ui-ackc-muted);
}
.ui-ackc__rewind {
  position: absolute;
  top: 50%;
  right: 8px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 22px;
  margin: 0;
  padding: 0 9px 0 7px;
  border: 0;
  border-radius: 6px;
  background: var(--ui-ackc-card);
  box-shadow: var(--ui-ackc-shadow);
  font: inherit;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-ackc-ink);
  cursor: pointer;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-50%) scale(0.96);
  transition:
    opacity 150ms ease,
    transform 150ms ease;
}
.ui-ackc__rewind svg {
  color: var(--ui-ackc-muted);
}
.ui-ackc__row:is(:hover, :focus-visible) .ui-ackc__rewind {
  opacity: 1;
  pointer-events: auto;
  transform: translateY(-50%);
}
.ui-ackc__row:has(.ui-ackc__rewind):is(:hover, :focus-visible) .ui-ackc__meta {
  opacity: 0;
}
.ui-ackc__rewind:active {
  transform: translateY(-50%) scale(0.97);
}
@media (hover: none) {
  .ui-ackc__rewind {
    right: 6px;
    height: 26px;
  }
}
@container ui-ackc (max-width: 420px) {
  .ui-ackc__task,
  .ui-ackc__files {
    display: none;
  }
}
@keyframes ui-ackc-draw {
  from {
    stroke-dashoffset: 1;
  }
}
@keyframes ui-ackc-pop {
  from {
    opacity: 0;
    transform: scale(0.4);
  }
}
@keyframes ui-ackc-rise {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
}
@keyframes ui-ackc-glint {
  from {
    transform: translateX(-10px) rotate(20deg);
  }
  to {
    transform: translateX(10px) rotate(20deg);
  }
}
@keyframes ui-ackc-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ackc *,
  .ui-ackc *::before,
  .ui-ackc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-ackc__row[data-status="running"] .ui-ackc__name {
    background: none;
    color: var(--ui-ackc-ink);
  }
  .ui-ackc__glint {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ackc {
  --ui-ackc-card: #1c1c1f;
  --ui-ackc-strong: #ffffff;
  --ui-ackc-ink: rgba(255, 255, 255, 0.9);
  --ui-ackc-text: rgba(255, 255, 255, 0.62);
  --ui-ackc-muted: rgba(255, 255, 255, 0.45);
  --ui-ackc-faint: rgba(255, 255, 255, 0.28);
  --ui-ackc-line: rgba(255, 255, 255, 0.08);
  --ui-ackc-hover: rgba(255, 255, 255, 0.04);
  --ui-ackc-chip: rgba(255, 255, 255, 0.07);
  --ui-ackc-link: #3d7fd6;
  --ui-ackc-rail: rgba(255, 255, 255, 0.16);
  --ui-ackc-dot: #3d7fd6;
  --ui-ackc-head: #5b9aff;
  --ui-ackc-failed-bg: rgba(255, 90, 60, 0.14);
  --ui-ackc-failed-ink: #ff8a70;
  --ui-ackc-focus: rgba(77, 141, 255, 0.8);
  --ui-ackc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
