const n=`.ui-af {
  --ui-af-tray: #f0f0f0;
  --ui-af-card: #ffffff;
  --ui-af-strong: #171717;
  --ui-af-ink: #171717;
  --ui-af-text: #6b6b6b;
  --ui-af-muted: #626873;
  --ui-af-faint: #6b6b6b;
  --ui-af-line: #ececec;
  --ui-af-fill: #ececec;
  --ui-af-hover: #f6f6f6;
  --ui-af-select: #f2f2f3;
  --ui-af-run-bg: rgba(47, 107, 255, 0.12);
  --ui-af-run-edge: rgba(47, 107, 255, 0.55);
  --ui-af-done-bg: #e4e4e6;
  --ui-af-done-edge: #d6d6d9;
  --ui-af-fail-bg: #fdecea;
  --ui-af-fail-edge: rgba(194, 51, 31, 0.45);
  --ui-af-crit: #c2331f;
  --ui-af-warn: #a45200;
  --ui-af-note: #2a5ee5;
  --ui-af-focus: rgba(0, 96, 226, 0.7);
  --ui-af-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-af-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-af-row: 40px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 640px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-af-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-af-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-af *,
.ui-af *::before,
.ui-af *::after {
  box-sizing: border-box;
}
:where(.ui-af) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-af button:focus-visible {
  outline: 2px solid var(--ui-af-focus);
  outline-offset: 2px;
}
.ui-af :is(ul, ol) {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-af svg {
  display: block;
  flex: none;
}
.ui-af b {
  font-weight: 500;
}
.ui-af__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-af__card {
  border-radius: 16px;
  background: var(--ui-af-card);
  box-shadow: var(--ui-af-shadow);
  overflow: hidden;
}
.ui-af__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 10px 12px 12px 14px;
}
.ui-af__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: #0060e2;
}
.ui-af__title {
  font-weight: 600;
  color: var(--ui-af-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-af__progress {
  flex: 1 0 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-af-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-af__totals {
  display: flex;
  flex: none;
  gap: 12px;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
}
.ui-af__totals > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: color 300ms ease;
}
.ui-af__totals > span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
}
.ui-af__totals [data-severity="critical"] {
  color: var(--ui-af-crit);
}
.ui-af__totals [data-severity="warning"] {
  color: var(--ui-af-warn);
}
.ui-af__totals [data-zero] {
  color: var(--ui-af-faint);
}
.ui-af__totals b,
.ui-af__found b {
  display: inline-block;
  font-variant-numeric: tabular-nums;
  animation: ui-af-roll 420ms var(--ui-af-ease);
}
.ui-af__agents {
  padding: 6px;
}
.ui-af__agent {
  display: grid;
  grid-template-columns:
    26px minmax(0, 1fr) 128px max(40px, var(--ui-af-count-w))
    max(60px, var(--ui-af-found-w));
  align-items: center;
  gap: 12px;
  width: 100%;
  height: 52px;
  padding: 0 10px;
  border-radius: 12px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-af__agent:hover {
  background: var(--ui-af-hover);
}
.ui-af__agent[aria-pressed="true"] {
  background: var(--ui-af-select);
}
.ui-af__agent[data-dim] {
  opacity: 0.5;
}
.ui-af__agent[data-dim]:hover {
  opacity: 0.8;
}
.ui-af__avatar {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  overflow: hidden;
  border-radius: 50%;
  background: var(--ui-af-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-af-text);
}
.ui-af__avatar[data-logo] {
  background: var(--ui-af-card);
  box-shadow: var(--ui-af-shadow);
}
.ui-af__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-af__avatar > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-af__who {
  display: grid;
  min-width: 0;
}
.ui-af__name {
  overflow: hidden;
  font-weight: 500;
  line-height: 19px;
  color: var(--ui-af-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-af__step {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 17px;
  color: var(--ui-af-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-af-swap 360ms var(--ui-af-ease);
}
.ui-af__track {
  position: relative;
  height: 8px;
  border-radius: 4px;
  background: var(--ui-af-fill);
  overflow: hidden;
}
.ui-af__fill {
  position: absolute;
  inset: 0 auto 0 0;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-af-done-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-af-done-edge);
  transition:
    width 700ms var(--ui-af-ease),
    background-color 300ms ease;
}
.ui-af__agent[data-status="running"] .ui-af__fill {
  background: var(--ui-af-run-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-af-run-edge);
}
.ui-af__agent[data-status="failed"] .ui-af__fill {
  background: var(--ui-af-fail-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-af-fail-edge);
}
.ui-af__agent[data-status="running"] .ui-af__fill::before {
  content: "";
  position: absolute;
  inset: 0 auto 0 0;
  width: 40px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--ui-af-card),
    transparent
  );
  opacity: 0.7;
  animation: ui-af-sheen 1500ms linear infinite;
}
.ui-af__agent[data-status="running"] .ui-af__fill::after {
  content: "";
  position: absolute;
  inset: 0 0 0 auto;
  width: 18px;
  background: linear-gradient(90deg, transparent, var(--ui-af-run-edge));
  animation: ui-af-breathe 1100ms ease-in-out infinite alternate;
}
.ui-af__count {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-af-muted);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-af__found {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  font-size: 12px;
  line-height: 16px;
}
.ui-af__found > span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  min-width: 22px;
}
.ui-af__found [data-zero] {
  opacity: 0.28;
}
.ui-af__found [data-zero] .ui-af__mark {
  color: var(--ui-af-faint);
}
.ui-af__found [data-severity="critical"] b {
  color: var(--ui-af-crit);
}
.ui-af__found [data-severity="warning"] b {
  color: var(--ui-af-warn);
}
.ui-af__found [data-zero] b {
  color: var(--ui-af-muted);
}
.ui-af__mark[data-severity="critical"] {
  color: var(--ui-af-crit);
}
.ui-af__mark[data-severity="warning"] {
  color: var(--ui-af-warn);
}
.ui-af__mark[data-severity="note"] {
  color: var(--ui-af-note);
}
.ui-af__feed-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 4px 14px 0;
}
.ui-af__label {
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-af-text);
}
.ui-af__chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 22px;
  padding: 0 6px 0 9px;
  border-radius: 999px;
  background: var(--ui-af-card);
  box-shadow: var(--ui-af-shadow);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-af-ink);
  animation: ui-af-swap 260ms var(--ui-af-ease);
}
.ui-af__chip {
  max-width: 60%;
}
.ui-af__chip-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-af__chip svg {
  color: var(--ui-af-muted);
}
.ui-af__feed {
  position: relative;
  height: calc(var(--ui-af-shown, var(--ui-af-rows)) * var(--ui-af-row) + 12px);
  transition: height 520ms var(--ui-af-ease);
  margin: 6px;
  overflow: hidden;
}
.ui-af__slot {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  height: var(--ui-af-row);
  transition:
    transform 520ms var(--ui-af-ease),
    opacity 320ms ease;
}
.ui-af__slot[data-out] {
  opacity: 0;
  pointer-events: none;
}
.ui-af__finding {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 12px;
  transition: background-color 160ms ease;
}
.ui-af__finding:hover {
  background: var(--ui-af-hover);
}
.ui-af__in {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 100%;
  min-width: 0;
  padding: 0 10px;
  animation: ui-af-in 560ms var(--ui-af-ease);
}
.ui-af__ftitle {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-af-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-af__meta {
  display: flex;
  flex: 1 1 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-af-muted);
  white-space: nowrap;
}
.ui-af__meta code {
  overflow: hidden;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  text-overflow: ellipsis;
}
.ui-af__who-name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-af__meta code {
  flex: 0 1 auto;
  min-width: 0;
}
.ui-af__dot {
  color: var(--ui-af-faint);
}
.ui-af__time {
  flex: none;
  min-width: 28px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-af-faint);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-af__none {
  display: grid;
  place-items: center;
  height: 48px;
  font-size: 12px;
  color: var(--ui-af-muted);
}
.ui-af__empty {
  display: grid;
  place-items: center;
  height: var(--ui-af-row);
  font-size: 12px;
  color: var(--ui-af-muted);
}
@keyframes ui-af-in {
  from {
    opacity: 0;
    transform: translateY(-10px);
    filter: blur(2px);
  }
}
@keyframes ui-af-swap {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-af-roll {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }
}
@keyframes ui-af-sheen {
  from {
    transform: translateX(-40px);
  }
  to {
    transform: translateX(160px);
  }
}
@keyframes ui-af-breathe {
  from {
    opacity: 0.45;
  }
  to {
    opacity: 1;
  }
}
@container (max-width: 480px) {
  .ui-af__agent {
    grid-template-columns: 26px minmax(0, 1fr) 64px max(
        52px,
        var(--ui-af-found-w)
      );
    gap: 10px;
  }
  .ui-af__count {
    display: none;
  }
  .ui-af__progress {
    display: none;
  }
  .ui-af__meta {
    display: none;
  }
  .ui-af__ftitle {
    flex: 1;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-af *,
  .ui-af *::before,
  .ui-af *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-af {
  --ui-af-tray: #111113;
  --ui-af-card: #19191b;
  --ui-af-strong: #ffffff;
  --ui-af-ink: rgba(255, 255, 255, 0.9);
  --ui-af-text: rgba(255, 255, 255, 0.62);
  --ui-af-muted: rgba(255, 255, 255, 0.45);
  --ui-af-faint: rgba(255, 255, 255, 0.28);
  --ui-af-line: rgba(255, 255, 255, 0.08);
  --ui-af-fill: rgba(255, 255, 255, 0.08);
  --ui-af-hover: rgba(255, 255, 255, 0.04);
  --ui-af-select: rgba(255, 255, 255, 0.06);
  --ui-af-run-bg: #0077ff3a;
  --ui-af-run-edge: rgba(112, 184, 255, 0.6);
  --ui-af-done-bg: rgba(255, 255, 255, 0.1);
  --ui-af-done-edge: rgba(255, 255, 255, 0.16);
  --ui-af-fail-bg: #ff35232b;
  --ui-af-fail-edge: rgba(255, 151, 125, 0.45);
  --ui-af-crit: #ff977d;
  --ui-af-warn: #ffa057;
  --ui-af-note: #70b8ff;
  --ui-af-focus: rgba(77, 141, 255, 0.8);
  --ui-af-shadow: 0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-af__spark {
  color: #70b8ff;
}
:where(.dark, [data-theme="dark"])
  .ui-af__agent[data-status="running"]
  .ui-af__fill::before {
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.14),
    transparent
  );
}
`;export{n as default};
