const n=`.ui-afc {
  --ui-afc-card: #ffffff;
  --ui-afc-strong: #000000;
  --ui-afc-ink: rgba(0, 0, 0, 0.88);
  --ui-afc-text: rgba(0, 0, 0, 0.65);
  --ui-afc-muted: rgba(0, 0, 0, 0.65);
  --ui-afc-faint: rgba(0, 0, 0, 0.65);
  --ui-afc-line: rgba(0, 0, 0, 0.06);
  --ui-afc-fill: rgba(0, 0, 0, 0.06);
  --ui-afc-hover: rgba(0, 0, 0, 0.025);
  --ui-afc-select: rgba(0, 0, 0, 0.04);
  --ui-afc-run-bg: rgba(0, 96, 226, 0.1);
  --ui-afc-run-edge: rgba(0, 96, 226, 0.32);
  --ui-afc-done-bg: rgba(0, 0, 0, 0.05);
  --ui-afc-done-edge: rgba(0, 0, 0, 0.1);
  --ui-afc-fail-bg: #f52b0018;
  --ui-afc-fail-edge: rgba(215, 36, 0, 0.34);
  --ui-afc-crit: #cd2200;
  --ui-afc-warn: #b74400;
  --ui-afc-note: #0060e2;
  --ui-afc-focus: rgba(0, 96, 226, 0.7);
  --ui-afc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-afc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-afc-row: 40px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 640px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-afc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-afc *,
.ui-afc *::before,
.ui-afc *::after {
  box-sizing: border-box;
}
:where(.ui-afc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-afc button:focus-visible {
  outline: 2px solid var(--ui-afc-focus);
  outline-offset: -2px;
}
.ui-afc :is(ul, ol) {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-afc svg {
  display: block;
  flex: none;
}
.ui-afc b {
  font-weight: 500;
}
.ui-afc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-afc__card {
  border-radius: 10px;
  background: var(--ui-afc-card);
  box-shadow: var(--ui-afc-shadow);
  overflow: hidden;
}
.ui-afc__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 14px 16px;
  border-bottom: 0.5px solid var(--ui-afc-line);
}
.ui-afc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: #0060e2;
}
.ui-afc__title {
  font-weight: 500;
  color: var(--ui-afc-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-afc__progress {
  flex: 1 0 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-afc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-afc__totals {
  display: flex;
  flex: none;
  gap: 12px;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
}
.ui-afc__totals > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  transition: color 300ms ease;
}
.ui-afc__totals > span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
}
.ui-afc__totals [data-severity="critical"] {
  color: var(--ui-afc-crit);
}
.ui-afc__totals [data-severity="warning"] {
  color: var(--ui-afc-warn);
}
.ui-afc__totals [data-zero] {
  color: var(--ui-afc-faint);
}
.ui-afc__totals b,
.ui-afc__found b {
  display: inline-block;
  font-variant-numeric: tabular-nums;
  animation: ui-afc-roll 420ms var(--ui-afc-ease);
}
.ui-afc__agents {
  padding: 6px 6px 2px;
}
.ui-afc__agent {
  display: grid;
  grid-template-columns:
    24px minmax(0, 1fr) 128px max(40px, var(--ui-afc-count-w))
    max(60px, var(--ui-afc-found-w));
  align-items: center;
  gap: 12px;
  width: 100%;
  height: 48px;
  padding: 0 10px;
  border-radius: 8px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-afc__agent:hover {
  background: var(--ui-afc-hover);
}
.ui-afc__agent[aria-pressed="true"] {
  background: var(--ui-afc-select);
}
.ui-afc__agent[data-dim] {
  opacity: 0.5;
}
.ui-afc__agent[data-dim]:hover {
  opacity: 0.8;
}
.ui-afc__avatar {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-afc-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-afc-text);
}
.ui-afc__avatar[data-logo] {
  background: var(--ui-afc-card);
  box-shadow: var(--ui-afc-shadow);
}
.ui-afc__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-afc__avatar > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-afc__who {
  display: grid;
  min-width: 0;
}
.ui-afc__name {
  overflow: hidden;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-afc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-afc__step {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-afc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-afc-swap 360ms var(--ui-afc-ease);
}
.ui-afc__track {
  position: relative;
  height: 6px;
  border-radius: 3px;
  background: var(--ui-afc-fill);
  overflow: hidden;
}
.ui-afc__fill {
  position: absolute;
  inset: 0 auto 0 0;
  overflow: hidden;
  border-radius: 3px;
  background: var(--ui-afc-done-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-afc-done-edge);
  transition:
    width 700ms var(--ui-afc-ease),
    background-color 300ms ease;
}
.ui-afc__agent[data-status="running"] .ui-afc__fill {
  background: var(--ui-afc-run-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-afc-run-edge);
}
.ui-afc__agent[data-status="failed"] .ui-afc__fill {
  background: var(--ui-afc-fail-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-afc-fail-edge);
}
.ui-afc__agent[data-status="running"] .ui-afc__fill::before {
  content: "";
  position: absolute;
  inset: 0 auto 0 0;
  width: 40px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--ui-afc-card),
    transparent
  );
  opacity: 0.7;
  animation: ui-afc-sheen 1500ms linear infinite;
}
.ui-afc__agent[data-status="running"] .ui-afc__fill::after {
  content: "";
  position: absolute;
  inset: 0 0 0 auto;
  width: 18px;
  background: linear-gradient(90deg, transparent, var(--ui-afc-run-edge));
  animation: ui-afc-breathe 1100ms ease-in-out infinite alternate;
}
.ui-afc__count {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-afc-muted);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-afc__found {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  font-size: 12px;
  line-height: 16px;
}
.ui-afc__found > span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  min-width: 22px;
}
.ui-afc__found [data-zero] {
  opacity: 0.28;
}
.ui-afc__found [data-zero] .ui-afc__mark {
  color: var(--ui-afc-faint);
}
.ui-afc__found [data-severity="critical"] b {
  color: var(--ui-afc-crit);
}
.ui-afc__found [data-severity="warning"] b {
  color: var(--ui-afc-warn);
}
.ui-afc__found [data-zero] b {
  color: var(--ui-afc-muted);
}
.ui-afc__mark[data-severity="critical"] {
  color: var(--ui-afc-crit);
}
.ui-afc__mark[data-severity="warning"] {
  color: var(--ui-afc-warn);
}
.ui-afc__mark[data-severity="note"] {
  color: var(--ui-afc-note);
}
.ui-afc__feed-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  margin-top: 4px;
  padding: 0 16px;
  border-top: 0.5px solid var(--ui-afc-line);
}
.ui-afc__label {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-afc-muted);
}
.ui-afc__chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 6px 0 8px;
  border-radius: 6px;
  background: var(--ui-afc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-afc-ink);
  animation: ui-afc-swap 260ms var(--ui-afc-ease);
}
.ui-afc__chip {
  max-width: 60%;
}
.ui-afc__chip-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-afc__chip svg {
  color: var(--ui-afc-muted);
}
.ui-afc__feed {
  position: relative;
  height: calc(
    var(--ui-afc-shown, var(--ui-afc-rows)) * var(--ui-afc-row) + 8px
  );
  transition: height 520ms var(--ui-afc-ease);
  margin: 0 6px;
  padding-bottom: 8px;
  overflow: hidden;
}
.ui-afc__slot {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  height: var(--ui-afc-row);
  transition:
    transform 520ms var(--ui-afc-ease),
    opacity 320ms ease;
}
.ui-afc__slot[data-out] {
  opacity: 0;
  pointer-events: none;
}
.ui-afc__finding {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 8px;
  transition: background-color 160ms ease;
}
.ui-afc__finding:hover {
  background: var(--ui-afc-hover);
}
.ui-afc__in {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 100%;
  min-width: 0;
  padding: 0 10px;
  animation: ui-afc-in 560ms var(--ui-afc-ease);
}
.ui-afc__ftitle {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-afc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-afc__meta {
  display: flex;
  flex: 1 1 0;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-afc-muted);
  white-space: nowrap;
}
.ui-afc__meta code {
  overflow: hidden;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  text-overflow: ellipsis;
}
.ui-afc__who-name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-afc__meta code {
  flex: 0 1 auto;
  min-width: 0;
}
.ui-afc__dot {
  color: var(--ui-afc-faint);
}
.ui-afc__time {
  flex: none;
  min-width: 28px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-afc-faint);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-afc__none {
  display: grid;
  place-items: center;
  height: 48px;
  font-size: 12px;
  color: var(--ui-afc-muted);
}
.ui-afc__empty {
  display: grid;
  place-items: center;
  height: var(--ui-afc-row);
  font-size: 12px;
  color: var(--ui-afc-muted);
}
@keyframes ui-afc-in {
  from {
    opacity: 0;
    transform: translateY(-10px);
    filter: blur(2px);
  }
}
@keyframes ui-afc-swap {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-afc-roll {
  from {
    opacity: 0;
    transform: translateY(-5px);
  }
}
@keyframes ui-afc-sheen {
  from {
    transform: translateX(-40px);
  }
  to {
    transform: translateX(160px);
  }
}
@keyframes ui-afc-breathe {
  from {
    opacity: 0.45;
  }
  to {
    opacity: 1;
  }
}
@container (max-width: 480px) {
  .ui-afc__agent {
    grid-template-columns: 24px minmax(0, 1fr) 64px max(
        52px,
        var(--ui-afc-found-w)
      );
    gap: 10px;
  }
  .ui-afc__count {
    display: none;
  }
  .ui-afc__progress {
    display: none;
  }
  .ui-afc__meta {
    display: none;
  }
  .ui-afc__ftitle {
    flex: 1;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-afc *,
  .ui-afc *::before,
  .ui-afc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-afc {
  --ui-afc-card: #1c1c1f;
  --ui-afc-strong: #ffffff;
  --ui-afc-ink: rgba(255, 255, 255, 0.9);
  --ui-afc-text: rgba(255, 255, 255, 0.62);
  --ui-afc-muted: rgba(255, 255, 255, 0.45);
  --ui-afc-faint: rgba(255, 255, 255, 0.28);
  --ui-afc-line: rgba(255, 255, 255, 0.08);
  --ui-afc-fill: rgba(255, 255, 255, 0.08);
  --ui-afc-hover: rgba(255, 255, 255, 0.04);
  --ui-afc-select: rgba(255, 255, 255, 0.06);
  --ui-afc-run-bg: rgba(112, 184, 255, 0.18);
  --ui-afc-run-edge: rgba(112, 184, 255, 0.5);
  --ui-afc-done-bg: rgba(255, 255, 255, 0.08);
  --ui-afc-done-edge: rgba(255, 255, 255, 0.14);
  --ui-afc-fail-bg: #ff35232b;
  --ui-afc-fail-edge: rgba(255, 151, 125, 0.45);
  --ui-afc-crit: #ff977d;
  --ui-afc-warn: #ffa057;
  --ui-afc-note: #70b8ff;
  --ui-afc-focus: rgba(77, 141, 255, 0.8);
  --ui-afc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-afc__spark {
  color: #70b8ff;
}
:where(.dark, [data-theme="dark"])
  .ui-afc__agent[data-status="running"]
  .ui-afc__fill::before {
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.14),
    transparent
  );
}
`;export{n as default};
