const n=`.ui-ag {
  --ui-ag-focus: rgba(0, 96, 226, 0.7);
  --ui-ag-ink: #171717;
  --ui-ag-text: #404040;
  --ui-ag-muted: #8f8f8f;
  --ui-ag-base-top: #f4f4f6;
  --ui-ag-base-bottom: #e9e9ee;
  --ui-ag-screen: #ffffff;
  --ui-ag-page: #fafafa;
  --ui-ag-screen-line: #ececec;
  --ui-ag-chip: #ffffff;
  --ui-ag-chip-line: #e5e5e5;
  --ui-ag-soft: #f5f5f5;
  --ui-ag-btn: #ffffff;
  --ui-ag-shine: rgba(255, 255, 255, 0.75);
  --ui-ag-ok: #1e8a4f;
  --ui-ag-ok-bg: #e6f5ec;
  --ui-ag-height: 560px;
  --ui-ag-side: 104px;
  --ui-ag-gap: 14px;
  --ui-ag-open: min(70cqw, 1120px);
  --ui-ag-ease: cubic-bezier(0.65, 0, 0.25, 1);
  container-type: inline-size;
  overflow: hidden;
  padding: 8px 0 8px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-ag-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-ag *,
.ui-ag *::before,
.ui-ag *::after {
  box-sizing: border-box;
}
.ui-ag button {
  font: inherit;
  color: inherit;
  margin: 0;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ag button:focus-visible {
  outline: 2px solid var(--ui-ag-focus);
  outline-offset: 2px;
}
.ui-ag__viewport:focus-visible {
  outline: none;
}
.ui-ag__viewport:focus-visible .ui-ag__panel[data-open] {
  outline: 2px solid var(--ui-ag-focus);
  outline-offset: -2px;
}
.ui-ag .ui-ag__pick:focus-visible {
  outline-offset: -2px;
}
.ui-ag__head {
  max-width: 620px;
  margin: 0 auto 36px;
  padding: 0 20px;
  text-align: center;
}
.ui-ag__head h2 {
  overflow-wrap: anywhere;
  margin: 0;
  font-size: 30px;
  font-weight: 600;
  letter-spacing: -0.025em;
  line-height: 1.15;
}
.ui-ag__head p {
  overflow-wrap: anywhere;
  margin: 12px 0 0;
  font-size: 16px;
  line-height: 1.5;
  color: var(--ui-ag-muted);
}
.ui-ag__viewport {
  overflow: hidden;
}
.ui-ag__track {
  display: flex;
  gap: var(--ui-ag-gap);
  width: max-content;
  height: var(--ui-ag-height);
  transform: translateX(
    calc(
      50cqw - var(--pos) * (var(--ui-ag-side) + var(--ui-ag-gap)) -
        var(--ui-ag-open) / 2
    )
  );
  transition: transform 620ms var(--ui-ag-ease);
}
.ui-ag__track[data-snap],
.ui-ag__track[data-snap] * {
  transition: none !important;
  animation: none !important;
}
.ui-ag__panel {
  position: relative;
  flex: 0 0 var(--ui-ag-side);
  overflow: hidden;
  border-radius: 20px;
  transition: flex-basis 620ms var(--ui-ag-ease);
}
.ui-ag__panel[data-open] {
  flex-basis: var(--ui-ag-open);
}
.ui-ag__art {
  position: absolute;
  inset: 0;
  background:
    linear-gradient(
      118deg,
      transparent 38%,
      var(--ui-ag-shine) 47%,
      transparent 57%
    ),
    radial-gradient(
      110% 80% at 0% 0%,
      color-mix(in srgb, var(--a) 70%, transparent) 0%,
      transparent 60%
    ),
    radial-gradient(90% 70% at 100% 100%, var(--b) 0%, transparent 72%),
    radial-gradient(
      60% 50% at 30% 100%,
      color-mix(in srgb, var(--a) 28%, transparent) 0%,
      transparent 70%
    ),
    linear-gradient(180deg, var(--ui-ag-base-top), var(--ui-ag-base-bottom));
  filter: saturate(0.35);
  transition:
    filter 500ms ease,
    transform 900ms var(--ui-ag-ease);
}
.ui-ag__panel:hover .ui-ag__art {
  filter: none;
}
.ui-ag__panel[data-open] .ui-ag__art {
  filter: none;
}
.ui-ag__panel[data-far] .ui-ag__art {
  filter: saturate(0.12);
}
.ui-ag__pick {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: flex-end;
  padding: 0 0 22px 16px;
  border: 0;
  background: none;
  animation: ui-ag-fade 400ms ease 200ms both;
}
.ui-ag__label {
  writing-mode: vertical-rl;
  transform: rotate(180deg);
  font-size: 17px;
  font-weight: 500;
  letter-spacing: -0.01em;
  white-space: nowrap;
  text-orientation: sideways;
  max-height: calc(var(--ui-ag-height) - 44px);
  overflow: hidden;
  text-overflow: ellipsis;
  color: color-mix(in srgb, var(--a) 70%, var(--ui-ag-text));
  opacity: 0.85;
}
.ui-ag__panel[data-far] .ui-ag__label {
  color: var(--ui-ag-muted);
}
.ui-ag__screen {
  position: absolute;
  top: 44px;
  left: 44px;
  width: max(640px, calc(100% - 88px));
  min-height: 620px;
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-ag-page);
  box-shadow:
    0 0 0 1px var(--ui-ag-screen-line),
    0 20px 50px -20px rgba(0, 0, 0, 0.18);
  font-size: 11.5px;
  color: var(--ui-ag-text);
  opacity: 0;
  transform: translate(28px, 14px) scale(0.98);
  transition:
    opacity 260ms ease,
    transform 420ms var(--ui-ag-ease);
}
.ui-ag__panel[data-open] .ui-ag__screen {
  opacity: 1;
  transform: none;
  transition:
    opacity 420ms ease 260ms,
    transform 620ms var(--ui-ag-ease) 220ms;
}
.ui-ag__screen svg {
  width: 13px;
  height: 13px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ag__screen u {
  text-decoration: underline;
  text-decoration-color: var(--ui-ag-chip-line);
  text-underline-offset: 3px;
  text-decoration-thickness: 1.5px;
  color: var(--ui-ag-ink);
}
.ui-ag__bar {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 48px;
  padding: 0 14px;
  background: var(--ui-ag-screen);
}
.ui-ag__brand {
  width: 18px;
  height: 18px;
  border-radius: 5px;
  background: var(--ui-ag-ink);
}
.ui-ag__switch {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 8px 0 6px;
  border-radius: 8px;
  box-shadow: inset 0 0 0 1px var(--ui-ag-chip-line);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-ag-ink);
}
.ui-ag__switch {
  min-width: 0;
}
.ui-ag__switch-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ag__switch svg {
  width: 12px;
  height: 12px;
  color: var(--ui-ag-muted);
}
.ui-ag__mark,
.ui-ag__logo {
  border-radius: 5px;
  background: linear-gradient(135deg, var(--a), var(--b));
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.35);
}
.ui-ag__mark {
  flex: none;
  width: 16px;
  height: 16px;
}
.ui-ag__new {
  flex: none;
  margin-left: auto;
  padding: 5px 10px;
  border-radius: 8px;
  box-shadow:
    inset 0 0 0 1px var(--ui-ag-chip-line),
    0 1px 1px rgba(0, 0, 0, 0.04);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-ag-ink);
}
.ui-ag__avatar {
  display: inline-grid;
  place-items: center;
  width: 18px;
  height: 18px;
  flex: none;
  border-radius: 50%;
  background: var(--ui-ag-soft);
  box-shadow: inset 0 0 0 1px var(--ui-ag-chip-line);
  font-size: 7.5px;
  font-weight: 600;
  color: var(--ui-ag-text);
}
.ui-ag__bar .ui-ag__avatar {
  width: 26px;
  height: 26px;
  font-size: 9px;
}
.ui-ag__page {
  padding: 16px max(28px, calc((100% - 560px) / 2)) 24px;
}
.ui-ag__hero {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}
.ui-ag__logo {
  width: 30px;
  height: 30px;
  border-radius: 8px;
}
.ui-ag__sync {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11px;
  color: var(--ui-ag-muted);
}
.ui-ag__page h3 {
  overflow-wrap: anywhere;
  margin: 8px 0 2px;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  color: var(--ui-ag-ink);
}
.ui-ag__sub {
  margin: 0 0 12px;
  overflow: hidden;
  font-size: 11px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-ag-muted);
}
.ui-ag__kpis {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  margin-bottom: 12px;
}
.ui-ag__kpis > div {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 54px;
  grid-template-areas: "label spark" "value spark";
  column-gap: 8px;
  padding: 0 12px;
  border-left: 1px solid var(--ui-ag-screen-line);
}
.ui-ag__kpis > div:first-child {
  padding-left: 0;
  border-left: 0;
}
.ui-ag__kpis span {
  grid-area: label;
  font-size: 10.5px;
  color: var(--ui-ag-muted);
  white-space: nowrap;
}
.ui-ag__kpis b {
  grid-area: value;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.02em;
  color: var(--ui-ag-ink);
  font-variant-numeric: tabular-nums;
}
.ui-ag__screen .ui-ag__spark {
  grid-area: spark;
  align-self: end;
  width: 54px;
  height: 20px;
  margin-bottom: 2px;
  overflow: visible;
}
.ui-ag__spark path {
  fill: none;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ag__tabs {
  display: flex;
  gap: 16px;
  margin: 0 -400px 14px;
  padding: 0 400px;
  border-bottom: 1px solid var(--ui-ag-screen-line);
}
.ui-ag__tabs > * {
  padding: 0 1px 8px;
  font-size: 11.5px;
  color: var(--ui-ag-muted);
}
.ui-ag__tabs b {
  font-weight: 500;
  color: var(--ui-ag-ink);
  box-shadow: inset 0 -1.5px 0 var(--ui-ag-ink);
}
.ui-ag__page h4 {
  margin: 0;
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-ag-ink);
}
.ui-ag__hint {
  margin: 3px 0 12px;
  font-size: 11px;
  color: var(--ui-ag-muted);
}
.ui-ag__toolbar {
  display: flex;
  gap: 6px;
  margin-bottom: 14px;
}
.ui-ag__search,
.ui-ag__filter {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 30px;
  padding: 0 10px;
  border-radius: 10px;
  background: var(--ui-ag-screen);
  box-shadow: inset 0 0 0 1px var(--ui-ag-chip-line);
  font-size: 11px;
  color: var(--ui-ag-muted);
}
.ui-ag__search {
  flex: 1;
}
.ui-ag__filter {
  color: var(--ui-ag-ink);
}
.ui-ag__feed {
  position: relative;
  display: grid;
  gap: 12px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ag__feed::before {
  content: "";
  position: absolute;
  left: 12px;
  top: 24px;
  bottom: 8px;
  width: 1px;
  background: var(--ui-ag-screen-line);
}
.ui-ag__feed li {
  position: relative;
  display: grid;
  grid-template-columns: 25px minmax(0, 1fr);
  gap: 10px;
  align-items: start;
}
.ui-ag__compose .ui-ag__avatar {
  width: 25px;
  height: 25px;
  font-size: 8.5px;
}
.ui-ag__box {
  display: grid;
  gap: 18px;
  padding: 10px 10px 8px 12px;
  border-radius: 12px;
  background: var(--ui-ag-screen);
  box-shadow:
    inset 0 0 0 1px var(--ui-ag-chip-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  overflow-wrap: anywhere;
  color: var(--ui-ag-muted);
}
.ui-ag__box-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ui-ag__box-foot b {
  padding: 4px 9px;
  border-radius: 8px;
  background: var(--ui-ag-soft);
  font-size: 10.5px;
  font-weight: 500;
  color: var(--ui-ag-ink);
}
.ui-ag__dot {
  display: grid;
  place-items: center;
  width: 25px;
  height: 25px;
  border-radius: 50%;
  background: var(--ui-ag-page);
  box-shadow: inset 0 0 0 1px var(--ui-ag-chip-line);
  color: var(--ui-ag-muted);
}
.ui-ag__dot svg {
  width: 12px;
  height: 12px;
}
.ui-ag__dot--app {
  background: linear-gradient(135deg, var(--a), var(--b));
  box-shadow: none;
  color: #fff;
}
.ui-ag__line {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 5px;
  margin: 5px 0 0;
  color: var(--ui-ag-muted);
}
.ui-ag__line b {
  font-weight: 500;
  color: var(--ui-ag-ink);
}
.ui-ag__ext {
  width: 9px;
  height: 11px;
  border-radius: 2px;
  background: #f04438;
}
.ui-ag__ext[data-kind="csv"] {
  background: #30a465;
}
.ui-ag__card {
  margin: 7px 0 0;
  padding: 9px 12px;
  border-radius: 10px;
  background: var(--ui-ag-screen);
  box-shadow:
    inset 0 0 0 1px var(--ui-ag-chip-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  line-height: 1.5;
  overflow-wrap: anywhere;
  color: var(--ui-ag-ink);
}
.ui-ag__foot {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 24px;
  width: var(--ui-ag-open);
  margin: 26px auto 0;
}
.ui-ag__caption {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  line-clamp: 3;
  min-width: 0;
  max-width: 520px;
  margin: 0;
  overflow-wrap: anywhere;
  font-size: 19px;
  line-height: 1.45;
  letter-spacing: -0.01em;
  color: var(--ui-ag-muted);
  animation: ui-ag-fade 420ms ease both;
}
.ui-ag__caption b {
  font-weight: 500;
  color: var(--ui-ag-ink);
}
.ui-ag__arrows {
  display: flex;
  flex: none;
  border-radius: 12px;
  background: var(--ui-ag-btn);
  box-shadow:
    0 0 0 1px var(--ui-ag-chip-line),
    0 1px 2px rgba(0, 0, 0, 0.05);
}
.ui-ag__arrows button {
  display: grid;
  place-items: center;
  width: 42px;
  height: 38px;
  padding: 0;
  border: 0;
  background: none;
  transition: background-color 160ms ease;
}
.ui-ag__arrows button:first-child {
  border-radius: 12px 0 0 12px;
  box-shadow: 1px 0 0 var(--ui-ag-chip-line);
}
.ui-ag__arrows button:last-child {
  border-radius: 0 12px 12px 0;
}
.ui-ag__arrows button:hover {
  background: var(--ui-ag-soft);
}
.ui-ag__arrows svg {
  width: 17px;
  height: 17px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ag__empty {
  margin: 0;
  padding: 48px 20px;
  font-size: 15px;
  text-align: center;
  color: var(--ui-ag-muted);
}
.ui-ag__arrows[hidden] {
  display: none;
}
@keyframes ui-ag-fade {
  from {
    opacity: 0;
  }
}
@container (max-width: 760px) {
  .ui-ag {
    --ui-ag-height: 400px;
    --ui-ag-side: 56px;
    --ui-ag-gap: 10px;
  }
  .ui-ag {
    --ui-ag-open: calc(
      100cqw - 2 * (var(--ui-ag-side) + var(--ui-ag-gap)) - 24px
    );
  }
  .ui-ag__label {
    font-size: 14px;
  }
  .ui-ag__pick {
    padding: 0 0 16px 10px;
  }
  .ui-ag__screen {
    top: 40px;
    left: 22px;
  }
  .ui-ag__foot {
    width: calc(100cqw - 40px);
  }
  .ui-ag__caption {
    font-size: 16px;
  }
  .ui-ag__head h2 {
    font-size: 24px;
  }
}
@media (pointer: coarse) {
  .ui-ag__arrows button {
    width: 46px;
    height: 44px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ag__track,
  .ui-ag__panel,
  .ui-ag__art {
    transition: none;
  }
  .ui-ag__caption,
  .ui-ag__pick {
    animation: none;
  }
  .ui-ag__screen,
  .ui-ag__panel[data-open] .ui-ag__screen {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ag {
  --ui-ag-focus: rgba(77, 141, 255, 0.8);
  --ui-ag-ink: #ededed;
  --ui-ag-text: #c4c4c4;
  --ui-ag-muted: #8f8f8f;
  --ui-ag-base-top: #232326;
  --ui-ag-base-bottom: #1a1a1c;
  --ui-ag-screen: #232326;
  --ui-ag-page: #1c1c1f;
  --ui-ag-screen-line: rgba(255, 255, 255, 0.08);
  --ui-ag-chip: #2a2a2d;
  --ui-ag-chip-line: rgba(255, 255, 255, 0.08);
  --ui-ag-soft: #2a2a2d;
  --ui-ag-btn: #232326;
  --ui-ag-shine: rgba(255, 255, 255, 0.08);
  --ui-ag-ok: #7dcf9f;
  --ui-ag-ok-bg: rgba(125, 207, 159, 0.14);
}

.gallery-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.gallery-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.gallery-demo {
  padding-left: 0;
  padding-right: 0;
}
.card__preview .gallery-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.gallery-demo[data-fit="card"] .gallery-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 0;
}
.gallery-demo__frame {
  min-width: 0;
}
`;export{n as default};
