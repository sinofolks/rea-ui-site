const n=`.ui-agg {
  --ui-agg-tray: #f0f0f0;
  --ui-agg-panel: #ffffff;
  --ui-agg-card: #ffffff;
  --ui-agg-ink: #171717;
  --ui-agg-text: #6b6b6b;
  --ui-agg-muted: #626873;
  --ui-agg-line: #ececec;
  --ui-agg-chip: #f5f5f5;
  --ui-agg-link: #82bcff;
  --ui-agg-pulse: #2a5ee5;
  --ui-agg-glow: rgba(130, 188, 255, 0.2);
  --ui-agg-breath: rgba(47, 107, 255, 0.17);
  --ui-agg-breath-out: rgba(47, 107, 255, 0.03);
  --ui-agg-user-bg: #171717;
  --ui-agg-user-fg: #ffffff;
  --ui-agg-brand-bg: #eaf1ff;
  --ui-agg-brand-fg: #2456d6;
  --ui-agg-ok: #1fa35c;
  --ui-agg-ok-bg: #e6f6ec;
  --ui-agg-ok-fg: #187941;
  --ui-agg-warn: #f59f0a;
  --ui-agg-warn-bg: #fff3e0;
  --ui-agg-warn-fg: #a45200;
  --ui-agg-danger: #e5484d;
  --ui-agg-danger-bg: #fdecea;
  --ui-agg-danger-fg: #c2331f;
  --ui-agg-focus: rgba(0, 96, 226, 0.7);
  --ui-agg-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-agg-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-agg-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-agg *,
.ui-agg *::before,
.ui-agg *::after {
  box-sizing: border-box;
}
:where(.ui-agg) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-agg button:focus-visible {
  outline: 2px solid var(--ui-agg-focus);
  outline-offset: 2px;
}
.ui-agg p,
.ui-agg ul {
  margin: 0;
  padding: 0;
}
.ui-agg svg {
  display: block;
  flex: none;
  overflow: visible;
}
.ui-agg__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  padding: 7px 12px 9px 12px;
}
.ui-agg__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-agg-pulse);
}
.ui-agg__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-agg-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agg__sum {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  align-items: center;
  gap: 2px 14px;
  margin-left: auto;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-agg-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-agg__sum b {
  font-weight: 600;
  color: var(--ui-agg-ink);
}
.ui-agg__sum-cost {
  min-width: 42px;
  font-weight: 600;
  color: var(--ui-agg-ink);
  text-align: right;
}
.ui-agg[data-narrow] .ui-agg__bar {
  row-gap: 6px;
}
.ui-agg[data-narrow] .ui-agg__title {
  line-height: 24px;
}
.ui-agg[data-narrow] .ui-agg__sum {
  flex-basis: 100%;
  justify-content: space-between;
  gap: 2px 8px;
  margin-left: 0;
  font-size: 12px;
}
.ui-agg__panel {
  position: relative;
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-agg-panel);
  box-shadow:
    0 0 0 1px var(--ui-agg-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-agg__stage {
  position: relative;
  width: 100%;
  min-height: 200px;
  container-type: inline-size;
}
.ui-agg__svg {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-agg__halo {
  animation: ui-agg-fade-in 1200ms ease both;
}
.ui-agg__edge {
  fill: none;
  stroke: var(--ui-agg-link);
  stroke-linecap: round;
  opacity: 0.75;
  stroke-dasharray: 1 1;
  stroke-dashoffset: 0;
  animation: ui-agg-draw 560ms var(--ui-agg-ease) backwards;
  transition:
    stroke-width 700ms var(--ui-agg-ease),
    opacity 320ms ease,
    stroke 300ms ease;
}
.ui-agg__edge[data-idle] {
  opacity: 0.38;
}
.ui-agg__edge[data-live] {
  opacity: 1;
  transition-duration: 700ms, 160ms, 300ms;
}
.ui-agg__edge[data-ask] {
  stroke: var(--ui-agg-warn);
  opacity: 0.9;
}
.ui-agg__edge[data-error] {
  stroke: var(--ui-agg-danger);
  opacity: 1;
  transition-duration: 700ms, 120ms, 120ms;
}
.ui-agg__edge[data-leaving] {
  stroke-dashoffset: 0;
  animation: ui-agg-retract 420ms var(--ui-agg-ease) forwards;
}
.ui-agg[data-focus] .ui-agg__edge:not([data-near]) {
  opacity: 0.1;
}
.ui-agg[data-focus] .ui-agg__edge[data-near] {
  opacity: 1;
}
.ui-agg__pulse .ui-agg__head,
.ui-agg__pulse .ui-agg__tail {
  fill: var(--ui-agg-pulse);
}
.ui-agg__pulse[data-kind="res"] .ui-agg__head,
.ui-agg__pulse[data-kind="askres"] .ui-agg__head,
.ui-agg__pulse[data-kind="err"] .ui-agg__head {
  fill: var(--ui-agg-panel);
  stroke: var(--ui-agg-pulse);
  stroke-width: 1.75;
}
.ui-agg__pulse[data-kind="ask"] :is(.ui-agg__head, .ui-agg__tail),
.ui-agg__pulse[data-kind="askres"] .ui-agg__tail {
  fill: var(--ui-agg-warn);
}
.ui-agg__pulse[data-kind="askres"] .ui-agg__head {
  stroke: var(--ui-agg-warn);
}
.ui-agg__pulse[data-kind="err"] .ui-agg__tail {
  fill: var(--ui-agg-danger);
}
.ui-agg__pulse[data-kind="err"] .ui-agg__head {
  stroke: var(--ui-agg-danger);
}
.ui-agg[data-focus] .ui-agg__pulse {
  opacity: 0.25;
}
.ui-agg__glow {
  fill: var(--ui-agg-pulse);
  opacity: 0.16;
}
.ui-agg__pulse:is([data-kind="ask"], [data-kind="askres"]) .ui-agg__glow {
  fill: var(--ui-agg-warn);
}
.ui-agg__pulse[data-kind="err"] .ui-agg__glow {
  fill: var(--ui-agg-danger);
}
.ui-agg__ripple {
  fill: none;
  stroke: var(--ui-agg-pulse);
  stroke-width: 1.25;
}
.ui-agg__ripple:is([data-kind="ask"], [data-kind="askres"]) {
  stroke: var(--ui-agg-warn);
}
.ui-agg__ripple[data-kind="err"] {
  stroke: var(--ui-agg-danger);
  stroke-width: 2;
}
.ui-agg__nodes {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-agg__node {
  position: absolute;
  top: 0;
  left: 0;
  width: 0;
  height: 0;
  transition: opacity 320ms ease;
  will-change: transform;
}
.ui-agg[data-focus] .ui-agg__node[data-dim] {
  opacity: 0.3;
}
.ui-agg__body {
  position: absolute;
  top: 0;
  left: 0;
  transform-origin: 0 0;
  animation: ui-agg-pop 560ms var(--ui-agg-ease) both;
}
.ui-agg__node[data-leaving] .ui-agg__body {
  animation: ui-agg-out 420ms var(--ui-agg-ease) forwards;
}
.ui-agg__disc {
  position: absolute;
  top: calc(var(--d) / -2);
  left: calc(var(--d) / -2);
  display: grid;
  place-items: center;
  width: var(--d);
  height: var(--d);
  border-radius: 50%;
  background: var(--ui-agg-card);
  box-shadow:
    0 0 0 1px var(--ui-agg-line),
    0 2px 6px -2px rgba(0, 0, 0, 0.1);
  color: var(--ui-agg-text);
  pointer-events: auto;
  transition:
    width 300ms var(--ui-agg-ease),
    height 300ms var(--ui-agg-ease),
    top 300ms var(--ui-agg-ease),
    left 300ms var(--ui-agg-ease),
    box-shadow 240ms ease,
    transform 240ms var(--ui-agg-ease);
}
.ui-agg__disc::before {
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 50%;
}
.ui-agg__disc:hover,
.ui-agg__node[data-open] .ui-agg__disc {
  transform: scale(1.06);
}
.ui-agg__disc > svg {
  width: 48%;
  height: 48%;
}
.ui-agg__initials {
  font-size: 11px;
  font-weight: 600;
  color: var(--ui-agg-text);
}
.ui-agg__node[data-kind="agent"] .ui-agg__disc {
  box-shadow:
    0 0 0 4px var(--ui-agg-tray),
    0 0 0 5px var(--ui-agg-line),
    0 4px 12px -4px rgba(0, 0, 0, 0.14);
}
.ui-agg__node[data-kind="agent"] .ui-agg__disc > svg {
  width: 46%;
  height: 46%;
}
.ui-agg__node[data-kind="user"] .ui-agg__disc {
  background: var(--ui-agg-user-bg);
  color: var(--ui-agg-user-fg);
  box-shadow: 0 2px 6px -2px rgba(0, 0, 0, 0.25);
}
.ui-agg__node[data-kind="user"] .ui-agg__disc > svg {
  width: 44%;
  height: 44%;
}
.ui-agg__node[data-flash] .ui-agg__disc {
  animation: ui-agg-flash 500ms ease 3;
}
.ui-agg__ring {
  position: absolute;
  top: calc(var(--d) / -2);
  left: calc(var(--d) / -2);
  width: var(--d);
  height: var(--d);
  border-radius: 50%;
  opacity: 0;
  transition: opacity 400ms ease;
}
.ui-agg__node[data-status="working"] .ui-agg__ring {
  opacity: 1;
  animation: ui-agg-breathe 2600ms ease-in-out infinite;
}
.ui-agg__node[data-status="waiting"] .ui-agg__ring {
  opacity: 1;
  --ui-agg-breath: rgba(245, 159, 10, 0.22);
  --ui-agg-breath-out: rgba(245, 159, 10, 0.04);
  animation: ui-agg-breathe 1500ms ease-in-out infinite;
}
.ui-agg__node[data-status="error"] .ui-agg__ring {
  opacity: 1;
  box-shadow: 0 0 0 8px rgba(229, 72, 77, 0.16);
}
.ui-agg__node[data-status="waiting"] .ui-agg__disc {
  box-shadow:
    0 0 0 4px var(--ui-agg-tray),
    0 0 0 5.5px var(--ui-agg-warn),
    0 4px 12px -4px rgba(0, 0, 0, 0.14);
}
.ui-agg__node[data-status="error"] .ui-agg__disc {
  box-shadow:
    0 0 0 4px var(--ui-agg-tray),
    0 0 0 5.5px var(--ui-agg-danger),
    0 4px 12px -4px rgba(0, 0, 0, 0.14);
}
.ui-agg__badge {
  position: absolute;
  top: calc(var(--d) * -0.36 - 9px);
  left: calc(var(--d) * 0.36 - 7px);
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  box-shadow: 0 0 0 2px var(--ui-agg-panel);
  color: #fff;
  pointer-events: none;
  animation: ui-agg-pop 360ms var(--ui-agg-ease) both;
}
.ui-agg__badge > svg {
  width: 11px;
  height: 11px;
}
.ui-agg__badge[data-status="waiting"] {
  background: var(--ui-agg-warn);
}
.ui-agg__badge[data-status="error"] {
  background: var(--ui-agg-danger);
}
.ui-agg__badge[data-status="done"] {
  background: var(--ui-agg-ok);
}
.ui-agg__label {
  position: absolute;
  top: calc(var(--d) / 2 + 5px);
  left: 0;
  display: grid;
  justify-items: center;
  padding: 1px 6px;
  border-radius: 7px;
  background: var(--ui-agg-panel);
  box-shadow: 0 0 6px 2px var(--ui-agg-panel);
  transform: translateX(-50%);
  white-space: nowrap;
  pointer-events: none;
}
.ui-agg__label[data-above] {
  top: auto;
  bottom: calc(var(--d) / 2 + 5px);
}
.ui-agg__node[data-kind="agent"] .ui-agg__label {
  top: calc(var(--d) / 2 + 7px);
}
.ui-agg__node[data-kind="agent"] .ui-agg__label[data-above] {
  top: auto;
  bottom: calc(var(--d) / 2 + 7px);
}
.ui-agg__name,
.ui-agg__line {
  width: max-content;
  max-width: 150px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-agg[data-narrow] :is(.ui-agg__name, .ui-agg__line) {
  max-width: 72px;
}
.ui-agg__name {
  font-size: 12px;
  font-weight: 500;
  line-height: 15px;
  color: var(--ui-agg-text);
}
.ui-agg__node[data-kind="agent"] .ui-agg__name {
  font-size: 12.5px;
  font-weight: 600;
  color: var(--ui-agg-ink);
}
.ui-agg__line {
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-agg-muted);
}
.ui-agg__line[data-status="waiting"] {
  font-weight: 500;
  color: var(--ui-agg-warn-fg);
}
.ui-agg__line[data-status="error"] {
  font-weight: 500;
  color: var(--ui-agg-danger-fg);
}
.ui-agg[data-narrow] .ui-agg__name {
  font-size: 11px;
  line-height: 14px;
}
.ui-agg[data-narrow] .ui-agg__ring {
  --ui-agg-b1: 4px;
  --ui-agg-b2: 9px;
}
.ui-agg[data-narrow] .ui-agg__label {
  padding: 0 4px;
}
.ui-agg[data-narrow] .ui-agg__node[data-kind="agent"] .ui-agg__name {
  font-size: 11.5px;
}
.ui-agg[data-narrow] .ui-agg__line {
  font-size: 10.5px;
  line-height: 13px;
}
.ui-agg[data-narrow] .ui-agg__node[data-kind="agent"] .ui-agg__disc {
  box-shadow:
    0 0 0 3px var(--ui-agg-tray),
    0 0 0 4px var(--ui-agg-line),
    0 3px 10px -4px rgba(0, 0, 0, 0.14);
}
.ui-agg__alerts {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  min-width: 0;
}
.ui-agg__chip {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  margin: -3px 0;
  padding: 0 9px 0 6px;
  border-radius: 999px;
  font-size: 12px;
  font-weight: 500;
  white-space: nowrap;
  animation: ui-agg-rise 320ms var(--ui-agg-ease) both;
  transition: filter 160ms ease;
}
.ui-agg__chip > svg {
  width: 14px;
  height: 14px;
}
.ui-agg__chip[data-kind="waiting"] {
  background: var(--ui-agg-warn-bg);
  color: var(--ui-agg-warn-fg);
}
.ui-agg__chip[data-kind="error"] {
  background: var(--ui-agg-danger-bg);
  color: var(--ui-agg-danger-fg);
}
.ui-agg__chip:hover {
  filter: saturate(1.3) brightness(0.97);
}
.ui-agg__card {
  position: absolute;
  z-index: 5;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
  width: 264px;
  padding: 12px;
  border-radius: 16px;
  background: var(--ui-agg-card);
  box-shadow:
    0 0 0 1px var(--ui-agg-line),
    0 16px 32px -12px rgba(0, 0, 0, 0.2);
  animation: ui-agg-rise 220ms var(--ui-agg-ease) both;
}
.ui-agg[data-narrow] .ui-agg__card {
  right: 8px;
  bottom: 8px;
  left: 8px;
  width: auto;
}
.ui-agg__card-head {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ui-agg__card-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--ui-agg-card);
  box-shadow:
    0 0 0 1px var(--ui-agg-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  font-size: 10px;
  font-weight: 600;
  color: var(--ui-agg-text);
}
.ui-agg__card-icon > svg {
  width: 15px;
  height: 15px;
}
.ui-agg__card-icon[data-kind="user"] {
  background: var(--ui-agg-user-bg);
  color: var(--ui-agg-user-fg);
  box-shadow: none;
}
.ui-agg__card-who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-agg__card-name {
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  line-height: 17px;
  color: var(--ui-agg-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agg__card-detail {
  overflow: hidden;
  font-size: 11.5px;
  line-height: 15px;
  color: var(--ui-agg-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agg__pill {
  flex: none;
  height: 20px;
  padding: 0 7px;
  border-radius: 999px;
  background: var(--ui-agg-chip);
  font-size: 11px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-agg-text);
  white-space: nowrap;
}
.ui-agg__pill[data-status="working"] {
  background: var(--ui-agg-brand-bg);
  color: var(--ui-agg-brand-fg);
}
.ui-agg__pill[data-status="waiting"] {
  background: var(--ui-agg-warn-bg);
  color: var(--ui-agg-warn-fg);
}
.ui-agg__pill[data-status="error"] {
  background: var(--ui-agg-danger-bg);
  color: var(--ui-agg-danger-fg);
}
.ui-agg__pill[data-status="done"] {
  background: var(--ui-agg-ok-bg);
  color: var(--ui-agg-ok-fg);
}
.ui-agg__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  margin: -4px -4px -4px -2px;
  border-radius: 999px;
  color: var(--ui-agg-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-agg__close:hover {
  background: var(--ui-agg-chip);
  color: var(--ui-agg-ink);
}
.ui-agg__doing {
  font-size: 12.5px;
  line-height: 17px;
  color: var(--ui-agg-text);
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-agg__calls {
  display: grid;
  gap: 2px;
  padding: 4px;
  border-radius: 12px;
  background: var(--ui-agg-tray);
  list-style: none;
}
.ui-agg__call {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 26px;
  padding: 0 6px;
  border-radius: 8px;
  font-size: 12px;
  line-height: 16px;
  animation: ui-agg-rise 260ms var(--ui-agg-ease) both;
}
.ui-agg__call:first-child {
  background: var(--ui-agg-card);
  box-shadow: 0 0 0 1px var(--ui-agg-line);
}
.ui-agg__call-dir {
  display: grid;
  flex: none;
  place-items: center;
  color: var(--ui-agg-muted);
}
.ui-agg__call-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  font-size: 7.5px;
  font-weight: 600;
  color: var(--ui-agg-text);
}
.ui-agg__call-icon > svg {
  width: 13px;
  height: 13px;
}
.ui-agg__call-text {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-agg-muted);
}
.ui-agg__call-who {
  font-weight: 500;
  color: var(--ui-agg-ink);
}
.ui-agg__call-end {
  flex: none;
  font-size: 11.5px;
  color: var(--ui-agg-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agg__call[data-status="pending"] .ui-agg__call-end {
  color: var(--ui-agg-brand-fg);
}
.ui-agg__call[data-status="error"] .ui-agg__call-end {
  font-weight: 500;
  color: var(--ui-agg-danger-fg);
}
.ui-agg__spin {
  animation: ui-agg-spin 900ms linear infinite;
}
.ui-agg__card-foot {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agg-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agg__card-cost {
  font-weight: 600;
  color: var(--ui-agg-ink);
}
.ui-agg__legend {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 4px 16px;
  padding: 0 12px 12px;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-agg-muted);
}
.ui-agg__legend > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-agg__legend-call,
.ui-agg__legend-tail {
  fill: var(--ui-agg-pulse);
}
.ui-agg__legend-reply {
  fill: var(--ui-agg-panel);
  stroke: var(--ui-agg-pulse);
  stroke-width: 1.6;
}
.ui-agg__legend-line {
  stroke: var(--ui-agg-link);
  stroke-linecap: round;
}
.ui-agg__legend-wait {
  fill: var(--ui-agg-warn);
}
.ui-agg__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@property --ui-agg-turn {
  syntax: "<angle>";
  inherits: false;
  initial-value: 0deg;
}
.ui-agg .ui-agg__node {
  --ui-agg-r: calc(var(--d) * 0.27);
}
.ui-agg :is(.ui-agg__disc, .ui-agg__ring, .ui-agg__disc::after) {
  border-radius: var(--ui-agg-r);
}
.ui-agg .ui-agg__disc::before {
  border-radius: calc(var(--ui-agg-r) + 6px);
}
.ui-agg .ui-agg__badge {
  top: calc(var(--d) / -2 - 6px);
  left: calc(var(--d) / 2 - 9px);
}
.ui-agg .ui-agg__card-icon {
  border-radius: 8px;
}
.ui-agg .ui-agg__stroke {
  box-sizing: border-box;
  padding: 1px;
  border-radius: var(--ui-agg-r);
  background: conic-gradient(
    from var(--ui-agg-turn),
    transparent 0deg,
    transparent 40deg,
    var(--ui-agg-state) 360deg
  );
  -webkit-mask:
    linear-gradient(#000 0 0) content-box,
    linear-gradient(#000 0 0);
  -webkit-mask-composite: xor;
  mask:
    linear-gradient(#000 0 0) content-box exclude,
    linear-gradient(#000 0 0);
  animation: ui-agg-turn 1200ms linear infinite;
}
@keyframes ui-agg-turn {
  to {
    --ui-agg-turn: 360deg;
  }
}
@keyframes ui-agg-draw {
  from {
    stroke-dashoffset: 1;
  }
}
@keyframes ui-agg-retract {
  from {
    stroke-dashoffset: 0;
  }
  to {
    stroke-dashoffset: 1;
    opacity: 0;
  }
}
@keyframes ui-agg-pop {
  from {
    opacity: 0;
    transform: scale(0.4);
  }
}
@keyframes ui-agg-out {
  to {
    opacity: 0;
    transform: scale(0.5);
  }
}
@keyframes ui-agg-rise {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.98);
  }
}
@keyframes ui-agg-fade-in {
  from {
    opacity: 0;
  }
}
@keyframes ui-agg-breathe {
  0%,
  100% {
    box-shadow: 0 0 0 var(--ui-agg-b1, 6px) var(--ui-agg-breath);
  }
  50% {
    box-shadow: 0 0 0 var(--ui-agg-b2, 13px) var(--ui-agg-breath-out);
  }
}
@keyframes ui-agg-flash {
  50% {
    background: var(--ui-agg-danger-bg);
  }
}
@keyframes ui-agg-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-agg *,
  .ui-agg *::before,
  .ui-agg *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-agg__edge {
    stroke-dasharray: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-agg {
  --ui-agg-tray: #19191c;
  --ui-agg-panel: #1f1f22;
  --ui-agg-card: #2a2a2e;
  --ui-agg-ink: #ededed;
  --ui-agg-text: #a1a1a6;
  --ui-agg-muted: #7c7c82;
  --ui-agg-line: #303035;
  --ui-agg-chip: #2e2e33;
  --ui-agg-link: #4f8fdb;
  --ui-agg-pulse: #6ea8ff;
  --ui-agg-glow: rgba(79, 143, 219, 0.16);
  --ui-agg-breath: rgba(110, 168, 255, 0.16);
  --ui-agg-breath-out: rgba(110, 168, 255, 0.03);
  --ui-agg-user-bg: #ededed;
  --ui-agg-user-fg: #141416;
  --ui-agg-brand-bg: #16243f;
  --ui-agg-brand-fg: #8ab4ff;
  --ui-agg-ok: #2fbf71;
  --ui-agg-ok-bg: #12301f;
  --ui-agg-ok-fg: #3dd68c;
  --ui-agg-warn: #f5a524;
  --ui-agg-warn-bg: #3a2410;
  --ui-agg-warn-fg: #ffa057;
  --ui-agg-danger: #f2555a;
  --ui-agg-danger-bg: #3b1714;
  --ui-agg-danger-fg: #ff977d;
  --ui-agg-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-agg__panel {
  box-shadow: 0 0 0 1px var(--ui-agg-line);
}
`;export{n as default};
