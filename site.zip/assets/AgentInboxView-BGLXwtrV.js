import{j as i,r as p}from"./workbench-model-C4LJxhar.js";const P=[{id:"needs",label:"Needs you"},{id:"running",label:"Running"},{id:"done",label:"Done"}],L={waiting:"Waiting for you",running:"Running",done:"Done",failed:"Failed"},V=new Intl.NumberFormat("en",{notation:"compact",maximumFractionDigits:1}),A=new Intl.NumberFormat("en");function z(a){return a==="waiting"||a==="failed"?"needs":a==="running"?"running":"done"}function ii(a){return a==="running"||a==="waiting"}function ai(a){return a==="waiting"||a==="done"||a==="failed"?a:"running"}function ei(a){return a instanceof Date?a.getTime():typeof a=="number"?a:typeof a=="string"?Date.parse(a):NaN}function T(a){return typeof a=="number"&&Number.isFinite(a)&&a>=0?a:void 0}function ti(a){if(!Number.isFinite(a))return"—";const n=Math.max(0,Math.floor(a/1e3));if(n<60)return`${n}s`;const t=Math.floor(n/60),s=g=>String(g).padStart(2,"0");if(t<60)return`${t}m ${s(n%60)}s`;const u=Math.floor(t/60);return u<24?`${u}h ${s(t%60)}m`:`${Math.floor(u/24)}d ${u%24}h`}function ni(a,n){const t=new Map;return(Array.isArray(a)?a:[]).filter(s=>!!s&&typeof s=="object").map(s=>{const u=String(s.id??""),g=t.get(u)??0;t.set(u,g+1);const x=g?`${u}#${g}`:u,_=n[x]?{...s,...n[x]}:s,f=(Array.isArray(_.steps)?_.steps:[]).filter(l=>!!l&&typeof l=="object"&&String(l.label??"").trim()!=="").map(l=>({label:String(l.label),time:l.time?String(l.time):void 0}));return{..._,key:x,src:s,status:ai(_.status),title:String(_.title??"").trim()||"Untitled task",steps:f}})}function U(){return typeof window<"u"&&window.matchMedia("(prefers-reduced-motion: reduce)").matches}const j={fill:"none",stroke:"currentColor",strokeWidth:1.4,strokeLinecap:"round",strokeLinejoin:"round"},Y=()=>i.jsxs("svg",{width:"14",height:"14",viewBox:"0 0 14 14","aria-hidden":"true",children:[i.jsx("path",{d:"M7 1.2c.4 2.9 1.9 4.4 4.8 4.8-2.9.4-4.4 1.9-4.8 4.8C6.6 7.9 5.1 6.4 2.2 6 5.1 5.6 6.6 4.1 7 1.2Z",fill:"currentColor"}),i.jsx("circle",{cx:"11.6",cy:"11.4",r:"1.1",fill:"currentColor",opacity:"0.55"})]}),ri=({status:a,prefix:n})=>i.jsxs("span",{className:`${n}__state-icon`,"data-status":a,"aria-hidden":"true",children:[a==="running"&&i.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 12 12",children:[i.jsx("circle",{cx:"6",cy:"6",r:"4.6",fill:"none",stroke:"currentColor",strokeOpacity:"0.25",strokeWidth:"1.6"}),i.jsx("path",{d:"M6 1.4a4.6 4.6 0 0 1 4.6 4.6",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round"})]}),a==="waiting"&&i.jsx("svg",{width:"12",height:"12",viewBox:"0 0 12 12",children:i.jsx("path",{d:"M6 1.6 11 10.2H1L6 1.6Z",fill:"currentColor"})}),a==="done"&&i.jsx("svg",{width:"12",height:"12",viewBox:"0 0 12 12",children:i.jsx("circle",{cx:"6",cy:"6",r:"3.4",fill:"currentColor"})}),a==="failed"&&i.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 12 12",children:[i.jsx("circle",{cx:"6",cy:"6",r:"4.8",fill:"currentColor"}),i.jsx("path",{d:"M6 3.6v2.8M6 8.3v.1",stroke:"#fff",strokeWidth:"1.5",strokeLinecap:"round"})]})]}),oi=()=>i.jsx("svg",{width:"12",height:"12",viewBox:"0 0 12 12","aria-hidden":"true",children:i.jsx("path",{d:"M7.6 1.6a2.6 2.6 0 0 0-2.4 3.5L1.7 8.6a1.1 1.1 0 0 0 1.6 1.6l3.5-3.5a2.6 2.6 0 0 0 3.5-2.4l-1.5 1.1-1.5-.4-.4-1.5 1.1-1.5c-.1 0-.3-.4-.4-.4Z",...j,strokeWidth:1.2})}),si=()=>i.jsxs("svg",{width:"12",height:"12",viewBox:"0 0 12 12","aria-hidden":"true",children:[i.jsx("circle",{cx:"5.2",cy:"5.2",r:"3.3",...j,strokeWidth:1.2}),i.jsx("path",{d:"m7.7 7.7 2.6 2.6",...j,strokeWidth:1.2})]}),ci=()=>i.jsxs("svg",{width:"13",height:"13",viewBox:"0 0 14 14","aria-hidden":"true",children:[i.jsx("rect",{x:"1.8",y:"2.2",width:"3.2",height:"9.6",rx:"1",...j,strokeWidth:1.2}),i.jsx("rect",{x:"8.9",y:"2.2",width:"3.2",height:"6.4",rx:"1",...j,strokeWidth:1.2})]}),di=()=>i.jsx("svg",{width:"13",height:"13",viewBox:"0 0 14 14","aria-hidden":"true",children:i.jsx("path",{d:"M2.2 3.6h9.6M2.2 7h9.6M2.2 10.4h9.6",...j,strokeWidth:1.2})}),ui=()=>i.jsx("svg",{width:"12",height:"12",viewBox:"0 0 12 12","aria-hidden":"true",children:i.jsx("path",{d:"M6 2.2v7.6M2.2 6h7.6",...j,strokeWidth:1.5})}),C=new Set;let I=0;function li(a){const[n,t]=p.useState(()=>Date.now());return p.useEffect(()=>{if(!a)return;const s=()=>t(Date.now());return s(),C.add(s),I||(I=window.setInterval(()=>C.forEach(u=>u()),1e3)),()=>{C.delete(s),C.size||(window.clearInterval(I),I=0)}},[a]),n}function pi({since:a,fixed:n}){const t=li(a!==void 0);return i.jsx(i.Fragment,{children:ti(a===void 0?n:t-a)})}function xi({task:a,inbox:n,prefix:t,onApprove:s,onReject:u,onRetry:g,onOpen:x,highlight:_}){const f=n.expandedKey===a.key,l=a.steps.slice(-4),h=T(a.elapsed),b=a.status!=="failed"&&(a.status!=="done"||h!==void 0),k=T(a.sources),r=T(a.tools),o=typeof a.description=="string"?a.description.trim():"",w=String(a.agent??"").trim(),d=`${n.id}-${encodeURIComponent(a.key)}`,m=a.status==="done"?b?"Done in":L.done:a.status==="failed"?L.failed:`${L[a.status]} ·`;return i.jsxs("li",{"data-id":a.id,className:`${t}__card`,"data-faded":_&&a.id!==_?"":void 0,"data-status":a.status,"data-open":f?"":void 0,ref:v=>{v?n.cardRefs.current.set(a.key,v):n.cardRefs.current.delete(a.key)},children:[i.jsxs("button",{type:"button",className:`${t}__card-main`,"aria-expanded":f,"aria-controls":d,onClick:()=>n.toggleTask(a.key),children:[i.jsxs("span",{className:`${t}__title-row`,children:[i.jsx("span",{className:`${t}__spark`,children:i.jsx(Y,{})}),i.jsx("span",{className:`${t}__title`,dir:"auto",title:a.title,children:a.title})]}),o&&i.jsx("span",{className:`${t}__desc`,dir:"auto",children:o}),i.jsxs("span",{className:`${t}__foot`,children:[i.jsxs("span",{className:`${t}__state`,"data-status":a.status,"data-bare":b?void 0:"",children:[i.jsx(ri,{status:a.status,prefix:t}),i.jsx("span",{className:`${t}__state-word`,children:m}),b&&i.jsx("span",{className:`${t}__time`,children:i.jsx(pi,{since:n.startedAt(a),fixed:h??0})})]}),i.jsxs("span",{className:`${t}__meta`,children:[k!==void 0&&i.jsxs("span",{title:`Sources read: ${A.format(k)}`,children:[i.jsx(si,{}),V.format(k)]}),r!==void 0&&i.jsxs("span",{title:`Tool calls: ${A.format(r)}`,children:[i.jsx(oi,{}),V.format(r)]})]})]})]}),i.jsx("div",{id:d,className:`${t}__fold`,"data-open":f?"":void 0,inert:!f,children:i.jsx("div",{className:`${t}__clip`,children:i.jsxs("div",{className:`${t}__more`,children:[w&&i.jsx("div",{className:`${t}__agent`,dir:"auto",children:w}),l.length>0&&i.jsx("ol",{className:`${t}__steps`,children:l.map((v,S)=>i.jsxs("li",{"data-last":S===l.length-1?"":void 0,children:[i.jsx("span",{dir:"auto",children:v.label}),v.time&&i.jsx("time",{dir:"auto",children:v.time})]},S))}),i.jsxs("div",{className:`${t}__actions`,children:[a.status==="waiting"&&i.jsxs(i.Fragment,{children:[i.jsx("button",{type:"button",className:`${t}__btn`,onClick:()=>n.transitionTask(a,"failed","You rejected the request",u),children:"Reject"}),i.jsx("button",{type:"button",className:`${t}__btn ${t}__btn--primary`,onClick:()=>n.transitionTask(a,"running","You approved – continuing",s),children:"Approve"})]}),a.status==="failed"&&i.jsx("button",{type:"button",className:`${t}__btn ${t}__btn--primary`,onClick:()=>n.transitionTask(a,"running","Retrying",g),children:"Retry"}),(a.status==="running"||a.status==="done")&&x&&i.jsx("button",{type:"button",className:`${t}__btn`,onClick:()=>x(a),children:"Open"})]})]})})})]})}function _i({tasks:a,view:n,defaultView:t="board",onViewChange:s},u){var W,O;const g=p.useId(),x=p.useRef(null),[_,f]=p.useState(t),l=n??_,[h,b]=p.useState(null),[k,r]=p.useState({}),o=ni(a,k),w=p.useRef({});for(const e of o)(W=w.current)[O=e.key]??(W[O]=Date.now());function d(e){if(!ii(e.status))return;const c=ei(e.startedAt);return Number.isFinite(c)?c:w.current[e.key]-(T(e.elapsed)??0)}const[m,v]=p.useState(()=>Object.fromEntries(o.map(e=>[e.key,z(e.status)]))),S=o.map(e=>`${e.key}:${z(e.status)}`).join("|");p.useEffect(()=>{if(!o.some(c=>m[c.key]!==z(c.status)))return;const e=window.setTimeout(()=>v(Object.fromEntries(o.map(c=>[c.key,z(c.status)]))),U()?0:900);return()=>window.clearTimeout(e)},[S]);function D(e){return m[e.key]??z(e.status)}const R=p.useRef(new Map),F=p.useRef(new Map),$=JSON.stringify(m)+l,B=p.useRef($);x.current&&B.current!==$&&(F.current=new Map([...R.current].map(([e,c])=>[e,c.getBoundingClientRect()]))),p.useLayoutEffect(()=>{if(B.current!==$&&(B.current=$,!U()))for(const[e,c]of R.current){const y=F.current.get(e);if(!y){c.animate([{opacity:0,transform:"translateY(6px)"},{opacity:1,transform:"none"}],{duration:380,easing:"cubic-bezier(0.32, 0.72, 0.24, 1)"});continue}const N=c.getBoundingClientRect(),M=y.left-N.left,K=y.top-N.top;Math.abs(M)<1&&Math.abs(K)<1||c.animate([{transform:`translate(${M}px, ${K}px)`,zIndex:2},{transform:"none",zIndex:2}],{duration:560,easing:"cubic-bezier(0.32, 0.72, 0.24, 1)"})}},[$]);function Z(e,c,y,N){if(N){N(e.src);return}r(M=>({...M,[e.key]:{status:c,startedAt:Date.now(),steps:[...e.steps,{label:y,time:"now"}]}}))}function q(e){b(c=>c===e?null:e)}function H(e){var c,y;e.key!=="Escape"||!h||(e.stopPropagation(),(y=(c=R.current.get(h))==null?void 0:c.querySelector(`.${u}__card-main`))==null||y.focus({preventScroll:!0}),b(null))}function J(e){f(e),s==null||s(e)}const G=Object.fromEntries(P.map(e=>[e.id,o.filter(c=>D(c)===e.id).length])),E=o.filter(e=>e.status==="waiting"||e.status==="failed").length,Q=o.filter(e=>e.status==="running").length,X=`${E} ${E===1?"needs":"need"} you, ${Q} running`;return{id:g,rootRef:x,currentView:l,expandedKey:h,normalizedTasks:o,startedAt:d,laneForTask:D,cardRefs:R,transitionTask:Z,toggleTask:q,handleKeyDown:H,changeView:J,counts:G,announcement:X}}const gi=`
.ui-ai {
  --ui-ai-tray: #f0f0f0;
  --ui-ai-card: #ffffff;
  --ui-ai-line: #ececec;
  --ui-ai-chip: #f5f5f5;
  --ui-ai-track: #e6e6e6;
  --ui-ai-ink: #171717;
  --ui-ai-text: #6b6b6b;
  --ui-ai-muted: #59616c;
  --ui-ai-faint: #6b6b6b;
  --ui-ai-blue: #2a5ee5;
  --ui-ai-amber: #955d00;
  --ui-ai-green: #0f783c;
  --ui-ai-red: #bf372f;
  --ui-ai-brand-bg: #eaf1ff;
  --ui-ai-brand-fg: #2456d6;
  --ui-ai-warn-bg: #fff3e0;
  --ui-ai-warn-fg: #a45200;
  --ui-ai-ok-bg: #e6f6ec;
  --ui-ai-ok-fg: #187941;
  --ui-ai-danger-bg: #fdecea;
  --ui-ai-danger-fg: #c2331f;
  --ui-ai-focus: rgba(0, 96, 226, 0.7);
  --ui-ai-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ai-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-ai-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ai *,
.ui-ai *::before,
.ui-ai *::after {
  box-sizing: border-box;
}
:where(.ui-ai) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ai button:focus-visible {
  outline: 2px solid var(--ui-ai-focus);
  outline-offset: 2px;
}
.ui-ai ul,
.ui-ai ol {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ai svg {
  display: block;
  flex: none;
}
.ui-ai__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-ai__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 8px 8px 10px 14px;
}
.ui-ai__heading {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 14px;
  font-weight: 600;
  color: var(--ui-ai-ink);
  white-space: nowrap;
}
.ui-ai__crumb {
  flex: none;
  color: var(--ui-ai-muted);
  font-weight: 500;
}
.ui-ai__slash {
  flex: none;
  color: var(--ui-ai-faint);
  font-weight: 400;
}
.ui-ai__heading-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ai__tools {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
}
.ui-ai__action-label {
  max-width: 200px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ai__action {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  padding: 0 12px 0 10px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ai-ink);
  transition: background-color 160ms ease;
}
.ui-ai__action:hover {
  background: var(--ui-ai-track);
}
.ui-ai__views {
  display: flex;
  flex: none;
  padding: 3px;
  border-radius: 12px;
  background: var(--ui-ai-track);
}
.ui-ai__view {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 12px;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ai-muted);
  transition:
    background-color 200ms ease,
    color 200ms ease,
    box-shadow 200ms ease;
}
.ui-ai__view:hover {
  color: var(--ui-ai-ink);
}
.ui-ai__view[aria-checked="true"] {
  background: var(--ui-ai-card);
  color: var(--ui-ai-ink);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
}
.ui-ai__lanes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 4px;
  align-items: start;
}
.ui-ai__lane {
  min-width: 0;
}
.ui-ai__lane-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 32px;
  padding: 0 10px;
}
.ui-ai__lane-spark {
  display: grid;
  color: var(--ui-ai-blue);
}
.ui-ai__lane[aria-label="Needs you"] .ui-ai__lane-spark {
  color: var(--ui-ai-amber);
}
.ui-ai__lane[aria-label="Done"] .ui-ai__lane-spark {
  color: var(--ui-ai-green);
}
.ui-ai__lane-name {
  overflow: hidden;
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-ai-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ai__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 999px;
  background: var(--ui-ai-card);
  box-shadow: 0 0 0 1px var(--ui-ai-line);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-ai-text);
  font-variant-numeric: tabular-nums;
}
.ui-ai__cards {
  display: grid;
  gap: 4px;
}
.ui-ai__empty {
  padding: 18px 0 20px;
  border-radius: 16px;
  box-shadow: inset 0 0 0 1px var(--ui-ai-track);
  font-size: 13px;
  text-align: center;
  color: var(--ui-ai-muted);
}
.ui-ai__card[data-faded] {
  opacity: 0.4;
}
.ui-ai__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-ai-card);
  box-shadow:
    0 0 0 1px var(--ui-ai-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-ai__card:hover,
.ui-ai__card[data-open] {
  box-shadow:
    0 0 0 1px #e0e0e0,
    0 6px 16px -8px rgba(0, 0, 0, 0.14);
}
.ui-ai__card-main {
  display: grid;
  gap: 6px;
  width: 100%;
  padding: 14px 14px 12px;
  border-radius: 16px;
  container: ai-card / inline-size;
}
.ui-ai__title-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}
.ui-ai__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 20px;
  color: var(--ui-ai-blue);
  transition: color 300ms ease;
}
.ui-ai__card[data-status="waiting"] .ui-ai__spark {
  color: var(--ui-ai-amber);
}
.ui-ai__card[data-status="failed"] .ui-ai__spark {
  color: var(--ui-ai-red);
}
.ui-ai__card[data-status="done"] .ui-ai__spark {
  color: var(--ui-ai-green);
}
.ui-ai__title {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-ai-ink);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow-wrap: anywhere;
}
.ui-ai__desc {
  display: -webkit-box;
  padding-left: 26px;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-ai-text);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-ai__card[data-open] .ui-ai__title {
  white-space: normal;
}
.ui-ai__card[data-open] .ui-ai__desc {
  -webkit-line-clamp: unset;
}
.ui-ai__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  margin-top: 6px;
  padding-left: 26px;
}
.ui-ai__state {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 24px;
  padding: 0 10px 0 8px;
  border-radius: 999px;
  background: var(--ui-ai-brand-bg);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ai-brand-fg);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-ai__state[data-status="waiting"] {
  background: var(--ui-ai-warn-bg);
  color: var(--ui-ai-warn-fg);
}
.ui-ai__state[data-status="done"] {
  background: var(--ui-ai-ok-bg);
  color: var(--ui-ai-ok-fg);
}
.ui-ai__state[data-status="failed"] {
  background: var(--ui-ai-danger-bg);
  color: var(--ui-ai-danger-fg);
}
.ui-ai__state-word {
  min-width: 2.6em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: pre;
  margin-right: calc(0.28em - 6px);
}
.ui-ai__time {
  flex: none;
}
.ui-ai__state-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  color: currentColor;
  animation: ui-ai-pop 360ms var(--ui-ai-ease) both;
}
.ui-ai__state-icon[data-status="running"] svg {
  animation: ui-ai-spin 900ms linear infinite;
}
.ui-ai__meta {
  display: inline-flex;
  flex: none;
  align-items: center;
  font-size: 12.5px;
  color: var(--ui-ai-muted);
  font-variant-numeric: tabular-nums;
}
.ui-ai__meta > span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 9px;
}
.ui-ai__meta > span + span {
  border-left: 1px solid var(--ui-ai-line);
}
.ui-ai__meta > span:last-child {
  padding-right: 0;
}
.ui-ai__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 460ms var(--ui-ai-ease),
    opacity 240ms ease;
}
.ui-ai__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 460ms var(--ui-ai-ease),
    opacity 320ms ease 100ms;
}
.ui-ai__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-ai__more {
  margin: 0 14px;
  padding: 12px 0 14px;
  border-top: 1px solid var(--ui-ai-line);
}
.ui-ai__agent {
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ai-muted);
}
.ui-ai__steps {
  position: relative;
  display: grid;
  gap: 6px;
  margin-top: 8px !important;
  padding-left: 14px !important;
}
.ui-ai__steps li {
  position: relative;
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ai-text);
}
.ui-ai__steps li::before {
  content: "";
  position: absolute;
  top: 6px;
  left: -14px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-ai-faint);
}
.ui-ai__steps li:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 15px;
  bottom: -9px;
  left: -11.5px;
  width: 1px;
  background: var(--ui-ai-line);
}
.ui-ai__steps li[data-last]::before {
  background: var(--ui-ai-ink);
}
.ui-ai__steps li > span {
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-ai__steps time {
  flex: none;
  max-width: 45%;
  color: var(--ui-ai-muted);
  text-align: end;
}
.ui-ai__actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 12px;
}
.ui-ai__actions:empty {
  display: none;
}
.ui-ai__btn {
  display: inline-flex;
  align-items: center;
  height: 32px;
  padding: 0 14px;
  border-radius: 10px;
  background: var(--ui-ai-card);
  box-shadow:
    0 0 0 1px var(--ui-ai-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-ai-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-ai__btn:hover {
  background: var(--ui-ai-chip);
}
.ui-ai__btn--primary {
  background: var(--ui-ai-ink);
  box-shadow: none;
  color: var(--ui-ai-card);
}
.ui-ai__btn--primary:hover {
  background: var(--ui-ai-ink);
  opacity: 0.88;
}
.ui-ai[data-view="list"] .ui-ai__lanes {
  grid-template-columns: minmax(0, 1fr);
  gap: 8px;
}
.ui-ai__lanes {
  animation: ui-ai-in 320ms ease both;
}
@keyframes ui-ai-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-ai-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-ai-in {
  from {
    opacity: 0.4;
  }
}
@container (max-width: 620px) {
  .ui-ai__views {
    display: none;
  }
  .ui-ai__action {
    justify-content: center;
    width: 30px;
    padding: 0;
    background: var(--ui-ai-track);
  }
  .ui-ai__action-label {
    display: none;
  }
  .ui-ai .ui-ai__lanes {
    grid-template-columns: minmax(0, 1fr);
    gap: 8px;
  }
}
@container ai-card (max-width: 300px) {
  .ui-ai__desc,
  .ui-ai__foot {
    padding-left: 0;
  }
  .ui-ai__state:not([data-status="failed"]):not([data-bare])
    .ui-ai__state-word {
    display: none;
  }
}
@container (max-width: 360px) {
  .ui-ai__desc,
  .ui-ai__foot {
    padding-left: 0;
  }
  .ui-ai__title {
    white-space: normal;
  }
  .ui-ai__card:not([data-open]) .ui-ai__title {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
}
@media (pointer: coarse) {
  .ui-ai__view {
    height: 34px;
  }
  .ui-ai__btn {
    height: 40px;
    padding: 0 18px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ai *,
  .ui-ai *::before,
  .ui-ai *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ai {
  --ui-ai-tray: #111113;
  --ui-ai-card: #1c1c1f;
  --ui-ai-line: #2a2a2e;
  --ui-ai-chip: #26262a;
  --ui-ai-track: #1f1f22;
  --ui-ai-ink: #ededed;
  --ui-ai-text: #a1a1a6;
  --ui-ai-muted: #7c7c82;
  --ui-ai-faint: #4a4a50;
  --ui-ai-blue: #5b9aff;
  --ui-ai-amber: #f5b638;
  --ui-ai-green: #3ecf8e;
  --ui-ai-red: #ff6b66;
  --ui-ai-brand-bg: #16243f;
  --ui-ai-brand-fg: #8ab4ff;
  --ui-ai-warn-bg: #3a2410;
  --ui-ai-warn-fg: #ffa057;
  --ui-ai-ok-bg: #12301f;
  --ui-ai-ok-fg: #3dd68c;
  --ui-ai-danger-bg: #3b1714;
  --ui-ai-danger-fg: #ff977d;
  --ui-ai-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ai__card:hover,
:where(.dark, [data-theme="dark"]) .ui-ai__card[data-open] {
  box-shadow:
    0 0 0 1px #34343a,
    0 6px 18px -8px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-ai__view[aria-checked="true"] {
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.4),
    0 0 0 1px rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"])
  .ui-ai__state-icon[data-status="failed"]
  path {
  stroke: var(--ui-ai-danger-bg);
}
`,fi=`
.ui-aic {
  --ui-aic-lane: #f4f4f5;
  --ui-aic-card: #ffffff;
  --ui-aic-line: #e9e9ec;
  --ui-aic-ink: #1c1c1f;
  --ui-aic-text: #55555c;
  --ui-aic-muted: #626873;
  --ui-aic-faint: #6b6b6b;
  --ui-aic-blue: #2a5ee5;
  --ui-aic-amber: #8f6100;
  --ui-aic-green: #167942;
  --ui-aic-red: #bf383d;
  --ui-aic-focus: rgba(0, 96, 226, 0.7);
  --ui-aic-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-aic-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-aic *,
.ui-aic *::before,
.ui-aic *::after {
  box-sizing: border-box;
}
:where(.ui-aic) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-aic button:focus-visible {
  outline: 2px solid var(--ui-aic-focus);
  outline-offset: 2px;
}
.ui-aic ul,
.ui-aic ol {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-aic svg {
  display: block;
  flex: none;
}
.ui-aic__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-aic__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
  padding: 0 2px;
}
.ui-aic__heading {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-aic-ink);
  white-space: nowrap;
}
.ui-aic__crumb {
  flex: none;
  color: var(--ui-aic-muted);
  font-weight: 400;
}
.ui-aic__slash {
  flex: none;
  color: var(--ui-aic-faint);
}
.ui-aic__heading-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-aic__views {
  display: flex;
  flex: none;
  gap: 2px;
  padding: 3px;
  border-radius: 10px;
  background: var(--ui-aic-lane);
}
.ui-aic__view {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px;
  border-radius: 7px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-aic-muted);
  transition:
    background-color 180ms ease,
    color 180ms ease,
    box-shadow 180ms ease;
}
.ui-aic__view:hover {
  color: var(--ui-aic-ink);
}
.ui-aic__view[aria-checked="true"] {
  background: var(--ui-aic-card);
  color: var(--ui-aic-ink);
  box-shadow:
    0 1px 2px rgba(16, 16, 24, 0.08),
    0 0 0 1px rgba(16, 16, 24, 0.04);
}
.ui-aic__lanes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  align-items: start;
}
.ui-aic__lane {
  min-width: 0;
  padding: 4px 4px 4px;
  border-radius: 14px;
  background: var(--ui-aic-lane);
}
.ui-aic__lane-head {
  display: grid;
  grid-template-columns: 20px 1fr minmax(20px, auto);
  align-items: center;
  height: 34px;
  padding: 0 8px 0 10px;
}
.ui-aic__lane-spark {
  color: var(--ui-aic-blue);
  opacity: 0.7;
}
.ui-aic__lane-name {
  overflow: hidden;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.08em;
  text-align: center;
  text-transform: uppercase;
  color: var(--ui-aic-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-aic__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(16, 16, 24, 0.06);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-aic-text);
  font-variant-numeric: tabular-nums;
}
.ui-aic__cards {
  display: grid;
  gap: 6px;
}
.ui-aic__empty {
  padding: 18px 0 20px;
  font-size: 12.5px;
  text-align: center;
  color: var(--ui-aic-faint);
}
.ui-aic__card[data-faded] {
  opacity: 0.4;
}
.ui-aic__card {
  position: relative;
  border-radius: 10px;
  background: var(--ui-aic-card);
  box-shadow:
    0 0 0 1px var(--ui-aic-line),
    0 1px 2px rgba(16, 16, 24, 0.04);
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-aic__card:hover,
.ui-aic__card[data-open] {
  box-shadow:
    0 0 0 1px #dcdce1,
    0 4px 14px -6px rgba(16, 16, 24, 0.12);
}
.ui-aic__card-main {
  display: grid;
  gap: 6px;
  width: 100%;
  padding: 12px 14px 12px 12px;
  border-radius: 10px;
  container: aic-card / inline-size;
}
.ui-aic__title-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}
.ui-aic__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 20px;
  color: var(--ui-aic-blue);
  transition: color 300ms ease;
}
.ui-aic__card[data-status="waiting"] .ui-aic__spark {
  color: var(--ui-aic-amber);
}
.ui-aic__card[data-status="failed"] .ui-aic__spark {
  color: var(--ui-aic-red);
}
.ui-aic__card[data-status="done"] .ui-aic__spark {
  color: var(--ui-aic-green);
}
.ui-aic__title {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-aic-ink);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow-wrap: anywhere;
}
.ui-aic__desc {
  display: -webkit-box;
  padding-left: 26px;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-aic-text);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-aic__card[data-open] .ui-aic__title {
  white-space: normal;
}
.ui-aic__card[data-open] .ui-aic__desc {
  -webkit-line-clamp: unset;
}
.ui-aic__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  margin-top: 4px;
  padding-left: 26px;
}
.ui-aic__state {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 12.5px;
  color: var(--ui-aic-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-aic__state-word {
  min-width: 2.6em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: pre;
  margin-right: calc(0.28em - 8px);
}
.ui-aic__time {
  flex: none;
}
.ui-aic__state-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  color: var(--ui-aic-blue);
  animation: ui-aic-pop 360ms var(--ui-aic-ease) both;
}
.ui-aic__state-icon[data-status="running"] svg {
  animation: ui-aic-spin 900ms linear infinite;
}
.ui-aic__state-icon[data-status="waiting"] {
  color: var(--ui-aic-amber);
}
.ui-aic__state-icon[data-status="done"] {
  color: var(--ui-aic-green);
}
.ui-aic__state-icon[data-status="failed"] {
  color: var(--ui-aic-red);
}
.ui-aic__meta {
  display: inline-flex;
  flex: none;
  align-items: center;
  font-size: 12px;
  color: var(--ui-aic-muted);
  font-variant-numeric: tabular-nums;
}
.ui-aic__meta > span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 9px;
}
.ui-aic__meta > span + span {
  border-left: 1px solid var(--ui-aic-line);
}
.ui-aic__meta > span:last-child {
  padding-right: 0;
}
.ui-aic__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 460ms var(--ui-aic-ease),
    opacity 240ms ease;
}
.ui-aic__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 460ms var(--ui-aic-ease),
    opacity 320ms ease 100ms;
}
.ui-aic__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-aic__more {
  margin: 0 14px 0 12px;
  padding: 10px 0 12px;
  border-top: 1px solid var(--ui-aic-line);
}
.ui-aic__agent {
  font-size: 12px;
  color: var(--ui-aic-muted);
}
.ui-aic__steps {
  position: relative;
  display: grid;
  gap: 5px;
  margin-top: 6px !important;
  padding-left: 12px !important;
}
.ui-aic__steps li {
  position: relative;
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-aic-text);
}
.ui-aic__steps li::before {
  content: "";
  position: absolute;
  top: 7px;
  left: -12px;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: var(--ui-aic-faint);
}
.ui-aic__steps li:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 15px;
  bottom: -8px;
  left: -10.5px;
  width: 1px;
  background: var(--ui-aic-line);
}
.ui-aic__steps li[data-last]::before {
  background: var(--ui-aic-ink);
}
.ui-aic__steps li > span {
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-aic__steps time {
  flex: none;
  max-width: 45%;
  color: var(--ui-aic-muted);
  text-align: end;
}
.ui-aic__actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 10px;
}
.ui-aic__actions:empty {
  display: none;
}
.ui-aic__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 12px;
  border-radius: 8px;
  box-shadow: inset 0 0 0 1px var(--ui-aic-line);
  background: var(--ui-aic-card);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-aic-ink);
  transition: background-color 160ms ease;
}
.ui-aic__btn:hover {
  background: var(--ui-aic-lane);
}
.ui-aic__btn--primary {
  background: var(--ui-aic-ink);
  box-shadow: none;
  color: var(--ui-aic-card);
}
.ui-aic__btn--primary:hover {
  background: #33333a;
}
.ui-aic[data-view="list"] .ui-aic__lanes {
  grid-template-columns: minmax(0, 1fr);
}
.ui-aic[data-view="list"] .ui-aic__lane-head {
  grid-template-columns: 20px auto 1fr;
  gap: 4px;
}
.ui-aic[data-view="list"] .ui-aic__lane-name {
  text-align: left;
}
.ui-aic[data-view="list"] .ui-aic__count {
  justify-self: start;
}
.ui-aic__lanes {
  animation: ui-aic-in 320ms ease both;
}
@keyframes ui-aic-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-aic-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-aic-in {
  from {
    opacity: 0.4;
  }
}
@container (max-width: 620px) {
  .ui-aic__views {
    display: none;
  }
  .ui-aic .ui-aic__lanes {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-aic .ui-aic__lane-head {
    grid-template-columns: 20px auto 1fr;
    gap: 4px;
  }
  .ui-aic .ui-aic__lane-name {
    text-align: left;
  }
  .ui-aic .ui-aic__count {
    justify-self: start;
  }
}
@container aic-card (max-width: 300px) {
  .ui-aic__desc,
  .ui-aic__foot {
    padding-left: 0;
  }
  .ui-aic__state:is([data-status="running"], [data-status="done"]):not(
      [data-bare]
    )
    .ui-aic__state-word {
    display: none;
  }
  .ui-aic__foot {
    flex-wrap: wrap;
    row-gap: 2px;
  }
  .ui-aic__state[data-status="waiting"] {
    flex: 1 1 110px;
  }
}
@container (max-width: 360px) {
  .ui-aic__desc,
  .ui-aic__foot {
    padding-left: 0;
  }
  .ui-aic__title {
    white-space: normal;
  }
  .ui-aic__card:not([data-open]) .ui-aic__title {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
}
@media (pointer: coarse) {
  .ui-aic__view {
    height: 32px;
  }
  .ui-aic__btn {
    height: 36px;
    padding: 0 16px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-aic *,
  .ui-aic *::before,
  .ui-aic *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-aic {
  --ui-aic-lane: #161618;
  --ui-aic-card: #1e1e21;
  --ui-aic-line: #2c2c31;
  --ui-aic-ink: #ededed;
  --ui-aic-text: #b6b6bd;
  --ui-aic-muted: #85858d;
  --ui-aic-faint: #5c5c63;
  --ui-aic-blue: #5b8cff;
  --ui-aic-amber: #f5b638;
  --ui-aic-green: #3ecf8e;
  --ui-aic-red: #ff6b66;
  --ui-aic-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-aic__card:hover,
:where(.dark, [data-theme="dark"]) .ui-aic__card[data-open] {
  box-shadow:
    0 0 0 1px #3a3a40,
    0 6px 18px -8px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-aic__count {
  background: rgba(255, 255, 255, 0.07);
}
:where(.dark, [data-theme="dark"]) .ui-aic__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"])
  .ui-aic__state-icon[data-status="failed"]
  path {
  stroke: #1e1e21;
}
`;function hi({clean:a=!1,...n}){const{title:t="Agent inbox",action:s,view:u,onViewChange:g,lanes:x,className:_,highlight:f,onApprove:l,onReject:h,onRetry:b,onOpen:k}=n,r=a?"ui-aic":"ui-ai",o=_i(n,r),w=(u===void 0||g)&&i.jsx("div",{className:`${r}__views`,role:"radiogroup","aria-label":"Layout",children:["board","list"].map(d=>i.jsxs("button",{type:"button",role:"radio","aria-checked":o.currentView===d,className:`${r}__view`,onClick:()=>o.changeView(d),children:[d==="board"?i.jsx(ci,{}):i.jsx(di,{}),d==="board"?"Board":"List"]},d))});return i.jsxs("div",{ref:o.rootRef,className:[r,_].filter(Boolean).join(" "),"data-view":o.currentView,onKeyDown:o.handleKeyDown,children:[i.jsx("style",{href:a?"ui-agent-inbox-clean":"ui-agent-inbox",precedence:"default",children:a?fi:gi}),i.jsxs("div",{className:`${r}__bar`,children:[i.jsxs("span",{className:`${r}__heading`,children:[i.jsx("span",{className:`${r}__crumb`,children:"Agents"}),i.jsx("span",{className:`${r}__slash`,"aria-hidden":"true",children:"/"}),i.jsx("span",{className:`${r}__heading-title`,title:t,children:t})]}),a?w:i.jsxs("div",{className:`${r}__tools`,children:[s&&i.jsxs("button",{type:"button",className:`${r}__action`,"aria-label":s.label,title:s.label,onClick:s.onClick,children:[i.jsx(ui,{}),i.jsx("span",{className:`${r}__action-label`,children:s.label})]}),w]})]}),i.jsx("div",{className:`${r}__lanes`,children:P.filter(d=>!x||x.includes(d.id)).map(d=>i.jsxs("section",{className:`${r}__lane`,"aria-label":d.label,children:[i.jsxs("header",{className:`${r}__lane-head`,children:[i.jsx("span",{className:`${r}__lane-spark`,"aria-hidden":"true",children:i.jsx(Y,{})}),i.jsx("span",{className:`${r}__lane-name`,children:d.label}),i.jsx("span",{className:`${r}__count`,title:o.counts[d.id]>999?A.format(o.counts[d.id]):void 0,children:o.counts[d.id]>999?"999+":String(o.counts[d.id])})]}),i.jsxs("ul",{className:`${r}__cards`,children:[o.normalizedTasks.filter(m=>o.laneForTask(m)===d.id).map(m=>i.jsx(xi,{task:m,inbox:o,prefix:r,highlight:f,onApprove:l,onReject:h,onRetry:b,onOpen:k},m.key)),o.counts[d.id]===0&&i.jsx("li",{className:`${r}__empty`,children:"Nothing here"})]})]},d.id))}),i.jsx("span",{className:`${r}__sr`,"aria-live":"polite",children:o.announcement})]})}export{hi as A};
