const n=`.ui-al {
  --ui-al-tray: #f0f0f0;
  --ui-al-card: #ffffff;
  --ui-al-strong: #171717;
  --ui-al-ink: #171717;
  --ui-al-text: #6b6b6b;
  --ui-al-muted: #626873;
  --ui-al-faint: #6b6b6b;
  --ui-al-line: #ececec;
  --ui-al-rail: #c4c4c8;
  --ui-al-wash: #f6f6f6;
  --ui-al-fill: #ececec;
  --ui-al-done: #f2f2f3;
  --ui-al-solid: #171717;
  --ui-al-on-solid: #ffffff;
  --ui-al-run-bg: rgba(47, 107, 255, 0.1);
  --ui-al-run-fg: #2a5ee5;
  --ui-al-run-edge: rgba(47, 107, 255, 0.55);
  --ui-al-warn-bg: #fff3e0;
  --ui-al-warn-fg: #a45200;
  --ui-al-danger-bg: #fdecea;
  --ui-al-danger-fg: #c2331f;
  --ui-al-focus: rgba(0, 96, 226, 0.7);
  --ui-al-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-al-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-al-row: 48px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 760px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-al-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-al-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-al *,
.ui-al *::before,
.ui-al *::after {
  box-sizing: border-box;
}
:where(.ui-al) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-al button:focus-visible {
  outline: 2px solid var(--ui-al-focus);
  outline-offset: 2px;
}
.ui-al ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-al svg {
  display: block;
  flex: none;
}
.ui-al__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-al__card {
  border-radius: 16px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
}
.ui-al__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 10px 10px 12px 14px;
}
.ui-al__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: #0060e2;
}
.ui-al__title {
  font-weight: 600;
  color: var(--ui-al-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__summary {
  display: flex;
  flex: 1;
  gap: 12px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-muted);
  white-space: nowrap;
}
.ui-al__summary span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-al__summary span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-al-run-fg);
}
.ui-al__summary [data-kind="needs"] {
  color: var(--ui-al-warn-fg);
}
.ui-al__summary [data-kind="needs"]::before {
  background: var(--ui-al-warn-fg);
  animation: ui-al-pulse 1600ms ease-in-out infinite;
}
.ui-al__window {
  flex: none;
  padding: 3px 10px;
  border-radius: 999px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
}
.ui-al__body {
  display: grid;
  grid-template-columns: 168px minmax(0, 1fr);
  padding: 26px 16px 12px 0;
}
.ui-al__agents {
  display: grid;
  grid-auto-rows: var(--ui-al-row);
}
.ui-al__agent {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 0 12px 0 16px;
}
.ui-al__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  overflow: hidden;
  border-radius: 50%;
  background: var(--ui-al-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-al-text);
}
.ui-al__avatar[data-logo] {
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
}
.ui-al__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-al__who {
  display: grid;
  min-width: 0;
}
.ui-al__name {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-al-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-al__name-line {
  display: flex;
  align-items: center;
  min-width: 0;
}
.ui-al__model {
  display: flex;
  align-items: center;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-muted);
  white-space: nowrap;
}
.ui-al__model-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__state {
  display: inline-grid;
  flex: none;
  grid-template-columns: 0fr;
  margin-left: 0;
  opacity: 0;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 220ms ease;
}
.ui-al__state[data-show] {
  grid-template-columns: 1fr;
  margin-left: 6px;
  opacity: 1;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 260ms ease 80ms;
}
.ui-al__state > span {
  min-width: 0;
  overflow: hidden;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-al-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
  white-space: nowrap;
}
.ui-al__who[data-state="waiting"] .ui-al__state > span {
  background: var(--ui-al-warn-bg);
  color: var(--ui-al-warn-fg);
}
.ui-al__track {
  position: relative;
  height: calc(var(--rows) * var(--ui-al-row));
}
.ui-al__track::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    transparent 0,
    transparent calc(var(--ui-al-row) - 0.5px),
    var(--ui-al-line) calc(var(--ui-al-row) - 0.5px),
    var(--ui-al-line) var(--ui-al-row)
  );
  pointer-events: none;
}
.ui-al__grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-al__tick {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 0;
  border-left: 0.5px dashed var(--ui-al-line);
}
.ui-al__tick > span {
  position: absolute;
  bottom: 100%;
  left: 0;
  margin-bottom: 6px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-al-faint);
  white-space: nowrap;
  transform: translateX(-50%);
  font-variant-numeric: tabular-nums;
}
.ui-al__clip {
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(to right, transparent 0, #000 40px);
  mask-image: linear-gradient(to right, transparent 0, #000 40px);
}
.ui-al__layer {
  position: absolute;
  inset: 0;
  will-change: transform;
}
.ui-al__curves {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-al__curves path {
  fill: none;
  stroke: var(--ui-al-rail);
  stroke-width: 1;
  stroke-dasharray: 3 3;
}
.ui-al__curves path[data-live] {
  stroke: var(--ui-al-run-edge);
  animation: ui-al-flow 900ms linear infinite;
}
.ui-al__lane {
  position: absolute;
  left: 0;
  right: 0;
  height: var(--ui-al-row);
  transition: opacity 240ms ease;
}
.ui-al__agent {
  transition: opacity 240ms ease;
}
:is(.ui-al__agent, .ui-al__lane)[data-faded] {
  opacity: 0.4;
}
.ui-al__slot {
  position: absolute;
  top: 10px;
  bottom: 10px;
  min-width: 6px;
}
.ui-al__slot:is([data-status="running"], [data-status="waiting"]),
.ui-al__slot:is([data-status="running"], [data-status="waiting"])
  .ui-al__block {
  min-width: 0;
}
.ui-al__block {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  min-width: 6px;
  padding: 0 10px;
  overflow: hidden;
  border-radius: 8px;
  background: var(--ui-al-done);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
  white-space: nowrap;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-al__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: clip;
  text-align: start;
}
.ui-al__tools {
  display: flex;
  flex: none;
  gap: 4px;
  margin-right: 6px;
}
.ui-al__tool {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-al__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-al__block:hover {
  background: var(--ui-al-fill);
}
.ui-al__block[data-status="running"] {
  position: relative;
  background: var(--ui-al-run-bg);
  color: var(--ui-al-run-fg);
  box-shadow: inset -2px 0 0 var(--ui-al-run-edge);
}
.ui-al__block[data-status="running"]::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(255, 255, 255, 0.55) 50%,
      transparent 100%
    )
    0 0 / 50% 100% no-repeat;
  animation: ui-al-shimmer 2200ms ease-in-out infinite;
}
.ui-al__block[data-status="waiting"] {
  background: var(--ui-al-warn-bg);
  color: var(--ui-al-warn-fg);
}
.ui-al__block[data-status="failed"] {
  background: var(--ui-al-danger-bg);
  color: var(--ui-al-danger-fg);
}
.ui-al__block[data-open] {
  filter: brightness(0.97);
}
.ui-al__flag {
  position: absolute;
  top: 50%;
  right: 4px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-al-warn-fg);
  white-space: nowrap;
  transform: translateY(-50%);
  pointer-events: none;
  animation: ui-al-pulse 1600ms ease-in-out infinite;
}
.ui-al__slot:has(.ui-al__block[data-status="waiting"]) {
  z-index: 2;
}
.ui-al__pop {
  position: absolute;
  z-index: 5;
  animation: ui-al-in 180ms ease both;
}
.ui-al__pop[data-up] {
  transform: translateY(-100%);
  animation-name: ui-al-in-up;
}
.ui-al__ask {
  display: grid;
  gap: 2px;
  width: 290px;
  padding: 14px;
  border-radius: 14px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-pop);
  max-width: calc(100cqw - 24px);
  overflow-wrap: anywhere;
}
.ui-al__tip {
  display: grid;
  gap: 4px;
  width: max-content;
  max-width: min(calc(100cqw - 24px), 230px);
  padding: 10px 12px;
  border-radius: 12px;
  background: rgba(23, 23, 23, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 10px 28px -8px rgba(0, 0, 0, 0.35);
  font-size: 12.5px;
  line-height: 17px;
  color: rgba(255, 255, 255, 0.86);
  translate: -50% 0;
  overflow-wrap: anywhere;
}
.ui-al__tip-head {
  display: flex;
  gap: 4px;
  min-width: 0;
  font-size: 11.5px;
  color: rgba(255, 255, 255, 0.55);
  white-space: nowrap;
}
.ui-al__tip-title {
  color: #fff;
}
.ui-al__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__tip-head > span:last-child {
  flex: none;
}
.ui-al__tip-list {
  display: grid;
  gap: 2px;
}
.ui-al__tip-list li {
  position: relative;
  padding-left: 10px;
}
.ui-al__tip-list li::before {
  content: "";
  position: absolute;
  top: 8px;
  left: 1px;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
}
.ui-al__tip-open {
  justify-self: start;
  margin-top: 2px;
  font-size: 12.5px;
  font-weight: 500;
  color: #fff;
  text-decoration: underline;
  text-decoration-color: rgba(255, 255, 255, 0.35);
  text-underline-offset: 2px;
}
.ui-al__ask-title {
  font-weight: 500;
  color: var(--ui-al-strong);
}
.ui-al__ask-text {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-text);
}
.ui-al__ask-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 8px;
}
.ui-al__btn {
  display: inline-flex;
  align-items: center;
  height: 30px;
  padding: 0 12px;
  border-radius: 9px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-al-strong);
}
.ui-al__btn:hover {
  background: var(--ui-al-wash);
}
.ui-al__btn--primary {
  background: var(--ui-al-solid);
  box-shadow: none;
  color: var(--ui-al-on-solid);
}
.ui-al__btn--primary:hover {
  background: #33333a;
}
.ui-al__now {
  position: absolute;
  top: -6px;
  right: 0;
  width: 0;
  pointer-events: none;
}
.ui-al__now > span {
  position: absolute;
  bottom: 100%;
  right: 0;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-al-run-bg);
  font-size: 10px;
  font-weight: 500;
  line-height: 14px;
  color: var(--ui-al-run-fg);
}
@keyframes ui-al-pulse {
  50% {
    opacity: 0.55;
  }
}
@keyframes ui-al-shimmer {
  from {
    background-position: -100% 0;
  }
  to {
    background-position: 200% 0;
  }
}
@keyframes ui-al-flow {
  to {
    stroke-dashoffset: -6;
  }
}
@keyframes ui-al-in {
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
}
@keyframes ui-al-in-up {
  from {
    opacity: 0;
    transform: translateY(calc(-100% + 3px));
  }
  to {
    transform: translateY(-100%);
  }
}
@container (max-width: 520px) {
  .ui-al__tip {
    max-width: 200px;
  }
  .ui-al__body {
    grid-template-columns: 48px minmax(0, 1fr);
  }
  .ui-al__who {
    display: none;
  }
  .ui-al__summary [data-kind="running"] {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-al *,
  .ui-al *::before,
  .ui-al *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-al {
  --ui-al-tray: #111113;
  --ui-al-card: #19191b;
  --ui-al-strong: #ffffff;
  --ui-al-ink: rgba(255, 255, 255, 0.9);
  --ui-al-text: rgba(255, 255, 255, 0.62);
  --ui-al-muted: rgba(255, 255, 255, 0.45);
  --ui-al-faint: rgba(255, 255, 255, 0.28);
  --ui-al-line: rgba(255, 255, 255, 0.08);
  --ui-al-rail: rgba(255, 255, 255, 0.2);
  --ui-al-wash: rgba(255, 255, 255, 0.04);
  --ui-al-fill: rgba(255, 255, 255, 0.08);
  --ui-al-done: rgba(255, 255, 255, 0.06);
  --ui-al-solid: rgba(255, 255, 255, 0.92);
  --ui-al-on-solid: #141416;
  --ui-al-run-bg: #0077ff3a;
  --ui-al-run-fg: #70b8ff;
  --ui-al-run-edge: rgba(112, 184, 255, 0.6);
  --ui-al-warn-bg: #fb6a0025;
  --ui-al-warn-fg: #ffa057;
  --ui-al-danger-bg: #ff35232b;
  --ui-al-danger-fg: #ff977d;
  --ui-al-focus: rgba(77, 141, 255, 0.8);
  --ui-al-shadow: 0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-al-pop: 0 0 0 1px #2a2a2e, 0 16px 36px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-al__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"]) .ui-al__block[data-status="running"]::after {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.12) 50%,
    transparent 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-al__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-head {
  color: rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-title,
:where(.dark, [data-theme="dark"]) .ui-al__tip-open {
  color: #000;
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-open {
  text-decoration-color: rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-list li::before {
  background: rgba(0, 0, 0, 0.4);
}
`;export{n as default};
