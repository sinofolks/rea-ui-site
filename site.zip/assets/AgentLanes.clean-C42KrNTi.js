const n=`.ui-alc {
  --ui-alc-card: #ffffff;
  --ui-alc-strong: #000000;
  --ui-alc-ink: rgba(0, 0, 0, 0.88);
  --ui-alc-text: rgba(0, 0, 0, 0.65);
  --ui-alc-muted: rgba(0, 0, 0, 0.65);
  --ui-alc-faint: rgba(0, 0, 0, 0.65);
  --ui-alc-line: rgba(0, 0, 0, 0.06);
  --ui-alc-rail: rgba(0, 0, 0, 0.15);
  --ui-alc-wash: rgba(0, 0, 0, 0.03);
  --ui-alc-fill: rgba(0, 0, 0, 0.06);
  --ui-alc-done: rgba(0, 0, 0, 0.05);
  --ui-alc-solid: rgba(0, 0, 0, 0.88);
  --ui-alc-on-solid: #fcfcfc;
  --ui-alc-run-bg: #008ff519;
  --ui-alc-run-fg: #006ac6;
  --ui-alc-run-edge: rgba(0, 96, 226, 0.5);
  --ui-alc-warn-bg: #ff9c0029;
  --ui-alc-warn-fg: #b74400;
  --ui-alc-danger-bg: #f52b0018;
  --ui-alc-danger-fg: #cd2200;
  --ui-alc-focus: rgba(0, 96, 226, 0.7);
  --ui-alc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-alc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-alc-row: 48px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 760px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-alc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-alc *,
.ui-alc *::before,
.ui-alc *::after {
  box-sizing: border-box;
}
:where(.ui-alc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-alc button:focus-visible {
  outline: 2px solid var(--ui-alc-focus);
  outline-offset: 2px;
}
.ui-alc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-alc svg {
  display: block;
  flex: none;
}
.ui-alc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-alc__card {
  border-radius: 10px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
}
.ui-alc__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 14px 16px;
  border-bottom: 0.5px solid var(--ui-alc-line);
}
.ui-alc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: #0060e2;
}
.ui-alc__title {
  font-weight: 500;
  color: var(--ui-alc-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__summary {
  display: flex;
  flex: 1;
  gap: 12px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-muted);
  white-space: nowrap;
}
.ui-alc__summary span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-alc__summary span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-alc-run-fg);
}
.ui-alc__summary [data-kind="needs"] {
  color: var(--ui-alc-warn-fg);
}
.ui-alc__summary [data-kind="needs"]::before {
  background: var(--ui-alc-warn-fg);
  animation: ui-alc-pulse 1600ms ease-in-out infinite;
}
.ui-alc__window {
  flex: none;
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--ui-alc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
}
.ui-alc__body {
  display: grid;
  grid-template-columns: 168px minmax(0, 1fr);
  padding: 26px 16px 12px 0;
}
.ui-alc__agents {
  display: grid;
  grid-auto-rows: var(--ui-alc-row);
}
.ui-alc__agent {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 0 12px 0 16px;
}
.ui-alc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-alc-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-alc-text);
}
.ui-alc__avatar[data-logo] {
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
}
.ui-alc__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-alc__who {
  display: grid;
  min-width: 0;
}
.ui-alc__name {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-alc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-alc__name-line {
  display: flex;
  align-items: center;
  min-width: 0;
}
.ui-alc__model {
  display: flex;
  align-items: center;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-muted);
  white-space: nowrap;
}
.ui-alc__model-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__state {
  display: inline-grid;
  flex: none;
  grid-template-columns: 0fr;
  margin-left: 0;
  opacity: 0;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 220ms ease;
}
.ui-alc__state[data-show] {
  grid-template-columns: 1fr;
  margin-left: 6px;
  opacity: 1;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 260ms ease 80ms;
}
.ui-alc__state > span {
  min-width: 0;
  overflow: hidden;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-alc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
  white-space: nowrap;
}
.ui-alc__who[data-state="waiting"] .ui-alc__state > span {
  background: var(--ui-alc-warn-bg);
  color: var(--ui-alc-warn-fg);
}
.ui-alc__track {
  position: relative;
  height: calc(var(--rows) * var(--ui-alc-row));
}
.ui-alc__track::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    transparent 0,
    transparent calc(var(--ui-alc-row) - 0.5px),
    var(--ui-alc-line) calc(var(--ui-alc-row) - 0.5px),
    var(--ui-alc-line) var(--ui-alc-row)
  );
  pointer-events: none;
}
.ui-alc__grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-alc__tick {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 0;
  border-left: 0.5px dashed var(--ui-alc-line);
}
.ui-alc__tick > span {
  position: absolute;
  bottom: 100%;
  left: 0;
  margin-bottom: 6px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-alc-faint);
  white-space: nowrap;
  transform: translateX(-50%);
  font-variant-numeric: tabular-nums;
}
.ui-alc__clip {
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(to right, transparent 0, #000 40px);
  mask-image: linear-gradient(to right, transparent 0, #000 40px);
}
.ui-alc__layer {
  position: absolute;
  inset: 0;
  will-change: transform;
}
.ui-alc__curves {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-alc__curves path {
  fill: none;
  stroke: var(--ui-alc-rail);
  stroke-width: 1;
  stroke-dasharray: 3 3;
}
.ui-alc__curves path[data-live] {
  stroke: var(--ui-alc-run-edge);
  animation: ui-alc-flow 900ms linear infinite;
}
.ui-alc__lane {
  position: absolute;
  left: 0;
  right: 0;
  height: var(--ui-alc-row);
  transition: opacity 240ms ease;
}
.ui-alc__agent {
  transition: opacity 240ms ease;
}
:is(.ui-alc__agent, .ui-alc__lane)[data-faded] {
  opacity: 0.4;
}
.ui-alc__slot {
  position: absolute;
  top: 10px;
  bottom: 10px;
  min-width: 6px;
}
.ui-alc__slot:is([data-status="running"], [data-status="waiting"]),
.ui-alc__slot:is([data-status="running"], [data-status="waiting"])
  .ui-alc__block {
  min-width: 0;
}
.ui-alc__block {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  min-width: 6px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-alc-done);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
  white-space: nowrap;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-alc__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: clip;
  text-align: start;
}
.ui-alc__tools {
  display: flex;
  flex: none;
  gap: 4px;
  margin-right: 6px;
}
.ui-alc__tool {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-alc__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-alc__block:hover {
  background: var(--ui-alc-fill);
}
.ui-alc__block[data-status="running"] {
  position: relative;
  background: var(--ui-alc-run-bg);
  color: var(--ui-alc-run-fg);
  box-shadow: inset -2px 0 0 var(--ui-alc-run-edge);
}
.ui-alc__block[data-status="running"]::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(255, 255, 255, 0.55) 50%,
      transparent 100%
    )
    0 0 / 50% 100% no-repeat;
  animation: ui-alc-shimmer 2200ms ease-in-out infinite;
}
.ui-alc__block[data-status="waiting"] {
  background: var(--ui-alc-warn-bg);
  color: var(--ui-alc-warn-fg);
}
.ui-alc__block[data-status="failed"] {
  background: var(--ui-alc-danger-bg);
  color: var(--ui-alc-danger-fg);
}
.ui-alc__block[data-open] {
  filter: brightness(0.97);
}
.ui-alc__flag {
  position: absolute;
  top: 50%;
  right: 4px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-alc-warn-fg);
  white-space: nowrap;
  transform: translateY(-50%);
  pointer-events: none;
  animation: ui-alc-pulse 1600ms ease-in-out infinite;
}
.ui-alc__slot:has(.ui-alc__block[data-status="waiting"]) {
  z-index: 2;
}
.ui-alc__pop {
  position: absolute;
  z-index: 5;
  animation: ui-alc-in 180ms ease both;
}
.ui-alc__pop[data-up] {
  transform: translateY(-100%);
  animation-name: ui-alc-in-up;
}
.ui-alc__ask {
  display: grid;
  gap: 2px;
  width: 280px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-pop);
  max-width: calc(100cqw - 24px);
  overflow-wrap: anywhere;
}
.ui-alc__tip {
  display: grid;
  gap: 4px;
  width: max-content;
  max-width: min(calc(100cqw - 24px), 220px);
  padding: 8px 10px;
  border-radius: 8px;
  background: rgba(24, 24, 27, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.35);
  font-size: 12px;
  line-height: 16px;
  color: rgba(255, 255, 255, 0.86);
  translate: -50% 0;
  overflow-wrap: anywhere;
}
.ui-alc__tip-head {
  display: flex;
  gap: 4px;
  min-width: 0;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.55);
  white-space: nowrap;
}
.ui-alc__tip-title {
  color: #fff;
}
.ui-alc__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__tip-head > span:last-child {
  flex: none;
}
.ui-alc__tip-list {
  display: grid;
  gap: 2px;
}
.ui-alc__tip-list li {
  position: relative;
  padding-left: 10px;
}
.ui-alc__tip-list li::before {
  content: "";
  position: absolute;
  top: 7px;
  left: 1px;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
}
.ui-alc__tip-open {
  justify-self: start;
  margin-top: 2px;
  font-size: 12px;
  font-weight: 500;
  color: #fff;
  text-decoration: underline;
  text-decoration-color: rgba(255, 255, 255, 0.35);
  text-underline-offset: 2px;
}
.ui-alc__ask-title {
  font-weight: 500;
  color: var(--ui-alc-strong);
}
.ui-alc__ask-text {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-text);
}
.ui-alc__ask-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 8px;
}
.ui-alc__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-alc-strong);
}
.ui-alc__btn:hover {
  background: var(--ui-alc-wash);
}
.ui-alc__btn--primary {
  background: var(--ui-alc-solid);
  box-shadow: none;
  color: var(--ui-alc-on-solid);
}
.ui-alc__btn--primary:hover {
  background: #33333a;
}
.ui-alc__now {
  position: absolute;
  top: -6px;
  right: 0;
  width: 0;
  pointer-events: none;
}
.ui-alc__now > span {
  position: absolute;
  bottom: 100%;
  right: 0;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-alc-run-bg);
  font-size: 10px;
  font-weight: 500;
  line-height: 14px;
  color: var(--ui-alc-run-fg);
}
@keyframes ui-alc-pulse {
  50% {
    opacity: 0.55;
  }
}
@keyframes ui-alc-shimmer {
  from {
    background-position: -100% 0;
  }
  to {
    background-position: 200% 0;
  }
}
@keyframes ui-alc-flow {
  to {
    stroke-dashoffset: -6;
  }
}
@keyframes ui-alc-in {
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
}
@keyframes ui-alc-in-up {
  from {
    opacity: 0;
    transform: translateY(calc(-100% + 3px));
  }
  to {
    transform: translateY(-100%);
  }
}
@container (max-width: 520px) {
  .ui-alc__tip {
    max-width: 200px;
  }
  .ui-alc__body {
    grid-template-columns: 48px minmax(0, 1fr);
  }
  .ui-alc__who {
    display: none;
  }
  .ui-alc__summary [data-kind="running"] {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-alc *,
  .ui-alc *::before,
  .ui-alc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-alc {
  --ui-alc-card: #1c1c1f;
  --ui-alc-strong: #ffffff;
  --ui-alc-ink: rgba(255, 255, 255, 0.9);
  --ui-alc-text: rgba(255, 255, 255, 0.62);
  --ui-alc-muted: rgba(255, 255, 255, 0.45);
  --ui-alc-faint: rgba(255, 255, 255, 0.28);
  --ui-alc-line: rgba(255, 255, 255, 0.08);
  --ui-alc-rail: rgba(255, 255, 255, 0.2);
  --ui-alc-wash: rgba(255, 255, 255, 0.04);
  --ui-alc-fill: rgba(255, 255, 255, 0.08);
  --ui-alc-done: rgba(255, 255, 255, 0.06);
  --ui-alc-solid: rgba(255, 255, 255, 0.92);
  --ui-alc-on-solid: #141416;
  --ui-alc-run-bg: #0077ff3a;
  --ui-alc-run-fg: #70b8ff;
  --ui-alc-run-edge: rgba(112, 184, 255, 0.6);
  --ui-alc-warn-bg: #fb6a0025;
  --ui-alc-warn-fg: #ffa057;
  --ui-alc-danger-bg: #ff35232b;
  --ui-alc-danger-fg: #ff977d;
  --ui-alc-focus: rgba(77, 141, 255, 0.8);
  --ui-alc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-alc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-alc__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"])
  .ui-alc__block[data-status="running"]::after {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.12) 50%,
    transparent 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-head {
  color: rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-title,
:where(.dark, [data-theme="dark"]) .ui-alc__tip-open {
  color: #000;
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-open {
  text-decoration-color: rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-list li::before {
  background: rgba(0, 0, 0, 0.4);
}
`;export{n as default};
