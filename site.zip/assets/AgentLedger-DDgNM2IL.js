const n=`.ui-ldg {
  --ui-ldg-tray: #f0f0f0;
  --ui-ldg-panel: #ffffff;
  --ui-ldg-card: #ffffff;
  --ui-ldg-strong: #171717;
  --ui-ldg-ink: #171717;
  --ui-ldg-text: #6b6b6b;
  --ui-ldg-muted: #626873;
  --ui-ldg-faint: #6b6b6b;
  --ui-ldg-line: #f0f0f0;
  --ui-ldg-fill: rgba(0, 0, 0, 0.05);
  --ui-ldg-accent: #2a5ee5;
  --ui-ldg-focus: rgba(0, 96, 226, 0.7);
  --ui-ldg-undo-bg: #f2f6ff;
  --ui-ldg-also-bg: #f5f8ff;
  --ui-ldg-also-chip: #e3ecff;
  --ui-ldg-also-fg: #2456d6;
  --ui-ldg-kept-bg: #fff8ee;
  --ui-ldg-kept-chip: #ffefd6;
  --ui-ldg-kept-fg: #a45200;
  --ui-ldg-strike: #8a8a8a;
  --ui-ldg-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-ldg-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-ldg-row: 62px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ldg-tray);
  container: ui-ldg / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-ldg-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ldg *,
.ui-ldg *::before,
.ui-ldg *::after {
  box-sizing: border-box;
}
:where(.ui-ldg) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ldg button:focus-visible {
  outline: 2px solid var(--ui-ldg-focus);
  outline-offset: 2px;
}
.ui-ldg svg {
  display: block;
  flex: none;
}
.ui-ldg__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  padding: 8px 12px 12px;
}
.ui-ldg__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-ldg-accent);
}
.ui-ldg__title {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 600;
  color: var(--ui-ldg-strong);
}
.ui-ldg__agent {
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  color: var(--ui-ldg-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ldg__sum {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-left: auto;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ldg-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-ldg__sum b {
  font-weight: 600;
  color: var(--ui-ldg-ink);
}
.ui-ldg__sum-undone {
  animation: ui-ldg-fade 240ms ease both;
}
.ui-ldg__panel {
  display: grid;
  margin: 0;
  padding: 6px;
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-ldg-panel);
  box-shadow: var(--ui-ldg-shadow);
  list-style: none;
}
.ui-ldg__row {
  position: relative;
  display: grid;
  grid-template-columns: 32px minmax(0, 1fr) auto;
  align-items: center;
  column-gap: 12px;
  height: var(--ui-ldg-row);
  padding: 10px 12px 10px 10px;
  border-radius: 11px;
  transition: background-color 200ms ease;
  animation: ui-ldg-grow 520ms var(--ui-ldg-ease) backwards;
}
.ui-ldg__row > * {
  animation: ui-ldg-in 420ms var(--ui-ldg-ease) 140ms backwards;
}
.ui-ldg__row[data-initial],
.ui-ldg__row[data-initial] > * {
  animation: none;
}
.ui-ldg__row + .ui-ldg__row::before {
  content: "";
  position: absolute;
  top: 0;
  right: 12px;
  left: 54px;
  height: 1px;
  background: var(--ui-ldg-line);
}
.ui-ldg__row:hover {
  background: #fafafa;
}
.ui-ldg__row[data-preview] {
  background: var(--ui-ldg-undo-bg);
}
.ui-ldg__row[data-chain="also"] {
  background: var(--ui-ldg-also-bg);
}
.ui-ldg__row[data-chain="kept"] {
  background: var(--ui-ldg-kept-bg);
}
.ui-ldg__row:is([data-preview], [data-chain]) + .ui-ldg__row::before,
.ui-ldg__row:is([data-preview], [data-chain])::before {
  opacity: 0;
}
.ui-ldg__icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  background: var(--ui-ldg-card);
  box-shadow: var(--ui-ldg-shadow);
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-ldg-text);
  transition:
    opacity 300ms ease,
    filter 300ms ease;
}
.ui-ldg__icon > svg {
  width: 16px;
  height: 16px;
}
.ui-ldg__main {
  position: relative;
  display: grid;
  min-width: 0;
}
.ui-ldg__what {
  position: relative;
  display: flex;
  align-items: baseline;
  gap: 6px;
  justify-self: start;
  min-width: 0;
  max-width: 100%;
  white-space: nowrap;
}
.ui-ldg__action {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 600;
  color: var(--ui-ldg-ink);
  transition: color 300ms ease;
}
.ui-ldg__target {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ldg-text);
  text-overflow: ellipsis;
  transition: color 300ms ease;
}
.ui-ldg__change {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-ldg-muted);
  white-space: nowrap;
}
.ui-ldg__before {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-decoration: line-through;
  text-decoration-color: var(--ui-ldg-faint);
}
.ui-ldg__arrow {
  flex: none;
  color: var(--ui-ldg-faint);
}
.ui-ldg__detail {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ldg__after {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ldg-text);
  text-overflow: ellipsis;
}
.ui-ldg__strike {
  position: absolute;
  top: 50%;
  left: -2px;
  width: calc(100% + 4px);
  height: 1.5px;
  border-radius: 1px;
  background: var(--ui-ldg-strike);
  transform: scaleX(0);
  transform-origin: left;
  pointer-events: none;
  transition: transform 380ms var(--ui-ldg-ease) calc(var(--o, 0) * 110ms);
}
.ui-ldg__row[data-undone] .ui-ldg__strike {
  transform: scaleX(1);
}
.ui-ldg__row[data-undone]
  :is(.ui-ldg__action, .ui-ldg__target, .ui-ldg__after) {
  color: var(--ui-ldg-muted);
  transition-delay: calc(var(--o, 0) * 110ms);
}
.ui-ldg__row[data-undone] .ui-ldg__icon {
  opacity: 0.5;
  filter: grayscale(1);
  transition-delay: calc(var(--o, 0) * 110ms);
}
.ui-ldg__end {
  position: relative;
  display: grid;
  justify-items: end;
  align-items: center;
  min-width: 120px;
  height: 28px;
}
.ui-ldg__time {
  grid-area: 1 / 1;
  pointer-events: none;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ldg-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  transition: opacity 140ms ease;
}
.ui-ldg__row[data-undone] .ui-ldg__time {
  color: var(--ui-ldg-faint);
}
.ui-ldg__act {
  position: relative;
  z-index: 1;
  grid-area: 1 / 1;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin-right: -4px;
  padding: 0 11px 0 9px;
  border-radius: 999px;
  background: var(--ui-ldg-card);
  box-shadow: var(--ui-ldg-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ldg-ink);
  white-space: nowrap;
  opacity: 0;
  transition:
    opacity 140ms ease,
    box-shadow 140ms ease;
}
.ui-ldg__row:is(:hover, :focus-within, [data-preview]) .ui-ldg__act {
  opacity: 1;
}
.ui-ldg__row:is(:hover, :focus-within) .ui-ldg__time[data-hide],
.ui-ldg__row[data-preview] .ui-ldg__time[data-hide] {
  opacity: 0;
}
.ui-ldg__act:hover {
  box-shadow:
    0 0 0 1px #e2e2e2,
    0 2px 6px rgba(0, 0, 0, 0.08);
}
.ui-ldg__row[data-preview] .ui-ldg__act {
  color: var(--ui-ldg-also-fg);
}
.ui-ldg__flag {
  grid-area: 1 / 1;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 10px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 24px;
  white-space: nowrap;
  animation: ui-ldg-fade 160ms ease both;
}
.ui-ldg__flag[data-kind="also"] {
  background: var(--ui-ldg-also-chip);
  color: var(--ui-ldg-also-fg);
}
.ui-ldg__flag[data-kind="kept"] {
  background: var(--ui-ldg-kept-chip);
  color: var(--ui-ldg-kept-fg);
}
@container ui-ldg (max-width: 480px) {
  .ui-ldg__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-ldg__row {
    column-gap: 10px;
    padding: 10px 8px 10px 8px;
  }
  .ui-ldg__row + .ui-ldg__row::before {
    left: 50px;
    right: 8px;
  }
  .ui-ldg__end {
    min-width: 76px;
  }
  .ui-ldg__sys {
    display: none;
  }
  .ui-ldg__act {
    width: 28px;
    justify-content: center;
    padding: 0;
  }
  .ui-ldg__act-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}
@media (hover: none) {
  .ui-ldg__act {
    opacity: 1;
  }
  .ui-ldg__time[data-hide] {
    opacity: 0;
  }
}
@keyframes ui-ldg-grow {
  from {
    height: 0;
    padding-top: 0;
    padding-bottom: 0;
  }
}
@keyframes ui-ldg-in {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }
}
@keyframes ui-ldg-fade {
  from {
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ldg *,
  .ui-ldg *::before,
  .ui-ldg *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ldg {
  --ui-ldg-tray: #1a1a1c;
  --ui-ldg-panel: #232326;
  --ui-ldg-card: #2a2a2e;
  --ui-ldg-strong: #f5f5f5;
  --ui-ldg-ink: #f0f0f0;
  --ui-ldg-text: #a1a1a1;
  --ui-ldg-muted: #8a8a8a;
  --ui-ldg-faint: #5c5c5c;
  --ui-ldg-line: #2e2e31;
  --ui-ldg-fill: rgba(255, 255, 255, 0.06);
  --ui-ldg-accent: #6d93ff;
  --ui-ldg-focus: rgba(77, 141, 255, 0.8);
  --ui-ldg-undo-bg: #1d2436;
  --ui-ldg-also-bg: #1c2232;
  --ui-ldg-also-chip: #1d2b4d;
  --ui-ldg-also-fg: #8aaeff;
  --ui-ldg-kept-bg: #2a2219;
  --ui-ldg-kept-chip: #3a2a12;
  --ui-ldg-kept-fg: #ffb357;
  --ui-ldg-strike: #8a8a8a;
  --ui-ldg-shadow: 0 0 0 1px #2e2e31, 0 1px 2px rgba(0, 0, 0, 0.4);
}
`;export{n as default};
