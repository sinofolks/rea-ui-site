const n=`.ui-ldgc {
  --ui-ldgc-panel: #ffffff;
  --ui-ldgc-card: #ffffff;
  --ui-ldgc-strong: #000000;
  --ui-ldgc-ink: rgba(0, 0, 0, 0.88);
  --ui-ldgc-text: rgba(0, 0, 0, 0.65);
  --ui-ldgc-muted: rgba(0, 0, 0, 0.65);
  --ui-ldgc-faint: rgba(0, 0, 0, 0.65);
  --ui-ldgc-line: rgba(0, 0, 0, 0.06);
  --ui-ldgc-fill: rgba(0, 0, 0, 0.06);
  --ui-ldgc-accent: #0060e2;
  --ui-ldgc-focus: rgba(0, 96, 226, 0.7);
  --ui-ldgc-undo-bg: rgba(0, 96, 226, 0.06);
  --ui-ldgc-also-bg: rgba(0, 96, 226, 0.045);
  --ui-ldgc-also-fg: #0058cf;
  --ui-ldgc-kept-bg: #ff9c0014;
  --ui-ldgc-kept-fg: #b74400;
  --ui-ldgc-ok-fg: #007d2ee0;
  --ui-ldgc-strike: rgba(0, 0, 0, 0.45);
  --ui-ldgc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ldgc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-ldgc-row: 56px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-ldgc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-ldgc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ldgc *,
.ui-ldgc *::before,
.ui-ldgc *::after {
  box-sizing: border-box;
}
:where(.ui-ldgc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ldgc button:focus-visible {
  outline: 2px solid var(--ui-ldgc-focus);
  outline-offset: 2px;
}
.ui-ldgc svg {
  display: block;
  flex: none;
}
.ui-ldgc__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  margin-bottom: 16px;
}
.ui-ldgc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-ldgc-accent);
}
.ui-ldgc__title {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-ldgc-strong);
}
.ui-ldgc__agent {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ldgc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ldgc__sum {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ldgc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-ldgc__sum b {
  font-weight: 500;
  color: var(--ui-ldgc-ink);
}
.ui-ldgc__sum-undone {
  animation: ui-ldgc-fade 240ms ease both;
}
.ui-ldgc__panel {
  display: grid;
  margin: 0;
  padding: 4px;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-ldgc-panel);
  box-shadow: var(--ui-ldgc-shadow);
  list-style: none;
}
.ui-ldgc__row {
  position: relative;
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr) auto;
  align-items: center;
  column-gap: 12px;
  height: var(--ui-ldgc-row);
  padding: 9px 12px 9px 10px;
  border-radius: 7px;
  transition: background-color 200ms ease;
  animation: ui-ldgc-grow 520ms var(--ui-ldgc-ease) backwards;
}
.ui-ldgc__row > * {
  animation: ui-ldgc-in 420ms var(--ui-ldgc-ease) 140ms backwards;
}
.ui-ldgc__row[data-initial],
.ui-ldgc__row[data-initial] > * {
  animation: none;
}
.ui-ldgc__row + .ui-ldgc__row::before {
  content: "";
  position: absolute;
  top: -0.25px;
  right: 12px;
  left: 50px;
  height: 0.5px;
  background: var(--ui-ldgc-line);
}
.ui-ldgc__row:hover {
  background: rgba(0, 0, 0, 0.015);
}
.ui-ldgc__row[data-preview] {
  background: var(--ui-ldgc-undo-bg);
}
.ui-ldgc__row[data-chain="also"] {
  background: var(--ui-ldgc-also-bg);
}
.ui-ldgc__row[data-chain="kept"] {
  background: var(--ui-ldgc-kept-bg);
}
.ui-ldgc__row:is([data-preview], [data-chain]) + .ui-ldgc__row::before,
.ui-ldgc__row:is([data-preview], [data-chain])::before {
  opacity: 0;
}
.ui-ldgc__icon {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--ui-ldgc-card);
  box-shadow: var(--ui-ldgc-shadow);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-ldgc-text);
  transition:
    opacity 300ms ease,
    filter 300ms ease;
}
.ui-ldgc__icon > svg {
  width: 14px;
  height: 14px;
}
.ui-ldgc__main {
  position: relative;
  display: grid;
  min-width: 0;
}
.ui-ldgc__what {
  position: relative;
  display: flex;
  align-items: baseline;
  gap: 6px;
  justify-self: start;
  min-width: 0;
  max-width: 100%;
  white-space: nowrap;
}
.ui-ldgc__action {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-ldgc-ink);
  transition: color 300ms ease;
}
.ui-ldgc__target {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ldgc-text);
  text-overflow: ellipsis;
  transition: color 300ms ease;
}
.ui-ldgc__change {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-ldgc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ldgc__before {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-decoration: line-through;
  text-decoration-color: var(--ui-ldgc-faint);
}
.ui-ldgc__arrow {
  flex: none;
  color: var(--ui-ldgc-faint);
}
.ui-ldgc__detail {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ldgc__after {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ldgc-text);
  text-overflow: ellipsis;
}
.ui-ldgc__strike {
  position: absolute;
  top: 50%;
  left: -2px;
  width: calc(100% + 4px);
  height: 1px;
  border-radius: 1px;
  background: var(--ui-ldgc-strike);
  transform: scaleX(0);
  transform-origin: left;
  pointer-events: none;
  transition: transform 380ms var(--ui-ldgc-ease) calc(var(--o, 0) * 110ms);
}
.ui-ldgc__row[data-undone] .ui-ldgc__strike {
  transform: scaleX(1);
}
.ui-ldgc__row[data-undone]
  :is(.ui-ldgc__action, .ui-ldgc__target, .ui-ldgc__after) {
  color: var(--ui-ldgc-muted);
  transition-delay: calc(var(--o, 0) * 110ms);
}
.ui-ldgc__row[data-undone] .ui-ldgc__icon {
  opacity: 0.5;
  filter: grayscale(1);
  transition-delay: calc(var(--o, 0) * 110ms);
}
.ui-ldgc__end {
  position: relative;
  display: grid;
  justify-items: end;
  align-items: center;
  min-width: 108px;
  height: 24px;
}
.ui-ldgc__time {
  grid-area: 1 / 1;
  pointer-events: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ldgc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  transition: opacity 140ms ease;
}
.ui-ldgc__row[data-undone] .ui-ldgc__time {
  color: var(--ui-ldgc-faint);
}
.ui-ldgc__act {
  position: relative;
  z-index: 1;
  grid-area: 1 / 1;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  margin-right: -6px;
  padding: 0 7px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-ldgc-ink);
  white-space: nowrap;
  opacity: 0;
  transition:
    opacity 140ms ease,
    background-color 140ms ease;
}
.ui-ldgc__row:is(:hover, :focus-within) .ui-ldgc__time[data-hide] {
  opacity: 0;
}
.ui-ldgc__row:is(:hover, :focus-within, [data-preview]) .ui-ldgc__act {
  opacity: 1;
}
.ui-ldgc__row[data-preview] .ui-ldgc__time[data-hide] {
  opacity: 0;
}
.ui-ldgc__row[data-preview] .ui-ldgc__act {
  background: rgba(0, 96, 226, 0.09);
  color: var(--ui-ldgc-also-fg);
}
.ui-ldgc__act:hover {
  background: var(--ui-ldgc-fill);
}
.ui-ldgc__flag {
  grid-area: 1 / 1;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  animation: ui-ldgc-fade 160ms ease both;
}
.ui-ldgc__flag[data-kind="also"] {
  background: rgba(0, 96, 226, 0.09);
  color: var(--ui-ldgc-also-fg);
}
.ui-ldgc__flag[data-kind="kept"] {
  background: #ff9c0026;
  color: var(--ui-ldgc-kept-fg);
}
@container ui-ldgc (max-width: 480px) {
  .ui-ldgc__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-ldgc__row {
    column-gap: 10px;
    padding: 9px 8px 9px 8px;
  }
  .ui-ldgc__row + .ui-ldgc__row::before {
    left: 46px;
    right: 8px;
  }
  .ui-ldgc__end {
    min-width: 64px;
  }
  .ui-ldgc__sys {
    display: none;
  }
  .ui-ldgc__act {
    width: 28px;
    justify-content: center;
    padding: 0;
  }
  .ui-ldgc__act-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}
@media (hover: none) {
  .ui-ldgc__act {
    opacity: 1;
  }
  .ui-ldgc__time[data-hide] {
    opacity: 0;
  }
}
@keyframes ui-ldgc-grow {
  from {
    height: 0;
    padding-top: 0;
    padding-bottom: 0;
  }
}
@keyframes ui-ldgc-in {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }
}
@keyframes ui-ldgc-fade {
  from {
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ldgc *,
  .ui-ldgc *::before,
  .ui-ldgc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ldgc {
  --ui-ldgc-panel: #1c1c1f;
  --ui-ldgc-card: #232326;
  --ui-ldgc-strong: #ffffff;
  --ui-ldgc-ink: rgba(255, 255, 255, 0.9);
  --ui-ldgc-text: rgba(255, 255, 255, 0.62);
  --ui-ldgc-muted: rgba(255, 255, 255, 0.45);
  --ui-ldgc-faint: rgba(255, 255, 255, 0.28);
  --ui-ldgc-line: rgba(255, 255, 255, 0.08);
  --ui-ldgc-fill: rgba(255, 255, 255, 0.08);
  --ui-ldgc-accent: #5b9aff;
  --ui-ldgc-focus: rgba(77, 141, 255, 0.8);
  --ui-ldgc-undo-bg: rgba(91, 154, 255, 0.1);
  --ui-ldgc-also-bg: rgba(91, 154, 255, 0.07);
  --ui-ldgc-also-fg: #8ab8ff;
  --ui-ldgc-kept-bg: rgba(255, 160, 40, 0.09);
  --ui-ldgc-kept-fg: #ffb357;
  --ui-ldgc-ok-fg: #3dd68c;
  --ui-ldgc-strike: rgba(255, 255, 255, 0.5);
  --ui-ldgc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
