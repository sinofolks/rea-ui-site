const n=`.ui-pl {
  --ui-pl-tray: #f0f0f0;
  --ui-pl-card: #ffffff;
  --ui-pl-ink: #171717;
  --ui-pl-text: #6b6b6b;
  --ui-pl-muted: #626873;
  --ui-pl-faint: #6b6b6b;
  --ui-pl-line: #ececec;
  --ui-pl-raise: #ffffff;
  --ui-pl-hover: #f6f6f6;
  --ui-pl-quiet-hover: #e4e4e5;
  --ui-pl-press: rgba(23, 23, 23, 0.05);
  --ui-pl-chip: #f3f3f3;
  --ui-pl-chip-text: #555555;
  --ui-pl-marker: #f0f0f0;
  --ui-pl-rail: #c4c4c8;
  --ui-pl-on-ink: #ffffff;
  --ui-pl-red: #c2331f;
  --ui-pl-red-bg: #fdf3f1;
  --ui-pl-red-ring: rgba(194, 51, 31, 0.32);
  --ui-pl-focus: rgba(0, 96, 226, 0.7);
  --ui-pl-lift:
    0 1px 2px rgba(0, 0, 0, 0.06), 0 12px 28px -10px rgba(0, 0, 0, 0.2);
  --ui-pl-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-pl-inset: 30px;
  container-type: inline-size;
  position: relative;
  box-sizing: border-box;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 460px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-pl-tray);
  color: var(--ui-pl-text);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pl__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-pl-card);
  box-shadow:
    0 0 0 1px var(--ui-pl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pl:not([data-status="draft"]) {
  --ui-pl-inset: 14px;
}
.ui-pl[data-dragging] {
  cursor: grabbing;
  user-select: none;
  -webkit-user-select: none;
}
.ui-pl *,
.ui-pl *::before,
.ui-pl *::after {
  box-sizing: border-box;
}
.ui-pl svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
:where(.ui-pl) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  letter-spacing: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-pl__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-pl__head {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  padding: 16px 18px 8px;
}
.ui-pl__meta {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 18px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-pl-muted);
}
.ui-pl__state {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  flex: none;
}
.ui-pl__state-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-pl__state-icon,
.ui-pl__status-icon {
  flex: none;
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-pl__state-icon circle[r=".6"] {
  fill: currentColor;
}
.ui-pl__estimate {
  display: inline-flex;
  align-items: center;
  min-width: 0;
  gap: 5px;
  margin-left: auto;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-pl__estimate > span {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pl__estimate svg {
  flex: none;
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-pl__title {
  margin: 0;
  color: var(--ui-pl-ink);
  font-size: 15px;
  font-weight: 600;
  line-height: 22px;
  letter-spacing: -0.012em;
  text-wrap: balance;
  overflow-wrap: anywhere;
  text-align: start;
}
.ui-pl__list {
  position: relative;
  margin: 0;
  padding: 2px 6px 6px;
  list-style: none;
}
.ui-pl__step {
  position: relative;
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr) auto;
  column-gap: 12px;
  align-items: start;
  padding: 10px 10px 10px var(--ui-pl-inset);
  border-radius: 10px;
  outline: none;
  transition:
    transform 420ms var(--ui-pl-ease),
    padding 420ms var(--ui-pl-ease),
    height 260ms var(--ui-pl-ease),
    opacity 180ms ease,
    background-color 160ms ease,
    box-shadow 200ms ease;
}
.ui-pl[data-status="draft"] .ui-pl__step:hover {
  background: var(--ui-pl-hover);
}
.ui-pl__step:focus-visible {
  outline: 2px solid var(--ui-pl-focus);
  outline-offset: -2px;
}
.ui-pl__step[data-dragging] {
  z-index: 2;
  background: var(--ui-pl-raise) !important;
  box-shadow:
    inset 0 0 0 1px var(--ui-pl-line),
    var(--ui-pl-lift);
  transition:
    background-color 160ms ease,
    box-shadow 200ms ease;
}
.ui-pl__step[data-removing] {
  height: 0 !important;
  padding-top: 0;
  padding-bottom: 0;
  overflow: hidden;
  opacity: 0;
  pointer-events: none;
}
.ui-pl__step[data-enter] {
  animation: ui-pl-enter 380ms var(--ui-pl-ease) both;
}
.ui-pl__grip {
  position: absolute;
  top: 10px;
  left: 6px;
  display: grid;
  place-items: center;
  width: 18px;
  height: 22px;
  margin-top: -1px;
  border-radius: 5px;
  color: var(--ui-pl-faint);
  fill: currentColor;
  cursor: grab;
  touch-action: none;
  opacity: 0;
  transition:
    opacity 160ms ease,
    color 160ms ease,
    background-color 160ms ease;
}
.ui-pl__grip svg {
  width: 14px;
  height: 14px;
}
.ui-pl__step:hover .ui-pl__grip,
.ui-pl__step:focus-visible .ui-pl__grip,
.ui-pl__step[data-dragging] .ui-pl__grip {
  opacity: 1;
}
.ui-pl__grip:hover,
.ui-pl__step[data-dragging] .ui-pl__grip {
  color: var(--ui-pl-text);
  background: var(--ui-pl-press);
}
.ui-pl__step[data-dragging] .ui-pl__grip {
  cursor: grabbing;
}
.ui-pl__marker {
  position: relative;
  z-index: 1;
  display: grid;
  place-items: center;
  justify-self: center;
  width: 20px;
  height: 20px;
  border-radius: 999px;
  background: var(--ui-pl-card);
  box-shadow: inset 0 0 0 1px var(--ui-pl-line);
  color: var(--ui-pl-muted);
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 320ms ease,
    color 320ms ease,
    box-shadow 320ms ease;
}
.ui-pl__marker > * {
  grid-area: 1 / 1;
  animation: ui-pl-pop 360ms var(--ui-pl-ease) both;
}
.ui-pl__num {
  animation: none !important;
}
.ui-pl__marker .ui-pl__spinner {
  width: 13px;
  height: 13px;
}
.ui-pl__mark {
  width: 11px !important;
  height: 11px !important;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.9;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-pl__step[data-step="active"] .ui-pl__marker {
  box-shadow: none;
  color: var(--ui-pl-ink);
}
.ui-pl__step[data-step="done"] .ui-pl__marker {
  background: var(--ui-pl-marker);
  box-shadow: none;
  color: var(--ui-pl-ink);
}
.ui-pl__step[data-step="failed"] .ui-pl__marker {
  background: var(--ui-pl-red-bg);
  box-shadow: inset 0 0 0 1px var(--ui-pl-red-ring);
  color: var(--ui-pl-red);
}
.ui-pl__step[data-step="skipped"] .ui-pl__marker {
  box-shadow: none;
  outline: 1px dashed var(--ui-pl-faint);
  outline-offset: -1px;
}
.ui-pl__draw {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-pl-draw 420ms var(--ui-pl-ease) 80ms forwards;
}
.ui-pl__spinner line {
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  opacity: 0.18;
  animation: ui-pl-ray 800ms linear infinite;
}
.ui-pl__main {
  display: grid;
  gap: 2px;
  min-width: 0;
}
.ui-pl__name {
  color: var(--ui-pl-ink);
  font-weight: 500;
  overflow-wrap: anywhere;
  text-align: start;
  transition: color 300ms ease;
}
.ui-pl[data-status="draft"] .ui-pl__name {
  cursor: text;
}
.ui-pl__step[data-step="pending"] .ui-pl__name {
  color: var(--ui-pl-text);
}
.ui-pl__step[data-step="skipped"] .ui-pl__name {
  color: var(--ui-pl-muted);
  text-decoration: line-through;
  text-decoration-color: var(--ui-pl-faint);
}
.ui-pl__sub {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 3px 8px;
  min-width: 0;
  color: var(--ui-pl-muted);
  font-size: 12.5px;
  line-height: 18px;
}
.ui-pl__detail {
  min-width: 0;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
}
.ui-pl__tool {
  padding: 1px 6px;
  border-radius: 6px;
  background: var(--ui-pl-chip);
  color: var(--ui-pl-chip-text);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11px;
  line-height: 16px;
  letter-spacing: 0;
  white-space: nowrap;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pl__edit {
  width: calc(100% + 14px);
  height: 26px;
  margin: -3px -7px;
  padding: 0 6px;
  border: 0;
  border-radius: 7px;
  background: var(--ui-pl-raise);
  box-shadow: inset 0 0 0 1px var(--ui-pl-rail);
  color: var(--ui-pl-ink);
  font: inherit;
  font-weight: 500;
  letter-spacing: inherit;
  outline: none;
}
.ui-pl__fail {
  display: grid;
  justify-items: start;
  gap: 8px;
  margin-top: 4px;
  animation: ui-pl-fade 360ms var(--ui-pl-ease) both;
}
.ui-pl__error {
  color: var(--ui-pl-red);
  font-size: 12.5px;
  line-height: 18px;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
}
.ui-pl__retry {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 9px;
  border-radius: 8px;
  background: var(--ui-pl-raise);
  box-shadow:
    inset 0 0 0 1px var(--ui-pl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-pl-ink);
  font-size: 12.5px;
  font-weight: 500;
  transition:
    background-color 160ms ease,
    transform 160ms var(--ui-pl-ease);
}
.ui-pl__retry svg {
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-pl__retry:hover {
  background: var(--ui-pl-hover);
}
.ui-pl__retry:active {
  transform: scale(0.97);
}
.ui-pl__aside {
  display: flex;
  align-items: center;
  min-height: 20px;
  color: var(--ui-pl-muted);
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-pl__time {
  animation: ui-pl-fade 300ms ease both;
}
.ui-pl__step[data-step="active"] .ui-pl__time {
  color: var(--ui-pl-ink);
}
.ui-pl__remove {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  margin: -2px -4px 0 0;
  border-radius: 7px;
  color: var(--ui-pl-faint);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  opacity: 0;
  transition:
    opacity 160ms ease,
    color 160ms ease,
    background-color 160ms ease;
}
.ui-pl__remove svg {
  width: 14px;
  height: 14px;
}
.ui-pl__step:hover .ui-pl__remove,
.ui-pl__step:focus-visible .ui-pl__remove,
.ui-pl__remove:focus-visible {
  opacity: 1;
}
.ui-pl__remove:hover {
  color: var(--ui-pl-ink);
  background: var(--ui-pl-press);
}
.ui-pl__remove:focus-visible,
.ui-pl__retry:focus-visible,
.ui-pl__btn:focus-visible {
  outline: 2px solid var(--ui-pl-focus);
  outline-offset: 2px;
}
.ui-pl__rail {
  position: absolute;
  top: 35px;
  bottom: -5px;
  left: calc(var(--ui-pl-inset) + 10.5px);
  width: 1px;
  overflow: hidden;
  background: var(--ui-pl-line);
  opacity: 0;
  pointer-events: none;
  transition: opacity 300ms ease;
}
.ui-pl:not([data-status="draft"]) .ui-pl__rail {
  opacity: 1;
  transition-delay: 240ms;
}
.ui-pl__rail::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--ui-pl-rail);
  transform: scaleY(0);
  transform-origin: top;
  transition: transform 560ms var(--ui-pl-ease);
}
.ui-pl__step[data-step="done"] .ui-pl__rail::after,
.ui-pl__step[data-step="skipped"] .ui-pl__rail::after {
  transform: scaleY(1);
}
.ui-pl__tail {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 420ms var(--ui-pl-ease),
    opacity 260ms ease;
}
.ui-pl:not([data-status="draft"]) .ui-pl__tail {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-pl__tail-inner {
  min-height: 0;
  overflow: hidden;
}
.ui-pl__add {
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr);
  column-gap: 12px;
  align-items: center;
  margin: 0 6px 8px;
  padding: 7px 10px 7px var(--ui-pl-inset);
  border-radius: 10px;
  cursor: text;
  transition: background-color 160ms ease;
}
.ui-pl__add:hover,
.ui-pl__add:focus-within {
  background: var(--ui-pl-hover);
}
.ui-pl__add-icon {
  display: grid;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 999px;
  outline: 1px dashed var(--ui-pl-faint);
  outline-offset: -1px;
  color: var(--ui-pl-muted);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
}
.ui-pl__add-icon svg {
  width: 12px;
  height: 12px;
}
.ui-pl__add input {
  width: 100%;
  min-width: 0;
  height: 22px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ui-pl-ink);
  font: inherit;
  letter-spacing: inherit;
  outline: none;
}
.ui-pl__add input::placeholder {
  color: var(--ui-pl-muted);
  opacity: 1;
}
.ui-pl__foot {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 46px;
  padding: 0 6px 0 12px;
  font-size: 12.5px;
  color: var(--ui-pl-muted);
  animation: ui-pl-fade 320ms var(--ui-pl-ease) both;
}
.ui-pl__hint {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-pl-muted);
  font-size: 12px;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-pl__actions {
  display: flex;
  flex: none;
  gap: 8px;
  margin-left: auto;
}
.ui-pl__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 32px;
  padding: 0 13px;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    opacity 160ms ease,
    transform 160ms var(--ui-pl-ease);
}
.ui-pl__btn:active {
  transform: scale(0.97);
}
.ui-pl__btn--primary {
  padding-right: 11px;
  background: var(--ui-pl-ink);
  color: var(--ui-pl-on-ink);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.ui-pl__btn--primary:hover {
  opacity: 0.88;
}
.ui-pl__btn--primary:disabled {
  opacity: 0.4;
  cursor: default;
  transform: none;
}
.ui-pl__btn--primary svg {
  width: 12px;
  height: 12px;
  fill: currentColor;
}
.ui-pl__btn--quiet {
  padding: 0 11px;
  color: var(--ui-pl-text);
}
.ui-pl__btn--quiet:hover {
  background: var(--ui-pl-quiet-hover);
  color: var(--ui-pl-ink);
}
.ui-pl__btn--quiet svg {
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-pl__status {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  color: var(--ui-pl-ink);
}
.ui-pl__foot[data-phase="failed"] .ui-pl__status {
  color: var(--ui-pl-red);
}
.ui-pl__status-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-pl__elapsed {
  margin-left: auto;
  padding-right: 6px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
@media (hover: none) {
  .ui-pl__grip,
  .ui-pl__remove {
    opacity: 1;
  }
}
@container (max-width: 400px) {
  .ui-pl__hint {
    display: none;
  }
}
@container (max-width: 340px) {
  .ui-pl__head {
    padding: 14px 14px 8px;
  }
  .ui-pl__list {
    padding-inline: 4px;
  }
  .ui-pl__step,
  .ui-pl__add {
    column-gap: 10px;
    padding-right: 8px;
  }
  .ui-pl__add {
    margin-inline: 4px;
  }
  .ui-pl__foot {
    padding-left: 10px;
  }
  .ui-pl__btn {
    padding: 0 11px;
  }
}
@keyframes ui-pl-fade {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pl-enter {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pl-pop {
  from {
    opacity: 0;
    transform: scale(0.5);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pl-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-pl-ray {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0.18;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pl *,
  .ui-pl *::before,
  .ui-pl *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
  .ui-pl__spinner line {
    opacity: 0.6;
  }
  .ui-pl__draw {
    stroke-dashoffset: 0;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pl {
  --ui-pl-tray: #111113;
  --ui-pl-card: #19191b;
  --ui-pl-ink: #ededed;
  --ui-pl-text: #a1a1a1;
  --ui-pl-muted: #8b8b92;
  --ui-pl-faint: #5c5c63;
  --ui-pl-line: #2a2a2e;
  --ui-pl-raise: #1f1f22;
  --ui-pl-hover: #1f1f22;
  --ui-pl-quiet-hover: #222225;
  --ui-pl-press: rgba(255, 255, 255, 0.07);
  --ui-pl-chip: #232326;
  --ui-pl-chip-text: #b4b4b4;
  --ui-pl-marker: #26262a;
  --ui-pl-rail: #4a4a50;
  --ui-pl-on-ink: #19191b;
  --ui-pl-red: #f2786b;
  --ui-pl-red-bg: rgba(242, 120, 107, 0.08);
  --ui-pl-red-ring: rgba(242, 120, 107, 0.4);
  --ui-pl-focus: rgba(77, 141, 255, 0.8);
  --ui-pl-lift:
    0 1px 2px rgba(0, 0, 0, 0.4), 0 14px 32px -10px rgba(0, 0, 0, 0.7);
}
`;export{n as default};
