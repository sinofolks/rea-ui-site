const n=`@property --ui-agqc-ymax {
  syntax: "<number>";
  inherits: true;
  initial-value: 10;
}
.ui-agqc {
  --ui-agqc-card: #ffffff;
  --ui-agqc-strong: #000000;
  --ui-agqc-ink: rgba(0, 0, 0, 0.88);
  --ui-agqc-text: rgba(0, 0, 0, 0.65);
  --ui-agqc-muted: rgba(0, 0, 0, 0.65);
  --ui-agqc-faint: rgba(0, 0, 0, 0.65);
  --ui-agqc-line: rgba(0, 0, 0, 0.06);
  --ui-agqc-grid: rgba(0, 0, 0, 0.045);
  --ui-agqc-fill: rgba(0, 0, 0, 0.06);
  --ui-agqc-wash: rgba(0, 0, 0, 0.02);
  --ui-agqc-accent: #0060e2;
  --ui-agqc-depth: rgba(91, 91, 214, 0.9);
  --ui-agqc-depth-fill: rgba(91, 91, 214, 0.14);
  --ui-agqc-depth-fade: rgba(91, 91, 214, 0);
  --ui-agqc-agent-bg: rgba(0, 0, 0, 0.045);
  --ui-agqc-agent-edge: rgba(0, 0, 0, 0.1);
  --ui-agqc-agent-ink: rgba(0, 0, 0, 0.65);
  --ui-agqc-agent-sq: rgba(0, 0, 0, 0.1);
  --ui-agqc-llm-bg: rgba(91, 91, 214, 0.1);
  --ui-agqc-llm-edge: rgba(91, 91, 214, 0.3);
  --ui-agqc-llm-ink: #4a4ac2;
  --ui-agqc-llm-sq: rgba(91, 91, 214, 0.22);
  --ui-agqc-tool-bg: rgba(0, 123, 172, 0.085);
  --ui-agqc-tool-edge: rgba(0, 123, 172, 0.28);
  --ui-agqc-tool-ink: #006a94;
  --ui-agqc-tool-sq: rgba(0, 123, 172, 0.2);
  --ui-agqc-human-bg: rgba(0, 96, 226, 0.08);
  --ui-agqc-human-edge: rgba(0, 96, 226, 0.26);
  --ui-agqc-human-ink: #0055c8;
  --ui-agqc-human-sq: rgba(0, 96, 226, 0.18);
  --ui-agqc-error-bg: #f52b0018;
  --ui-agqc-error-edge: rgba(215, 36, 0, 0.34);
  --ui-agqc-error-ink: #cd2200;
  --ui-agqc-ok-bg: #00a43319;
  --ui-agqc-ok-edge: rgba(0, 140, 50, 0.3);
  --ui-agqc-ok-fg: #007a2d;
  --ui-agqc-warn: #f5a524;
  --ui-agqc-warn-bg: #ff9c0029;
  --ui-agqc-warn-soft: #ff9c0012;
  --ui-agqc-warn-edge: rgba(230, 130, 0, 0.36);
  --ui-agqc-warn-fg: #b74400;
  --ui-agqc-brand-bg: #008ff519;
  --ui-agqc-brand-fg: #006ac6;
  --ui-agqc-focus: rgba(0, 96, 226, 0.7);
  --ui-agqc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-agqc-lift:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.06),
    0 2px 6px -3px rgba(0, 0, 0, 0.08);
  --ui-agqc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-agqc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  border-radius: 12px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
  container: ui-agqc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-agqc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-agqc *,
.ui-agqc *::before,
.ui-agqc *::after {
  box-sizing: border-box;
}
:where(.ui-agqc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-agqc button:focus-visible {
  outline: 2px solid var(--ui-agqc-focus);
  outline-offset: 2px;
}
.ui-agqc :is(p, dl, dd) {
  margin: 0;
}
.ui-agqc svg {
  display: block;
  flex: none;
}
.ui-agqc__num {
  font-variant-numeric: tabular-nums;
}
.ui-agqc__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  min-height: 52px;
  padding: 12px 12px 12px 16px;
  border-bottom: 0.5px solid var(--ui-agqc-line);
}
.ui-agqc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-agqc-accent);
}
.ui-agqc__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-agqc-strong);
}
.ui-agqc__name {
  flex: 0 1000 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-agqc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agqc__pill {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  background: var(--ui-agqc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agqc-text);
  white-space: nowrap;
}
.ui-agqc__pill > svg {
  width: 11px;
  height: 11px;
}
.ui-agqc__pill:is([data-status="live"], [data-status="running"]) {
  background: var(--ui-agqc-brand-bg);
  color: var(--ui-agqc-brand-fg);
}
.ui-agqc__pill[data-status="limited"] {
  background: var(--ui-agqc-warn-bg);
  color: var(--ui-agqc-warn-fg);
}
.ui-agqc__pill[data-status="done"] {
  background: var(--ui-agqc-ok-bg);
  color: var(--ui-agqc-ok-fg);
}
.ui-agqc__pill[data-status="failed"] {
  background: var(--ui-agqc-error-bg);
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__pulse {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  animation: ui-agqc-pulse 1400ms ease-in-out infinite;
}
.ui-agqc__tools {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
  margin-left: auto;
}
.ui-agqc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 6px;
  border-radius: 6px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-agqc-strong);
  white-space: nowrap;
  transition: background-color 140ms ease;
}
.ui-agqc__btn > svg {
  width: 16px;
  height: 16px;
  color: rgba(0, 0, 0, 0.65);
}
.ui-agqc__btn:hover {
  background: rgba(0, 0, 0, 0.02);
}
.ui-agqc__btn[aria-pressed="true"] {
  color: var(--ui-agqc-brand-fg);
}
.ui-agqc__btn[aria-pressed="true"] > svg {
  color: var(--ui-agqc-brand-fg);
}
.ui-agqc__btn[data-kind="danger"],
.ui-agqc__btn[data-kind="danger"] > svg {
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__stepper {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 2px 0 10px;
  border-radius: 6px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
}
.ui-agqc__stepper button {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 4px;
  color: rgba(0, 0, 0, 0.65);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-agqc__stepper button:hover:not(:disabled) {
  background: var(--ui-agqc-fill);
  color: var(--ui-agqc-ink);
}
.ui-agqc__stepper button:disabled {
  opacity: 0.35;
  cursor: default;
}
.ui-agqc__stepper-value {
  min-width: 18px;
  font-weight: 500;
  color: var(--ui-agqc-strong);
  text-align: center;
  font-variant-numeric: tabular-nums;
}
.ui-agqc__card {
  position: relative;
}
.ui-agqc__stats {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  padding: 12px 0;
  border-bottom: 0.5px solid var(--ui-agqc-line);
}
.ui-agqc__stat {
  display: grid;
  gap: 2px;
  min-width: 0;
  padding: 0 16px;
}
.ui-agqc__stat:first-child {
  padding-left: 22px;
}
.ui-agqc__stat:last-child {
  padding-right: 10px;
}
.ui-agqc__stat + .ui-agqc__stat {
  border-left: 0.5px solid var(--ui-agqc-line);
}
.ui-agqc__stat dt {
  overflow: hidden;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-agqc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agqc__stat dd {
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-agqc-ink);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  transition: color 240ms ease;
}
.ui-agqc__of {
  margin-left: 1px;
  font-size: 13px;
  color: var(--ui-agqc-muted);
}
.ui-agqc__stat[data-kind="warn"] dd {
  color: var(--ui-agqc-warn-fg);
}
.ui-agqc__stat[data-kind="failed"] dd {
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__flow {
  position: relative;
  border-bottom: 0.5px solid var(--ui-agqc-line);
  transition: height 360ms var(--ui-agqc-ease);
}
.ui-agqc__flow > *,
.ui-agqc__jobs > * {
  position: absolute;
  top: 0;
  left: 0;
}
.ui-agqc__col-head {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-agqc-muted);
  white-space: nowrap;
}
.ui-agqc__col-head > b {
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0;
  color: var(--ui-agqc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__col-head > .ui-agqc__col-more {
  margin-left: auto;
  letter-spacing: 0.3px;
}
.ui-agqc__well {
  border-radius: 6px;
  background: var(--ui-agqc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-agqc-line);
}
.ui-agqc__empty {
  display: grid;
  place-items: center;
  color: var(--ui-agqc-faint);
  animation: ui-agqc-calm 300ms var(--ui-agqc-ease) both;
}
.ui-agqc__well {
  transition: opacity 300ms var(--ui-agqc-ease);
}
.ui-agqc__well[data-empty] {
  opacity: 0;
}
@keyframes ui-agqc-calm {
  from {
    opacity: 0;
  }
}
.ui-agqc__more {
  display: grid;
  place-items: center;
  border-radius: 3px;
  background: var(--ui-agqc-fill);
  font-size: 10px;
  font-weight: 500;
  line-height: 12px;
  color: var(--ui-agqc-text);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__slot {
  border-radius: 8px;
  background: var(--ui-agqc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-agqc-line);
  transition:
    translate 560ms var(--ui-agqc-ease),
    width 560ms var(--ui-agqc-ease),
    background-color 300ms ease,
    box-shadow 300ms ease;
  animation: ui-agqc-slot 420ms var(--ui-agqc-ease) both;
}
.ui-agqc__who {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 8px;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agqc__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 5px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-agqc-text);
}
.ui-agqc__logo > svg {
  width: 14px;
  height: 14px;
}
.ui-agqc__who-text {
  display: grid;
  min-width: 0;
}
.ui-agqc__who-name {
  overflow: hidden;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agqc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agqc__rail {
  position: absolute;
  display: flex;
  align-items: center;
  padding-left: 10px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-agqc-line);
  background-image: repeating-linear-gradient(
    -45deg,
    transparent 0 6px,
    rgba(0, 0, 0, 0.022) 6px 6.5px
  );
  font-size: 12px;
  color: var(--ui-agqc-faint);
}
.ui-agqc__bin {
  z-index: 1;
  padding: 12px;
  border-radius: 8px;
  background: var(--ui-agqc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-agqc-line);
}
.ui-agqc__bin-icon {
  position: absolute;
  top: 12px;
  left: 12px;
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 5px;
}
.ui-agqc__bin[data-kind="done"] .ui-agqc__bin-icon {
  background: var(--ui-agqc-ok-bg);
  color: var(--ui-agqc-ok-fg);
}
.ui-agqc__bin[data-kind="failed"] .ui-agqc__bin-icon {
  background: var(--ui-agqc-error-bg);
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__bin-label {
  position: absolute;
  top: 14px;
  left: 40px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-agqc-muted);
}
.ui-agqc__bin-count {
  position: absolute;
  left: 12px;
  bottom: 10px;
  font-size: 20px;
  font-weight: 500;
  line-height: 28px;
  letter-spacing: -0.2px;
  color: var(--ui-agqc-strong);
}
.ui-agqc__bin[data-kind="failed"] .ui-agqc__bin-count {
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__bin-hit {
  position: absolute;
  top: 12px;
  left: 12px;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  opacity: 0;
  pointer-events: none;
  animation: ui-agqc-hit 700ms ease-out 380ms;
}
.ui-agqc__bin[data-kind="done"] .ui-agqc__bin-hit {
  box-shadow: 0 0 0 1px var(--ui-agqc-ok-fg);
}
.ui-agqc__bin[data-kind="failed"] .ui-agqc__bin-hit {
  box-shadow: 0 0 0 1px var(--ui-agqc-error-ink);
}
.ui-agqc__flow[data-narrow] .ui-agqc__who-text {
  display: none;
}
.ui-agqc__flow[data-narrow] .ui-agqc__bin {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 10px;
}
.ui-agqc__flow[data-narrow]
  :is(.ui-agqc__bin-icon, .ui-agqc__bin-label, .ui-agqc__bin-count) {
  position: static;
}
.ui-agqc__flow[data-narrow] .ui-agqc__bin-icon {
  flex: none;
}
.ui-agqc__flow[data-narrow] .ui-agqc__bin-count {
  order: 1;
  font-size: 15px;
  line-height: 24px;
}
.ui-agqc__flow[data-narrow] .ui-agqc__bin-label {
  order: 2;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agqc__flow[data-narrow] .ui-agqc__bin-hit {
  top: 10px;
}
.ui-agqc [data-kind] {
  --k-bg: var(--ui-agqc-agent-bg);
  --k-edge: var(--ui-agqc-agent-edge);
  --k-ink: var(--ui-agqc-agent-ink);
  --k-sq: var(--ui-agqc-agent-sq);
}
.ui-agqc [data-kind="llm"] {
  --k-bg: var(--ui-agqc-llm-bg);
  --k-edge: var(--ui-agqc-llm-edge);
  --k-ink: var(--ui-agqc-llm-ink);
  --k-sq: var(--ui-agqc-llm-sq);
}
.ui-agqc [data-kind="tool"] {
  --k-bg: var(--ui-agqc-tool-bg);
  --k-edge: var(--ui-agqc-tool-edge);
  --k-ink: var(--ui-agqc-tool-ink);
  --k-sq: var(--ui-agqc-tool-sq);
}
.ui-agqc [data-kind="human"] {
  --k-bg: var(--ui-agqc-human-bg);
  --k-edge: var(--ui-agqc-human-edge);
  --k-ink: var(--ui-agqc-human-ink);
  --k-sq: var(--ui-agqc-human-sq);
}
.ui-agqc .ui-agqc__job:is([data-status="failed"], [data-flash]) {
  --k-bg: var(--ui-agqc-error-bg);
  --k-edge: var(--ui-agqc-error-edge);
  --k-ink: var(--ui-agqc-error-ink);
  --k-sq: var(--ui-agqc-error-edge);
}
.ui-agqc .ui-agqc__job[data-status="done"] {
  --k-bg: var(--ui-agqc-ok-bg);
  --k-edge: var(--ui-agqc-ok-edge);
  --k-ink: var(--ui-agqc-ok-fg);
  --k-sq: var(--ui-agqc-ok-edge);
}
.ui-agqc__jobs {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-agqc__job {
  z-index: 1;
  display: block;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-lift);
  pointer-events: auto;
  transition:
    translate 560ms var(--ui-agqc-ease),
    width 560ms var(--ui-agqc-ease),
    height 560ms var(--ui-agqc-ease),
    border-radius 560ms var(--ui-agqc-ease),
    background-color 320ms ease,
    box-shadow 320ms ease,
    opacity 240ms ease;
  animation: ui-agqc-drop 520ms var(--ui-agqc-ease) backwards;
}
.ui-agqc__job:hover,
.ui-agqc__job[data-open] {
  z-index: 2;
  box-shadow:
    0 0 0 1px var(--k-edge),
    0 2px 8px -2px rgba(0, 0, 0, 0.1);
}
.ui-agqc__job:focus-visible {
  z-index: 2;
  outline: 2px solid var(--ui-agqc-focus);
  outline-offset: 2px;
}
.ui-agqc__job[data-flash] {
  background: var(--k-bg);
  box-shadow: 0 0 0 0.5px var(--k-edge);
  animation:
    ui-agqc-drop 520ms var(--ui-agqc-ease) backwards,
    ui-agqc-shake 420ms ease;
}
.ui-agqc__job[data-shape="square"] {
  border-radius: 3px;
  background: var(--k-sq);
  box-shadow: inset 0 0 0 0.5px var(--k-edge);
}
.ui-agqc__job[data-shape="square"][data-priority="high"] {
  box-shadow: inset 0 0 0 1.5px var(--ui-agqc-warn);
}
.ui-agqc__job[data-shape="square"]:hover {
  box-shadow: inset 0 0 0 1px var(--k-ink);
}
.ui-agqc__job[data-shape="bar"] {
  box-shadow: var(--ui-agqc-shadow);
}
.ui-agqc__job[data-shape="gone"] {
  z-index: 0;
  border-radius: 3px;
  background: var(--k-sq);
  box-shadow: none;
  opacity: 0;
  pointer-events: none;
  transition:
    translate 480ms var(--ui-agqc-ease),
    width 480ms var(--ui-agqc-ease),
    height 480ms var(--ui-agqc-ease),
    border-radius 480ms ease,
    background-color 200ms ease,
    opacity 200ms ease 220ms;
}
.ui-agqc__job-in {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 0 8px 0 6px;
  white-space: nowrap;
  opacity: 1;
  transition: opacity 200ms ease 160ms;
}
.ui-agqc__job:is([data-shape="square"], [data-shape="gone"]) .ui-agqc__job-in {
  opacity: 0;
  transition: opacity 120ms ease;
}
.ui-agqc__job-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 4px;
  background: var(--k-bg);
  color: var(--k-ink);
}
.ui-agqc__job-icon[data-logo] {
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
}
.ui-agqc__job-icon > svg {
  width: 11px;
  height: 11px;
}
.ui-agqc__job-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-ink);
  text-overflow: ellipsis;
}
.ui-agqc__badge {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
}
.ui-agqc__badge[data-kind="high"] {
  width: 16px;
  padding: 0;
  justify-content: center;
  background: var(--ui-agqc-warn-bg);
  color: var(--ui-agqc-warn-fg);
}
.ui-agqc__badge[data-kind="retry"] {
  background: var(--ui-agqc-error-bg);
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__job-meta {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__job[data-status="running"] .ui-agqc__job-meta {
  color: var(--k-ink);
}
.ui-agqc__job[data-flash] :is(.ui-agqc__job-name, .ui-agqc__job-meta) {
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__fill {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 0.5px var(--k-edge);
  clip-path: inset(0 calc((1 - var(--p)) * 100%) 0 0 round 6px);
  opacity: 0;
  transition:
    clip-path 260ms linear,
    opacity 300ms var(--ui-agqc-ease),
    background-color 300ms ease,
    box-shadow 300ms ease;
}
.ui-agqc__job[data-shape="bar"] .ui-agqc__fill {
  opacity: 1;
  animation: ui-agqc-grow 560ms var(--ui-agqc-ease) backwards;
}
.ui-agqc__job[data-shape="bar"] .ui-agqc__fill::before {
  transition: opacity 300ms var(--ui-agqc-ease);
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent,
      var(--ui-agqc-card),
      transparent
    ) -60px
    0 / 60px 100% no-repeat;
  opacity: 0.7;
  animation: ui-agqc-sweep 1500ms linear infinite;
}
.ui-agqc__job[data-shape="bar"] .ui-agqc__fill::after {
  transition: opacity 300ms var(--ui-agqc-ease);
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: calc(var(--p) * 100% - 28px);
  width: 28px;
  background: linear-gradient(90deg, transparent, var(--k-edge));
  animation: ui-agqc-glow 1100ms ease-in-out infinite alternate;
}
.ui-agqc__job[data-shape="gone"] .ui-agqc__fill {
  opacity: 0;
}
.ui-agqc__pop {
  z-index: 5;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-pop);
  pointer-events: none;
  transition: translate 560ms var(--ui-agqc-ease);
  animation: ui-agqc-open 200ms var(--ui-agqc-ease) both;
}
.ui-agqc__pop[data-pinned] {
  pointer-events: auto;
}
.ui-agqc__pop-head {
  display: flex;
  align-items: center;
  min-width: 0;
}
.ui-agqc__pop-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-right: 10px;
  border-radius: 6px;
  background: var(--k-bg);
  color: var(--k-ink);
}
.ui-agqc__pop-icon[data-logo] {
  background: var(--ui-agqc-card);
  box-shadow: var(--ui-agqc-shadow);
}
.ui-agqc__pop-icon > svg {
  width: 15px;
  height: 15px;
}
.ui-agqc__pop-who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-agqc__pop-name {
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-agqc-strong);
  overflow-wrap: anywhere;
}
.ui-agqc__pop-kind {
  display: -webkit-box;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-muted);
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-agqc__pop-head .ui-agqc__pill {
  height: 18px;
  margin-left: 8px;
  padding: 0 6px;
  border-radius: 4px;
  font-size: 11px;
}
.ui-agqc__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin: -2px -4px 0 4px;
  border-radius: 6px;
  color: var(--ui-agqc-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-agqc__close:hover {
  background: var(--ui-agqc-fill);
  color: var(--ui-agqc-ink);
}
.ui-agqc__pop-stats {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 8px 12px;
  padding: 8px 10px;
  border-radius: 8px;
  background: rgba(0, 0, 0, 0.025);
  box-shadow: inset 0 0 0 0.5px var(--ui-agqc-line);
}
.ui-agqc__pop-stats dt {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-agqc-muted);
}
.ui-agqc__pop-stats dd {
  overflow: hidden;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-agqc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-agqc__pop-error {
  display: flex;
  gap: 8px;
  min-width: 0;
  overflow-wrap: anywhere;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--ui-agqc-error-bg);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-error-ink);
}
.ui-agqc__pop-error > svg {
  margin-top: 2px;
}
.ui-agqc__pop-actions {
  display: flex;
  gap: 8px;
}
.ui-agqc__pop-actions .ui-agqc__btn > svg {
  width: 12px;
  height: 12px;
}
.ui-agqc__chart {
  padding: 12px 16px 12px;
}
.ui-agqc__chart-head {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 10px;
  line-height: 16px;
  white-space: nowrap;
}
.ui-agqc__chart-title {
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-agqc-muted);
}
.ui-agqc__plot {
  position: relative;
  margin-left: var(--ui-agqc-gutter, 26px);
}
.ui-agqc__grid {
  position: absolute;
  left: -6px;
  right: 0;
  bottom: calc(var(--v) / var(--ui-agqc-ymax) * 100%);
  height: 0.5px;
  background: var(--ui-agqc-line);
}
.ui-agqc__grid[data-zero] {
  background: rgba(0, 0, 0, 0.1);
}
.ui-agqc__grid > span {
  position: absolute;
  right: calc(100% + 8px);
  top: -8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__svg {
  position: absolute;
  inset: 0;
  overflow: hidden;
}
.ui-agqc__scaled {
  transform: translateY(calc(var(--h) * 1px))
    scaleY(calc(-1 * var(--h) / var(--ui-agqc-ymax)));
}
.ui-agqc__stop[data-at="top"] {
  stop-color: var(--ui-agqc-depth-fade);
}
.ui-agqc__stop[data-at="bottom"] {
  stop-color: var(--ui-agqc-depth-fill);
}
.ui-agqc__line {
  fill: none;
  stroke: var(--ui-agqc-depth);
  stroke-width: 1.25;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
}
.ui-agqc__bp {
  stroke: var(--ui-agqc-faint);
  stroke-width: 1;
  stroke-dasharray: 3 3;
  vector-effect: non-scaling-stroke;
}
.ui-agqc__band rect {
  fill: var(--ui-agqc-warn);
  opacity: 0.07;
}
.ui-agqc__bp-label {
  position: absolute;
  right: calc(100% + 8px);
  bottom: calc(var(--v) / var(--ui-agqc-ymax) * 100% - 8px);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__dot {
  position: absolute;
  right: -3px;
  bottom: calc(var(--v) / var(--ui-agqc-ymax) * 100% - 3px);
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-agqc-depth);
  box-shadow: 0 0 0 3px var(--ui-agqc-card);
}
.ui-agqc[data-state="live"] .ui-agqc__dot::after,
.ui-agqc[data-state="limited"] .ui-agqc__dot::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: var(--ui-agqc-depth);
  animation: ui-agqc-ping 1600ms ease-out infinite;
}
.ui-agqc__axis {
  display: flex;
  justify-content: space-between;
  margin: 6px 0 0 var(--ui-agqc-gutter, 26px);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agqc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agqc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@container ui-agqc (max-width: 560px) {
  .ui-agqc__head {
    flex-wrap: wrap;
    row-gap: 10px;
    padding: 10px 12px;
  }
  .ui-agqc__name {
    display: none;
  }
  .ui-agqc__stats {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    row-gap: 10px;
    padding: 10px 0;
  }
  .ui-agqc__stat {
    padding: 0 12px;
  }
  .ui-agqc__stat:nth-child(odd) {
    padding-left: 16px;
  }
  .ui-agqc__stat:nth-child(3) {
    border-left: 0;
  }
  .ui-agqc__chart {
    padding: 12px 12px 10px;
  }
}
@container ui-agqc (max-width: 440px) {
  .ui-agqc__tools {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-agqc__stat dt {
    letter-spacing: 0.2px;
  }
}
.ui-agqc__job[data-halted] .ui-agqc__fill {
  opacity: 0.55;
}
.ui-agqc__job[data-halted] .ui-agqc__fill::before,
.ui-agqc__job[data-halted] .ui-agqc__fill::after {
  opacity: 0;
  animation-play-state: paused;
}
.ui-agqc__job[data-halted] .ui-agqc__job-meta {
  color: var(--ui-agqc-muted);
}
@keyframes ui-agqc-drop {
  from {
    opacity: 0;
    transform: translateY(-10px) scale(0.6);
  }
}
@keyframes ui-agqc-slot {
  from {
    opacity: 0;
    transform: translateX(-8px);
  }
}
@keyframes ui-agqc-grow {
  from {
    clip-path: inset(0 100% 0 0 round 6px);
  }
}
@keyframes ui-agqc-sweep {
  to {
    background-position: calc(100% + 60px) 0;
  }
}
@keyframes ui-agqc-glow {
  from {
    filter: opacity(0.45);
  }
  to {
    filter: opacity(1);
  }
}
@keyframes ui-agqc-pulse {
  50% {
    opacity: 0.35;
  }
}
@keyframes ui-agqc-pop {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
}
@keyframes ui-agqc-open {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.97);
  }
}
@keyframes ui-agqc-hit {
  0% {
    opacity: 0.45;
    transform: scale(1);
  }
  100% {
    opacity: 0;
    transform: scale(1.45);
  }
}
@keyframes ui-agqc-ping {
  0% {
    opacity: 0.5;
    transform: scale(1);
  }
  100% {
    opacity: 0;
    transform: scale(2.8);
  }
}
@keyframes ui-agqc-flow {
  0%,
  100% {
    opacity: 0.35;
  }
  40% {
    opacity: 1;
  }
}
@keyframes ui-agqc-shake {
  20% {
    transform: translateX(-3px);
  }
  40% {
    transform: translateX(3px);
  }
  60% {
    transform: translateX(-2px);
  }
  80% {
    transform: translateX(1px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-agqc *,
  .ui-agqc *::before,
  .ui-agqc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-agqc {
  --ui-agqc-card: #1c1c1f;
  --ui-agqc-strong: #ffffff;
  --ui-agqc-ink: rgba(255, 255, 255, 0.9);
  --ui-agqc-text: rgba(255, 255, 255, 0.62);
  --ui-agqc-muted: rgba(255, 255, 255, 0.45);
  --ui-agqc-faint: rgba(255, 255, 255, 0.28);
  --ui-agqc-line: rgba(255, 255, 255, 0.08);
  --ui-agqc-grid: rgba(255, 255, 255, 0.05);
  --ui-agqc-fill: rgba(255, 255, 255, 0.08);
  --ui-agqc-wash: rgba(255, 255, 255, 0.025);
  --ui-agqc-accent: #5b9aff;
  --ui-agqc-depth: rgba(150, 150, 255, 0.95);
  --ui-agqc-depth-fill: rgba(130, 130, 255, 0.22);
  --ui-agqc-depth-fade: rgba(130, 130, 255, 0);
  --ui-agqc-agent-bg: rgba(255, 255, 255, 0.07);
  --ui-agqc-agent-edge: rgba(255, 255, 255, 0.14);
  --ui-agqc-agent-ink: rgba(255, 255, 255, 0.7);
  --ui-agqc-agent-sq: rgba(255, 255, 255, 0.14);
  --ui-agqc-llm-bg: rgba(130, 130, 255, 0.16);
  --ui-agqc-llm-edge: rgba(130, 130, 255, 0.38);
  --ui-agqc-llm-ink: #b1a9ff;
  --ui-agqc-llm-sq: rgba(130, 130, 255, 0.34);
  --ui-agqc-tool-bg: rgba(0, 170, 220, 0.13);
  --ui-agqc-tool-edge: rgba(0, 170, 220, 0.34);
  --ui-agqc-tool-ink: #4ccce6;
  --ui-agqc-tool-sq: rgba(0, 170, 220, 0.3);
  --ui-agqc-human-bg: rgba(60, 140, 255, 0.14);
  --ui-agqc-human-edge: rgba(60, 140, 255, 0.36);
  --ui-agqc-human-ink: #70b8ff;
  --ui-agqc-human-sq: rgba(60, 140, 255, 0.3);
  --ui-agqc-error-bg: #ff35232b;
  --ui-agqc-error-edge: rgba(255, 90, 70, 0.4);
  --ui-agqc-error-ink: #ff977d;
  --ui-agqc-ok-bg: #00f04a1f;
  --ui-agqc-ok-edge: rgba(60, 214, 140, 0.36);
  --ui-agqc-ok-fg: #3dd68c;
  --ui-agqc-warn: #ffa057;
  --ui-agqc-warn-bg: #fb6a0025;
  --ui-agqc-warn-soft: #fb6a0012;
  --ui-agqc-warn-edge: rgba(255, 160, 87, 0.36);
  --ui-agqc-warn-fg: #ffa057;
  --ui-agqc-brand-bg: #0077ff3a;
  --ui-agqc-brand-fg: #70b8ff;
  --ui-agqc-focus: rgba(77, 141, 255, 0.8);
  --ui-agqc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-agqc-lift:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 1px 2px 0 rgba(0, 0, 0, 0.4),
    0 2px 6px -3px rgba(0, 0, 0, 0.5);
  --ui-agqc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"])
  .ui-agqc
  :is(.ui-agqc__btn, .ui-agqc__stepper button)
  > svg,
:where(.dark, [data-theme="dark"]) .ui-agqc__stepper button {
  color: rgba(255, 255, 255, 0.55);
}
:where(.dark, [data-theme="dark"]) .ui-agqc__btn:hover {
  background: rgba(255, 255, 255, 0.03);
}
:where(.dark, [data-theme="dark"]) .ui-agqc__grid[data-zero] {
  background: rgba(255, 255, 255, 0.12);
}
:where(.dark, [data-theme="dark"]) .ui-agqc__pop-stats {
  background: rgba(255, 255, 255, 0.03);
}
:where(.dark, [data-theme="dark"]) .ui-agqc__rail {
  background-image: repeating-linear-gradient(
    -45deg,
    transparent 0 6px,
    rgba(255, 255, 255, 0.025) 6px 6.5px
  );
}
`;export{n as default};
