import{r as h,j as r}from"./workbench-model-C4LJxhar.js";const cr={needs:"Nothing needs you",failed:"Nothing failed",done:"Nothing done yet"},sr=[{kind:"needs",label:"Needs you"},{kind:"failed",label:"Failed"},{kind:"done",label:"Done"}],$=1e3,k=100,A=120,q=.022;function j(o){return o instanceof Date?o.getTime():typeof o=="number"?o:typeof o=="string"?new Date(o).getTime():o===null?0:NaN}function dr(o,u){const s=Math.max(0,Math.round((u-o)/6e4)),t=Math.floor(s/60);return t?`${t}h ${s%60?`${s%60}m`:""}`.trim():`${s}m`}function Y(o){return o.kind==="failed"?"Retry":o.action??"Approve"}function H(o){return o.kind==="failed"?"Fixed":o.doneLabel??"Done"}function ur(o){const u=o.map(({event:e,position:l})=>({position:l,weight:e.kind==="done"?.7+Math.log10((e.count??1)+1)*.45:1.05}));function s(e){return u.reduce((l,m)=>l+m.weight*Math.exp(-((e-m.position)**2)/(2*q*q)),0)+.04}const t=Array.from({length:A+1},(e,l)=>s(l/A)),v=Math.max(...t,.2),i=e=>98-e/v*84,f=t.map((e,l)=>[l/A*$,i(e)]);let n=`M ${f[0][0]} ${f[0][1]}`;for(let e=0;e<f.length-1;e++){const l=f[Math.max(0,e-1)],[m,c]=f[e],[w,g]=f[e+1],_=f[Math.min(f.length-1,e+2)];n+=` C ${m+(w-l[0])/6} ${c+(g-l[1])/6}, ${w-(_[0]-m)/6} ${g-(_[1]-c)/6}, ${w} ${g}`}return{line:n,area:`${n} L ${$} ${k} L 0 ${k} Z`,yAt:e=>i(s(e))/k}}function pr({events:o,since:u,until:s,replay:t=1800,locale:v,onAction:i,onUndo:f,onRedo:n,onHover:e},l){const m=`${l}${h.useId().replace(/[^a-zA-Z0-9_-]/g,"")}`,c=j(u),[w]=h.useState(()=>Date.now()),g=s===void 0?w:j(s),_=Math.max(1,g-c),M=h.useMemo(()=>new Intl.DateTimeFormat(v,{hour:"numeric",minute:"2-digit"}),[v]),p=h.useMemo(()=>o.filter(a=>Number.isFinite(j(a.at))).map(a=>({event:a,position:Math.min(1,Math.max(0,(j(a.at)-c)/_))})).sort((a,d)=>a.position-d.position),[o,c,_]),y=h.useMemo(()=>ur(p),[p]),[S,E]=h.useState(t>0?0:1);h.useEffect(()=>{if(t<=0||window.matchMedia("(prefers-reduced-motion: reduce)").matches){E(1);return}let a=0;const d=performance.now();function x(F){const z=Math.min(1,Math.max(0,(F-d)/t));E(1-(1-z)**3),z<1&&(a=requestAnimationFrame(x))}a=requestAnimationFrame(x);const b=window.setTimeout(()=>E(1),t+150);return()=>{cancelAnimationFrame(a),window.clearTimeout(b)}},[t]);const[Z,G]=h.useState({}),[N,T]=h.useState(null),I=h.useRef(e);I.current=e,h.useEffect(()=>{var a;(a=I.current)==null||a.call(I,N?o.find(d=>d.id===N)??null:null)},[N]);const[K,D]=h.useState(null);function R(a){return Z[String(a)]??"open"}function P(a,d){G(x=>({...x,[String(a)]:d}))}const O=h.useRef(null),L=h.useRef(null),[J,W]=h.useState("");function C(a,d,x,b){L.current={id:a.id,target:x},P(a.id,d),W(b)}h.useEffect(()=>{const a=L.current,d=O.current;if(!a||!d)return;const x=d.querySelector(`[data-card-id="${CSS.escape(String(a.id))}"] [data-focus="${a.target}"]`);if(!x)return;L.current=null;const b=document.activeElement;(!b||b===document.body||d.contains(b))&&x.focus()});function Q(a,d){if(d==="review"){i==null||i(a,"review");return}const x=i==null?void 0:i(a,"primary");x&&typeof x.then=="function"?(L.current=null,P(a.id,"working"),W(`${a.kind==="failed"?"Retrying":"Working on"}: ${a.title}`),x.then(()=>C(a,"resolved","undo",`${H(a)}: ${a.title}`),()=>C(a,"open","main",`Didn't work: ${a.title}`))):C(a,"resolved","undo",`${H(a)}: ${a.title}`)}function rr(a){C(a,a.kind==="done"?"undone":"open",a.kind==="done"?"redo":"main",`Undone: ${a.title}`),f==null||f(a)}function ar(a){C(a,"open","undo",`Redone: ${a.title}`),n==null||n(a)}function B(a){return a<=S+1e-4}const U=p.filter(a=>B(a.position)),V=a=>U.filter(({event:d})=>d.kind===a&&R(d.id)!=="resolved").length,ir={done:U.filter(({event:a})=>a.kind==="done"&&R(a.id)!=="undone"||R(a.id)==="resolved").length,needs:V("needs"),failed:V("failed")},er=N?p.find(a=>a.event.id===N):void 0,tr=h.useMemo(()=>{const a=[],d=new Date(c);for(d.setMinutes(0,0,0),d.setHours(d.getHours()+1);d.getTime()<g;d.setHours(d.getHours()+1))a.push((d.getTime()-c)/_);return a},[c,g,_]);function nr(a){const d=a.currentTarget.getBoundingClientRect(),x=Math.min(1,Math.max(0,(a.clientX-d.left)/d.width)),b=p.reduce((F,z)=>Math.abs(z.position-x)<.025&&(!F||Math.abs(z.position-x)<Math.abs(F.position-x))?z:F,null);D(b?b.position:x),T(b?b.event.id:null)}function or(){D(null),T(null)}return{id:m,start:c,end:g,timeFormat:M,timeline:p,curve:y,progress:S,hoveredId:N,setHoveredId:T,cursor:K,stateOf:R,rootRef:O,announcement:J,act:Q,undo:rr,redo:ar,isVisible:B,counts:ir,hoveredEvent:er,hourTicks:tr,handleChartPointer:nr,clearChartHover:or}}function X({kind:o,prefix:u}){return r.jsxs("svg",{className:`${u}__kind`,"data-kind":o,viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.4",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:[o==="needs"&&r.jsxs(r.Fragment,{children:[r.jsx("circle",{cx:"8",cy:"5.25",r:"2.5"}),r.jsx("path",{d:"M3.25 13.25c.6-2.35 2.45-3.75 4.75-3.75s4.15 1.4 4.75 3.75"})]}),o==="failed"&&r.jsxs(r.Fragment,{children:[r.jsx("path",{d:"M7.13 2.75a1 1 0 0 1 1.74 0l5.2 9.25a1 1 0 0 1-.87 1.5H2.8a1 1 0 0 1-.87-1.5z"}),r.jsx("path",{d:"M8 6.5v2.75M8 11.25v.01"})]}),o==="done"&&r.jsxs(r.Fragment,{children:[r.jsx("circle",{cx:"8",cy:"8",r:"5.75"}),r.jsx("path",{d:"m5.6 8.2 1.6 1.6 3.2-3.4"})]})]})}function lr(){return r.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:r.jsx("path",{d:"m4 8.25 2.75 2.75L12 5.5"})})}function fr({recap:o,prefix:u}){const{id:s,curve:t,progress:v,cursor:i,timeline:f,stateOf:n,hoveredId:e,setHoveredId:l,isVisible:m,hoveredEvent:c,timeFormat:w,hourTicks:g,handleChartPointer:_,clearChartHover:M}=o;return r.jsxs("div",{className:`${u}__chart`,"aria-hidden":"true",onPointerMove:_,onPointerLeave:M,children:[r.jsxs("svg",{viewBox:`0 0 ${$} ${k}`,preserveAspectRatio:"none",children:[r.jsxs("defs",{children:[r.jsxs("linearGradient",{id:`${s}-fade`,x1:"0",y1:"0",x2:"0",y2:"1",children:[r.jsx("stop",{offset:"0",stopColor:`var(--${u}-area)`,stopOpacity:"1"}),r.jsx("stop",{offset:"1",stopColor:`var(--${u}-area)`,stopOpacity:"0"})]}),r.jsx("clipPath",{id:`${s}-clip`,children:r.jsx("rect",{x:"0",y:"0",width:Math.max(0,v*$),height:k})})]}),r.jsxs("g",{className:`${u}__grid`,children:[[.25,.5,.75].map(p=>r.jsx("line",{x1:"0",x2:$,y1:p*k,y2:p*k,vectorEffect:"non-scaling-stroke"},p)),g.map(p=>r.jsx("line",{x1:p*$,x2:p*$,y1:"0",y2:k,vectorEffect:"non-scaling-stroke"},p))]}),r.jsxs("g",{clipPath:`url(#${s}-clip)`,children:[r.jsx("path",{className:`${u}__area`,d:t.area,fill:`url(#${s}-fade)`}),r.jsx("path",{className:`${u}__line`,d:t.line,vectorEffect:"non-scaling-stroke"})]})]}),r.jsx("span",{className:`${u}__frame`}),i!==null&&r.jsx("span",{className:`${u}__cursor`,style:{left:`${i*100}%`}}),f.map(({event:p,position:y},S)=>r.jsx("span",{className:`${u}__dot`,"data-kind":n(p.id)==="resolved"?"done":p.kind,"data-on":m(y)||void 0,"data-hot":e===p.id||void 0,style:{left:`${y*100}%`,top:`${t.yAt(y)*100}%`},onPointerEnter:()=>l(p.id),onPointerLeave:()=>l(null)},`${p.id}:${S}`)),c&&r.jsxs("span",{className:`${u}__tip`,style:{left:`${c.position*100}%`,top:`${t.yAt(c.position)*100}%`},"data-edge":c.position<.15?"start":c.position>.85?"end":void 0,children:[w.format(j(c.event.at))," · ",c.event.title]})]})}function xr({item:o,kind:u,recap:s,prefix:t,locale:v}){var l,m;const{event:i,position:f}=o,n=s.stateOf(i.id),e=n==="working";return r.jsxs("li",{className:`${t}__card`,"data-card-id":i.id,onFocus:()=>s.setHoveredId(i.id),onBlur:c=>{c.currentTarget.contains(c.relatedTarget)||s.setHoveredId(null)},"data-kind":u,"data-state":n,"data-seen":s.isVisible(f)||void 0,"data-hot":s.hoveredId===i.id||void 0,onPointerEnter:()=>s.setHoveredId(i.id),onPointerLeave:()=>s.setHoveredId(null),children:[r.jsxs("span",{className:`${t}__card-top`,children:[r.jsx("span",{className:`${t}__mark`,"aria-hidden":"true",children:n==="resolved"?r.jsx(lr,{}):i.logo??((m=Array.from(((l=i.title)==null?void 0:l.trim())??"")[0])==null?void 0:m.toUpperCase())}),r.jsx("span",{className:`${t}__card-title`,title:i.title,children:i.title})]}),r.jsxs("span",{className:`${t}__card-meta`,children:[r.jsx("span",{className:`${t}__detail`,title:i.detail,children:i.detail}),u==="done"&&i.count!==void 0&&r.jsx("span",{className:`${t}__tag`,title:i.count>=1e4?i.count.toLocaleString(v):void 0,children:new Intl.NumberFormat(v,i.count>=1e4?{notation:"compact",maximumFractionDigits:1}:{}).format(i.count)}),r.jsx("time",{className:`${t}__time`,dateTime:new Date(j(i.at)).toISOString(),children:s.timeFormat.format(j(i.at))})]}),u==="done"?r.jsxs("span",{className:`${t}__card-foot`,children:[r.jsx("span",{className:`${t}__status`,children:r.jsx("span",{className:`${t}__state`,"data-off":n==="undone"||void 0,children:n==="undone"?"Undone":"Done"})}),r.jsx("button",{type:"button",className:`${t}__btn`,"data-focus":n==="undone"?"redo":"undo","aria-label":`${n==="undone"?"Redo":"Undo"}: ${i.title}`,onClick:()=>n==="undone"?s.redo(i):s.undo(i),children:n==="undone"?"Redo":"Undo"})]}):r.jsx("span",{className:`${t}__card-foot`,children:n==="resolved"?r.jsxs(r.Fragment,{children:[r.jsx("span",{className:`${t}__status`,children:r.jsx("span",{className:`${t}__state`,children:H(i)})}),r.jsx("button",{type:"button",className:`${t}__btn`,"data-focus":"undo","aria-label":`Undo: ${i.title}`,onClick:()=>s.undo(i),children:"Undo"})]}):r.jsxs(r.Fragment,{children:[r.jsx("span",{className:`${t}__status`,"data-working":e||void 0,children:e?u==="failed"?"Retrying…":"Working…":""}),u==="needs"&&r.jsx("button",{type:"button",className:`${t}__btn`,disabled:e,"aria-label":`Review: ${i.title}`,onClick:()=>s.act(i,"review"),children:"Review"}),r.jsxs("button",{type:"button",className:`${t}__btn ${t}__btn--main`,"data-focus":"main",disabled:e,"aria-label":`${Y(i)}: ${i.title}`,onClick:()=>s.act(i,"primary"),children:[e&&r.jsx("span",{className:`${t}__spin`,"aria-hidden":"true"}),r.jsx("span",{className:`${t}__btn-label`,children:Y(i)})]})]})})]})}const hr=`
.ui-rca {
  --ui-rca-tray: #f0f0f0;
  --ui-rca-card: #ffffff;
  --ui-rca-strong: #171717;
  --ui-rca-ink: #171717;
  --ui-rca-text: #6b6b6b;
  --ui-rca-muted: #626873;
  --ui-rca-faint: #6b6b6b;
  --ui-rca-line: #ececec;
  --ui-rca-soft: #f4f4f4;
  --ui-rca-grid: #f0f0f0;
  --ui-rca-stroke: #8a8a8a;
  --ui-rca-area: rgba(23, 23, 23, 0.06);
  --ui-rca-dot: #525252;
  --ui-rca-cursor: #d4d4d4;
  --ui-rca-needs: #2f6bff;
  --ui-rca-failed: #be3f0b;
  --ui-rca-ok: #187941;
  --ui-rca-ok-bg: #e6f6ec;
  --ui-rca-primary: #171717;
  --ui-rca-primary-hover: #2e2e2e;
  --ui-rca-primary-ink: #ffffff;
  --ui-rca-hover-ring: #dcdcdc;
  --ui-rca-tip: #171717;
  --ui-rca-tip-text: #fafafa;
  --ui-rca-card-h: 96px;
  --ui-rca-focus-ring: rgba(47, 107, 255, 0.35);
  --ui-rca-focus: rgba(0, 96, 226, 0.7);
  --ui-rca-ring: 0 0 0 1px var(--ui-rca-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-rca-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-rca-tray);
  container: ui-rca / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-rca-text);
  -webkit-font-smoothing: antialiased;
  --ui-rca-dot-needs: #e8590c;
  --ui-rca-dot-failed: var(--ui-rca-failed);
}
.ui-rca *,
.ui-rca *::before,
.ui-rca *::after {
  box-sizing: border-box;
}
:where(.ui-rca) :where(h2, h3, p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-rca) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  cursor: pointer;
}
.ui-rca button:focus-visible {
  outline: 2px solid var(--ui-rca-focus);
  outline-offset: 2px;
}
.ui-rca__panel {
  padding: 16px 16px 12px;
  border-radius: 16px;
  background: var(--ui-rca-card);
  box-shadow: var(--ui-rca-ring);
}
.ui-rca__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px 16px;
}
.ui-rca__title {
  font-size: 15px;
  font-weight: 600;
  line-height: 22px;
  color: var(--ui-rca-strong);
}
.ui-rca__since {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 2px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-rca-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rca__pill {
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-rca-soft);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rca-text);
}
.ui-rca__counts {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 14px;
  min-width: 0;
  padding-top: 3px;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
}
.ui-rca__counts li {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.ui-rca__counts b {
  font-weight: 600;
  color: var(--ui-rca-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rca__kind {
  flex: none;
  width: 15px;
  height: 15px;
  color: var(--ui-rca-muted);
}
.ui-rca__chart {
  position: relative;
  height: 96px;
  margin-top: 14px;
  cursor: crosshair;
}
.ui-rca__chart svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.ui-rca__grid line {
  stroke: var(--ui-rca-grid);
  stroke-width: 1;
}
.ui-rca__line {
  fill: none;
  stroke: var(--ui-rca-stroke);
  stroke-width: 1.5;
  stroke-linejoin: round;
}
.ui-rca__cursor {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  margin-left: -0.5px;
  background: var(--ui-rca-cursor);
  pointer-events: none;
}
.ui-rca__frame {
  position: absolute;
  inset: 0;
  border-top: 1px solid var(--ui-rca-grid);
  border-bottom: 1px solid var(--ui-rca-grid);
  pointer-events: none;
}
.ui-rca__dot {
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-rca-dot);
  box-shadow: 0 0 0 2px var(--ui-rca-card);
  transform: translate(-50%, -50%) scale(0);
  transition: transform 360ms var(--ui-rca-ease);
}
.ui-rca__dot[data-on] {
  transform: translate(-50%, -50%) scale(1);
}
@starting-style {
  .ui-rca__dot[data-on] {
    transform: translate(-50%, -50%) scale(0);
  }
}
.ui-rca__dot[data-hot] {
  transform: translate(-50%, -50%) scale(1.5);
}
.ui-rca__dot::after {
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 50%;
}
.ui-rca__dot[data-kind="needs"] {
  background: var(--ui-rca-dot-needs);
}
.ui-rca__dot[data-kind="failed"] {
  background: var(--ui-rca-dot-failed);
}
.ui-rca__tip {
  position: absolute;
  z-index: 2;
  max-width: 280px;
  overflow: hidden;
  margin-top: -12px;
  padding: 4px 9px;
  border-radius: 8px;
  background: var(--ui-rca-tip);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rca-tip-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  transform: translate(-50%, -100%);
  pointer-events: none;
  animation: ui-rca-pop 140ms ease both;
}
.ui-rca__tip[data-edge="start"] {
  transform: translate(-12px, -100%);
}
.ui-rca__tip[data-edge="end"] {
  transform: translate(calc(-100% + 12px), -100%);
}
.ui-rca__ends {
  display: flex;
  justify-content: space-between;
  margin-top: 4px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-rca-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rca__board {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 4px;
  align-items: stretch;
  margin-top: 4px;
}
.ui-rca__lane {
  min-width: 0;
}
.ui-rca__lane-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 38px;
  padding: 0 12px 0 10px;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rca-text);
}
.ui-rca__lane-head > span:first-child {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ui-rca__lane-head .ui-rca__kind {
  width: 20px;
}
.ui-rca__lane-n {
  display: grid;
  place-items: center;
  min-width: 22px;
  height: 20px;
  padding: 0 6px;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.06);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-rca-text);
  font-variant-numeric: tabular-nums;
}
.ui-rca__cards {
  display: grid;
  grid-auto-rows: var(--ui-rca-card-h);
  align-content: start;
  gap: 4px;
  min-height: calc(
    var(--ui-rca-limit) * var(--ui-rca-card-h) + (var(--ui-rca-limit) - 1) * 4px
  );
}
.ui-rca__card {
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 10px 12px 10px 10px;
  border-radius: 14px;
  background: var(--ui-rca-card);
  box-shadow: var(--ui-rca-ring);
  opacity: 0;
  filter: blur(2px);
  transform: translateY(4px);
  transition:
    opacity 320ms ease,
    filter 320ms ease,
    transform 420ms var(--ui-rca-ease),
    box-shadow 160ms ease;
}
.ui-rca__card[data-seen] {
  opacity: 1;
  filter: none;
  transform: none;
}
.ui-rca__card[data-hot] {
  box-shadow:
    0 0 0 1px var(--ui-rca-hover-ring),
    0 2px 6px rgba(0, 0, 0, 0.05);
}
.ui-rca__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 22px;
}
.ui-rca__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-rca-card);
  box-shadow: inset 0 0 0 1px var(--ui-rca-line);
  font-size: 10.5px;
  font-weight: 600;
  color: var(--ui-rca-ink);
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-rca__mark > svg {
  width: 12px;
  height: 12px;
}
.ui-rca__card[data-state="resolved"] .ui-rca__mark {
  background: var(--ui-rca-ok-bg);
  box-shadow: none;
  color: var(--ui-rca-ok);
}
.ui-rca__card-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-rca-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__card:is([data-state="resolved"], [data-state="undone"])
  .ui-rca__card-title {
  color: var(--ui-rca-muted);
}
.ui-rca__card-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 18px;
  padding-left: 28px;
}
.ui-rca__detail {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__card[data-kind="failed"][data-state="open"] .ui-rca__detail {
  color: var(--ui-rca-failed);
}
.ui-rca__tag {
  flex: none;
  padding: 0 6px;
  border-radius: 999px;
  background: var(--ui-rca-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rca-text);
  font-variant-numeric: tabular-nums;
}
.ui-rca__time {
  flex: none;
  font-size: 11.5px;
  color: var(--ui-rca-faint);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-rca__card-foot {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  height: 28px;
  margin-top: 6px;
}
.ui-rca__status {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__state {
  padding: 0 8px;
  border-radius: 999px;
  background: var(--ui-rca-ok-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ui-rca-ok);
}
.ui-rca__state[data-off] {
  background: var(--ui-rca-soft);
  color: var(--ui-rca-text);
}
.ui-rca__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-rca-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-rca-ease),
    opacity 160ms ease;
}
.ui-rca__btn:hover:not(:disabled) {
  background: var(--ui-rca-soft);
  color: var(--ui-rca-ink);
}
.ui-rca__btn--main {
  background: var(--ui-rca-primary);
  color: var(--ui-rca-primary-ink);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.ui-rca__btn--main:hover:not(:disabled) {
  background: var(--ui-rca-primary-hover);
  color: var(--ui-rca-primary-ink);
}
.ui-rca__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-rca__btn:disabled {
  opacity: 0.7;
  cursor: default;
}
.ui-rca__spin {
  width: 11px;
  height: 11px;
  border: 1.5px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ui-rca-spin 700ms linear infinite;
}
.ui-rca__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-rca__cards {
  position: relative;
}
.ui-rca__empty {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 12px;
  color: var(--ui-rca-faint);
}
.ui-rca__card {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rca__card:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-rca-focus-ring),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rca__btn {
  flex: none;
}
.ui-rca__btn--main {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 70%;
}
.ui-rca__btn-label {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rca button:focus-visible {
  outline: 2px solid var(--ui-rca-focus);
  outline-offset: 2px;
}
@keyframes ui-rca-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-rca-spin {
  to {
    transform: rotate(360deg);
  }
}
@container ui-rca (max-width: 640px) {
  .ui-rca__board {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rca *,
  .ui-rca *::before,
  .ui-rca *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rca {
  --ui-rca-tray: #141416;
  --ui-rca-card: #1f1f22;
  --ui-rca-strong: #fafafa;
  --ui-rca-ink: #ededed;
  --ui-rca-text: #a1a1aa;
  --ui-rca-muted: #8a8a93;
  --ui-rca-faint: #5a5a62;
  --ui-rca-line: #2c2c31;
  --ui-rca-soft: #2a2a2e;
  --ui-rca-grid: #2a2a2e;
  --ui-rca-stroke: #8a8a93;
  --ui-rca-area: rgba(255, 255, 255, 0.07);
  --ui-rca-dot: #d4d4d8;
  --ui-rca-cursor: #45454c;
  --ui-rca-needs: #5b9aff;
  --ui-rca-failed: #ff7a45;
  --ui-rca-ok: #4ade80;
  --ui-rca-ok-bg: rgba(74, 222, 128, 0.14);
  --ui-rca-primary: #fafafa;
  --ui-rca-primary-hover: #e4e4e7;
  --ui-rca-primary-ink: #111113;
  --ui-rca-hover-ring: #3a3a40;
  --ui-rca-focus-ring: rgba(91, 154, 255, 0.45);
  --ui-rca-focus: rgba(77, 141, 255, 0.8);
  --ui-rca-tip: #fafafa;
  --ui-rca-tip-text: #111113;
  --ui-rca-ring: 0 0 0 1px var(--ui-rca-line), 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-rca-dot-needs: #ff8b3e;
  --ui-rca-dot-failed: var(--ui-rca-failed);
}
:where(.dark, [data-theme="dark"]) .ui-rca__lane-n {
  background: rgba(255, 255, 255, 0.08);
}
`,mr=`
.ui-rcp {
  --ui-rcp-card: #ffffff;
  --ui-rcp-strong: #000000;
  --ui-rcp-ink: rgba(0, 0, 0, 0.88);
  --ui-rcp-text: rgba(0, 0, 0, 0.65);
  --ui-rcp-muted: rgba(0, 0, 0, 0.65);
  --ui-rcp-faint: rgba(0, 0, 0, 0.65);
  --ui-rcp-line: rgba(0, 0, 0, 0.06);
  --ui-rcp-lane: #f4f4f5;
  --ui-rcp-stroke: rgba(0, 0, 0, 0.42);
  --ui-rcp-area: rgba(0, 0, 0, 0.07);
  --ui-rcp-done: #a1a1aa;
  --ui-rcp-needs: #0060e2;
  --ui-rcp-failed: #bf383d;
  --ui-rcp-ok: #0f783c;
  --ui-rcp-grid: rgba(0, 0, 0, 0.045);
  --ui-rcp-hover: #fafafa;
  --ui-rcp-card-h: 90px;
  --ui-rcp-focus-ring: rgba(0, 96, 226, 0.35);
  --ui-rcp-focus: rgba(0, 96, 226, 0.7);
  --ui-rcp-cursor: rgba(0, 0, 0, 0.22);
  --ui-rcp-dot: rgba(0, 0, 0, 0.55);
  --ui-rcp-ok-bg: rgba(26, 154, 82, 0.1);
  --ui-rcp-tip: #18181b;
  --ui-rcp-tip-text: #fafafa;
  --ui-rcp-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-rcp-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 16px 16px 12px;
  border-radius: 14px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  container: ui-rcp / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rcp-text);
  -webkit-font-smoothing: antialiased;
  --ui-rcp-dot-needs: #f76b15;
  --ui-rcp-dot-failed: var(--ui-rcp-failed);
}
.ui-rcp *,
.ui-rcp *::before,
.ui-rcp *::after {
  box-sizing: border-box;
}
:where(.ui-rcp) :where(h2, h3, p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-rcp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-rcp button:focus-visible {
  outline: 2px solid var(--ui-rcp-focus);
  outline-offset: 2px;
}
.ui-rcp [data-kind="done"] {
  --k: var(--ui-rcp-done);
}
.ui-rcp [data-kind="needs"] {
  --k: var(--ui-rcp-needs);
}
.ui-rcp [data-kind="failed"] {
  --k: var(--ui-rcp-failed);
}
.ui-rcp__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px 16px;
}
.ui-rcp__title {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-rcp-strong);
}
.ui-rcp__since {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 2px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-rcp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__pill {
  padding: 0 6px;
  border-radius: 5px;
  background: rgba(0, 0, 0, 0.05);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rcp-text);
}
.ui-rcp__counts {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  min-width: 0;
  padding-top: 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
}
.ui-rcp__counts li {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.ui-rcp__counts b {
  font-weight: 500;
  color: var(--ui-rcp-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__kind {
  flex: none;
  width: 14px;
  height: 14px;
  color: var(--ui-rcp-muted);
}
.ui-rcp__chart {
  position: relative;
  height: 96px;
  margin: 14px 0 0;
  cursor: crosshair;
}
.ui-rcp__grid line {
  stroke: var(--ui-rcp-grid);
  stroke-width: 1;
}
.ui-rcp__chart svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.ui-rcp__cursor {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  margin-left: -0.5px;
  background: var(--ui-rcp-cursor);
  pointer-events: none;
}
.ui-rcp__frame {
  position: absolute;
  inset: 0;
  border-top: 1px solid var(--ui-rcp-grid);
  border-bottom: 1px solid var(--ui-rcp-grid);
  pointer-events: none;
}
.ui-rcp__line {
  fill: none;
  stroke: var(--ui-rcp-stroke);
  stroke-width: 1.5;
  stroke-linejoin: round;
}
.ui-rcp__dot {
  position: absolute;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--ui-rcp-dot);
  box-shadow: 0 0 0 1.5px var(--ui-rcp-card);
  transform: translate(-50%, -50%) scale(0);
  transition:
    transform 360ms var(--ui-rcp-ease),
    background-color 240ms ease;
}
.ui-rcp__dot[data-on] {
  transform: translate(-50%, -50%) scale(1);
}
@starting-style {
  .ui-rcp__dot[data-on] {
    transform: translate(-50%, -50%) scale(0);
  }
}
.ui-rcp__dot[data-hot] {
  transform: translate(-50%, -50%) scale(1.6);
}
.ui-rcp__dot::after {
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 50%;
}
.ui-rcp__dot[data-kind="needs"] {
  background: var(--ui-rcp-dot-needs);
}
.ui-rcp__dot[data-kind="failed"] {
  background: var(--ui-rcp-dot-failed);
}
.ui-rcp__tip {
  position: absolute;
  z-index: 2;
  max-width: 280px;
  overflow: hidden;
  margin-top: -12px;
  padding: 3px 8px;
  border-radius: 6px;
  background: var(--ui-rcp-tip);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-rcp-tip-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  transform: translate(-50%, -100%);
  pointer-events: none;
  animation: ui-rcp-pop 140ms ease both;
}
.ui-rcp__tip[data-edge="start"] {
  transform: translate(-12px, -100%);
}
.ui-rcp__tip[data-edge="end"] {
  transform: translate(calc(-100% + 12px), -100%);
}
.ui-rcp__ends {
  display: flex;
  justify-content: space-between;
  margin: 4px 0 0;
  font-size: 10.5px;
  line-height: 14px;
  color: var(--ui-rcp-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__board {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  align-items: stretch;
  margin-top: 14px;
}
.ui-rcp__lane {
  padding: 4px;
  border-radius: 14px;
  background: var(--ui-rcp-lane);
}
.ui-rcp__lane-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 32px;
  padding: 0 10px 0 9px;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rcp-muted);
}
.ui-rcp__lane-head > span:first-child {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ui-rcp__lane-head .ui-rcp__kind {
  width: 18px;
  height: 14px;
}
.ui-rcp__lane-n {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(16, 16, 24, 0.06);
  font-size: 11px;
  color: var(--ui-rcp-text);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__cards {
  display: grid;
  grid-auto-rows: var(--ui-rcp-card-h);
  align-content: start;
  gap: 4px;
  min-height: calc(
    var(--ui-rcp-limit) * var(--ui-rcp-card-h) + (var(--ui-rcp-limit) - 1) * 4px
  );
}
.ui-rcp__card {
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 9px 10px 9px 9px;
  border-radius: 10px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  opacity: 0;
  filter: blur(2px);
  transform: translateY(4px);
  transition:
    opacity 320ms ease,
    filter 320ms ease,
    transform 420ms var(--ui-rcp-ease),
    box-shadow 160ms ease,
    background-color 160ms ease;
}
.ui-rcp__card[data-seen] {
  opacity: 1;
  filter: none;
  transform: none;
}
.ui-rcp__card[data-hot] {
  background: var(--ui-rcp-hover);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rcp__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 20px;
}
.ui-rcp__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-rcp-ink);
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-rcp__mark > svg {
  width: 11px;
  height: 11px;
}
.ui-rcp__card[data-state="resolved"] .ui-rcp__mark {
  background: var(--ui-rcp-ok-bg);
  box-shadow: none;
  color: var(--ui-rcp-ok);
}
.ui-rcp__card-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-rcp-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__card:is([data-state="resolved"], [data-state="undone"])
  .ui-rcp__card-title {
  color: var(--ui-rcp-muted);
}
.ui-rcp__time {
  flex: none;
  font-size: 11px;
  color: var(--ui-rcp-faint);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-rcp__card-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 18px;
  padding-left: 26px;
}
.ui-rcp__detail {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__card[data-kind="failed"][data-state="open"] .ui-rcp__detail {
  color: var(--ui-rcp-failed);
}
.ui-rcp__tag {
  flex: none;
  padding: 0 5px;
  border-radius: 4px;
  background: rgba(0, 0, 0, 0.05);
  font-size: 10.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rcp-text);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__card-foot {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  height: 24px;
  margin-top: 6px;
}
.ui-rcp__status {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__state {
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-rcp-ok-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rcp-ok);
}
.ui-rcp__state[data-off] {
  background: rgba(0, 0, 0, 0.05);
  color: var(--ui-rcp-muted);
}
.ui-rcp__btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px !important;
  font-weight: 500;
  color: var(--ui-rcp-muted) !important;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms ease,
    opacity 160ms ease;
}
.ui-rcp__btn:hover:not(:disabled) {
  background: rgba(0, 0, 0, 0.04) !important;
  color: var(--ui-rcp-ink) !important;
}
.ui-rcp__btn--main {
  padding: 0 9px;
  background: var(--ui-rcp-card) !important;
  box-shadow: var(--ui-rcp-shadow);
  color: var(--ui-rcp-ink) !important;
}
.ui-rcp__btn--main:hover:not(:disabled) {
  background: var(--ui-rcp-card) !important;
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.12),
    0 1px 3px rgba(0, 0, 0, 0.08);
}
.ui-rcp__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-rcp__btn:disabled {
  opacity: 0.6;
  cursor: default !important;
}
.ui-rcp__spin {
  width: 11px;
  height: 11px;
  border: 1.5px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ui-rcp-spin 700ms linear infinite;
}
.ui-rcp__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-rcp__cards {
  position: relative;
}
.ui-rcp__empty {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 12px;
  color: var(--ui-rcp-faint);
}
.ui-rcp__card {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rcp__card:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-rcp-focus-ring),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rcp__btn {
  flex: none;
}
.ui-rcp__btn--main {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 70%;
}
.ui-rcp__btn-label {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rcp button:focus-visible {
  outline: 2px solid var(--ui-rcp-focus);
  outline-offset: 2px;
}
@keyframes ui-rcp-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-rcp-spin {
  to {
    transform: rotate(360deg);
  }
}
@container ui-rcp (max-width: 640px) {
  .ui-rcp__board {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rcp *,
  .ui-rcp *::before,
  .ui-rcp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rcp {
  --ui-rcp-card: #1c1c1f;
  --ui-rcp-strong: #ffffff;
  --ui-rcp-ink: rgba(255, 255, 255, 0.9);
  --ui-rcp-text: rgba(255, 255, 255, 0.62);
  --ui-rcp-muted: rgba(255, 255, 255, 0.45);
  --ui-rcp-faint: rgba(255, 255, 255, 0.28);
  --ui-rcp-line: rgba(255, 255, 255, 0.08);
  --ui-rcp-lane: #161618;
  --ui-rcp-stroke: rgba(255, 255, 255, 0.5);
  --ui-rcp-area: rgba(255, 255, 255, 0.08);
  --ui-rcp-done: #71717a;
  --ui-rcp-needs: #5b9aff;
  --ui-rcp-failed: #ff6369;
  --ui-rcp-ok: #2fb26a;
  --ui-rcp-grid: rgba(255, 255, 255, 0.05);
  --ui-rcp-hover: #222226;
  --ui-rcp-cursor: rgba(255, 255, 255, 0.28);
  --ui-rcp-focus-ring: rgba(91, 154, 255, 0.45);
  --ui-rcp-focus: rgba(77, 141, 255, 0.8);
  --ui-rcp-dot: rgba(255, 255, 255, 0.65);
  --ui-rcp-ok-bg: rgba(47, 178, 106, 0.16);
  --ui-rcp-tip: #fafafa;
  --ui-rcp-tip-text: #111113;
  --ui-rcp-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-rcp-dot-needs: #ff8b3e;
  --ui-rcp-dot-failed: var(--ui-rcp-failed);
}
:where(.dark, [data-theme="dark"]) .ui-rcp__lane-n {
  background: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-rcp__tag,
:where(.dark, [data-theme="dark"]) .ui-rcp__pill,
:where(.dark, [data-theme="dark"]) .ui-rcp__state[data-off] {
  background: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"])
  .ui-rcp__btn:not(.ui-rcp__btn--main):hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.06) !important;
}
`;function _r({clean:o=!1,...u}){const{title:s="While you were away",limit:t=3,board:v=!0,locale:i,className:f}=u,n=o?"ui-rcp":"ui-rca",e=pr(u,n),l=o?{"--ui-rcp-limit":t}:{"--ui-rca-limit":t},m=r.jsxs(r.Fragment,{children:[r.jsxs("header",{className:`${n}__head`,children:[r.jsxs("div",{children:[r.jsx("h2",{className:`${n}__title`,children:s}),r.jsxs("p",{className:`${n}__since`,children:["Since ",e.timeFormat.format(e.start),r.jsx("span",{className:`${n}__pill`,children:dr(e.start,e.end)})]})]}),r.jsx("ul",{className:`${n}__counts`,"aria-label":"Summary",children:["done","needs","failed"].map(c=>r.jsxs("li",{"data-kind":c,children:[r.jsx(X,{kind:c,prefix:n}),r.jsx("b",{children:e.counts[c]})," ",c==="needs"?"need you":c]},c))})]}),r.jsx(fr,{recap:e,prefix:n}),r.jsxs("div",{className:`${n}__ends`,"aria-hidden":"true",children:[r.jsx("span",{children:e.timeFormat.format(e.start)}),r.jsx("span",{children:e.timeFormat.format(e.end)})]})]});return r.jsxs("section",{ref:e.rootRef,className:[n,f].filter(Boolean).join(" "),style:l,"aria-label":s,children:[r.jsx("style",{href:o?"ui-agent-recap-clean":"ui-agent-recap",precedence:"default",children:o?mr:hr}),r.jsx("p",{className:`${n}__sr`,"aria-live":"polite",children:e.announcement}),o?m:r.jsx("div",{className:`${n}__panel`,children:m}),v&&r.jsx("div",{className:`${n}__board`,children:sr.map(({kind:c,label:w})=>{const g=e.timeline.filter(p=>p.event.kind===c),_=g.slice(0,t),M=g.filter(p=>!["resolved","undone"].includes(e.stateOf(p.event.id))).length;return r.jsxs("div",{className:`${n}__lane`,"data-kind":c,children:[r.jsxs("h3",{className:`${n}__lane-head`,children:[r.jsxs("span",{children:[r.jsx(X,{kind:c,prefix:n}),w]}),r.jsx("span",{className:`${n}__lane-n`,title:g.length>_.length?`Showing ${_.length} of ${g.length}`:void 0,children:M})]}),r.jsxs("ul",{className:`${n}__cards`,children:[_.length===0&&r.jsx("li",{className:`${n}__empty`,children:cr[c]}),_.map((p,y)=>r.jsx(xr,{item:p,kind:c,recap:e,prefix:n,locale:i},`${p.event.id}:${y}`))]})]},c)})})]})}export{_r as A};
