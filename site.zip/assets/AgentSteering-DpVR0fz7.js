const n=`.ui-st {
  --ui-st-tray: #f0f0f0;
  --ui-st-card: #ffffff;
  --ui-st-ink: #171717;
  --ui-st-text: #6b6b6b;
  --ui-st-muted: #626873;
  --ui-st-faint: #6b6b6b;
  --ui-st-line: #ececec;
  --ui-st-rail: #d4d4d8;
  --ui-st-hover: #e4e4e5;
  --ui-st-chip: #f5f5f5;
  --ui-st-accent: #2a5ee5;
  --ui-st-accent-bg: rgba(47, 107, 255, 0.08);
  --ui-st-amber: #8f6100;
  --ui-st-green: #167942;
  --ui-st-on-ink: #ffffff;
  --ui-st-focus: rgba(0, 96, 226, 0.7);
  --ui-st-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 460px;
  padding: 4px;
  overflow: hidden;
  border-radius: 20px;
  background: var(--ui-st-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-st-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-st *,
.ui-st *::before,
.ui-st *::after {
  box-sizing: border-box;
}
:where(.ui-st) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-st button:focus-visible {
  outline: 2px solid var(--ui-st-focus);
  outline-offset: 2px;
}
.ui-st ol,
.ui-st ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-st svg {
  display: block;
  flex: none;
}
.ui-st__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-st__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-st__head {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding: 14px 14px 12px 16px;
}
.ui-st__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-st-accent);
}
.ui-st[data-status="paused"] .ui-st__spark {
  color: var(--ui-st-amber);
}
.ui-st[data-status="done"] .ui-st__spark {
  color: var(--ui-st-green);
}
.ui-st__heading {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-st__title {
  text-align: start;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-st-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__sub {
  display: flex;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-st-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__dot {
  flex: none;
  margin: 0 6px;
  color: var(--ui-st-faint);
}
.ui-st__agent {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-st__count {
  flex: none;
  font-variant-numeric: tabular-nums;
}
.ui-st__state {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  height: 26px;
  padding: 0 10px;
  border-radius: 999px;
  background: var(--ui-st-chip);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-st-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-st__pulse {
  position: relative;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-st-accent);
}
.ui-st__pulse::after {
  content: "";
  position: absolute;
  inset: -3px;
  border-radius: 50%;
  background: var(--ui-st-accent);
  opacity: 0;
  animation: ui-st-pulse 1600ms ease-out infinite;
}
.ui-st__state[data-status="paused"] .ui-st__pulse {
  background: var(--ui-st-amber);
}
.ui-st__state[data-status="done"] .ui-st__pulse {
  background: var(--ui-st-green);
}
.ui-st__state:not([data-status="running"]) .ui-st__pulse::after {
  display: none;
}
.ui-st__icon-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--ui-st-muted);
  box-shadow: inset 0 0 0 1px var(--ui-st-line);
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-st__icon-btn:hover {
  color: var(--ui-st-ink);
  background: var(--ui-st-chip);
}
.ui-st__plan {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  padding: 10px 16px 14px !important;
  border-top: 1px solid var(--ui-st-line);
}
.ui-st__step {
  position: relative;
  padding: 6px 0;
  transition: opacity 240ms ease;
}
.ui-st__step[data-faded] {
  opacity: 0.4;
}
.ui-st__step:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 27px;
  bottom: -3px;
  left: 7.5px;
  width: 1px;
  background: var(--ui-st-rail);
}
.ui-st__step-row {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}
.ui-st__step-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-st-faint);
}
.ui-st__step-icon[data-status="done"] {
  color: var(--ui-st-ink);
  animation: ui-st-pop 360ms var(--ui-st-ease) both;
}
.ui-st__step-icon[data-status="active"] {
  color: var(--ui-st-accent);
}
.ui-st__step-icon[data-status="active"] svg {
  animation: ui-st-spin 900ms linear infinite;
}
.ui-st__step-title {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow: hidden;
  color: var(--ui-st-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__step[data-status="done"] .ui-st__step-title {
  color: var(--ui-st-text);
}
.ui-st__step[data-status="pending"] .ui-st__step-title {
  color: var(--ui-st-muted);
}
.ui-st[data-status="running"]
  .ui-st__step[data-status="active"]
  .ui-st__step-title {
  background: linear-gradient(
      90deg,
      var(--ui-st-ink) 0%,
      var(--ui-st-ink) 40%,
      var(--ui-st-faint) 50%,
      var(--ui-st-ink) 60%,
      var(--ui-st-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-st-shimmer 2200ms linear infinite;
}
.ui-st__step[data-status="active"] .ui-st__step-title {
  font-weight: 500;
}
.ui-st__step-time {
  flex: none;
  font-size: 12.5px;
  color: var(--ui-st-faint);
  font-variant-numeric: tabular-nums;
}
.ui-st__note {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 6px 0 2px 28px;
  padding: 6px 10px 6px 8px;
  border-radius: 10px;
  background: var(--ui-st-chip);
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-st-ink);
}
.ui-st__note > svg {
  margin-top: 3px;
  color: var(--ui-st-muted);
}
.ui-st__note-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-st__note-tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 3px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-st-accent);
  white-space: nowrap;
}
.ui-st__note[data-landed] {
  animation: ui-st-land 1400ms ease both;
}
.ui-st__queue {
  padding: 12px 8px 0;
}
.ui-st__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 4px 8px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-st-muted);
}
.ui-st__label span {
  display: grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-st-hover);
  color: var(--ui-st-text);
  font-variant-numeric: tabular-nums;
}
.ui-st__queued {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
}
.ui-st__chip {
  position: relative;
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 36px;
  padding: 4px 4px 4px 12px;
  border-radius: 12px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-st-ink);
}
.ui-st__chip::before {
  content: "";
  position: absolute;
  top: 9px;
  bottom: 9px;
  left: 0;
  width: 3px;
  border-radius: 0 3px 3px 0;
  background: var(--ui-st-accent);
}
.ui-st__chip-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
  font-size: 13px;
  line-height: 18px;
}
.ui-st__chip-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-st-text);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-st__chip-btn:hover {
  background: var(--ui-st-accent-bg);
  color: var(--ui-st-accent);
}
.ui-st__chip-x {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-st-faint);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-st__chip-x:hover {
  background: var(--ui-st-chip);
  color: var(--ui-st-ink);
}
.ui-st__compose {
  padding: 10px 8px 8px;
}
.ui-st__field {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  min-height: 42px;
  padding: 5px 5px 5px 14px;
  border-radius: 14px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  cursor: text;
  transition: box-shadow 160ms ease;
}
.ui-st__field:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-st-rail),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-st__field textarea {
  flex: 1;
  min-width: 0;
  height: 20px;
  margin: 6px 0;
  padding: 0;
  border: 0;
  outline: none;
  background: none;
  font: inherit;
  color: var(--ui-st-ink);
  resize: none;
}
.ui-st__field textarea::placeholder {
  color: var(--ui-st-muted);
}
.ui-st__field textarea:focus-visible {
  outline: none;
}
.ui-st__send {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 10px;
  background: var(--ui-st-ink);
  color: var(--ui-st-on-ink);
  transition:
    opacity 160ms ease,
    transform 160ms ease;
}
.ui-st__send:disabled {
  opacity: 0.16;
  cursor: default;
}
.ui-st__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-st__hint {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 14px;
  margin: 8px 6px 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-st-muted);
}
.ui-st__hint > span {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  white-space: nowrap;
}
.ui-st kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-st-card);
  box-shadow: 0 0 0 1px var(--ui-st-line);
  font: inherit;
  font-size: 10.5px;
  color: var(--ui-st-text);
}
.ui-st__compose[data-disabled] .ui-st__field {
  opacity: 0.6;
  cursor: default;
}
@keyframes ui-st-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-st-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-st-pulse {
  from {
    opacity: 0.45;
    transform: scale(0.6);
  }
  to {
    opacity: 0;
    transform: scale(1.8);
  }
}
@keyframes ui-st-shimmer {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-st-land {
  0%,
  30% {
    background-color: var(--ui-st-accent-bg);
    box-shadow: inset 0 0 0 1px var(--ui-st-accent-bg);
  }
}
@container (max-width: 380px) {
  .ui-st__head {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    column-gap: 12px;
    row-gap: 8px;
  }
  .ui-st__spark {
    grid-row: 1;
    align-self: center;
  }
  .ui-st__heading {
    grid-column: 2;
    grid-row: 1;
  }
  .ui-st__state {
    grid-column: 2;
    grid-row: 2;
    justify-self: start;
  }
  .ui-st__head > .ui-st__icon-btn {
    grid-column: 3;
    grid-row: 1;
  }
  .ui-st__head {
    padding-left: 14px;
  }
  .ui-st__plan {
    padding-left: 14px;
    padding-right: 14px;
  }
}
@media (pointer: coarse) {
  .ui-st__icon-btn,
  .ui-st__send {
    width: 36px;
    height: 36px;
  }
  .ui-st__chip-btn,
  .ui-st__chip-x {
    height: 32px;
  }
  .ui-st__chip-x {
    width: 32px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-st *,
  .ui-st *::before,
  .ui-st *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-st[data-status="running"]
    .ui-st__step[data-status="active"]
    .ui-st__step-title {
    background: none;
    color: var(--ui-st-ink);
  }
}
:where(.dark, [data-theme="dark"]) .ui-st {
  --ui-st-tray: #111113;
  --ui-st-card: #19191b;
  --ui-st-ink: #ededed;
  --ui-st-text: #a1a1a1;
  --ui-st-muted: #8b8b92;
  --ui-st-faint: #5c5c63;
  --ui-st-line: #2a2a2e;
  --ui-st-rail: #3a3a40;
  --ui-st-hover: #2a2a2e;
  --ui-st-chip: #232326;
  --ui-st-accent: #5b8cff;
  --ui-st-accent-bg: rgba(91, 140, 255, 0.14);
  --ui-st-amber: #f5b638;
  --ui-st-green: #3ecf8e;
  --ui-st-on-ink: #19191b;
  --ui-st-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-st__step-icon[data-status="done"] path {
  stroke: #19191b;
}
`;export{n as default};
