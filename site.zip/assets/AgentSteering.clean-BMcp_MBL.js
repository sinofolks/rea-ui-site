const n=`.ui-stc {
  --ui-stc-card: #ffffff;
  --ui-stc-strong: #000000;
  --ui-stc-ink: rgba(0, 0, 0, 0.88);
  --ui-stc-text: rgba(0, 0, 0, 0.65);
  --ui-stc-muted: rgba(0, 0, 0, 0.65);
  --ui-stc-faint: rgba(0, 0, 0, 0.65);
  --ui-stc-icon: rgba(0, 0, 0, 0.65);
  --ui-stc-line: rgba(0, 0, 0, 0.06);
  --ui-stc-rail: rgba(0, 0, 0, 0.15);
  --ui-stc-wash: rgba(0, 0, 0, 0.03);
  --ui-stc-fill: rgba(0, 0, 0, 0.06);
  --ui-stc-solid: rgba(0, 0, 0, 0.88);
  --ui-stc-on-solid: #fcfcfc;
  --ui-stc-accent: #0060e2;
  --ui-stc-accent-bg: rgba(0, 96, 226, 0.06);
  --ui-stc-amber: #8f5f00;
  --ui-stc-green: #0f783c;
  --ui-stc-focus: rgba(0, 96, 226, 0.7);
  --ui-stc-land-edge: rgba(0, 96, 226, 0.35);
  --ui-stc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-stc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 460px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-stc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-stc *,
.ui-stc *::before,
.ui-stc *::after {
  box-sizing: border-box;
}
:where(.ui-stc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-stc button:focus-visible {
  outline: 2px solid var(--ui-stc-focus);
  outline-offset: 2px;
}
.ui-stc ol,
.ui-stc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-stc svg {
  display: block;
  flex: none;
}
.ui-stc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-stc__card {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-stc-card);
  box-shadow: var(--ui-stc-shadow);
}
.ui-stc__head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 12px 12px 12px 14px;
}
.ui-stc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-stc-accent);
}
.ui-stc[data-status="paused"] .ui-stc__spark {
  color: var(--ui-stc-amber);
}
.ui-stc[data-status="done"] .ui-stc__spark {
  color: var(--ui-stc-green);
}
.ui-stc__heading {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-stc__title {
  text-align: start;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-stc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-stc__sub {
  display: flex;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-stc__dot {
  flex: none;
  margin: 0 6px;
  color: var(--ui-stc-faint);
}
.ui-stc__agent {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-stc__count {
  flex: none;
  font-variant-numeric: tabular-nums;
}
.ui-stc__state {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stc-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-stc__pulse {
  position: relative;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-stc-accent);
}
.ui-stc__pulse::after {
  content: "";
  position: absolute;
  inset: -3px;
  border-radius: 50%;
  background: var(--ui-stc-accent);
  opacity: 0;
  animation: ui-stc-pulse 1600ms ease-out infinite;
}
.ui-stc__state[data-status="paused"] .ui-stc__pulse {
  background: var(--ui-stc-amber);
}
.ui-stc__state[data-status="done"] .ui-stc__pulse {
  background: var(--ui-stc-green);
}
.ui-stc__state:not([data-status="running"]) .ui-stc__pulse::after {
  display: none;
}
.ui-stc__icon-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: var(--ui-stc-card);
  box-shadow: var(--ui-stc-shadow);
  color: var(--ui-stc-icon);
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-stc__icon-btn:hover {
  color: var(--ui-stc-ink);
  background: var(--ui-stc-wash);
}
.ui-stc__plan {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  padding: 10px 14px 12px !important;
  border-top: 0.5px solid var(--ui-stc-line);
}
.ui-stc__step {
  position: relative;
  padding: 5px 0;
  transition: opacity 240ms ease;
}
.ui-stc__step[data-faded] {
  opacity: 0.4;
}
.ui-stc__step:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 25px;
  bottom: -3px;
  left: 7.5px;
  width: 0.5px;
  background: var(--ui-stc-rail);
}
.ui-stc__step-row {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-stc__step-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-stc-faint);
}
.ui-stc__step-icon[data-status="done"] {
  color: var(--ui-stc-accent);
  animation: ui-stc-pop 360ms var(--ui-stc-ease) both;
}
.ui-stc__step-icon[data-status="active"] {
  color: var(--ui-stc-accent);
}
.ui-stc__step-icon[data-status="active"] svg {
  animation: ui-stc-spin 900ms linear infinite;
}
.ui-stc__step-title {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow: hidden;
  color: var(--ui-stc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: color 240ms ease;
}
.ui-stc__step[data-status="done"] .ui-stc__step-title {
  color: var(--ui-stc-text);
}
.ui-stc__step[data-status="pending"] .ui-stc__step-title {
  color: var(--ui-stc-muted);
}
.ui-stc[data-status="running"]
  .ui-stc__step[data-status="active"]
  .ui-stc__step-title {
  font-weight: 500;
  background: linear-gradient(
      90deg,
      var(--ui-stc-ink) 0%,
      var(--ui-stc-ink) 40%,
      var(--ui-stc-faint) 50%,
      var(--ui-stc-ink) 60%,
      var(--ui-stc-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-stc-shimmer 2200ms linear infinite;
}
.ui-stc__step[data-status="active"] .ui-stc__step-title {
  font-weight: 500;
}
.ui-stc__step-time {
  flex: none;
  font-size: 12px;
  color: var(--ui-stc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-stc__note {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 4px 0 2px 26px;
  padding: 4px 8px 4px 6px;
  border-radius: 6px;
  background: var(--ui-stc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-stc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stc-ink);
}
.ui-stc__note > svg {
  margin-top: 2px;
  color: var(--ui-stc-muted);
}
.ui-stc__note-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-stc__note-tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 3px;
  color: var(--ui-stc-accent);
  font-weight: 500;
  white-space: nowrap;
}
.ui-stc__note[data-landed] {
  animation: ui-stc-land 1400ms ease both;
}
.ui-stc__queue {
  padding: 10px 12px 2px 14px;
  border-top: 0.5px solid var(--ui-stc-line);
}
.ui-stc__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 6px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-stc-muted);
}
.ui-stc__label span {
  display: grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-stc-fill);
  color: var(--ui-stc-text);
  letter-spacing: 0;
  font-variant-numeric: tabular-nums;
}
.ui-stc__queued {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
}
.ui-stc__chip {
  position: relative;
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 32px;
  padding: 4px 4px 4px 10px;
  border-radius: 8px;
  background: var(--ui-stc-card);
  box-shadow: var(--ui-stc-shadow);
  color: var(--ui-stc-ink);
}
.ui-stc__chip::before {
  content: "";
  position: absolute;
  top: 8px;
  bottom: 8px;
  left: 0;
  width: 2px;
  border-radius: 0 2px 2px 0;
  background: var(--ui-stc-accent);
}
.ui-stc__chip-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
  font-size: 12.5px;
  line-height: 18px;
}
.ui-stc__chip-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-stc-text);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-stc__chip-btn:hover {
  background: var(--ui-stc-accent-bg);
  color: var(--ui-stc-accent);
}
.ui-stc__chip-x {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--ui-stc-faint);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-stc__chip-x:hover {
  background: var(--ui-stc-wash);
  color: var(--ui-stc-ink);
}
.ui-stc__compose {
  padding: 10px 12px 10px 14px;
  border-top: 0.5px solid var(--ui-stc-line);
}
.ui-stc__field {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  min-height: 36px;
  padding: 4px 4px 4px 10px;
  border-radius: 8px;
  background: var(--ui-stc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-stc-line);
  cursor: text;
  transition:
    box-shadow 160ms ease,
    background-color 160ms ease;
}
.ui-stc__field:focus-within {
  background: var(--ui-stc-card);
  box-shadow: inset 0 0 0 0.5px var(--ui-stc-rail);
}
.ui-stc__field textarea {
  flex: 1;
  min-width: 0;
  height: 20px;
  margin: 4px 0;
  padding: 0;
  border: 0;
  outline: none;
  background: none;
  font: inherit;
  color: var(--ui-stc-strong);
  resize: none;
}
.ui-stc__field textarea::placeholder {
  color: var(--ui-stc-muted);
}
.ui-stc__field textarea:focus-visible {
  outline: none;
}
.ui-stc__send {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: var(--ui-stc-solid);
  color: var(--ui-stc-on-solid);
  transition:
    opacity 160ms ease,
    transform 160ms ease;
}
.ui-stc__send:disabled {
  opacity: 0.18;
  cursor: default;
}
.ui-stc__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-stc__hint {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 14px;
  margin-top: 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stc-muted);
}
.ui-stc__hint > span {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  white-space: nowrap;
}
.ui-stc kbd {
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 3px;
  border-radius: 4px;
  background: var(--ui-stc-card);
  box-shadow: var(--ui-stc-shadow);
  font: inherit;
  font-size: 10px;
  color: var(--ui-stc-text);
}
.ui-stc__compose[data-disabled] .ui-stc__field {
  opacity: 0.6;
  cursor: default;
}
@keyframes ui-stc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-stc-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-stc-pulse {
  from {
    opacity: 0.45;
    transform: scale(0.6);
  }
  to {
    opacity: 0;
    transform: scale(1.8);
  }
}
@keyframes ui-stc-shimmer {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-stc-land {
  0%,
  30% {
    background-color: var(--ui-stc-accent-bg);
    box-shadow: inset 0 0 0 0.5px var(--ui-stc-land-edge);
  }
}
@container (max-width: 380px) {
  .ui-stc__head {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    column-gap: 10px;
    row-gap: 8px;
  }
  .ui-stc__spark {
    grid-row: 1;
    align-self: center;
  }
  .ui-stc__heading {
    grid-column: 2;
    grid-row: 1;
  }
  .ui-stc__state {
    grid-column: 2;
    grid-row: 2;
    justify-self: start;
  }
  .ui-stc__head > .ui-stc__icon-btn {
    grid-column: 3;
    grid-row: 1;
  }
  .ui-stc__head {
    padding-left: 12px;
  }
  .ui-stc__plan,
  .ui-stc__queue,
  .ui-stc__compose {
    padding-left: 12px;
    padding-right: 12px;
  }
}
@media (pointer: coarse) {
  .ui-stc__icon-btn,
  .ui-stc__send {
    width: 34px;
    height: 34px;
  }
  .ui-stc__chip-btn,
  .ui-stc__chip-x {
    height: 30px;
  }
  .ui-stc__chip-x {
    width: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-stc *,
  .ui-stc *::before,
  .ui-stc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-stc[data-status="running"]
    .ui-stc__step[data-status="active"]
    .ui-stc__step-title {
    background: none;
    color: var(--ui-stc-ink);
  }
}
:where(.dark, [data-theme="dark"]) .ui-stc {
  --ui-stc-card: #1c1c1f;
  --ui-stc-strong: #ffffff;
  --ui-stc-ink: rgba(255, 255, 255, 0.9);
  --ui-stc-text: rgba(255, 255, 255, 0.62);
  --ui-stc-muted: rgba(255, 255, 255, 0.45);
  --ui-stc-faint: rgba(255, 255, 255, 0.28);
  --ui-stc-icon: rgba(255, 255, 255, 0.5);
  --ui-stc-line: rgba(255, 255, 255, 0.08);
  --ui-stc-rail: rgba(255, 255, 255, 0.16);
  --ui-stc-wash: rgba(255, 255, 255, 0.04);
  --ui-stc-fill: rgba(255, 255, 255, 0.08);
  --ui-stc-solid: rgba(255, 255, 255, 0.92);
  --ui-stc-on-solid: #141416;
  --ui-stc-accent: #5b9aff;
  --ui-stc-accent-bg: rgba(91, 154, 255, 0.12);
  --ui-stc-amber: #f5b638;
  --ui-stc-green: #3ecf8e;
  --ui-stc-focus: rgba(77, 141, 255, 0.8);
  --ui-stc-land-edge: rgba(91, 154, 255, 0.45);
  --ui-stc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-stc__step-icon[data-status="done"] path {
  stroke: #1c1c1f;
}
`;export{n as default};
