const n=`.ui-atm {
  /* 1 unit of the 600 × 400 layout grid */
  --u: calc(100cqw / 600);
  --ui-atm-surface: #ffffff;
  --ui-atm-ring: rgba(10, 10, 10, 0.06);
  --ui-atm-text: #171717;
  --ui-atm-accent: #2f6bff;
  --ui-atm-caret: #171717;
  /* Same pink → violet as the Get Pro button */
  --ui-atm-halo-from: rgba(221, 6, 116, 0.18);
  --ui-atm-halo-to: rgba(94, 62, 224, 0.18);
  --ui-atm-dash: #e4e7ec; /* same gray as the lines in Outreach Branches */
  --ui-atm-face: #eef0f4;
  --ui-atm-online: #34c46a;
  --ui-atm-dot-ring: #e2f6e9;
  --ui-atm-dot-edge: rgba(52, 196, 106, 0.1);
  --ui-atm-tool-ring: #e5e5e5;
  --ui-atm-shadow:
    0 calc(10 * var(--u)) calc(24 * var(--u)) rgba(0, 0, 0, 0.07),
    0 calc(2 * var(--u)) calc(5 * var(--u)) rgba(0, 0, 0, 0.05);
  --ui-atm-ease: cubic-bezier(0.7, 0, 0.25, 1);
  --ui-atm-pop: cubic-bezier(0.34, 1.4, 0.64, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  overflow: hidden;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    sans-serif;
  -webkit-font-smoothing: antialiased;
}
.ui-atm *,
.ui-atm *::before,
.ui-atm *::after {
  box-sizing: border-box;
}

/* ---------- Dashed lines, revealed top to bottom ---------- */

.ui-atm-lines {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.ui-atm-line {
  fill: none;
  stroke: var(--ui-atm-dash);
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-dasharray: 6 7.23;
}
.ui-atm-reveal {
  fill: none;
  stroke: #fff;
  stroke-width: 8;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  transition: stroke-dashoffset 700ms var(--ui-atm-ease);
}
.ui-atm:is([data-phase="sent"], [data-phase="team"]) .ui-atm-reveal {
  stroke-dashoffset: 0;
}
.ui-atm[data-phase="reset"] .ui-atm-lines {
  opacity: 0;
  transition: opacity 500ms ease;
}

/* ---------- Prompt ---------- */

.ui-atm-halo {
  position: absolute;
  left: 50%;
  top: calc(52 * var(--u));
  width: calc(400 * var(--u));
  height: calc(68 * var(--u));
  transform: translateX(-50%) scale(0.9);
  border-radius: 999px;
  background: linear-gradient(
    90deg,
    var(--ui-atm-halo-from),
    var(--ui-atm-halo-to)
  );
  filter: blur(calc(22 * var(--u)));
  opacity: 0;
  transition:
    opacity 700ms ease,
    transform 900ms var(--ui-atm-ease);
}
.ui-atm:is([data-phase="sent"], [data-phase="team"]) .ui-atm-halo {
  opacity: 1;
  transform: translateX(-50%) scale(1);
}

.ui-atm-prompt {
  position: absolute;
  left: 50%;
  top: calc(60 * var(--u));
  display: flex;
  align-items: center;
  gap: calc(12 * var(--u));
  width: calc(380 * var(--u));
  height: calc(52 * var(--u));
  padding: 0 calc(8 * var(--u)) 0 calc(20 * var(--u));
  transform: translateX(-50%);
  border-radius: 999px;
  background: var(--ui-atm-surface);
  box-shadow:
    0 0 0 calc(1 * var(--u)) var(--ui-atm-ring),
    var(--ui-atm-shadow);
}
.ui-atm-text {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  /* A long prompt keeps its newest letters in view as it types: right-to-left overflow, left-aligned while it fits */
  direction: rtl;
  text-align: left;
  font-size: calc(15 * var(--u));
  line-height: 1.3;
  letter-spacing: -0.01em;
  white-space: nowrap;
  color: var(--ui-atm-text);
}
.ui-atm-typed {
  direction: ltr;
  unicode-bidi: isolate;
}
.ui-atm-caret {
  display: inline-block;
  width: calc(1.6 * var(--u));
  height: calc(17 * var(--u));
  margin-left: calc(2 * var(--u));
  vertical-align: calc(-3 * var(--u));
  border-radius: 1px;
  background: var(--ui-atm-caret);
  animation: ui-atm-blink 1s steps(1) infinite;
}
.ui-atm-send {
  flex: none;
  display: grid;
  place-items: center;
  width: calc(36 * var(--u));
  height: calc(36 * var(--u));
  border-radius: 50%;
  background: var(--ui-atm-accent);
  transition:
    transform 200ms var(--ui-atm-pop),
    filter 200ms ease;
}
.ui-atm-send svg {
  width: calc(18 * var(--u));
  height: calc(18 * var(--u));
  fill: none;
  stroke: #fff;
  stroke-width: 2.2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-atm[data-phase="sent"] .ui-atm-send {
  animation: ui-atm-press 380ms var(--ui-atm-ease);
}
.ui-atm[data-phase="reset"] .ui-atm-text {
  opacity: 0;
  transition: opacity 400ms ease;
}

/* ---------- Agents ---------- */

.ui-atm-agent {
  position: absolute;
  top: calc(196 * var(--u));
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: calc(14 * var(--u));
  transform: translateX(-50%);
}
.ui-atm-node,
.ui-atm-role {
  opacity: 0;
  transform: translateY(calc(10 * var(--u))) scale(0.92);
  transition:
    opacity 360ms ease,
    transform 520ms var(--ui-atm-pop);
}
.ui-atm[data-phase="team"] .ui-atm-node {
  opacity: 1;
  transform: none;
  transition-delay: calc(var(--i) * 160ms);
}
.ui-atm[data-phase="team"] .ui-atm-role {
  opacity: 1;
  transform: none;
  transition-delay: calc(var(--i) * 160ms + 120ms);
}
.ui-atm[data-phase="reset"] .ui-atm-node,
.ui-atm[data-phase="reset"] .ui-atm-role {
  transform: none;
  transition: opacity 500ms ease;
}

.ui-atm-node {
  position: relative;
  width: calc(84 * var(--u));
  height: calc(84 * var(--u));
  padding: calc(5 * var(--u));
  border-radius: 50%;
  background: var(--ui-atm-surface);
  box-shadow:
    inset 0 0 0 calc(1 * var(--u)) var(--ui-atm-ring),
    var(--ui-atm-shadow);
}
.ui-atm-face {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
  border-radius: 50%;
  background: var(--ui-atm-face);
}
.ui-atm-face img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  user-select: none;
}
.ui-atm-dot {
  position: absolute;
  right: calc(1 * var(--u));
  bottom: calc(3 * var(--u));
  width: calc(24 * var(--u));
  height: calc(24 * var(--u));
  border: calc(7 * var(--u)) solid var(--ui-atm-dot-ring);
  border-radius: 50%;
  background: var(--ui-atm-online);
  box-shadow: 0 0 0 calc(2 * var(--u)) var(--ui-atm-dot-edge);
  transform: scale(0);
  transition: transform 420ms var(--ui-atm-pop);
}
.ui-atm[data-phase="team"] .ui-atm-dot {
  transform: scale(1);
  transition-delay: calc(var(--i) * 160ms + 360ms);
}

/* Role pill: overlapping tool circles first, then the role */
.ui-atm-role {
  display: flex;
  align-items: center;
  gap: calc(10 * var(--u));
  height: calc(42 * var(--u));
  padding: 0 calc(15 * var(--u)) 0 calc(7 * var(--u));
  border-radius: 999px;
  background: var(--ui-atm-surface);
  box-shadow:
    0 0 0 calc(1 * var(--u)) var(--ui-atm-ring),
    var(--ui-atm-shadow);
  font-size: calc(12.5 * var(--u));
  font-weight: 500;
  letter-spacing: -0.01em;
  white-space: nowrap;
  color: var(--ui-atm-text);
}
.ui-atm-role:not(:has(.ui-atm-tools)) {
  padding-left: calc(15 * var(--u));
}
/* A long role ends in … inside its pill – the pills never run into each other */
.ui-atm-role {
  max-width: calc(184 * var(--u));
}
.ui-atm-role > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-atm-tools {
  display: flex;
}
.ui-atm-tool {
  display: grid;
  place-items: center;
  width: calc(26 * var(--u));
  height: calc(26 * var(--u));
  border-radius: 50%;
  background: var(--ui-atm-surface);
  box-shadow:
    0 0 0 calc(1 * var(--u)) var(--ui-atm-tool-ring),
    0 calc(1.5 * var(--u)) calc(3 * var(--u)) rgba(0, 0, 0, 0.08);
}
/* The second circle sits slightly over the first */
.ui-atm-tool + .ui-atm-tool {
  margin-left: calc(-8 * var(--u));
}
.ui-atm-tool svg {
  width: calc(14 * var(--u));
  height: calc(14 * var(--u));
}

@keyframes ui-atm-blink {
  50% {
    opacity: 0;
  }
}
@keyframes ui-atm-press {
  0% {
    transform: scale(1);
  }
  40% {
    transform: scale(0.86);
  }
  100% {
    transform: scale(1);
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-atm *,
  .ui-atm *::before {
    transition: none !important;
    animation: none !important;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-atm {
  --ui-atm-surface: #232326;
  --ui-atm-ring: rgba(255, 255, 255, 0.08);
  --ui-atm-text: #ededed;
  --ui-atm-accent: #2f6bff;
  --ui-atm-caret: #ededed;
  --ui-atm-halo-from: rgba(244, 114, 182, 0.16);
  --ui-atm-halo-to: rgba(167, 139, 250, 0.16);
  --ui-atm-dash: rgba(255, 255, 255, 0.14);
  --ui-atm-face: #2e2e33;
  --ui-atm-online: #3fd17a;
  --ui-atm-dot-ring: #24392c;
  --ui-atm-dot-edge: rgba(63, 209, 122, 0.12);
  --ui-atm-tool-ring: rgba(255, 255, 255, 0.12);
  --ui-atm-shadow:
    0 calc(10 * var(--u)) calc(24 * var(--u)) rgba(0, 0, 0, 0.4),
    0 calc(2 * var(--u)) calc(5 * var(--u)) rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-atm-tool {
  background: #f4f4f5;
}

.agent-team-demo {
  width: 100%;
}
.stage .agent-team-demo {
  width: min(100%, 560px);
}
.card__preview .agent-team-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .agent-team-demo .ui-atm {
  width: auto;
  height: 100%;
}
`;export{n as default};
