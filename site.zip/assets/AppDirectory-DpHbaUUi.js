const n=`.ui-ad {
  --ui-ad-focus: rgba(0, 96, 226, 0.7);
  --ui-ad-tray: #f0f0f0;
  --ui-ad-card: #ffffff;
  --ui-ad-line: #ececec;
  --ui-ad-ink: #171717;
  --ui-ad-text: #404040;
  --ui-ad-muted: #8f8f8f;
  --ui-ad-accent: #4fb0fe;
  --ui-ad-ok: #1e8a4f;
  --ui-ad-accent-text: #4fb0fe;
  --ui-ad-accent-ring: #cde9ff;
  --ui-ad-card-line: #e5e5e5;
  --ui-ad-shadow: rgba(0, 0, 0, 0.06);
  --ui-ad-field: #ffffff;
  --ui-ad-field-hover: #f7f7f7;
  --ui-ad-ring: #e5e5e5;
  --ui-ad-app: #ffffff;
  --ui-ad-app-hover-line: #e2e2e2;
  --ui-ad-app-hover-shadow: rgba(0, 0, 0, 0.12);
  --ui-ad-tile: #ffffff;
  --ui-ad-tile-line: #e8e8e8;
  --ui-ad-tile-filled-line: rgba(0, 0, 0, 0.06);
  --ui-ad-menu-shadow: rgba(0, 0, 0, 0.18);
  --ui-ad-menu-hover: #f5f5f5;
  --ui-ad-nav-hover: #f6f6f6;
  --ui-ad-nav-current: #f0f0f0;
  --ui-ad-count: #b5b5b5;
  --ui-ad-subtle: #a3a3a3;
  --ui-ad-underline: #d4d4d4;
  --ui-ad-spinner-track: #d4d4d4;
  --ui-ad-dashed: #dedede;
  --ui-ad-empty-line: #e2e2e2;
  --ui-ad-discover: #fcfcfc;
  --ui-ad-ok-bg: #f3faf6;
  --ui-ad-ok-ring: #d0eddc;
  --ui-ad-danger: #f04438;
  --ui-ad-danger-bg: #fff4f4;
  --ui-ad-danger-edge: #f6d5d0;
  --ui-ad-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  container-type: inline-size;
  background: var(--ui-ad-tray);
  padding: 6px;
  border-radius: 22px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-ad-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-ad *,
.ui-ad *::before,
.ui-ad *::after {
  box-sizing: border-box;
}
.ui-ad button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-ad button:focus-visible,
.ui-ad a:focus-visible {
  outline: 2px solid var(--ui-ad-focus);
  outline-offset: 2px;
}
.ui-ad__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 11px 20px 10px;
  font-size: 14px;
  line-height: 20px;
}
.ui-ad__bar-title {
  font-weight: 500;
}
.ui-ad__bar-meta {
  font-size: 13px;
  color: var(--ui-ad-muted);
  font-variant-numeric: tabular-nums;
}
.ui-ad__card {
  padding: 40px 40px 44px;
  background: var(--ui-ad-card);
  border: 1px solid var(--ui-ad-card-line);
  border-radius: 16px;
  box-shadow: 0 1px 2px var(--ui-ad-shadow);
}
.ui-ad__title {
  margin: 0;
  font-size: 26px;
  font-weight: 600;
  line-height: 32px;
  letter-spacing: -0.02em;
  overflow-wrap: anywhere;
}
.ui-ad__subtitle {
  margin: 6px 0 0;
  font-size: 15px;
  line-height: 22px;
  color: var(--ui-ad-muted);
  overflow-wrap: anywhere;
}
.ui-ad__link {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  color: var(--ui-ad-text);
  text-decoration: underline;
  text-decoration-color: var(--ui-ad-underline);
  text-underline-offset: 3px;
}
.ui-ad__link:hover {
  color: var(--ui-ad-ink);
  text-decoration-color: currentColor;
}
.ui-ad__tools {
  display: flex;
  gap: 10px;
  margin-top: 28px;
}
.ui-ad__search {
  display: flex;
  flex: 1;
  min-width: 0;
  align-items: center;
  gap: 8px;
  height: 38px;
  padding: 0 12px;
  border-radius: 11px;
  background: var(--ui-ad-field);
  box-shadow:
    0 0 0 1px var(--ui-ad-ring),
    0 1px 2px rgba(0, 0, 0, 0.03);
  color: var(--ui-ad-muted);
  transition: box-shadow 160ms ease;
}
.ui-ad__search:focus-within {
  box-shadow:
    0 0 0 1px color-mix(in srgb, var(--ui-ad-muted) 50%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.03);
}
.ui-ad__search input {
  flex: 1;
  min-width: 0;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--ui-ad-ink);
}
.ui-ad__search input::placeholder {
  color: var(--ui-ad-subtle);
}
.ui-ad__search input::-webkit-search-cancel-button {
  display: none;
}
.ui-ad__btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 38px;
  padding: 0 14px;
  border: 0;
  border-radius: 11px;
  background: var(--ui-ad-field);
  box-shadow:
    0 0 0 1px var(--ui-ad-ring),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 14px !important;
  font-weight: 500;
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-ad__btn:hover {
  background: var(--ui-ad-field-hover);
}
.ui-ad__btn[data-active] {
  color: var(--ui-ad-accent-text) !important;
  box-shadow: 0 0 0 1px var(--ui-ad-accent-ring);
}
.ui-ad__filter {
  position: relative;
  flex: none;
}
.ui-ad__menu {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  z-index: 5;
  display: grid;
  gap: 2px;
  min-width: 180px;
  padding: 4px;
  border-radius: 12px;
  background: var(--ui-ad-field);
  box-shadow:
    0 0 0 1px var(--ui-ad-ring),
    0 10px 28px -8px var(--ui-ad-menu-shadow);
  animation: ui-ad-drop 180ms var(--ui-ad-ease);
}
.ui-ad__menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 13px !important;
  text-align: left;
}
.ui-ad__menu-item:hover {
  background: var(--ui-ad-menu-hover);
}
.ui-ad__menu-item[aria-checked="true"] {
  color: var(--ui-ad-accent-text) !important;
  font-weight: 500;
}
.ui-ad__layout {
  display: grid;
  grid-template-columns: 200px minmax(0, 1fr);
  gap: 32px;
  margin-top: 28px;
}
.ui-ad__nav {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.ui-ad__nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 34px;
  padding: 0 10px;
  border: 0;
  border-radius: 10px;
  background: transparent;
  font-size: 14px !important;
  text-align: left;
  color: var(--ui-ad-text) !important;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-ad__nav-item:hover {
  background: var(--ui-ad-nav-hover);
  color: var(--ui-ad-ink) !important;
}
.ui-ad__nav-item[aria-current] {
  background: var(--ui-ad-nav-current);
  color: var(--ui-ad-ink) !important;
  font-weight: 500;
}
.ui-ad__nav-icon {
  display: grid;
  flex: none;
  color: var(--ui-ad-muted);
}
.ui-ad__nav-item[aria-current] .ui-ad__nav-icon {
  color: var(--ui-ad-ink);
}
.ui-ad__nav-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ad__nav-count {
  flex: none;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ad-count);
}
.ui-ad__heading {
  display: flex;
  align-items: baseline;
  gap: 8px;
  margin: 4px 0 14px;
  font-size: 17px;
  font-weight: 600;
  line-height: 24px;
}
.ui-ad__heading-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ad__heading span:not(.ui-ad__heading-text) {
  flex: none;
  font-variant-numeric: tabular-nums;
  font-size: 13px;
  font-weight: 400;
  color: var(--ui-ad-muted);
}
.ui-ad__grid {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 14px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ad__app {
  display: flex;
  flex-direction: column;
  padding: 16px;
  border: 1px solid var(--ui-ad-line);
  border-radius: 16px;
  background: var(--ui-ad-app);
  animation: ui-ad-in 420ms var(--ui-ad-ease) both;
  transition:
    border-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-ad__app:hover {
  border-color: var(--ui-ad-app-hover-line);
  box-shadow: 0 6px 18px -10px var(--ui-ad-app-hover-shadow);
}
.ui-ad__app-head {
  display: flex;
  align-items: center;
  gap: 12px;
}
.ui-ad__tile {
  display: grid;
  place-items: center;
  flex: none;
  width: 40px;
  height: 40px;
  border-radius: 11px;
  background: var(--ui-ad-tile);
  box-shadow: inset 0 0 0 1px var(--ui-ad-tile-line);
}
.ui-ad__tile[data-filled] {
  box-shadow: inset 0 0 0 1px var(--ui-ad-tile-filled-line);
}
.ui-ad__tile svg {
  width: 21px;
  height: 21px;
}
.ui-ad__tile-initial {
  font-size: 16px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-ad-text);
}
.ui-ad__tile[data-filled] .ui-ad__tile-initial {
  color: #fff;
}
.ui-ad__stack .ui-ad__tile-initial {
  font-size: 13px;
}
.ui-ad__app-name {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-ad__name {
  display: inline-flex;
  min-width: 0;
  align-items: center;
  gap: 5px;
  font-size: 15px;
  font-weight: 500;
  line-height: 20px;
}
.ui-ad__verified {
  flex: none;
  color: var(--ui-ad-accent);
}
.ui-ad__name-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ad__vendor {
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-ad-muted);
}
.ui-ad__desc {
  display: -webkit-box;
  flex: 1;
  margin: 10px 0 14px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  font-size: 13px;
  line-height: 19px;
  min-height: 38px;
  overflow-wrap: anywhere;
  color: var(--ui-ad-muted);
}
.ui-ad__connect {
  display: inline-flex;
  align-items: center;
  overflow: hidden;
  white-space: nowrap;
  align-self: flex-start;
  height: 30px;
  padding: 0 12px;
  border: 0;
  border-radius: 9px;
  background: var(--ui-ad-field);
  box-shadow:
    0 0 0 1px var(--ui-ad-ring),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 13px !important;
  font-weight: 500;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-ad__connect[data-smooth] {
  transition:
    width 320ms cubic-bezier(0.22, 1, 0.36, 1),
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-ad__connect-label {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
}
.ui-ad__connect:hover {
  background: var(--ui-ad-field-hover);
}
.ui-ad__connect[data-state="busy"] {
  color: var(--ui-ad-muted) !important;
  cursor: progress;
}
.ui-ad__connect[data-state="on"] {
  color: var(--ui-ad-ok) !important;
  background: var(--ui-ad-ok-bg);
  box-shadow: 0 0 0 1px var(--ui-ad-ok-ring);
}
.ui-ad__off-label {
  display: none;
}
.ui-ad__connect[data-state="on"]:is(:hover, :focus-visible, [data-armed]) {
  color: var(--ui-ad-danger) !important;
  background: var(--ui-ad-danger-bg);
  box-shadow: 0 0 0 1px var(--ui-ad-danger-edge);
}
.ui-ad__connect[data-state="on"]:is(:hover, :focus-visible, [data-armed])
  .ui-ad__on-label {
  display: none;
}
.ui-ad__connect[data-state="on"]:is(:hover, :focus-visible, [data-armed])
  .ui-ad__off-label {
  display: inline;
}
.ui-ad__spinner {
  width: 12px;
  height: 12px;
  border: 1.5px solid var(--ui-ad-spinner-track);
  border-top-color: var(--ui-ad-ink);
  border-radius: 50%;
  animation: ui-ad-spin 700ms linear infinite;
}
.ui-ad__discover {
  justify-content: space-between;
  border-style: dashed;
  border-color: var(--ui-ad-dashed);
  background: var(--ui-ad-discover);
}
.ui-ad__discover-head {
  display: flex;
  justify-content: space-between;
  gap: 12px;
}
.ui-ad__discover-head > span:first-child {
  display: grid;
}
.ui-ad__discover .ui-ad__btn {
  align-self: flex-start;
  height: 30px;
  margin-top: 18px;
  padding: 0 12px;
  font-size: 13px !important;
  border-radius: 9px;
}
.ui-ad__stack {
  display: flex;
}
.ui-ad__stack .ui-ad__tile {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  box-shadow:
    0 0 0 2px var(--ui-ad-discover),
    inset 0 0 0 1px var(--ui-ad-tile-line);
}
.ui-ad__stack .ui-ad__tile + .ui-ad__tile {
  margin-left: -10px;
}
.ui-ad__stack .ui-ad__tile svg {
  width: 17px;
  height: 17px;
}
.ui-ad__empty {
  display: grid;
  justify-items: center;
  gap: 12px;
  padding: 48px 0;
  border: 1px dashed var(--ui-ad-empty-line);
  border-radius: 16px;
  font-size: 14px;
  color: var(--ui-ad-muted);
}
.ui-ad__empty p {
  margin: 0;
}
.ui-ad__empty .ui-ad__btn {
  color: var(--ui-ad-ink);
}
@container (max-width: 820px) {
  .ui-ad__layout {
    grid-template-columns: minmax(0, 1fr);
    gap: 18px;
  }
  .ui-ad__nav {
    flex-direction: row;
    overflow-x: auto;
    scrollbar-width: none;
    margin: -4px;
    padding: 4px;
  }
  .ui-ad__nav-item {
    flex: none;
    max-width: 240px;
  }
  .ui-ad__nav-count {
    display: none;
  }
  .ui-ad__grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@container (max-width: 560px) {
  .ui-ad__card {
    padding: 24px 18px 28px;
  }
  .ui-ad__grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (pointer: coarse) {
  .ui-ad__search,
  .ui-ad__btn {
    height: 42px;
  }
  .ui-ad__search input {
    font-size: 16px;
  }
  .ui-ad__nav-item {
    height: 40px;
  }
  .ui-ad__menu-item {
    height: 42px;
  }
  .ui-ad__connect,
  .ui-ad__discover .ui-ad__btn {
    height: 38px;
  }
}
@keyframes ui-ad-in {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
}
@keyframes ui-ad-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-ad-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ad__app,
  .ui-ad__menu {
    animation: none;
  }
}
.ui-ad__morph {
  overflow: hidden;
  margin: -6px;
}
.ui-ad__main {
  padding: 6px;
}
.ui-ad__morph[data-smooth] {
  transition: height 420ms cubic-bezier(0.22, 1, 0.36, 1);
}
@media (prefers-reduced-motion: reduce) {
  .ui-ad__morph[data-smooth],
  .ui-ad__connect[data-smooth] {
    transition: none;
  }
}
.ui-ad input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-ad textarea:focus-visible,
.ui-ad [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-ad {
  --ui-ad-focus: rgba(77, 141, 255, 0.8);
  --ui-ad-tray: #161618;
  --ui-ad-card: #232326;
  --ui-ad-line: rgba(255, 255, 255, 0.08);
  --ui-ad-ink: #ededed;
  --ui-ad-text: #c4c4c4;
  --ui-ad-muted: #8f8f8f;
  --ui-ad-ok: #5fc88a;
  --ui-ad-accent-text: #4fb0fe;
  --ui-ad-accent-ring: rgba(79, 176, 254, 0.45);
  --ui-ad-card-line: rgba(255, 255, 255, 0.08);
  --ui-ad-shadow: rgba(0, 0, 0, 0.4);
  --ui-ad-field: #2a2a2d;
  --ui-ad-field-hover: #313135;
  --ui-ad-ring: rgba(255, 255, 255, 0.08);
  --ui-ad-app: #232326;
  --ui-ad-app-hover-line: rgba(255, 255, 255, 0.14);
  --ui-ad-app-hover-shadow: rgba(0, 0, 0, 0.5);
  --ui-ad-tile: #2a2a2d;
  --ui-ad-tile-line: rgba(255, 255, 255, 0.08);
  --ui-ad-tile-filled-line: rgba(255, 255, 255, 0.1);
  --ui-ad-menu-shadow: rgba(0, 0, 0, 0.5);
  --ui-ad-menu-hover: rgba(255, 255, 255, 0.06);
  --ui-ad-nav-hover: rgba(255, 255, 255, 0.06);
  --ui-ad-nav-current: #2a2a2d;
  --ui-ad-count: #6b6b70;
  --ui-ad-subtle: #6b6b70;
  --ui-ad-underline: rgba(255, 255, 255, 0.24);
  --ui-ad-spinner-track: rgba(255, 255, 255, 0.14);
  --ui-ad-dashed: rgba(255, 255, 255, 0.14);
  --ui-ad-empty-line: rgba(255, 255, 255, 0.14);
  --ui-ad-discover: #1c1c1f;
  --ui-ad-ok-bg: rgba(125, 207, 159, 0.12);
  --ui-ad-ok-ring: rgba(125, 207, 159, 0.28);
  --ui-ad-danger: #ff6b5f;
  --ui-ad-danger-bg: rgba(255, 107, 95, 0.14);
  --ui-ad-danger-edge: rgba(255, 107, 95, 0.32);
}

.apps-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.apps-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.card__preview .apps-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.apps-demo[data-fit="card"] .apps-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 24px;
}
.apps-demo__frame {
  min-width: 0;
}
`;export{n as default};
