const n=`.ui-gate {
  --ui-gate-tray: #f0f0f0;
  --ui-gate-card: #ffffff;
  --ui-gate-strong: #171717;
  --ui-gate-ink: #171717;
  --ui-gate-text: #6b6b6b;
  --ui-gate-muted: #626873;
  --ui-gate-faint: #6b6b6b;
  --ui-gate-line: #ececec;
  --ui-gate-fill: #f2f2f2;
  --ui-gate-well: #f7f7f7;
  --ui-gate-rail: #d6d6d6;
  --ui-gate-wait-bg: #fff2e0;
  --ui-gate-wait-fg: #aa4e00;
  --ui-gate-ok-bg: #e8f6ec;
  --ui-gate-ok-fg: #197832;
  --ui-gate-danger-bg: #fdecea;
  --ui-gate-danger-fg: #c2331f;
  --ui-gate-brand-bg: #eaf1ff;
  --ui-gate-brand-fg: #2a5ee5;
  --ui-gate-add-bg: #eaf7ee;
  --ui-gate-add-fg: #1f7a3a;
  --ui-gate-del-bg: #fdeeec;
  --ui-gate-del-fg: #b42318;
  --ui-gate-focus: rgba(0, 96, 226, 0.7);
  --ui-gate-solid: #171717;
  --ui-gate-on-solid: #ffffff;
  --ui-gate-shadow:
    0 0 0 1px var(--ui-gate-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-gate-float:
    0 0 0 1px var(--ui-gate-line), 0 1px 2px rgba(0, 0, 0, 0.04),
    0 10px 28px -12px rgba(0, 0, 0, 0.14);
  --ui-gate-mono:
    ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
  --ui-gate-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-gate-w: 560px;
  --ui-gate-peek: 11px;
  --ui-gate-shrink: 0.05;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  container: ui-gate / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-gate-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-gate *,
.ui-gate *::before,
.ui-gate *::after {
  box-sizing: border-box;
}
:where(.ui-gate) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-gate button:focus-visible {
  outline: 2px solid var(--ui-gate-focus);
  outline-offset: 2px;
}
.ui-gate textarea:focus-visible {
  outline: none;
}
.ui-gate :is(p, dl, dd, ol, ul, pre, h3) {
  margin: 0;
}
.ui-gate :is(ol, ul) {
  padding: 0;
  list-style: none;
}
.ui-gate svg {
  display: block;
  flex: none;
}
.ui-gate__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-gate__summary {
  width: min(100%, var(--ui-gate-w));
  margin: 0 auto 14px;
  padding: 4px;
  border-radius: 16px;
  background: var(--ui-gate-tray);
}
.ui-gate__bar {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 5px 6px 8px 8px;
}
.ui-gate__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-gate-muted);
}
.ui-gate__title {
  flex: none;
  font-weight: 500;
  color: var(--ui-gate-strong);
  white-space: nowrap;
}
.ui-gate__task {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-gate-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__pill {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 20px;
  margin-left: auto;
  padding: 0 7px;
  border-radius: 5px;
  background: var(--ui-gate-fill);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-gate-text);
  white-space: nowrap;
}
.ui-gate__pill[data-state="waiting"] {
  background: var(--ui-gate-wait-bg);
  color: var(--ui-gate-wait-fg);
}
.ui-gate__pill[data-state="running"] {
  background: var(--ui-gate-brand-bg);
  color: var(--ui-gate-brand-fg);
}
.ui-gate__pill[data-state="done"] {
  background: var(--ui-gate-ok-bg);
  color: var(--ui-gate-ok-fg);
}
.ui-gate__pill[data-state="stopped"] {
  background: var(--ui-gate-danger-bg);
  color: var(--ui-gate-danger-fg);
}
.ui-gate__pulse {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  animation: ui-gate-pulse 1400ms ease-in-out infinite;
}
.ui-gate__stats {
  display: grid;
  grid-template-columns: minmax(0, 0.8fr) minmax(0, 0.6fr) minmax(0, 2fr);
  padding: 9px 0 10px;
  border-radius: 12px;
  background: var(--ui-gate-card);
  box-shadow: var(--ui-gate-shadow);
}
.ui-gate__stat {
  display: grid;
  gap: 1px;
  min-width: 0;
  padding: 0 12px;
}
.ui-gate__stat:first-child {
  padding-left: 12px;
}
.ui-gate__stat + .ui-gate__stat {
  border-left: 1px solid var(--ui-gate-line);
}
.ui-gate__stat dt {
  overflow: hidden;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-gate-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__stat dd {
  display: flex;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-gate-ink);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-gate__run {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-gate__body {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
}
.ui-gate__stack {
  position: relative;
  display: grid;
  justify-items: center;
  gap: 8px;
  width: min(100%, var(--ui-gate-w));
  margin: 0 auto;
  outline: none;
}
.ui-gate__pager {
  display: flex;
  flex: none;
  align-items: center;
  gap: 2px;
  order: 2;
  margin: -4px -2px -4px 0;
  transition: opacity 200ms ease;
}
.ui-gate__pager[data-off] {
  opacity: 0;
}
.ui-gate__page {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--ui-gate-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-gate__page:hover {
  background: var(--ui-gate-fill);
  color: var(--ui-gate-ink);
}
.ui-gate__page-n {
  min-width: 44px;
  font-size: 12px;
  line-height: 16px;
  text-align: center;
  color: var(--ui-gate-muted);
  font-variant-numeric: tabular-nums;
}
.ui-gate__pile {
  position: relative;
  display: grid;
  align-content: start;
  width: 100%;
  min-height: calc(var(--ui-gate-floor, 0px) + var(--ui-gate-peek) * 2);
  padding-top: calc(var(--ui-gate-peek) * 2);
}
.ui-gate__back {
  position: absolute;
  top: calc(var(--ui-gate-peek) * 2);
  left: 0;
  right: 0;
  height: var(--ui-gate-front-h);
  border-radius: 16px;
  background: var(--ui-gate-tray);
  box-shadow: var(--ui-gate-shadow);
  transform: translateY(calc(var(--ui-gate-k) * var(--ui-gate-peek) * -1))
    scale(calc(1 - var(--ui-gate-k) * var(--ui-gate-shrink)));
  transform-origin: top center;
  opacity: calc(1 - var(--ui-gate-k) * 0.22);
  transition:
    transform 360ms var(--ui-gate-ease),
    opacity 300ms ease;
  z-index: calc(3 - var(--ui-gate-k));
}
.ui-gate__back:hover {
  opacity: 1;
}
.ui-gate__back[data-fresh] {
  animation: ui-gate-behind 420ms var(--ui-gate-ease) both;
}
.ui-gate__back-text {
  position: absolute;
  top: 0;
  right: 16px;
  left: 16px;
  height: var(--ui-gate-peek);
  overflow: hidden;
  font-size: 0;
}
.ui-gate__card {
  position: relative;
  z-index: 4;
  display: flex;
  flex-direction: column;
  gap: 0;
  min-width: 0;
  padding: 4px;
  border-radius: 16px;
  background: var(--ui-gate-tray);
  box-shadow: var(--ui-gate-float);
  animation: ui-gate-rise 380ms var(--ui-gate-ease) both;
}
.ui-gate__card:not(.ui-gate__card--leaving) {
  min-height: var(--ui-gate-floor, 0px);
}
.ui-gate__card > .ui-gate__actions {
  padding: 6px 2px 2px;
}
.ui-gate__card[data-fresh] {
  animation: ui-gate-in 420ms var(--ui-gate-ease) both;
}
.ui-gate__card--leaving {
  position: absolute;
  top: calc(var(--ui-gate-peek) * 2);
  right: 0;
  left: 0;
  z-index: 5;
  pointer-events: none;
  animation: ui-gate-leave 360ms var(--ui-gate-ease) both;
}
.ui-gate__card--leaving[data-decision="rejected"] {
  animation-name: ui-gate-leave-no;
}
.ui-gate__card-body {
  display: flex;
  flex: 1;
  flex-direction: column;
  gap: 10px;
  min-width: 0;
  padding: 12px;
  border-radius: 12px;
  background: var(--ui-gate-card);
  box-shadow: var(--ui-gate-shadow);
}
.ui-gate__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 4px 4px 8px 6px;
}
.ui-gate__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-gate-card);
  box-shadow: var(--ui-gate-shadow);
  font-size: 9px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-gate-text);
}
.ui-gate__avatar[data-logo] > svg {
  width: 12px;
  height: 12px;
}
.ui-gate__card-who {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-gate-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__card-agent {
  color: var(--ui-gate-text);
}
.ui-gate__badge {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  background: var(--ui-gate-fill);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-gate-text);
  white-space: nowrap;
}
.ui-gate__badge[data-status="open"] {
  background: var(--ui-gate-wait-bg);
  color: var(--ui-gate-wait-fg);
}
.ui-gate__badge:is([data-status="approved"], [data-status="edited"]) {
  background: var(--ui-gate-ok-bg);
  color: var(--ui-gate-ok-fg);
}
.ui-gate__badge[data-status="rejected"] {
  background: var(--ui-gate-danger-bg);
  color: var(--ui-gate-danger-fg);
}
.ui-gate__card-action {
  overflow-wrap: anywhere;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ui-gate-strong);
}
.ui-gate__card-why {
  margin-top: -6px;
  overflow-wrap: anywhere;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-gate-text);
}
.ui-gate__section {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
  min-width: 0;
}
.ui-gate__label {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-gate-muted);
}
.ui-gate__data,
.ui-gate__diff {
  max-height: 128px;
  overflow: auto;
  overscroll-behavior: contain;
  border-radius: 8px;
  background: var(--ui-gate-well);
  box-shadow: inset 0 0 0 1px var(--ui-gate-line);
  scrollbar-width: thin;
  outline: none;
  transition: max-height 300ms var(--ui-gate-ease);
}
.ui-gate :is(.ui-gate__data, .ui-gate__diff)[data-full] {
  max-height: 260px;
}
.ui-gate__data {
  padding: 8px 10px;
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-gate-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-gate .ui-gate__context:focus-visible {
  outline: 2px solid var(--ui-gate-focus);
  outline-offset: -2px;
}
.ui-gate :is(.ui-gate__data, .ui-gate__diff):focus-visible {
  outline: 2px solid var(--ui-gate-focus);
  outline-offset: -2px;
}
.ui-gate__data[data-mono],
.ui-gate__edit[data-mono] {
  font-family: var(--ui-gate-mono);
  font-size: 11.5px;
}
.ui-gate__diff {
  display: grid;
  gap: 8px;
  padding: 6px 0;
}
.ui-gate__file {
  display: grid;
  gap: 4px;
  min-width: 0;
}
.ui-gate__file-name {
  min-width: 0;
  overflow: hidden;
  padding: 0 10px;
  font-family: var(--ui-gate-mono);
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-gate-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__file pre {
  font-family: var(--ui-gate-mono);
  font-size: 11.5px;
  line-height: 18px;
  color: var(--ui-gate-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-gate__dl {
  display: block;
  padding: 0 10px 0 22px;
  text-indent: -14px;
}
.ui-gate__dl > span:first-child {
  display: inline-block;
  width: 14px;
  text-indent: 0;
  color: var(--ui-gate-faint);
}
.ui-gate__dl[data-type="add"] {
  background: var(--ui-gate-add-bg);
  color: var(--ui-gate-add-fg);
}
.ui-gate__dl[data-type="del"] {
  background: var(--ui-gate-del-bg);
  color: var(--ui-gate-del-fg);
}
.ui-gate__dl:not([data-type="ctx"]) > span:first-child {
  color: inherit;
}
.ui-gate__edit {
  width: 100%;
  min-height: 72px;
  padding: 8px 10px;
  border: 0;
  border-radius: 8px;
  background: var(--ui-gate-card);
  box-shadow: inset 0 0 0 1px var(--ui-gate-faint);
  font: inherit;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-gate-ink);
  resize: vertical;
  outline: none;
}
.ui-gate__edit::placeholder {
  color: var(--ui-gate-faint);
}
.ui-gate__extra {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  min-width: 0;
}
.ui-gate__fold[data-open] > .ui-gate__fold-in:not(.ui-gate__row-body) {
  padding-top: 10px;
}
.ui-gate__more {
  display: inline-flex;
  align-items: center;
  justify-self: start;
  gap: 4px;
  height: 22px;
  margin: -2px 0 -4px -6px;
  padding: 0 6px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-gate-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-gate__more:hover {
  background: var(--ui-gate-fill);
  color: var(--ui-gate-ink);
}
.ui-gate__more-chev,
.ui-gate__row-chev {
  display: grid;
  color: var(--ui-gate-faint);
  transition: transform 240ms var(--ui-gate-ease);
}
:is(.ui-gate__more-chev, .ui-gate__row-chev)[data-open] {
  transform: rotate(180deg);
}
.ui-gate__fold {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  transition: grid-template-rows 300ms var(--ui-gate-ease);
}
.ui-gate__fold[data-open] {
  grid-template-rows: 1fr;
}
.ui-gate__fold-in {
  display: grid;
  gap: 10px;
  min-height: 0;
  overflow: hidden;
  opacity: 0;
  transition: opacity 200ms ease;
}
.ui-gate__fold[data-open] .ui-gate__fold-in {
  opacity: 1;
}
.ui-gate__context {
  display: grid;
  gap: 2px;
  max-height: 168px;
  overflow: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  outline: none;
  border-radius: 6px;
  counter-reset: ui-gate-step;
}
.ui-gate__context > li {
  position: relative;
  min-width: 0;
  padding-left: 20px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-gate-text);
  overflow-wrap: anywhere;
  counter-increment: ui-gate-step;
}
.ui-gate__context > li::before {
  content: counter(ui-gate-step);
  position: absolute;
  left: 0;
  width: 14px;
  font-size: 11px;
  color: var(--ui-gate-faint);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-gate__files {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.ui-gate__files > li {
  max-width: 100%;
  overflow: hidden;
  padding: 2px 7px;
  border-radius: 5px;
  background: var(--ui-gate-fill);
  font-family: var(--ui-gate-mono);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-gate-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  padding-top: 4px;
}
.ui-gate__spacer {
  flex: 1;
}
.ui-gate__actions > .ui-gate__btn[data-quiet]:first-child:nth-last-child(2) {
  margin-left: auto;
}
.ui-gate__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 30px;
  padding: 0 12px;
  border-radius: 7px;
  background: var(--ui-gate-card);
  box-shadow: var(--ui-gate-shadow);
  font-size: 13px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-gate-ink);
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    opacity 140ms ease;
}
.ui-gate__btn:hover {
  background: var(--ui-gate-well);
}
.ui-gate__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-gate__btn[data-primary] {
  background: var(--ui-gate-solid);
  box-shadow: none;
  color: var(--ui-gate-on-solid);
}
.ui-gate__btn[data-primary]:hover {
  background: var(--ui-gate-solid);
  opacity: 0.88;
}
.ui-gate__btn[data-quiet] {
  padding: 0 8px 0 6px;
  background: none;
  box-shadow: none;
  color: var(--ui-gate-text);
}
.ui-gate__btn[data-quiet]:hover {
  background: var(--ui-gate-fill);
  color: var(--ui-gate-ink);
}
.ui-gate__btn:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-gate__btn > svg {
  color: var(--ui-gate-muted);
}
.ui-gate__card--empty {
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 22px 16px;
  background: var(--ui-gate-well);
  box-shadow: none;
  text-align: center;
}
.ui-gate__empty-mark {
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  margin-bottom: 4px;
  border-radius: 50%;
  background: var(--ui-gate-ok-bg);
  color: var(--ui-gate-ok-fg);
}
.ui-gate__empty-mark[data-state="stopped"] {
  background: var(--ui-gate-danger-bg);
  color: var(--ui-gate-danger-fg);
}
.ui-gate__empty-mark > svg {
  width: 12px;
  height: 12px;
}
.ui-gate__empty-title {
  font-weight: 500;
  color: var(--ui-gate-ink);
}
.ui-gate__empty-sub {
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-gate-muted);
  overflow-wrap: anywhere;
}
.ui-gate__after {
  display: flex;
  align-items: center;
  gap: 12px;
  width: min(100%, var(--ui-gate-w));
  min-height: 36px;
  margin: 0 auto;
  padding: 10px 2px 0;
}
.ui-gate__holds {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-gate-wait-fg);
  animation: ui-gate-fade 300ms ease both;
}
.ui-gate__holds > span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__held {
  color: var(--ui-gate-muted);
}
.ui-gate__done {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  width: min(100%, var(--ui-gate-w));
  padding: 4px;
  border-radius: 14px;
  background: var(--ui-gate-tray);
  margin: 6px auto 0;
}
.ui-gate__done > .ui-gate__label {
  padding: 2px 8px 0;
}
.ui-gate__rows {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 3px;
}
.ui-gate__row {
  border-radius: 9px;
  background: var(--ui-gate-card);
  box-shadow: var(--ui-gate-shadow);
}
.ui-gate__row[data-fresh] {
  animation: ui-gate-land 420ms 120ms var(--ui-gate-ease) both;
}
.ui-gate__row-head {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  min-width: 0;
  height: 32px;
  padding: 0 9px;
  border-radius: 9px;
  transition: background-color 140ms ease;
}
.ui-gate__row-head:hover {
  background: var(--ui-gate-well);
}
.ui-gate .ui-gate__row-head:focus-visible {
  outline: 2px solid var(--ui-gate-focus);
  outline-offset: -2px;
}
.ui-gate__row-mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: var(--ui-gate-fill);
  color: var(--ui-gate-muted);
}
.ui-gate__row-mark[data-status="rejected"] {
  background: var(--ui-gate-danger-bg);
  color: var(--ui-gate-danger-fg);
}
.ui-gate__row-action {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-gate-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__row-who {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  color: var(--ui-gate-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-gate__row-outcome {
  display: inline-flex;
  flex: none;
  align-items: center;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-gate-text);
  white-space: pre;
}
.ui-gate__row-tag {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-gate-danger-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-gate-danger-fg);
}
.ui-gate__row-at {
  color: var(--ui-gate-faint);
}
.ui-gate__row-body {
  gap: 6px;
  padding: 0 10px 0 31px;
}
.ui-gate__row[data-open] .ui-gate__row-body {
  padding: 0 10px 10px 31px;
}
.ui-gate__row-body :is(.ui-gate__data, .ui-gate__diff) {
  max-height: 88px;
}
.ui-gate__row-body .ui-gate__card-why {
  font-size: 12px;
}
.ui-gate__row-body .ui-gate__card-why {
  margin-top: 0;
}
.ui-gate__note {
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--ui-gate-well);
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-gate-text);
  overflow-wrap: anywhere;
}
.ui-gate__note[data-status="rejected"] {
  background: var(--ui-gate-danger-bg);
  color: var(--ui-gate-danger-fg);
}
@container ui-gate (max-width: 560px) {
  .ui-gate__task {
    display: none;
  }
  .ui-gate__stats {
    grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
    row-gap: 8px;
  }
  .ui-gate__stat[data-wide] {
    grid-column: 1 / -1;
    padding-left: 12px;
    border-left: 0;
  }
  .ui-gate__card-body {
    padding: 10px;
  }
  .ui-gate__row-who {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-gate__btn {
    height: 36px;
    padding: 0 14px;
  }
  .ui-gate__page {
    width: 32px;
    height: 32px;
  }
  .ui-gate__more {
    height: 32px;
  }
}
@keyframes ui-gate-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-gate-rise {
  from {
    opacity: 0.6;
    transform: translateY(calc(var(--ui-gate-peek) * -1)) scale(0.96);
  }
}
@keyframes ui-gate-in {
  from {
    opacity: 0;
    transform: translateY(-14px) scale(0.97);
  }
}
@keyframes ui-gate-behind {
  from {
    opacity: 0;
    transform: translateY(
        calc(var(--ui-gate-k) * var(--ui-gate-peek) * -1 - 12px)
      )
      scale(0.9);
  }
}
@keyframes ui-gate-leave {
  to {
    opacity: 0;
    transform: translateY(36px) scale(0.96);
  }
}
@keyframes ui-gate-leave-no {
  20% {
    transform: translateX(-4px);
  }
  40% {
    transform: translateX(3px);
  }
  to {
    opacity: 0;
    transform: translateY(36px) scale(0.96);
  }
}
@keyframes ui-gate-land {
  from {
    opacity: 0;
    transform: translateY(-10px) scale(0.98);
  }
}
@keyframes ui-gate-pulse {
  50% {
    opacity: 0.35;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-gate *,
  .ui-gate *::before,
  .ui-gate *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-gate {
  --ui-gate-tray: #19191c;
  --ui-gate-card: #232326;
  --ui-gate-strong: #ededed;
  --ui-gate-ink: #ededed;
  --ui-gate-text: #a1a1a6;
  --ui-gate-muted: #7c7c82;
  --ui-gate-faint: #4a4a50;
  --ui-gate-line: #2f2f34;
  --ui-gate-fill: #2c2c30;
  --ui-gate-well: #28282b;
  --ui-gate-rail: #3a3a40;
  --ui-gate-wait-bg: #3a2512;
  --ui-gate-wait-fg: #ffa057;
  --ui-gate-ok-bg: #16301f;
  --ui-gate-ok-fg: #5fd38a;
  --ui-gate-danger-bg: #3b1714;
  --ui-gate-danger-fg: #ff977d;
  --ui-gate-brand-bg: #1b2b4a;
  --ui-gate-brand-fg: #8ab4ff;
  --ui-gate-add-bg: #16301f;
  --ui-gate-add-fg: #5fd38a;
  --ui-gate-del-bg: #3b1714;
  --ui-gate-del-fg: #ff977d;
  --ui-gate-focus: rgba(77, 141, 255, 0.8);
  --ui-gate-solid: #ededed;
  --ui-gate-on-solid: #141416;
  --ui-gate-shadow: 0 0 0 1px var(--ui-gate-line), 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-gate-float:
    0 0 0 1px var(--ui-gate-line), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
`;export{n as default};
