import{r as t,j as a}from"./workbench-model-C4LJxhar.js";function oa(r){const n=c=>String(c).padStart(2,"0");return r<3600?`${Math.floor(r/60)}:${n(r%60)}`:`${Math.floor(r/3600)}:${n(Math.floor(r/60)%60)}:${n(r%60)}`}function pa(r){const[n,c]=r<120?[r,"second"]:r<7200?[Math.round(r/60),"minute"]:[Math.round(r/3600),"hour"];return`${n} ${c}${n===1?"":"s"}`}function sa(r){const n=Math.floor((Date.now()-r)/1e3);return n<60?"just now":n<3600?`${Math.floor(n/60)} min ago`:n<86400?`${Math.floor(n/3600)} h ago`:`${Math.floor(n/86400)} d ago`}function ua({title:r,status:n,defaultStatus:c="pending",onApprove:x,onDeny:b,expiresIn:N,onExpire:u}){const X=t.useId(),[aa,A]=t.useState(c),d=n??aa,s=d!=="pending",[D,I]=t.useState(!1),[v,w]=t.useState(!1),[g,_]=t.useState("user"),[ia,K]=t.useState(()=>s?Date.now():null),[R,m]=t.useState(""),[z,P]=t.useState(!1),[ea,l]=t.useState(!1),[ta,Y]=t.useState("⌘"),[O,U]=t.useState(d),[V,L]=t.useState(!1),[f,B]=t.useState(!1);O!==d&&(U(d),d==="pending"?(L(!1),B(!0),I(!1),w(!1),_("user"),K(null),m("")):(L(O==="pending"),B(!1),K(Date.now()),m(`${d==="approved"?"Approved":g==="timeout"?"Expired":"Denied"}: ${r}`)));const S=t.useRef(null),Z=t.useRef(null),G=t.useRef(null),H=t.useRef(!1);t.useEffect(()=>{var p;const e=((p=navigator.userAgentData)==null?void 0:p.platform)??navigator.platform??"";/mac|iphone|ipad|ipod/i.test(e||navigator.userAgent)||Y("Ctrl")},[]);async function J(){if(s||v)return;const e=x==null?void 0:x({always:D});if(e&&typeof e.then=="function"){w(!0);try{await e}catch{w(!1);return}w(!1)}n===void 0&&A("approved")}function E(e="user"){s||v&&e==="user"||(_(e),e==="timeout"&&(u==null||u()),b==null||b({reason:e}),n===void 0&&A("denied"))}function ra(e){s||v||e.defaultPrevented||(e.key==="Enter"&&(e.metaKey||e.ctrlKey)?(e.preventDefault(),J()):e.key==="Escape"&&(e.preventDefault(),E()))}const h=typeof N=="number"&&Number.isFinite(N)&&N>0?N*1e3:0,M=t.useRef(h),[T,C]=t.useState(Math.ceil(h/1e3)),Q=t.useRef(()=>{});t.useLayoutEffect(()=>{Q.current=()=>E("timeout")}),t.useEffect(()=>{d==="pending"&&(M.current=h,C(Math.ceil(h/1e3)))},[d,h]);const i=z||ea||v;t.useEffect(()=>{if(!h||s||i)return;let e=performance.now(),p=0;function j($){if(M.current-=$-e,e=$,C(Math.max(0,Math.ceil(M.current/1e3))),M.current<=0){Q.current();return}p=requestAnimationFrame(j)}return p=requestAnimationFrame(j),()=>cancelAnimationFrame(p)},[h,s,i]);const k=t.useRef(0),y=t.useRef(!1),F=t.useRef(!1);t.useEffect(()=>{const e=S.current;if(!e||typeof ResizeObserver>"u")return;const p=new ResizeObserver(()=>{y.current||(k.current=e.offsetHeight)});return p.observe(e),()=>p.disconnect()},[]),t.useLayoutEffect(()=>{var q,o;const e=S.current;if(!e)return;if(!F.current){F.current=!0,k.current=e.offsetHeight;return}s&&e.contains(document.activeElement)&&((q=Z.current)==null||q.focus({preventScroll:!0})),!s&&H.current&&((o=G.current)==null||o.focus({preventScroll:!0})),H.current=!1;const p=k.current;e.style.height="";const j=e.offsetHeight;if(!p||p===j)return;y.current=!0,e.style.height=`${p}px`,e.offsetHeight,e.style.height=`${j}px`;const $=window.setTimeout(()=>{e.style.height="",y.current=!1,k.current=e.offsetHeight},560);return()=>{window.clearTimeout($),e.style.height="",y.current=!1}},[s]);const[,W]=t.useState(0);return t.useEffect(()=>{if(!s)return;const e=window.setInterval(()=>W(p=>p+1),3e4);return()=>window.clearInterval(e)},[s]),{id:X,currentStatus:d,resolved:s,always:D,setAlways:I,busy:v,denialReason:g,resolvedAt:ia,announcement:R,setHovered:P,setFocused:l,modifier:ta,leaving:V,setLeaving:L,entering:f,setEntering:B,rootRef:S,resolvedRef:Z,approveRef:G,restoreFocusRef:H,approve:J,deny:E,handleKeyDown:ra,duration:h,secondsRemaining:T,paused:i}}const da=`
.ui-ap {
  --ui-ap-tray: #f0f0f0;
  --ui-ap-bg: #ffffff;
  --ui-ap-ink: #171717;
  --ui-ap-text: #6b6b6b;
  --ui-ap-muted: #626873;
  --ui-ap-line: #ececec;
  --ui-ap-soft: #fafafa;
  --ui-ap-tile: #f4f4f4;
  --ui-ap-hover: #e4e4e5;
  --ui-ap-primary: #171717;
  --ui-ap-primary-hover: #2e2e2e;
  --ui-ap-primary-ink: #ffffff;
  --ui-ap-primary-kbd: rgba(255, 255, 255, 0.14);
  --ui-ap-primary-kbd-ink: rgba(255, 255, 255, 0.72);
  --ui-ap-kbd: rgba(0, 0, 0, 0.055);
  --ui-ap-box: #d4d4d4;
  --ui-ap-box-hover: #b5b5b5;
  --ui-ap-focus: rgba(0, 96, 226, 0.7);
  --ui-ap-timer-low: #905e15;
  --ui-ap-low-bg: #f2f2f2;
  --ui-ap-low-ink: #6b6b6b;
  --ui-ap-med-bg: #fbf3e2;
  --ui-ap-med-ink: #8a5a00;
  --ui-ap-high-bg: #fdeceb;
  --ui-ap-high-ink: #b42318;
  --ui-ap-ok-bg: #e9f6ee;
  --ui-ap-ok-ink: #187941;
  --ui-ap-no-bg: #f2f2f2;
  --ui-ap-no-ink: #6b6b6b;
  --ui-ap-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  overflow: hidden;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ap-tray);
  color: var(--ui-ap-text);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 1.45;
  letter-spacing: -0.006em;
  text-align: left;
  -webkit-font-smoothing: antialiased;
  transition: height 520ms var(--ui-ap-ease);
}
.ui-ap *,
.ui-ap *::before,
.ui-ap *::after {
  box-sizing: border-box;
}
.ui-ap__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-ap-bg);
  box-shadow:
    0 0 0 1px var(--ui-ap-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-ap__pending > .ui-ap__card {
  padding: 16px;
}
.ui-ap__pending[data-leaving] {
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  pointer-events: none;
  animation: ui-ap-out 280ms var(--ui-ap-ease) both;
}
.ui-ap__pending[data-entering] {
  animation: ui-ap-in 420ms var(--ui-ap-ease) 80ms both;
}
.ui-ap[data-busy] .ui-ap__pending {
  pointer-events: none;
}
.ui-ap__head {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: start;
  gap: 12px;
}
.ui-ap__icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  background: var(--ui-ap-tile);
  box-shadow: inset 0 0 0 1px var(--ui-ap-line);
  color: var(--ui-ap-ink);
}
.ui-ap__icon svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ap__titles {
  min-width: 0;
  padding-top: 1px;
}
.ui-ap__title {
  margin: 0;
  overflow: hidden;
  color: var(--ui-ap-ink);
  font-size: 14px;
  font-weight: 550;
  line-height: 20px;
  letter-spacing: -0.011em;
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ap__desc {
  margin: 1px 0 0;
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ap__risk {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  margin-top: 1px;
  padding: 0 9px 0 8px;
  border-radius: 999px;
  background: var(--ui-ap-low-bg);
  color: var(--ui-ap-low-ink);
  font-size: 12px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
}
.ui-ap__risk-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  opacity: 0.8;
}
.ui-ap__risk-word {
  white-space: pre;
}
.ui-ap__risk[data-risk="medium"] {
  background: var(--ui-ap-med-bg);
  color: var(--ui-ap-med-ink);
}
.ui-ap__risk[data-risk="high"] {
  background: var(--ui-ap-high-bg);
  color: var(--ui-ap-high-ink);
}
.ui-ap__preview {
  display: grid;
  gap: 12px;
  max-height: 360px;
  overflow-y: auto;
  overscroll-behavior: contain;
  margin-top: 14px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-ap-soft);
  box-shadow: inset 0 0 0 1px var(--ui-ap-line);
}
.ui-ap__custom {
  min-width: 0;
}
.ui-ap__custom + .ui-ap__details {
  padding-top: 12px;
  border-top: 1px solid var(--ui-ap-line);
}
.ui-ap__details {
  display: grid;
  grid-template-columns: fit-content(min(40%, 180px)) minmax(0, 1fr);
  gap: 6px 16px;
  margin: 0;
}
.ui-ap__detail {
  display: contents;
}
.ui-ap__detail dt {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ap-muted);
  overflow-wrap: normal;
  text-overflow: ellipsis;
}
.ui-ap__detail dd {
  min-width: 0;
  margin: 0;
  overflow-x: auto;
  color: var(--ui-ap-ink);
  text-align: start;
  overflow-wrap: anywhere;
}
.ui-ap__always {
  display: flex;
  width: fit-content;
  max-width: 100%;
  margin-top: 14px;
  align-items: flex-start;
  gap: 8px;
  min-width: 0;
  cursor: pointer;
  user-select: none;
}
.ui-ap__always-label {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-ap__box {
  position: relative;
  display: grid;
  flex: none;
  margin-top: 1.5px;
  width: 16px;
  height: 16px;
}
.ui-ap__box input {
  appearance: none;
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  margin: 0;
  border-radius: 5px;
  background: var(--ui-ap-bg);
  box-shadow: inset 0 0 0 1px var(--ui-ap-box);
  cursor: pointer;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-ap__box input:hover {
  box-shadow: inset 0 0 0 1px var(--ui-ap-box-hover);
}
.ui-ap__box input:checked {
  background: var(--ui-ap-primary);
  box-shadow: inset 0 0 0 1px var(--ui-ap-primary);
}
.ui-ap__box input:focus-visible {
  outline: 2px solid var(--ui-ap-focus);
  outline-offset: 2px;
}
.ui-ap__box svg {
  position: absolute;
  inset: 0;
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-ap-primary-ink);
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 160ms ease,
    transform 260ms var(--ui-ap-ease);
  pointer-events: none;
}
.ui-ap__box input:checked + svg {
  opacity: 1;
  transform: none;
}
.ui-ap__label {
  overflow: hidden;
  padding: 6px 8px 4px;
  color: var(--ui-ap-muted);
  font-size: 12.5px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ap[data-label] .ui-ap__pending[data-leaving] {
  top: 30px;
}
.ui-ap__card > .ui-ap__foot {
  min-height: 0;
  margin-top: 14px;
  padding: 0;
}
.ui-ap__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 12px;
  min-height: 44px;
  padding: 6px 2px 2px 10px;
}
.ui-ap__expires {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  color: var(--ui-ap-muted);
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  transition: color 300ms ease;
}
.ui-ap__expires svg {
  width: 14px;
  height: 14px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ap__expires[data-low] {
  color: var(--ui-ap-timer-low);
}
.ui-ap__actions {
  display: flex;
  flex: 0 1 auto;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 4px;
  min-width: 0;
  margin-left: auto;
}
.ui-ap__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 34px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    transform 160ms var(--ui-ap-ease),
    opacity 160ms ease;
}
.ui-ap__btn:active,
.ui-ap__btn[data-pressed] {
  transform: scale(0.97);
}
.ui-ap__btn:focus-visible {
  outline: 2px solid var(--ui-ap-focus);
  outline-offset: 2px;
}
.ui-ap__btn--primary {
  padding-right: 8px;
  background: var(--ui-ap-primary);
  color: var(--ui-ap-primary-ink);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.ui-ap__btn--primary:hover,
.ui-ap__btn--primary[data-pressed] {
  background: var(--ui-ap-primary-hover);
}
.ui-ap__btn--quiet {
  padding-right: 8px;
  background: transparent;
  color: var(--ui-ap-ink);
}
.ui-ap__btn--quiet:hover,
.ui-ap__btn--quiet[data-pressed] {
  background: var(--ui-ap-hover);
}
.ui-ap__btn--ghost {
  background: transparent;
  color: var(--ui-ap-text);
}
.ui-ap__btn--ghost:hover {
  background: var(--ui-ap-hover);
  color: var(--ui-ap-ink);
}
.ui-ap[data-busy] .ui-ap__btn:not(.ui-ap__approve),
.ui-ap[data-busy] .ui-ap__always {
  opacity: 0.5;
}
.ui-ap[data-busy] .ui-ap__approve {
  cursor: progress;
}
.ui-ap__kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-ap-kbd);
  color: #59616c;
  font: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
}
.ui-ap__btn--primary .ui-ap__kbd {
  background: var(--ui-ap-primary-kbd);
  color: var(--ui-ap-primary-kbd-ink);
}
.ui-ap__spinner {
  width: 20px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-dasharray: 26 38;
  transform-origin: 50% 50%;
  animation: ui-ap-spin 800ms linear infinite;
}
.ui-ap__resolved {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 48px;
  padding: 12px 14px;
  outline: none;
  animation: ui-ap-in 420ms var(--ui-ap-ease) 120ms both;
}
.ui-ap__resolved:focus-visible {
  outline: 2px solid var(--ui-ap-focus);
  outline-offset: -2px;
}
.ui-ap__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ui-ap-ok-bg);
  color: var(--ui-ap-ok-ink);
  animation: ui-ap-pop 460ms var(--ui-ap-ease) 140ms both;
}
.ui-ap__resolved[data-status="denied"] .ui-ap__mark {
  background: var(--ui-ap-no-bg);
  color: var(--ui-ap-no-ink);
}
.ui-ap__mark svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.9;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ap__mark path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-ap-draw 420ms var(--ui-ap-ease) 300ms forwards;
}
.ui-ap__row-title {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-ap-ink);
  font-size: 13.5px;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ap__row-status {
  flex: none;
  color: var(--ui-ap-muted);
  white-space: nowrap;
}
.ui-ap__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@container (max-width: 400px) {
  .ui-ap__actions {
    flex: 1 1 100%;
    margin-left: 0;
  }
  .ui-ap__foot {
    padding-left: 2px;
  }
  .ui-ap__expires {
    padding-left: 8px;
  }
  .ui-ap__actions .ui-ap__btn {
    flex: 1 1 0;
    padding: 0 10px;
  }
  .ui-ap__kbd {
    display: none;
  }
}
@container (max-width: 340px) {
  .ui-ap__pending > .ui-ap__card {
    padding: 14px;
  }
  .ui-ap__head {
    gap: 10px;
  }
  .ui-ap__risk-word {
    display: none;
  }
  .ui-ap__row-time {
    display: none;
  }
  .ui-ap__details {
    column-gap: 12px;
  }
}
@media (hover: none) {
  .ui-ap__kbd {
    display: none;
  }
}
@keyframes ui-ap-out {
  to {
    opacity: 0;
    transform: translateY(-6px) scale(0.985);
    filter: blur(2px);
  }
}
@keyframes ui-ap-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-ap-pop {
  from {
    opacity: 0;
    transform: scale(0.5);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-ap-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-ap-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ap,
  .ui-ap *,
  .ui-ap *::before,
  .ui-ap *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition-duration: 1ms !important;
  }
  .ui-ap__spinner {
    animation: ui-ap-spin 1.6s linear infinite !important;
  }
  .ui-ap__mark path {
    stroke-dashoffset: 0;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ap {
  --ui-ap-tray: #111113;
  --ui-ap-bg: #19191b;
  --ui-ap-ink: #ededed;
  --ui-ap-text: #a1a1a1;
  --ui-ap-muted: #8b8b92;
  --ui-ap-line: #2a2a2e;
  --ui-ap-soft: #1f1f22;
  --ui-ap-tile: #1f1f22;
  --ui-ap-hover: #222225;
  --ui-ap-primary: #ededed;
  --ui-ap-primary-hover: #ffffff;
  --ui-ap-primary-ink: #19191b;
  --ui-ap-primary-kbd: rgba(0, 0, 0, 0.08);
  --ui-ap-primary-kbd-ink: rgba(25, 25, 27, 0.6);
  --ui-ap-kbd: rgba(255, 255, 255, 0.07);
  --ui-ap-box: rgba(255, 255, 255, 0.2);
  --ui-ap-box-hover: rgba(255, 255, 255, 0.32);
  --ui-ap-focus: rgba(77, 141, 255, 0.8);
  --ui-ap-timer-low: #e0a84a;
  --ui-ap-low-bg: rgba(255, 255, 255, 0.07);
  --ui-ap-low-ink: #a1a1a1;
  --ui-ap-med-bg: rgba(232, 183, 92, 0.12);
  --ui-ap-med-ink: #e8b75c;
  --ui-ap-high-bg: rgba(240, 138, 128, 0.12);
  --ui-ap-high-ink: #f08a80;
  --ui-ap-ok-bg: rgba(92, 201, 138, 0.13);
  --ui-ap-ok-ink: #5cc98a;
  --ui-ap-no-bg: rgba(255, 255, 255, 0.07);
  --ui-ap-no-ink: #a1a1a1;
}
`,ca=`
.ui-apc {
  --ui-apc-tray: #f0f0f0;
  --ui-apc-bg: #ffffff;
  --ui-apc-ink: #171717;
  --ui-apc-text: #6b6b6b;
  --ui-apc-muted: #626873;
  --ui-apc-line: #ececec;
  --ui-apc-soft: #fafafa;
  --ui-apc-tile: #f4f4f4;
  --ui-apc-hover: #e4e4e5;
  --ui-apc-primary: #171717;
  --ui-apc-primary-hover: #2e2e2e;
  --ui-apc-primary-ink: #ffffff;
  --ui-apc-primary-kbd: rgba(255, 255, 255, 0.14);
  --ui-apc-primary-kbd-ink: rgba(255, 255, 255, 0.72);
  --ui-apc-kbd: rgba(0, 0, 0, 0.055);
  --ui-apc-box: #d4d4d4;
  --ui-apc-box-hover: #b5b5b5;
  --ui-apc-focus: rgba(0, 96, 226, 0.7);
  --ui-apc-timer-low: #905e15;
  --ui-apc-low-bg: #f2f2f2;
  --ui-apc-low-ink: #6b6b6b;
  --ui-apc-med-bg: #fbf3e2;
  --ui-apc-med-ink: #8a5a00;
  --ui-apc-high-bg: #fdeceb;
  --ui-apc-high-ink: #b42318;
  --ui-apc-ok-bg: #e9f6ee;
  --ui-apc-ok-ink: #187941;
  --ui-apc-no-bg: #f2f2f2;
  --ui-apc-no-ink: #6b6b6b;
  --ui-apc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  overflow: hidden;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-apc-tray);
  color: var(--ui-apc-text);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 1.45;
  letter-spacing: -0.006em;
  text-align: left;
  -webkit-font-smoothing: antialiased;
  transition: height 520ms var(--ui-apc-ease);
}
.ui-apc *,
.ui-apc *::before,
.ui-apc *::after {
  box-sizing: border-box;
}
.ui-apc__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-apc-bg);
  box-shadow:
    0 0 0 1px var(--ui-apc-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-apc__pending > .ui-apc__card {
  padding: 16px;
}
.ui-apc__pending[data-leaving] {
  position: absolute;
  top: 4px;
  left: 4px;
  right: 4px;
  pointer-events: none;
  animation: ui-apc-out 280ms var(--ui-apc-ease) both;
}
.ui-apc__pending[data-entering] {
  animation: ui-apc-in 420ms var(--ui-apc-ease) 80ms both;
}
.ui-apc[data-busy] .ui-apc__pending {
  pointer-events: none;
}
.ui-apc__head {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: start;
  gap: 12px;
}
.ui-apc__icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  background: transparent;
  box-shadow: inset 0 0 0 1px var(--ui-apc-line);
  color: var(--ui-apc-ink);
}
.ui-apc__icon svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-apc__titles {
  min-width: 0;
  padding-top: 1px;
}
.ui-apc__title {
  margin: 0;
  overflow: hidden;
  color: var(--ui-apc-ink);
  font-size: 14px;
  font-weight: 550;
  line-height: 20px;
  letter-spacing: -0.011em;
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-apc__desc {
  margin: 1px 0 0;
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-apc__risk {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  margin-top: 1px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-apc-low-bg);
  color: var(--ui-apc-low-ink);
  font-size: 12px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
}
.ui-apc__risk-dot {
  display: none;
}
.ui-apc__risk-word {
  white-space: pre;
}
.ui-apc__risk[data-risk="medium"] {
  background: var(--ui-apc-med-bg);
  color: var(--ui-apc-med-ink);
}
.ui-apc__risk[data-risk="high"] {
  background: var(--ui-apc-high-bg);
  color: var(--ui-apc-high-ink);
}
.ui-apc__preview {
  display: grid;
  gap: 12px;
  max-height: 360px;
  overflow-y: auto;
  overscroll-behavior: contain;
  margin-top: 14px;
  padding-top: 14px;
  border-top: 1px solid var(--ui-apc-line);
}
.ui-apc__custom {
  min-width: 0;
}
.ui-apc__custom + .ui-apc__details {
  padding-top: 2px;
}
.ui-apc__details {
  display: grid;
  grid-template-columns: fit-content(min(40%, 180px)) minmax(0, 1fr);
  gap: 6px 16px;
  margin: 0;
}
.ui-apc__detail {
  display: contents;
}
.ui-apc__detail dt {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-apc-muted);
  overflow-wrap: normal;
  text-overflow: ellipsis;
}
.ui-apc__detail dd {
  min-width: 0;
  margin: 0;
  overflow-x: auto;
  color: var(--ui-apc-ink);
  text-align: start;
  overflow-wrap: anywhere;
}
.ui-apc__always {
  display: flex;
  width: fit-content;
  max-width: 100%;
  margin-top: 14px;
  align-items: flex-start;
  gap: 8px;
  min-width: 0;
  cursor: pointer;
  user-select: none;
}
.ui-apc__always-label {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-apc__box {
  position: relative;
  display: grid;
  flex: none;
  margin-top: 1.5px;
  width: 16px;
  height: 16px;
}
.ui-apc__box input {
  appearance: none;
  -webkit-appearance: none;
  width: 16px;
  height: 16px;
  margin: 0;
  border-radius: 5px;
  background: var(--ui-apc-bg);
  box-shadow: inset 0 0 0 1px var(--ui-apc-box);
  cursor: pointer;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-apc__box input:hover {
  box-shadow: inset 0 0 0 1px var(--ui-apc-box-hover);
}
.ui-apc__box input:checked {
  background: var(--ui-apc-primary);
  box-shadow: inset 0 0 0 1px var(--ui-apc-primary);
}
.ui-apc__box input:focus-visible {
  outline: 2px solid var(--ui-apc-focus);
  outline-offset: 2px;
}
.ui-apc__box svg {
  position: absolute;
  inset: 0;
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-apc-primary-ink);
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 160ms ease,
    transform 260ms var(--ui-apc-ease);
  pointer-events: none;
}
.ui-apc__box input:checked + svg {
  opacity: 1;
  transform: none;
}
.ui-apc__label {
  overflow: hidden;
  padding: 6px 8px 4px;
  color: var(--ui-apc-muted);
  font-size: 12.5px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-apc[data-label] .ui-apc__pending[data-leaving] {
  top: 30px;
}
.ui-apc[data-actions="card"] {
  padding: 0;
  border-radius: 16px;
  background: transparent;
}
.ui-apc[data-actions="card"] .ui-apc__card {
  box-shadow: inset 0 0 0 1px var(--ui-apc-line);
}
.ui-apc[data-actions="card"] .ui-apc__pending[data-leaving] {
  top: 0;
  left: 0;
  right: 0;
}
.ui-apc[data-actions="card"][data-label] .ui-apc__pending[data-leaving] {
  top: 26px;
}
.ui-apc[data-actions="card"] .ui-apc__label {
  padding-left: 2px;
}
.ui-apc__card > .ui-apc__foot {
  min-height: 0;
  margin-top: 16px;
  padding: 14px 0 0;
  border-top: 1px solid var(--ui-apc-line);
}
.ui-apc__card > .ui-apc__foot .ui-apc__always {
  margin-top: 0;
}
.ui-apc__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 12px;
  min-height: 44px;
  padding: 6px 2px 2px 10px;
}
.ui-apc__expires {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  color: var(--ui-apc-muted);
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  transition: color 300ms ease;
}
.ui-apc__expires svg {
  width: 14px;
  height: 14px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-apc__expires[data-low] {
  color: var(--ui-apc-timer-low);
}
.ui-apc__actions {
  display: flex;
  flex: 0 1 auto;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 4px;
  min-width: 0;
  margin-left: auto;
}
.ui-apc__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 34px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    transform 160ms var(--ui-apc-ease),
    opacity 160ms ease;
}
.ui-apc__btn:active,
.ui-apc__btn[data-pressed] {
  transform: scale(0.97);
}
.ui-apc__btn:focus-visible {
  outline: 2px solid var(--ui-apc-focus);
  outline-offset: 2px;
}
.ui-apc__btn--primary {
  padding-right: 8px;
  background: var(--ui-apc-primary);
  color: var(--ui-apc-primary-ink);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.ui-apc__btn--primary:hover,
.ui-apc__btn--primary[data-pressed] {
  background: var(--ui-apc-primary-hover);
}
.ui-apc__btn--quiet {
  padding-right: 8px;
  background: transparent;
  color: var(--ui-apc-ink);
}
.ui-apc__btn--quiet:hover,
.ui-apc__btn--quiet[data-pressed] {
  background: var(--ui-apc-hover);
}
.ui-apc__btn--ghost {
  background: transparent;
  color: var(--ui-apc-text);
}
.ui-apc__btn--ghost:hover {
  background: var(--ui-apc-hover);
  color: var(--ui-apc-ink);
}
.ui-apc[data-busy] .ui-apc__btn:not(.ui-apc__approve),
.ui-apc[data-busy] .ui-apc__always {
  opacity: 0.5;
}
.ui-apc[data-busy] .ui-apc__approve {
  cursor: progress;
}
.ui-apc__kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-apc-kbd);
  color: var(--ui-apc-muted);
  font: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
}
.ui-apc__btn--primary .ui-apc__kbd {
  background: var(--ui-apc-primary-kbd);
  color: var(--ui-apc-primary-kbd-ink);
}
.ui-apc__spinner {
  width: 20px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-dasharray: 26 38;
  transform-origin: 50% 50%;
  animation: ui-apc-spin 800ms linear infinite;
}
.ui-apc__resolved {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 48px;
  padding: 12px 14px;
  outline: none;
  animation: ui-apc-in 420ms var(--ui-apc-ease) 120ms both;
}
.ui-apc__resolved:focus-visible {
  outline: 2px solid var(--ui-apc-focus);
  outline-offset: -2px;
}
.ui-apc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: var(--ui-apc-ok-bg);
  color: var(--ui-apc-ok-ink);
  animation: ui-apc-pop 460ms var(--ui-apc-ease) 140ms both;
}
.ui-apc__resolved[data-status="denied"] .ui-apc__mark {
  background: var(--ui-apc-no-bg);
  color: var(--ui-apc-no-ink);
}
.ui-apc__mark svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.9;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-apc__mark path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-apc-draw 420ms var(--ui-apc-ease) 300ms forwards;
}
.ui-apc__row-title {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-apc-ink);
  font-size: 13.5px;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-apc__row-status {
  flex: none;
  color: var(--ui-apc-muted);
  white-space: nowrap;
}
.ui-apc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@container (max-width: 400px) {
  .ui-apc__actions {
    flex: 1 1 100%;
    margin-left: 0;
  }
  .ui-apc__foot {
    padding-left: 2px;
  }
  .ui-apc__expires {
    padding-left: 8px;
  }
  .ui-apc__actions .ui-apc__btn {
    flex: 1 1 0;
    padding: 0 10px;
  }
  .ui-apc__kbd {
    display: none;
  }
}
@container (max-width: 340px) {
  .ui-apc__pending > .ui-apc__card {
    padding: 14px;
  }
  .ui-apc__head {
    gap: 10px;
  }
  .ui-apc__risk-word {
    display: none;
  }
  .ui-apc__row-time {
    display: none;
  }
  .ui-apc__details {
    column-gap: 12px;
  }
}
@media (hover: none) {
  .ui-apc__kbd {
    display: none;
  }
}
@keyframes ui-apc-out {
  to {
    opacity: 0;
    transform: translateY(-6px) scale(0.985);
    filter: blur(2px);
  }
}
@keyframes ui-apc-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-apc-pop {
  from {
    opacity: 0;
    transform: scale(0.5);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-apc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-apc-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-apc,
  .ui-apc *,
  .ui-apc *::before,
  .ui-apc *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition-duration: 1ms !important;
  }
  .ui-apc__spinner {
    animation: ui-apc-spin 1.6s linear infinite !important;
  }
  .ui-apc__mark path {
    stroke-dashoffset: 0;
  }
}
:where(.dark, [data-theme="dark"]) .ui-apc {
  --ui-apc-tray: #111113;
  --ui-apc-bg: #19191b;
  --ui-apc-ink: #ededed;
  --ui-apc-text: #a1a1a1;
  --ui-apc-muted: #8b8b92;
  --ui-apc-line: #2a2a2e;
  --ui-apc-soft: #1f1f22;
  --ui-apc-tile: #1f1f22;
  --ui-apc-hover: #222225;
  --ui-apc-primary: #ededed;
  --ui-apc-primary-hover: #ffffff;
  --ui-apc-primary-ink: #19191b;
  --ui-apc-primary-kbd: rgba(0, 0, 0, 0.08);
  --ui-apc-primary-kbd-ink: rgba(25, 25, 27, 0.6);
  --ui-apc-kbd: rgba(255, 255, 255, 0.07);
  --ui-apc-box: rgba(255, 255, 255, 0.2);
  --ui-apc-box-hover: rgba(255, 255, 255, 0.32);
  --ui-apc-focus: rgba(77, 141, 255, 0.8);
  --ui-apc-timer-low: #e0a84a;
  --ui-apc-low-bg: rgba(255, 255, 255, 0.07);
  --ui-apc-low-ink: #a1a1a1;
  --ui-apc-med-bg: rgba(232, 183, 92, 0.12);
  --ui-apc-med-ink: #e8b75c;
  --ui-apc-high-bg: rgba(240, 138, 128, 0.12);
  --ui-apc-high-ink: #f08a80;
  --ui-apc-ok-bg: rgba(92, 201, 138, 0.13);
  --ui-apc-ok-ink: #5cc98a;
  --ui-apc-no-bg: rgba(255, 255, 255, 0.07);
  --ui-apc-no-ink: #a1a1a1;
}
`,la={low:"Low",medium:"Medium",high:"High"};function ha({clean:r=!1,...n}){const{title:c,description:x,risk:b,icon:N,details:u,preview:X,children:aa,onEdit:A,allowAlways:d=!0,alwaysLabel:s="Always allow this action",approveLabel:D="Approve",denyLabel:I="Deny",editLabel:v="Edit",shortcuts:w=!0,label:g,actions:_=r?"card":"tray",className:ia}=n,K=ua(n),{id:R,currentStatus:m,resolved:z,always:P,setAlways:ea,busy:l,denialReason:ta,resolvedAt:Y,announcement:O,setHovered:U,setFocused:V,modifier:L,leaving:f,setLeaving:B,entering:S,setEntering:Z,rootRef:G,resolvedRef:H,approveRef:J,restoreFocusRef:E,approve:ra,deny:h,handleKeyDown:M,duration:T,secondsRemaining:C,paused:Q}=K,i=r?"ui-apc":"ui-ap",k=`${R}-title`,y=`${R}-row`,F=`${R}-desc`,W=`${R}-timer`,e=X??aa,p=m==="approved"?"Approved":ta==="timeout"?"Expired":"Denied",j=[x?F:null,T&&!z?W:null].filter(Boolean).join(" "),$=d&&a.jsxs("label",{className:`${i}__always`,children:[a.jsxs("span",{className:`${i}__box`,children:[a.jsx("input",{type:"checkbox",checked:P,disabled:l,onChange:o=>ea(o.target.checked)}),a.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("path",{d:"M4 8.3 6.8 11 12 5.2"})})]}),a.jsx("span",{className:`${i}__always-label`,children:s})]}),q=a.jsxs("div",{className:`${i}__foot`,children:[r&&_==="card"&&$,T>0&&a.jsxs("span",{className:`${i}__expires`,"data-paused":Q||void 0,"data-low":C<=10||void 0,"aria-hidden":"true",children:[a.jsxs("svg",{viewBox:"0 0 16 16",children:[a.jsx("circle",{cx:"8",cy:"8",r:"6"}),a.jsx("path",{d:"M8 5v3.2l2 1.3"})]}),"Expires in ",oa(C)]}),a.jsxs("div",{className:`${i}__actions`,children:[A&&a.jsx("button",{type:"button",className:`${i}__btn ${i}__btn--ghost`,"aria-disabled":l||void 0,onClick:()=>{l||A()},children:v}),a.jsxs("button",{type:"button",className:`${i}__btn ${i}__btn--quiet ${i}__deny`,"aria-keyshortcuts":"Escape","aria-disabled":l||void 0,onClick:()=>h(),children:[I,w&&a.jsx("kbd",{className:`${i}__kbd`,"aria-hidden":"true",children:"Esc"})]}),a.jsxs("button",{ref:J,type:"button",className:`${i}__btn ${i}__btn--primary ${i}__approve`,"aria-keyshortcuts":"Meta+Enter Control+Enter","aria-disabled":l||void 0,onClick:()=>void ra(),children:[D,l?a.jsx("svg",{className:`${i}__spinner`,viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("circle",{cx:"8",cy:"8",r:"6"})}):w&&a.jsx("kbd",{className:`${i}__kbd`,"aria-hidden":"true",children:L==="⌘"?"⌘↵":"Ctrl ↵"})]})]})]});return a.jsxs("div",{ref:G,className:[i,ia].filter(Boolean).join(" "),role:"group","aria-labelledby":z?y:k,"aria-describedby":j||void 0,"aria-busy":l||void 0,"data-status":m,"data-busy":l||void 0,"data-label":g?"":void 0,"data-actions":_,onKeyDown:M,onPointerEnter:()=>U(!0),onPointerLeave:()=>U(!1),onFocus:()=>V(!0),onBlur:o=>{o.currentTarget.contains(o.relatedTarget)||V(!1)},children:[a.jsx("style",{href:r?"ui-approval-card-clean":"ui-approval-card",precedence:"default",children:r?ca:da}),g&&a.jsx("div",{className:`${i}__label`,title:typeof g=="string"?g:void 0,children:g}),(!z||f)&&a.jsxs("div",{className:`${i}__pending`,"data-leaving":f||void 0,"data-entering":S||void 0,inert:f,"aria-hidden":f||void 0,onAnimationEnd:o=>{o.target===o.currentTarget&&(f&&B(!1),S&&Z(!1))},children:[a.jsxs("div",{className:`${i}__card`,children:[a.jsxs("div",{className:`${i}__head`,children:[a.jsx("span",{className:`${i}__icon`,"aria-hidden":"true",children:N??a.jsxs("svg",{viewBox:"0 0 24 24",children:[a.jsx("path",{d:"M12 3 5 5.8v5.4c0 4.3 2.9 8.2 7 9.8 4.1-1.6 7-5.5 7-9.8V5.8L12 3Z"}),a.jsx("path",{d:"m9.2 12.2 2 2 3.8-4"})]})}),a.jsxs("div",{className:`${i}__titles`,children:[a.jsx("h3",{className:`${i}__title`,dir:"auto",title:c,id:f?void 0:k,children:c}),x&&a.jsx("p",{className:`${i}__desc`,dir:"auto",title:typeof x=="string"?x:void 0,id:f?void 0:F,children:x})]}),b&&a.jsxs("span",{className:`${i}__risk`,"data-risk":b,children:[a.jsx("span",{className:`${i}__risk-dot`,"aria-hidden":"true"}),la[b],a.jsx("span",{className:`${i}__risk-word`,children:" risk"})]})]}),(e||(u==null?void 0:u.length))&&a.jsxs("div",{className:`${i}__preview`,children:[e&&a.jsx("div",{className:`${i}__custom`,children:e}),u!=null&&u.length?a.jsx("dl",{className:`${i}__details`,children:u.map((o,na)=>a.jsxs("div",{className:`${i}__detail`,children:[a.jsx("dt",{dir:"auto",title:o.label,children:o.label}),a.jsx("dd",{dir:"auto",children:o.value})]},o.label+na))}):null]}),(!r||_==="tray")&&$,_==="card"&&q]}),_==="tray"&&q,T>0&&a.jsx("span",{className:`${i}__sr`,id:f?void 0:W,children:`Expires in ${pa(C)} unless approved. The timer pauses while the card is hovered or focused.`})]}),z&&a.jsxs("div",{ref:H,className:`${i}__card ${i}__resolved`,tabIndex:-1,"data-status":m,onFocus:()=>{E.current=!0},onBlur:o=>{(o.relatedTarget||o.currentTarget.isConnected)&&(E.current=!1)},children:[a.jsx("span",{className:`${i}__mark`,"aria-hidden":"true",children:a.jsx("svg",{viewBox:"0 0 16 16",children:m==="approved"?a.jsx("path",{d:"M4.2 8.4 6.9 11 11.8 5.6",pathLength:1}):a.jsx("path",{d:"M5.2 5.2 10.8 10.8M10.8 5.2 5.2 10.8",pathLength:1})})}),a.jsx("span",{className:`${i}__row-title`,dir:"auto",title:c,id:y,children:c}),a.jsxs("span",{className:`${i}__row-status`,children:[p,m==="approved"&&P&&a.jsx("span",{className:`${i}__row-extra`,children:" · Always"}),Y!==null&&a.jsxs("span",{className:`${i}__row-time`,children:[" · ",sa(Y)]})]})]}),a.jsx("span",{className:`${i}__sr`,role:"status","aria-live":"polite",children:O})]})}export{ha as A};
