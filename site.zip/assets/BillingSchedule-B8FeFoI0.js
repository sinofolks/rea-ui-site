const n=`.ui-bs {
  --ui-bs-tray: #f0f0f0;
  --ui-bs-card: #ffffff;
  --ui-bs-card-line: #e5e5e5;
  --ui-bs-line: #ececec;
  --ui-bs-inset: #f7f7f7;
  --ui-bs-ink: #171717;
  --ui-bs-text: #404040;
  --ui-bs-muted: #626873;
  --ui-bs-hover: #f5f5f5;
  --ui-bs-grad-a: #c7d7ff;
  --ui-bs-grad-b: #e4d9ff;
  --ui-bs-grad-c: #fbe0ef;
  --ui-bs-grad-text: #3550b0;
  --ui-bs-focus: rgba(0, 96, 226, 0.7);
  --ui-bs-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-bs-ease: cubic-bezier(0.22, 1, 0.36, 1);
  width: 100%;
  max-width: 560px;
  padding: 6px;
  border-radius: 20px;
  background: var(--ui-bs-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-bs-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-bs *,
.ui-bs *::before,
.ui-bs *::after {
  box-sizing: border-box;
}
.ui-bs button,
.ui-bs select,
.ui-bs input {
  font: inherit;
  color: inherit;
  margin: 0;
}
.ui-bs button {
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-bs :focus-visible {
  outline: 2px solid var(--ui-bs-focus);
  outline-offset: 2px;
}
.ui-bs svg {
  width: 16px;
  height: 16px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-bs__title {
  margin: 0;
  overflow-wrap: anywhere;
  padding: 10px 10px 12px;
  font-size: 15px;
  font-weight: 500;
  letter-spacing: -0.01em;
}
.ui-bs__card {
  padding: 12px;
  border: 1px solid var(--ui-bs-card-line);
  border-radius: 16px;
  background: var(--ui-bs-card);
  box-shadow: var(--ui-bs-shadow);
}
.ui-bs__summary {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 2px 2px 12px;
  font-size: 14px;
  color: var(--ui-bs-text);
}
.ui-bs__phase {
  min-width: 0;
  padding: 2px 4px;
  margin-left: -4px !important;
  border: 0;
  border-radius: 6px;
  background: none;
  font-weight: 500;
  color: var(--ui-bs-ink) !important;
  outline: none;
  transition: background-color 160ms ease;
}
.ui-bs__phase:hover,
.ui-bs__phase:focus {
  background: var(--ui-bs-hover);
}
.ui-bs__summary svg {
  width: 15px;
  height: 15px;
  color: var(--ui-bs-muted);
}
.ui-bs__end {
  animation: ui-bs-fade 260ms ease both;
}
.ui-bs__fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 10px;
  border-radius: 12px;
  background: var(--ui-bs-inset);
}
.ui-bs__field {
  display: grid;
  gap: 7px;
  min-width: 0;
  font-size: 13px;
  color: var(--ui-bs-text);
}
.ui-bs__input,
.ui-bs__select {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  height: 40px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-bs-card);
  box-shadow:
    inset 0 0 0 1px var(--ui-bs-card-line),
    0 1px 1px rgba(0, 0, 0, 0.03);
  font-size: 14px;
  color: var(--ui-bs-ink) !important;
  text-align: left;
}
.ui-bs__input input {
  flex: 1;
  min-width: 0;
  height: 100%;
  border: 0;
  background: none;
  outline: none;
}
.ui-bs__input input::-webkit-calendar-picker-indicator {
  position: absolute;
  inset: 0;
  width: auto;
  height: auto;
  opacity: 0;
  cursor: pointer;
}
.ui-bs__input svg {
  color: var(--ui-bs-text);
  pointer-events: none;
}
.ui-bs__input:focus-within {
  box-shadow:
    inset 0 0 0 1px color-mix(in srgb, var(--ui-bs-ink) 22%, transparent),
    0 1px 1px rgba(0, 0, 0, 0.03);
}
.ui-bs__select svg {
  color: var(--ui-bs-muted);
  transition: transform 220ms var(--ui-bs-ease);
}
.ui-bs__select[aria-expanded="true"] svg {
  transform: rotate(180deg);
}
.ui-bs__select--accent {
  background: linear-gradient(
    100deg,
    var(--ui-bs-grad-a),
    var(--ui-bs-grad-b) 60%,
    var(--ui-bs-grad-c)
  );
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.5),
    0 1px 2px rgba(47, 107, 255, 0.12);
  color: var(--ui-bs-grad-text) !important;
}
.ui-bs__select--accent svg {
  color: var(--ui-bs-grad-text);
}
.ui-bs__dd {
  position: relative;
}
.ui-bs__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 5;
  display: grid;
  gap: 2px;
  min-width: 220px;
  padding: 5px;
  border-radius: 12px;
  background: var(--ui-bs-card);
  box-shadow:
    0 0 0 1px var(--ui-bs-card-line),
    0 10px 30px rgba(0, 0, 0, 0.1);
  animation: ui-bs-menu 200ms var(--ui-bs-ease) both;
  transform-origin: top;
}
.ui-bs__menu {
  max-width: min(360px, calc(100vw - 32px));
  max-height: min(320px, 60vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-bs__menu button {
  overflow-wrap: anywhere;
}
.ui-bs__menu-empty {
  margin: 0;
  padding: 6px 8px;
  color: var(--ui-bs-muted);
}
.ui-bs__menu[data-up] {
  top: auto;
  bottom: calc(100% + 6px);
  right: auto;
  transform-origin: bottom left;
}
.ui-bs__menu button {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  padding: 8px 10px;
  border: 0;
  border-radius: 8px;
  background: none;
  font-size: 13.5px;
  text-align: left;
}
.ui-bs__menu button:hover {
  background: var(--ui-bs-hover);
}
.ui-bs__menu small {
  display: block;
  margin-top: 1px;
  font-size: 12px;
  color: var(--ui-bs-muted);
}
.ui-bs__table {
  margin-top: 6px;
}
.ui-bs__row {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 0.85fr) 216px;
  align-items: center;
  gap: 14px;
  min-height: 52px;
  padding: 6px 4px 6px 6px;
  border-bottom: 1px solid var(--ui-bs-line);
  font-size: 14px;
  animation: ui-bs-row 320ms var(--ui-bs-ease) both;
}
.ui-bs__row--head {
  min-height: 40px;
  font-size: 13px;
  color: var(--ui-bs-muted);
  animation: none;
}
.ui-bs__right {
  text-align: right;
  padding-right: 30px;
}
.ui-bs__rows-outer {
  overflow: hidden;
}
.ui-bs__rows-outer[data-smooth] {
  transition: height 320ms var(--ui-bs-ease);
}
.ui-bs__empty {
  margin: 0;
  padding: 16px 6px;
  font-size: 13px;
  color: var(--ui-bs-muted);
}
.ui-bs__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-bs__name-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-bs__tag {
  display: grid;
  place-items: center;
  width: 22px;
  height: 22px;
  flex: none;
  border-radius: 7px;
  background: var(--ui-bs-inset);
  color: var(--ui-bs-text);
}
.ui-bs__tag svg {
  width: 13px;
  height: 13px;
}
.ui-bs__muted {
  font-size: 13px;
  color: var(--ui-bs-muted);
  white-space: nowrap;
}
.ui-bs__repeat {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--ui-bs-text);
}
.ui-bs__repeat select,
.ui-bs__timing {
  padding: 3px 4px;
  margin-left: -4px !important;
  border: 0;
  border-radius: 6px;
  background: none;
  appearance: none;
  cursor: pointer;
  transition: background-color 160ms ease;
}
.ui-bs__repeat select:hover,
.ui-bs__timing:hover {
  background: var(--ui-bs-hover);
}
.ui-bs__timing {
  margin: 0 28px 0 0 !important;
  padding: 1px 4px !important;
  font-size: 12px;
  color: var(--ui-bs-muted) !important;
  text-align: right;
}
.ui-bs__price {
  display: grid;
  justify-items: end;
  min-width: 0;
}
.ui-bs__price-main {
  display: flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
}
.ui-bs__num {
  display: inline-flex;
  align-items: center;
  color: var(--ui-bs-ink);
  font-variant-numeric: tabular-nums;
}
.ui-bs__num input {
  padding: 3px 1px;
  border: 0;
  border-radius: 6px;
  background: none;
  outline: none;
  text-align: right;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-bs__num input:hover {
  background: var(--ui-bs-hover);
}
.ui-bs__num input:focus {
  background: var(--ui-bs-card);
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-bs-ink) 22%, transparent);
}
.ui-bs__remove {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  margin-left: 4px !important;
  padding: 0;
  border: 0;
  border-radius: 7px;
  background: none;
  color: var(--ui-bs-muted) !important;
  opacity: 0;
  transition:
    opacity 160ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-bs__remove svg {
  width: 13px;
  height: 13px;
}
.ui-bs__row:hover .ui-bs__remove,
.ui-bs__remove:focus-visible {
  opacity: 1;
}
.ui-bs__remove:hover {
  background: var(--ui-bs-hover);
  color: var(--ui-bs-ink) !important;
}
.ui-bs__actions {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  padding: 10px;
  border-radius: 12px;
  background: var(--ui-bs-inset);
}
.ui-bs__spacer {
  flex: 1;
}
.ui-bs__btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-bs-card);
  box-shadow:
    inset 0 0 0 1px var(--ui-bs-card-line),
    0 1px 1px rgba(0, 0, 0, 0.03);
  font-size: 13.5px;
  color: var(--ui-bs-ink) !important;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    opacity 200ms ease,
    transform 160ms ease;
}
.ui-bs__btn:hover:not(:disabled) {
  background: var(--ui-bs-hover);
}
.ui-bs__btn:active:not(:disabled) {
  transform: scale(0.98);
}
.ui-bs__btn:disabled {
  opacity: 0.45;
  cursor: default;
}
.ui-bs__btn svg {
  color: var(--ui-bs-text);
}
.ui-bs__select-label {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ui-bs__totals {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  flex-wrap: wrap;
  padding: 12px 10px 6px;
  font-size: 13px;
  color: var(--ui-bs-muted);
}
.ui-bs__totals b {
  margin-left: 4px;
  white-space: nowrap;
  font-weight: 600;
  color: var(--ui-bs-ink);
  font-variant-numeric: tabular-nums;
}
.ui-bs__totals em {
  margin-left: 6px;
  font-style: normal;
  font-size: 12px;
  color: var(--ui-bs-grad-text);
}
@keyframes ui-bs-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-bs-row {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }
}
@keyframes ui-bs-menu {
  from {
    opacity: 0;
    transform: scale(0.97) translateY(-4px);
  }
}
@media (max-width: 520px) {
  .ui-bs__fields {
    grid-template-columns: 1fr;
  }
  .ui-bs__summary {
    flex-wrap: wrap;
    row-gap: 2px;
  }
  .ui-bs__row {
    grid-template-columns: minmax(0, 1fr);
    gap: 2px;
    padding: 10px 4px 10px 6px;
  }
  .ui-bs__row > :nth-child(2) {
    display: none;
  }
  .ui-bs__row--head {
    display: none;
  }
  .ui-bs__price {
    justify-items: stretch;
  }
  .ui-bs__price-main {
    justify-content: flex-start;
  }
  .ui-bs__timing {
    justify-self: start;
    margin: 0 0 0 -4px !important;
  }
  .ui-bs__remove {
    opacity: 1;
    margin-left: auto !important;
  }
  .ui-bs__actions {
    flex-wrap: wrap;
  }
  .ui-bs__spacer {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bs__rows-outer[data-smooth] {
    transition: none;
  }
  .ui-bs__row,
  .ui-bs__menu,
  .ui-bs__end {
    animation: none;
  }
}
.ui-bs input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-bs textarea:focus-visible,
.ui-bs [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-bs {
  --ui-bs-tray: #161618;
  --ui-bs-card: #232326;
  --ui-bs-card-line: rgba(255, 255, 255, 0.08);
  --ui-bs-line: rgba(255, 255, 255, 0.07);
  --ui-bs-inset: #1c1c1f;
  --ui-bs-ink: #ededed;
  --ui-bs-text: #c4c4c4;
  --ui-bs-muted: #8f8f8f;
  --ui-bs-hover: rgba(255, 255, 255, 0.05);
  --ui-bs-grad-a: #2a3a6b;
  --ui-bs-grad-b: #3a2d66;
  --ui-bs-grad-c: #4a2240;
  --ui-bs-grad-text: #c9d6ff;
  --ui-bs-focus: rgba(77, 141, 255, 0.8);
  --ui-bs-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-bs__input input {
  color-scheme: dark;
}
`;export{n as default};
