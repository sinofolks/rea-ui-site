const n=`.ui-bx {
  --ui-bx-duration: 420ms;
  --ui-bx-blur: 10px;
  --ui-bx-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  display: block;
}
.ui-bx--both {
  display: inline-block;
  vertical-align: top;
}
.ui-bx[data-busy] {
  overflow: hidden;
}
.ui-bx__layer {
  display: block;
}
.ui-bx--both > .ui-bx__layer {
  width: max-content;
}
.ui-bx__layer--out {
  position: absolute;
  top: 0;
  left: 0;
  pointer-events: none;
}
.ui-bx--height > .ui-bx__layer--out,
.ui-bx--none > .ui-bx__layer--out {
  right: 0;
}
.ui-bx--both > .ui-bx__layer--out {
  left: 50%;
  translate: -50% 0;
}
.ui-bx--both > .ui-bx__layer--in {
  margin-left: 50%;
  translate: -50% 0;
}
.ui-bx__layer--in {
  animation: ui-bx-in var(--ui-bx-duration) var(--ui-bx-ease) both;
}
.ui-bx__layer--out {
  animation: ui-bx-out calc(var(--ui-bx-duration) * 0.8) ease-in both;
}
@keyframes ui-bx-in {
  from {
    opacity: 0;
    filter: blur(var(--ui-bx-blur));
    transform: scale(0.98);
  }
  to {
    opacity: 1;
    filter: blur(0);
    transform: scale(1);
  }
}
@keyframes ui-bx-out {
  from {
    opacity: 1;
    filter: blur(0);
    transform: scale(1);
  }
  to {
    opacity: 0;
    filter: blur(var(--ui-bx-blur));
    transform: scale(1.02);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bx__layer--in,
  .ui-bx__layer--out {
    animation: none;
  }
  .ui-bx__layer--out {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-bx {
  color: inherit;
}

.blur-crossfade-demo {
  -webkit-font-smoothing: antialiased;
  color: #171717;
  grid-template-columns: minmax(0, 1fr);
  place-items: center;
  width: 100%;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    sans-serif;
  display: grid;
}
.bxd-card {
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  width: min(100%, 360px);
  padding: 16px;
  box-shadow: 0 1px 2px #0000000f;
}
.bxd-head {
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  min-height: 32px;
  display: flex;
}
.bxd-meta {
  gap: 2px;
  min-width: 0;
  display: grid;
}
.bxd-title {
  letter-spacing: -0.01em;
  font-size: 14px;
  font-weight: 600;
}
.bxd-sub {
  color: #8f8f8f;
  font-size: 12px;
}
.bxd-primary {
  color: #fff;
  height: 30px;
  font: inherit;
  cursor: pointer;
  background: linear-gradient(#323137, #201e25);
  border: 0;
  border-radius: 9px;
  flex: none;
  padding: 0 12px;
  font-size: 12.5px;
  font-weight: 500;
  transition: background 0.3s;
  box-shadow:
    0 1px 2px #0000002e,
    inset 0 1px #ffffff1a;
}
.bxd-primary[data-status="busy"] {
  cursor: progress;
}
.bxd-primary[data-status="done"] {
  background: linear-gradient(#1aa774, #0f8a5f);
}
.bxd-primary:focus-visible {
  outline-offset: 2px;
  outline: 2px solid #2f6bff;
}
.bxd-btn {
  white-space: nowrap;
  align-items: center;
  gap: 6px;
  height: 30px;
  display: inline-flex;
}
.bxd-spin {
  border: 1.5px solid #ffffff4d;
  border-top-color: #fff;
  border-radius: 999px;
  width: 12px;
  height: 12px;
  animation: 0.7s linear infinite bxd-spin;
}
@keyframes bxd-spin {
  to {
    transform: rotate(360deg);
  }
}
.bxd-panel {
  background: #f7f7f8;
  border-radius: 12px;
  margin-top: 14px;
  padding: 12px 14px;
}
.bxd-note {
  justify-items: start;
  gap: 6px;
  display: grid;
}
.bxd-note p {
  color: #404040;
  text-wrap: pretty;
  margin: 0;
  font-size: 13px;
  line-height: 1.5;
}
.bxd-tag {
  border-radius: 999px;
  padding: 2px 7px;
  font-size: 11px;
  font-weight: 600;
}
.bxd-tag[data-kind="Shipped"] {
  color: #0f9f6e;
  background: #10b9811f;
}
.bxd-tag[data-kind="Improved"] {
  color: #2f6bff;
  background: #2f6bff1a;
}
.bxd-tag[data-kind="Fixed"] {
  color: #b86e00;
  background: #f59e0b24;
}
.bxd-foot {
  justify-content: space-between;
  align-items: center;
  margin-top: 12px;
  display: flex;
}
.bxd-dots {
  gap: 5px;
  display: inline-flex;
}
.bxd-dots i {
  background: #e0e0e2;
  border-radius: 999px;
  width: 6px;
  height: 6px;
  transition:
    background 0.3s,
    width 0.3s;
}
.bxd-dots i[data-on] {
  background: #171717;
  width: 16px;
}
.bxd-chip {
  color: #171717;
  height: 30px;
  font: inherit;
  cursor: pointer;
  background: #fff;
  border: 0;
  border-radius: 9px;
  padding: 0 12px;
  font-size: 12.5px;
  font-weight: 500;
  box-shadow:
    0 0 0 1px #e5e5e5,
    0 1px 2px #0000000a;
}
.bxd-chip:hover {
  background: #fafafa;
}
.bxd-chip:focus-visible {
  outline-offset: 2px;
  outline: 2px solid #2f6bff;
}
@media (prefers-reduced-motion: reduce) {
  .bxd-spin {
    animation-duration: 2s;
  }
}
:where(.dark, [data-theme="dark"]) .blur-crossfade-demo {
  color: #ededed;
}
:where(.dark, [data-theme="dark"]) .bxd-card {
  background: #232326;
  border-color: #ffffff14;
}
:where(.dark, [data-theme="dark"]) .bxd-panel {
  background: #ffffff0a;
}
:where(.dark, [data-theme="dark"]) .bxd-note p {
  color: #c8c8cc;
}
:where(.dark, [data-theme="dark"]) .bxd-tag[data-kind="Fixed"] {
  color: #f5b544;
}
:where(.dark, [data-theme="dark"]) .bxd-tag[data-kind="Improved"] {
  color: #7aa2ff;
}
:where(.dark, [data-theme="dark"]) .bxd-tag[data-kind="Shipped"] {
  color: #34d399;
}
:where(.dark, [data-theme="dark"]) .bxd-dots i {
  background: #ffffff1f;
}
:where(.dark, [data-theme="dark"]) .bxd-dots i[data-on] {
  background: #ededed;
}
:where(.dark, [data-theme="dark"]) .bxd-primary {
  color: #171717;
  background: linear-gradient(#f4f4f5, #dcdce0);
}
:where(.dark, [data-theme="dark"]) .bxd-primary[data-status="done"] {
  color: #fff;
  background: linear-gradient(#1aa774, #0f8a5f);
}
:where(.dark, [data-theme="dark"]) .bxd-spin {
  border-color: #171717 #0003 #0003;
}
:where(.dark, [data-theme="dark"]) .bxd-chip {
  color: #ededed;
  background: #2c2c30;
  box-shadow: 0 0 0 1px #ffffff14;
}
:where(.dark, [data-theme="dark"]) .bxd-chip:hover {
  background: #333338;
}
.card__preview .blur-crossfade-demo {
  position: absolute;
  inset: 0;
}
.card__preview .blur-crossfade-demo .bxd-card {
  zoom: 0.64;
}
`;export{n as default};
