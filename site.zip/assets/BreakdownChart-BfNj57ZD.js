const n=`.ui-bc {
  --ui-bc-tray: #f0f0f0;
  --ui-bc-card: #ffffff;
  --ui-bc-line: #ececec;
  --ui-bc-grid: #ebebeb;
  --ui-bc-ink: #171717;
  --ui-bc-text: #404040;
  --ui-bc-muted: #626873;
  --ui-bc-accent: #2f6bff;
  --ui-bc-accent-ink: #2a5ee5;
  --ui-bc-border: #e5e5e5;
  --ui-bc-surface-hover: #f8f8f8;
  --ui-bc-option-hover: #f5f5f5;
  --ui-bc-zero: #dcdcdc;
  --ui-bc-rest: #f2f2f2;
  --ui-bc-head-bg: #fcfcfc;
  --ui-bc-row-active: #f6f6f6;
  --ui-bc-wash: rgba(0, 0, 0, 0.05);
  --ui-bc-accent-wash: rgba(47, 107, 255, 0.08);
  --ui-bc-focus: rgba(0, 96, 226, 0.7);
  --ui-bc-card-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-bc-btn-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-bc-pop-shadow: 0 10px 28px -8px rgba(0, 0, 0, 0.18);
  --ui-bc-tip-shadow: 0 10px 26px -8px rgba(0, 0, 0, 0.18);
  --ui-bc-pill-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
  --ui-bc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 560px;
  background: var(--ui-bc-tray);
  padding: 6px;
  border-radius: 22px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-bc-ink);
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
}
.ui-bc *,
.ui-bc *::before,
.ui-bc *::after {
  box-sizing: border-box;
}
.ui-bc button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-bc button:focus-visible {
  outline: 2px solid var(--ui-bc-focus);
  outline-offset: 2px;
}
.ui-bc__head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 2px 12px;
  padding: 11px 18px 10px;
  font-size: 14px;
  line-height: 20px;
}
.ui-bc__title {
  flex: 1 1 0;
  min-width: min(120px, 100%);
  overflow: hidden;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__total {
  flex: none;
  max-width: 100%;
  color: var(--ui-bc-muted);
}
.ui-bc__total strong {
  white-space: nowrap;
  font-size: 15px;
  font-weight: 600;
  color: var(--ui-bc-ink);
}
.ui-bc__card {
  overflow: hidden;
  background: var(--ui-bc-card);
  border: 1px solid var(--ui-bc-border);
  border-radius: 16px;
  box-shadow: var(--ui-bc-card-shadow);
}
.ui-bc__controls {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
  padding: 16px 18px 4px;
}
.ui-bc__select {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
  min-width: 0;
}
.ui-bc__select-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bc-muted);
}
.ui-bc__select-btn {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 34px;
  padding: 0 10px 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-btn-shadow);
  font-size: 13px !important;
  font-weight: 500;
  text-align: left;
  transition: background-color 140ms ease;
}
.ui-bc__select-btn span {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__select-btn svg {
  flex: none;
  color: var(--ui-bc-muted);
  transition: transform 200ms var(--ui-bc-ease);
}
.ui-bc__select-btn[aria-expanded="true"] svg {
  transform: rotate(180deg);
}
.ui-bc__select-btn:hover {
  background: var(--ui-bc-surface-hover);
}
.ui-bc__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 6;
  display: grid;
  gap: 2px;
  padding: 4px;
  border-radius: 12px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-pop-shadow);
  animation: ui-bc-drop 180ms var(--ui-bc-ease);
}
.ui-bc__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 13px !important;
  text-align: left;
}
.ui-bc__option {
  gap: 8px;
}
.ui-bc__option span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__option svg {
  flex: none;
}
.ui-bc__option:hover,
.ui-bc__option:focus-visible {
  background: var(--ui-bc-option-hover);
  outline: none;
}
.ui-bc__option[aria-selected="true"] {
  color: var(--ui-bc-accent-ink) !important;
  font-weight: 500;
}
.ui-bc__chart {
  padding: 22px 18px 12px;
}
.ui-bc__plot {
  position: relative;
  height: 200px;
  margin-right: 30px;
}
.ui-bc__grid {
  position: absolute;
  left: 0;
  right: 0;
  height: 0;
  border-top: 1px dashed var(--ui-bc-grid);
}
.ui-bc__grid[data-zero] {
  border-top-style: solid;
  border-color: var(--ui-bc-zero);
}
.ui-bc__tick {
  position: absolute;
  right: -30px;
  top: -8px;
  width: 26px;
  font-size: 11px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-bc-muted);
}
.ui-bc__bars {
  position: absolute;
  inset: 0;
  display: grid;
  gap: 4px;
}
.ui-bc__col {
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  height: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  transition: opacity 200ms ease;
}
.ui-bc__col:focus-visible {
  outline-offset: 2px;
}
.ui-bc__col[data-dim] {
  opacity: 0.38;
}
.ui-bc__rest {
  position: absolute;
  top: 0;
  left: 50%;
  width: min(10px, 100%);
  transform: translateX(-50%);
  background: var(--ui-bc-rest);
  opacity: 0;
  transition:
    opacity 180ms ease,
    bottom 520ms var(--ui-bc-ease);
}
.ui-bc__col[data-active] .ui-bc__rest {
  opacity: 1;
}
.ui-bc__bar {
  position: relative;
  display: flex;
  flex-direction: column-reverse;
  gap: 1px;
  width: min(10px, 100%);
  min-height: 0;
  overflow: hidden;
  transition: height 520ms var(--ui-bc-ease);
}
.ui-bc__seg {
  flex-basis: 0;
  min-height: 2px;
  transition:
    flex-grow 520ms var(--ui-bc-ease),
    background-color 300ms ease;
}
.ui-bc__tooltip {
  position: absolute;
  z-index: 4;
  min-width: 150px;
  padding: 9px 11px 10px;
  border-radius: 12px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-tip-shadow);
  top: 0;
  pointer-events: none;
  max-width: min(260px, 100%);
  transition: left 200ms var(--ui-bc-ease);
  animation: ui-bc-pop 160ms var(--ui-bc-ease);
}
.ui-bc__tip-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
}
.ui-bc__tip-head > strong {
  flex: none;
}
.ui-bc__tip-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-bc__tip-label > span,
.ui-bc__tip-seg,
.ui-bc__pill > span,
.ui-bc__row-label > span,
.ui-bc__th-seg > span:last-child,
.ui-bc__chip > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-bc__tooltip ul {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 2px;
  margin: 6px 0 0;
  padding: 6px 0 0;
  border-top: 1px solid var(--ui-bc-line);
  list-style: none;
}
.ui-bc__tooltip li {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-bc-text);
}
.ui-bc__tip-seg {
  flex: 1;
  white-space: nowrap;
}
.ui-bc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-bc__xaxis {
  display: grid;
  gap: 4px;
  margin: 8px 30px 0 0;
}
.ui-bc__xlabel {
  display: grid;
  place-items: center;
  height: 24px;
  min-width: 0;
  color: var(--ui-bc-muted);
}
.ui-bc__xlabel {
  position: relative;
  overflow: visible;
}
.ui-bc__pill {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 24px;
  padding: 0 10px 0 7px;
  border-radius: 999px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-pill-shadow);
  font-size: 12px;
  font-weight: 500;
  max-width: min(220px, 80cqw);
  white-space: nowrap;
  color: var(--ui-bc-ink);
  transform: translate(-50%, -50%);
  animation: ui-bc-pill 200ms var(--ui-bc-ease);
}
.ui-bc__xtext {
  overflow: hidden;
  max-width: 100%;
  font-size: 11px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__table-wrap {
  overflow-x: auto;
  border-top: 1px solid var(--ui-bc-line);
  scrollbar-width: thin;
}
.ui-bc__table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  line-height: 18px;
}
.ui-bc__table th,
.ui-bc__table td {
  height: 38px;
  padding: 0 14px;
  border-top: 1px solid var(--ui-bc-line);
  text-align: left;
  white-space: nowrap;
}
.ui-bc__table thead th {
  border-top: 0;
  font-weight: 450;
  color: var(--ui-bc-muted);
  background: var(--ui-bc-head-bg);
}
.ui-bc__table [data-num] {
  text-align: right;
}
.ui-bc__table tbody th {
  position: sticky;
  left: 0;
  z-index: 1;
  background: var(--ui-bc-card);
  font-weight: 450;
}
.ui-bc__table tbody tr {
  transition: background-color 140ms ease;
}
.ui-bc__table tbody tr[data-active] th,
.ui-bc__table tbody tr[data-active] td {
  background: var(--ui-bc-row-active);
}
.ui-bc__table td {
  color: var(--ui-bc-text);
}
.ui-bc__table [data-hidden] {
  opacity: 0.35;
}
.ui-bc__row-label,
.ui-bc__th-seg {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  max-width: 220px;
}
.ui-bc__th-seg {
  max-width: 160px;
}
.ui-bc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 44px;
  padding: 6px 10px 7px 10px;
}
.ui-bc__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 2px;
  min-width: 0;
}
.ui-bc__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  white-space: nowrap;
  padding: 0 9px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 12.5px !important;
  color: var(--ui-bc-text) !important;
  transition:
    background-color 140ms ease,
    opacity 160ms ease;
}
.ui-bc__chip:hover {
  background: var(--ui-bc-wash);
}
.ui-bc__chip[aria-pressed="false"] {
  opacity: 0.45;
  text-decoration: line-through;
}
.ui-bc__hint {
  padding-left: 8px;
  font-size: 12.5px;
  color: var(--ui-bc-muted);
}
.ui-bc__reset {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 12.5px !important;
  font-weight: 500;
  color: var(--ui-bc-accent-ink) !important;
}
.ui-bc__reset:hover {
  background: var(--ui-bc-accent-wash);
}
@keyframes ui-bc-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-bc-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-bc-pill {
  from {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.92);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bc__bar,
  .ui-bc__seg,
  .ui-bc__tooltip,
  .ui-bc__col,
  .ui-bc__rest {
    transition: none;
  }
  .ui-bc__menu,
  .ui-bc__tooltip,
  .ui-bc__pill {
    animation: none;
  }
}
.ui-bc__morph {
  overflow: hidden;
}
.ui-bc__morph[data-smooth] {
  transition: height 380ms cubic-bezier(0.22, 1, 0.36, 1);
}
@media (prefers-reduced-motion: reduce) {
  .ui-bc__morph[data-smooth] {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-bc {
  --ui-bc-tray: #161618;
  --ui-bc-card: #232326;
  --ui-bc-line: rgba(255, 255, 255, 0.08);
  --ui-bc-grid: rgba(255, 255, 255, 0.09);
  --ui-bc-ink: #ededed;
  --ui-bc-text: #c4c4c4;
  --ui-bc-muted: #8f8f8f;
  --ui-bc-accent-ink: #6b95ff;
  --ui-bc-border: rgba(255, 255, 255, 0.08);
  --ui-bc-surface-hover: #2a2a2d;
  --ui-bc-option-hover: #313135;
  --ui-bc-zero: rgba(255, 255, 255, 0.16);
  --ui-bc-rest: rgba(255, 255, 255, 0.06);
  --ui-bc-head-bg: #262629;
  --ui-bc-row-active: #2a2a2d;
  --ui-bc-wash: rgba(255, 255, 255, 0.06);
  --ui-bc-accent-wash: rgba(47, 107, 255, 0.16);
  --ui-bc-focus: rgba(77, 141, 255, 0.8);
  --ui-bc-card-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-bc-btn-shadow: 0 1px 2px rgba(0, 0, 0, 0.35);
  --ui-bc-pop-shadow: 0 12px 30px -8px rgba(0, 0, 0, 0.5);
  --ui-bc-tip-shadow: 0 12px 28px -8px rgba(0, 0, 0, 0.5);
  --ui-bc-pill-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-bc__menu,
:where(.dark, [data-theme="dark"]) .ui-bc__tooltip,
:where(.dark, [data-theme="dark"]) .ui-bc__pill {
  background: #2a2a2d;
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.1),
    var(--ui-bc-pop-shadow);
}
:where(.dark, [data-theme="dark"]) .ui-bc__select-btn {
  background: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-bc__select-btn:hover {
  background: #313135;
}
`;export{n as default};
