const n=`.ui-chat-composer {
  --ui-cc-tray: #f0f0f0;
  --ui-cc-card: #ffffff;
  --ui-cc-line: #e5e5e5;
  --ui-cc-ink: #171717;
  --ui-cc-ink-muted: #626873;
  --ui-cc-ink-hover: #404040;
  --ui-cc-ink-faint: #6b6b6b;
  --ui-cc-placeholder: #626873;
  --ui-cc-ink-shine: rgba(255, 255, 255, 0.82);
  --ui-cc-alert: #c33500;
  --ui-cc-alert-wash: rgba(244, 73, 0, 0.1);
  --ui-cc-on-ink: #fff;
  --ui-cc-menu-fill: #f5f5f5;
  --ui-cc-square-hover: #fafafa;
  --ui-cc-shadow: rgba(0, 0, 0, 0.06);
  --ui-cc-focus: rgba(0, 96, 226, 0.7);
  --ui-cc-hover-filter: brightness(0.6);
  --ui-cc-load: 650ms;
  --ui-cc-swap: 620ms;
  --ui-cc-ease-swap: cubic-bezier(0.72, 0, 0.1, 1);
  --ui-cc-ease-out: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-cc-ease-pop: cubic-bezier(0.34, 1.5, 0.64, 1);
  container-type: inline-size;
  position: relative;
  width: 100%;
  max-width: 680px;
}
.ui-chat-composer__body {
  --u: min(calc(100cqw / var(--ui-cc-span, 1900)), 0.27px);
  --ui-cc-frame: 20;
  --ui-cc-inset: calc(var(--ui-cc-frame) * var(--u));
  --ui-cc-card-h: calc(453.576 + var(--ui-cc-grow, 0));
  position: relative;
  height: calc((var(--ui-cc-card-h) + 169 + 2 * var(--ui-cc-frame)) * var(--u));
  transition: height var(--ui-cc-swap) var(--ui-cc-ease-swap);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-weight: 400;
  font-synthesis: none;
  color: var(--ui-cc-ink-muted);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  -webkit-tap-highlight-color: transparent;
}
.ui-chat-composer__body button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: left;
  cursor: pointer;
}
.ui-chat-composer__body svg {
  display: block;
  max-width: none;
}
.ui-chat-composer__tray {
  position: absolute;
  inset: 0;
  background: var(--ui-cc-tray);
  border-radius: calc(92.758 * var(--u));
}
.ui-chat-composer__foot {
  position: absolute;
  left: calc(78.5 * var(--u) + var(--ui-cc-inset));
  right: calc(73 * var(--u) + var(--ui-cc-inset));
  bottom: 0;
  height: calc(169 * var(--u) + var(--ui-cc-inset));
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: calc(48 * var(--u));
}
.ui-chat-composer__row {
  display: flex;
  align-items: center;
  min-width: 0;
  height: calc(68.155 * var(--u));
  border-radius: calc(24 * var(--u));
  white-space: nowrap;
}
.ui-chat-composer__row--folder {
  flex: 0 1 auto;
  gap: calc(26.752 * var(--u));
}
.ui-chat-composer__folder-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-chat-composer__row--apps {
  flex: none;
  gap: calc(36 * var(--u));
  margin-left: auto;
}
.ui-chat-composer__label {
  position: relative;
  display: block;
  font-size: calc(60.453 * var(--u));
  line-height: calc(60.453 * var(--u));
  letter-spacing: calc(-0.5634 * var(--u));
  transition: color 160ms ease;
}
.ui-chat-composer__icon {
  position: relative;
  flex: none;
  width: calc(68.155 * var(--u));
  height: calc(68.155 * var(--u));
}
.ui-chat-composer__icon--folder {
  width: calc(67 * var(--u));
  height: calc(67 * var(--u));
}
.ui-chat-composer__icon--chevron {
  width: calc(52 * var(--u));
  height: calc(52 * var(--u));
}
.ui-chat-composer__icon > svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
}
.ui-chat-composer__icon > svg {
  color: var(--ui-cc-ink-muted);
}
.ui-chat-composer__logos {
  display: flex;
  align-items: center;
  gap: calc(24 * var(--u));
}
.ui-chat-composer__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: calc(50 * var(--u));
  height: calc(50 * var(--u));
}
.ui-chat-composer__logo > svg {
  width: 100%;
  height: 100%;
}
.ui-chat-composer__card {
  position: absolute;
  left: var(--ui-cc-inset);
  top: var(--ui-cc-inset);
  box-sizing: border-box;
  width: calc(100% - 2 * var(--ui-cc-inset));
  height: calc(var(--ui-cc-card-h) * var(--u));
  background: var(--ui-cc-card);
  border: calc(4 * var(--u)) solid var(--ui-cc-line);
  border-radius: calc(66 * var(--u));
  box-shadow: 0 calc(3.092 * var(--u)) calc(6.184 * var(--u))
    var(--ui-cc-shadow);
  overflow: clip;
  cursor: text;
  transition:
    transform var(--ui-cc-swap) var(--ui-cc-ease-swap),
    height var(--ui-cc-swap) var(--ui-cc-ease-swap);
}
.ui-chat-composer__message {
  position: absolute;
  left: calc(66 * var(--u));
  right: calc(69 * var(--u));
  top: calc(83.2 * var(--u));
  box-sizing: border-box;
  height: calc((106.424 + var(--ui-cc-grow, 0)) * var(--u));
  transition: height var(--ui-cc-swap) var(--ui-cc-ease-swap);
  margin: 0;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  resize: none;
  overflow-y: auto;
  scrollbar-width: none;
  font: inherit;
  font-size: calc(73.396 * var(--u));
  line-height: calc(106.424 * var(--u));
  letter-spacing: calc(-1.4679 * var(--u));
  color: var(--ui-cc-ink);
  caret-color: var(--ui-cc-ink);
  text-align: start;
}
.ui-chat-composer__message:focus-visible {
  outline: none;
}
.ui-chat-composer__message::-webkit-scrollbar {
  display: none;
}
.ui-chat-composer__message::placeholder {
  color: var(--ui-cc-placeholder);
  opacity: 1;
}
.ui-chat-composer__toolbar {
  position: absolute;
  left: calc(95.2 * var(--u));
  top: calc((282.476 + var(--ui-cc-grow, 0)) * var(--u));
  height: calc(68.155 * var(--u));
  display: flex;
  align-items: center;
  gap: calc(46.678 * var(--u));
  transform-origin: 0 50%;
  transition:
    transform var(--ui-cc-swap) var(--ui-cc-ease-swap),
    top var(--ui-cc-swap) var(--ui-cc-ease-swap);
}
.ui-chat-composer__toolbar--end {
  left: auto;
  right: calc(73 * var(--u));
  gap: calc(40 * var(--u));
  transform-origin: 100% 50%;
}
.ui-chat-composer__icon-btn,
.ui-chat-composer__model {
  display: flex;
  align-items: center;
  border-radius: calc(24 * var(--u));
}
.ui-chat-composer__model {
  gap: calc(10 * var(--u));
  white-space: nowrap;
}
.ui-chat-composer__icon-btn svg,
.ui-chat-composer__model svg {
  transition: filter 160ms ease;
}
.ui-chat-composer__send {
  position: relative;
  flex: none;
  display: grid;
  place-items: center;
  width: calc(112 * var(--u));
  height: calc(112 * var(--u));
  border-radius: calc(32 * var(--u));
  background: var(--ui-cc-ink) !important;
  transition:
    opacity 200ms ease-out,
    transform 200ms var(--ui-cc-ease-out);
}
.ui-chat-composer__send svg {
  width: calc(60 * var(--u));
  height: calc(60 * var(--u));
}
.ui-chat-composer__send:disabled {
  opacity: 0.18;
  cursor: default;
}
.ui-chat-composer__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-chat-composer__approval {
  position: relative;
  display: flex;
  align-items: center;
  gap: calc(21.783 * var(--u));
  border-radius: calc(24 * var(--u));
  white-space: nowrap;
  transition: padding 480ms var(--ui-cc-ease-out);
}
.ui-chat-composer__wash {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-cc-alert-wash);
  opacity: 0;
  transition: opacity 200ms ease-out;
}
.ui-chat-composer__approval .ui-chat-composer__icon > svg {
  transition:
    opacity 200ms ease-out,
    transform 360ms var(--ui-cc-ease-out),
    filter 160ms ease;
}
.ui-chat-composer__hand {
  transform-origin: 50% 90%;
}
.ui-chat-composer__shield {
  opacity: 0;
  transform: scale(0.4);
}
.ui-chat-composer__approval-text {
  position: relative;
  display: grid;
}
.ui-chat-composer__approval-text > span {
  grid-area: 1 / 1;
  font-size: calc(60.453 * var(--u));
  line-height: calc(60.453 * var(--u));
  letter-spacing: calc(-0.5634 * var(--u));
}
.ui-chat-composer__request {
  transition:
    color 160ms ease,
    opacity 200ms ease-out,
    filter 200ms ease-out;
}
.ui-chat-composer__granted {
  color: var(--ui-cc-alert);
  opacity: 0;
  filter: blur(8px);
  transition:
    opacity 200ms ease-out,
    filter 200ms ease-out;
}
.ui-chat-composer__shimmer {
  position: relative;
}
.ui-chat-composer__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-cc-ink-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  opacity: 0;
  pointer-events: none;
}
.ui-chat-composer__body button:focus-visible {
  outline: 2px solid var(--ui-cc-focus);
  outline-offset: 2px;
}
.ui-chat-composer__row:hover .ui-chat-composer__label,
.ui-chat-composer__row[aria-expanded="true"] .ui-chat-composer__label,
.ui-chat-composer__body[data-approval="idle"]
  .ui-chat-composer__approval:hover
  .ui-chat-composer__request,
.ui-chat-composer__model:hover .ui-chat-composer__label {
  color: var(--ui-cc-ink-hover);
}
.ui-chat-composer__body[data-approval="idle"]
  .ui-chat-composer__approval:hover
  .ui-chat-composer__hand,
.ui-chat-composer__icon-btn:hover svg,
.ui-chat-composer__model:hover svg {
  filter: var(--ui-cc-hover-filter);
}
.ui-chat-composer__body[data-approval="loading"]
  .ui-chat-composer__request::after {
  opacity: 1;
  animation: ui-chat-composer-sweep var(--ui-cc-load) linear 2 both;
}
.ui-chat-composer__body[data-approval="loading"] .ui-chat-composer__hand {
  animation: ui-chat-composer-wave var(--ui-cc-load) ease-in-out 2;
}
@keyframes ui-chat-composer-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@keyframes ui-chat-composer-wave {
  0%,
  76%,
  100% {
    transform: rotate(0deg);
  }
  18% {
    transform: rotate(16deg);
  }
  38% {
    transform: rotate(-10deg);
  }
  58% {
    transform: rotate(7deg);
  }
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__approval {
  padding: calc(22.104 * var(--u));
  cursor: default;
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__wash {
  opacity: 1;
  transition: opacity 300ms ease-out;
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__hand {
  opacity: 0;
  transform: scale(0.4) rotate(-14deg);
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__shield {
  opacity: 1;
  transform: none;
  transition:
    opacity 220ms ease-out 90ms,
    transform 520ms var(--ui-cc-ease-pop) 90ms;
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__request {
  opacity: 0;
  filter: blur(8px);
}
.ui-chat-composer__body[data-approval="done"] .ui-chat-composer__granted {
  opacity: 1;
  filter: blur(0);
  transition:
    opacity 320ms ease-out 90ms,
    filter 320ms ease-out 90ms;
}
.ui-chat-composer__sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@media (prefers-reduced-motion: reduce) {
  .ui-chat-composer *,
  .ui-chat-composer *::after {
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
  .ui-chat-composer__hand {
    animation: none !important;
  }
}
.ui-chat-composer__row,
.ui-chat-composer__icon-btn,
.ui-chat-composer__model {
  transition: transform 160ms var(--ui-cc-ease-out);
}
.ui-chat-composer__row:active,
.ui-chat-composer__icon-btn:active,
.ui-chat-composer__model:active {
  transform: scale(0.96);
}
.ui-chat-composer__model {
  overflow: clip;
}
.ui-chat-composer__model-face {
  display: inline-flex;
  align-items: center;
  min-width: 0;
}
.ui-chat-composer__model-name {
  max-width: calc(400 * var(--u));
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-chat-composer__model-face[data-morph] {
  animation: ui-chat-composer-model-in 460ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-chat-composer__model-face[data-morph] .ui-chat-composer__model-logo {
  animation: ui-chat-composer-logo-in 520ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
@keyframes ui-chat-composer-model-in {
  from {
    opacity: 0;
    filter: blur(3px);
    transform: translateY(30%);
  }
}
@keyframes ui-chat-composer-logo-in {
  from {
    opacity: 0;
    transform: scale(0.6) rotate(-12deg);
  }
}
.ui-chat-composer__model-logo {
  display: grid;
  flex: none;
  place-items: center;
  width: calc(50 * var(--u));
  height: calc(50 * var(--u));
  margin-right: calc(6 * var(--u));
  color: var(--ui-cc-ink);
}
.ui-chat-composer__model-logo svg,
.ui-chat-composer__option-logo svg {
  width: 100%;
  height: 100%;
}
.ui-chat-composer__model[aria-expanded="true"] .ui-chat-composer__label {
  color: var(--ui-cc-ink-hover);
}
.ui-chat-composer__model[aria-expanded="true"]
  .ui-chat-composer__icon--chevron
  svg {
  transform: rotate(180deg);
}
.ui-chat-composer__icon--chevron svg {
  transition:
    transform 220ms var(--ui-cc-ease-out),
    filter 160ms ease;
}
.ui-chat-composer__menu {
  --morph: 420ms cubic-bezier(0.32, 0.72, 0, 1);
  position: absolute;
  z-index: 5;
  width: calc(1100 * var(--u));
  filter: drop-shadow(
      0 calc(24 * var(--u)) calc(48 * var(--u)) rgba(0, 0, 0, 0.08)
    )
    drop-shadow(0 calc(4 * var(--u)) calc(10 * var(--u)) rgba(0, 0, 0, 0.05));
  transition: visibility 0s linear 0s;
}
.ui-chat-composer__menu[data-open="false"] {
  visibility: hidden;
  pointer-events: none;
  transition: visibility 0s linear 300ms;
}
.ui-chat-composer__menu-panel {
  position: relative;
  box-sizing: border-box;
  padding: calc(20 * var(--u));
  display: flex;
  flex-direction: column;
  background: var(--ui-cc-card);
  border: calc(4 * var(--u)) solid var(--ui-cc-line);
  border-radius: calc(92.758 * var(--u));
  outline: none;
  font-family: inherit;
  clip-path: inset(0 0 0 0 round calc(92.758 * var(--u)));
  transition: clip-path var(--morph);
  max-height: calc(1100 * var(--u));
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-chat-composer__menu[data-placing="true"] .ui-chat-composer__menu-panel {
  transition: none !important;
}
.ui-chat-composer__menu[data-open="false"] .ui-chat-composer__menu-panel {
  clip-path: inset(
    var(--from-top) 0 var(--from-bottom) var(--from-left) round
      var(--from-radius)
  );
  transition: clip-path 300ms cubic-bezier(0.4, 0, 0.2, 1);
}
.ui-chat-composer__menu-panel > * {
  transition:
    opacity 220ms ease-out 110ms,
    transform 380ms var(--ui-cc-ease-out) 60ms;
}
.ui-chat-composer__menu[data-open="false"] .ui-chat-composer__menu-panel > * {
  opacity: 0;
  transition: opacity 120ms ease-in;
}
.ui-chat-composer__menu[data-open="false"] .ui-chat-composer__option {
  transform: translateY(calc(12 * var(--u)));
}
.ui-chat-composer__menu[data-open="false"][data-up="false"]
  .ui-chat-composer__option {
  transform: translateY(calc(-12 * var(--u)));
}
.ui-chat-composer__menu-panel:focus-visible {
  outline: none;
}
.ui-chat-composer__menu-fill {
  position: absolute;
  left: calc(20 * var(--u));
  right: calc(20 * var(--u));
  top: 0;
  border-radius: calc(68.758 * var(--u));
  background: var(--ui-cc-menu-fill);
  pointer-events: none;
  transition:
    transform 190ms cubic-bezier(0.25, 1, 0.3, 1),
    height 190ms cubic-bezier(0.25, 1, 0.3, 1),
    opacity 160ms ease-out;
}
.ui-chat-composer__menu-fill[data-glide="false"] {
  transition: opacity 160ms ease-out;
}
.ui-chat-composer__menu-title {
  padding: calc(24 * var(--u)) calc(48 * var(--u)) calc(12 * var(--u));
  font-size: calc(44 * var(--u));
  line-height: 1.25;
  color: var(--ui-cc-ink-muted);
}
.ui-chat-composer__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: calc(34 * var(--u));
  padding: calc(32 * var(--u)) calc(48 * var(--u));
  border-radius: calc(68.758 * var(--u));
  cursor: pointer;
}
.ui-chat-composer__option-logo {
  display: grid;
  place-items: center;
  flex: none;
  width: calc(64 * var(--u));
  height: calc(64 * var(--u));
  color: var(--ui-cc-ink);
}
.ui-chat-composer__option-text {
  display: flex;
  flex-direction: column;
  gap: calc(8 * var(--u));
  min-width: 0;
  flex: 1;
}
.ui-chat-composer__option-name {
  overflow-wrap: anywhere;
  text-align: start;
  font-size: calc(58 * var(--u));
  line-height: 1.2;
  font-weight: 500;
  letter-spacing: calc(-0.5 * var(--u));
  color: var(--ui-cc-ink);
}
.ui-chat-composer__option-desc {
  text-align: start;
  font-size: calc(44 * var(--u));
  line-height: 1.25;
  color: var(--ui-cc-ink-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-chat-composer__option-check {
  flex: none;
  width: calc(56 * var(--u));
  height: calc(56 * var(--u));
  color: var(--ui-cc-ink);
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 160ms ease-out,
    transform 260ms var(--ui-cc-ease-pop);
}
.ui-chat-composer__option-check svg {
  width: 100%;
  height: 100%;
}
.ui-chat-composer__option[data-checked] .ui-chat-composer__option-check {
  opacity: 1;
  transform: none;
}
.ui-chat-composer__send svg {
  color: var(--ui-cc-on-ink);
}
.ui-chat-composer__toolbar--end {
  transition:
    opacity 220ms ease-out,
    transform 320ms var(--ui-cc-ease-out);
}
.ui-chat-composer__draft {
  position: absolute;
  text-align: start;
  left: calc(66 * var(--u));
  right: calc(69 * var(--u));
  top: calc(83.2 * var(--u));
  height: calc((106.424 + var(--ui-cc-grow, 0)) * var(--u));
  overflow: hidden;
  white-space: pre-wrap;
  overflow-wrap: break-word;
  font-size: calc(73.396 * var(--u));
  line-height: calc(106.424 * var(--u));
  letter-spacing: calc(-1.4679 * var(--u));
  color: var(--ui-cc-ink);
  pointer-events: none;
  visibility: hidden;
}
.ui-chat-composer__heard {
  color: var(--ui-cc-ink-faint);
}
.ui-chat-composer__body[data-recording="true"] .ui-chat-composer__draft {
  visibility: visible;
}
.ui-chat-composer__body[data-recording="true"] .ui-chat-composer__message {
  color: transparent;
  caret-color: transparent;
}
.ui-chat-composer__body[data-recording="true"]
  .ui-chat-composer__message::placeholder {
  color: transparent;
}
.ui-chat-composer__trace {
  display: flex;
  align-items: center;
  gap: calc(14 * var(--u));
  height: calc(68 * var(--u));
  margin-right: calc(10 * var(--u));
}
.ui-chat-composer__trace > span {
  flex: none;
  width: calc(8 * var(--u));
  border-radius: 999px;
  background: var(--ui-cc-ink-hover);
  transition: height 110ms ease-out;
}
.ui-chat-composer__square {
  flex: none;
  display: grid !important;
  place-items: center;
  box-sizing: border-box;
  width: calc(112 * var(--u));
  height: calc(112 * var(--u));
  border: calc(4 * var(--u)) solid var(--ui-cc-line) !important;
  border-radius: calc(32 * var(--u)) !important;
  background: var(--ui-cc-card) !important;
  box-shadow: 0 calc(3.092 * var(--u)) calc(6.184 * var(--u))
    var(--ui-cc-shadow);
  color: var(--ui-cc-ink) !important;
  transition:
    background-color 160ms ease,
    transform 160ms var(--ui-cc-ease-out);
}
.ui-chat-composer__square:hover {
  background: var(--ui-cc-square-hover) !important;
}
.ui-chat-composer__square:active {
  transform: scale(0.95);
}
.ui-chat-composer__square svg {
  width: calc(56 * var(--u));
  height: calc(56 * var(--u));
  color: var(--ui-cc-ink);
}
.ui-chat-composer__toolbar--voice {
  gap: calc(24 * var(--u));
  opacity: 0;
  transform: translateY(calc(16 * var(--u)));
  pointer-events: none;
}
.ui-chat-composer__body[data-recording="true"]
  .ui-chat-composer__toolbar--end:not(.ui-chat-composer__toolbar--voice) {
  opacity: 0;
  transform: translateY(calc(-16 * var(--u)));
  pointer-events: none;
}
.ui-chat-composer__body[data-recording="true"]
  .ui-chat-composer__toolbar--voice {
  opacity: 1;
  transform: none;
  pointer-events: auto;
}
@media (prefers-reduced-motion: reduce) {
  .ui-chat-composer__model-face[data-morph],
  .ui-chat-composer__model-face[data-morph] .ui-chat-composer__model-logo {
    animation: none;
  }
}
.ui-chat-composer
  input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-chat-composer textarea:focus-visible,
.ui-chat-composer [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-chat-composer {
  --ui-cc-tray: #161618;
  --ui-cc-card: #262629;
  --ui-cc-line: rgba(255, 255, 255, 0.08);
  --ui-cc-ink: #ededed;
  --ui-cc-ink-muted: #8f8f8f;
  --ui-cc-ink-hover: #c4c4c4;
  --ui-cc-ink-faint: #6b6b70;
  --ui-cc-placeholder: #5f5f64;
  --ui-cc-ink-shine: rgba(255, 255, 255, 0.95);
  --ui-cc-alert: #ff6a2b;
  --ui-cc-alert-wash: rgba(244, 73, 0, 0.16);
  --ui-cc-on-ink: #121213;
  --ui-cc-menu-fill: #313135;
  --ui-cc-square-hover: #2e2e32;
  --ui-cc-shadow: rgba(0, 0, 0, 0.4);
  --ui-cc-focus: rgba(77, 141, 255, 0.8);
  --ui-cc-hover-filter: brightness(1.5);
}
:where(.dark, [data-theme="dark"]) .ui-chat-composer__menu {
  filter: drop-shadow(
      0 calc(24 * var(--u)) calc(48 * var(--u)) rgba(0, 0, 0, 0.45)
    )
    drop-shadow(0 calc(4 * var(--u)) calc(10 * var(--u)) rgba(0, 0, 0, 0.35));
}
`;export{n as default};
