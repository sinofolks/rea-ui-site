const n=`.ui-ca {
  --ui-ca-tray: #f0f0f0;
  --ui-ca-card: #ffffff;
  --ui-ca-line: #ececec;
  --ui-ca-ink: #171717;
  --ui-ca-text: #404040;
  --ui-ca-muted: #626873;
  --ui-ca-faded: #626873;
  --ui-ca-well: #f4f4f5;
  --ui-ca-accent: #2f6bff;
  --ui-ca-hl: rgba(47, 107, 255, 0.1);
  --ui-ca-mark: rgba(47, 107, 255, 0.16);
  --ui-ca-ok: #18794e;
  --ui-ca-focus: rgba(0, 96, 226, 0.7);
  --ui-ca-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 460px;
  min-width: 0;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ca-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ca-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ca *,
.ui-ca *::before,
.ui-ca *::after {
  box-sizing: border-box;
}
:where(.ui-ca) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ca :is(button, a):focus-visible {
  outline: 2px solid var(--ui-ca-focus);
  outline-offset: 2px;
}
.ui-ca svg {
  display: block;
  flex: none;
}
.ui-ca b {
  font-weight: 500;
  color: var(--ui-ca-ink);
}
.ui-ca [data-tone="blue"] {
  --ui-ca-g: #1f55d6;
  --ui-ca-g-bg: rgba(47, 107, 255, 0.12);
}
.ui-ca [data-tone="violet"] {
  --ui-ca-g: #6941c6;
  --ui-ca-g-bg: rgba(124, 92, 255, 0.13);
}
.ui-ca [data-tone="green"] {
  --ui-ca-g: #18794e;
  --ui-ca-g-bg: rgba(34, 160, 90, 0.13);
}
.ui-ca [data-tone="amber"] {
  --ui-ca-g: #96590a;
  --ui-ca-g-bg: rgba(240, 160, 32, 0.18);
}
.ui-ca [data-tone="gray"] {
  --ui-ca-g: #5f5f66;
  --ui-ca-g-bg: rgba(110, 110, 120, 0.12);
}
.ui-ca__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-ca-g-bg);
  font-size: 9.5px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-ca-g);
}
.ui-ca__glyph > :is(img, svg) {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-ca__card {
  padding: 12px 16px 14px;
  border-radius: 16px;
  background: var(--ui-ca-card);
  box-shadow:
    0 0 0 1px var(--ui-ca-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-ca__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 22px;
}
.ui-ca__stack {
  display: flex;
  flex: none;
}
.ui-ca__stack .ui-ca__glyph {
  box-shadow: 0 0 0 1.5px var(--ui-ca-card);
}
.ui-ca__stack .ui-ca__glyph + .ui-ca__glyph {
  margin-left: -4px;
}
.ui-ca__meta {
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-ca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-ca__text {
  margin-top: 8px;
  color: var(--ui-ca-text);
}
.ui-ca__p {
  margin: 0;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  font-size: 13.5px;
  line-height: 23px;
}
.ui-ca__p + .ui-ca__p {
  margin-top: 10px;
}
.ui-ca__seg {
  margin: 0 -2px;
  padding: 2px 2px;
  border-radius: 5px;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  transition:
    background-color 220ms ease,
    color 220ms ease;
}
.ui-ca__seg[data-hl] {
  background: var(--ui-ca-hl);
  color: var(--ui-ca-ink);
}
.ui-ca__seg[data-dim] {
  color: var(--ui-ca-faded);
}
.ui-ca__keep {
  white-space: nowrap;
}
.ui-ca[data-hot] .ui-ca__marker:not([data-lit]):not([aria-expanded="true"]) {
  opacity: 0.5;
}
.ui-ca__marker {
  position: relative;
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  margin-left: 3px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-ca-well);
  box-shadow: inset 0 0 0 1px var(--ui-ca-line);
  font-size: 10.5px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-ca-text);
  vertical-align: 1px;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 180ms ease,
    color 180ms ease,
    box-shadow 180ms ease,
    opacity 220ms ease;
}
.ui-ca__marker + .ui-ca__marker {
  margin-left: 2px;
}
.ui-ca__marker::after {
  content: "";
  position: absolute;
  inset: -4px -2px;
}
.ui-ca__marker:hover,
.ui-ca__marker[data-lit] {
  background: var(--ui-ca-accent);
  box-shadow: inset 0 0 0 1px var(--ui-ca-accent);
  color: #fff;
}
.ui-ca__marker[aria-expanded="true"] {
  background: var(--ui-ca-ink);
  box-shadow: inset 0 0 0 1px var(--ui-ca-ink);
  color: var(--ui-ca-card);
}
.ui-ca__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-ca-ease),
    opacity 220ms ease;
}
.ui-ca__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-ca-ease),
    opacity 320ms ease 80ms;
}
.ui-ca__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-ca__preview {
  margin-top: 12px;
  padding: 10px 12px 12px;
  border-radius: 12px;
  background: var(--ui-ca-well);
  animation: ui-ca-swap-in 320ms ease both;
}
.ui-ca__pv-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 22px;
}
.ui-ca__pv-meta {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-ca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ca__pv-date {
  flex: none;
  white-space: pre;
}
.ui-ca__pv-domain {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--ui-ca-text);
}
.ui-ca__pv-num {
  display: grid;
  flex: none;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-ca-card);
  box-shadow: inset 0 0 0 1px var(--ui-ca-line);
  font-size: 10.5px;
  font-weight: 600;
  color: var(--ui-ca-text);
  font-variant-numeric: tabular-nums;
}
.ui-ca__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  margin-right: -4px;
  border-radius: 7px;
  color: var(--ui-ca-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ca__close:hover {
  background: var(--ui-ca-line);
  color: var(--ui-ca-ink);
}
.ui-ca__pv-title {
  display: -webkit-box;
  overflow-wrap: anywhere;
  text-align: start;
  margin-top: 6px;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-ca-ink);
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-ca__quote {
  margin: 8px 0 0;
  max-height: 200px;
  overflow: auto;
  overscroll-behavior: contain;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  padding: 0 0 0 10px;
  border-left: 2px solid var(--ui-ca-line);
  font-size: 12.5px;
  line-height: 20px;
  color: var(--ui-ca-text);
}
.ui-ca__quote mark {
  margin: 0 -1px;
  padding: 1px 1px;
  border-radius: 3px;
  background: var(--ui-ca-mark);
  color: var(--ui-ca-ink);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}
.ui-ca__pv-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  margin-top: 12px;
}
.ui-ca__btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 28px;
  padding: 0 9px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ca-text);
  text-decoration: none;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ca__btn:hover {
  background: var(--ui-ca-line);
  color: var(--ui-ca-ink);
}
.ui-ca__btn--main {
  padding: 0 8px 0 10px;
  background: var(--ui-ca-card);
  box-shadow:
    0 0 0 1px var(--ui-ca-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-ca-ink);
}
.ui-ca__btn--main:hover {
  background: var(--ui-ca-card);
}
.ui-ca__btn--main svg {
  transition: transform 220ms var(--ui-ca-ease);
}
.ui-ca__btn--main:hover svg {
  transform: translate(1px, -1px);
}
.ui-ca__btn[data-done] {
  color: var(--ui-ca-ok);
}
.ui-ca__btn-icon {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
  animation: ui-ca-swap-in 280ms ease both;
}
.ui-ca__chips {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding: 6px 4px 0;
}
.ui-ca__chip-item {
  display: flex;
  min-width: 0;
  max-width: 100%;
}
.ui-ca__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: 28px;
  padding: 0 8px 0 6px;
  border-radius: 8px;
  font-size: 12.5px;
  color: var(--ui-ca-text);
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    opacity 220ms ease,
    color 160ms ease;
}
.ui-ca__chip:hover,
.ui-ca__chip[data-lit] {
  background: var(--ui-ca-card);
  box-shadow:
    0 0 0 1px var(--ui-ca-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-ca-ink);
}
.ui-ca__chip[aria-expanded="true"] {
  background: var(--ui-ca-card);
  box-shadow:
    0 0 0 1px var(--ui-ca-line),
    0 1px 2px rgba(0, 0, 0, 0.04),
    inset 0 0 0 1px color-mix(in srgb, var(--ui-ca-ink) 45%, transparent);
  color: var(--ui-ca-ink);
}
.ui-ca__chip[data-dim] {
  opacity: 0.45;
}
.ui-ca__chip-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ca__chip-num {
  flex: none;
  font-size: 11.5px;
  color: var(--ui-ca-muted);
  font-variant-numeric: tabular-nums;
}
.ui-ca__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 36px;
  padding: 2px 4px 0 10px;
}
.ui-ca__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-ca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-ca__swap {
  display: grid;
  min-width: 0;
}
.ui-ca__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-ca-swap-in 320ms ease both;
}
.ui-ca__swap-item[data-out] {
  animation: ui-ca-swap-out 220ms ease both;
}
.ui-ca__swap-item[data-tone="ok"] {
  color: var(--ui-ca-ok);
}
.ui-ca__action {
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  align-items: center;
  gap: 4px;
  height: 26px;
  padding: 0 6px 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ca-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ca__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ca__action:hover {
  background: var(--ui-ca-card);
  color: var(--ui-ca-ink);
}
.ui-ca__action svg {
  transition: transform 220ms var(--ui-ca-ease);
}
.ui-ca__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-ca-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-ca-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@container (max-width: 360px) {
  .ui-ca__card {
    padding: 12px 14px 12px;
  }
  .ui-ca__pv-num {
    display: none;
  }
}
@container (max-width: 280px) {
  .ui-ca__btn-text {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-ca__marker::after {
    inset: -8px -5px;
  }
  .ui-ca__chip {
    height: 34px;
  }
  .ui-ca__btn {
    height: 34px;
  }
  .ui-ca__close {
    width: 30px;
    height: 30px;
    margin-right: -7px;
  }
  .ui-ca__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ca *,
  .ui-ca *::before,
  .ui-ca *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ca {
  --ui-ca-tray: #111113;
  --ui-ca-card: #19191b;
  --ui-ca-line: #2a2a2e;
  --ui-ca-ink: #ededed;
  --ui-ca-text: #c8c8cc;
  --ui-ca-muted: #8b8b92;
  --ui-ca-faded: #5c5c63;
  --ui-ca-well: #222225;
  --ui-ca-accent: #4f82ff;
  --ui-ca-hl: rgba(79, 130, 255, 0.16);
  --ui-ca-mark: rgba(79, 130, 255, 0.28);
  --ui-ca-ok: #6ee7a8;
  --ui-ca-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ca [data-tone="blue"] {
  --ui-ca-g: #9bb8ff;
  --ui-ca-g-bg: rgba(79, 130, 255, 0.2);
}
:where(.dark, [data-theme="dark"]) .ui-ca [data-tone="violet"] {
  --ui-ca-g: #c3b1ff;
  --ui-ca-g-bg: rgba(124, 92, 255, 0.22);
}
:where(.dark, [data-theme="dark"]) .ui-ca [data-tone="green"] {
  --ui-ca-g: #6ee7a8;
  --ui-ca-g-bg: rgba(34, 160, 90, 0.2);
}
:where(.dark, [data-theme="dark"]) .ui-ca [data-tone="amber"] {
  --ui-ca-g: #f5c264;
  --ui-ca-g-bg: rgba(240, 160, 32, 0.2);
}
:where(.dark, [data-theme="dark"]) .ui-ca [data-tone="gray"] {
  --ui-ca-g: #b4b4bb;
  --ui-ca-g-bg: rgba(110, 110, 120, 0.22);
}
`;export{n as default};
