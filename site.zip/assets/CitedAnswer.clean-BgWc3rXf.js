const n=`.ui-cac {
  --ui-cac-card: #ffffff;
  --ui-cac-ink: rgba(0, 0, 0, 0.88);
  --ui-cac-strong: #000000;
  --ui-cac-text: rgba(0, 0, 0, 0.65);
  --ui-cac-muted: rgba(0, 0, 0, 0.65);
  --ui-cac-faint: rgba(0, 0, 0, 0.65);
  --ui-cac-icon: rgba(0, 0, 0, 0.65);
  --ui-cac-line: rgba(0, 0, 0, 0.06);
  --ui-cac-fill: rgba(0, 0, 0, 0.06);
  --ui-cac-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-cac-wash: rgba(0, 0, 0, 0.03);
  --ui-cac-hl: rgba(0, 96, 226, 0.07);
  --ui-cac-mark: rgba(0, 96, 226, 0.1);
  --ui-cac-ok: #0f783c;
  --ui-cac-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cac-focus: rgba(0, 96, 226, 0.7);
  --ui-cac-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 460px;
  min-width: 0;
  container-type: inline-size;
  border-radius: 10px;
  background: var(--ui-cac-card);
  box-shadow: var(--ui-cac-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cac-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-cac *,
.ui-cac *::before,
.ui-cac *::after {
  box-sizing: border-box;
}
:where(.ui-cac) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-cac :is(button, a):focus-visible {
  outline: 2px solid var(--ui-cac-focus);
  outline-offset: 2px;
}
.ui-cac svg {
  display: block;
  flex: none;
}
.ui-cac b {
  font-weight: 500;
  color: var(--ui-cac-ink);
}
.ui-cac__dot {
  color: var(--ui-cac-faint);
}
.ui-cac__icon {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cac [data-tone="blue"] {
  --ui-cac-g: #1f5fd1;
  --ui-cac-g-bg: rgba(0, 96, 226, 0.08);
}
.ui-cac [data-tone="violet"] {
  --ui-cac-g: #6a4fd0;
  --ui-cac-g-bg: rgba(110, 86, 230, 0.09);
}
.ui-cac [data-tone="green"] {
  --ui-cac-g: #14783e;
  --ui-cac-g-bg: rgba(26, 154, 82, 0.09);
}
.ui-cac [data-tone="amber"] {
  --ui-cac-g: #915e01;
  --ui-cac-g-bg: rgba(232, 162, 12, 0.12);
}
.ui-cac [data-tone="gray"] {
  --ui-cac-g: rgba(0, 0, 0, 0.65);
  --ui-cac-g-bg: rgba(0, 0, 0, 0.06);
}
.ui-cac__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-cac-g-bg);
  font-size: 9.5px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-cac-g);
}
.ui-cac__glyph > :is(img, svg) {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-cac__body {
  padding: 16px 20px 16px;
}
.ui-cac__head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 16px;
}
.ui-cac__stack {
  display: flex;
  flex: none;
}
.ui-cac__stack .ui-cac__glyph {
  box-shadow: 0 0 0 1.5px var(--ui-cac-card);
}
.ui-cac__stack .ui-cac__glyph + .ui-cac__glyph {
  margin-left: -4px;
}
.ui-cac__meta {
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cac-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-cac__text {
  margin-top: 12px;
  color: var(--ui-cac-ink);
}
.ui-cac__p {
  margin: 0;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  font-size: 13px;
  line-height: 22px;
}
.ui-cac__p + .ui-cac__p {
  margin-top: 10px;
}
.ui-cac__seg {
  margin: 0 -2px;
  padding: 2px 2px;
  border-radius: 4px;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-cac__seg[data-hl] {
  background: var(--ui-cac-hl);
  color: var(--ui-cac-strong);
}
.ui-cac__seg[data-dim] {
  color: var(--ui-cac-faint);
}
.ui-cac__keep {
  white-space: nowrap;
}
.ui-cac[data-hot] .ui-cac__marker:not([data-lit]):not([aria-expanded="true"]) {
  opacity: 0.5;
}
.ui-cac__marker {
  position: relative;
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  margin-left: 3px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-cac-fill);
  box-shadow: inset 0 0 0 0.5px var(--ui-cac-line);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cac-text);
  vertical-align: 1px;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-cac__marker + .ui-cac__marker {
  margin-left: 2px;
}
.ui-cac__marker::after {
  content: "";
  position: absolute;
  inset: -4px -2px;
}
.ui-cac__marker:hover,
.ui-cac__marker[data-lit],
.ui-cac__marker[aria-expanded="true"] {
  background: var(--ui-cac-fill-strong);
  color: var(--ui-cac-ink);
}
.ui-cac__chips {
  display: flex;
  gap: 4px;
  margin-top: 16px;
  min-width: 0;
}
.ui-cac__chips[data-all] {
  flex-wrap: wrap;
}
.ui-cac__chip-item {
  display: flex;
  flex: none;
  min-width: 0;
  max-width: 100%;
}
.ui-cac__chip-item:only-child,
.ui-cac__chips:not([data-all])
  .ui-cac__chip-item:first-child:nth-last-child(2) {
  flex: 0 1 auto;
}
.ui-cac__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  height: 28px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cac-line);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cac-text);
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    opacity 200ms ease;
}
.ui-cac__chip:hover,
.ui-cac__chip[data-lit] {
  background: var(--ui-cac-wash);
  color: var(--ui-cac-ink);
}
.ui-cac__chip[aria-expanded="true"] {
  background: var(--ui-cac-fill);
  color: var(--ui-cac-ink);
}
.ui-cac__chip[data-dim]:not([aria-expanded="true"]) {
  opacity: 0.5;
}
.ui-cac__chip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cac__chip-num {
  flex: none;
  margin-left: -1px;
  font-size: 11px;
  font-weight: 400;
  color: var(--ui-cac-faint);
  font-variant-numeric: tabular-nums;
}
.ui-cac__more {
  display: inline-grid;
  flex: none;
  place-items: center;
  height: 28px;
  padding: 0 8px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cac-line);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cac-text);
  font-variant-numeric: tabular-nums;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-cac__more:hover {
  background: var(--ui-cac-wash);
  color: var(--ui-cac-ink);
}
.ui-cac__ruler {
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  gap: 4px;
  height: 0;
  overflow: hidden;
  visibility: hidden;
  pointer-events: none;
}
.ui-cac__ruler > * {
  flex: none;
}
.ui-cac__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-cac-ease),
    opacity 220ms ease;
}
.ui-cac__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-cac-ease),
    opacity 320ms ease 80ms;
}
.ui-cac__clip {
  min-height: 0;
  overflow: hidden;
  margin: 0 -4px -4px;
  padding: 0 4px 4px;
}
.ui-cac__preview {
  margin-top: 12px;
  padding: 10px 12px 12px;
  border-radius: 8px;
  background: var(--ui-cac-card);
  box-shadow: var(--ui-cac-shadow);
  animation: ui-cac-swap-in 320ms ease both;
}
.ui-cac__pv-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 24px;
}
.ui-cac__pv-date {
  flex: none;
  white-space: pre;
}
.ui-cac__pv-meta {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cac-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cac__pv-domain {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--ui-cac-text);
}
.ui-cac__pv-num {
  display: grid;
  flex: none;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-cac-fill);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cac-text);
  font-variant-numeric: tabular-nums;
}
.ui-cac__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  margin-right: -6px;
  border-radius: 6px;
  color: var(--ui-cac-icon);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-cac__close:hover {
  background: var(--ui-cac-wash);
  color: var(--ui-cac-ink);
}
.ui-cac__pv-title {
  display: -webkit-box;
  overflow-wrap: anywhere;
  text-align: start;
  margin-top: 6px;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cac-strong);
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-cac__quote {
  margin: 8px 0 0;
  max-height: 200px;
  overflow: auto;
  overscroll-behavior: contain;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  padding: 0 0 0 10px;
  border-left: 2px solid var(--ui-cac-fill);
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-cac-text);
}
.ui-cac__quote mark {
  margin: 0 -1px;
  padding: 1px 1px;
  border-radius: 3px;
  background: var(--ui-cac-mark);
  color: var(--ui-cac-ink);
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}
.ui-cac__pv-actions {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
}
.ui-cac__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cac-text);
  text-decoration: none;
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-cac__btn .ui-cac__icon {
  color: var(--ui-cac-icon);
  transition:
    color 140ms ease,
    transform 220ms var(--ui-cac-ease);
}
.ui-cac__btn:hover {
  background: var(--ui-cac-wash);
  color: var(--ui-cac-ink);
}
.ui-cac__btn:hover .ui-cac__icon {
  color: var(--ui-cac-ink);
}
.ui-cac__btn--main {
  background: var(--ui-cac-card);
  box-shadow: var(--ui-cac-shadow);
  color: var(--ui-cac-strong);
}
.ui-cac__btn--main:hover {
  background: #fafafa;
  color: var(--ui-cac-strong);
}
.ui-cac__btn--main:hover .ui-cac__icon {
  transform: translate(1px, -1px);
}
.ui-cac__btn[data-done],
.ui-cac__btn[data-done] .ui-cac__icon {
  color: var(--ui-cac-ok);
}
.ui-cac__btn-icon {
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  animation: ui-cac-swap-in 280ms ease both;
}
.ui-cac__foot {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 44px;
  padding: 0 8px 0 20px;
  border-top: 0.5px solid var(--ui-cac-line);
}
.ui-cac__foot:not(:has(.ui-cac__action)) {
  padding-right: 20px;
}
.ui-cac__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cac-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-cac__swap {
  display: grid;
  min-width: 0;
}
.ui-cac__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cac-swap-in 320ms ease both;
}
.ui-cac__swap-item[data-out] {
  animation: ui-cac-swap-out 220ms ease both;
}
.ui-cac__swap-item[data-tone="ok"] {
  color: var(--ui-cac-ok);
}
.ui-cac__action {
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 8px 0 10px;
  border-radius: 6px;
  background: var(--ui-cac-card);
  box-shadow: var(--ui-cac-shadow);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cac-strong);
  white-space: nowrap;
  transition: background-color 140ms ease;
}
.ui-cac__action .ui-cac__icon {
  color: var(--ui-cac-icon);
  transition:
    transform 220ms var(--ui-cac-ease),
    color 140ms ease;
}
.ui-cac__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cac__action:hover {
  background: #fafafa;
}
.ui-cac__action:hover .ui-cac__icon {
  color: var(--ui-cac-ink);
  transform: translateX(2px);
}
@keyframes ui-cac-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cac-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@container (max-width: 400px) {
  .ui-cac__body {
    padding: 14px 16px 16px;
  }
  .ui-cac__foot {
    padding-left: 16px;
  }
}
@container (max-width: 360px) {
  .ui-cac__pv-num {
    display: none;
  }
}
@container (max-width: 280px) {
  .ui-cac__btn-text {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-cac__marker::after {
    inset: -8px -5px;
  }
  .ui-cac__chip,
  .ui-cac__more {
    height: 34px;
  }
  .ui-cac__btn {
    height: 34px;
  }
  .ui-cac__close {
    width: 32px;
    height: 32px;
    margin-right: -8px;
  }
  .ui-cac__action {
    height: 34px;
  }
  .ui-cac__foot {
    height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cac *,
  .ui-cac *::before,
  .ui-cac *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cac {
  --ui-cac-card: #1c1c1e;
  --ui-cac-ink: rgba(255, 255, 255, 0.9);
  --ui-cac-strong: #ffffff;
  --ui-cac-text: rgba(255, 255, 255, 0.62);
  --ui-cac-muted: rgba(255, 255, 255, 0.46);
  --ui-cac-faint: rgba(255, 255, 255, 0.3);
  --ui-cac-icon: rgba(255, 255, 255, 0.5);
  --ui-cac-line: rgba(255, 255, 255, 0.08);
  --ui-cac-fill: rgba(255, 255, 255, 0.08);
  --ui-cac-fill-strong: rgba(255, 255, 255, 0.14);
  --ui-cac-wash: rgba(255, 255, 255, 0.04);
  --ui-cac-hl: rgba(77, 141, 255, 0.14);
  --ui-cac-mark: rgba(77, 141, 255, 0.24);
  --ui-cac-ok: #3ec27a;
  --ui-cac-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-cac-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-cac__btn--main:hover,
:where(.dark, [data-theme="dark"]) .ui-cac__action:hover {
  background: #232326;
}
:where(.dark, [data-theme="dark"]) .ui-cac [data-tone="blue"] {
  --ui-cac-g: #9bbcff;
  --ui-cac-g-bg: rgba(77, 141, 255, 0.16);
}
:where(.dark, [data-theme="dark"]) .ui-cac [data-tone="violet"] {
  --ui-cac-g: #c3b4ff;
  --ui-cac-g-bg: rgba(124, 92, 255, 0.18);
}
:where(.dark, [data-theme="dark"]) .ui-cac [data-tone="green"] {
  --ui-cac-g: #6ee7a8;
  --ui-cac-g-bg: rgba(34, 160, 90, 0.16);
}
:where(.dark, [data-theme="dark"]) .ui-cac [data-tone="amber"] {
  --ui-cac-g: #f5c264;
  --ui-cac-g-bg: rgba(240, 160, 32, 0.16);
}
:where(.dark, [data-theme="dark"]) .ui-cac [data-tone="gray"] {
  --ui-cac-g: rgba(255, 255, 255, 0.62);
  --ui-cac-g-bg: rgba(255, 255, 255, 0.08);
}
`;export{n as default};
