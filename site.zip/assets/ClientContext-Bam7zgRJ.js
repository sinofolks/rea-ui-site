const n=`.ui-cx {
  --ui-cx-focus: rgba(0, 96, 226, 0.7);
  --ui-cx-tray: #f0f0f0;
  --ui-cx-card: #ffffff;
  --ui-cx-card-line: #e5e5e5;
  --ui-cx-line: #ececec;
  --ui-cx-line-strong: #dcdcdc;
  --ui-cx-inset: #f6f6f6;
  --ui-cx-ink: #171717;
  --ui-cx-text: #404040;
  --ui-cx-muted: #8f8f8f;
  --ui-cx-accent: #4fb0fe;
  --ui-cx-good: #1e8a4f;
  --ui-cx-bad: #c21f78;
  --ui-cx-mark: rgba(1, 144, 254, 0.16);
  --ui-cx-hover: rgba(0, 0, 0, 0.04);
  --ui-cx-track: rgba(0, 0, 0, 0.05);
  --ui-cx-thumb: #ffffff;
  --ui-cx-btn-top: #323137;
  --ui-cx-btn-bottom: #201e25;
  --ui-cx-btn-ring: #0d0d0d;
  --ui-cx-btn-text: #ffffff;
  --ui-cx-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-cx-pop: 0 0 0 1px rgba(0, 0, 0, 0.06), 0 12px 32px rgba(0, 0, 0, 0.1);
  --ui-cx-ease: cubic-bezier(0.65, 0, 0.25, 1);
  --ui-cx-out: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-cx-spring: cubic-bezier(0.34, 1.3, 0.64, 1);
  container-type: inline-size;
  width: 100%;
  max-width: 900px;
  padding: 0 6px 6px;
  border-radius: 24px;
  background: var(--ui-cx-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  color: var(--ui-cx-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cx *,
.ui-cx *::before,
.ui-cx *::after {
  box-sizing: border-box;
}
.ui-cx :where(button) {
  margin: 0;
  font: inherit;
  color: inherit;
}
.ui-cx :where(p, h2, h3, ol, ul) {
  margin: 0;
}
.ui-cx :where(ol, ul) {
  padding: 0;
  list-style: none;
}
.ui-cx mark {
  border-radius: 3px;
  background: var(--ui-cx-mark);
  color: inherit;
}
.ui-cx__icon {
  width: 15px;
  height: 15px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cx__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 16px 10px 14px 12px;
}
.ui-cx__who {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  animation: ui-cx-in 360ms var(--ui-cx-out);
}
.ui-cx__who-text {
  display: grid;
  gap: 2px;
  min-width: 0;
}
.ui-cx__name {
  overflow: hidden;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cx__meta {
  font-size: 12.5px;
  color: var(--ui-cx-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cx__mark {
  display: grid;
  place-items: center;
  flex: none;
  border-radius: 30%;
  font-weight: 650;
  line-height: 1;
  box-shadow: inset 0 0 0 1px rgba(0, 0, 0, 0.08);
}
.ui-cx__actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex: none;
}
.ui-cx__chip-btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-cx-card);
  box-shadow:
    0 0 0 1px var(--ui-cx-card-line),
    var(--ui-cx-shadow);
  font-size: 12.5px;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background 160ms ease,
    box-shadow 160ms ease,
    transform 120ms ease;
}
.ui-cx__chip-btn:hover:not(:disabled) {
  background: var(--ui-cx-inset);
}
.ui-cx__chip-btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-cx__chip-btn:disabled {
  opacity: 0.6;
  cursor: default;
}
.ui-cx__chip-btn[data-active] {
  box-shadow:
    0 0 0 1px var(--ui-cx-accent),
    var(--ui-cx-shadow);
  color: var(--ui-cx-accent);
}
.ui-cx__chip-btn > .ui-cx__icon:last-child:not(:first-child) {
  color: var(--ui-cx-muted);
}
.ui-cx__sync {
  gap: 8px;
  color: var(--ui-cx-text);
}
.ui-cx__sync-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #29be6d;
  box-shadow: 0 0 0 3px rgba(95, 200, 138, 0.16);
  transition:
    background 200ms ease,
    box-shadow 200ms ease;
}
.ui-cx__sync-dot[data-state="syncing"] {
  background: #e8b000;
  box-shadow: 0 0 0 3px rgba(232, 176, 0, 0.18);
}
.ui-cx__spin {
  display: grid;
  color: var(--ui-cx-muted);
}
.ui-cx__spin[data-spinning] .ui-cx__icon {
  animation: ui-cx-spin 0.9s linear infinite;
}
@keyframes ui-cx-spin {
  to {
    transform: rotate(360deg);
  }
}
.ui-cx__pop {
  position: relative;
}
.ui-cx__menu {
  position: absolute;
  left: 0;
  top: calc(100% + 6px);
  z-index: 5;
  min-width: 230px;
  max-width: min(320px, calc(100cqw - 24px));
  padding: 5px;
  border-radius: 14px;
  background: var(--ui-cx-card);
  box-shadow: var(--ui-cx-pop);
  transform-origin: top left;
  animation: ui-cx-pop 180ms var(--ui-cx-out);
}
.ui-cx__menu--end {
  left: auto;
  right: 0;
  transform-origin: top right;
}
@keyframes ui-cx-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.97);
  }
}
.ui-cx__menu-item {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 36px;
  padding: 0 10px 0 8px;
  border: 0;
  border-radius: 9px;
  background: transparent;
  text-align: left;
  cursor: pointer;
}
.ui-cx__menu-item:hover,
.ui-cx__menu-item[aria-selected="true"] {
  background: var(--ui-cx-hover);
}
.ui-cx__menu-label {
  flex: 1;
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cx__menu-item > .ui-cx__icon {
  color: var(--ui-cx-muted);
}
.ui-cx__menu-count {
  color: var(--ui-cx-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cx__menu-check {
  display: grid;
  width: 15px;
  color: var(--ui-cx-accent);
}
.ui-cx__menu-sep {
  height: 1px;
  margin: 5px 4px;
  background: var(--ui-cx-line);
}
.ui-cx__menu-plus {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 6px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-text);
}
.ui-cx__menu-plus .ui-cx__icon {
  width: 12px;
  height: 12px;
}
.ui-cx__create {
  display: flex;
  gap: 6px;
  padding: 3px;
}
.ui-cx__create input {
  flex: 1;
  min-width: 0;
  height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  outline: none;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-ink);
  font: inherit;
}
.ui-cx__create input:focus {
  box-shadow: inset 0 0 0 1px var(--ui-cx-muted);
}
.ui-cx__kpis {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
  margin-bottom: 6px;
}
.ui-cx__kpi {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
  min-width: 0;
  padding: 14px 16px;
  border: 0;
  border-radius: 16px;
  background: var(--ui-cx-card);
  box-shadow:
    0 0 0 1px var(--ui-cx-card-line),
    var(--ui-cx-shadow);
  text-align: left;
  cursor: pointer;
  transition:
    box-shadow 200ms ease,
    transform 160ms ease;
  animation: ui-cx-in 360ms var(--ui-cx-out) both;
}
.ui-cx__kpi:nth-child(2) {
  animation-delay: 40ms;
}
.ui-cx__kpi:nth-child(3) {
  animation-delay: 80ms;
}
.ui-cx__kpi:nth-child(4) {
  animation-delay: 120ms;
}
.ui-cx__kpi:hover {
  box-shadow:
    0 0 0 1px var(--ui-cx-line-strong),
    var(--ui-cx-shadow);
}
.ui-cx__kpi:active {
  transform: scale(0.98);
}
.ui-cx__kpi[aria-pressed="true"] {
  box-shadow:
    0 0 0 1.5px var(--ui-cx-accent),
    var(--ui-cx-shadow);
}
.ui-cx__kpi-label {
  overflow: hidden;
  font-size: 12.5px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-cx-text);
}
.ui-cx__kpi-row {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  justify-content: space-between;
  gap: 8px;
}
.ui-cx__kpi-value {
  font-size: 20px;
  font-weight: 600;
  letter-spacing: -0.02em;
  line-height: 1.1;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  max-width: 100%;
}
.ui-cx__spark {
  flex: none;
  width: 56px;
  height: 22px;
  overflow: visible;
}
.ui-cx__spark[data-wide] {
  width: 84px;
}
.ui-cx__spark path {
  fill: none;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  vector-effect: non-scaling-stroke;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-cx-draw 700ms var(--ui-cx-out) forwards;
}
.ui-cx__spark circle {
  opacity: 0;
  animation: ui-cx-fade 240ms ease forwards;
}
@keyframes ui-cx-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-cx-fade {
  to {
    opacity: 1;
  }
}
@keyframes ui-cx-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
.ui-cx__card {
  border-radius: 20px;
  background: var(--ui-cx-card);
  box-shadow:
    0 0 0 1px var(--ui-cx-card-line),
    var(--ui-cx-shadow);
}
.ui-cx__toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 14px;
  border-bottom: 1px solid var(--ui-cx-line);
}
.ui-cx__seg {
  position: relative;
  display: grid;
  grid-template-columns: repeat(4, 84px);
  padding: 3px;
  border-radius: 10px;
  background: var(--ui-cx-track);
}
.ui-cx__seg-thumb {
  position: absolute;
  top: 3px;
  left: 3px;
  width: 84px;
  height: calc(100% - 6px);
  border-radius: 7px;
  background: var(--ui-cx-thumb);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  transform: translateX(calc(var(--i, 0) * 100%));
  transition: transform 420ms var(--ui-cx-spring);
}
.ui-cx__seg button {
  position: relative;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 7px;
  background: none;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-cx-muted) !important;
  cursor: pointer;
  transition: color 200ms ease;
}
.ui-cx__seg button[aria-selected="true"] {
  color: var(--ui-cx-ink) !important;
}
.ui-cx__tools {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-cx__search {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 220px;
  height: 34px;
  padding: 0 8px 0 11px;
  border-radius: 10px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-muted);
  transition:
    box-shadow 160ms ease,
    background 160ms ease;
}
.ui-cx__search:focus-within {
  background: var(--ui-cx-card);
  box-shadow: inset 0 0 0 1px var(--ui-cx-muted);
}
.ui-cx__search input {
  flex: 1;
  min-width: 0;
  height: 100%;
  border: 0;
  outline: none;
  background: transparent;
  color: var(--ui-cx-ink);
  font: inherit;
}
.ui-cx__search input::placeholder {
  color: var(--ui-cx-muted);
}
.ui-cx__clear {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--ui-cx-muted);
  cursor: pointer;
}
.ui-cx__clear:hover {
  background: var(--ui-cx-hover);
  color: var(--ui-cx-ink);
}
.ui-cx__clear .ui-cx__icon {
  width: 12px;
  height: 12px;
}
.ui-cx__panel {
  padding: 22px 24px 26px;
  animation: ui-cx-in 300ms var(--ui-cx-out);
}
.ui-cx__compose {
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr);
  gap: 14px;
  align-items: start;
}
.ui-cx__compose > .ui-cx__avatar {
  margin-top: 6px;
}
.ui-cx__composer {
  position: relative;
  border-radius: 14px;
  background: var(--ui-cx-card);
  box-shadow:
    0 0 0 1px var(--ui-cx-card-line),
    var(--ui-cx-shadow);
  transition: box-shadow 160ms ease;
}
.ui-cx__composer:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-cx-muted),
    var(--ui-cx-shadow);
}
.ui-cx__composer textarea {
  display: block;
  width: 100%;
  min-height: 62px;
  max-height: 180px;
  padding: 12px 14px 4px;
  border: 0;
  outline: none;
  resize: none;
  background: transparent;
  color: var(--ui-cx-ink);
  font: inherit;
  line-height: 1.55;
  field-sizing: content;
}
.ui-cx__composer textarea::placeholder {
  color: var(--ui-cx-muted);
}
.ui-cx__suggest {
  position: absolute;
  left: 10px;
  top: calc(100% - 40px);
  z-index: 4;
  min-width: 220px;
  padding: 5px;
  border-radius: 12px;
  background: var(--ui-cx-card);
  box-shadow: var(--ui-cx-pop);
  animation: ui-cx-pop 160ms var(--ui-cx-out);
}
.ui-cx__attached {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding: 6px 14px 2px;
}
.ui-cx__file-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 4px 0 8px;
  border-radius: 8px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-text);
  font-size: 12px;
  animation: ui-cx-pop 200ms var(--ui-cx-out);
}
.ui-cx__file-chip button {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--ui-cx-muted);
  cursor: pointer;
}
.ui-cx__file-chip button:hover {
  background: var(--ui-cx-hover);
  color: var(--ui-cx-ink);
}
.ui-cx__file-chip .ui-cx__icon {
  width: 12px;
  height: 12px;
}
.ui-cx__file-chip .ui-cx__file-icon {
  margin: 0;
}
.ui-cx__file-chip {
  max-width: 100%;
}
.ui-cx__file-chip button,
.ui-cx__file-chip .ui-cx__file-icon {
  flex: none;
}
.ui-cx__file-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cx__composer-bar {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px 10px;
}
.ui-cx__icon-btn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-cx-muted);
  cursor: pointer;
  transition:
    background 160ms ease,
    color 160ms ease;
}
.ui-cx__icon-btn:hover:not(:disabled) {
  background: var(--ui-cx-hover);
  color: var(--ui-cx-ink);
}
.ui-cx__icon-btn:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-cx__hint {
  display: inline-flex;
  gap: 3px;
  margin-left: auto;
}
.ui-cx__hint kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-muted);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
}
.ui-cx__primary {
  height: 32px;
  padding: 0 14px;
  border: 0;
  border-radius: 9px;
  background: linear-gradient(var(--ui-cx-btn-top), var(--ui-cx-btn-bottom));
  box-shadow:
    0 0 0 1px var(--ui-cx-btn-ring),
    inset 0 1px 0 rgba(255, 255, 255, 0.14);
  color: var(--ui-cx-btn-text) !important;
  font-size: 12.5px;
  font-weight: 500;
  white-space: nowrap;
  cursor: pointer;
  transition:
    opacity 160ms ease,
    transform 120ms ease;
}
.ui-cx__primary:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-cx__primary:disabled {
  opacity: 0.35;
  cursor: default;
}
.ui-cx__timeline {
  position: relative;
  margin-top: 28px;
}
.ui-cx__timeline::before {
  content: "";
  position: absolute;
  left: 13.5px;
  top: 14px;
  bottom: 14px;
  width: 1px;
  background: var(--ui-cx-line);
}
.ui-cx__item {
  position: relative;
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr);
  gap: 14px;
  padding-bottom: 26px;
}
.ui-cx__item:last-child {
  padding-bottom: 0;
}
.ui-cx__item[data-fresh] {
  animation: ui-cx-new 520ms var(--ui-cx-out);
}
@keyframes ui-cx-new {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
}
.ui-cx__node {
  position: relative;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: var(--ui-cx-card);
  box-shadow:
    0 0 0 1px var(--ui-cx-line-strong),
    0 0 0 5px var(--ui-cx-card);
  color: var(--ui-cx-muted);
}
.ui-cx__node .ui-cx__icon {
  width: 13px;
  height: 13px;
}
.ui-cx__node[data-kind="integration"] {
  background: transparent;
  box-shadow: 0 0 0 5px var(--ui-cx-card);
}
.ui-cx__stripe {
  display: block;
  width: 26px;
  height: 26px;
}
.ui-cx__body {
  min-width: 0;
  padding-top: 4px;
}
.ui-cx__line {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  min-height: 20px;
  color: var(--ui-cx-text);
  line-height: 20px;
}
.ui-cx__line > .ui-cx__avatar {
  margin-top: 0;
}
.ui-cx__line > span:not(.ui-cx__when, .ui-cx__avatar) {
  flex: 0 1 auto;
  min-width: 0;
}
.ui-cx__line strong {
  color: var(--ui-cx-ink);
  font-weight: 500;
}
.ui-cx__when {
  flex: none;
  color: var(--ui-cx-muted);
  white-space: nowrap;
}
.ui-cx__when::before {
  content: "·";
  margin-right: 8px;
}
.ui-cx__ref {
  display: inline;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ui-cx-ink);
  font-weight: 500;
  text-decoration: underline;
  text-decoration-color: var(--ui-cx-line-strong);
  text-underline-offset: 3px;
  transition: text-decoration-color 160ms ease;
}
button.ui-cx__ref {
  cursor: pointer;
  text-align: left;
}
button.ui-cx__ref:hover {
  text-decoration-color: currentColor;
}
.ui-cx__file {
  white-space: nowrap;
}
.ui-cx__file .ui-cx__ref {
  white-space: normal;
  overflow-wrap: anywhere;
}
.ui-cx__line > span:not(.ui-cx__when, .ui-cx__avatar) {
  overflow-wrap: anywhere;
}
.ui-cx__file-icon {
  display: inline-block;
  width: 12px;
  height: 14px;
  margin: 0 4px 0 2px;
  vertical-align: -2px;
}
.ui-cx__remove {
  display: grid;
  place-items: center;
  flex: none;
  width: 22px;
  height: 22px;
  margin: -1px 0 0 auto;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: transparent;
  color: var(--ui-cx-muted);
  opacity: 0;
  cursor: pointer;
  transition:
    opacity 160ms ease,
    background 160ms ease,
    color 160ms ease;
}
.ui-cx__item:hover .ui-cx__remove,
.ui-cx__remove:focus-visible {
  opacity: 1;
}
@media (hover: none) {
  .ui-cx__remove {
    opacity: 1;
  }
}
.ui-cx__remove:hover {
  background: var(--ui-cx-hover);
  color: var(--ui-cx-bad);
}
.ui-cx__remove .ui-cx__icon {
  width: 13px;
  height: 13px;
}
.ui-cx__note {
  margin-top: 10px;
  padding: 12px 14px;
  border-radius: 12px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-text);
  line-height: 1.6;
  overflow-wrap: anywhere;
}
.ui-cx__mention {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  margin: 0 1px;
  padding: 0 6px 0 5px;
  border: 0;
  border-radius: 6px;
  background: color-mix(in srgb, var(--ui-cx-accent) 10%, transparent);
  color: var(--ui-cx-accent) !important;
  font-weight: 500;
  line-height: 20px;
  vertical-align: -1px;
  white-space: nowrap;
  cursor: pointer;
  transition: background 160ms ease;
}
.ui-cx__mention {
  max-width: 100%;
}
.ui-cx__mention > span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cx__mention:hover {
  background: color-mix(in srgb, var(--ui-cx-accent) 16%, transparent);
}
.ui-cx__mention .ui-cx__icon {
  width: 12px;
  height: 12px;
}
.ui-cx__avatar {
  display: block;
  flex: none;
  border-radius: 50%;
  object-fit: cover;
}
.ui-cx__avatar--initial {
  display: grid;
  place-items: center;
  background: var(--ui-cx-inset);
  color: var(--ui-cx-text);
  font-weight: 600;
}
.ui-cx__empty {
  margin-top: 28px;
  padding: 22px;
  border-radius: 14px;
  background: var(--ui-cx-inset);
  color: var(--ui-cx-muted);
  text-align: center;
}
.ui-cx__empty--flush {
  margin-top: 0;
}
.ui-cx__card--none {
  margin-top: 6px;
}
.ui-cx__none {
  padding: 40px 20px;
  color: var(--ui-cx-muted);
  text-align: center;
}
.ui-cx__empty button {
  padding: 0;
  border: 0;
  background: none;
  color: var(--ui-cx-ink);
  font-weight: 500;
  text-decoration: underline;
  text-underline-offset: 3px;
  cursor: pointer;
}
.ui-cx__list {
  overflow: hidden;
  border-radius: 14px;
  box-shadow: 0 0 0 1px var(--ui-cx-line);
}
.ui-cx__list > li + li {
  border-top: 1px solid var(--ui-cx-line);
}
.ui-cx__row {
  display: flex;
  align-items: center;
  gap: 14px;
  min-height: 66px;
  padding: 12px 16px;
}
.ui-cx__row-main {
  display: grid;
  gap: 3px;
  flex: 1;
  min-width: 0;
  text-align: left;
}
.ui-cx__row-main strong {
  overflow: hidden;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-cx-ink);
}
.ui-cx__row-main span {
  color: var(--ui-cx-muted);
  font-size: 12.5px;
}
.ui-cx__row-icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  background: var(--ui-cx-inset);
  box-shadow: inset 0 0 0 1px var(--ui-cx-line);
  color: var(--ui-cx-muted);
}
.ui-cx__app {
  display: grid;
  flex: none;
}
.ui-cx__app .ui-cx__stripe {
  width: 32px;
  height: 32px;
}
.ui-cx__report-head {
  display: flex;
  align-items: center;
  gap: 14px;
  width: 100%;
  min-height: 66px;
  padding: 12px 16px;
  border: 0;
  background: transparent;
  cursor: pointer;
  transition: background 160ms ease;
}
.ui-cx__report-head:hover {
  background: var(--ui-cx-hover);
}
.ui-cx__chevron {
  display: grid;
  color: var(--ui-cx-muted);
  transition: transform 300ms var(--ui-cx-ease);
}
.ui-cx__report[data-open] .ui-cx__chevron {
  transform: rotate(180deg);
}
.ui-cx__report-body {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 320ms var(--ui-cx-ease);
}
.ui-cx__report[data-open] .ui-cx__report-body {
  grid-template-rows: 1fr;
}
.ui-cx__report-body > div {
  overflow: hidden;
  padding: 0 16px 0 62px;
}
.ui-cx__report-body p {
  color: var(--ui-cx-text);
  line-height: 1.6;
  overflow-wrap: anywhere;
}
.ui-cx__report-actions {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  padding: 14px 0 18px;
}
.ui-cx__fin button {
  display: flex;
  align-items: center;
  gap: 14px;
  width: 100%;
  min-height: 66px;
  padding: 12px 16px;
  border: 0;
  background: transparent;
  cursor: pointer;
  transition: background 200ms ease;
}
.ui-cx__fin button:hover {
  background: var(--ui-cx-hover);
}
.ui-cx__fin[data-active] button {
  background: color-mix(in srgb, var(--ui-cx-accent) 6%, transparent);
}
.ui-cx__fin-dot {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 50%;
}
.ui-cx__fin-value {
  display: grid;
  justify-items: end;
  gap: 3px;
  min-width: 84px;
}
.ui-cx__fin-value strong {
  font-size: 14px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.ui-cx__fin-value span {
  font-size: 12px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-cx__fin-value [data-trend="up"] {
  color: var(--ui-cx-good);
}
.ui-cx__fin-value [data-trend="down"] {
  color: var(--ui-cx-bad);
}
.ui-cx__toggle {
  position: relative;
  flex: none;
  width: 36px;
  height: 22px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: var(--ui-cx-line-strong);
  cursor: pointer;
  transition: background 200ms ease;
}
.ui-cx__toggle span {
  position: absolute;
  left: 2px;
  top: 2px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  transition: transform 260ms var(--ui-cx-spring);
}
.ui-cx__toggle[aria-checked="true"] {
  background: var(--ui-cx-accent);
}
.ui-cx__toggle[aria-checked="true"] span {
  transform: translateX(14px);
}
.ui-cx button:focus-visible {
  outline: 2px solid var(--ui-cx-focus);
  outline-offset: 2px;
}
.ui-cx .ui-cx__report-head:focus-visible,
.ui-cx .ui-cx__fin button:focus-visible {
  outline-offset: -2px;
}
@container (max-width: 680px) {
  .ui-cx__head {
    flex-wrap: wrap;
  }
  .ui-cx__actions {
    width: 100%;
  }
  .ui-cx__actions > .ui-cx__pop {
    margin-left: auto;
  }
  .ui-cx__actions > .ui-cx__sync {
    min-width: 0;
  }
  .ui-cx__sync > span:not([class]) {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .ui-cx__kpis {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
  .ui-cx__toolbar {
    flex-direction: column;
    align-items: stretch;
  }
  .ui-cx__seg {
    grid-template-columns: repeat(4, minmax(0, 1fr));
  }
  .ui-cx__seg-thumb {
    width: calc((100% - 6px) / 4);
  }
  .ui-cx__tools {
    width: 100%;
  }
  .ui-cx__search {
    flex: 1;
    width: auto;
  }
  .ui-cx__panel {
    padding: 18px 16px 20px;
  }
  .ui-cx__hint {
    display: none;
  }
  .ui-cx__composer-bar .ui-cx__primary {
    margin-left: auto;
  }
  .ui-cx__fin .ui-cx__spark {
    display: none;
  }
  .ui-cx__report-body > div {
    padding-left: 16px;
  }
  .ui-cx__line {
    flex-wrap: wrap;
    row-gap: 2px;
  }
  .ui-cx__line > span:not(.ui-cx__when, .ui-cx__avatar) {
    flex: 1 1 calc(100% - 28px);
  }
  .ui-cx__when {
    order: 3;
    margin-left: 28px;
  }
  .ui-cx__when::before {
    content: none;
  }
  .ui-cx__file {
    white-space: normal;
  }
}
@media (pointer: coarse) {
  .ui-cx__chip-btn {
    height: 40px;
  }
  .ui-cx__primary {
    height: 38px;
  }
  .ui-cx__seg button {
    height: 34px;
  }
  .ui-cx__search {
    height: 40px;
  }
  .ui-cx__create input {
    height: 38px;
  }
  .ui-cx__search input,
  .ui-cx__create input,
  .ui-cx__composer textarea {
    font-size: 16px;
  }
  .ui-cx__icon-btn {
    width: 38px;
    height: 38px;
  }
  .ui-cx__clear {
    width: 30px;
    height: 30px;
  }
  .ui-cx__menu-item {
    height: 42px;
  }
  .ui-cx__file-chip {
    height: 34px;
  }
  .ui-cx__file-chip button {
    width: 30px;
    height: 30px;
  }
  .ui-cx__remove {
    width: 34px;
    height: 34px;
    margin-top: -7px;
    opacity: 1;
  }
  .ui-cx__toggle {
    width: 42px;
    height: 26px;
  }
  .ui-cx__toggle span {
    width: 22px;
    height: 22px;
  }
  .ui-cx__toggle[aria-checked="true"] span {
    transform: translateX(16px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cx *,
  .ui-cx *::before,
  .ui-cx *::after {
    animation-duration: 1ms !important;
    transition-duration: 1ms !important;
  }
}
.ui-cx input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-cx textarea:focus-visible,
.ui-cx [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-cx {
  --ui-cx-focus: rgba(77, 141, 255, 0.8);
  --ui-cx-tray: #161618;
  --ui-cx-card: #232326;
  --ui-cx-card-line: rgba(255, 255, 255, 0.08);
  --ui-cx-line: rgba(255, 255, 255, 0.07);
  --ui-cx-line-strong: rgba(255, 255, 255, 0.14);
  --ui-cx-inset: #1c1c1f;
  --ui-cx-ink: #ededed;
  --ui-cx-text: #c4c4c4;
  --ui-cx-muted: #8f8f8f;
  --ui-cx-accent: #4fb0fe;
  --ui-cx-good: #5fc88a;
  --ui-cx-bad: #ff8a7a;
  --ui-cx-mark: rgba(79, 176, 254, 0.28);
  --ui-cx-hover: rgba(255, 255, 255, 0.05);
  --ui-cx-track: rgba(255, 255, 255, 0.06);
  --ui-cx-thumb: #313135;
  --ui-cx-btn-top: #f4f4f5;
  --ui-cx-btn-bottom: #e4e4e7;
  --ui-cx-btn-ring: rgba(0, 0, 0, 0.6);
  --ui-cx-btn-text: #121213;
  --ui-cx-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-cx-pop:
    0 0 0 1px rgba(255, 255, 255, 0.06), 0 16px 40px rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-cx__toggle span {
  background: #ededed;
}
:where(.dark, [data-theme="dark"]) .ui-cx__mark {
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}

.context-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.context-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.card__preview .context-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.context-demo[data-fit="card"] .context-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 24px;
}
.context-demo__frame {
  min-width: 0;
}
`;export{n as default};
