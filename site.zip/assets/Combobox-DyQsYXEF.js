const n=`.ui-cbx {
  --ui-cbx-tray: #f0f0f0;
  --ui-cbx-card: #ffffff;
  --ui-cbx-line: #ececec;
  --ui-cbx-ink: #171717;
  --ui-cbx-text: #404040;
  --ui-cbx-muted: #626873;
  --ui-cbx-faint: #6b6b6b;
  --ui-cbx-edge: #d4d4d8;
  --ui-cbx-active: #f0f0f1;
  --ui-cbx-chip: #f4f4f5;
  --ui-cbx-chip-line: #e6e6e8;
  --ui-cbx-armed: #e4e4e7;
  --ui-cbx-flash: #d9d9dd;
  --ui-cbx-avatar: #e9e9ec;
  --ui-cbx-avatar-ink: #5b5b62;
  --ui-cbx-mark: rgba(47, 107, 255, 0.14);
  --ui-cbx-accent: #2f6bff;
  --ui-cbx-ring: rgba(23, 23, 23, 0.08);
  --ui-cbx-focus: rgba(0, 96, 226, 0.7);
  --ui-cbx-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.18),
    0 4px 12px -4px rgba(0, 0, 0, 0.06);
  --ui-cbx-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-cbx-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  position: relative;
  display: block;
  width: 100%;
  max-width: 440px;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.4;
  color: var(--ui-cbx-text);
  -webkit-font-smoothing: antialiased;
}
.ui-cbx *,
.ui-cbx *::before,
.ui-cbx *::after {
  box-sizing: border-box;
}
:where(.ui-cbx) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cbx) svg {
  display: block;
  flex: none;
}
.ui-cbx__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cbx__label {
  display: block;
  margin: 0 0 7px 2px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-cbx-ink);
}
.ui-cbx__field {
  position: relative;
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cbx-card);
  box-shadow:
    0 0 0 1px var(--ui-cbx-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  cursor: text;
  transition:
    height 300ms var(--ui-cbx-ease),
    box-shadow 160ms ease;
}
.ui-cbx__field:hover {
  box-shadow:
    0 0 0 1px var(--ui-cbx-edge),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cbx__field:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-cbx-edge),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cbx__field-inner {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  row-gap: 4px;
  min-height: 40px;
  padding: 6px 40px 6px 6px;
}
.ui-cbx__field-inner {
  max-height: 140px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-cbx__chips {
  display: contents;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-cbx__chip {
  display: grid;
  grid-template-columns: 1fr;
  min-width: 0;
  max-width: 100%;
  overflow: hidden;
  margin-right: 4px;
  transition:
    grid-template-columns 260ms var(--ui-cbx-ease) 160ms,
    margin-right 260ms var(--ui-cbx-ease) 160ms,
    opacity 200ms ease 140ms;
}
.ui-cbx__chip[data-leaving] {
  grid-template-columns: 0fr;
  margin-right: 0;
  opacity: 0;
  pointer-events: none;
}
.ui-cbx__chip-body {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 28px;
  overflow: hidden;
  padding: 0 3px 0 5px;
  border-radius: 8px;
  background: var(--ui-cbx-chip);
  box-shadow: inset 0 0 0 1px var(--ui-cbx-chip-line);
  white-space: nowrap;
  color: var(--ui-cbx-ink);
  font-size: 13px;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-cbx__chip[data-plain] .ui-cbx__chip-body {
  padding-left: 9px;
}
.ui-cbx__chip[data-armed] .ui-cbx__chip-body {
  background: var(--ui-cbx-armed);
  box-shadow: inset 0 0 0 1px var(--ui-cbx-faint);
}
.ui-cbx__chip[data-leaving] .ui-cbx__chip-body {
  animation: ui-cbx-flash 300ms ease-out both;
}
.ui-cbx__chip-label {
  min-width: 0;
  max-width: 168px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cbx__chip-x {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  border-radius: 6px;
  color: var(--ui-cbx-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-cbx__chip-x:hover {
  background: var(--ui-cbx-armed);
  color: var(--ui-cbx-ink);
}
.ui-cbx__chip-x .ui-cbx__glyph {
  width: 13px;
  height: 13px;
  stroke-width: 2;
}
.ui-cbx__chip .ui-cbx__avatar {
  width: 18px;
  height: 18px;
  font-size: 8.5px;
}
.ui-cbx__chip .ui-cbx__dot {
  margin: 0 2px;
}
.ui-cbx__more .ui-cbx__chip-body {
  padding: 0 9px;
  color: var(--ui-cbx-text);
  font-variant-numeric: tabular-nums;
}
.ui-cbx__more {
  transition-delay: 0ms;
}
.ui-cbx__more[data-hidden] {
  grid-template-columns: 0fr;
  margin-right: 0;
  opacity: 0;
}
.ui-cbx__roll {
  display: inline-grid;
  overflow: hidden;
}
.ui-cbx__roll > span {
  animation: ui-cbx-roll-up 300ms var(--ui-cbx-ease) both;
}
.ui-cbx__roll > span[data-dir="down"] {
  animation-name: ui-cbx-roll-down;
}
.ui-cbx__input {
  flex: 1 0 72px;
  min-width: 72px;
  height: 28px;
  margin: 0;
  padding: 0 4px 0 6px;
  border: 0;
  background: transparent;
  font: inherit;
  color: var(--ui-cbx-ink);
  outline: none;
}
.ui-cbx__input::placeholder {
  color: var(--ui-cbx-faint);
}
.ui-cbx__toggle {
  position: absolute;
  top: 6px;
  right: 6px;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-cbx-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-cbx__toggle:hover {
  background: var(--ui-cbx-active);
  color: var(--ui-cbx-ink);
}
.ui-cbx__toggle .ui-cbx__glyph {
  transition: transform 260ms var(--ui-cbx-ease);
}
.ui-cbx[data-open] .ui-cbx__toggle .ui-cbx__glyph {
  transform: rotate(180deg);
}
.ui-cbx__avatar {
  display: grid;
  place-items: center;
  flex: none;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  object-fit: cover;
  background: var(--ui-cbx-avatar);
  color: var(--ui-cbx-avatar-ink);
  font-size: 9.5px;
  font-weight: 600;
  letter-spacing: 0.02em;
}
.ui-cbx__dot {
  flex: none;
  width: 8px;
  height: 8px;
  margin: 0 4px;
  border-radius: 50%;
}
.ui-cbx__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 18px;
  height: 18px;
  color: var(--ui-cbx-muted);
}
.ui-cbx__icon svg {
  width: 16px;
  height: 16px;
}
.ui-cbx__icon {
  overflow: hidden;
}
.ui-cbx__icon img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-cbx__pop {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  padding: 4px;
  border-radius: 18px;
  background: var(--ui-cbx-tray);
  box-shadow: var(--ui-cbx-shadow);
  transform-origin: top center;
  animation: ui-cbx-open 240ms var(--ui-cbx-ease) both;
}
.ui-cbx__card {
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-cbx-card);
  box-shadow: 0 0 0 1px var(--ui-cbx-line);
}
.ui-cbx__list {
  position: relative;
  max-height: 300px;
  padding: 4px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  transition: height 300ms var(--ui-cbx-ease);
}
.ui-cbx__pill {
  position: absolute;
  top: 0;
  left: 4px;
  right: 4px;
  border-radius: 9px;
  background: var(--ui-cbx-active);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 220ms var(--ui-cbx-ease),
    height 220ms var(--ui-cbx-ease),
    opacity 160ms ease;
}
.ui-cbx__group-label {
  padding: 9px 8px 4px;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-cbx-faint);
  overflow-wrap: anywhere;
}
.ui-cbx__group:first-child .ui-cbx__group-label {
  padding-top: 5px;
}
.ui-cbx__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 36px;
  padding: 0 8px;
  border-radius: 9px;
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}
.ui-cbx__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cbx__name {
  flex: 0 0 auto;
  max-width: 100%;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cbx-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cbx__hint {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cbx-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cbx mark {
  border-radius: 3px;
  background: var(--ui-cbx-mark);
  color: inherit;
}
.ui-cbx__check {
  width: 16px;
  height: 16px;
  margin-left: auto;
  color: var(--ui-cbx-ink);
  stroke-width: 2.2;
  opacity: 0;
  transform: scale(0.4);
  transition:
    opacity 120ms ease,
    transform 160ms ease;
}
.ui-cbx__option[aria-selected="true"] .ui-cbx__check {
  opacity: 1;
  transform: none;
  transition:
    opacity 160ms ease,
    transform 380ms var(--ui-cbx-spring);
}
.ui-cbx__empty {
  padding: 14px 10px 10px;
  text-align: center;
  color: var(--ui-cbx-muted);
  animation: ui-cbx-in 240ms var(--ui-cbx-ease) both;
  overflow-wrap: anywhere;
}
.ui-cbx__create {
  animation: ui-cbx-in 240ms var(--ui-cbx-ease) both;
}
.ui-cbx__create .ui-cbx__name {
  flex: 0 1 auto;
}
.ui-cbx__plus {
  display: grid;
  place-items: center;
  flex: none;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  color: var(--ui-cbx-muted);
  box-shadow: inset 0 0 0 1px var(--ui-cbx-edge);
}
.ui-cbx__plus .ui-cbx__glyph {
  width: 13px;
  height: 13px;
  stroke-width: 2;
}
.ui-cbx__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 32px;
  padding: 0 10px;
  font-size: 12px;
  color: var(--ui-cbx-muted);
}
.ui-cbx__count {
  display: inline-flex;
  font-variant-numeric: tabular-nums;
}
.ui-cbx__keys {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  white-space: nowrap;
}
.ui-cbx kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-cbx-card);
  box-shadow:
    inset 0 0 0 1px var(--ui-cbx-line),
    0 1px 0 var(--ui-cbx-line);
  font-family: inherit;
  font-size: 10.5px;
  font-weight: 500;
  color: var(--ui-cbx-muted);
}
.ui-cbx__keys > span {
  margin: 0 6px 0 2px;
}
.ui-cbx__keys > span:last-child {
  margin-right: 0;
}
.ui-cbx__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-cbx-open {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-cbx-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-cbx-flash {
  0% {
    background-color: var(--ui-cbx-chip);
  }
  35% {
    background-color: var(--ui-cbx-flash);
  }
  100% {
    background-color: var(--ui-cbx-flash);
    transform: scale(0.92);
  }
}
@keyframes ui-cbx-roll-up {
  from {
    opacity: 0;
    transform: translateY(70%);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-cbx-roll-down {
  from {
    opacity: 0;
    transform: translateY(-70%);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 380px) {
  .ui-cbx__keys {
    display: none;
  }
  .ui-cbx__chip-label {
    max-width: 132px;
  }
  .ui-cbx__hint {
    font-size: 12px;
  }
  .ui-cbx__input {
    flex-basis: 44px;
    min-width: 44px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cbx__field-inner {
    min-height: 44px;
    padding-right: 44px;
  }
  .ui-cbx__chip-body {
    height: 32px;
  }
  .ui-cbx__chip-x {
    width: 26px;
    height: 26px;
  }
  .ui-cbx__input {
    height: 32px;
    font-size: 16px;
  }
  .ui-cbx__toggle {
    width: 32px;
    height: 32px;
  }
  .ui-cbx__option {
    height: 44px;
  }
  .ui-cbx__list {
    max-height: 340px;
  }
  .ui-cbx__keys {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cbx *,
  .ui-cbx *::before,
  .ui-cbx *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cbx {
  --ui-cbx-tray: #111113;
  --ui-cbx-card: #19191b;
  --ui-cbx-line: #2a2a2e;
  --ui-cbx-ink: #ededed;
  --ui-cbx-text: #c8c8cc;
  --ui-cbx-muted: #8b8b92;
  --ui-cbx-faint: #5c5c63;
  --ui-cbx-edge: #3a3a40;
  --ui-cbx-active: #26262a;
  --ui-cbx-chip: #232326;
  --ui-cbx-chip-line: #2f2f34;
  --ui-cbx-armed: #303035;
  --ui-cbx-flash: #3a3a40;
  --ui-cbx-avatar: #2c2c31;
  --ui-cbx-avatar-ink: #b4b4bb;
  --ui-cbx-mark: rgba(109, 139, 255, 0.24);
  --ui-cbx-accent: #6d8bff;
  --ui-cbx-ring: rgba(255, 255, 255, 0.07);
  --ui-cbx-focus: rgba(77, 141, 255, 0.8);
  --ui-cbx-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.6);
}
`;export{n as default};
