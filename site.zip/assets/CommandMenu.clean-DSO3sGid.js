const n=`.ui-cm {
  --ui-cm-tray: #f0f0f0;
  --ui-cm-card: #ffffff;
  --ui-cm-line: #ececec;
  --ui-cm-ink: #171717;
  --ui-cm-text: #404040;
  --ui-cm-muted: #626873;
  --ui-cm-faint: #6b6b6b;
  --ui-cm-active: #f0f0f1;
  --ui-cm-tile: #ffffff;
  --ui-cm-tile-ring: rgba(0, 0, 0, 0.09);
  --ui-cm-kbd: #ffffff;
  --ui-cm-mark: rgba(47, 107, 255, 0.14);
  --ui-cm-ok: #1f8a4c;
  --ui-cm-accent: #2f6bff;
  --ui-cm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 600px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cm-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  color: var(--ui-cm-text);
  -webkit-font-smoothing: antialiased;
}
.ui-cm *,
.ui-cm *::before,
.ui-cm *::after {
  box-sizing: border-box;
}
:where(.ui-cm) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cm) svg {
  display: block;
  flex: none;
}
.ui-cm__card {
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-cm-card);
  box-shadow:
    0 0 0 1px var(--ui-cm-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cm__search {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 52px;
  padding: 0 16px;
  border-bottom: 1px solid var(--ui-cm-line);
  cursor: text;
}
.ui-cm__search > svg {
  width: 18px;
  height: 18px;
  fill: none;
  stroke: var(--ui-cm-muted);
  stroke-width: 1.8;
  stroke-linecap: round;
}
.ui-cm__search input {
  flex: 1;
  min-width: 0;
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  font-size: 15px;
  color: var(--ui-cm-ink);
  outline: none;
}
.ui-cm__search input::placeholder {
  color: var(--ui-cm-faint);
}
.ui-cm__search input:focus-visible {
  outline: none;
}
.ui-cm__enter {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ui-cm-faint);
}
.ui-cm__enter svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cm__list {
  position: relative;
  max-height: 340px;
  padding: 4px 6px 8px;
  overflow-y: auto;
  scrollbar-width: thin;
  transition: height 320ms var(--ui-cm-ease);
}
.ui-cm__group {
  display: flex;
  flex-direction: column;
}
.ui-cm__label {
  padding: 10px 10px 4px;
  overflow-wrap: anywhere;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-cm-faint);
}
.ui-cm__pill {
  position: absolute;
  top: 0;
  left: 6px;
  right: 6px;
  border-radius: 10px;
  background: var(--ui-cm-active);
  transition:
    transform 220ms var(--ui-cm-ease),
    height 220ms var(--ui-cm-ease);
}
.ui-cm__item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  height: 40px;
  padding: 0 10px;
  border-radius: 10px;
  text-align: start;
}
.ui-cm__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: var(--ui-cm-tile);
  box-shadow: inset 0 0 0 1px var(--ui-cm-tile-ring);
  color: var(--ui-cm-ink);
}
.ui-cm__logo svg {
  width: 14px;
  height: 14px;
}
.ui-cm__logo,
.ui-cm__icon {
  overflow: hidden;
}
.ui-cm__logo img {
  width: 14px;
  height: 14px;
  object-fit: contain;
}
.ui-cm__icon img {
  width: 17px;
  height: 17px;
  object-fit: contain;
}
.ui-cm__logo[data-broken] > *,
.ui-cm__icon[data-broken] > * {
  display: none;
}
.ui-cm__logo[data-broken]::after,
.ui-cm__icon[data-broken]::after {
  content: attr(data-letter);
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-cm-text);
}
.ui-cm__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 26px;
  height: 26px;
  color: var(--ui-cm-muted);
}
.ui-cm__glyph {
  width: 17px;
  height: 17px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cm__item[aria-selected="true"] .ui-cm__icon {
  color: var(--ui-cm-ink);
}
.ui-cm__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cm__name {
  overflow: hidden;
  color: var(--ui-cm-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cm__hint {
  overflow: hidden;
  color: var(--ui-cm-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cm mark {
  border-radius: 3px;
  background: var(--ui-cm-mark);
  color: inherit;
}
.ui-cm__keys {
  display: inline-flex;
  flex: none;
  gap: 3px;
  opacity: 0.85;
}
.ui-cm kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-cm-kbd);
  box-shadow:
    inset 0 0 0 1px var(--ui-cm-line),
    0 1px 0 var(--ui-cm-line);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-cm-muted);
}
.ui-cm__item[aria-selected="true"] .ui-cm__keys {
  opacity: 1;
}
.ui-cm__item[data-ran] {
  animation: ui-cm-ran 600ms var(--ui-cm-ease);
}
@keyframes ui-cm-ran {
  30% {
    transform: scale(0.985);
  }
}
.ui-cm__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 38px;
  padding: 0 12px;
  font-size: 12.5px;
  color: var(--ui-cm-muted);
}
.ui-cm__foot > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-cm__done-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cm__foot-right {
  flex: none;
}
.ui-cm__foot .ui-cm__keys {
  opacity: 1;
}
.ui-cm__done {
  color: var(--ui-cm-ink);
  animation: ui-cm-in 260ms var(--ui-cm-ease);
}
.ui-cm__done svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: var(--ui-cm-ok);
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
@keyframes ui-cm-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 480px) {
  .ui-cm__item .ui-cm__keys,
  .ui-cm__foot > .ui-cm__foot-right,
  .ui-cm__foot > .ui-cm__tip,
  .ui-cm__enter,
  .ui-cm__hint {
    display: none;
  }
  .ui-cm__item {
    height: 44px;
  }
  .ui-cm__list {
    max-height: 360px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cm *,
  .ui-cm *::before,
  .ui-cm *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cm {
  --ui-cm-tray: #111113;
  --ui-cm-card: #19191b;
  --ui-cm-line: #2a2a2e;
  --ui-cm-ink: #ededed;
  --ui-cm-text: #c8c8cc;
  --ui-cm-muted: #8b8b92;
  --ui-cm-faint: #5c5c63;
  --ui-cm-active: #26262a;
  --ui-cm-tile: #26262a;
  --ui-cm-tile-ring: rgba(255, 255, 255, 0.1);
  --ui-cm-kbd: #232326;
  --ui-cm-mark: rgba(109, 139, 255, 0.24);
  --ui-cm-ok: #3ec27a;
  --ui-cm-accent: #6d8bff;
}

.ui-cmc {
  --ui-cmc-card: #ffffff;
  --ui-cmc-ink: rgba(0, 0, 0, 0.88);
  --ui-cmc-strong: #000000;
  --ui-cmc-text: rgba(0, 0, 0, 0.65);
  --ui-cmc-muted: rgba(0, 0, 0, 0.65);
  --ui-cmc-faint: rgba(0, 0, 0, 0.65);
  --ui-cmc-icon: rgba(0, 0, 0, 0.65);
  --ui-cmc-line: rgba(0, 0, 0, 0.06);
  --ui-cmc-line-strong: rgba(0, 0, 0, 0.1);
  --ui-cmc-active: rgba(0, 0, 0, 0.06);
  --ui-cmc-tile: #ffffff;
  --ui-cmc-tile-ring: rgba(0, 0, 0, 0.1);
  --ui-cmc-mark: rgba(0, 96, 226, 0.12);
  --ui-cmc-accent: rgba(0, 96, 226, 0.765);
  --ui-cmc-ok: #1a9a52;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cmc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 600px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cmc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cmc *,
.ui-cmc *::before,
.ui-cmc *::after {
  box-sizing: border-box;
}
:where(.ui-cmc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cmc) svg {
  display: block;
  flex: none;
}
.ui-cmc__card {
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cmc-card);
  box-shadow: var(--ui-cmc-shadow);
}
.ui-cmc__search {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 48px;
  padding: 0 12px 0 14px;
  border-bottom: 0.5px solid var(--ui-cmc-line);
  cursor: text;
}
.ui-cmc__search > svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-icon);
  stroke-width: 1.1;
  stroke-linecap: round;
}
.ui-cmc__search input {
  flex: 1;
  min-width: 0;
  height: 20px;
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cmc-ink);
  caret-color: var(--ui-cmc-accent);
  outline: none;
}
.ui-cmc__search input::placeholder {
  color: var(--ui-cmc-faint);
}
.ui-cmc__search input:focus-visible {
  outline: none;
}
.ui-cmc__enter svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__list {
  position: relative;
  max-height: 360px;
  padding: 0 4px 4px;
  overflow-y: auto;
  scrollbar-width: thin;
  transition: height 320ms var(--ui-cmc-ease);
}
.ui-cmc__group {
  display: flex;
  flex-direction: column;
}
.ui-cmc__label {
  padding: 10px 8px 4px;
  overflow-wrap: anywhere;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-cmc-muted);
}
.ui-cmc__group:first-child:not(:has(.ui-cmc__label)) {
  padding-top: 4px;
}
.ui-cmc__pill {
  position: absolute;
  top: 0;
  left: 4px;
  right: 4px;
  border-radius: 6px;
  background: var(--ui-cmc-active);
  opacity: 0;
  transition:
    transform 90ms ease-out,
    height 90ms ease-out,
    opacity 140ms ease;
}
.ui-cmc__pill[data-lit] {
  opacity: 1;
}
.ui-cmc__item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 36px;
  padding: 0 8px;
  border-radius: 6px;
  text-align: start;
}
.ui-cmc__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-cmc-tile);
  box-shadow:
    0 0 0 0.5px var(--ui-cmc-tile-ring),
    0 1px 1px -1px rgba(0, 0, 0, 0.1);
  color: var(--ui-cmc-strong);
}
.ui-cmc__logo svg {
  width: 12px;
  height: 12px;
}
.ui-cmc__logo,
.ui-cmc__icon {
  overflow: hidden;
}
.ui-cmc__logo img {
  width: 12px;
  height: 12px;
  object-fit: contain;
}
.ui-cmc__icon img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-cmc__logo[data-broken] > *,
.ui-cmc__icon[data-broken] > * {
  display: none;
}
.ui-cmc__logo[data-broken]::after,
.ui-cmc__icon[data-broken]::after {
  content: attr(data-letter);
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-cmc-text);
}
.ui-cmc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  color: var(--ui-cmc-icon);
  transition: color 140ms ease;
}
.ui-cmc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__glyph path {
  vector-effect: non-scaling-stroke;
}
.ui-cmc__item[aria-selected="true"] .ui-cmc__icon {
  color: var(--ui-cmc-ink);
}
.ui-cmc__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cmc__name {
  overflow: hidden;
  color: var(--ui-cmc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc__hint {
  overflow: hidden;
  color: var(--ui-cmc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc mark {
  border-radius: 3px;
  background: var(--ui-cmc-mark);
  color: inherit;
}
.ui-cmc__keys {
  display: inline-flex;
  flex: none;
  gap: 2px;
}
.ui-cmc kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cmc-line-strong);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cmc-muted);
  transition: color 140ms ease;
}
.ui-cmc__item[aria-selected="true"] kbd {
  color: var(--ui-cmc-text);
}
.ui-cmc__enter {
  padding: 0 4px;
  color: var(--ui-cmc-icon);
}
.ui-cmc__item[data-ran] {
  animation: ui-cmc-ran 600ms var(--ui-cmc-ease);
}
@keyframes ui-cmc-ran {
  30% {
    transform: scale(0.985);
  }
}
.ui-cmc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 40px;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-cmc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cmc-muted);
}
.ui-cmc__foot > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-cmc__done {
  color: var(--ui-cmc-ink);
  animation: ui-cmc-in 260ms var(--ui-cmc-ease);
}
.ui-cmc__done-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cmc__done svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-ok);
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__foot-right {
  flex: none;
}
@keyframes ui-cmc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 480px) {
  .ui-cmc__item .ui-cmc__keys,
  .ui-cmc__foot > .ui-cmc__foot-right,
  .ui-cmc__foot > .ui-cmc__tip,
  .ui-cmc__enter,
  .ui-cmc__hint {
    display: none;
  }
  .ui-cmc__item {
    height: 40px;
  }
  .ui-cmc__list {
    max-height: 360px;
  }
  .ui-cmc__foot:not(:has(.ui-cmc__done)) {
    display: none;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cmc__item {
    height: 44px;
  }
  .ui-cmc__search {
    height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cmc *,
  .ui-cmc *::before,
  .ui-cmc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cmc {
  --ui-cmc-card: #1c1c1e;
  --ui-cmc-ink: rgba(255, 255, 255, 0.9);
  --ui-cmc-strong: #ffffff;
  --ui-cmc-text: rgba(255, 255, 255, 0.62);
  --ui-cmc-muted: rgba(255, 255, 255, 0.46);
  --ui-cmc-faint: rgba(255, 255, 255, 0.3);
  --ui-cmc-icon: rgba(255, 255, 255, 0.5);
  --ui-cmc-line: rgba(255, 255, 255, 0.08);
  --ui-cmc-line-strong: rgba(255, 255, 255, 0.12);
  --ui-cmc-active: rgba(255, 255, 255, 0.08);
  --ui-cmc-tile: #2a2a2d;
  --ui-cmc-tile-ring: rgba(255, 255, 255, 0.12);
  --ui-cmc-mark: rgba(77, 141, 255, 0.24);
  --ui-cmc-accent: #4d8dff;
  --ui-cmc-ok: #3ec27a;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
