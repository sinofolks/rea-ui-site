import{j as e,r as s}from"./workbench-model-BwgilGut.js";const b={doc:"M7 3h7l5 5v13H7zM14 3v5h5M10 13h6M10 17h4",person:"M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4.5 20a7.5 7.5 0 0 1 15 0M19 8v4M17 10h4",inbox:"M4 13l2.5-8h11L20 13v6H4zM4 13h4.5a3.5 3.5 0 0 0 7 0H20",home:"M4 11l8-7 8 7v9h-5v-6H9v6H4z",gear:"M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 13.5l1.6 1.2-2 3.4-1.9-.7a7 7 0 0 1-1.7 1L15 20.5h-4l-.4-2.1a7 7 0 0 1-1.7-1l-1.9.7-2-3.4 1.6-1.2a7 7 0 0 1 0-3l-1.6-1.2 2-3.4 1.9.7a7 7 0 0 1 1.7-1L11 3.5h4l.4 2.1a7 7 0 0 1 1.7 1l1.9-.7 2 3.4-1.6 1.2a7 7 0 0 1 0 3z",moon:"M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z",help:"M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6M12 17h.01",upload:"M12 16V4M7 9l5-5 5 5M5 20h14",chart:"M5 20V10M12 20V4M19 20v-7"};function k({d:t,prefix:n}){return e.jsx("svg",{viewBox:"0 0 24 24",className:`${n}__glyph`,"aria-hidden":"true",children:e.jsx("path",{d:t})})}function I({prefix:t}){return e.jsxs("svg",{viewBox:"0 0 24 24","aria-hidden":"true",children:[e.jsx("defs",{children:e.jsxs("linearGradient",{id:`${t}-spark`,x1:"0",y1:"0",x2:"1",y2:"1",children:[e.jsx("stop",{stopColor:"#7C5CFF"}),e.jsx("stop",{offset:"1",stopColor:"#2F9BFF"})]})}),e.jsx("path",{fill:`url(#${t}-spark)`,d:"M12 2.5c.6 3.9 2.1 6.4 4.4 7.6 1.1.6 2.4.9 4.1 1.1v1.6c-4.6.6-7.3 3-8.5 8.7h-1.6c-.6-3.9-2.1-6.4-4.4-7.6-1.1-.6-2.4-.9-4.1-1.1v-1.6c4.6-.6 7.3-3 8.5-8.7z"})]})}function R(){return"lg"+s.useId().replace(/[^a-zA-Z0-9_-]/g,"")}const J=()=>{let t=R();return e.jsxs("svg",{viewBox:"0 0 56.4108 44.8722",fill:"none","aria-hidden":"true",children:[e.jsx("path",{d:"M44.2255 5.76727H56.4051V41.0239C56.4051 43.148 54.683 44.8701 52.5589 44.8701H46.1486C45.8961 44.8701 45.646 44.8204 45.4127 44.7237C45.1794 44.6271 44.9674 44.4854 44.7888 44.3069C44.6102 44.1283 44.4686 43.9163 44.3719 43.683C44.2753 43.4497 44.2255 43.1996 44.2255 42.947V5.76727Z",fill:`url(#${t}-0)`}),e.jsx("path",{d:"M12.1796 5.76727H0V41.0239C0 43.148 1.72213 44.8701 3.84618 44.8701H10.2565C10.509 44.8701 10.7591 44.8204 10.9924 44.7237C11.2257 44.6271 11.4377 44.4854 11.6163 44.3069C11.7949 44.1283 11.9365 43.9163 12.0332 43.683C12.1298 43.4497 12.1796 43.1996 12.1796 42.947V5.76727Z",fill:"#FC413D"}),e.jsx("path",{d:"M10.0085 1.42778C7.43377 -0.736342 3.5924 -0.403647 1.42828 2.17105C-0.735843 4.74543 -0.403148 8.58681 2.17155 10.7512L26.5557 31.2479C27.0178 31.6362 27.602 31.8492 28.2056 31.8492C28.8091 31.8492 29.3934 31.6362 29.8554 31.2479L54.2396 10.7509C56.814 8.58681 57.1467 4.74543 54.9825 2.17073C52.8184 -0.403648 48.977 -0.736342 46.4027 1.42778L28.2054 16.724L10.0085 1.42778Z",fill:`url(#${t}-1)`}),e.jsxs("defs",{children:[e.jsxs("linearGradient",{id:`${t}-0`,x1:"50.3153",y1:"5.76727",x2:"50.3153",y2:"44.8701",gradientUnits:"userSpaceOnUse",children:[e.jsx("stop",{stopColor:"#60D673"}),e.jsx("stop",{offset:"0.17",stopColor:"#42C868"}),e.jsx("stop",{offset:"0.39",stopColor:"#0EBC5F"}),e.jsx("stop",{offset:"0.62",stopColor:"#00A9BB"}),e.jsx("stop",{offset:"0.86",stopColor:"#3C90FF"}),e.jsx("stop",{offset:"1",stopColor:"#3186FF"})]}),e.jsxs("linearGradient",{id:`${t}-1`,x1:"6.04194e-05",y1:"6.45153",x2:"56.4107",y2:"6.45153",gradientUnits:"userSpaceOnUse",children:[e.jsx("stop",{offset:"0.08",stopColor:"#FF63A0"}),e.jsx("stop",{offset:"0.3",stopColor:"#FC413D"}),e.jsx("stop",{offset:"0.5",stopColor:"#FC413D"}),e.jsx("stop",{offset:"0.65",stopColor:"#FC413D"}),e.jsx("stop",{offset:"0.72",stopColor:"#FC5C30"}),e.jsx("stop",{offset:"0.86",stopColor:"#FEB10C"}),e.jsx("stop",{offset:"0.91",stopColor:"#FEC700"}),e.jsx("stop",{offset:"0.96",stopColor:"#FFDB0F"})]})]})]})},X=()=>{let t=R();return e.jsxs("svg",{viewBox:"0 0 49.7096 59.6884",fill:"none","aria-hidden":"true",children:[e.jsx("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M0 45.9002L9.1618 38.8247C14.0602 45.1745 19.2307 48.1679 24.9455 48.1679C30.6603 48.1679 35.7401 45.2652 40.3663 38.9154L49.7096 45.8094C42.997 54.8805 34.6516 59.6882 24.9455 59.6882C15.3301 59.6882 6.89403 54.8805 0 45.9002Z",fill:`url(#${t}-0)`}),e.jsx("path",{fillRule:"evenodd",clipRule:"evenodd",d:"M24.9535 15.3301L8.62558 29.3903L1.09657 20.5914L25.0442 0L48.8105 20.5914L41.1908 29.2996L24.9535 15.3301Z",fill:`url(#${t}-1)`}),e.jsxs("defs",{children:[e.jsxs("linearGradient",{id:`${t}-0`,x1:"0",y1:"49.2666",x2:"49.75",y2:"49.2666",gradientUnits:"userSpaceOnUse",children:[e.jsx("stop",{stopColor:"#8930FD"}),e.jsx("stop",{offset:"1",stopColor:"#49CCF9"})]}),e.jsxs("linearGradient",{id:`${t}-1`,x1:"1.09231",y1:"14.6901",x2:"48.7603",y2:"14.6901",gradientUnits:"userSpaceOnUse",children:[e.jsx("stop",{stopColor:"#FF02F0"}),e.jsx("stop",{offset:"1",stopColor:"#FFC800"})]})]})]})},ee=()=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"#FF7A59","aria-hidden":"true",children:e.jsx("path",{d:"M18.164 7.93V5.084a2.198 2.198 0 001.267-1.978v-.067A2.2 2.2 0 0017.238.845h-.067a2.2 2.2 0 00-2.193 2.193v.067a2.196 2.196 0 001.252 1.973l.013.006v2.852a6.22 6.22 0 00-2.969 1.31l.012-.01-7.828-6.095A2.497 2.497 0 104.3 4.656l-.012.006 7.697 5.991a6.176 6.176 0 00-1.038 3.446c0 1.343.425 2.588 1.147 3.607l-.013-.02-2.342 2.343a1.968 1.968 0 00-.58-.095h-.002a2.033 2.033 0 102.033 2.033 1.978 1.978 0 00-.1-.595l.005.014 2.317-2.317a6.247 6.247 0 104.782-11.134l-.036-.005zm-.964 9.378a3.206 3.206 0 113.215-3.207v.002a3.206 3.206 0 01-3.207 3.207z"})}),ie=()=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"#4285F4","aria-hidden":"true",children:e.jsx("path",{d:"M18.316 5.684H24v12.632h-5.684V5.684zM5.684 24h12.632v-5.684H5.684V24zM18.316 5.684V0H1.895A1.894 1.894 0 0 0 0 1.895v16.421h5.684V5.684h12.632zm-7.207 6.25v-.065c.272-.144.5-.349.687-.617s.279-.595.279-.982c0-.379-.099-.72-.3-1.025a2.05 2.05 0 0 0-.832-.714 2.703 2.703 0 0 0-1.197-.257c-.6 0-1.094.156-1.481.467-.386.311-.65.671-.793 1.078l1.085.452c.086-.249.224-.461.413-.633.189-.172.445-.257.767-.257.33 0 .602.088.816.264a.86.86 0 0 1 .322.703c0 .33-.12.589-.36.778-.24.19-.535.284-.886.284h-.567v1.085h.633c.407 0 .748.109 1.02.327.272.218.407.499.407.843 0 .336-.129.614-.387.832s-.565.327-.924.327c-.351 0-.651-.103-.897-.311-.248-.208-.422-.502-.521-.881l-1.096.452c.178.616.505 1.082.977 1.401.472.319.984.478 1.538.477a2.84 2.84 0 0 0 1.293-.291c.382-.193.684-.458.902-.794.218-.336.327-.72.327-1.149 0-.429-.115-.797-.344-1.105a2.067 2.067 0 0 0-.881-.689zm2.093-1.931l.602.913L15 10.045v5.744h1.187V8.446h-.827l-2.158 1.557zM22.105 0h-3.289v5.184H24V1.895A1.894 1.894 0 0 0 22.105 0zm-3.289 23.5l4.684-4.684h-4.684V23.5zM0 22.105C0 23.152.848 24 1.895 24h3.289v-5.184H0v3.289z"})}),te=()=>e.jsxs("svg",{viewBox:"0 0 49.883 49.877",fill:"none","aria-hidden":"true",children:[e.jsxs("g",{transform:"translate(0 0)",children:[e.jsx("path",{d:"M18.3549 10.4784C15.4713 10.4784 13.1157 8.12279 13.1157 5.2392C13.1157 2.35561 15.4713 0 18.3549 0C21.2385 0 23.5941 2.35561 23.5941 5.2392V10.4784H18.3549Z",fill:"#36C5F0"}),e.jsx("path",{d:"M18.3575 13.12C21.2411 13.12 23.5967 15.4756 23.5967 18.3592C23.5967 21.2428 21.2411 23.5984 18.3575 23.5984H5.2392C2.35561 23.5984 0 21.2428 0 18.3592C0 15.4756 2.35561 13.12 5.2392 13.12H18.3575Z",fill:"#36C5F0"})]}),e.jsxs("g",{transform:"translate(26.28 0)",children:[e.jsx("path",{d:"M13.1244 18.3592C13.1244 15.4756 15.48 13.12 18.3636 13.12C21.2472 13.12 23.6028 15.4756 23.6028 18.3592C23.6028 21.2428 21.2472 23.5984 18.3636 23.5984H13.1244V18.3592Z",fill:"#2EB67D"}),e.jsx("path",{d:"M10.4785 18.3575C10.4785 21.2411 8.12286 23.5967 5.23927 23.5967C2.35568 23.5967 7.4362e-05 21.2411 7.4362e-05 18.3575V5.2392C7.4362e-05 2.35561 2.35568 0 5.23927 0C8.12286 0 10.4785 2.35561 10.4785 5.2392V18.3575Z",fill:"#2EB67D"})]}),e.jsxs("g",{transform:"translate(0 26.28)",children:[e.jsx("path",{d:"M10.4784 5.2392C10.4784 8.12279 8.12279 10.4784 5.2392 10.4784C2.35561 10.4784 0 8.12279 0 5.2392C0 2.35561 2.35561 0 5.2392 0H10.4784V5.2392Z",fill:"#E01E5A"}),e.jsx("path",{d:"M13.1157 5.2392C13.1157 2.35561 15.4713 0 18.3549 0C21.2385 0 23.5941 2.35561 23.5941 5.2392V18.3575C23.5941 21.2411 21.2385 23.5967 18.3549 23.5967C15.4713 23.5967 13.1157 21.2411 13.1157 18.3575V5.2392Z",fill:"#E01E5A"})]}),e.jsxs("g",{transform:"translate(26.28 26.28)",children:[e.jsx("path",{d:"M5.23927 13.1157C8.12286 13.1157 10.4785 15.4713 10.4785 18.3549C10.4785 21.2385 8.12286 23.5941 5.23927 23.5941C2.35568 23.5941 7.4362e-05 21.2385 7.4362e-05 18.3549V13.1157H5.23927Z",fill:"#ECB22E"}),e.jsx("path",{d:"M5.23927 10.4784C2.35568 10.4784 7.4362e-05 8.12279 7.4362e-05 5.2392C7.4362e-05 2.35561 2.35568 0 5.23927 0H18.3576C21.2412 0 23.5968 2.35561 23.5968 5.2392C23.5968 8.12279 21.2412 10.4784 18.3576 10.4784H5.23927Z",fill:"#ECB22E"})]})]}),oe=()=>e.jsx("svg",{viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":"true",children:e.jsx("path",{d:"M4.459 4.208c.746.606 1.026.56 2.428.466l13.215-.793c.28 0 .047-.28-.046-.326L17.86 1.968c-.42-.326-.981-.7-2.055-.607L3.01 2.295c-.466.046-.56.28-.374.466zm.793 3.08v13.904c0 .747.373 1.027 1.214.98l14.523-.84c.841-.046.935-.56.935-1.167V6.354c0-.606-.233-.933-.748-.887l-15.177.887c-.56.047-.747.327-.747.933zm14.337.745c.093.42 0 .84-.42.888l-.7.14v10.264c-.608.327-1.168.514-1.635.514-.748 0-.935-.234-1.495-.933l-4.577-7.186v6.952L12.21 19s0 .84-1.168.84l-3.222.186c-.093-.186 0-.653.327-.746l.84-.233V9.854L7.822 9.76c-.094-.42.14-1.026.793-1.073l3.456-.233 4.764 7.279v-6.44l-1.215-.139c-.093-.514.28-.887.747-.933zM1.936 1.035l13.31-.98c1.634-.14 2.055-.047 3.082.7l4.249 2.986c.7.513.934.653.934 1.213v16.378c0 1.026-.373 1.634-1.68 1.726l-15.458.934c-.98.047-1.448-.093-1.962-.747l-3.129-4.06c-.56-.747-.793-1.306-.793-1.96V2.667c0-.839.374-1.54 1.447-1.632z"})});function T(t){return[{id:"suggestions",label:"Suggestions",commands:[{id:"email",label:"Write an email",hint:"Gmail",logo:e.jsx(J,{}),keywords:"mail send compose"},{id:"ask",label:"Ask assistant",hint:"Summaries, drafts, answers",logo:e.jsx(I,{prefix:t}),keywords:"ai chat question"},{id:"task",label:"Create a task",hint:"ClickUp",logo:e.jsx(X,{}),keywords:"todo issue"},{id:"crm",label:"Add contact to CRM",hint:"HubSpot",logo:e.jsx(ee,{}),keywords:"lead deal company"},{id:"meet",label:"Schedule a meeting",hint:"Google Calendar",logo:e.jsx(ie,{}),keywords:"call invite event"}]},{id:"share",label:"Share",commands:[{id:"slack",label:"Post an update",hint:"#team-updates",logo:e.jsx(te,{}),keywords:"message channel"},{id:"notion",label:"Save as page",hint:"Notion · Meeting notes",logo:e.jsx(oe,{}),keywords:"doc wiki"}]},{id:"general",label:"General",commands:[{id:"new-doc",label:"New document",icon:e.jsx(k,{d:b.doc,prefix:t}),keys:["N"]},{id:"invite",label:"Invite teammates",icon:e.jsx(k,{d:b.person,prefix:t}),keys:["I"]},{id:"upload",label:"Upload files",icon:e.jsx(k,{d:b.upload,prefix:t}),keys:["U"]},{id:"theme",label:"Switch to dark mode",icon:e.jsx(k,{d:b.moon,prefix:t}),keywords:"theme appearance light",keys:["⇧","D"]}]},{id:"go",label:"Go to",commands:[{id:"home",label:"Home",icon:e.jsx(k,{d:b.home,prefix:t}),keys:["G","H"]},{id:"inbox",label:"Inbox",icon:e.jsx(k,{d:b.inbox,prefix:t}),keys:["G","I"]},{id:"reports",label:"Reports",icon:e.jsx(k,{d:b.chart,prefix:t}),keys:["G","R"]},{id:"settings",label:"Settings",icon:e.jsx(k,{d:b.gear,prefix:t}),keys:["G","S"]},{id:"help",label:"Help & feedback",icon:e.jsx(k,{d:b.help,prefix:t}),keys:["?"]}]}]}const ne=T("ui-cm"),ae=T("ui-cmc");function H(t){return t.normalize("NFD").replace(new RegExp("\\p{M}","gu"),"").toLowerCase()}function A(t){var n;return(((n=t.match(/[\p{L}\p{N}]/u))==null?void 0:n[0])??"").toUpperCase()}function re(t){return(t??[]).filter(Boolean).map((n,h)=>({key:`g${h}`,id:n.id,label:String(n.label??""),commands:(Array.isArray(n.commands)?n.commands:[]).filter(Boolean).map((l,d)=>{const r=String(l.label??""),o=l.hint==null||l.hint===""?void 0:String(l.hint);return{row:{...l,label:r,hint:o,key:`${h}-${d}`,shortcut:0},searchText:H(`${r} ${o??""} ${l.keywords??""}`)}})}))}function se(t,{onRun:n,onClose:h,autoFocus:l},d){const r=`${d}${s.useId().replace(/[^a-zA-Z0-9_-]/g,"")}`,o=s.useRef(null),g=s.useRef(null),u=s.useRef(null),[x,w]=s.useState(0),[v,S]=s.useState(""),[U,C]=s.useState(null),[L,N]=s.useState(null),[Z,B]=s.useState(null),[K,M]=s.useState(!0),O=typeof navigator<"u"&&/Mac|iPhone|iPad/.test(navigator.platform)?"⌘":"Ctrl",E=s.useMemo(()=>re(t),[t]),j=v.trim(),y=s.useMemo(()=>{const i=H(j),a=E.map(c=>({...c,commands:c.commands.filter(p=>!i||p.searchText.includes(i)).map((p,f)=>c.id==="suggestions"&&f<5?{...p.row,shortcut:f+1}:p.row)})).filter(c=>c.commands.length);return i&&a.unshift({key:"ask",id:"ask-about",label:"Assistant",commands:[{key:"ask",shortcut:0,id:"ask-about",label:`Ask assistant about “${j}”`,logo:e.jsx(I,{prefix:d})}]}),a},[E,j,d]),_=s.useMemo(()=>y.flatMap(i=>i.commands),[y]),q=_.filter(i=>i.shortcut),m=_.find(i=>i.key===U)??_[0],$=s.useRef(!1);s.useLayoutEffect(()=>{const i=g.current,a=i==null?void 0:i.querySelector(`[data-key="${m==null?void 0:m.key}"]`);if(!i||!a){B(null);return}if(B({y:a.offsetTop,height:a.offsetHeight}),!$.current)return;$.current=!1;const c=a.previousElementSibling,p=c instanceof HTMLElement&&c.classList.contains(`${d}__label`)?c.offsetHeight:0,f=a.offsetTop-8-p,z=a.offsetTop+a.offsetHeight+8;f<i.scrollTop?i.scrollTop=f:z>i.scrollTop+i.clientHeight&&(i.scrollTop=z-i.clientHeight)},[m==null?void 0:m.key,_.length,d]),s.useLayoutEffect(()=>{const i=g.current,a=u.current;if(!i||!a)return;function c(){if(!i||!a)return;const f=getComputedStyle(i),z=parseFloat(f.paddingTop)+parseFloat(f.paddingBottom),W=parseFloat(f.maxHeight)||1/0;w(Math.min(a.offsetHeight+z,W))}c();const p=new ResizeObserver(c);return p.observe(a),()=>p.disconnect()},[]),s.useEffect(()=>{function i(a){var c,p;(a.metaKey||a.ctrlKey)&&a.key.toLowerCase()==="k"&&(a.preventDefault(),(c=o.current)==null||c.focus(),(p=o.current)==null||p.select())}return window.addEventListener("keydown",i),()=>window.removeEventListener("keydown",i)},[]),s.useEffect(()=>{var i;l&&((i=o.current)==null||i.focus())},[l]),s.useEffect(()=>{if(!L)return;const i=window.setTimeout(()=>N(null),1800);return()=>window.clearTimeout(i)},[L]);function F(i){C(i.key),N({id:i.key,label:i.key==="ask"?`Asked the assistant about “${j}”`:i.label}),i.key==="ask"?n==null||n("ask",j):n==null||n(i.id)}const V=s.useRef({move:i=>{},run:i=>{}});V.current={move:i=>{M(!0),i.key!==(m==null?void 0:m.key)&&C(i.key)},run:i=>{var a;F(i),(a=o.current)==null||a.focus({preventScroll:!0})}};function P(i){if(!_.length||!m)return;$.current=!0,M(!0);const a=_.findIndex(c=>c.key===m.key);C(_[(a+i+_.length)%_.length].key)}function Q(i){S(i.target.value),C(null)}function Y(i){if(i.key==="ArrowDown"||i.key==="ArrowUp")i.preventDefault(),P(i.key==="ArrowDown"?1:-1);else if(i.key==="Enter"&&m)i.preventDefault(),F(m);else if(i.key==="Tab"&&y.length>1){i.preventDefault();const a=y.findIndex(p=>p.commands.some(f=>f.key===(m==null?void 0:m.key))),c=i.shiftKey?a<=0?y.length-1:a-1:(a+1)%y.length;$.current=!0,M(!0),C(y[c].commands[0].key)}else if(i.key==="Escape")v?S(""):h==null||h();else if((i.metaKey||i.ctrlKey)&&/^[1-5]$/.test(i.key)){const a=q[Number(i.key)-1];a&&(i.preventDefault(),F(a))}}return{id:r,inputRef:o,listRef:g,innerRef:u,listHeight:x,query:v,trimmedQuery:j,lastRun:L,selectionBounds:Z,highlighted:K,setHighlighted:M,modifier:O,visibleGroups:y,selected:m,handlers:V,handleChange:Q,handleKeyDown:Y}}function D({text:t,query:n}){const h=H(t),l=H(n),d=l&&h.length===t.length?h.indexOf(l):-1;return d<0?e.jsx(e.Fragment,{children:t}):e.jsxs(e.Fragment,{children:[t.slice(0,d),e.jsx("mark",{children:t.slice(d,d+l.length)}),t.slice(d+l.length)]})}function G(t){t.currentTarget.dataset.broken=""}const ce=s.memo(function({command:n,domId:h,selected:l,ran:d,modifier:r,query:o,handlers:g,prefix:u}){const x=n.shortcut?[r,String(n.shortcut)]:n.keys;return e.jsxs("button",{id:h,"data-key":n.key,type:"button",role:"option","aria-selected":l,"data-ran":d||void 0,className:`${u}__item`,tabIndex:-1,onMouseMove:()=>g.current.move(n),onClick:()=>g.current.run(n),children:[n.logo?e.jsx("span",{className:`${u}__logo`,"data-letter":A(n.label),onErrorCapture:G,children:n.logo}):e.jsx("span",{className:`${u}__icon`,"data-letter":A(n.label),onErrorCapture:G,children:n.icon}),e.jsxs("span",{className:`${u}__text`,children:[e.jsx("span",{className:`${u}__name`,dir:"auto",title:n.label,children:e.jsx(D,{text:n.label,query:o})}),n.hint&&e.jsx("span",{className:`${u}__hint`,dir:"auto",title:n.hint,children:e.jsx(D,{text:n.hint,query:o})})]}),x&&e.jsx("span",{className:`${u}__keys`,"aria-hidden":"true",children:x.map((w,v)=>e.jsx("kbd",{children:w},v))})]})}),le=`
.ui-cm {
  --ui-cm-tray: #f0f0f0;
  --ui-cm-card: #ffffff;
  --ui-cm-line: #ececec;
  --ui-cm-ink: #171717;
  --ui-cm-text: #404040;
  --ui-cm-muted: #626873;
  --ui-cm-faint: #6b6b6b;
  --ui-cm-active: #f0f0f1;
  --ui-cm-tile: #ffffff;
  --ui-cm-tile-ring: rgba(0, 0, 0, 0.09);
  --ui-cm-kbd: #ffffff;
  --ui-cm-mark: rgba(47, 107, 255, 0.14);
  --ui-cm-ok: #1f8a4c;
  --ui-cm-accent: #2f6bff;
  --ui-cm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 600px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cm-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  color: var(--ui-cm-text);
  -webkit-font-smoothing: antialiased;
}
.ui-cm *,
.ui-cm *::before,
.ui-cm *::after {
  box-sizing: border-box;
}
:where(.ui-cm) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cm) svg {
  display: block;
  flex: none;
}
.ui-cm__card {
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-cm-card);
  box-shadow:
    0 0 0 1px var(--ui-cm-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cm__search {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 52px;
  padding: 0 16px;
  border-bottom: 1px solid var(--ui-cm-line);
  cursor: text;
}
.ui-cm__search > svg {
  width: 18px;
  height: 18px;
  fill: none;
  stroke: var(--ui-cm-muted);
  stroke-width: 1.8;
  stroke-linecap: round;
}
.ui-cm__search input {
  flex: 1;
  min-width: 0;
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  font-size: 15px;
  color: var(--ui-cm-ink);
  outline: none;
}
.ui-cm__search input::placeholder {
  color: var(--ui-cm-faint);
}
.ui-cm__search input:focus-visible {
  outline: none;
}
.ui-cm__enter {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--ui-cm-faint);
}
.ui-cm__enter svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cm__list {
  position: relative;
  max-height: 340px;
  padding: 4px 6px 8px;
  overflow-y: auto;
  scrollbar-width: thin;
  transition: height 320ms var(--ui-cm-ease);
}
.ui-cm__group {
  display: flex;
  flex-direction: column;
}
.ui-cm__label {
  padding: 10px 10px 4px;
  overflow-wrap: anywhere;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-cm-faint);
}
.ui-cm__pill {
  position: absolute;
  top: 0;
  left: 6px;
  right: 6px;
  border-radius: 10px;
  background: var(--ui-cm-active);
  transition:
    transform 220ms var(--ui-cm-ease),
    height 220ms var(--ui-cm-ease);
}
.ui-cm__item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  height: 40px;
  padding: 0 10px;
  border-radius: 10px;
  text-align: start;
}
.ui-cm__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: var(--ui-cm-tile);
  box-shadow: inset 0 0 0 1px var(--ui-cm-tile-ring);
  color: var(--ui-cm-ink);
}
.ui-cm__logo svg {
  width: 14px;
  height: 14px;
}
.ui-cm__logo,
.ui-cm__icon {
  overflow: hidden;
}
.ui-cm__logo img {
  width: 14px;
  height: 14px;
  object-fit: contain;
}
.ui-cm__icon img {
  width: 17px;
  height: 17px;
  object-fit: contain;
}
.ui-cm__logo[data-broken] > *,
.ui-cm__icon[data-broken] > * {
  display: none;
}
.ui-cm__logo[data-broken]::after,
.ui-cm__icon[data-broken]::after {
  content: attr(data-letter);
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-cm-text);
}
.ui-cm__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 26px;
  height: 26px;
  color: var(--ui-cm-muted);
}
.ui-cm__glyph {
  width: 17px;
  height: 17px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cm__item[aria-selected="true"] .ui-cm__icon {
  color: var(--ui-cm-ink);
}
.ui-cm__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cm__name {
  overflow: hidden;
  color: var(--ui-cm-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cm__hint {
  overflow: hidden;
  color: var(--ui-cm-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cm mark {
  border-radius: 3px;
  background: var(--ui-cm-mark);
  color: inherit;
}
.ui-cm__keys {
  display: inline-flex;
  flex: none;
  gap: 3px;
  opacity: 0.85;
}
.ui-cm kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-cm-kbd);
  box-shadow:
    inset 0 0 0 1px var(--ui-cm-line),
    0 1px 0 var(--ui-cm-line);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-cm-muted);
}
.ui-cm__item[aria-selected="true"] .ui-cm__keys {
  opacity: 1;
}
.ui-cm__item[data-ran] {
  animation: ui-cm-ran 600ms var(--ui-cm-ease);
}
@keyframes ui-cm-ran {
  30% {
    transform: scale(0.985);
  }
}
.ui-cm__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 38px;
  padding: 0 12px;
  font-size: 12.5px;
  color: var(--ui-cm-muted);
}
.ui-cm__foot > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-cm__done-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cm__foot-right {
  flex: none;
}
.ui-cm__foot .ui-cm__keys {
  opacity: 1;
}
.ui-cm__done {
  color: var(--ui-cm-ink);
  animation: ui-cm-in 260ms var(--ui-cm-ease);
}
.ui-cm__done svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: var(--ui-cm-ok);
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
@keyframes ui-cm-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 480px) {
  .ui-cm__item .ui-cm__keys,
  .ui-cm__foot > .ui-cm__foot-right,
  .ui-cm__foot > .ui-cm__tip,
  .ui-cm__enter,
  .ui-cm__hint {
    display: none;
  }
  .ui-cm__item {
    height: 44px;
  }
  .ui-cm__list {
    max-height: 360px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cm *,
  .ui-cm *::before,
  .ui-cm *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cm {
  --ui-cm-tray: #111113;
  --ui-cm-card: #19191b;
  --ui-cm-line: #2a2a2e;
  --ui-cm-ink: #ededed;
  --ui-cm-text: #c8c8cc;
  --ui-cm-muted: #8b8b92;
  --ui-cm-faint: #5c5c63;
  --ui-cm-active: #26262a;
  --ui-cm-tile: #26262a;
  --ui-cm-tile-ring: rgba(255, 255, 255, 0.1);
  --ui-cm-kbd: #232326;
  --ui-cm-mark: rgba(109, 139, 255, 0.24);
  --ui-cm-ok: #3ec27a;
  --ui-cm-accent: #6d8bff;
}
`,de=`
.ui-cmc {
  --ui-cmc-card: #ffffff;
  --ui-cmc-ink: rgba(0, 0, 0, 0.88);
  --ui-cmc-strong: #000000;
  --ui-cmc-text: rgba(0, 0, 0, 0.65);
  --ui-cmc-muted: rgba(0, 0, 0, 0.65);
  --ui-cmc-faint: rgba(0, 0, 0, 0.65);
  --ui-cmc-icon: rgba(0, 0, 0, 0.65);
  --ui-cmc-line: rgba(0, 0, 0, 0.06);
  --ui-cmc-line-strong: rgba(0, 0, 0, 0.1);
  --ui-cmc-active: rgba(0, 0, 0, 0.06);
  --ui-cmc-tile: #ffffff;
  --ui-cmc-tile-ring: rgba(0, 0, 0, 0.1);
  --ui-cmc-mark: rgba(0, 96, 226, 0.12);
  --ui-cmc-accent: rgba(0, 96, 226, 0.765);
  --ui-cmc-ok: #1a9a52;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cmc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 600px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cmc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cmc *,
.ui-cmc *::before,
.ui-cmc *::after {
  box-sizing: border-box;
}
:where(.ui-cmc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cmc) svg {
  display: block;
  flex: none;
}
.ui-cmc__card {
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cmc-card);
  box-shadow: var(--ui-cmc-shadow);
}
.ui-cmc__search {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 48px;
  padding: 0 12px 0 14px;
  border-bottom: 0.5px solid var(--ui-cmc-line);
  cursor: text;
}
.ui-cmc__search > svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-icon);
  stroke-width: 1.1;
  stroke-linecap: round;
}
.ui-cmc__search input {
  flex: 1;
  min-width: 0;
  height: 20px;
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cmc-ink);
  caret-color: var(--ui-cmc-accent);
  outline: none;
}
.ui-cmc__search input::placeholder {
  color: var(--ui-cmc-faint);
}
.ui-cmc__search input:focus-visible {
  outline: none;
}
.ui-cmc__enter svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__list {
  position: relative;
  max-height: 360px;
  padding: 0 4px 4px;
  overflow-y: auto;
  scrollbar-width: thin;
  transition: height 320ms var(--ui-cmc-ease);
}
.ui-cmc__group {
  display: flex;
  flex-direction: column;
}
.ui-cmc__label {
  padding: 10px 8px 4px;
  overflow-wrap: anywhere;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-cmc-muted);
}
.ui-cmc__group:first-child:not(:has(.ui-cmc__label)) {
  padding-top: 4px;
}
.ui-cmc__pill {
  position: absolute;
  top: 0;
  left: 4px;
  right: 4px;
  border-radius: 6px;
  background: var(--ui-cmc-active);
  opacity: 0;
  transition:
    transform 90ms ease-out,
    height 90ms ease-out,
    opacity 140ms ease;
}
.ui-cmc__pill[data-lit] {
  opacity: 1;
}
.ui-cmc__item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 36px;
  padding: 0 8px;
  border-radius: 6px;
  text-align: start;
}
.ui-cmc__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-cmc-tile);
  box-shadow:
    0 0 0 0.5px var(--ui-cmc-tile-ring),
    0 1px 1px -1px rgba(0, 0, 0, 0.1);
  color: var(--ui-cmc-strong);
}
.ui-cmc__logo svg {
  width: 12px;
  height: 12px;
}
.ui-cmc__logo,
.ui-cmc__icon {
  overflow: hidden;
}
.ui-cmc__logo img {
  width: 12px;
  height: 12px;
  object-fit: contain;
}
.ui-cmc__icon img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-cmc__logo[data-broken] > *,
.ui-cmc__icon[data-broken] > * {
  display: none;
}
.ui-cmc__logo[data-broken]::after,
.ui-cmc__icon[data-broken]::after {
  content: attr(data-letter);
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-cmc-text);
}
.ui-cmc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  color: var(--ui-cmc-icon);
  transition: color 140ms ease;
}
.ui-cmc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__glyph path {
  vector-effect: non-scaling-stroke;
}
.ui-cmc__item[aria-selected="true"] .ui-cmc__icon {
  color: var(--ui-cmc-ink);
}
.ui-cmc__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cmc__name {
  overflow: hidden;
  color: var(--ui-cmc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc__hint {
  overflow: hidden;
  color: var(--ui-cmc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc mark {
  border-radius: 3px;
  background: var(--ui-cmc-mark);
  color: inherit;
}
.ui-cmc__keys {
  display: inline-flex;
  flex: none;
  gap: 2px;
}
.ui-cmc kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cmc-line-strong);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cmc-muted);
  transition: color 140ms ease;
}
.ui-cmc__item[aria-selected="true"] kbd {
  color: var(--ui-cmc-text);
}
.ui-cmc__enter {
  padding: 0 4px;
  color: var(--ui-cmc-icon);
}
.ui-cmc__item[data-ran] {
  animation: ui-cmc-ran 600ms var(--ui-cmc-ease);
}
@keyframes ui-cmc-ran {
  30% {
    transform: scale(0.985);
  }
}
.ui-cmc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 40px;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-cmc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cmc-muted);
}
.ui-cmc__foot > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-cmc__done {
  color: var(--ui-cmc-ink);
  animation: ui-cmc-in 260ms var(--ui-cmc-ease);
}
.ui-cmc__done-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cmc__done svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-ok);
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__foot-right {
  flex: none;
}
@keyframes ui-cmc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 480px) {
  .ui-cmc__item .ui-cmc__keys,
  .ui-cmc__foot > .ui-cmc__foot-right,
  .ui-cmc__foot > .ui-cmc__tip,
  .ui-cmc__enter,
  .ui-cmc__hint {
    display: none;
  }
  .ui-cmc__item {
    height: 40px;
  }
  .ui-cmc__list {
    max-height: 360px;
  }
  .ui-cmc__foot:not(:has(.ui-cmc__done)) {
    display: none;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cmc__item {
    height: 44px;
  }
  .ui-cmc__search {
    height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cmc *,
  .ui-cmc *::before,
  .ui-cmc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cmc {
  --ui-cmc-card: #1c1c1e;
  --ui-cmc-ink: rgba(255, 255, 255, 0.9);
  --ui-cmc-strong: #ffffff;
  --ui-cmc-text: rgba(255, 255, 255, 0.62);
  --ui-cmc-muted: rgba(255, 255, 255, 0.46);
  --ui-cmc-faint: rgba(255, 255, 255, 0.3);
  --ui-cmc-icon: rgba(255, 255, 255, 0.5);
  --ui-cmc-line: rgba(255, 255, 255, 0.08);
  --ui-cmc-line-strong: rgba(255, 255, 255, 0.12);
  --ui-cmc-active: rgba(255, 255, 255, 0.08);
  --ui-cmc-tile: #2a2a2d;
  --ui-cmc-tile-ring: rgba(255, 255, 255, 0.12);
  --ui-cmc-mark: rgba(77, 141, 255, 0.24);
  --ui-cmc-accent: #4d8dff;
  --ui-cmc-ok: #3ec27a;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;function me({clean:t=!1,...n}){const{groups:h=t?ae:ne,placeholder:l="Type a command or search…",className:d}=n,r=t?"ui-cmc":"ui-cm",o=se(h,n,r),g=e.jsxs("footer",{className:`${r}__foot`,"aria-live":"polite",children:[o.lastRun?e.jsxs("span",{className:`${r}__done`,children:[e.jsx("svg",{viewBox:t?"0 0 16 16":"0 0 24 24","aria-hidden":"true",children:e.jsx("path",{d:t?"m3.5 8.5 3 3 6-7":"m5 12.5 4.5 4.5L19 7.5"})}),e.jsx("span",{className:`${r}__done-text`,children:o.lastRun.label})]},o.lastRun.label):e.jsxs("span",{className:`${r}__tip`,children:[e.jsx("kbd",{children:"Tab"})," to jump between sections"]}),e.jsxs("span",{className:`${r}__foot-right`,children:[e.jsxs("span",{className:`${r}__keys`,children:[e.jsx("kbd",{children:o.modifier}),e.jsx("kbd",{children:"K"})]}),"to open"]})]});return e.jsxs("div",{className:[r,d].filter(Boolean).join(" "),children:[e.jsx("style",{href:t?"ui-command-menu-clean":"ui-command-menu",precedence:"default",children:t?de:le}),e.jsxs("div",{className:`${r}__card`,children:[e.jsxs("label",{className:`${r}__search`,children:[e.jsxs("svg",{viewBox:t?"0 0 16 16":"0 0 24 24","aria-hidden":"true",children:[e.jsx("circle",{cx:t?"7.25":"11",cy:t?"7.25":"11",r:t?"4.75":"7"}),e.jsx("path",{d:t?"m13.5 13.5-2.9-2.9":"m20 20-3.5-3.5"})]}),e.jsx("input",{ref:o.inputRef,value:o.query,dir:"auto",placeholder:l,"aria-label":"Command",role:"combobox","aria-expanded":"true","aria-controls":`${o.id}-list`,"aria-activedescendant":o.selected?`${o.id}-${o.selected.key}`:void 0,onChange:o.handleChange,onKeyDown:o.handleKeyDown}),t?e.jsx("kbd",{className:`${r}__enter`,"aria-hidden":"true",children:e.jsx("svg",{viewBox:"0 0 16 16",children:e.jsx("path",{d:"M12.5 4v3a2 2 0 0 1-2 2h-7M6 6.5 3.5 9 6 11.5"})})}):e.jsxs("span",{className:`${r}__enter`,"aria-hidden":"true",children:[e.jsx("svg",{viewBox:"0 0 24 24",children:e.jsx("path",{d:"M19 6v5a3 3 0 0 1-3 3H6m4-4-4 4 4 4"})}),"Enter"]})]}),e.jsxs("div",{ref:o.listRef,id:`${o.id}-list`,className:`${r}__list`,role:"listbox","aria-label":"Commands",style:o.listHeight?{height:o.listHeight}:void 0,onMouseLeave:t?()=>o.setHighlighted(!1):void 0,children:[o.selectionBounds&&e.jsx("span",{className:`${r}__pill`,"data-lit":t&&o.highlighted||void 0,style:{transform:`translateY(${o.selectionBounds.y}px)`,height:o.selectionBounds.height},"aria-hidden":"true"}),e.jsx("div",{ref:o.innerRef,className:`${r}__inner`,children:o.visibleGroups.map(u=>e.jsxs("div",{role:"group","aria-label":u.label,className:`${r}__group`,children:[u.key!=="ask"&&u.label&&e.jsx("span",{className:`${r}__label`,dir:"auto",children:u.label}),u.commands.map(x=>{var w,v;return e.jsx(ce,{command:x,domId:`${o.id}-${x.key}`,selected:x.key===((w=o.selected)==null?void 0:w.key),ran:((v=o.lastRun)==null?void 0:v.id)===x.key,modifier:o.modifier,query:o.trimmedQuery,handlers:o.handlers,prefix:r},x.key)})]},u.key))})]}),t&&g]}),!t&&g]})}export{me as C};
