const n=`.ui-ct {
  --ui-ct-tray: #f0f0f0;
  --ui-ct-card: #ffffff;
  --ui-ct-ink: #171717;
  --ui-ct-text: #404040;
  --ui-ct-muted: #626873;
  --ui-ct-accent: #2f6bff;
  --ui-ct-focus: rgba(0, 96, 226, 0.7);
  --ui-ct-ok: #1f8a4c;
  --ui-ct-accent-text: #2a5ee5;
  --ui-ct-border: #e5e5e5;
  --ui-ct-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-ct-hover: rgba(0, 0, 0, 0.05);
  --ui-ct-row-hover: #f5f5f5;
  --ui-ct-initials: #eef3ff;
  --ui-ct-dot: #d4d4d4;
  --ui-ct-subtle: #626873;
  --ui-ct-avatar-ring: rgba(0, 0, 0, 0.06);
  --ui-ct-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 420px;
  /* Like the Chat Composer: a gray tray with heading and reply field, the white card sits on top of it */
  background: var(--ui-ct-tray);
  /* The gray tray frames the white card on every side */
  padding: 6px;
  border-radius: 22px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-ct-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-ct *,
.ui-ct *::before,
.ui-ct *::after {
  box-sizing: border-box;
}
.ui-ct button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-ct button:focus-visible {
  outline: 2px solid var(--ui-ct-focus);
  outline-offset: 2px;
}

.ui-ct__head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 46px;
  padding: 6px 10px 6px 18px;
}
/* A long title takes two lines at most – the count and close stay in place */
.ui-ct__title {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow-wrap: anywhere;
  margin: 0;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
}
.ui-ct__count {
  flex: none;
  margin-right: auto;
  white-space: nowrap;
  font-size: 12.5px;
  color: var(--ui-ct-muted);
}
.ui-ct__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-ct-muted) !important;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-ct__icon-btn:hover {
  background: var(--ui-ct-hover);
  color: var(--ui-ct-ink) !important;
}

.ui-ct__card {
  background: var(--ui-ct-card);
  border: 1px solid var(--ui-ct-border);
  border-radius: 16px;
  box-shadow: var(--ui-ct-shadow);
}
.ui-ct__scroll {
  display: grid;
  gap: 18px;
  align-content: start;
  min-height: var(--ui-ct-min-height, 0px);
  max-height: var(--ui-ct-max-height, 340px);
  padding: 16px 18px 18px;
  overflow-y: auto;
  scrollbar-width: thin;
}
/* Each message builds up piece by piece: name row, text, status – the assistant's first reply a beat later */
.ui-ct__msg {
  --ui-ct-d: 0ms;
  min-width: 0;
}
.ui-ct__msg[data-delayed] {
  --ui-ct-d: 700ms;
}
.ui-ct__msg > * {
  animation: ui-ct-in 420ms var(--ui-ct-ease) both;
  animation-delay: var(--ui-ct-d);
}
.ui-ct__msg > :nth-child(2) {
  animation-delay: calc(var(--ui-ct-d) + 80ms);
}
.ui-ct__msg > :nth-child(3) {
  animation-delay: calc(var(--ui-ct-d) + 160ms);
}
.ui-ct__meta {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ui-ct__avatar {
  display: grid;
  place-items: center;
  flex: none;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  object-fit: cover;
  overflow: hidden;
}
img.ui-ct__avatar {
  box-shadow: 0 0 0 1px var(--ui-ct-avatar-ring);
}
.ui-ct__avatar svg {
  width: 100%;
  height: 100%;
}
.ui-ct__avatar--initials {
  background: var(--ui-ct-initials);
  font-size: 9px;
  font-weight: 600;
  color: var(--ui-ct-accent-text);
}
.ui-ct__name {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ct__time {
  flex: none;
  margin-left: auto;
  white-space: nowrap;
  font-size: 12.5px;
  color: var(--ui-ct-muted);
  font-variant-numeric: tabular-nums;
}
.ui-ct__text {
  margin: 8px 0 0;
  font-size: 14px;
  line-height: 21px;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  color: var(--ui-ct-text);
}
.ui-ct__command {
  color: var(--ui-ct-muted);
}

.ui-ct__status {
  margin-top: 8px;
}
.ui-ct__status-btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  max-width: 100%;
  height: 26px;
  padding: 0 6px 0 8px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 14px !important;
  transition: background-color 140ms ease;
}
/* The global button reset sets margin: 0 – shift the row so the check icon sits centered under the avatars */
.ui-ct .ui-ct__status-btn {
  margin-left: -4px;
}
.ui-ct__status-btn:hover:not(:disabled) {
  background: var(--ui-ct-row-hover);
}
.ui-ct__status-btn:disabled {
  cursor: default;
}
.ui-ct__status-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ct__check,
.ui-ct__chevron {
  flex: none;
}
.ui-ct__check {
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--ui-ct-ok);
  color: #fff;
}
.ui-ct__chevron {
  display: grid;
  color: var(--ui-ct-muted);
  transition: transform 260ms var(--ui-ct-ease);
}
.ui-ct__status-btn[aria-expanded="true"] .ui-ct__chevron {
  transform: rotate(180deg);
}
.ui-ct__details {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 320ms var(--ui-ct-ease);
}
.ui-ct__details[data-open] {
  grid-template-rows: 1fr;
}
.ui-ct__details ul {
  min-height: 0;
  overflow: hidden;
  margin: 0;
  padding: 0 0 0 28px;
  list-style: none;
}
.ui-ct__details li {
  position: relative;
  margin-top: 6px;
  font-size: 13px;
  line-height: 19px;
  overflow-wrap: anywhere;
  text-align: start;
  color: var(--ui-ct-muted);
  /* Closing: lines fade out quickly while the box folds */
  opacity: 0;
  transform: translateY(-4px);
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-ct-ease);
}
/* Opening: lines come in one after another */
.ui-ct__details[data-open] li {
  opacity: 1;
  transform: none;
  transition-duration: 320ms, 420ms;
  transition-delay: calc(60ms + var(--i, 0) * 60ms);
}
/* Tree lines instead of dots: each line gets its own corner – down on the axis of the check icon, then a rounded turn right */
.ui-ct__details li:first-child {
  margin-top: 5px;
}
.ui-ct__details li::before {
  content: "";
  position: absolute;
  left: -16.625px;
  top: -3px;
  width: 10.5px;
  height: 13px;
  border-left: 1.25px solid var(--ui-ct-dot);
  border-bottom: 1.25px solid var(--ui-ct-dot);
  border-bottom-left-radius: 5px;
}
/* The first branch starts with a small gap under the check icon */
.ui-ct__details li:first-child::before {
  top: -5px;
  height: 15px;
}

.ui-ct__thinking {
  display: inline-block;
  margin: 8px 0 0;
  font-size: 14px;
  background: linear-gradient(
    90deg,
    var(--ui-ct-subtle) 0%,
    var(--ui-ct-subtle) 35%,
    rgba(255, 255, 255, 0.9) 50%,
    var(--ui-ct-subtle) 65%,
    var(--ui-ct-subtle) 100%
  );
  background-size: 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ui-ct-shine 1.6s linear infinite;
}

.ui-ct__composer {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 9px 9px 18px;
}
.ui-ct__input {
  flex: 1;
  min-width: 0;
  height: 32px;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--ui-ct-ink);
}
.ui-ct__input::placeholder {
  color: var(--ui-ct-subtle);
}
.ui-ct__send {
  display: grid;
  place-items: center;
  flex: none;
  width: 30px;
  height: 30px;
  padding: 0;
  border: 0;
  border-radius: 50%;
  background: linear-gradient(#323137, #201e25);
  box-shadow:
    0 0 0 1px #0d0d0d,
    0 2px 4px rgba(0, 0, 0, 0.1);
  color: #fff !important;
  transition:
    opacity 160ms ease,
    transform 160ms ease;
}
.ui-ct__send:disabled {
  opacity: 0.3;
  cursor: default;
}
.ui-ct__send:not(:disabled):active {
  transform: scale(0.94);
}

@keyframes ui-ct-in {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
}
@keyframes ui-ct-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ct__msg > *,
  .ui-ct__thinking {
    animation: none;
  }
  .ui-ct__details,
  .ui-ct__details li,
  .ui-ct__chevron {
    transition: none;
  }
}

/* Height changes glide instead of jumping */
.ui-ct__morph {
  overflow: hidden;
}
.ui-ct__morph[data-smooth] {
  transition: height 380ms cubic-bezier(0.22, 1, 0.36, 1);
}
@media (prefers-reduced-motion: reduce) {
  .ui-ct__morph[data-smooth] {
    transition: none;
  }
}

/* Text fields: no focus box while typing – also against global :focus-visible rules of the host page */
.ui-ct input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-ct textarea:focus-visible,
.ui-ct [contenteditable]:focus-visible {
  outline: none;
}
/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-ct {
  --ui-ct-focus: rgba(77, 141, 255, 0.8);
  --ui-ct-tray: #161618;
  --ui-ct-card: #232326;
  --ui-ct-ink: #ededed;
  --ui-ct-text: #c4c4c4;
  --ui-ct-muted: #8f8f8f;
  --ui-ct-ok: #2a9d5c;
  --ui-ct-accent-text: #6b95ff;
  --ui-ct-border: rgba(255, 255, 255, 0.08);
  --ui-ct-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-ct-hover: rgba(255, 255, 255, 0.06);
  --ui-ct-row-hover: rgba(255, 255, 255, 0.06);
  --ui-ct-initials: rgba(47, 107, 255, 0.16);
  --ui-ct-dot: rgba(255, 255, 255, 0.14);
  --ui-ct-subtle: #6b6b70;
  --ui-ct-avatar-ring: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-ct__send {
  background: linear-gradient(#f4f4f5, #e4e4e7);
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.6),
    0 2px 4px rgba(0, 0, 0, 0.35),
    inset 0 1px 0 #ffffff;
  color: #121213 !important;
}
`;export{n as default};
