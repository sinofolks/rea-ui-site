const n=`.ui-cb {
  --ui-cb-tray: #f0f0f0;
  --ui-cb-card: #ffffff;
  --ui-cb-line: #ececec;
  --ui-cb-ink: #171717;
  --ui-cb-text: #404040;
  --ui-cb-muted: #626873;
  --ui-cb-well: #f4f4f5;
  --ui-cb-hover: #f4f4f5;
  --ui-cb-up: #18794e;
  --ui-cb-up-bg: rgba(34, 160, 90, 0.1);
  --ui-cb-down: #b42318;
  --ui-cb-down-bg: rgba(220, 60, 60, 0.08);
  --ui-cb-c1: #2f6bff;
  --ui-cb-c2: #74a0ff;
  --ui-cb-c3: #b4cbff;
  --ui-cb-c4: #a8a8ae;
  --ui-cb-c5: #d4d4d8;
  --ui-cb-focus: rgba(0, 96, 226, 0.7);
  --ui-cb-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 360px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cb-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 1.45;
  color: var(--ui-cb-text);
  -webkit-font-smoothing: antialiased;
}
.ui-cb *,
.ui-cb *::before,
.ui-cb *::after {
  box-sizing: border-box;
}
:where(.ui-cb) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cb) :is(h3, p, ul) {
  margin: 0;
  padding: 0;
}
:where(.ui-cb) ul {
  list-style: none;
}
.ui-cb :is(button, [tabindex="0"]):focus-visible {
  outline: 2px solid var(--ui-cb-focus);
  outline-offset: 2px;
}
.ui-cb b {
  font-weight: 500;
  color: var(--ui-cb-ink);
}
.ui-cb__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
}
.ui-cb__card {
  border-radius: 16px;
  background: var(--ui-cb-card);
  box-shadow:
    0 0 0 1px var(--ui-cb-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  padding: 12px 14px 8px;
}
.ui-cb__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 30px;
}
.ui-cb__title {
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-cb-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cb__switch {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, auto);
  grid-auto-flow: column;
  flex: 0 1 auto;
  min-width: 0;
  padding: 2px;
  border-radius: 10px;
  background: var(--ui-cb-well);
  box-shadow: inset 0 0 0 1px var(--ui-cb-line);
}
.ui-cb__pill {
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 8px;
  background: var(--ui-cb-card);
  box-shadow:
    0 0 0 1px var(--ui-cb-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 420ms var(--ui-cb-ease),
    width 420ms var(--ui-cb-ease);
}
.ui-cb__option {
  position: relative;
  z-index: 1;
  height: 24px;
  padding: 0 8px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-cb-muted);
  white-space: nowrap;
  transition: color 200ms ease;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cb__option:hover,
.ui-cb__option[aria-checked="true"] {
  color: var(--ui-cb-ink);
}
.ui-cb__figure {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 12px;
}
.ui-cb__big {
  font-size: 26px;
  font-weight: 600;
  line-height: 32px;
  letter-spacing: -0.02em;
  color: var(--ui-cb-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cb__delta {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  height: 20px;
  padding: 0 6px 0 4px;
  border-radius: 999px;
  background: var(--ui-cb-down-bg);
  color: var(--ui-cb-down);
  font-size: 12px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  animation: ui-cb-pop 380ms var(--ui-cb-ease) both;
}
.ui-cb__delta[data-up] {
  background: var(--ui-cb-up-bg);
  color: var(--ui-cb-up);
}
.ui-cb__delta svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cb__caption {
  height: 18px;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-cb-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cb__caption-label {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cb__caption-share {
  flex: none;
}
.ui-cb__caption-in {
  display: inline-flex;
  max-width: 100%;
  align-items: center;
  gap: 6px;
  animation: ui-cb-in 260ms var(--ui-cb-ease) both;
}
.ui-cb__bar {
  display: flex;
  gap: 2px;
  height: 8px;
  margin-top: 12px;
  padding: 0;
  border-radius: 4px;
}
.ui-cb__seg {
  flex: 0 1 0;
  height: 100%;
  min-width: 2px;
  border-radius: 2.5px;
  transition:
    opacity 200ms ease,
    transform 260ms var(--ui-cb-ease);
}
.ui-cb__seg:first-child {
  border-radius: 4px 2.5px 2.5px 4px;
}
.ui-cb__seg:last-child {
  border-radius: 2.5px 4px 4px 2.5px;
}
.ui-cb__bar[data-active] .ui-cb__seg:not([data-active]) {
  opacity: 0.25;
}
.ui-cb__seg[data-active] {
  transform: scaleY(1.5);
}
.ui-cb__list {
  position: relative;
  display: grid;
  margin-top: 8px;
}
.ui-cb__row {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 320ms var(--ui-cb-ease),
    opacity 200ms ease;
}
.ui-cb__row[data-leaving] {
  grid-template-rows: 0fr;
  opacity: 0;
  pointer-events: none;
}
.ui-cb__item {
  display: flex;
  align-items: center;
  gap: 9px;
  min-height: 0;
  height: 30px;
  margin: 0 -8px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 8px;
  cursor: default;
  transition:
    background-color 160ms ease,
    opacity 200ms ease;
}
.ui-cb__item[data-active] {
  background: var(--ui-cb-hover);
}
.ui-cb__list[data-active] .ui-cb__item:not([data-active]) {
  opacity: 0.45;
}
.ui-cb__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2.5px;
}
.ui-cb__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cb-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cb__value {
  flex: none;
  white-space: nowrap;
  color: var(--ui-cb-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-cb__share {
  flex: none;
  width: 34px;
  white-space: nowrap;
  text-align: right;
  color: var(--ui-cb-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cb__foot {
  display: flex;
  align-items: center;
  min-height: 34px;
  padding: 4px 10px 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cb-muted);
  white-space: nowrap;
}
.ui-cb__foot-in {
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cb-in 320ms var(--ui-cb-ease) both;
}
@keyframes ui-cb-in {
  from {
    opacity: 0;
    transform: translateY(5px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-cb-pop {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 250px) {
  .ui-cb__share {
    display: none;
  }
  .ui-cb__option {
    padding: 0 6px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cb__option {
    height: 32px;
    padding: 0 10px;
  }
  .ui-cb__item {
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cb *,
  .ui-cb *::before,
  .ui-cb *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cb {
  --ui-cb-tray: #111113;
  --ui-cb-card: #19191b;
  --ui-cb-line: #2a2a2e;
  --ui-cb-ink: #ededed;
  --ui-cb-text: #c8c8cc;
  --ui-cb-muted: #8b8b92;
  --ui-cb-well: #222225;
  --ui-cb-hover: #222225;
  --ui-cb-up: #6ee7a8;
  --ui-cb-up-bg: rgba(110, 231, 168, 0.12);
  --ui-cb-down: #ff8a80;
  --ui-cb-down-bg: rgba(255, 138, 128, 0.12);
  --ui-cb-c1: #5b8cff;
  --ui-cb-c2: #3d63c9;
  --ui-cb-c3: #2c4388;
  --ui-cb-c4: #6b6b73;
  --ui-cb-c5: #3d3d42;
  --ui-cb-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-cb__pill {
  background: #2a2a2e;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.06);
}
`;export{n as default};
