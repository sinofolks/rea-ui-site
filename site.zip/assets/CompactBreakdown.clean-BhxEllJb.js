const n=`.ui-cbc {
  --ui-cbc-card: #ffffff;
  --ui-cbc-ink: rgba(0, 0, 0, 0.88);
  --ui-cbc-strong: #000000;
  --ui-cbc-text: rgba(0, 0, 0, 0.65);
  --ui-cbc-muted: rgba(0, 0, 0, 0.65);
  --ui-cbc-faint: rgba(0, 0, 0, 0.27);
  --ui-cbc-line: rgba(0, 0, 0, 0.06);
  --ui-cbc-wash: rgba(0, 0, 0, 0.03);
  --ui-cbc-fill: rgba(0, 0, 0, 0.06);
  --ui-cbc-up: #0f783c;
  --ui-cbc-up-bg: rgba(26, 154, 82, 0.08);
  --ui-cbc-down: #bf383d;
  --ui-cbc-down-bg: rgba(229, 72, 77, 0.08);
  --ui-cbc-c1: rgba(0, 96, 226, 0.765);
  --ui-cbc-c2: rgba(0, 96, 226, 0.5);
  --ui-cbc-c3: rgba(0, 96, 226, 0.32);
  --ui-cbc-c4: rgba(0, 96, 226, 0.18);
  --ui-cbc-c5: rgba(0, 0, 0, 0.14);
  --ui-cbc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cbc-focus: rgba(0, 96, 226, 0.7);
  --ui-cbc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-cbc-snap: cubic-bezier(0.25, 0.9, 0.3, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 360px;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-cbc-card);
  box-shadow: var(--ui-cbc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cbc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cbc *,
.ui-cbc *::before,
.ui-cbc *::after {
  box-sizing: border-box;
}
:where(.ui-cbc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cbc) :is(h3, p, ul) {
  margin: 0;
  padding: 0;
}
:where(.ui-cbc) ul {
  list-style: none;
}
:where(.ui-cbc) svg {
  display: block;
  flex: none;
}
.ui-cbc :is(button, [tabindex="0"]):focus-visible {
  outline: 2px solid var(--ui-cbc-focus);
  outline-offset: 2px;
}
.ui-cbc b {
  font-weight: 500;
  color: var(--ui-cbc-ink);
}
.ui-cbc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
}
.ui-cbc__body {
  padding: 16px 16px 10px;
}
.ui-cbc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 28px;
}
.ui-cbc__title {
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-cbc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cbc__switch {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, auto);
  grid-auto-flow: column;
  gap: 4px;
  flex: 0 1 auto;
  min-width: 0;
}
.ui-cbc__pill {
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 6px;
  background: var(--ui-cbc-fill);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 200ms var(--ui-cbc-snap),
    width 200ms var(--ui-cbc-snap);
}
.ui-cbc__option {
  position: relative;
  z-index: 1;
  height: 28px;
  padding: 4px 10px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cbc-line);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cbc-text);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  transition:
    color 90ms ease,
    background-color 90ms ease;
}
.ui-cbc__option[aria-checked="true"] {
  color: var(--ui-cbc-ink);
}
@media (hover: hover) {
  .ui-cbc__option[aria-checked="false"]:hover {
    background: var(--ui-cbc-wash);
  }
}
.ui-cbc__figure {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 14px;
}
.ui-cbc__big {
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.02em;
  color: var(--ui-cbc-strong);
  font-variant-numeric: tabular-nums;
}
.ui-cbc__delta {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  height: 20px;
  padding: 0 6px 0 4px;
  border-radius: 5px;
  background: var(--ui-cbc-down-bg);
  color: var(--ui-cbc-down);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  animation: ui-cbc-pop 380ms var(--ui-cbc-ease) both;
}
.ui-cbc__delta[data-up] {
  background: var(--ui-cbc-up-bg);
  color: var(--ui-cbc-up);
}
.ui-cbc__delta svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.3;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cbc__caption {
  height: 16px;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cbc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cbc__caption-label {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cbc__caption-share {
  flex: none;
}
.ui-cbc__caption-in {
  display: inline-flex;
  max-width: 100%;
  align-items: center;
  gap: 6px;
  animation: ui-cbc-in 260ms var(--ui-cbc-ease) both;
}
.ui-cbc__bar {
  display: flex;
  gap: 2px;
  height: 6px;
  margin-top: 16px;
  padding: 0;
  border-radius: 3px;
}
.ui-cbc__seg {
  flex: 0 1 0;
  height: 100%;
  min-width: 2px;
  border-radius: 1.5px;
  transition:
    opacity 160ms ease,
    transform 200ms var(--ui-cbc-ease);
}
.ui-cbc__seg:first-child {
  border-radius: 3px 1.5px 1.5px 3px;
}
.ui-cbc__seg:last-child {
  border-radius: 1.5px 3px 3px 1.5px;
}
.ui-cbc__bar[data-active] .ui-cbc__seg:not([data-active]) {
  opacity: 0.3;
}
.ui-cbc__seg[data-active] {
  transform: scaleY(1.5);
}
.ui-cbc__list {
  position: relative;
  display: grid;
  margin-top: 10px;
}
.ui-cbc__row {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 320ms var(--ui-cbc-ease),
    opacity 200ms ease;
}
.ui-cbc__row[data-leaving] {
  grid-template-rows: 0fr;
  opacity: 0;
  pointer-events: none;
}
.ui-cbc__item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 0;
  height: 32px;
  margin: 0 -8px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 6px;
  cursor: default;
  transition:
    background-color 90ms ease-out,
    opacity 160ms ease;
}
.ui-cbc__item[data-active] {
  background: var(--ui-cbc-wash);
}
.ui-cbc__list[data-active] .ui-cbc__item:not([data-active]) {
  opacity: 0.45;
}
.ui-cbc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-cbc__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cbc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cbc__value {
  flex: none;
  white-space: nowrap;
  color: var(--ui-cbc-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-cbc__share {
  flex: none;
  width: 34px;
  white-space: nowrap;
  font-size: 12px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-cbc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cbc__foot {
  display: flex;
  align-items: center;
  min-height: 40px;
  padding: 0 16px;
  overflow: hidden;
  border-top: 0.5px solid var(--ui-cbc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cbc-muted);
  white-space: nowrap;
}
.ui-cbc__foot-in {
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cbc-in 320ms var(--ui-cbc-ease) both;
}
@keyframes ui-cbc-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-cbc-pop {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 320px) {
  .ui-cbc__body {
    padding: 14px 14px 8px;
  }
  .ui-cbc__foot {
    padding: 0 14px;
  }
  .ui-cbc__switch {
    gap: 2px;
  }
  .ui-cbc__option {
    padding: 4px 8px;
  }
}
@container (max-width: 250px) {
  .ui-cbc__share {
    display: none;
  }
  .ui-cbc__option {
    padding: 4px 6px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cbc__option {
    height: 32px;
    padding: 6px 10px;
  }
  .ui-cbc__item {
    height: 40px;
  }
  .ui-cbc__foot {
    min-height: 44px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cbc *,
  .ui-cbc *::before,
  .ui-cbc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cbc {
  --ui-cbc-card: #1c1c1e;
  --ui-cbc-ink: rgba(255, 255, 255, 0.9);
  --ui-cbc-strong: #ffffff;
  --ui-cbc-text: rgba(255, 255, 255, 0.62);
  --ui-cbc-muted: rgba(255, 255, 255, 0.46);
  --ui-cbc-faint: rgba(255, 255, 255, 0.3);
  --ui-cbc-line: rgba(255, 255, 255, 0.08);
  --ui-cbc-wash: rgba(255, 255, 255, 0.04);
  --ui-cbc-fill: rgba(255, 255, 255, 0.08);
  --ui-cbc-up: #3ec27a;
  --ui-cbc-up-bg: rgba(62, 194, 122, 0.14);
  --ui-cbc-down: #ff6b70;
  --ui-cbc-down-bg: rgba(229, 72, 77, 0.14);
  --ui-cbc-c1: #4d8dff;
  --ui-cbc-c2: rgba(77, 141, 255, 0.62);
  --ui-cbc-c3: rgba(77, 141, 255, 0.4);
  --ui-cbc-c4: rgba(77, 141, 255, 0.22);
  --ui-cbc-c5: rgba(255, 255, 255, 0.16);
  --ui-cbc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-cbc-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
