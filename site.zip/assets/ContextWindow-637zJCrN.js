const n=`.ui-cw {
  --ui-cw-tray: #f0f0f0;
  --ui-cw-card: #ffffff;
  --ui-cw-line: #ececec;
  --ui-cw-ink: #171717;
  --ui-cw-text: #404040;
  --ui-cw-muted: #626873;
  --ui-cw-well: #f4f4f5;
  --ui-cw-free: #ededf0;
  --ui-cw-c1: #26262b;
  --ui-cw-c2: #8d8d95;
  --ui-cw-c3: #c4c4ca;
  --ui-cw-c4: #2f6bff;
  --ui-cw-c5: #a9c4ff;
  --ui-cw-c6: #5f5f66;
  --ui-cw-warn: #9e5a03;
  --ui-cw-warn-bg: rgba(240, 160, 32, 0.14);
  --ui-cw-full: #b42318;
  --ui-cw-full-bg: rgba(229, 72, 77, 0.1);
  --ui-cw-ok: #18794e;
  --ui-cw-ok-bg: rgba(34, 160, 90, 0.11);
  --ui-cw-focus: rgba(0, 96, 226, 0.7);
  --ui-cw-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 360px;
  min-width: 0;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cw-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cw-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-cw *,
.ui-cw *::before,
.ui-cw *::after {
  box-sizing: border-box;
}
:where(.ui-cw) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-cw button:focus-visible {
  outline: 2px solid var(--ui-cw-focus);
  outline-offset: 2px;
}
.ui-cw svg {
  display: block;
  flex: none;
}
.ui-cw b {
  font-weight: 500;
  color: var(--ui-cw-ink);
}
.ui-cw ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-cw__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-cw__card {
  position: relative;
  padding: 12px 14px 8px;
  border-radius: 16px;
  background: var(--ui-cw-card);
  box-shadow:
    0 0 0 1px var(--ui-cw-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cw__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 22px;
}
.ui-cw__title {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__model {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  max-width: 62%;
  height: 20px;
  padding: 0 7px 0 6px;
  border-radius: 5px;
  background: var(--ui-cw-well);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11px;
  line-height: 20px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
}
.ui-cw__model > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__model-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-cw__model-icon > * {
  width: 12px;
  height: 12px;
}
.ui-cw__figure {
  display: flex;
  align-items: baseline;
  gap: 7px;
  margin-top: 8px;
}
.ui-cw__big {
  font-size: 24px;
  font-weight: 600;
  line-height: 30px;
  letter-spacing: -0.02em;
  color: var(--ui-cw-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cw__of {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__pill {
  align-self: baseline;
  flex: none;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  font-variant-numeric: tabular-nums;
  transition: color 300ms ease;
}
.ui-cw[data-level="warn"] .ui-cw__pill {
  color: var(--ui-cw-warn);
}
.ui-cw[data-level="full"] .ui-cw__pill {
  color: var(--ui-cw-full);
}
.ui-cw__field {
  display: grid;
  grid-template-columns: repeat(var(--ui-cw-cols), minmax(0, 1fr));
  gap: 2px;
  margin-top: 10px;
}
.ui-cw__cell {
  aspect-ratio: 1;
  border-radius: 26%;
  background: var(--ui-cw-color);
  transition:
    background-color 380ms ease,
    opacity 220ms ease,
    transform 300ms var(--ui-cw-ease);
  transition-delay: calc(var(--i) * 2ms), 0ms, 0ms;
}
.ui-cw__cell[data-free] {
  background: var(--ui-cw-free);
}
.ui-cw__field[data-hot] .ui-cw__cell:not([data-on], [data-free]) {
  opacity: 0.22;
}
.ui-cw__cell[data-on] {
  transform: scale(1.12);
}
.ui-cw__cell[data-busy] {
  animation: ui-cw-wave 900ms ease-in-out infinite;
  animation-delay: calc(var(--i) * 15ms);
}
.ui-cw__parts {
  margin-top: 8px !important;
}
.ui-cw__part {
  margin: 0 -8px;
  padding: 0 8px;
  border-radius: 10px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-cw__part[data-hot] {
  background: var(--ui-cw-well);
}
.ui-cw__part[data-dim] {
  opacity: 0.55;
}
.ui-cw__row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 30px;
}
.ui-cw__main {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 9px;
  min-width: 0;
  height: 30px;
  border-radius: 8px;
}
.ui-cw__swatch {
  flex: none;
  width: 7px;
  height: 7px;
  border-radius: 26%;
}
.ui-cw__label {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 3px;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__label-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__value {
  flex: none;
  min-width: 52px;
  text-align: right;
  color: var(--ui-cw-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cw__open {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-cw-muted);
}
.ui-cw__chevron {
  transition: transform 300ms var(--ui-cw-ease);
}
.ui-cw__open[data-open] .ui-cw__chevron {
  transform: rotate(180deg);
}
.ui-cw__compact {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 22px;
  margin-right: -10px;
  padding: 0 6px 0 5px;
  border-radius: 7px;
  font-size: 12px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-cw__compact:hover:not(:disabled) {
  background: var(--ui-cw-line);
  color: var(--ui-cw-ink);
}
.ui-cw__compact:disabled {
  cursor: default;
  opacity: 0.5;
}
.ui-cw__compact[data-busy] {
  opacity: 1;
  color: var(--ui-cw-ink);
}
.ui-cw__compact[data-done] {
  opacity: 1;
  color: var(--ui-cw-ok);
}
.ui-cw__compact[data-leaving] {
  animation: ui-cw-leave 400ms var(--ui-cw-ease) both;
}
.ui-cw__compact-icon {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
  animation: ui-cw-swap-in 300ms ease both;
}
.ui-cw__compact-text {
  animation: ui-cw-swap-in 300ms ease both;
}
.ui-cw__spinner {
  width: 12px;
  height: 12px;
  border: 1.5px solid var(--ui-cw-line);
  border-top-color: var(--ui-cw-ink);
  border-radius: 50%;
  animation: ui-cw-spin 700ms linear infinite;
}
.ui-cw__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-cw-ease),
    opacity 240ms ease;
}
.ui-cw__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-cw-ease),
    opacity 320ms ease 80ms;
}
.ui-cw__fold--item {
  transition-duration: 240ms, 180ms;
}
.ui-cw__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-cw__items {
  padding: 0 0 8px 17px !important;
}
.ui-cw__item {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 28px;
  font-size: 12.5px;
}
.ui-cw__item-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__item-value {
  flex: none;
  color: var(--ui-cw-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cw__remove {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 7px;
  color: var(--ui-cw-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-cw__remove:hover {
  background: var(--ui-cw-full-bg);
  color: var(--ui-cw-full);
}
.ui-cw__empty {
  height: 28px;
  font-size: 12.5px;
  line-height: 28px;
  color: var(--ui-cw-muted);
}
.ui-cw__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 38px;
  padding: 4px 4px 0 10px;
}
.ui-cw__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-cw__hot {
  display: flex;
  min-width: 0;
}
.ui-cw__hot > b {
  min-width: 32px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__hot > span {
  flex: none;
  white-space: pre;
}
.ui-cw__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__swap {
  display: grid;
  min-width: 0;
}
.ui-cw__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cw-swap-in 320ms ease both;
}
.ui-cw__swap-item[data-out] {
  animation: ui-cw-swap-out 220ms ease both;
}
.ui-cw__swap-item[data-tone="ok"] {
  color: var(--ui-cw-ok);
}
.ui-cw__swap-item[data-tone="ok"] b {
  color: inherit;
}
.ui-cw__action {
  display: inline-flex;
  flex: 0 1 auto;
  align-items: center;
  min-width: 0;
  max-width: 50%;
  gap: 4px;
  height: 26px;
  padding: 0 6px 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-cw-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-cw__action:hover {
  background: var(--ui-cw-card);
  color: var(--ui-cw-ink);
}
.ui-cw__action svg {
  transition: transform 220ms var(--ui-cw-ease);
}
.ui-cw__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-cw-leave {
  to {
    opacity: 0;
    filter: blur(3px);
    transform: scale(0.92);
  }
}
@keyframes ui-cw-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cw-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cw-wave {
  0%,
  100% {
    opacity: 1;
    transform: none;
  }
  50% {
    opacity: 0.28;
    transform: scale(0.72);
  }
}
@keyframes ui-cw-spin {
  to {
    transform: rotate(360deg);
  }
}
@container (max-width: 310px) {
  .ui-cw__model {
    max-width: 42%;
  }
  .ui-cw__field {
    grid-template-columns: repeat(var(--ui-cw-cols-narrow), minmax(0, 1fr));
  }
  .ui-cw__compact {
    padding: 0 6px;
  }
  .ui-cw__compact-text {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-cw__row {
    min-height: 38px;
  }
  .ui-cw__main {
    height: 38px;
  }
  .ui-cw__compact {
    height: 30px;
    padding: 0 9px 0 7px;
  }
  .ui-cw__item {
    height: 34px;
  }
  .ui-cw__remove {
    width: 30px;
    height: 30px;
  }
  .ui-cw__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cw *,
  .ui-cw *::before,
  .ui-cw *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cw {
  --ui-cw-tray: #111113;
  --ui-cw-card: #19191b;
  --ui-cw-line: #2a2a2e;
  --ui-cw-ink: #ededed;
  --ui-cw-text: #c8c8cc;
  --ui-cw-muted: #8b8b92;
  --ui-cw-well: #222225;
  --ui-cw-free: #2a2a2e;
  --ui-cw-c1: #e4e4e7;
  --ui-cw-c2: #8a8a92;
  --ui-cw-c3: #55555c;
  --ui-cw-c4: #4f82ff;
  --ui-cw-c5: #8fb1ff;
  --ui-cw-warn: #f5c264;
  --ui-cw-full: #ff9b93;
  --ui-cw-ok: #6ee7a8;
  --ui-cw-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
