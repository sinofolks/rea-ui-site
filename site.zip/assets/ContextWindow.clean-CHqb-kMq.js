const n=`.ui-cwc {
  --ui-cwc-card: #ffffff;
  --ui-cwc-strong: #000000;
  --ui-cwc-ink: rgba(0, 0, 0, 0.88);
  --ui-cwc-text: rgba(0, 0, 0, 0.65);
  --ui-cwc-muted: rgba(0, 0, 0, 0.65);
  --ui-cwc-faint: rgba(0, 0, 0, 0.27);
  --ui-cwc-icon: rgba(0, 0, 0, 0.65);
  --ui-cwc-line: rgba(0, 0, 0, 0.06);
  --ui-cwc-fill: rgba(0, 0, 0, 0.06);
  --ui-cwc-wash: rgba(0, 0, 0, 0.03);
  --ui-cwc-free: rgba(0, 0, 0, 0.06);
  --ui-cwc-c1: rgba(0, 96, 226, 0.765);
  --ui-cwc-c2: rgba(0, 96, 226, 0.5);
  --ui-cwc-c3: rgba(0, 96, 226, 0.26);
  --ui-cwc-c4: rgba(91, 91, 214, 0.8);
  --ui-cwc-c5: rgba(26, 154, 82, 0.72);
  --ui-cwc-c6: rgba(232, 162, 12, 0.8);
  --ui-cwc-accent: rgba(0, 96, 226, 0.765);
  --ui-cwc-warn: #916100;
  --ui-cwc-warn-bg: rgba(232, 162, 12, 0.12);
  --ui-cwc-full: #bf353a;
  --ui-cwc-full-bg: rgba(229, 72, 77, 0.08);
  --ui-cwc-ok: #0f783c;
  --ui-cwc-ok-bg: rgba(26, 154, 82, 0.08);
  --ui-cwc-shine: rgba(255, 255, 255, 0.82);
  --ui-cwc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cwc-focus: rgba(0, 96, 226, 0.7);
  --ui-cwc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 360px;
  min-width: 0;
  container-type: inline-size;
  border-radius: 10px;
  background: var(--ui-cwc-card);
  box-shadow: var(--ui-cwc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cwc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-cwc *,
.ui-cwc *::before,
.ui-cwc *::after {
  box-sizing: border-box;
}
:where(.ui-cwc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-cwc button:focus-visible {
  outline: 2px solid var(--ui-cwc-focus);
  outline-offset: 2px;
}
:where(.ui-cwc) svg {
  display: block;
  flex: none;
}
.ui-cwc b {
  font-weight: 500;
  color: var(--ui-cwc-ink);
}
.ui-cwc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-cwc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-cwc__card {
  position: relative;
  padding: 14px 16px 8px;
}
.ui-cwc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 20px;
}
.ui-cwc__title {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cwc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cwc__model {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  max-width: 62%;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-cwc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cwc-text);
  white-space: nowrap;
}
.ui-cwc__model > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cwc__model-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-cwc__model-icon > * {
  width: 12px;
  height: 12px;
}
.ui-cwc__figure {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
}
.ui-cwc__big {
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.02em;
  color: var(--ui-cwc-strong);
  font-variant-numeric: tabular-nums;
}
.ui-cwc__of {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  padding-top: 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cwc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cwc__pill {
  flex: none;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-cwc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cwc-text);
  font-variant-numeric: tabular-nums;
  transition:
    color 300ms ease,
    background-color 300ms ease;
}
.ui-cwc[data-level="warn"] .ui-cwc__pill {
  background: var(--ui-cwc-warn-bg);
  color: var(--ui-cwc-warn);
}
.ui-cwc[data-level="full"] .ui-cwc__pill {
  background: var(--ui-cwc-full-bg);
  color: var(--ui-cwc-full);
}
.ui-cwc__field {
  display: grid;
  grid-template-columns: repeat(var(--ui-cwc-cols), minmax(0, 1fr));
  gap: 2px;
  margin-top: 10px;
}
.ui-cwc__cell {
  position: relative;
  aspect-ratio: 1;
  border-radius: 2px;
  background: var(--ui-cwc-color);
  transition:
    background-color 380ms ease,
    opacity 220ms ease,
    transform 300ms var(--ui-cwc-ease);
  transition-delay: calc(var(--i) * 2ms), 0ms, 0ms;
}
.ui-cwc__cell[data-free] {
  background: var(--ui-cwc-free);
}
.ui-cwc__field[data-hot] .ui-cwc__cell:not([data-on], [data-free]) {
  opacity: 0.25;
}
.ui-cwc__cell[data-on] {
  transform: scale(1.1);
}
.ui-cwc__cell::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-cwc-shine);
  opacity: 0;
  pointer-events: none;
}
.ui-cwc__cell[data-busy] {
  animation: ui-cwc-wave 900ms ease-in-out infinite;
  animation-delay: calc(var(--i) * 15ms);
}
.ui-cwc__cell[data-busy]::after {
  animation: ui-cwc-shine 900ms ease-in-out infinite;
  animation-delay: calc(var(--i) * 15ms);
}
.ui-cwc__parts {
  margin-top: 10px !important;
}
.ui-cwc__part {
  margin: 0 -8px;
  padding: 0 8px;
  border-radius: 6px;
  transition:
    background-color 120ms ease-out,
    opacity 220ms ease;
}
.ui-cwc__part[data-hot] {
  background: var(--ui-cwc-wash);
}
.ui-cwc__part[data-dim] {
  opacity: 0.5;
}
.ui-cwc__row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 32px;
}
.ui-cwc__main {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 32px;
  border-radius: 6px;
}
.ui-cwc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-cwc__label {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 2px;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cwc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cwc__label-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cwc__value {
  flex: none;
  min-width: 52px;
  text-align: right;
  color: var(--ui-cwc-text);
  font-variant-numeric: tabular-nums;
  transition: color 160ms ease;
}
.ui-cwc__part[data-hot] .ui-cwc__value {
  color: var(--ui-cwc-ink);
}
.ui-cwc__open {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-cwc-icon);
}
.ui-cwc__chevron {
  transition: transform 300ms var(--ui-cwc-ease);
}
.ui-cwc__open[data-open] .ui-cwc__chevron {
  transform: rotate(180deg);
}
.ui-cwc__compact {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  margin-right: -8px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cwc-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-cwc__compact:hover:not(:disabled) {
  background: var(--ui-cwc-fill);
  color: var(--ui-cwc-ink);
}
.ui-cwc__compact:disabled {
  cursor: default;
  opacity: 0.5;
}
.ui-cwc__compact[data-busy] {
  opacity: 1;
  color: var(--ui-cwc-ink);
}
.ui-cwc__compact[data-done] {
  opacity: 1;
  background: var(--ui-cwc-ok-bg);
  color: var(--ui-cwc-ok);
}
.ui-cwc__compact[data-leaving] {
  animation: ui-cwc-leave 400ms var(--ui-cwc-ease) both;
}
.ui-cwc__compact-icon {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
  animation: ui-cwc-swap-in 300ms ease both;
}
.ui-cwc__compact-text {
  animation: ui-cwc-swap-in 300ms ease both;
}
.ui-cwc__spinner {
  width: 11px;
  height: 11px;
  border: 1.25px solid var(--ui-cwc-fill);
  border-top-color: var(--ui-cwc-accent);
  border-radius: 50%;
  animation: ui-cwc-spin 700ms linear infinite;
}
.ui-cwc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-cwc-ease),
    opacity 240ms ease;
}
.ui-cwc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-cwc-ease),
    opacity 320ms ease 80ms;
}
.ui-cwc__fold--item {
  transition-duration: 240ms, 180ms;
}
.ui-cwc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-cwc__items {
  padding: 0 0 6px 18px !important;
}
.ui-cwc__item {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 28px;
  margin-right: -4px;
  font-size: 12px;
  line-height: 16px;
}
.ui-cwc__item-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cwc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cwc__item-value {
  flex: none;
  color: var(--ui-cwc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cwc__remove {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--ui-cwc-icon);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-cwc__remove:hover {
  background: var(--ui-cwc-full-bg);
  color: var(--ui-cwc-full);
}
.ui-cwc__empty {
  height: 28px;
  font-size: 12px;
  line-height: 28px;
  color: var(--ui-cwc-muted);
}
.ui-cwc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 44px;
  padding: 0 8px 0 16px;
  border-top: 0.5px solid var(--ui-cwc-line);
}
.ui-cwc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cwc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-cwc__hot {
  display: flex;
  min-width: 0;
}
.ui-cwc__hot > b {
  min-width: 32px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cwc__hot > span {
  flex: none;
  white-space: pre;
}
.ui-cwc__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cwc__swap {
  display: grid;
  min-width: 0;
}
.ui-cwc__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cwc-swap-in 320ms ease both;
}
.ui-cwc__swap-item[data-out] {
  animation: ui-cwc-swap-out 220ms ease both;
}
.ui-cwc__swap-item[data-tone="ok"] {
  color: var(--ui-cwc-ok);
}
.ui-cwc__swap-item[data-tone="ok"] b {
  color: inherit;
}
.ui-cwc__swap-item[data-tone="warn"] {
  color: var(--ui-cwc-warn);
}
.ui-cwc__swap-item[data-tone="full"] {
  color: var(--ui-cwc-full);
}
.ui-cwc__action {
  display: inline-flex;
  flex: 0 1 auto;
  align-items: center;
  min-width: 0;
  max-width: 50%;
  gap: 6px;
  height: 28px;
  padding: 0 8px 0 10px;
  border-radius: 6px;
  background: var(--ui-cwc-card);
  box-shadow: var(--ui-cwc-shadow);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cwc-strong);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-cwc__action:hover {
  background: #fafafa;
}
.ui-cwc__action svg {
  color: var(--ui-cwc-icon);
  transition:
    transform 220ms var(--ui-cwc-ease),
    color 160ms ease;
}
.ui-cwc__action:hover svg {
  color: var(--ui-cwc-ink);
  transform: translateX(2px);
}
.ui-cwc__shimmer {
  position: relative;
  display: inline-block;
}
.ui-cwc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-cwc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-cwc-sweep 1.6s linear infinite;
  pointer-events: none;
}
@keyframes ui-cwc-leave {
  to {
    opacity: 0;
    filter: blur(3px);
    transform: scale(0.92);
  }
}
@keyframes ui-cwc-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cwc-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cwc-wave {
  0%,
  100% {
    transform: none;
  }
  50% {
    transform: scale(0.82);
  }
}
@keyframes ui-cwc-shine {
  0%,
  100% {
    opacity: 0;
  }
  50% {
    opacity: 0.75;
  }
}
@keyframes ui-cwc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-cwc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 310px) {
  .ui-cwc__card {
    padding: 12px 14px 6px;
  }
  .ui-cwc__foot {
    padding: 0 8px 0 14px;
  }
  .ui-cwc__model {
    max-width: 42%;
  }
  .ui-cwc__field {
    grid-template-columns: repeat(var(--ui-cwc-cols-narrow), minmax(0, 1fr));
  }
  .ui-cwc__compact {
    padding: 0 6px;
  }
  .ui-cwc__compact-text {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-cwc__row {
    min-height: 38px;
  }
  .ui-cwc__main {
    height: 38px;
  }
  .ui-cwc__compact {
    height: 30px;
    padding: 0 9px 0 7px;
  }
  .ui-cwc__item {
    height: 34px;
  }
  .ui-cwc__remove {
    width: 30px;
    height: 30px;
  }
  .ui-cwc__foot {
    height: 52px;
  }
  .ui-cwc__action {
    height: 34px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cwc *,
  .ui-cwc *::before,
  .ui-cwc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cwc {
  --ui-cwc-card: #1c1c1e;
  --ui-cwc-strong: #ffffff;
  --ui-cwc-ink: rgba(255, 255, 255, 0.9);
  --ui-cwc-text: rgba(255, 255, 255, 0.62);
  --ui-cwc-muted: rgba(255, 255, 255, 0.46);
  --ui-cwc-faint: rgba(255, 255, 255, 0.3);
  --ui-cwc-icon: rgba(255, 255, 255, 0.5);
  --ui-cwc-line: rgba(255, 255, 255, 0.08);
  --ui-cwc-fill: rgba(255, 255, 255, 0.08);
  --ui-cwc-wash: rgba(255, 255, 255, 0.04);
  --ui-cwc-free: rgba(255, 255, 255, 0.08);
  --ui-cwc-c1: #4d8dff;
  --ui-cwc-c2: rgba(77, 141, 255, 0.7);
  --ui-cwc-c3: rgba(77, 141, 255, 0.46);
  --ui-cwc-c4: #7b7bec;
  --ui-cwc-c5: #3ec27a;
  --ui-cwc-c6: #f0b43a;
  --ui-cwc-accent: #4d8dff;
  --ui-cwc-warn: #f0b43a;
  --ui-cwc-warn-bg: rgba(232, 162, 12, 0.16);
  --ui-cwc-full: #ff8a8e;
  --ui-cwc-full-bg: rgba(229, 72, 77, 0.14);
  --ui-cwc-ok: #3ec27a;
  --ui-cwc-ok-bg: rgba(26, 154, 82, 0.14);
  --ui-cwc-shine: #ffffff;
  --ui-cwc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-cwc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-cwc__action:hover {
  background: #232326;
}
`;export{n as default};
