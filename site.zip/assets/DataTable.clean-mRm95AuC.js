const n=`.ui-dtc {
  --ui-dtc-card: #ffffff;
  --ui-dtc-ink: rgba(0, 0, 0, 0.88);
  --ui-dtc-strong: #000000;
  --ui-dtc-text: rgba(0, 0, 0, 0.65);
  --ui-dtc-muted: rgba(0, 0, 0, 0.65);
  --ui-dtc-faint: rgba(0, 0, 0, 0.65);
  --ui-dtc-icon: rgba(0, 0, 0, 0.65);
  --ui-dtc-line: rgba(0, 0, 0, 0.06);
  --ui-dtc-fill: rgba(0, 0, 0, 0.06);
  --ui-dtc-wash: rgba(0, 0, 0, 0.03);
  --ui-dtc-row-hover: rgba(0, 0, 0, 0.015);
  --ui-dtc-accent: #0060e2;
  --ui-dtc-selected: rgba(0, 96, 226, 0.05);
  --ui-dtc-active-blur: rgba(0, 96, 226, 0.35);
  --ui-dtc-check-ring: rgba(0, 0, 0, 0.22);
  --ui-dtc-check-ring-hover: rgba(0, 0, 0, 0.4);
  --ui-dtc-check-on: rgba(0, 0, 0, 0.88);
  --ui-dtc-check-mark: #fcfcfc;
  --ui-dtc-underline: rgba(0, 0, 0, 0.16);
  --ui-dtc-danger: #bf383d;
  --ui-dtc-danger-wash: rgba(229, 72, 77, 0.08);
  --ui-dtc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dtc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dtc-focus: rgba(0, 96, 226, 0.7);
  --ui-dtc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-dtc-card);
  box-shadow: var(--ui-dtc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-dtc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-dtc *,
.ui-dtc *::before,
.ui-dtc *::after {
  box-sizing: border-box;
}
:where(.ui-dtc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-dtc) svg {
  display: block;
  flex: none;
}
.ui-dtc button:focus-visible,
.ui-dtc a:focus-visible {
  outline: 2px solid var(--ui-dtc-focus);
  outline-offset: 2px;
}
.ui-dtc__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 52px;
  padding: 12px 12px 12px 16px;
}
.ui-dtc__title {
  margin: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-dtc-strong);
}
.ui-dtc__title-icon {
  display: grid;
  flex: none;
}
.ui-dtc__title-icon svg {
  width: 18px;
  height: 18px;
}
.ui-dtc__tools {
  display: flex;
  gap: 2px;
  margin-left: auto;
}
.ui-dtc__tool {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-dtc-icon);
  transition:
    background-color 140ms ease,
    color 140ms ease,
    opacity 140ms ease;
}
.ui-dtc__tool:hover:not(:disabled) {
  background: var(--ui-dtc-wash);
  color: var(--ui-dtc-ink);
}
.ui-dtc__tool:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-dtc__scroll {
  overflow-x: auto;
  scrollbar-width: thin;
  outline: none;
}
.ui-dtc__scroll[data-dragging] {
  cursor: cell;
  user-select: none;
}
.ui-dtc__table {
  width: 100%;
  min-width: 600px;
  border-collapse: collapse;
  table-layout: fixed;
  font-size: 13px;
  line-height: 20px;
}
.ui-dtc__table th,
.ui-dtc__table td {
  position: relative;
  height: 40px;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-dtc-line);
  text-align: left;
  vertical-align: middle;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-dtc__table th {
  height: 36px;
  padding: 0 6px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-dtc-text);
  transition: color 140ms ease;
}
.ui-dtc__table th[data-col-active] {
  color: var(--ui-dtc-ink);
}
.ui-dtc__th {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 28px;
  padding: 0 6px;
  border-radius: 6px;
  text-align: left;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-dtc__th:hover {
  background: var(--ui-dtc-wash);
  color: var(--ui-dtc-ink);
}
.ui-dtc__th:focus-visible {
  outline-offset: -2px;
}
.ui-dtc__th-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-dtc__col-icon {
  display: grid;
  color: var(--ui-dtc-icon);
}
.ui-dtc__sort {
  display: grid;
  margin-left: auto;
  color: var(--ui-dtc-icon);
  opacity: 0;
  transition:
    opacity 140ms ease,
    transform 220ms var(--ui-dtc-ease);
}
.ui-dtc__th:hover .ui-dtc__sort {
  opacity: 1;
}
.ui-dtc__sort[data-dir] {
  opacity: 1;
  color: var(--ui-dtc-accent);
}
.ui-dtc__sort[data-dir="asc"] {
  transform: rotate(180deg);
}
.ui-dtc__table .ui-dtc__select {
  padding: 0;
  text-align: center;
}
.ui-dtc__select .ui-dtc__check {
  margin: 0 auto;
}
.ui-dtc__table tbody tr {
  transition: background-color 120ms ease;
}
.ui-dtc__table tbody tr:hover {
  background: var(--ui-dtc-row-hover);
}
.ui-dtc__table tbody tr[data-selected] {
  background: var(--ui-dtc-selected);
}
.ui-dtc__table td[data-cell] {
  cursor: cell;
}
.ui-dtc__table td[data-in-range] {
  background: var(--ui-dtc-selected);
}
.ui-dtc__table td[data-active]::after {
  content: "";
  position: absolute;
  inset: 1px;
  border-radius: 4px;
  box-shadow: inset 0 0 0 1.5px var(--ui-dtc-accent);
  pointer-events: none;
}
.ui-dtc__scroll:not(:focus-within) td[data-active]::after {
  box-shadow: inset 0 0 0 1px var(--ui-dtc-active-blur);
}
.ui-dtc__table td[data-editing] {
  padding: 0;
  overflow: visible;
  background: var(--ui-dtc-card);
}
.ui-dtc__input {
  width: 100%;
  height: 100%;
  padding: 0 12px;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  color: var(--ui-dtc-ink);
  caret-color: var(--ui-dtc-accent);
}
.ui-dtc__table td[data-type="number"] .ui-dtc__input {
  font-variant-numeric: tabular-nums;
}
.ui-dtc__picker-anchor {
  display: block;
}
.ui-dtc__picker-origin {
  position: fixed;
  left: 0;
  top: 0;
  width: 0;
  height: 0;
  pointer-events: none;
}
.ui-dtc__picker {
  position: fixed;
  z-index: 50;
  display: grid;
  gap: 2px;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-dtc-card);
  box-shadow: var(--ui-dtc-shadow-pop);
  animation: ui-dtc-drop 180ms var(--ui-dtc-ease);
}
.ui-dtc__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 32px;
  padding: 0 6px;
  border-radius: 6px;
  text-align: left;
}
.ui-dtc__option:hover,
.ui-dtc__option:focus-visible {
  background: var(--ui-dtc-fill);
  outline: none;
}
.ui-dtc__option-check {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-dtc-accent);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
}
.ui-dtc__option[aria-selected="true"] .ui-dtc__option-check {
  opacity: 1;
}
.ui-dtc__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-dtc__name-text {
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-dtc-ink);
}
.ui-dtc__name-text[data-empty] {
  font-weight: 400;
  color: var(--ui-dtc-faint);
}
.ui-dtc__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 16px;
}
.ui-dtc__logo svg {
  width: 100%;
  height: 100%;
}
.ui-dtc__logo--empty {
  border-radius: 4px;
  background: var(--ui-dtc-fill);
}
.ui-dtc__check {
  display: grid;
  place-items: center;
  flex: none;
  width: 14px;
  height: 14px;
  border-radius: 4px;
  background: var(--ui-dtc-card);
  box-shadow:
    inset 0 0 0 0.5px var(--ui-dtc-check-ring),
    0 1px 1px 0 rgba(0, 0, 0, 0.04);
  transition:
    background-color 140ms ease,
    box-shadow 140ms ease;
}
.ui-dtc__check:hover {
  box-shadow:
    inset 0 0 0 0.5px var(--ui-dtc-check-ring-hover),
    0 1px 1px 0 rgba(0, 0, 0, 0.04);
}
.ui-dtc__check:focus-visible {
  outline-offset: 2px;
}
.ui-dtc__check svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: var(--ui-dtc-check-mark);
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 140ms ease,
    transform 220ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-dtc__check[aria-checked="true"],
.ui-dtc__check[aria-checked="mixed"] {
  background: var(--ui-dtc-check-on);
  box-shadow: none;
}
.ui-dtc__check[aria-checked="true"] svg,
.ui-dtc__check[aria-checked="mixed"] svg {
  opacity: 1;
  transform: none;
}
@media (pointer: coarse) {
  .ui-dtc__check {
    position: relative;
    width: 18px;
    height: 18px;
    border-radius: 5px;
  }
  .ui-dtc__check svg {
    width: 14px;
    height: 14px;
  }
  .ui-dtc__check::before {
    content: "";
    position: absolute;
    inset: -9px;
  }
}
.ui-dtc__tag {
  display: inline-block;
  max-width: 100%;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  overflow: hidden;
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  text-overflow: ellipsis;
  vertical-align: middle;
}
.ui-dtc__tag[data-tone="blue"] {
  background: rgba(0, 96, 226, 0.08);
  color: #1f63d6;
}
.ui-dtc__tag[data-tone="violet"] {
  background: rgba(124, 77, 255, 0.09);
  color: #6c45e0;
}
.ui-dtc__tag[data-tone="pink"] {
  background: rgba(219, 39, 119, 0.08);
  color: #c22a6e;
}
.ui-dtc__tag[data-tone="green"] {
  background: rgba(26, 154, 82, 0.09);
  color: #157a43;
}
.ui-dtc__tag[data-tone="amber"] {
  background: rgba(232, 162, 12, 0.12);
  color: #935e00;
}
.ui-dtc__tag[data-tone="gray"] {
  background: rgba(0, 0, 0, 0.05);
  color: var(--ui-dtc-text);
}
.ui-dtc__link {
  color: var(--ui-dtc-text);
  text-decoration: underline;
  text-decoration-color: var(--ui-dtc-underline);
  text-decoration-thickness: 1px;
  text-underline-offset: 3px;
  transition:
    text-decoration-color 140ms ease,
    color 140ms ease;
}
.ui-dtc__link:hover {
  color: var(--ui-dtc-ink);
  text-decoration-color: currentColor;
}
.ui-dtc__text {
  color: var(--ui-dtc-text);
  font-variant-numeric: tabular-nums;
}
.ui-dtc__empty {
  margin: 0;
  padding: 24px;
  border-top: 0.5px solid var(--ui-dtc-line);
  text-align: center;
  color: var(--ui-dtc-muted);
}
.ui-dtc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 44px;
  padding: 8px 16px 8px 8px;
  border-top: 0.5px solid var(--ui-dtc-line);
}
.ui-dtc__bulk {
  display: flex;
  align-items: center;
  gap: 2px;
  min-width: 0;
  padding-left: 8px;
}
.ui-dtc__bulk > span {
  margin-right: 8px;
  font-weight: 500;
  white-space: nowrap;
  color: var(--ui-dtc-ink);
}
.ui-dtc__add {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  font-weight: 500;
  white-space: nowrap;
  color: var(--ui-dtc-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-dtc__add svg {
  color: var(--ui-dtc-icon);
  transition: color 140ms ease;
}
.ui-dtc__add:not(:has(svg)) {
  padding: 0 10px;
}
.ui-dtc__add:hover {
  background: var(--ui-dtc-wash);
  color: var(--ui-dtc-ink);
}
.ui-dtc__add:hover svg {
  color: var(--ui-dtc-ink);
}
.ui-dtc__add--danger,
.ui-dtc__add--danger svg,
.ui-dtc__add--danger:hover svg {
  color: var(--ui-dtc-danger);
}
.ui-dtc__add--danger:hover {
  background: var(--ui-dtc-danger-wash);
  color: var(--ui-dtc-danger);
}
.ui-dtc__summary {
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-dtc-muted);
}
@keyframes ui-dtc-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
.ui-dtc__morph {
  overflow: hidden;
}
.ui-dtc__morph[data-smooth] {
  transition: height 380ms var(--ui-dtc-ease);
}
@media (max-width: 480px) {
  .ui-dtc__head {
    padding-left: 14px;
  }
  .ui-dtc__foot {
    padding-right: 14px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-dtc__tool {
    width: 36px;
    height: 36px;
  }
  .ui-dtc__add {
    height: 36px;
  }
  .ui-dtc__table td {
    height: 44px;
  }
  .ui-dtc__option {
    height: 40px;
  }
  .ui-dtc__check {
    position: relative;
  }
  .ui-dtc__check::after {
    content: "";
    position: absolute;
    inset: -12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dtc *,
  .ui-dtc *::before,
  .ui-dtc *::after {
    animation: none !important;
    transition: none !important;
  }
}
.ui-dtc input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-dtc textarea:focus-visible,
.ui-dtc [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-dtc {
  --ui-dtc-card: #1c1c1e;
  --ui-dtc-ink: rgba(255, 255, 255, 0.9);
  --ui-dtc-strong: #ffffff;
  --ui-dtc-text: rgba(255, 255, 255, 0.62);
  --ui-dtc-muted: rgba(255, 255, 255, 0.46);
  --ui-dtc-faint: rgba(255, 255, 255, 0.3);
  --ui-dtc-icon: rgba(255, 255, 255, 0.5);
  --ui-dtc-line: rgba(255, 255, 255, 0.08);
  --ui-dtc-fill: rgba(255, 255, 255, 0.08);
  --ui-dtc-wash: rgba(255, 255, 255, 0.05);
  --ui-dtc-row-hover: rgba(255, 255, 255, 0.025);
  --ui-dtc-accent: #4d8dff;
  --ui-dtc-selected: rgba(77, 141, 255, 0.14);
  --ui-dtc-active-blur: rgba(77, 141, 255, 0.5);
  --ui-dtc-check-ring: rgba(255, 255, 255, 0.28);
  --ui-dtc-check-ring-hover: rgba(255, 255, 255, 0.45);
  --ui-dtc-check-on: rgba(255, 255, 255, 0.9);
  --ui-dtc-check-mark: #1c1c1e;
  --ui-dtc-underline: rgba(255, 255, 255, 0.22);
  --ui-dtc-danger: #ff6369;
  --ui-dtc-danger-wash: rgba(229, 72, 77, 0.14);
  --ui-dtc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-dtc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-dtc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-dtc__check {
  box-shadow: inset 0 0 0 0.5px var(--ui-dtc-check-ring);
}
:where(.dark, [data-theme="dark"]) .ui-dtc__check[aria-checked="true"],
:where(.dark, [data-theme="dark"]) .ui-dtc__check[aria-checked="mixed"] {
  box-shadow: none;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="blue"] {
  background: rgba(77, 141, 255, 0.16);
  color: #8ab4ff;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="violet"] {
  background: rgba(124, 77, 255, 0.18);
  color: #b49cff;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="pink"] {
  background: rgba(236, 72, 153, 0.16);
  color: #f48cc4;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="green"] {
  background: rgba(62, 194, 122, 0.15);
  color: #6fd69b;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="amber"] {
  background: rgba(245, 158, 11, 0.15);
  color: #f5c04a;
}
:where(.dark, [data-theme="dark"]) .ui-dtc__tag[data-tone="gray"] {
  background: rgba(255, 255, 255, 0.08);
  color: var(--ui-dtc-text);
}
`;export{n as default};
