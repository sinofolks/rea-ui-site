const n=`.ui-drpc {
  --ui-drpc-card: #ffffff;
  --ui-drpc-ink: rgba(0, 0, 0, 0.88);
  --ui-drpc-strong: #000000;
  --ui-drpc-text: rgba(0, 0, 0, 0.65);
  --ui-drpc-muted: rgba(0, 0, 0, 0.65);
  --ui-drpc-faint: rgba(0, 0, 0, 0.65);
  --ui-drpc-icon: rgba(0, 0, 0, 0.65);
  --ui-drpc-line: rgba(0, 0, 0, 0.06);
  --ui-drpc-wash: rgba(0, 0, 0, 0.03);
  --ui-drpc-fill: rgba(0, 0, 0, 0.06);
  --ui-drpc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-drpc-chip: rgba(0, 0, 0, 0.88);
  --ui-drpc-chip-hover: rgba(0, 0, 0, 0.78);
  --ui-drpc-on-chip: #fcfcfc;
  --ui-drpc-band: rgba(0, 0, 0, 0.06);
  --ui-drpc-band-preview: rgba(0, 0, 0, 0.04);
  --ui-drpc-compare: rgba(0, 96, 226, 0.08);
  --ui-drpc-compare-edge: rgba(0, 96, 226, 0.4);
  --ui-drpc-accent: #0060e2;
  --ui-drpc-today-on-chip: #6ea2ff;
  --ui-drpc-focus: rgba(0, 96, 226, 0.7);
  --ui-drpc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-drpc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.12), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-drpc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-drpc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-drpc-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-drpc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-drpc *,
.ui-drpc *::before,
.ui-drpc *::after {
  box-sizing: border-box;
}
:where(.ui-drpc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-drpc) svg {
  display: block;
  flex: none;
}
.ui-drpc button:focus-visible {
  outline: 2px solid var(--ui-drpc-focus);
  outline-offset: 2px;
}
.ui-drpc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.65;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-drpc__trigger {
  display: inline-flex;
  align-items: center;
  overflow: hidden;
  max-width: 100%;
  height: 32px;
  padding: 0 8px;
  border-radius: 8px;
  background: var(--ui-drpc-card);
  box-shadow: var(--ui-drpc-shadow);
  text-align: left;
  transition:
    box-shadow 160ms ease,
    width 320ms var(--ui-drpc-ease);
}
.ui-drpc__trigger:hover {
  box-shadow: var(--ui-drpc-shadow-hover);
}
.ui-drpc__trigger-inner {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  max-width: calc(100vw - 56px);
  color: var(--ui-drpc-icon);
}
.ui-drpc__trigger-text {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
  animation: ui-drpc-in 240ms var(--ui-drpc-ease) both;
}
.ui-drpc__trigger-range {
  flex: 0 0 auto;
  max-width: 100%;
  overflow: hidden;
  color: var(--ui-drpc-ink);
  font-weight: 500;
  text-overflow: ellipsis;
}
.ui-drpc__trigger-compare {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-drpc-muted);
  text-overflow: ellipsis;
}
.ui-drpc__chevron {
  transition: transform 260ms var(--ui-drpc-ease);
}
.ui-drpc[data-open] .ui-drpc__chevron {
  transform: rotate(180deg);
}
.ui-drpc__panel {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  container-type: inline-size;
  width: var(--ui-drpc-panel-width, min(652px, calc(100vw - 32px)));
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-drpc-card);
  box-shadow: var(--ui-drpc-shadow-pop);
  transform-origin: top left;
  animation: ui-drpc-open 240ms var(--ui-drpc-ease) both;
}
.ui-drpc__clip {
  overflow: hidden;
  transition: height 320ms var(--ui-drpc-ease);
}
.ui-drpc__body {
  display: grid;
  grid-template-columns: 140px 1fr;
}
.ui-drpc__presets {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: 4px;
  border-right: 0.5px solid var(--ui-drpc-line);
}
.ui-drpc__preset {
  display: flex;
  align-items: center;
  flex: none;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  text-align: left;
  white-space: nowrap;
  font-weight: 500;
  color: var(--ui-drpc-text);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-drpc__preset {
  max-width: 100%;
  min-width: 0;
}
.ui-drpc__preset-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
button.ui-drpc__preset:hover:not([aria-selected="true"]) {
  background: var(--ui-drpc-wash);
  color: var(--ui-drpc-ink);
}
.ui-drpc__preset[aria-selected="true"],
.ui-drpc__preset-custom[data-active] {
  background: var(--ui-drpc-fill);
  color: var(--ui-drpc-ink);
}
.ui-drpc__preset-custom {
  margin-top: auto;
  color: var(--ui-drpc-faint);
  cursor: default;
}
.ui-drpc__cal {
  position: relative;
  padding: 10px 12px 10px;
  overflow: hidden;
}
.ui-drpc__nav {
  position: absolute;
  top: 10px;
  left: 12px;
  right: 12px;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  pointer-events: none;
}
.ui-drpc__nav > * {
  pointer-events: auto;
}
.ui-drpc__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-drpc-icon);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-drpc__icon-btn:hover {
  background: var(--ui-drpc-wash);
  color: var(--ui-drpc-ink);
}
.ui-drpc__months {
  display: grid;
  grid-template-columns: repeat(2, auto);
  justify-content: center;
  gap: 24px;
  animation: ui-drpc-slide 320ms var(--ui-drpc-ease) both;
}
.ui-drpc__months[data-dir="-1"] {
  animation-name: ui-drpc-slide-back;
}
.ui-drpc__month-name {
  height: 28px;
  margin-bottom: 4px;
  font-weight: 500;
  line-height: 28px;
  text-align: center;
  color: var(--ui-drpc-strong);
}
.ui-drpc__grid {
  display: grid;
  gap: 2px;
}
.ui-drpc__weekdays,
.ui-drpc__week {
  display: grid;
  grid-template-columns: repeat(7, 32px);
}
.ui-drpc__weekday {
  height: 24px;
  font-size: 10px;
  font-weight: 500;
  line-height: 24px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  text-align: center;
  color: var(--ui-drpc-muted);
}
.ui-drpc__day {
  position: relative;
  display: grid;
  height: 32px;
}
.ui-drpc__day::before {
  content: "";
  position: absolute;
  inset: 2px 0;
  transition:
    background-color 160ms ease,
    border-radius 220ms var(--ui-drpc-ease),
    left 220ms var(--ui-drpc-ease),
    right 220ms var(--ui-drpc-ease);
}
.ui-drpc__day[data-range]::before {
  background: var(--ui-drpc-band);
}
.ui-drpc__day[data-preview]::before {
  background: var(--ui-drpc-band-preview);
}
.ui-drpc__day[data-compare]::before {
  background: var(--ui-drpc-compare);
}
.ui-drpc__day[data-start]::before,
.ui-drpc__day[data-compare-start]::before,
.ui-drpc__day[data-row-start]::before {
  left: 2px;
  border-top-left-radius: 6px;
  border-bottom-left-radius: 6px;
}
.ui-drpc__day[data-end]::before,
.ui-drpc__day[data-compare-end]::before,
.ui-drpc__day[data-row-end]::before {
  right: 2px;
  border-top-right-radius: 6px;
  border-bottom-right-radius: 6px;
}
.ui-drpc__day button {
  position: relative;
  margin: 2px;
  border-radius: 6px;
  font-size: 13px;
  line-height: 20px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-drpc-ink);
  transition:
    background-color 120ms ease,
    color 120ms ease,
    box-shadow 120ms ease,
    transform 160ms var(--ui-drpc-ease);
}
.ui-drpc__day button:hover:not(:disabled) {
  background: var(--ui-drpc-fill);
}
.ui-drpc__day button:active:not(:disabled) {
  transform: scale(0.94);
}
.ui-drpc__day button:disabled {
  color: var(--ui-drpc-faint);
  cursor: default;
}
.ui-drpc .ui-drpc__day button:focus-visible {
  outline-offset: -2px;
}
.ui-drpc__day button[aria-current="date"] {
  color: var(--ui-drpc-accent);
  font-weight: 500;
}
.ui-drpc__day button[aria-current="date"]::after {
  content: "";
  position: absolute;
  left: 50%;
  bottom: 3px;
  width: 4px;
  height: 4px;
  margin-left: -2px;
  border-radius: 50%;
  background: var(--ui-drpc-accent);
}
.ui-drpc__day[data-start] button,
.ui-drpc__day[data-end] button {
  background: var(--ui-drpc-chip) !important;
  color: var(--ui-drpc-on-chip);
  font-weight: 500;
  box-shadow: none !important;
  animation: ui-drpc-pick 380ms var(--ui-drpc-spring);
}
.ui-drpc__day[data-start] button[aria-current="date"]::after,
.ui-drpc__day[data-end] button[aria-current="date"]::after {
  background: var(--ui-drpc-today-on-chip);
}
.ui-drpc__day[data-preview][data-end] button {
  animation: none;
}
.ui-drpc__day[data-compare-start] button,
.ui-drpc__day[data-compare-end] button {
  box-shadow: inset 0 0 0 0.5px var(--ui-drpc-compare-edge);
}
.ui-drpc__day-empty::before {
  display: none;
}
.ui-drpc__foot {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 12px;
  padding: 10px 10px 10px 14px;
  border-top: 0.5px solid var(--ui-drpc-line);
}
.ui-drpc__summary {
  display: grid;
  gap: 8px;
  min-width: 0;
}
.ui-drpc__summary-range {
  display: flex;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
  white-space: nowrap;
  color: var(--ui-drpc-strong);
  font-weight: 500;
}
.ui-drpc__summary-range > span:first-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-drpc-in 240ms var(--ui-drpc-ease) both;
}
.ui-drpc__count {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  font-weight: 400;
  font-variant-numeric: tabular-nums;
  color: var(--ui-drpc-muted);
  animation: ui-drpc-in 240ms var(--ui-drpc-ease) both;
}
.ui-drpc__compare {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-drpc__compare-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-drpc-muted);
}
.ui-drpc__segments {
  display: inline-flex;
  flex-wrap: wrap;
  gap: 4px;
}
.ui-drpc__segment {
  padding: 4px 10px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-drpc-line);
  font-weight: 500;
  white-space: nowrap;
  color: var(--ui-drpc-text);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-drpc__segment:hover:not([aria-checked="true"]) {
  background: var(--ui-drpc-wash);
  color: var(--ui-drpc-ink);
}
.ui-drpc__segment[aria-checked="true"] {
  background: var(--ui-drpc-fill);
  color: var(--ui-drpc-ink);
}
.ui-drpc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  margin-top: -8px;
  transition:
    grid-template-rows 300ms var(--ui-drpc-ease),
    opacity 200ms ease,
    margin-top 300ms var(--ui-drpc-ease);
}
.ui-drpc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  margin-top: 0;
}
.ui-drpc__fold > div {
  min-height: 0;
  overflow: hidden;
}
.ui-drpc__compare-range {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-drpc-muted);
  animation: ui-drpc-in 220ms var(--ui-drpc-ease) both;
}
.ui-drpc__compare-range::before {
  content: "";
  flex: none;
  width: 14px;
  height: 8px;
  border-radius: 3px;
  background: var(--ui-drpc-compare);
  box-shadow: inset 0 0 0 0.5px var(--ui-drpc-compare-edge);
}
.ui-drpc__buttons {
  display: flex;
  flex: none;
  gap: 8px;
}
.ui-drpc__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-drpc-card);
  box-shadow: var(--ui-drpc-shadow);
  font-weight: 500;
  color: var(--ui-drpc-strong);
  transition:
    background-color 140ms ease,
    box-shadow 140ms ease,
    opacity 140ms ease,
    transform 140ms ease;
}
.ui-drpc__btn:not(.ui-drpc__btn-primary):hover {
  box-shadow: var(--ui-drpc-shadow-hover);
}
.ui-drpc__btn-primary {
  background: var(--ui-drpc-chip);
  box-shadow: none;
  color: var(--ui-drpc-on-chip);
}
.ui-drpc__btn-primary:hover:not(:disabled) {
  background: var(--ui-drpc-chip-hover);
}
.ui-drpc__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-drpc__btn-primary:disabled {
  opacity: 0.35;
  cursor: default;
}
@keyframes ui-drpc-open {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drpc-slide {
  from {
    opacity: 0;
    transform: translateX(14px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drpc-slide-back {
  from {
    opacity: 0;
    transform: translateX(-14px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drpc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drpc-pick {
  0% {
    transform: scale(0.82);
  }
  60% {
    transform: scale(1.06);
  }
  100% {
    transform: scale(1);
  }
}
@container (max-width: 600px) {
  .ui-drpc__body {
    grid-template-columns: 1fr;
  }
  .ui-drpc__presets {
    flex-direction: row;
    gap: 4px;
    padding: 8px;
    overflow-x: auto;
    border-right: 0;
    border-bottom: 0.5px solid var(--ui-drpc-line);
    scrollbar-width: none;
  }
  .ui-drpc__presets::-webkit-scrollbar {
    display: none;
  }
  .ui-drpc__preset {
    height: auto;
    padding: 4px 10px;
    box-shadow: inset 0 0 0 0.5px var(--ui-drpc-line);
  }
  .ui-drpc__preset-custom {
    display: none;
  }
  .ui-drpc__months {
    grid-template-columns: 1fr;
    justify-items: center;
  }
  .ui-drpc__month:not([data-second]) {
    display: none;
  }
  .ui-drpc__foot {
    flex-direction: column;
    align-items: stretch;
    padding: 10px 10px 10px 12px;
  }
  .ui-drpc__buttons {
    justify-content: flex-end;
  }
  .ui-drpc__compare {
    flex-wrap: wrap;
  }
}
@container (max-width: 340px) {
  .ui-drpc__weekdays,
  .ui-drpc__week {
    grid-template-columns: repeat(7, 1fr);
  }
  .ui-drpc__cal {
    padding: 10px 8px;
  }
  .ui-drpc__nav {
    left: 8px;
    right: 8px;
  }
  .ui-drpc__months {
    justify-items: stretch;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-drpc__trigger {
    height: 40px;
  }
  .ui-drpc__day {
    height: 40px;
  }
  .ui-drpc__weekdays,
  .ui-drpc__week {
    grid-template-columns: repeat(7, minmax(0, 40px));
  }
  .ui-drpc__icon-btn {
    width: 36px;
    height: 36px;
  }
  .ui-drpc__month-name {
    height: 36px;
    line-height: 36px;
  }
  .ui-drpc__preset {
    height: 36px;
  }
  .ui-drpc__btn {
    height: 36px;
    padding: 0 14px;
  }
  .ui-drpc__segment {
    padding: 8px 12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-drpc *,
  .ui-drpc *::before,
  .ui-drpc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-drpc {
  --ui-drpc-card: #1c1c1e;
  --ui-drpc-ink: rgba(255, 255, 255, 0.9);
  --ui-drpc-strong: #ffffff;
  --ui-drpc-text: rgba(255, 255, 255, 0.62);
  --ui-drpc-muted: rgba(255, 255, 255, 0.46);
  --ui-drpc-faint: rgba(255, 255, 255, 0.3);
  --ui-drpc-icon: rgba(255, 255, 255, 0.5);
  --ui-drpc-line: rgba(255, 255, 255, 0.08);
  --ui-drpc-wash: rgba(255, 255, 255, 0.04);
  --ui-drpc-fill: rgba(255, 255, 255, 0.08);
  --ui-drpc-fill-strong: rgba(255, 255, 255, 0.13);
  --ui-drpc-chip: rgba(255, 255, 255, 0.9);
  --ui-drpc-chip-hover: rgba(255, 255, 255, 0.8);
  --ui-drpc-on-chip: #111113;
  --ui-drpc-band: rgba(255, 255, 255, 0.08);
  --ui-drpc-band-preview: rgba(255, 255, 255, 0.05);
  --ui-drpc-compare: rgba(77, 141, 255, 0.14);
  --ui-drpc-compare-edge: rgba(77, 141, 255, 0.55);
  --ui-drpc-accent: #4d8dff;
  --ui-drpc-today-on-chip: #0060e2;
  --ui-drpc-focus: rgba(77, 141, 255, 0.8);
  --ui-drpc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-drpc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.18), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-drpc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 12px 28px -10px rgba(0, 0, 0, 0.6),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
