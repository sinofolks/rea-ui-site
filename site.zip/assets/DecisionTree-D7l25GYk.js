const n=`.ui-dct {
  --ui-dct-tray: #f0f0f0;
  --ui-dct-card: #ffffff;
  --ui-dct-strong: #171717;
  --ui-dct-ink: #171717;
  --ui-dct-text: #5f5f5f;
  --ui-dct-muted: #626873;
  --ui-dct-faint: #6b6b6b;
  --ui-dct-line: #ececec;
  --ui-dct-line-strong: #dedede;
  --ui-dct-fill: #f3f3f3;
  --ui-dct-leaf-bg: #fafafa;
  --ui-dct-accent: #2a5ee5;
  --ui-dct-focus: rgba(0, 96, 226, 0.7);
  --ui-dct-link: #d6d6d6;
  --ui-dct-link-pick: #a9bff5;
  --ui-dct-link-hot: #a3a3a3;
  --ui-dct-link-pick-hot: #7d9df0;
  --ui-dct-high-bg: #fde8e5;
  --ui-dct-high-fg: #c2331f;
  --ui-dct-mid-bg: #fff3e0;
  --ui-dct-mid-fg: #a45200;
  --ui-dct-ok-bg: #e6f6ec;
  --ui-dct-ok-edge: #a9dcbc;
  --ui-dct-ok-fg: #187941;
  --ui-dct-flag-bg: #fff2d4;
  --ui-dct-flag-edge: #f0b44c;
  --ui-dct-flag-hot: #ffe2a6;
  --ui-dct-flag-ink: #6e4300;
  --ui-dct-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-dct-raised: 0 0 0 1px #e8e8e8, 0 1px 3px rgba(0, 0, 0, 0.07);
  --ui-dct-lift:
    0 0 0 1px #ececec, 0 4px 12px -4px rgba(0, 0, 0, 0.14),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-dct-lift-hot:
    0 0 0 1px #e8e8e8, 0 8px 20px -6px rgba(0, 0, 0, 0.18),
    0 1px 3px rgba(0, 0, 0, 0.06);
  --ui-dct-pick-lift:
    0 0 0 1px rgba(0, 96, 226, 0.2), 0 3px 8px -4px rgba(0, 96, 226, 0.14),
    0 1px 2px rgba(0, 60, 140, 0.05);
  --ui-dct-pick-lift-hot:
    0 0 0 1px rgba(0, 96, 226, 0.36), 0 8px 22px -6px rgba(0, 96, 226, 0.34),
    0 2px 4px -1px rgba(0, 96, 226, 0.16);
  --ui-dct-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-dct-height: 400px;
  --ui-dct-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-dct-tray);
  letter-spacing: -0.006em;
  outline: none;
  container: ui-dct / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-dct-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-dct *,
.ui-dct *::before,
.ui-dct *::after {
  box-sizing: border-box;
}
:where(.ui-dct) :is(button, textarea) {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-dct) button {
  cursor: pointer;
}
:where(.ui-dct) button:disabled {
  cursor: default;
}
.ui-dct :is(button, mark):focus-visible {
  outline: 2px solid var(--ui-dct-focus);
  outline-offset: 2px;
}
:where(.ui-dct) :is(p, h3) {
  margin: 0;
}
.ui-dct svg {
  display: block;
  flex: none;
}
.ui-dct__kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-dct-fill);
  font-family: inherit;
  font-size: 10.5px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-dct-muted);
  letter-spacing: 0;
}
.ui-dct__kbd[data-off] {
  visibility: hidden;
}
.ui-dct__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-dct__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 8px 14px 12px 12px;
}
.ui-dct__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-dct-accent);
}
.ui-dct__heading {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-dct-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dct__count {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  color: var(--ui-dct-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-dct__pager {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 10px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dct-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-dct__dots {
  display: flex;
  gap: 4px;
}
.ui-dct__dots > span {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--ui-dct-line-strong);
  transition:
    background-color 240ms ease,
    transform 240ms var(--ui-dct-ease);
}
.ui-dct__dots > span[data-on] {
  background: var(--ui-dct-ink);
  transform: scale(1.15);
}
.ui-dct__body {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: var(--ui-dct-height);
  padding: 44px 28px 56px;
  border-radius: 16px;
  background: var(--ui-dct-card);
  box-shadow: var(--ui-dct-shadow);
}
.ui-dct__tree {
  position: relative;
  isolation: isolate;
  display: grid;
  grid-template-columns: minmax(0, 210px) minmax(0, 1fr);
  align-items: center;
  column-gap: 44px;
  width: 100%;
  max-width: 860px;
  transition: opacity 260ms ease;
}
.ui-dct__tree[data-leaving] {
  opacity: 0;
}
.ui-dct__links {
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  overflow: visible;
  pointer-events: none;
}
.ui-dct__link {
  fill: none;
  stroke: var(--ui-dct-link);
  stroke-width: 1px;
  stroke-linecap: round;
  stroke-dasharray: 1 1;
  animation: ui-dct-draw 460ms var(--ui-dct-ease)
    calc(180ms + var(--i, 0) * 80ms) both;
  transition:
    stroke 220ms ease,
    opacity 260ms ease,
    stroke-width 220ms ease;
}
.ui-dct__link[data-kind="leaf"] {
  animation-delay: calc(360ms + var(--i, 0) * 80ms);
}
.ui-dct__link[data-kind="out"] {
  animation: ui-dct-draw 380ms var(--ui-dct-ease) 120ms both;
}
.ui-dct__link[data-pick] {
  stroke: var(--ui-dct-link-pick);
}
.ui-dct__link[data-hot] {
  stroke: var(--ui-dct-link-hot);
  stroke-width: 1.5px;
}
.ui-dct__link[data-pick][data-hot] {
  stroke: var(--ui-dct-link-pick-hot);
}
.ui-dct__link[data-dim] {
  opacity: 0.25;
}
.ui-dct__tree[data-picked] .ui-dct__link[data-dim] {
  opacity: 0;
}
.ui-dct__root {
  grid-template-columns: minmax(0, 1fr);
  display: grid;
  gap: 10px;
  padding: 14px 16px 15px;
  border-radius: 10px;
  background: var(--ui-dct-card);
  box-shadow: var(--ui-dct-shadow);
  animation: ui-dct-node 420ms var(--ui-dct-ease) 40ms backwards;
}
.ui-dct__who {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}
.ui-dct__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--ui-dct-card);
  box-shadow:
    0 0 0 1px var(--ui-dct-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-dct-text);
}
.ui-dct__avatar > :is(svg, img) {
  width: 14px;
  height: 14px;
  object-fit: contain;
}
.ui-dct__avatar {
  overflow: hidden;
}
.ui-dct__meta {
  display: grid;
  flex: 1;
  gap: 1px;
  min-width: 0;
}
.ui-dct__name {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
}
.ui-dct__agent {
  min-width: 0;
  font-size: 13px;
  font-weight: 600;
  line-height: 18px;
  color: var(--ui-dct-ink);
  overflow-wrap: anywhere;
}
.ui-dct__model {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dct-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dct__risk {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 20px;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--k-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--k-fg);
  white-space: nowrap;
}
.ui-dct [data-risk="high"] {
  --k-bg: var(--ui-dct-high-bg);
  --k-fg: var(--ui-dct-high-fg);
}
.ui-dct [data-risk="medium"] {
  --k-bg: var(--ui-dct-mid-bg);
  --k-fg: var(--ui-dct-mid-fg);
}
.ui-dct__q {
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-dct-strong);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-dct__context {
  margin-top: -4px;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-dct-muted);
  text-wrap: pretty;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-dct__branches {
  display: grid;
  gap: 14px;
}
.ui-dct__row {
  display: grid;
  grid-template-columns: minmax(0, 200px) minmax(0, 1fr);
  align-items: center;
  column-gap: 32px;
  transition: opacity 280ms ease;
  animation: ui-dct-node 420ms var(--ui-dct-ease)
    calc(140ms + var(--i, 0) * 80ms) backwards;
}
.ui-dct__row[data-dim] {
  opacity: 0.38;
}
.ui-dct__tree[data-picked] .ui-dct__row[data-dim] {
  opacity: 0;
  pointer-events: none;
}
.ui-dct__opt {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  gap: 2px 8px;
  min-width: 0;
  padding: 9px 12px;
  border-radius: 10px;
  background: var(--ui-dct-card);
  box-shadow: var(--ui-dct-shadow);
  text-align: left;
  transition:
    box-shadow 200ms ease,
    transform 140ms ease;
}
button.ui-dct__opt:hover:not(:disabled),
.ui-dct__opt[data-hot] {
  box-shadow: var(--ui-dct-lift-hot);
}
.ui-dct__opt[data-pick] {
  box-shadow: var(--ui-dct-pick-lift);
}
button.ui-dct__opt[data-pick]:hover:not(:disabled),
.ui-dct__opt[data-pick][data-hot] {
  box-shadow: var(--ui-dct-pick-lift-hot);
}
.ui-dct__opt[data-pressed] {
  transform: scale(0.98);
}
.ui-dct__label {
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-dct-ink);
  overflow-wrap: anywhere;
}
.ui-dct__pick {
  grid-column: 2;
  font-size: 11.5px;
  line-height: 14px;
  color: var(--ui-dct-accent);
}
.ui-dct__leaf {
  display: grid;
  gap: 3px;
  justify-self: start;
  min-width: 0;
  padding: 8px 12px;
  border-radius: 10px;
  background: var(--ui-dct-leaf-bg);
  box-shadow: inset 0 0 0 1px var(--ui-dct-line);
  animation: ui-dct-node 420ms var(--ui-dct-ease)
    calc(300ms + var(--i, 0) * 80ms) backwards;
}
.ui-dct__effect {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-dct-text);
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-dct__flag {
  padding: 1px 2px;
  margin: 0 -1px;
  border-radius: 4px;
  background: var(--ui-dct-flag-bg);
  box-shadow: inset 0 -1.5px 0 var(--ui-dct-flag-edge);
  color: var(--ui-dct-flag-ink);
  cursor: help;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-dct__flag:is(:hover, [data-on]) {
  background: var(--ui-dct-flag-hot);
  box-shadow: inset 0 0 0 1px var(--ui-dct-flag-edge);
}
.ui-dct__opt[data-other] {
  padding: 0;
  background: transparent;
  box-shadow: inset 0 0 0 1px var(--ui-dct-line-strong);
}
.ui-dct__opt[data-other][data-open] {
  background: var(--ui-dct-card);
}
.ui-dct__opt[data-other][data-open]:focus-within {
  box-shadow: inset 0 0 0 1px var(--ui-dct-link-hot);
}
.ui-dct__other {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  padding: 9px 12px;
  border-radius: inherit;
  text-align: left;
}
.ui-dct__other .ui-dct__label {
  font-weight: 400;
  color: var(--ui-dct-muted);
}
.ui-dct__grow {
  position: relative;
  height: 32px;
  overflow: hidden;
  transition: height 250ms var(--ui-dct-ease);
}
.ui-dct__mirror {
  position: absolute;
  top: 0;
  right: 0;
  left: 0;
  padding: 6px 12px;
  font-size: 13px;
  line-height: 20px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  visibility: hidden;
  pointer-events: none;
}
.ui-dct__input {
  display: block;
  width: 100%;
  height: 100%;
  padding: 6px 12px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-dct-ink);
  resize: none;
  overflow-y: hidden;
  outline: none;
  scrollbar-width: thin;
}
.ui-dct .ui-dct__input:focus-visible {
  outline: none;
}
.ui-dct__input::placeholder {
  color: var(--ui-dct-muted);
}
.ui-dct__said {
  padding: 6px 12px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-dct-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-dct__out {
  position: absolute;
  z-index: 1;
  display: grid;
  gap: 6px;
  max-width: 280px;
  padding: 9px 12px;
  border-radius: 10px;
  background: var(--ui-dct-card);
  box-shadow:
    var(--ui-dct-raised),
    0 0 0 1px var(--ui-dct-ok-edge);
  animation: ui-dct-node 360ms var(--ui-dct-ease) 320ms backwards;
}
.ui-dct__out[data-kind="replied"] {
  box-shadow: var(--ui-dct-lift);
}
.ui-dct__out-head {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-dct-ink);
  overflow-wrap: anywhere;
}
.ui-dct__out-head > svg {
  width: 15px;
  height: 15px;
  color: var(--ui-dct-ok-fg);
}
.ui-dct__running {
  font-weight: 400;
  color: var(--ui-dct-muted);
}
.ui-dct__answer {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-dct-text);
  animation: ui-dct-fade-up 280ms var(--ui-dct-ease) backwards;
  overflow-wrap: anywhere;
}
.ui-dct__typing {
  display: inline-flex;
  gap: 4px;
  justify-self: start;
  padding: 6px 0 4px;
}
.ui-dct__typing > span {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--ui-dct-muted);
  animation: ui-dct-dot 1100ms ease-in-out infinite;
}
.ui-dct__typing > span:nth-child(2) {
  animation-delay: 150ms;
}
.ui-dct__typing > span:nth-child(3) {
  animation-delay: 300ms;
}
.ui-dct__hint {
  position: absolute;
  bottom: 16px;
  left: 24px;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  color: var(--ui-dct-muted);
  pointer-events: none;
  animation: ui-dct-fade 300ms ease 600ms backwards;
}
.ui-dct__hint > span {
  margin: 0 3px;
  color: var(--ui-dct-faint);
}
.ui-dct__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 6;
  display: grid;
  gap: 4px;
  width: min(300px, calc(100% - 20px));
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-dct-card);
  box-shadow: var(--ui-dct-pop);
  pointer-events: none;
  transform-origin: var(--x, 50%) top;
  animation: ui-dct-tip 200ms var(--ui-dct-ease) both;
}
.ui-dct__tip[data-side="above"] {
  transform-origin: var(--x, 50%) bottom;
}
.ui-dct__tip-head {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-dct-mid-fg);
}
.ui-dct__tip-head > svg {
  width: 12px;
  height: 12px;
}
.ui-dct__tip p {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-dct-ink);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-dct__tip-source {
  justify-self: start;
  margin-top: 2px;
  padding: 1px 7px;
  border-radius: 5px;
  background: var(--ui-dct-fill);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-dct-text);
  max-width: 100%;
  overflow-wrap: anywhere;
}
.ui-dct__empty {
  display: grid;
  justify-items: center;
  gap: 4px;
  text-align: center;
  animation: ui-dct-fade-up 360ms var(--ui-dct-ease) both;
}
.ui-dct__empty-mark {
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  margin-bottom: 8px;
  border-radius: 14px;
  background: var(--ui-dct-card);
  color: var(--ui-dct-ok-fg);
  box-shadow:
    var(--ui-dct-shadow),
    0 0 0 4px var(--ui-dct-ok-bg);
}
.ui-dct__empty b {
  font-size: 15px;
  font-weight: 600;
  line-height: 22px;
  color: var(--ui-dct-strong);
}
.ui-dct__empty > span:last-child {
  font-size: 13px;
  color: var(--ui-dct-muted);
}
@container ui-dct (max-width: 639px) {
  .ui-dct__body {
    min-height: 0;
    padding: 20px 16px 48px;
  }
  .ui-dct__count {
    display: none;
  }
  .ui-dct__tree {
    grid-template-columns: minmax(0, 1fr);
    row-gap: 18px;
  }
  .ui-dct__branches {
    padding-left: 34px;
  }
  .ui-dct__row {
    grid-template-columns: minmax(0, 1fr);
    row-gap: 8px;
  }
  .ui-dct__leaf {
    margin-left: 26px;
  }
  .ui-dct__hint {
    left: 16px;
    bottom: 14px;
  }
  .ui-dct__hint kbd:last-of-type,
  .ui-dct__hint > span {
    display: none;
  }
}
@container ui-dct (max-width: 380px) {
  .ui-dct__of {
    display: none;
  }
  .ui-dct__branches {
    padding-left: 26px;
  }
  .ui-dct__leaf {
    margin-left: 18px;
  }
}
@keyframes ui-dct-draw {
  from {
    stroke-dashoffset: 1;
  }
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-dct-node {
  from {
    opacity: 0;
    transform: translateX(-8px);
  }
}
@keyframes ui-dct-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-dct-fade-up {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-dct-tip {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.96);
  }
}
@keyframes ui-dct-dot {
  0%,
  60%,
  100% {
    opacity: 0.35;
  }
  30% {
    opacity: 1;
  }
}
@media (pointer: coarse) {
  .ui-dct .ui-dct__kbd,
  .ui-dct__hint {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dct *,
  .ui-dct *::before,
  .ui-dct *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-dct {
  --ui-dct-tray: #19191c;
  --ui-dct-card: #232326;
  --ui-dct-strong: #ededed;
  --ui-dct-ink: #ededed;
  --ui-dct-text: #a8a8ad;
  --ui-dct-muted: #7c7c82;
  --ui-dct-faint: #55555b;
  --ui-dct-line: #2e2e33;
  --ui-dct-line-strong: #3a3a40;
  --ui-dct-fill: #2e2e32;
  --ui-dct-leaf-bg: #26262a;
  --ui-dct-accent: #5b9aff;
  --ui-dct-focus: rgba(77, 141, 255, 0.8);
  --ui-dct-link: #3a3a40;
  --ui-dct-link-pick: #36518f;
  --ui-dct-link-hot: #6a6a72;
  --ui-dct-link-pick-hot: #4d70c2;
  --ui-dct-high-bg: #3b1714;
  --ui-dct-high-fg: #ff977d;
  --ui-dct-mid-bg: #3a2610;
  --ui-dct-mid-fg: #ffb068;
  --ui-dct-ok-bg: #12301f;
  --ui-dct-ok-edge: #23593a;
  --ui-dct-ok-fg: #4fd890;
  --ui-dct-flag-bg: #3d2b0c;
  --ui-dct-flag-edge: #a8741f;
  --ui-dct-flag-hot: #54390c;
  --ui-dct-flag-ink: #ffd28a;
  --ui-dct-shadow: 0 0 0 1px #2e2e33, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-dct-raised: 0 0 0 1px #38383e, 0 1px 3px rgba(0, 0, 0, 0.4);
  --ui-dct-lift:
    0 0 0 1px #2e2e33, 0 6px 16px -4px rgba(0, 0, 0, 0.6),
    0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-dct-lift-hot:
    0 0 0 1px #38383e, 0 10px 24px -6px rgba(0, 0, 0, 0.7),
    0 1px 3px rgba(0, 0, 0, 0.4);
  --ui-dct-pick-lift:
    0 0 0 1px rgba(91, 154, 255, 0.3), 0 4px 12px -4px rgba(40, 100, 220, 0.24),
    0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-dct-pick-lift-hot:
    0 0 0 1px rgba(112, 170, 255, 0.5),
    0 10px 26px -6px rgba(60, 130, 255, 0.5),
    0 2px 5px -1px rgba(60, 130, 255, 0.25);
  --ui-dct-pop: 0 0 0 1px #34343a, 0 16px 36px -12px rgba(0, 0, 0, 0.6);
}
`;export{n as default};
