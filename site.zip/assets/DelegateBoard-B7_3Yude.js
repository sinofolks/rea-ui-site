const n=`.ui-db {
  --ui-db-tray: #f0f0f0;
  --ui-db-card: #ffffff;
  --ui-db-strong: #171717;
  --ui-db-ink: #171717;
  --ui-db-text: #6b6b6b;
  --ui-db-muted: #626873;
  --ui-db-faint: #6b6b6b;
  --ui-db-line: #ececec;
  --ui-db-wash: #f6f6f6;
  --ui-db-lane: #f4f4f5;
  --ui-db-switch-off: #dcdcdf;
  --ui-db-fill: #ececec;
  --ui-db-accent: #2a5ee5;
  --ui-db-brand-bg: rgba(47, 107, 255, 0.08);
  --ui-db-brand-fg: #2a5ee5;
  --ui-db-warn-bg: #fff3e0;
  --ui-db-warn-fg: #b85c00;
  --ui-db-ok-bg: #eaf6ef;
  --ui-db-ok-fg: #147944;
  --ui-db-focus: rgba(0, 96, 226, 0.7);
  --ui-db-target-bg: rgba(47, 107, 255, 0.045);
  --ui-db-target-edge: rgba(47, 107, 255, 0.32);
  --ui-db-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-db-lift:
    0 0 0 1px #e4e4e7, 0 18px 36px -12px rgba(0, 0, 0, 0.28),
    0 2px 6px rgba(0, 0, 0, 0.06);
  --ui-db-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 720px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-db-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  letter-spacing: -0.006em;
  font-size: 13.5px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-db-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-db[data-dragging] {
  cursor: grabbing;
  user-select: none;
  -webkit-user-select: none;
}
.ui-db *,
.ui-db *::before,
.ui-db *::after {
  box-sizing: border-box;
}
:where(.ui-db) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-db button:focus-visible {
  outline: 2px solid var(--ui-db-focus);
  outline-offset: 2px;
}
.ui-db ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-db h4 {
  margin: 0;
}
.ui-db svg {
  display: block;
  flex: none;
}
.ui-db__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-db__card {
  border-radius: 16px;
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
}
.ui-db__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 8px 6px 10px 14px;
}
.ui-db__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-db-accent);
}
.ui-db__title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 600;
  color: var(--ui-db-strong);
  white-space: nowrap;
}
.ui-db__hint {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-db-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-db__auto {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  height: 28px;
  padding: 0 2px 0 6px;
  border-radius: 6px;
}
.ui-db__auto-label {
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-db-strong);
  transition: opacity 200ms ease;
}
.ui-db__auto[aria-checked="false"] .ui-db__auto-label {
  color: var(--ui-db-muted);
}
.ui-db__switch {
  position: relative;
  width: 30px;
  height: 18px;
  border-radius: 999px;
  background: var(--ui-db-switch-off);
  transition: background-color 220ms ease;
}
.ui-db__switch > span {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 14px;
  height: 14px;
  border-radius: 50%;
  background: #fff;
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.18),
    0 0 0 0.5px rgba(0, 0, 0, 0.04);
  transition: transform 240ms var(--ui-db-ease);
}
.ui-db__auto[aria-checked="true"] .ui-db__switch {
  background: var(--ui-db-accent);
}
.ui-db__auto[aria-checked="true"] .ui-db__switch > span {
  transform: translateX(12px);
}
.ui-db__body {
  display: grid;
  grid-template-columns: 236px minmax(0, 1fr);
}
.ui-db__head {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 4px 8px !important;
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  color: var(--ui-db-muted);
}
.ui-db__count {
  display: grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-db-text);
  font-variant-numeric: tabular-nums;
}
.ui-db__pile {
  margin: 12px 0 12px 12px;
  padding: 10px 6px 6px;
  border-radius: 14px;
  background: var(--ui-db-lane);
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease;
}
.ui-db__pile .ui-db__head {
  margin-left: 6px !important;
}
.ui-db__pile[data-over] {
  box-shadow: inset 0 0 0 1px var(--ui-db-line);
}
.ui-db__tasks {
  display: grid;
  gap: 4px;
}
.ui-db__tasks[data-long] {
  max-height: 560px;
  margin: -2px;
  padding: 2px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-db__task,
.ui-db__ghost {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  width: 100%;
  padding: 10px 12px 10px 8px;
  border-radius: 12px;
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
  cursor: grab;
  touch-action: none;
  transition:
    opacity 160ms ease,
    box-shadow 160ms ease;
}
.ui-db__task:hover {
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 2px 6px -2px rgba(0, 0, 0, 0.12);
}
.ui-db__task[data-dragging],
.ui-db__chip[data-dragging] {
  opacity: 0.35;
}
.ui-db__task[data-picked] {
  background: var(--ui-db-target-bg);
  box-shadow:
    inset 0 0 0 0.5px var(--ui-db-target-edge),
    var(--ui-db-shadow);
}
.ui-db__grip {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 20px;
  color: var(--ui-db-faint);
}
.ui-db__task-main {
  display: grid;
  gap: 2px;
  min-width: 0;
}
.ui-db__task-title {
  overflow: hidden;
  text-align: start;
  font-weight: 500;
  color: var(--ui-db-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-db__task-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-db-muted);
  font-variant-numeric: tabular-nums;
}
.ui-db__tools {
  display: flex;
  gap: 4px;
}
.ui-db__tool,
.ui-db__tool > svg,
.ui-db__tool > img {
  display: grid;
  width: 12px;
  height: 12px;
}
.ui-db__tool {
  flex: none;
  overflow: hidden;
}
.ui-db__tool > img {
  object-fit: contain;
}
.ui-db__empty {
  display: grid;
  place-items: center;
  min-height: 52px;
  padding: 8px 10px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-db-muted);
  text-align: center;
}
.ui-db__ghost {
  position: absolute;
  z-index: 1000;
  box-shadow: var(--ui-db-lift);
  cursor: grabbing;
  pointer-events: none;
  transform: rotate(1.5deg) scale(1.02);
}
.ui-db__agents {
  padding: 14px 12px 12px;
}
.ui-db__roster {
  display: grid;
  gap: 4px;
}
.ui-db__agent {
  display: grid;
  grid-template-columns: 30px minmax(0, 1fr) auto;
  grid-template-areas: "avatar who load" "avatar queue queue";
  column-gap: 12px;
  row-gap: 8px;
  padding: 10px;
  border-radius: 12px;
  transition:
    background-color 180ms ease,
    box-shadow 180ms ease;
}
.ui-db[data-dragging] .ui-db__agent {
  box-shadow: inset 0 0 0 0.5px var(--ui-db-line);
}
.ui-db__agent[data-target] {
  background: var(--ui-db-target-bg);
}
.ui-db__avatar {
  grid-area: avatar;
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  background: var(--ui-db-fill);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-db-text);
}
.ui-db__avatar[data-logo] {
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
}
.ui-db__avatar > svg,
.ui-db__avatar > img {
  width: 15px;
  height: 15px;
}
.ui-db__avatar {
  flex: none;
  overflow: hidden;
}
.ui-db__avatar > img {
  object-fit: contain;
}
.ui-db__who {
  grid-area: who;
  display: grid;
  min-width: 0;
}
.ui-db__name-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-db__name {
  overflow: hidden;
  text-align: start;
  font-weight: 500;
  color: var(--ui-db-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-db__key {
  display: none;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-db-muted);
}
.ui-db:focus-within .ui-db__key {
  display: grid;
}
.ui-db__model {
  display: flex;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-db-muted);
  white-space: nowrap;
}
.ui-db__model-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-db__load {
  grid-area: load;
  align-self: start;
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-db__spend {
  margin-left: auto;
  font-variant-numeric: tabular-nums;
  animation: ui-db-in 260ms var(--ui-db-ease) both;
}
.ui-db__rate {
  flex: none;
  margin-left: 6px;
  color: var(--ui-db-faint);
  font-variant-numeric: tabular-nums;
}
.ui-db__price {
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-db-brand-fg);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-db-in 260ms var(--ui-db-ease) both;
}
.ui-db__tag {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 9px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-db-in 260ms var(--ui-db-ease) both;
}
.ui-db__tag[data-kind="free"] {
  background: var(--ui-db-ok-bg);
  color: var(--ui-db-ok-fg);
}
.ui-db__tag[data-kind="busy"] {
  background: var(--ui-db-fill);
  color: var(--ui-db-text);
}
.ui-db__tag[data-kind="preview"] {
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
  color: var(--ui-db-brand-fg);
}
.ui-db__queue {
  grid-area: queue;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  min-width: 0;
}
.ui-db__queue:empty {
  display: none;
}
.ui-db__chip-slot {
  min-width: 0;
  max-width: 100%;
}
.ui-db__chip {
  display: flex;
  align-items: center;
  gap: 5px;
  max-width: 100%;
  height: 26px;
  padding: 0 10px 0 7px;
  border-radius: 999px;
  background: var(--ui-db-card);
  box-shadow: var(--ui-db-shadow);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-db-text);
  cursor: grab;
  touch-action: none;
}
.ui-db__chip[data-running] {
  background: var(--ui-db-brand-bg);
  box-shadow: none;
  color: var(--ui-db-brand-fg);
  font-weight: 500;
}
.ui-db__chip-title {
  text-align: start;
  min-width: 0;
  max-width: 150px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-db__more {
  position: relative;
}
.ui-db__chip--more {
  padding: 0 8px;
  font-weight: 500;
  color: var(--ui-db-text);
  cursor: default;
}
.ui-db__tip {
  position: absolute;
  bottom: calc(100% + 6px);
  left: 50%;
  z-index: 10;
  display: grid;
  width: max-content;
  max-width: min(320px, 90cqw);
  padding: 10px 12px;
  border-radius: 12px;
  background: rgba(24, 24, 27, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.35);
  font-size: 12.5px;
  line-height: 17px;
  color: rgba(255, 255, 255, 0.86);
  text-align: left;
  opacity: 0;
  visibility: hidden;
  transform: translate(-50%, 3px);
  transition:
    opacity 160ms ease,
    transform 160ms ease,
    visibility 0s linear 160ms;
  pointer-events: none;
}
.ui-db__more:hover .ui-db__tip,
.ui-db__more:focus-within .ui-db__tip {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, 0);
  transition:
    opacity 160ms ease,
    transform 160ms ease,
    visibility 0s;
}
.ui-db__tip-list {
  display: grid;
  gap: 2px;
}
.ui-db__tip-list li {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-db__tip-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-db__tip-min {
  flex: none;
}
.ui-db__tip {
  --ui-dbc-strong: #fff;
  --ui-db-ink: #fff;
}
.ui-db__tip-min {
  color: rgba(255, 255, 255, 0.5);
}
.ui-db__spin {
  animation: ui-db-spin 900ms linear infinite;
}
@keyframes ui-db-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-db-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@container (max-width: 560px) {
  .ui-db__body {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-db__queue {
    position: relative;
  }
  .ui-db__more {
    position: static;
  }
  .ui-db__tip {
    left: 0;
    max-width: 100%;
    transform: translate(0, 3px);
  }
  .ui-db__more:hover .ui-db__tip,
  .ui-db__more:focus-within .ui-db__tip {
    transform: none;
  }
  .ui-db__pile {
    margin: 12px 12px 0;
  }
  .ui-db__hint {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-db__auto {
    height: 34px;
  }
  .ui-db__chip {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-db *,
  .ui-db *::before,
  .ui-db *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-db__ghost {
    transform: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-db {
  --ui-db-tray: #111113;
  --ui-db-card: #19191b;
  --ui-db-strong: #ffffff;
  --ui-db-ink: rgba(255, 255, 255, 0.9);
  --ui-db-text: rgba(255, 255, 255, 0.62);
  --ui-db-muted: rgba(255, 255, 255, 0.45);
  --ui-db-faint: rgba(255, 255, 255, 0.28);
  --ui-db-line: rgba(255, 255, 255, 0.08);
  --ui-db-wash: rgba(255, 255, 255, 0.04);
  --ui-db-lane: #141416;
  --ui-db-switch-off: rgba(255, 255, 255, 0.16);
  --ui-db-fill: rgba(255, 255, 255, 0.08);
  --ui-db-accent: #5b9aff;
  --ui-db-brand-bg: #0077ff3a;
  --ui-db-brand-fg: #70b8ff;
  --ui-db-warn-bg: #fb6a0025;
  --ui-db-warn-fg: #ffa057;
  --ui-db-ok-bg: #22ff991e;
  --ui-db-ok-fg: #46fea5d4;
  --ui-db-focus: rgba(77, 141, 255, 0.8);
  --ui-db-target-bg: rgba(91, 154, 255, 0.08);
  --ui-db-target-edge: rgba(112, 184, 255, 0.35);
  --ui-db-shadow: 0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-db-lift: 0 0 0 1px #333338, 0 18px 36px -12px rgba(0, 0, 0, 0.7);
}
:where(.dark, [data-theme="dark"]) .ui-db__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-db__tip {
  --ui-dbc-strong: rgba(0, 0, 0, 0.88);
  --ui-db-ink: rgba(0, 0, 0, 0.88);
}
:where(.dark, [data-theme="dark"]) .ui-db__tip-min {
  color: rgba(0, 0, 0, 0.5);
}
`;export{n as default};
