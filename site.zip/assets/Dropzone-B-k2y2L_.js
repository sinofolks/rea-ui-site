const n=`.ui-dz {
  --ui-dz-tray: #f0f0f0;
  --ui-dz-card: #ffffff;
  --ui-dz-line: #ececec;
  --ui-dz-ink: #171717;
  --ui-dz-text: #404040;
  --ui-dz-muted: #626873;
  --ui-dz-faint: #6b6b6b;
  --ui-dz-area: #fafafa;
  --ui-dz-dash: #d9d9dc;
  --ui-dz-hover: #e6e6e7;
  --ui-dz-track: #efeff1;
  --ui-dz-flash: #e9e9ec;
  --ui-dz-accent: #2a5ee5;
  --ui-dz-accent-soft: rgba(47, 107, 255, 0.06);
  --ui-dz-danger: #bf383d;
  --ui-dz-sheet: #ffffff;
  --ui-dz-focus: rgba(0, 96, 226, 0.7);
  --ui-dz-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  width: 100%;
  max-width: 520px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-dz-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.45;
  color: var(--ui-dz-text);
  -webkit-font-smoothing: antialiased;
}
.ui-dz *,
.ui-dz *::before,
.ui-dz *::after {
  box-sizing: border-box;
}
:where(.ui-dz) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-dz) svg {
  display: block;
  flex: none;
}
.ui-dz button:focus-visible {
  outline: 2px solid var(--ui-dz-focus);
  outline-offset: 2px;
}
.ui-dz__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-dz__card {
  overflow: hidden;
  border-radius: 16px;
  transition: height 360ms var(--ui-dz-ease);
  background: var(--ui-dz-card);
  box-shadow:
    0 0 0 1px var(--ui-dz-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-dz__inner {
  display: flow-root;
  padding: 6px;
}
.ui-dz__input {
  position: absolute;
  width: 1px;
  height: 1px;
  opacity: 0;
  pointer-events: none;
}
.ui-dz__area {
  position: relative;
  display: grid;
  justify-items: center;
  width: 100%;
  padding: 26px 20px 22px;
  border-radius: 12px;
  background: var(--ui-dz-area);
  text-align: center;
  transition:
    background-color 220ms ease,
    box-shadow 220ms ease;
}
.ui-dz__area::before {
  content: "";
  position: absolute;
  inset: 0;
  border: 1.5px dashed var(--ui-dz-dash);
  border-radius: inherit;
  transition: border-color 220ms ease;
  pointer-events: none;
}
.ui-dz__area:hover::before {
  border-color: var(--ui-dz-faint);
}
.ui-dz__area[data-dragging] {
  background: var(--ui-dz-accent-soft);
}
.ui-dz__area[data-dragging]::before {
  border-style: solid;
  border-color: var(--ui-dz-accent);
}
.ui-dz__area:focus-visible {
  outline-offset: 2px;
}
.ui-dz__stack {
  position: relative;
  width: 64px;
  height: 50px;
  margin-bottom: 12px;
}
.ui-dz__sheet {
  position: absolute;
  left: 50%;
  bottom: 0;
  width: 34px;
  height: 42px;
  margin-left: -17px;
  border-radius: 7px;
  background: var(--ui-dz-sheet);
  box-shadow:
    0 0 0 1px var(--ui-dz-line),
    0 2px 6px rgba(0, 0, 0, 0.06);
  transition: transform 420ms var(--ui-dz-ease);
}
.ui-dz__sheet-l,
.ui-dz__sheet-r {
  background: none;
  box-shadow: none;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.06));
}
.ui-dz__sheet .ui-dz__badge {
  width: 100%;
  height: 100%;
}
.ui-dz__sheet-l {
  transform: translate(-9px, 2px) rotate(-10deg);
}
.ui-dz__sheet-r {
  transform: translate(9px, 2px) rotate(10deg);
}
.ui-dz__sheet-m {
  display: grid;
  place-items: center;
  transform: translateY(-2px);
}
.ui-dz__sheet-m .ui-dz__glyph {
  width: 18px;
  height: 18px;
  color: var(--ui-dz-ink);
  transition:
    transform 420ms var(--ui-dz-ease),
    color 220ms ease;
}
.ui-dz__area:hover .ui-dz__sheet-m {
  transform: translateY(-4px);
}
.ui-dz__area[data-dragging] .ui-dz__sheet-l {
  transform: translate(-30px, 0) rotate(-16deg);
}
.ui-dz__area[data-dragging] .ui-dz__sheet-r {
  transform: translate(30px, 0) rotate(16deg);
}
.ui-dz__area[data-dragging] .ui-dz__sheet-m {
  transform: translateY(-9px) scale(1.06);
}
.ui-dz__area[data-dragging] .ui-dz__sheet-m .ui-dz__glyph {
  color: var(--ui-dz-accent);
  animation: ui-dz-bob 900ms ease-in-out infinite;
}
.ui-dz__title {
  font-size: 14.5px;
  font-weight: 500;
  color: var(--ui-dz-ink);
  animation: ui-dz-in 260ms var(--ui-dz-ease) both;
}
.ui-dz__browse {
  color: var(--ui-dz-accent);
}
.ui-dz__hint {
  margin-top: 3px;
  font-size: 12.5px;
  color: var(--ui-dz-muted);
  overflow-wrap: anywhere;
}
.ui-dz__list {
  display: grid;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-dz__list {
  max-height: 360px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-dz__row {
  display: grid;
  grid-template-rows: 1fr;
  animation: ui-dz-grow 420ms var(--ui-dz-ease) both;
  transition:
    grid-template-rows 260ms var(--ui-dz-ease),
    opacity 200ms ease;
}
.ui-dz__row[data-removing] {
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 260ms var(--ui-dz-ease) 200ms,
    opacity 220ms ease 180ms;
}
.ui-dz__row-inner {
  position: relative;
  isolation: isolate;
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 0;
  overflow: hidden;
  padding: 10px 6px 10px 10px;
}
.ui-dz__row-inner::before {
  content: "";
  position: absolute;
  inset: 3px 0;
  border-radius: 10px;
  background: var(--ui-dz-flash);
  opacity: 0;
  pointer-events: none;
  z-index: -1;
}
.ui-dz__row[data-removing] .ui-dz__row-inner::before {
  animation: ui-dz-flash 280ms ease-out both;
}
.ui-dz__row[data-removing] {
  pointer-events: none;
}
.ui-dz__row[data-removing] .ui-dz__icon-btn {
  background: none;
}
.ui-dz__row:first-child .ui-dz__row-inner {
  margin-top: 6px;
}
.ui-dz__row + .ui-dz__row .ui-dz__row-inner {
  border-top: 1px solid var(--ui-dz-line);
}
.ui-dz__badge {
  width: 28px;
  height: 34px;
}
.ui-dz__badge-sheet {
  fill: var(--ui-dz-sheet);
  stroke: var(--ui-dz-dash);
  stroke-width: 1.2;
}
.ui-dz__badge-fold {
  fill: none;
  stroke: var(--ui-dz-dash);
  stroke-width: 1.2;
  stroke-linejoin: round;
}
.ui-dz__badge-text {
  font-family: inherit;
  font-size: 7px;
  font-weight: 700;
  letter-spacing: 0.03em;
}
.ui-dz__info {
  flex: 1;
  min-width: 0;
}
.ui-dz__line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-dz__name {
  overflow: hidden;
  color: var(--ui-dz-ink);
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dz__name:has(> .ui-dz__name-head) {
  display: flex;
  min-width: 0;
}
.ui-dz__name-head {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-dz__name-tail {
  flex: none;
  white-space: pre;
}
.ui-dz__done {
  display: grid;
  place-items: center;
  flex: none;
  color: var(--ui-dz-muted);
  animation: ui-dz-pop 420ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-dz__done .ui-dz__glyph {
  width: 14px;
  height: 14px;
  stroke-width: 2.2;
}
.ui-dz__meta {
  margin-top: 1px;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-dz-muted);
  animation: ui-dz-in 240ms var(--ui-dz-ease) both;
}
.ui-dz__dot {
  margin: 0 5px;
  color: var(--ui-dz-faint);
}
.ui-dz__error {
  color: var(--ui-dz-danger);
  overflow-wrap: anywhere;
}
.ui-dz__row[data-status="error"] .ui-dz__row-inner {
  animation: ui-dz-shake 380ms ease both;
}
.ui-dz__bar {
  position: relative;
  height: 4px;
  margin-top: 7px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-dz-track);
  transition:
    height 320ms var(--ui-dz-ease) 250ms,
    margin-top 320ms var(--ui-dz-ease) 250ms,
    opacity 200ms ease 200ms;
}
.ui-dz__bar[data-hidden] {
  height: 0;
  margin-top: 0;
  opacity: 0;
}
.ui-dz__bar > span {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-dz-ink);
  transform-origin: left;
  transition:
    transform 200ms linear,
    background-color 200ms ease;
}
.ui-dz__row[data-status="error"] .ui-dz__bar > span {
  background: var(--ui-dz-danger);
}
.ui-dz__actions {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-dz__icon-btn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 8px;
  color: var(--ui-dz-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-dz__icon-btn:hover {
  background: var(--ui-dz-track);
  color: var(--ui-dz-ink);
}
.ui-dz__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 40px;
  padding: 0 8px 0 12px;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-dz-muted);
}
.ui-dz__foot > span {
  animation: ui-dz-in 240ms var(--ui-dz-ease) both;
}
.ui-dz__summary-done {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--ui-dz-ink);
}
.ui-dz__ok {
  width: 14px;
  height: 14px;
  stroke: var(--ui-dz-muted);
  stroke-width: 2.2;
}
.ui-dz__warn {
  width: 14px;
  height: 14px;
  stroke: var(--ui-dz-muted);
}
.ui-dz__clear {
  height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 12.5px;
  color: var(--ui-dz-text);
  transition: background-color 160ms ease;
  animation: ui-dz-in 240ms var(--ui-dz-ease) both;
}
.ui-dz__clear:hover {
  background: var(--ui-dz-hover);
}
.ui-dz__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-dz-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-dz-grow {
  from {
    grid-template-rows: 0fr;
    opacity: 0;
  }
  to {
    grid-template-rows: 1fr;
    opacity: 1;
  }
}
@keyframes ui-dz-pop {
  0% {
    transform: scale(0.4);
  }
  60% {
    transform: scale(1.15);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-dz-bob {
  50% {
    transform: translateY(-3px);
  }
}
@keyframes ui-dz-flash {
  0% {
    opacity: 0;
  }
  35% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@keyframes ui-dz-shake {
  20%,
  60% {
    transform: translateX(-3px);
  }
  40%,
  80% {
    transform: translateX(3px);
  }
}
@container (max-width: 420px) {
  .ui-dz__area {
    padding: 22px 16px 18px;
  }
  .ui-dz__title {
    font-size: 14px;
  }
}
.ui-dz__for-touch {
  display: none;
}
@media (hover: none) and (pointer: coarse) {
  .ui-dz__for-mouse {
    display: none;
  }
  .ui-dz__for-touch {
    display: inline;
  }
  .ui-dz__icon-btn {
    width: 40px;
    height: 40px;
    border-radius: 10px;
  }
  .ui-dz__actions {
    margin-right: -4px;
  }
  .ui-dz__clear {
    height: 36px;
    padding: 0 12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dz *,
  .ui-dz *::before,
  .ui-dz *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-dz {
  --ui-dz-tray: #111113;
  --ui-dz-card: #19191b;
  --ui-dz-line: #2a2a2e;
  --ui-dz-ink: #ededed;
  --ui-dz-text: #c8c8cc;
  --ui-dz-muted: #8b8b92;
  --ui-dz-faint: #5c5c63;
  --ui-dz-area: #1d1d20;
  --ui-dz-dash: #38383d;
  --ui-dz-hover: #222225;
  --ui-dz-track: #2a2a2e;
  --ui-dz-flash: #2e2e33;
  --ui-dz-accent: #6d8bff;
  --ui-dz-accent-soft: rgba(109, 139, 255, 0.08);
  --ui-dz-danger: #ff6369;
  --ui-dz-sheet: #26262a;
  --ui-dz-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
