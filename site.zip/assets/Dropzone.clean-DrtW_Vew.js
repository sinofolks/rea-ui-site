const n=`.ui-dzc {
  --ui-dzc-card: #ffffff;
  --ui-dzc-ink: rgba(0, 0, 0, 0.88);
  --ui-dzc-strong: #000000;
  --ui-dzc-text: rgba(0, 0, 0, 0.65);
  --ui-dzc-muted: rgba(0, 0, 0, 0.65);
  --ui-dzc-faint: rgba(0, 0, 0, 0.65);
  --ui-dzc-icon: rgba(0, 0, 0, 0.65);
  --ui-dzc-line: rgba(0, 0, 0, 0.06);
  --ui-dzc-dash: rgba(0, 0, 0, 0.12);
  --ui-dzc-dash-hover: rgba(0, 0, 0, 0.2);
  --ui-dzc-sheet-line: rgba(0, 0, 0, 0.14);
  --ui-dzc-track: rgba(0, 0, 0, 0.06);
  --ui-dzc-wash: rgba(0, 0, 0, 0.03);
  --ui-dzc-wash-big: rgba(0, 0, 0, 0.015);
  --ui-dzc-flash: rgba(0, 0, 0, 0.06);
  --ui-dzc-accent: #0060e2;
  --ui-dzc-accent-soft: rgba(0, 96, 226, 0.035);
  --ui-dzc-ok: #0f783c;
  --ui-dzc-warn: #8f6100;
  --ui-dzc-danger: #bf383d;
  --ui-dzc-shine: rgba(255, 255, 255, 0.82);
  --ui-dzc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dzc-focus: rgba(0, 96, 226, 0.7);
  --ui-dzc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  width: 100%;
  max-width: 520px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-dzc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-dzc *,
.ui-dzc *::before,
.ui-dzc *::after {
  box-sizing: border-box;
}
:where(.ui-dzc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-dzc) svg {
  display: block;
  flex: none;
}
.ui-dzc button:focus-visible {
  outline: 2px solid var(--ui-dzc-focus);
  outline-offset: 2px;
}
.ui-dzc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.65;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-dzc__glyph[data-solid] {
  fill: currentColor;
  stroke: none;
}
.ui-dzc__card {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-dzc-card);
  box-shadow: var(--ui-dzc-shadow);
}
.ui-dzc__body {
  overflow: hidden;
  transition: height 360ms var(--ui-dzc-ease);
}
.ui-dzc__inner {
  display: flow-root;
  padding: 8px 8px 4px;
}
.ui-dzc__input {
  position: absolute;
  width: 1px;
  height: 1px;
  opacity: 0;
  pointer-events: none;
}
.ui-dzc__area {
  position: relative;
  display: grid;
  justify-items: center;
  width: 100%;
  margin-bottom: 4px;
  padding: 24px 16px 20px;
  border: 1px dashed var(--ui-dzc-dash);
  border-radius: 10px;
  background: var(--ui-dzc-card);
  text-align: center;
  transition:
    background-color 160ms ease,
    border-color 160ms ease;
}
.ui-dzc__area:hover {
  border-color: var(--ui-dzc-dash-hover);
  background-color: var(--ui-dzc-wash-big);
}
.ui-dzc__area[data-dragging] {
  border-color: var(--ui-dzc-accent);
  background-color: var(--ui-dzc-accent-soft);
}
.ui-dzc__area:focus-visible {
  outline-offset: 2px;
}
.ui-dzc__stack {
  position: relative;
  width: 64px;
  height: 44px;
  margin-bottom: 12px;
}
.ui-dzc__sheet {
  position: absolute;
  left: 50%;
  bottom: 0;
  width: 30px;
  height: 36px;
  margin-left: -15px;
  border-radius: 6px;
  background: var(--ui-dzc-card);
  box-shadow: var(--ui-dzc-shadow);
  transition: transform 420ms var(--ui-dzc-ease);
}
.ui-dzc__sheet-l,
.ui-dzc__sheet-r {
  background: none;
  box-shadow: none;
  filter: drop-shadow(0 1px 1.5px rgba(0, 0, 0, 0.05));
}
.ui-dzc__sheet .ui-dzc__badge {
  width: 100%;
  height: 100%;
}
.ui-dzc__sheet-l {
  transform: translate(-12px, 2px) rotate(-10deg);
}
.ui-dzc__sheet-r {
  transform: translate(12px, 2px) rotate(10deg);
}
.ui-dzc__sheet-m {
  display: grid;
  place-items: center;
  transform: translateY(-2px);
}
.ui-dzc__sheet-m .ui-dzc__glyph {
  color: var(--ui-dzc-icon);
  transition: color 160ms ease;
}
.ui-dzc__area:hover .ui-dzc__sheet-m {
  transform: translateY(-4px);
}
.ui-dzc__area:hover .ui-dzc__sheet-m .ui-dzc__glyph {
  color: var(--ui-dzc-ink);
}
.ui-dzc__area[data-dragging] .ui-dzc__sheet-l {
  transform: translate(-28px, 0) rotate(-16deg);
}
.ui-dzc__area[data-dragging] .ui-dzc__sheet-r {
  transform: translate(28px, 0) rotate(16deg);
}
.ui-dzc__area[data-dragging] .ui-dzc__sheet-m {
  transform: translateY(-8px) scale(1.05);
}
.ui-dzc__area[data-dragging] .ui-dzc__sheet-m .ui-dzc__glyph {
  color: var(--ui-dzc-accent);
  animation: ui-dzc-bob 900ms ease-in-out infinite;
}
.ui-dzc__badge-sheet {
  fill: var(--ui-dzc-card);
  stroke: var(--ui-dzc-sheet-line);
  stroke-width: 0.9;
}
.ui-dzc__badge-fold {
  fill: none;
  stroke: var(--ui-dzc-sheet-line);
  stroke-width: 0.9;
  stroke-linejoin: round;
}
.ui-dzc__badge-text {
  font-family: inherit;
  font-size: 6.5px;
  font-weight: 500;
  letter-spacing: 0.04em;
}
.ui-dzc__title {
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-dzc-ink);
  animation: ui-dzc-in 260ms var(--ui-dzc-ease) both;
}
.ui-dzc__browse {
  color: var(--ui-dzc-accent);
}
.ui-dzc__hint {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dzc-muted);
  overflow-wrap: anywhere;
}
.ui-dzc__list {
  display: grid;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-dzc__list {
  max-height: 360px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-dzc__row {
  display: grid;
  grid-template-rows: 1fr;
  animation: ui-dzc-grow 420ms var(--ui-dzc-ease) both;
  transition:
    grid-template-rows 260ms var(--ui-dzc-ease),
    opacity 200ms ease;
}
.ui-dzc__row[data-removing] {
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 260ms var(--ui-dzc-ease) 200ms,
    opacity 220ms ease 180ms;
}
.ui-dzc__row-inner {
  position: relative;
  isolation: isolate;
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 0;
  overflow: hidden;
  padding: 8px 0 8px 8px;
}
.ui-dzc__row-inner::before {
  content: "";
  position: absolute;
  inset: 2px 0;
  border-radius: 6px;
  background: var(--ui-dzc-flash);
  opacity: 0;
  pointer-events: none;
  z-index: -1;
}
.ui-dzc__row[data-removing] .ui-dzc__row-inner::before {
  animation: ui-dzc-flash 280ms ease-out both;
}
.ui-dzc__row[data-removing] {
  pointer-events: none;
}
.ui-dzc__row[data-removing] .ui-dzc__icon-btn {
  background: none;
}
.ui-dzc__row + .ui-dzc__row .ui-dzc__row-inner {
  border-top: 0.5px solid var(--ui-dzc-line);
}
.ui-dzc__file {
  align-self: flex-start;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  overflow: visible;
}
.ui-dzc__file-sheet,
.ui-dzc__file-fold {
  fill: none;
  stroke: var(--ui-dzc-icon);
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-dzc__file-sheet {
  fill: var(--ui-dzc-card);
}
.ui-dzc__info {
  flex: 1;
  min-width: 0;
}
.ui-dzc__line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-dzc__name {
  overflow: hidden;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-dzc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dzc__name:has(> .ui-dzc__name-head) {
  display: flex;
  min-width: 0;
}
.ui-dzc__name-head {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-dzc__name-tail {
  flex: none;
  white-space: pre;
}
.ui-dzc__done {
  display: grid;
  place-items: center;
  flex: none;
  color: var(--ui-dzc-ok);
  animation: ui-dzc-pop 420ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-dzc__done .ui-dzc__glyph {
  width: 14px;
  height: 14px;
}
.ui-dzc__meta {
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-dzc-muted);
  animation: ui-dzc-in 240ms var(--ui-dzc-ease) both;
}
.ui-dzc__dot {
  margin: 0 5px;
  color: var(--ui-dzc-faint);
}
.ui-dzc__error {
  color: var(--ui-dzc-danger);
  overflow-wrap: anywhere;
}
.ui-dzc__row[data-status="error"] .ui-dzc__row-inner {
  animation: ui-dzc-shake 380ms ease both;
}
.ui-dzc__bar {
  position: relative;
  height: 2px;
  margin-top: 6px;
  margin-bottom: 2px;
  overflow: hidden;
  border-radius: 1px;
  background: var(--ui-dzc-track);
  transition:
    height 320ms var(--ui-dzc-ease) 250ms,
    margin 320ms var(--ui-dzc-ease) 250ms,
    opacity 200ms ease 200ms;
}
.ui-dzc__bar[data-hidden] {
  height: 0;
  margin-top: 0;
  margin-bottom: 0;
  opacity: 0;
}
.ui-dzc__bar > span {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-dzc-accent);
  transform-origin: left;
  transition:
    transform 200ms linear,
    background-color 200ms ease;
}
.ui-dzc__row[data-status="error"] .ui-dzc__bar > span {
  background: var(--ui-dzc-danger);
}
.ui-dzc__actions {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-dzc__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-dzc-icon);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-dzc__icon-btn:hover {
  background: var(--ui-dzc-wash);
  color: var(--ui-dzc-ink);
}
.ui-dzc__retry:active .ui-dzc__glyph {
  transform: rotate(120deg);
  transition: transform 300ms var(--ui-dzc-ease);
}
.ui-dzc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 44px;
  padding: 0 8px 0 16px;
  border-top: 0.5px solid var(--ui-dzc-line);
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-dzc-muted);
}
.ui-dzc__foot > span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-dzc-in 240ms var(--ui-dzc-ease) both;
}
.ui-dzc__summary {
  color: var(--ui-dzc-text);
}
.ui-dzc__summary .ui-dzc__dot {
  color: var(--ui-dzc-faint);
}
.ui-dzc__summary-done {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  color: var(--ui-dzc-ink);
}
.ui-dzc__ok {
  color: var(--ui-dzc-ok);
}
.ui-dzc__warn {
  color: var(--ui-dzc-warn);
}
.ui-dzc__summary-done .ui-dzc__glyph {
  width: 16px;
  height: 16px;
}
.ui-dzc__clear {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-dzc-card);
  box-shadow: var(--ui-dzc-shadow);
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-dzc-strong);
  transition: background-color 120ms ease;
  animation: ui-dzc-in 240ms var(--ui-dzc-ease) both;
}
.ui-dzc__clear:hover {
  background: #fafafa;
}
.ui-dzc__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-dzc__shimmer {
  position: relative;
}
.ui-dzc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-dzc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-dzc-sweep 1.6s linear infinite;
  pointer-events: none;
}
@keyframes ui-dzc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-dzc-grow {
  from {
    grid-template-rows: 0fr;
    opacity: 0;
  }
  to {
    grid-template-rows: 1fr;
    opacity: 1;
  }
}
@keyframes ui-dzc-pop {
  0% {
    transform: scale(0.4);
  }
  60% {
    transform: scale(1.15);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-dzc-bob {
  50% {
    transform: translateY(-3px);
  }
}
@keyframes ui-dzc-flash {
  0% {
    opacity: 0;
  }
  35% {
    opacity: 1;
  }
  100% {
    opacity: 0;
  }
}
@keyframes ui-dzc-shake {
  20%,
  60% {
    transform: translateX(-3px);
  }
  40%,
  80% {
    transform: translateX(3px);
  }
}
@keyframes ui-dzc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 420px) {
  .ui-dzc__area {
    padding: 20px 12px 16px;
  }
  .ui-dzc__foot {
    padding-left: 12px;
  }
}
.ui-dzc__for-touch {
  display: none;
}
@media (hover: none) and (pointer: coarse) {
  .ui-dzc__for-mouse {
    display: none;
  }
  .ui-dzc__for-touch {
    display: inline;
  }
  .ui-dzc__icon-btn {
    width: 36px;
    height: 36px;
  }
  .ui-dzc__foot {
    height: 52px;
  }
  .ui-dzc__clear {
    height: 34px;
    padding: 0 12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dzc *,
  .ui-dzc *::before,
  .ui-dzc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-dzc {
  --ui-dzc-card: #1c1c1e;
  --ui-dzc-ink: rgba(255, 255, 255, 0.9);
  --ui-dzc-strong: #ffffff;
  --ui-dzc-text: rgba(255, 255, 255, 0.62);
  --ui-dzc-muted: rgba(255, 255, 255, 0.46);
  --ui-dzc-faint: rgba(255, 255, 255, 0.3);
  --ui-dzc-icon: rgba(255, 255, 255, 0.5);
  --ui-dzc-line: rgba(255, 255, 255, 0.08);
  --ui-dzc-dash: rgba(255, 255, 255, 0.16);
  --ui-dzc-dash-hover: rgba(255, 255, 255, 0.26);
  --ui-dzc-sheet-line: rgba(255, 255, 255, 0.2);
  --ui-dzc-track: rgba(255, 255, 255, 0.08);
  --ui-dzc-wash: rgba(255, 255, 255, 0.05);
  --ui-dzc-wash-big: rgba(255, 255, 255, 0.02);
  --ui-dzc-flash: rgba(255, 255, 255, 0.08);
  --ui-dzc-accent: #4d8dff;
  --ui-dzc-accent-soft: rgba(77, 141, 255, 0.07);
  --ui-dzc-ok: #3ec27a;
  --ui-dzc-danger: #ff6369;
  --ui-dzc-shine: rgba(255, 255, 255, 0.82);
  --ui-dzc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-dzc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-dzc__clear:hover {
  background: #232326;
}
`;export{n as default};
