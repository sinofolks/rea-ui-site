const n=`.ui-xc {
  --ui-xc-tray: #f0f0f0;
  --ui-xc-card: #ffffff;
  --ui-xc-line: #ececec;
  --ui-xc-ink: #171717;
  --ui-xc-text: #404040;
  --ui-xc-muted: #626873;
  --ui-xc-well: #f4f4f5;
  --ui-xc-track: #ededf0;
  --ui-xc-c0: #b4b4ba;
  --ui-xc-c1: #2f6bff;
  --ui-xc-c2: #7c5cff;
  --ui-xc-c3: #f0a020;
  --ui-xc-c4: #22a05a;
  --ui-xc-focus: rgba(0, 96, 226, 0.7);
  --ui-xc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-xc-time: 520ms;
  box-sizing: border-box;
  width: 100%;
  max-width: 340px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-xc-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-xc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-xc *,
.ui-xc *::before,
.ui-xc *::after {
  box-sizing: border-box;
}
:where(.ui-xc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-xc button:focus-visible {
  outline: 2px solid var(--ui-xc-focus);
  outline-offset: 2px;
}
.ui-xc svg {
  display: block;
  flex: none;
}
.ui-xc b {
  font-weight: 600;
  color: var(--ui-xc-ink);
}
.ui-xc [data-tone="red"] {
  --ui-xc-tag: #b42318;
  --ui-xc-tag-bg: rgba(229, 72, 77, 0.1);
}
.ui-xc [data-tone="amber"] {
  --ui-xc-tag: #96590a;
  --ui-xc-tag-bg: rgba(240, 160, 32, 0.14);
}
.ui-xc [data-tone="green"] {
  --ui-xc-tag: #18794e;
  --ui-xc-tag-bg: rgba(34, 160, 90, 0.11);
}
.ui-xc [data-tone="blue"] {
  --ui-xc-tag: #1f55d6;
  --ui-xc-tag-bg: rgba(47, 107, 255, 0.09);
}
.ui-xc [data-tone="violet"] {
  --ui-xc-tag: #6941c6;
  --ui-xc-tag-bg: rgba(124, 92, 255, 0.1);
}
.ui-xc [data-tone="gray"] {
  --ui-xc-tag: #626873;
  --ui-xc-tag-bg: rgba(110, 110, 120, 0.09);
}
.ui-xc__card {
  border-radius: 16px;
  background: var(--ui-xc-card);
  box-shadow:
    0 0 0 1px var(--ui-xc-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-xc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows var(--ui-xc-time) var(--ui-xc-ease),
    opacity 260ms ease;
}
.ui-xc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-xc[data-open] > .ui-xc__fold,
.ui-xc[data-open] > .ui-xc__card > .ui-xc__fold {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows var(--ui-xc-time) var(--ui-xc-ease),
    opacity 380ms ease 120ms;
}
.ui-xc__head {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
}
.ui-xc__toggle {
  position: absolute;
  inset: 0;
  border-radius: 16px;
}
.ui-xc__head > :not(.ui-xc__toggle) {
  position: relative;
  pointer-events: none;
}
.ui-xc[data-open] .ui-xc__chart {
  pointer-events: auto;
}
.ui-xc__chart {
  overflow: hidden;
}
.ui-xc__chart[data-many] {
  gap: 1px;
}
.ui-xc__chart {
  display: flex;
  flex: none;
  align-items: flex-end;
  justify-content: center;
  gap: 3px;
  width: 34px;
  height: 34px;
  padding: 6px 5px 5px;
  border-radius: 10px;
  background: var(--ui-xc-well);
  box-shadow: inset 0 0 0 1px var(--ui-xc-line);
}
.ui-xc__col {
  flex: 1;
  max-width: 7px;
  height: calc(var(--ui-xc-size) * 100%);
  border-radius: 2.5px;
  background: var(--ui-xc-color);
  cursor: pointer;
  transition:
    height 620ms var(--ui-xc-ease),
    opacity 220ms ease,
    transform 260ms var(--ui-xc-ease);
  transform-origin: 50% 100%;
}
.ui-xc__col[data-hot] {
  transform: scaleX(1.25);
}
.ui-xc__col[data-dim] {
  opacity: 0.3;
}
.ui-xc__col[data-passed]:not([data-hot]) {
  opacity: 0.35;
}
.ui-xc__titles {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  flex: 1;
  min-width: 0;
}
.ui-xc__name {
  overflow: hidden;
  text-align: start;
  font-size: 13.5px;
  font-weight: 600;
  color: var(--ui-xc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xc__sub {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 20px;
  margin-top: 1px;
  overflow: hidden;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-xc-muted);
  white-space: nowrap;
}
.ui-xc__tag {
  display: inline-flex;
  flex: none;
  max-width: 100%;
  min-width: 0;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px 0 5px;
  border-radius: 5px;
  background: var(--ui-xc-tag-bg);
  font-weight: 500;
  color: var(--ui-xc-tag);
}
.ui-xc__tag-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-xc__note {
  min-width: 0;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
}
.ui-xc__lead {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding: 0 8px;
  border-radius: 6px;
  background: var(--ui-xc-tag-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-xc-tag);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-xc-pop 360ms var(--ui-xc-ease) both;
}
.ui-xc__lead b {
  color: inherit;
}
.ui-xc__body {
  padding: 0 12px 10px;
}
.ui-xc__switch {
  position: relative;
  display: grid;
  grid-auto-columns: 1fr;
  grid-auto-flow: column;
  padding: 2px;
  border-radius: 10px;
  background: var(--ui-xc-well);
  box-shadow: inset 0 0 0 1px var(--ui-xc-line);
}
.ui-xc__switch {
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-xc__switch::-webkit-scrollbar {
  display: none;
}
.ui-xc .ui-xc__metric:focus-visible {
  outline-offset: -2px;
}
.ui-xc__thumb {
  position: absolute;
  top: 2px;
  left: 0;
  height: calc(100% - 4px);
  border-radius: 8px;
  background: var(--ui-xc-card);
  box-shadow:
    0 0 0 1px var(--ui-xc-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  transition:
    transform 420ms var(--ui-xc-ease),
    width 420ms var(--ui-xc-ease);
}
.ui-xc__metric {
  position: relative;
  height: 26px;
  padding: 0 8px;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-xc-muted);
  text-align: center;
  white-space: nowrap;
  transition: color 200ms ease;
}
.ui-xc__metric:hover,
.ui-xc__metric[aria-checked="true"] {
  color: var(--ui-xc-ink);
}
.ui-xc__rows {
  display: grid;
  gap: 2px;
  margin-top: 8px;
}
.ui-xc__row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto auto;
  align-items: center;
  column-gap: 9px;
  row-gap: 6px;
  width: calc(100% + 12px);
  margin: 0 -6px;
  padding: 7px 6px 8px;
  border-radius: 10px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease,
    box-shadow 200ms ease;
}
.ui-xc__row[data-hot] {
  background: var(--ui-xc-well);
}
.ui-xc__row[data-dim] {
  opacity: 0.5;
}
.ui-xc__row[aria-checked="true"] {
  background: var(--ui-xc-well);
  box-shadow: inset 0 0 0 1px var(--ui-xc-line);
}
.ui-xc__badge {
  display: grid;
  place-items: center;
  min-width: 20px;
  max-width: 56px;
  padding: 0 4px;
  height: 20px;
  border-radius: 6px;
  background: color-mix(in srgb, var(--ui-xc-color) 16%, transparent);
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  color: color-mix(in srgb, var(--ui-xc-color) 72%, var(--ui-xc-ink));
  transition:
    background-color 220ms ease,
    color 220ms ease;
}
.ui-xc__badge > * {
  grid-area: 1 / 1;
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-xc-ease);
}
.ui-xc__badge span {
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xc__badge svg {
  opacity: 0;
  transform: scale(0.5);
}
.ui-xc__row[aria-checked="true"] .ui-xc__badge {
  background: var(--ui-xc-color);
  color: #fff;
}
.ui-xc__row[aria-checked="true"] .ui-xc__badge span {
  opacity: 0;
  transform: scale(0.5);
}
.ui-xc__row[aria-checked="true"] .ui-xc__badge svg {
  opacity: 1;
  transform: none;
}
.ui-xc__label {
  overflow: hidden;
  text-align: start;
  color: var(--ui-xc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xc__value {
  font-weight: 500;
  color: var(--ui-xc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-xc__lift {
  min-width: 50px;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-xc-tag-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-xc-tag);
  text-align: center;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 240ms ease,
    color 240ms ease;
}
.ui-xc__track {
  grid-column: 2 / -1;
  height: 4px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-xc-track);
}
.ui-xc__bar {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 2px;
  background: var(--ui-xc-color);
  transform-origin: 0 50%;
  transition: transform 620ms var(--ui-xc-ease);
}
.ui-xc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 38px;
  padding: 4px 4px 0 10px;
}
.ui-xc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-xc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-xc__caption > span {
  display: inline-block;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  vertical-align: top;
  animation: ui-xc-in 280ms var(--ui-xc-ease) both;
}
.ui-xc__action {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 65%;
  height: 26px;
  padding: 0 7px 0 10px;
  border-radius: 10px;
  background: var(--ui-xc-ink);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-xc-card);
  white-space: nowrap;
  animation: ui-xc-pop 360ms var(--ui-xc-ease) both;
  transition: opacity 160ms ease;
}
.ui-xc__action-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-xc__action:hover {
  opacity: 0.88;
}
.ui-xc__action svg {
  transition: transform 220ms var(--ui-xc-ease);
}
.ui-xc__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-xc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-xc-pop {
  from {
    opacity: 0;
    transform: scale(0.94);
  }
}
@container (max-width: 300px) {
  .ui-xc__head {
    gap: 8px;
    padding: 10px;
  }
  .ui-xc__chart {
    width: 30px;
    height: 30px;
    padding: 5px 4px 4px;
    gap: 2.5px;
  }
  .ui-xc__note {
    display: none;
  }
  .ui-xc__lead {
    gap: 3px;
    padding: 0 6px;
  }
  .ui-xc__lead svg {
    display: none;
  }
  .ui-xc__body {
    padding: 0 10px 10px;
  }
  .ui-xc__metric {
    padding: 0 4px;
  }
  .ui-xc__row {
    column-gap: 7px;
  }
  .ui-xc__lift {
    min-width: 44px;
    padding: 0 4px;
  }
}
@media (pointer: coarse) {
  .ui-xc__metric {
    height: 32px;
  }
  .ui-xc__row {
    padding: 10px 6px 11px;
  }
  .ui-xc__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-xc *,
  .ui-xc *::before,
  .ui-xc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-xc {
  --ui-xc-tray: #111113;
  --ui-xc-card: #19191b;
  --ui-xc-line: #2a2a2e;
  --ui-xc-ink: #ededed;
  --ui-xc-text: #c8c8cc;
  --ui-xc-muted: #8b8b92;
  --ui-xc-well: #222225;
  --ui-xc-track: #2c2c31;
  --ui-xc-c0: #6e6e76;
  --ui-xc-c1: #5b8cff;
  --ui-xc-c2: #9b83ff;
  --ui-xc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="red"] {
  --ui-xc-tag: #ff9b93;
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="amber"] {
  --ui-xc-tag: #f5c264;
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="green"] {
  --ui-xc-tag: #6ee7a8;
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="blue"] {
  --ui-xc-tag: #9bb8ff;
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="violet"] {
  --ui-xc-tag: #c3b1ff;
}
:where(.dark, [data-theme="dark"]) .ui-xc [data-tone="gray"] {
  --ui-xc-tag: #b4b4bb;
}
:where(.dark, [data-theme="dark"])
  .ui-xc__row[aria-checked="true"]
  .ui-xc__badge {
  color: #111113;
}
`;export{n as default};
