const n=`.ui-xcc {
  --ui-xcc-card: #ffffff;
  --ui-xcc-ink: rgba(0, 0, 0, 0.88);
  --ui-xcc-strong: #000000;
  --ui-xcc-text: rgba(0, 0, 0, 0.65);
  --ui-xcc-muted: rgba(0, 0, 0, 0.65);
  --ui-xcc-faint: rgba(0, 0, 0, 0.27);
  --ui-xcc-icon: rgba(0, 0, 0, 0.447);
  --ui-xcc-line: rgba(0, 0, 0, 0.06);
  --ui-xcc-fill: rgba(0, 0, 0, 0.06);
  --ui-xcc-wash: rgba(0, 0, 0, 0.03);
  --ui-xcc-track: rgba(0, 0, 0, 0.06);
  --ui-xcc-pick: rgba(0, 96, 226, 0.05);
  --ui-xcc-pick-line: rgba(0, 96, 226, 0.35);
  --ui-xcc-primary: rgba(0, 0, 0, 0.88);
  --ui-xcc-on-primary: #fcfcfc;
  --ui-xcc-c0: rgba(0, 0, 0, 0.22);
  --ui-xcc-c1: rgba(0, 96, 226, 0.765);
  --ui-xcc-c2: #5b5bd6;
  --ui-xcc-c3: #e8a20c;
  --ui-xcc-c4: #1a9a52;
  --ui-xcc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-xcc-focus: rgba(0, 96, 226, 0.7);
  --ui-xcc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-xcc-time: 520ms;
  box-sizing: border-box;
  width: 100%;
  max-width: 340px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-xcc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-xcc *,
.ui-xcc *::before,
.ui-xcc *::after {
  box-sizing: border-box;
}
:where(.ui-xcc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-xcc button:focus-visible {
  outline: 2px solid var(--ui-xcc-focus);
  outline-offset: 2px;
}
:where(.ui-xcc) svg {
  display: block;
  flex: none;
}
.ui-xcc b {
  font-weight: 500;
  color: var(--ui-xcc-ink);
}
.ui-xcc [data-tone="red"] {
  --ui-xcc-tag: #c13338;
  --ui-xcc-tag-bg: rgba(229, 72, 77, 0.08);
}
.ui-xcc [data-tone="amber"] {
  --ui-xcc-tag: #915f00;
  --ui-xcc-tag-bg: rgba(232, 162, 12, 0.1);
}
.ui-xcc [data-tone="green"] {
  --ui-xcc-tag: #0f783c;
  --ui-xcc-tag-bg: rgba(26, 154, 82, 0.08);
}
.ui-xcc [data-tone="blue"] {
  --ui-xcc-tag: #0060e2;
  --ui-xcc-tag-bg: rgba(0, 96, 226, 0.06);
}
.ui-xcc [data-tone="violet"] {
  --ui-xcc-tag: #5b5bd6;
  --ui-xcc-tag-bg: rgba(91, 91, 214, 0.08);
}
.ui-xcc [data-tone="gray"] {
  --ui-xcc-tag: rgba(0, 0, 0, 0.65);
  --ui-xcc-tag-bg: rgba(0, 0, 0, 0.05);
}
.ui-xcc__card {
  border-radius: 10px;
  background: var(--ui-xcc-card);
  box-shadow: var(--ui-xcc-shadow);
}
.ui-xcc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows var(--ui-xcc-time) var(--ui-xcc-ease),
    opacity 260ms ease;
}
.ui-xcc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-xcc[data-open] > .ui-xcc__card > .ui-xcc__fold {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows var(--ui-xcc-time) var(--ui-xcc-ease),
    opacity 380ms ease 120ms;
}
.ui-xcc__head {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
}
.ui-xcc__toggle {
  position: absolute;
  inset: 0;
  border-radius: 10px;
}
.ui-xcc__head > :not(.ui-xcc__toggle) {
  position: relative;
  pointer-events: none;
}
.ui-xcc[data-open] .ui-xcc__chart {
  pointer-events: auto;
}
.ui-xcc__chart {
  overflow: hidden;
}
.ui-xcc__chart[data-many] {
  gap: 1px;
}
.ui-xcc__chart {
  display: flex;
  flex: none;
  align-items: flex-end;
  justify-content: center;
  gap: 3px;
  width: 36px;
  height: 36px;
  padding: 7px 6px 6px;
  border-radius: 8px;
  background: var(--ui-xcc-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-xcc-line);
}
.ui-xcc__col {
  flex: 1;
  max-width: 6px;
  height: calc(var(--ui-xcc-size) * 100%);
  border-radius: 1.5px;
  background: var(--ui-xcc-color);
  cursor: pointer;
  transition:
    height 620ms var(--ui-xcc-ease),
    opacity 220ms ease,
    transform 260ms var(--ui-xcc-ease);
  transform-origin: 50% 100%;
}
.ui-xcc__col[data-hot] {
  transform: scaleX(1.25);
}
.ui-xcc__col[data-dim] {
  opacity: 0.3;
}
.ui-xcc__col[data-passed]:not([data-hot]) {
  opacity: 0.35;
}
.ui-xcc__titles {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  flex: 1;
  min-width: 0;
}
.ui-xcc__name {
  overflow: hidden;
  text-align: start;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-xcc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xcc__sub {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 20px;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-xcc-muted);
  white-space: nowrap;
}
.ui-xcc__tag {
  display: inline-flex;
  flex: none;
  max-width: 100%;
  min-width: 0;
  align-items: center;
  gap: 5px;
  height: 20px;
  padding: 0 6px 0 5px;
  border-radius: 5px;
  background: var(--ui-xcc-tag-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-xcc-tag);
}
.ui-xcc__tag-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-xcc__note {
  min-width: 0;
  overflow: hidden;
  text-align: start;
  text-overflow: ellipsis;
}
.ui-xcc__lead {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-xcc-tag-bg);
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-xcc-tag);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-xcc-pop 360ms var(--ui-xcc-ease) both;
}
.ui-xcc__lead b {
  color: inherit;
}
.ui-xcc__body {
  padding: 0 12px 10px;
}
.ui-xcc__switch {
  position: relative;
  display: flex;
  gap: 4px;
}
.ui-xcc__switch {
  margin: -3px;
  padding: 3px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-xcc__switch::-webkit-scrollbar {
  display: none;
}
.ui-xcc__thumb {
  position: absolute;
  top: 3px;
  left: 0;
  height: calc(100% - 6px);
  border-radius: 6px;
  background: var(--ui-xcc-fill);
  transition:
    transform 90ms ease-out,
    width 90ms ease-out;
}
.ui-xcc__metric {
  position: relative;
  height: 28px;
  padding: 4px 10px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-xcc-line);
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-xcc-text);
  text-align: center;
  white-space: nowrap;
  transition:
    color 140ms ease,
    background-color 140ms ease;
}
.ui-xcc__metric:hover {
  background: var(--ui-xcc-wash);
  color: var(--ui-xcc-ink);
}
.ui-xcc__metric[aria-checked="true"] {
  background: none;
  color: var(--ui-xcc-ink);
}
.ui-xcc__rows {
  display: grid;
  gap: 2px;
  margin-top: 8px;
}
.ui-xcc__row {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto auto;
  align-items: center;
  column-gap: 8px;
  row-gap: 6px;
  width: calc(100% + 12px);
  margin: 0 -6px;
  padding: 7px 6px 8px;
  border-radius: 6px;
  transition:
    background-color 120ms ease-out,
    opacity 220ms ease,
    box-shadow 160ms ease;
}
.ui-xcc__row[data-hot] {
  background: var(--ui-xcc-wash);
}
.ui-xcc__row[data-dim] {
  opacity: 0.55;
}
.ui-xcc__row[aria-checked="true"] {
  background: var(--ui-xcc-pick);
  box-shadow: 0 0 0 0.5px var(--ui-xcc-pick-line);
}
.ui-xcc__badge {
  display: grid;
  place-items: center;
  min-width: 20px;
  max-width: 56px;
  padding: 0 4px;
  height: 20px;
  border-radius: 5px;
  background: color-mix(in srgb, var(--ui-xcc-color) 14%, transparent);
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
  color: color-mix(in srgb, var(--ui-xcc-color) 80%, var(--ui-xcc-strong));
  transition:
    background-color 220ms ease,
    color 220ms ease;
}
.ui-xcc__badge > * {
  grid-area: 1 / 1;
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-xcc-ease);
}
.ui-xcc__badge span {
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xcc__badge svg {
  opacity: 0;
  transform: scale(0.5);
}
.ui-xcc__row[aria-checked="true"] .ui-xcc__badge {
  background: var(--ui-xcc-color);
  color: #fff;
}
.ui-xcc__row[aria-checked="true"] .ui-xcc__badge span {
  opacity: 0;
  transform: scale(0.5);
}
.ui-xcc__row[aria-checked="true"] .ui-xcc__badge svg {
  opacity: 1;
  transform: none;
}
.ui-xcc__label {
  overflow: hidden;
  text-align: start;
  color: var(--ui-xcc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-xcc__value {
  font-weight: 500;
  color: var(--ui-xcc-strong);
  font-variant-numeric: tabular-nums;
}
.ui-xcc__lift {
  min-width: 50px;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-xcc-tag-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-xcc-tag);
  text-align: center;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 240ms ease,
    color 240ms ease;
}
.ui-xcc__track {
  grid-column: 2 / -1;
  height: 3px;
  overflow: hidden;
  border-radius: 1.5px;
  background: var(--ui-xcc-track);
}
.ui-xcc__bar {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: 1.5px;
  background: var(--ui-xcc-color);
  transform-origin: 0 50%;
  transition: transform 620ms var(--ui-xcc-ease);
}
.ui-xcc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 44px;
  padding: 0 8px 0 12px;
  border-top: 0.5px solid var(--ui-xcc-line);
}
.ui-xcc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-xcc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-xcc__caption > span {
  display: inline-block;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  vertical-align: top;
  animation: ui-xcc-in 280ms var(--ui-xcc-ease) both;
}
.ui-xcc__action {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 65%;
  height: 28px;
  padding: 0 7px 0 10px;
  border-radius: 6px;
  background: var(--ui-xcc-primary);
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-xcc-on-primary);
  white-space: nowrap;
  animation: ui-xcc-pop 360ms var(--ui-xcc-ease) both;
  transition: opacity 160ms ease;
}
.ui-xcc__action-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-xcc__action:hover {
  opacity: 0.9;
}
.ui-xcc__action svg {
  transition: transform 220ms var(--ui-xcc-ease);
}
.ui-xcc__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-xcc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-xcc-pop {
  from {
    opacity: 0;
    transform: scale(0.94);
  }
}
@container (max-width: 300px) {
  .ui-xcc__head {
    gap: 8px;
    padding: 10px;
  }
  .ui-xcc__chart {
    width: 32px;
    height: 32px;
    padding: 6px 5px 5px;
    gap: 2.5px;
  }
  .ui-xcc__note {
    display: none;
  }
  .ui-xcc__lead {
    gap: 3px;
    padding: 0 6px;
  }
  .ui-xcc__lead svg {
    display: none;
  }
  .ui-xcc__body {
    padding: 0 10px 10px;
  }
  .ui-xcc__switch {
    gap: 2px;
  }
  .ui-xcc__metric {
    flex: 1;
    padding: 4px 6px;
  }
  .ui-xcc__row {
    column-gap: 7px;
  }
  .ui-xcc__lift {
    min-width: 44px;
    padding: 0 4px;
  }
  .ui-xcc__foot {
    padding: 0 8px 0 10px;
  }
}
@media (pointer: coarse) {
  .ui-xcc__metric {
    height: 34px;
    padding: 7px 12px;
  }
  .ui-xcc__row {
    padding: 10px 6px 11px;
  }
  .ui-xcc__foot {
    height: 52px;
  }
  .ui-xcc__action {
    height: 34px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-xcc *,
  .ui-xcc *::before,
  .ui-xcc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-xcc {
  --ui-xcc-card: #1c1c1e;
  --ui-xcc-ink: rgba(255, 255, 255, 0.9);
  --ui-xcc-strong: #ffffff;
  --ui-xcc-text: rgba(255, 255, 255, 0.62);
  --ui-xcc-muted: rgba(255, 255, 255, 0.46);
  --ui-xcc-faint: rgba(255, 255, 255, 0.3);
  --ui-xcc-icon: rgba(255, 255, 255, 0.5);
  --ui-xcc-line: rgba(255, 255, 255, 0.08);
  --ui-xcc-fill: rgba(255, 255, 255, 0.08);
  --ui-xcc-wash: rgba(255, 255, 255, 0.04);
  --ui-xcc-track: rgba(255, 255, 255, 0.08);
  --ui-xcc-pick: rgba(77, 141, 255, 0.14);
  --ui-xcc-pick-line: rgba(77, 141, 255, 0.4);
  --ui-xcc-primary: rgba(255, 255, 255, 0.9);
  --ui-xcc-on-primary: #1c1c1e;
  --ui-xcc-c0: rgba(255, 255, 255, 0.3);
  --ui-xcc-c1: #4d8dff;
  --ui-xcc-c2: #8585f0;
  --ui-xcc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-xcc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="red"] {
  --ui-xcc-tag: #ff8a8d;
  --ui-xcc-tag-bg: rgba(229, 72, 77, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="amber"] {
  --ui-xcc-tag: #f5c264;
  --ui-xcc-tag-bg: rgba(232, 162, 12, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="green"] {
  --ui-xcc-tag: #5fd394;
  --ui-xcc-tag-bg: rgba(26, 154, 82, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="blue"] {
  --ui-xcc-tag: #8fb6ff;
  --ui-xcc-tag-bg: rgba(77, 141, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="violet"] {
  --ui-xcc-tag: #ababf5;
  --ui-xcc-tag-bg: rgba(91, 91, 214, 0.18);
}
:where(.dark, [data-theme="dark"]) .ui-xcc [data-tone="gray"] {
  --ui-xcc-tag: rgba(255, 255, 255, 0.62);
  --ui-xcc-tag-bg: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-xcc__badge {
  color: color-mix(in srgb, var(--ui-xcc-color) 75%, #fff);
}
:where(.dark, [data-theme="dark"])
  .ui-xcc__row[aria-checked="true"]
  .ui-xcc__badge {
  color: #1c1c1e;
}
`;export{n as default};
