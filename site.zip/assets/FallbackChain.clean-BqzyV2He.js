const n=`.ui-fbkc {
  --ui-fbkc-card: #ffffff;
  --ui-fbkc-strong: #000000;
  --ui-fbkc-ink: rgba(0, 0, 0, 0.88);
  --ui-fbkc-text: rgba(0, 0, 0, 0.65);
  --ui-fbkc-muted: rgba(0, 0, 0, 0.65);
  --ui-fbkc-faint: rgba(0, 0, 0, 0.65);
  --ui-fbkc-line: rgba(0, 0, 0, 0.06);
  --ui-fbkc-link: rgba(0, 0, 0, 0.14);
  --ui-fbkc-fill: rgba(0, 0, 0, 0.05);
  --ui-fbkc-idle: #f4f4f5;
  --ui-fbkc-wait: #f9f9fa;
  --ui-fbkc-area: #fbfbfb;
  --ui-fbkc-grid: rgba(0, 0, 0, 0.05);
  --ui-fbkc-accent: #0060e2;
  --ui-fbkc-accent-soft: rgba(0, 96, 226, 0.3);
  --ui-fbkc-accent-bg: rgba(0, 96, 226, 0.07);
  --ui-fbkc-ok: #0a783e;
  --ui-fbkc-ok-soft: rgba(16, 138, 74, 0.34);
  --ui-fbkc-ok-bg: rgba(16, 138, 74, 0.07);
  --ui-fbkc-fail: #cd2200;
  --ui-fbkc-fail-soft: rgba(215, 36, 0, 0.38);
  --ui-fbkc-fail-bg: rgba(215, 36, 0, 0.07);
  --ui-fbkc-focus: rgba(0, 96, 226, 0.7);
  --ui-fbkc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-fbkc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-fbkc-row: 60px;
  --ui-fbkc-gap: 10px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 740px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-fbkc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-fbkc *,
.ui-fbkc *::before,
.ui-fbkc *::after {
  box-sizing: border-box;
}
:where(.ui-fbkc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-fbkc button:focus-visible {
  outline: 2px solid var(--ui-fbkc-focus);
  outline-offset: 2px;
}
:where(.ui-fbkc) ol {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-fbkc) svg {
  display: block;
  flex: none;
}
.ui-fbkc b {
  font-weight: 500;
}
.ui-fbkc__bar {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  min-height: 28px;
  margin-bottom: 10px;
  padding: 0 2px;
}
.ui-fbkc__title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-fbkc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fbkc__summary {
  display: flex;
  flex: none;
  align-items: center;
  gap: 12px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fbkc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-fbkc__state {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  animation: ui-fbkc-swap 300ms var(--ui-fbkc-ease);
}
.ui-fbkc__state::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-fbkc-faint);
  transition: background-color 300ms ease;
}
.ui-fbkc__summary[data-state="trying"] .ui-fbkc__state::before {
  background: var(--ui-fbkc-accent);
  animation: ui-fbkc-breathe 1200ms ease-in-out infinite alternate;
}
.ui-fbkc__summary[data-state="answered"] .ui-fbkc__state {
  color: var(--ui-fbkc-ok);
}
.ui-fbkc__summary[data-state="answered"] .ui-fbkc__state::before {
  background: var(--ui-fbkc-ok);
}
.ui-fbkc__summary[data-state="failed"] .ui-fbkc__state {
  color: var(--ui-fbkc-fail);
}
.ui-fbkc__summary[data-state="failed"] .ui-fbkc__state::before {
  background: var(--ui-fbkc-fail);
}
.ui-fbkc__state b {
  color: var(--ui-fbkc-ink);
}
.ui-fbkc__total {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding-left: 12px;
  box-shadow: inset 0.5px 0 0 var(--ui-fbkc-link);
  color: var(--ui-fbkc-ink);
}
.ui-fbkc__total svg {
  color: var(--ui-fbkc-faint);
}
.ui-fbkc__btn {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
  font-weight: 500;
  color: var(--ui-fbkc-strong);
  transition: background-color 160ms ease;
}
.ui-fbkc__btn:hover {
  background: var(--ui-fbkc-fill);
}
.ui-fbkc__card {
  border-radius: 12px;
  background: var(--ui-fbkc-area);
  box-shadow: var(--ui-fbkc-shadow);
}
.ui-fbkc__flow {
  display: grid;
  grid-template-columns: 140px 48px minmax(0, 1fr) 48px 140px;
  align-items: center;
  padding: 22px 16px;
  border-radius: inherit;
  background-image: radial-gradient(
    circle,
    var(--ui-fbkc-grid) 0.9px,
    transparent 1.1px
  );
  background-size: 12px 12px;
  background-position: 6px 6px;
}
.ui-fbkc__links {
  overflow: visible;
}
.ui-fbkc__links--tree {
  display: none;
}
.ui-fbkc__node {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 52px;
  padding: 0 8px;
  border-radius: 10px;
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
  transition:
    background-color 400ms ease,
    box-shadow 400ms ease;
}
.ui-fbkc__node-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 7px;
  background: var(--ui-fbkc-fill);
  color: var(--ui-fbkc-text);
  transition:
    background-color 400ms ease,
    color 400ms ease;
}
.ui-fbkc__node--from .ui-fbkc__node-icon {
  background: var(--ui-fbkc-accent-bg);
  color: var(--ui-fbkc-accent);
}
.ui-fbkc__node-text {
  display: grid;
  min-width: 0;
}
.ui-fbkc__node-title {
  overflow: hidden;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 17px;
  color: var(--ui-fbkc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: color 400ms ease;
}
.ui-fbkc__node-sub {
  overflow: hidden;
  font-size: 11px;
  line-height: 15px;
  color: var(--ui-fbkc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
  animation: ui-fbkc-swap 300ms var(--ui-fbkc-ease);
}
.ui-fbkc__node--from .ui-fbkc__node-sub {
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 10px;
  letter-spacing: -0.1px;
  animation: none;
}
.ui-fbkc__node--to:is([data-state="waiting"], [data-state="trying"]) {
  background: var(--ui-fbkc-wait);
  box-shadow: var(--ui-fbkc-shadow);
}
.ui-fbkc__node--to:is([data-state="waiting"], [data-state="trying"])
  .ui-fbkc__node-icon {
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
  color: var(--ui-fbkc-faint);
}
.ui-fbkc__node--to:is([data-state="waiting"], [data-state="trying"])
  .ui-fbkc__node-title {
  color: var(--ui-fbkc-muted);
}
.ui-fbkc__node--to[data-state="answered"] {
  box-shadow:
    0 0 0 1px var(--ui-fbkc-ok-soft),
    0 0 0 4px var(--ui-fbkc-ok-bg),
    var(--ui-fbkc-shadow);
  transition-delay: 500ms;
}
.ui-fbkc__node--to[data-state="answered"] .ui-fbkc__node-icon {
  background: var(--ui-fbkc-ok-bg);
  color: var(--ui-fbkc-ok);
  transition-delay: 500ms;
}
.ui-fbkc__node--to[data-state="answered"] .ui-fbkc__node-sub {
  color: var(--ui-fbkc-ok);
}
.ui-fbkc__node--to[data-state="failed"] {
  box-shadow:
    0 0 0 1px var(--ui-fbkc-fail-soft),
    var(--ui-fbkc-shadow);
}
.ui-fbkc__node--to[data-state="failed"] .ui-fbkc__node-icon {
  background: var(--ui-fbkc-fail-bg);
  color: var(--ui-fbkc-fail);
}
.ui-fbkc__node--to[data-state="failed"] .ui-fbkc__node-sub {
  color: var(--ui-fbkc-fail);
}
.ui-fbkc__link {
  fill: none;
  stroke: var(--ui-fbkc-link);
  stroke-width: 1.25;
  stroke-linecap: round;
  vector-effect: non-scaling-stroke;
}
.ui-fbkc__link:is([data-status="waiting"], [data-status="idle"]) {
  stroke-dasharray: 0.012 0.03;
}
.ui-fbkc__link[data-status="skipped"] {
  stroke-dasharray: 0.012 0.03;
  opacity: 0.5;
}
.ui-fbkc__link[data-status="trying"] {
  stroke: var(--ui-fbkc-accent-soft);
  stroke-dasharray: 1 1;
  animation: ui-fbkc-draw 600ms var(--ui-fbkc-ease) both;
}
.ui-fbkc__link[data-status="failed"] {
  stroke: var(--ui-fbkc-fail-soft);
  stroke-dasharray: 0.035 0.035;
  animation: ui-fbkc-fade 500ms ease both;
}
.ui-fbkc__link[data-status="answered"] {
  stroke: var(--ui-fbkc-ok);
  stroke-width: 1.5;
  stroke-dasharray: 1 1;
  animation: ui-fbkc-draw 500ms var(--ui-fbkc-ease) both;
}
.ui-fbkc__link--out[data-status="answered"] {
  animation-delay: 300ms;
}
.ui-fbkc__light {
  fill: none;
  stroke-width: 2.5;
  stroke-linecap: round;
  vector-effect: non-scaling-stroke;
  animation: ui-fbkc-fade 400ms ease 300ms both;
}
.ui-fbkc__models {
  display: grid;
  grid-auto-rows: var(--ui-fbkc-row);
  gap: var(--ui-fbkc-gap);
  min-width: 0;
}
.ui-fbkc__model {
  position: relative;
  display: grid;
  grid-template-columns: 26px minmax(0, 1fr) auto;
  grid-template-rows: auto auto;
  row-gap: 7px;
  align-content: center;
  align-items: center;
  column-gap: 10px;
  min-width: 0;
  padding: 0 12px 0 10px;
  border-radius: 10px;
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
  transition:
    box-shadow 400ms ease,
    opacity 400ms ease;
}
.ui-fbkc__model[data-status="trying"] {
  box-shadow:
    0 0 0 1px var(--ui-fbkc-accent-soft),
    0 0 0 4px var(--ui-fbkc-accent-bg),
    var(--ui-fbkc-shadow);
}
.ui-fbkc__model[data-status="answered"] {
  box-shadow:
    0 0 0 1px var(--ui-fbkc-ok-soft),
    0 0 0 4px var(--ui-fbkc-ok-bg),
    var(--ui-fbkc-shadow);
}
.ui-fbkc__model[data-status="waiting"] .ui-fbkc__logo {
  opacity: 0.6;
}
.ui-fbkc__model[data-status="skipped"] > :not(.ui-fbkc__pop) {
  opacity: 0.5;
}
.ui-fbkc__logo {
  position: relative;
  grid-row: 1 / 3;
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: var(--ui-fbkc-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-fbkc-text);
  transition: opacity 400ms ease;
}
.ui-fbkc__logo:has(> .ui-fbkc__mark[data-logo]) {
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
}
.ui-fbkc__mark {
  display: grid;
  place-items: center;
}
.ui-fbkc__mark > :is(svg, img) {
  width: 14px;
  height: 14px;
  object-fit: contain;
}
.ui-fbkc__n {
  position: absolute;
  right: -5px;
  bottom: -4px;
  display: grid;
  place-items: center;
  min-width: 13px;
  height: 13px;
  padding: 0 3px;
  border-radius: 7px;
  background: var(--ui-fbkc-card);
  box-shadow:
    0 0 0 0.5px var(--ui-fbkc-line),
    0 1px 2px rgba(0, 0, 0, 0.08);
  font-size: 8.5px;
  font-weight: 500;
  line-height: 13px;
  color: var(--ui-fbkc-muted);
  font-variant-numeric: tabular-nums;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-fbkc__model[data-status="trying"] .ui-fbkc__n {
  background: var(--ui-fbkc-accent);
  color: var(--ui-fbkc-card);
  box-shadow: none;
}
.ui-fbkc__model[data-status="failed"] .ui-fbkc__n {
  background: var(--ui-fbkc-fail);
  color: var(--ui-fbkc-card);
  box-shadow: none;
}
.ui-fbkc__model[data-status="answered"] .ui-fbkc__n {
  background: var(--ui-fbkc-ok);
  color: var(--ui-fbkc-card);
  box-shadow: none;
}
.ui-fbkc__who {
  display: grid;
  min-width: 0;
}
.ui-fbkc__top {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.ui-fbkc__name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 17px;
  color: var(--ui-fbkc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: opacity 400ms ease;
}
.ui-fbkc__provider {
  flex: 0 1000 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-fbkc-faint);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fbkc__status {
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-fbkc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-fbkc-swap 300ms var(--ui-fbkc-ease);
}
.ui-fbkc__model[data-status="trying"] .ui-fbkc__status {
  color: var(--ui-fbkc-accent);
}
.ui-fbkc__model[data-status="failed"] .ui-fbkc__status {
  color: var(--ui-fbkc-fail);
}
.ui-fbkc__model[data-status="answered"] .ui-fbkc__status {
  color: var(--ui-fbkc-ok);
}
.ui-fbkc__meta {
  display: grid;
  justify-items: end;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-fbkc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-fbkc__meta > :first-child {
  line-height: 17px;
  color: var(--ui-fbkc-ink);
}
.ui-fbkc__model:is([data-status="waiting"], [data-status="skipped"])
  .ui-fbkc__meta
  > :first-child {
  color: var(--ui-fbkc-faint);
}
.ui-fbkc__blocks {
  grid-column: 2 / 4;
  display: flex;
  justify-content: space-between;
  gap: 2px;
  min-width: 0;
  overflow: hidden;
}
.ui-fbkc__blocks > i {
  flex: none;
  width: 5px;
  height: 5px;
  border-radius: 1.25px;
  background: var(--ui-fbkc-fill);
  transition:
    background-color 220ms ease,
    opacity 220ms ease;
}
.ui-fbkc__model[data-status="trying"] .ui-fbkc__blocks > i[data-on] {
  background: var(--ui-fbkc-accent);
  opacity: 0.7;
}
.ui-fbkc__model[data-status="failed"] .ui-fbkc__blocks > i[data-on] {
  background: var(--ui-fbkc-fail-soft);
}
.ui-fbkc__model[data-status="answered"] .ui-fbkc__blocks > i[data-on] {
  background: var(--ui-fbkc-ok-soft);
}
.ui-fbkc__model:is([data-status="waiting"], [data-status="skipped"])
  .ui-fbkc__blocks
  > i {
  opacity: 0.55;
}
.ui-fbkc__blocks > i[data-head] {
  animation: ui-fbkc-breathe 700ms ease-in-out infinite alternate;
}
.ui-fbkc__empty {
  display: grid;
  place-items: center;
  height: var(--ui-fbkc-row);
  font-size: 12px;
  color: var(--ui-fbkc-muted);
}
.ui-fbkc__model[data-status="trying"] .ui-fbkc__meta > span,
.ui-fbkc__summary[data-state="trying"] .ui-fbkc__total {
  --ui-fbkc-shine: var(--ui-fbkc-ink);
  background: linear-gradient(
      100deg,
      var(--ui-fbkc-shine) 0 40%,
      var(--ui-fbkc-faint) 50%,
      var(--ui-fbkc-shine) 60% 100%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-fbkc-shimmer 2600ms ease-in-out infinite;
}
.ui-fbkc__model[data-status="trying"] .ui-fbkc__meta > span:last-child {
  --ui-fbkc-shine: var(--ui-fbkc-muted);
}
.ui-fbkc__summary[data-state="trying"] .ui-fbkc__total svg {
  color: var(--ui-fbkc-faint);
}
.ui-fbkc__hov {
  outline: none;
  cursor: default;
}
.ui-fbkc__hov:is(:hover, :focus-visible) {
  z-index: 20;
}
.ui-fbkc__model.ui-fbkc__hov:focus-visible,
.ui-fbkc__node.ui-fbkc__hov:focus-visible {
  outline: 2px solid var(--ui-fbkc-focus);
  outline-offset: 2px;
}
.ui-fbkc__pop {
  position: absolute;
  z-index: 30;
  display: grid;
  gap: 10px;
  width: 280px;
  padding: 12px;
  border-radius: 12px;
  background: var(--ui-fbkc-card);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 4px 12px -4px rgba(0, 0, 0, 0.12),
    0 16px 32px -12px rgba(0, 0, 0, 0.16);
  text-align: left;
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition:
    opacity 160ms ease,
    transform 200ms var(--ui-fbkc-ease),
    visibility 0s linear 200ms;
}
.ui-fbkc__pop[data-place="below"] {
  top: calc(100% + 8px);
  left: 50%;
  transform: translate(-50%, -4px);
}
.ui-fbkc__pop[data-place="above"] {
  bottom: calc(100% + 8px);
  left: 50%;
  transform: translate(-50%, 4px);
}
.ui-fbkc__pop[data-place="start"] {
  top: calc(100% + 8px);
  left: 0;
  transform: translateY(-4px);
}
.ui-fbkc__pop[data-place="end"] {
  top: calc(100% + 8px);
  right: 0;
  transform: translateY(-4px);
}
.ui-fbkc__hov:is(:hover, :focus-visible) > .ui-fbkc__pop {
  opacity: 1;
  visibility: visible;
  transition:
    opacity 160ms ease 140ms,
    transform 220ms var(--ui-fbkc-ease) 140ms,
    visibility 0s;
}
.ui-fbkc__hov:is(:hover, :focus-visible)
  > .ui-fbkc__pop:is([data-place="below"], [data-place="above"]) {
  transform: translate(-50%, 0);
}
.ui-fbkc__hov:is(:hover, :focus-visible)
  > .ui-fbkc__pop:is([data-place="start"], [data-place="end"]) {
  transform: none;
}
.ui-fbkc__pop-head {
  display: flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
}
.ui-fbkc__pop-logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-fbkc-card);
  box-shadow: var(--ui-fbkc-shadow);
  color: var(--ui-fbkc-text);
}
.ui-fbkc__pop-logo > :is(svg, img) {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-fbkc__pop-who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-fbkc__pop-title {
  overflow: hidden;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 17px;
  color: var(--ui-fbkc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fbkc__pop-sub {
  overflow: hidden;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-fbkc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fbkc__pop-badge {
  flex: none;
  height: 20px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-fbkc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-fbkc-text);
  white-space: nowrap;
}
.ui-fbkc__pop-badge[data-tone="trying"] {
  background: var(--ui-fbkc-accent-bg);
  color: var(--ui-fbkc-accent);
}
.ui-fbkc__pop-badge[data-tone="failed"] {
  background: var(--ui-fbkc-fail-bg);
  color: var(--ui-fbkc-fail);
}
.ui-fbkc__pop-badge[data-tone="answered"] {
  background: var(--ui-fbkc-ok-bg);
  color: var(--ui-fbkc-ok);
}
.ui-fbkc__pop-quote {
  display: block;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--ui-fbkc-idle);
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-fbkc-text);
}
.ui-fbkc__pop-quote > span {
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  overflow-wrap: anywhere;
}
.ui-fbkc__pop-rows {
  display: grid;
  gap: 5px;
  padding-top: 10px;
  border-top: 0.5px solid var(--ui-fbkc-line);
}
.ui-fbkc__pop-row {
  display: flex;
  align-items: baseline;
  gap: 12px;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
}
.ui-fbkc__pop-label {
  flex: none;
  color: var(--ui-fbkc-muted);
}
.ui-fbkc__pop-value {
  display: -webkit-box;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-fbkc-ink);
  text-align: right;
  overflow-wrap: anywhere;
  font-variant-numeric: tabular-nums;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
}
.ui-fbkc__pop-err {
  color: var(--ui-fbkc-fail);
}
@keyframes ui-fbkc-swap {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@keyframes ui-fbkc-shimmer {
  0% {
    background-position: 100% 0;
  }
  55%,
  100% {
    background-position: 0 0;
  }
}
@keyframes ui-fbkc-breathe {
  from {
    opacity: 0.4;
  }
  to {
    opacity: 1;
  }
}
@keyframes ui-fbkc-draw {
  from {
    stroke-dashoffset: 1;
  }
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-fbkc-fade {
  from {
    opacity: 0;
  }
}
@container (max-width: 680px) {
  .ui-fbkc__provider {
    display: none;
  }
}
@container (max-width: 520px) {
  .ui-fbkc__flow {
    grid-template-columns: 44px minmax(0, 1fr);
    padding: 16px 12px 16px 14px;
  }
  .ui-fbkc__node--from {
    grid-column: 1 / -1;
    justify-self: start;
    min-width: 150px;
    margin-bottom: 12px;
  }
  .ui-fbkc__links--wide,
  .ui-fbkc__node--to {
    display: none;
  }
  .ui-fbkc__links--tree {
    display: block;
    align-self: start;
    margin-top: -12px;
  }
  .ui-fbkc__bar {
    flex-wrap: wrap;
    row-gap: 4px;
  }
  .ui-fbkc__title {
    flex-basis: 100%;
  }
  .ui-fbkc__pop {
    width: min(280px, calc(100cqw - 24px));
  }
  .ui-fbkc__pop:is([data-place="below"], [data-place="above"]) {
    left: auto;
    right: 0;
    transform: translateY(-4px);
  }
  .ui-fbkc__hov:is(:hover, :focus-visible)
    > .ui-fbkc__pop:is([data-place="below"], [data-place="above"]) {
    transform: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-fbkc *,
  .ui-fbkc *::before,
  .ui-fbkc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-fbkc__light {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-fbkc {
  --ui-fbkc-card: #232327;
  --ui-fbkc-strong: #ffffff;
  --ui-fbkc-ink: rgba(255, 255, 255, 0.9);
  --ui-fbkc-text: rgba(255, 255, 255, 0.62);
  --ui-fbkc-muted: rgba(255, 255, 255, 0.45);
  --ui-fbkc-faint: rgba(255, 255, 255, 0.28);
  --ui-fbkc-line: rgba(255, 255, 255, 0.08);
  --ui-fbkc-link: rgba(255, 255, 255, 0.2);
  --ui-fbkc-fill: rgba(255, 255, 255, 0.08);
  --ui-fbkc-idle: #1f1f22;
  --ui-fbkc-wait: #1f1f22;
  --ui-fbkc-area: #19191b;
  --ui-fbkc-grid: rgba(255, 255, 255, 0.06);
  --ui-fbkc-accent: #70b8ff;
  --ui-fbkc-accent-soft: rgba(112, 184, 255, 0.5);
  --ui-fbkc-accent-bg: rgba(112, 184, 255, 0.1);
  --ui-fbkc-ok: #3dd68c;
  --ui-fbkc-ok-soft: rgba(61, 214, 140, 0.45);
  --ui-fbkc-ok-bg: rgba(61, 214, 140, 0.1);
  --ui-fbkc-fail: #ff977d;
  --ui-fbkc-fail-soft: rgba(255, 151, 125, 0.5);
  --ui-fbkc-fail-bg: rgba(255, 151, 125, 0.12);
  --ui-fbkc-focus: rgba(77, 141, 255, 0.8);
  --ui-fbkc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-fbkc__pop {
  background: #2a2a2f;
  box-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.12),
    0 16px 32px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-fbkc__pop-logo {
  background: #333338;
}
`;export{n as default};
