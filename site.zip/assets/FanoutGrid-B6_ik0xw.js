const n=`.ui-fog {
  --ui-fog-tray: #f0f0f0;
  --ui-fog-card: #ffffff;
  --ui-fog-panel: #ffffff;
  --ui-fog-strong: #171717;
  --ui-fog-ink: #171717;
  --ui-fog-text: #6b6b6b;
  --ui-fog-muted: #626873;
  --ui-fog-faint: #b8b8b8;
  --ui-fog-line: #ececec;
  --ui-fog-fill: rgba(0, 0, 0, 0.05);
  --ui-fog-accent: #2a5ee5;
  --ui-fog-focus: rgba(0, 96, 226, 0.7);
  --ui-fog-pin: rgba(23, 23, 23, 0.22);
  --ui-fog-queued-bg: #f3f3f3;
  --ui-fog-queued-edge: #e6e6e6;
  --ui-fog-running-bg: #e3ecff;
  --ui-fog-running-edge: #a9c2ff;
  --ui-fog-running-ink: #2456d6;
  --ui-fog-retrying-bg: #ffefd6;
  --ui-fog-retrying-edge: #f7c27a;
  --ui-fog-retrying-ink: #a45200;
  --ui-fog-done-bg: #dcf3e4;
  --ui-fog-done-edge: #9fd9b4;
  --ui-fog-done-ink: #187941;
  --ui-fog-failed-bg: #fde3df;
  --ui-fog-failed-edge: #f1a397;
  --ui-fog-failed-ink: #c2331f;
  --ui-fog-shine: rgba(255, 255, 255, 0.9);
  --ui-fog-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-fog-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-fog-cell: 12px;
  --ui-fog-gap: 4px;
  --ui-fog-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-fog-tray);
  container: ui-fog / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-fog-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-fog *,
.ui-fog *::before,
.ui-fog *::after {
  box-sizing: border-box;
}
:where(.ui-fog) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-fog button:focus-visible {
  outline: 2px solid var(--ui-fog-focus);
  outline-offset: 2px;
}
.ui-fog svg {
  display: block;
  flex: none;
}
.ui-fog__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-fog__n {
  font-variant-numeric: tabular-nums;
}
.ui-fog__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  padding: 8px 12px 12px;
}
.ui-fog__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-fog-accent);
}
.ui-fog__mark > svg {
  width: 16px;
  height: 16px;
}
.ui-fog__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-fog-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fog__job {
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  color: var(--ui-fog-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fog__sum {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 2px 14px;
  margin-left: auto;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-fog-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-fog__sum b {
  font-weight: 600;
  color: var(--ui-fog-ink);
}
.ui-fog__time[data-done] {
  font-weight: 500;
  color: var(--ui-fog-done-ink);
}
.ui-fog__panel {
  position: relative;
  display: grid;
  padding: 18px;
  border-radius: 16px;
  background: var(--ui-fog-panel);
  box-shadow: var(--ui-fog-shadow);
}
.ui-fog__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 12px;
  min-width: 0;
  padding: 8px 6px 4px 8px;
}
.ui-fog__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0 2px;
}
.ui-fog__key {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 9px;
  border-radius: 999px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-fog-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease,
    box-shadow 160ms ease;
}
.ui-fog__key:hover {
  background: var(--ui-fog-fill);
  color: var(--ui-fog-ink);
}
.ui-fog__key[aria-pressed="true"] {
  background: var(--ui-fog-card);
  box-shadow: var(--ui-fog-shadow);
  color: var(--ui-fog-ink);
}
.ui-fog__key[data-zero] {
  display: none;
}
.ui-fog__key[data-off] {
  opacity: 0.5;
}
.ui-fog__key .ui-fog__n {
  font-weight: 600;
  color: var(--ui-fog-ink);
}
.ui-fog__swatch {
  width: 9px;
  height: 9px;
  border-radius: 3px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 1px var(--k-edge);
}
.ui-fog__retry {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  margin-left: auto;
  padding: 0 12px 0 10px;
  border-radius: 999px;
  background: var(--ui-fog-card);
  box-shadow: var(--ui-fog-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-fog-failed-ink);
  animation: ui-fog-in 260ms var(--ui-fog-ease) both;
  transition: box-shadow 160ms ease;
}
.ui-fog__retry:hover {
  box-shadow: var(--ui-fog-pop);
}
.ui-fog [data-status="queued"] {
  --k-bg: var(--ui-fog-queued-bg);
  --k-edge: var(--ui-fog-queued-edge);
  --k-ink: var(--ui-fog-muted);
}
.ui-fog [data-status="running"] {
  --k-bg: var(--ui-fog-running-bg);
  --k-edge: var(--ui-fog-running-edge);
  --k-ink: var(--ui-fog-running-ink);
}
.ui-fog [data-status="retrying"] {
  --k-bg: var(--ui-fog-retrying-bg);
  --k-edge: var(--ui-fog-retrying-edge);
  --k-ink: var(--ui-fog-retrying-ink);
}
.ui-fog [data-status="done"] {
  --k-bg: var(--ui-fog-done-bg);
  --k-edge: var(--ui-fog-done-edge);
  --k-ink: var(--ui-fog-done-ink);
}
.ui-fog [data-status="failed"] {
  --k-bg: var(--ui-fog-failed-bg);
  --k-edge: var(--ui-fog-failed-edge);
  --k-ink: var(--ui-fog-failed-ink);
}
.ui-fog__grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, var(--ui-fog-cell));
  gap: var(--ui-fog-gap);
  justify-content: space-between;
  padding: 2px;
  margin: -2px;
  border-radius: 6px;
  outline: none;
}
.ui-fog__grid:focus-visible {
  outline: 2px solid var(--ui-fog-focus);
  outline-offset: 2px;
}
.ui-fog__cell {
  position: relative;
  width: var(--ui-fog-cell);
  height: var(--ui-fog-cell);
  border-radius: 3.5px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 1px var(--k-edge);
  overflow: hidden;
  cursor: pointer;
  transition:
    background-color 360ms ease,
    box-shadow 200ms ease,
    opacity 220ms ease,
    transform 160ms ease;
  animation: ui-fog-cell-in 420ms var(--ui-fog-ease) calc(var(--d, 0) * 2ms)
    backwards;
}
.ui-fog__cell[data-status="running"]::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      110deg,
      transparent 25%,
      var(--ui-fog-shine) 50%,
      transparent 75%
    )
    0 0 / 300% 100%;
  opacity: 0.8;
  animation: ui-fog-cell-sweep 1300ms linear calc(var(--i, 0) * -97ms) infinite;
}
.ui-fog__cell[data-status="retrying"] {
  animation: ui-fog-breathe 1100ms ease-in-out infinite alternate;
}
.ui-fog__cell:is([data-status="done"], [data-status="failed"]) {
  animation: ui-fog-pop 420ms var(--ui-fog-ease);
}
.ui-fog__cell:hover,
.ui-fog__cell[data-on] {
  box-shadow: inset 0 0 0 1.5px var(--k-ink);
  transform: scale(1.3);
  z-index: 1;
}
.ui-fog__cell[data-pinned] {
  box-shadow:
    inset 0 0 0 1.5px var(--k-ink),
    0 0 0 2px var(--ui-fog-pin);
}
.ui-fog__cell[data-dim] {
  opacity: 0.2;
}
.ui-fog__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 5;
  display: grid;
  gap: 3px;
  width: max-content;
  max-width: min(290px, calc(100% - 16px));
  padding: 10px 14px 11px;
  border-radius: 14px;
  background: var(--ui-fog-card);
  box-shadow: var(--ui-fog-pop);
  pointer-events: none;
  transform-origin: var(--x, 50%) bottom;
  animation: ui-fog-tip 160ms var(--ui-fog-ease) both;
}
.ui-fog__tip[data-side="below"] {
  transform-origin: var(--x, 50%) top;
}
.ui-fog__tip-head {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  min-width: 0;
}
.ui-fog__tip-label {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-fog-ink);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-fog__pill {
  flex: none;
  height: 20px;
  margin-left: auto;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--k-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--k-ink);
}
.ui-fog__tip-meta {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-fog-muted);
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.ui-fog__tip-result {
  display: -webkit-box;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-fog-text);
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
}
.ui-fog__tip-error {
  display: -webkit-box;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-fog-failed-ink);
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
}
@container ui-fog (max-width: 520px) {
  .ui-fog__panel {
    --ui-fog-cell: 10px;
    --ui-fog-gap: 3px;
    padding: 14px;
  }
  .ui-fog__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-fog__foot {
    align-items: center;
  }
  .ui-fog__legend {
    display: grid;
    grid-template-columns: repeat(2, max-content);
  }
  .ui-fog__key[data-zero] {
    display: inline-flex;
    opacity: 0.45;
  }
  .ui-fog__retry {
    flex: none;
    margin-left: auto;
  }
}
@keyframes ui-fog-cell-in {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-fog-pop {
  0% {
    transform: scale(0.7);
  }
  55% {
    transform: scale(1.18);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-fog-cell-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: -50% 0;
  }
}
@keyframes ui-fog-breathe {
  from {
    opacity: 0.55;
  }
  to {
    opacity: 1;
  }
}
@keyframes ui-fog-tip {
  from {
    opacity: 0;
    transform: translateY(3px) scale(0.97);
  }
}
@keyframes ui-fog-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-fog *,
  .ui-fog *::before,
  .ui-fog *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-fog {
  --ui-fog-tray: #1a1a1c;
  --ui-fog-card: #232326;
  --ui-fog-panel: #232326;
  --ui-fog-strong: #f5f5f5;
  --ui-fog-ink: #f0f0f0;
  --ui-fog-text: #a1a1a1;
  --ui-fog-muted: #8a8a8a;
  --ui-fog-faint: #5c5c5c;
  --ui-fog-line: #2e2e31;
  --ui-fog-fill: rgba(255, 255, 255, 0.06);
  --ui-fog-accent: #6d93ff;
  --ui-fog-focus: rgba(77, 141, 255, 0.8);
  --ui-fog-pin: rgba(255, 255, 255, 0.3);
  --ui-fog-queued-bg: #2b2b2f;
  --ui-fog-queued-edge: #36363b;
  --ui-fog-running-bg: #1d2b4d;
  --ui-fog-running-edge: #3c5fb3;
  --ui-fog-running-ink: #8aaeff;
  --ui-fog-retrying-bg: #3a2a12;
  --ui-fog-retrying-edge: #8a5a1c;
  --ui-fog-retrying-ink: #ffb357;
  --ui-fog-done-bg: #15321f;
  --ui-fog-done-edge: #2f7a4b;
  --ui-fog-done-ink: #55d68c;
  --ui-fog-failed-bg: #3d1a16;
  --ui-fog-failed-edge: #8f3a2e;
  --ui-fog-failed-ink: #ff8a76;
  --ui-fog-shine: rgba(255, 255, 255, 0.28);
  --ui-fog-shadow: 0 0 0 1px #2e2e31, 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-fog-pop: 0 0 0 1px #34343a, 0 16px 36px -12px rgba(0, 0, 0, 0.7);
}
`;export{n as default};
