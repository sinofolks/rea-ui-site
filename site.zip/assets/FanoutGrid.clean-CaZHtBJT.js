const n=`.ui-fogc {
  --ui-fogc-panel: #ffffff;
  --ui-fogc-card: #ffffff;
  --ui-fogc-strong: #000000;
  --ui-fogc-ink: rgba(0, 0, 0, 0.88);
  --ui-fogc-text: rgba(0, 0, 0, 0.65);
  --ui-fogc-muted: rgba(0, 0, 0, 0.65);
  --ui-fogc-faint: rgba(0, 0, 0, 0.27);
  --ui-fogc-line: rgba(0, 0, 0, 0.06);
  --ui-fogc-fill: rgba(0, 0, 0, 0.06);
  --ui-fogc-accent: #0060e2;
  --ui-fogc-focus: rgba(0, 96, 226, 0.7);
  --ui-fogc-pin: rgba(0, 96, 226, 0.35);
  --ui-fogc-queued-bg: rgba(0, 0, 0, 0.035);
  --ui-fogc-queued-edge: rgba(0, 0, 0, 0.07);
  --ui-fogc-running-bg: rgba(0, 96, 226, 0.12);
  --ui-fogc-running-edge: rgba(0, 96, 226, 0.36);
  --ui-fogc-running-ink: #0058cf;
  --ui-fogc-retrying-bg: #ff9c0030;
  --ui-fogc-retrying-edge: rgba(214, 120, 0, 0.45);
  --ui-fogc-retrying-ink: #b74400;
  --ui-fogc-done-bg: rgba(0, 164, 51, 0.2);
  --ui-fogc-done-edge: rgba(0, 140, 50, 0.38);
  --ui-fogc-done-ink: #007a2d;
  --ui-fogc-failed-bg: #f52b002e;
  --ui-fogc-failed-edge: rgba(215, 36, 0, 0.48);
  --ui-fogc-failed-ink: #cd2200;
  --ui-fogc-shine: rgba(255, 255, 255, 0.85);
  --ui-fogc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-fogc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-fogc-cell: 12px;
  --ui-fogc-gap: 4px;
  --ui-fogc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-fogc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-fogc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-fogc *,
.ui-fogc *::before,
.ui-fogc *::after {
  box-sizing: border-box;
}
:where(.ui-fogc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-fogc button:focus-visible {
  outline: 2px solid var(--ui-fogc-focus);
  outline-offset: 2px;
}
.ui-fogc svg {
  display: block;
  flex: none;
}
.ui-fogc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-fogc__n {
  font-variant-numeric: tabular-nums;
}
.ui-fogc__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  margin-bottom: 16px;
}
.ui-fogc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-fogc-accent);
}
.ui-fogc__mark > svg {
  width: 16px;
  height: 16px;
}
.ui-fogc__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-fogc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fogc__job {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-fogc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-fogc__sum {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 2px 14px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fogc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-fogc__sum b {
  font-weight: 500;
  color: var(--ui-fogc-ink);
}
.ui-fogc__time[data-done] {
  color: var(--ui-fogc-done-ink);
}
.ui-fogc__panel {
  position: relative;
  display: grid;
  gap: 14px;
  padding: 16px 16px 14px;
  border-radius: 10px;
  background: var(--ui-fogc-panel);
  box-shadow: var(--ui-fogc-shadow);
}
.ui-fogc__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 12px;
  min-width: 0;
}
.ui-fogc__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 0 2px;
  margin: -3px -6px;
}
.ui-fogc__key {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 24px;
  padding: 0 6px;
  border-radius: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fogc-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-fogc__key:hover,
.ui-fogc__key[aria-pressed="true"] {
  background: var(--ui-fogc-fill);
  color: var(--ui-fogc-ink);
}
.ui-fogc__key[data-zero] {
  display: none;
}
.ui-fogc__key[data-off] {
  opacity: 0.45;
}
.ui-fogc__key .ui-fogc__n {
  color: var(--ui-fogc-ink);
}
.ui-fogc__swatch {
  width: 8px;
  height: 8px;
  border-radius: 2.5px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 0.5px var(--k-edge);
}
.ui-fogc__retry {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  margin: -3px -6px -3px auto;
  padding: 0 6px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-fogc-failed-ink);
  animation: ui-fogc-in 260ms var(--ui-fogc-ease) both;
  transition: background-color 160ms ease;
}
.ui-fogc__retry:hover {
  background: var(--ui-fogc-failed-bg);
}
.ui-fogc__retry > svg {
  width: 13px;
  height: 13px;
}
.ui-fogc [data-status="queued"] {
  --k-bg: var(--ui-fogc-queued-bg);
  --k-edge: var(--ui-fogc-queued-edge);
  --k-ink: var(--ui-fogc-muted);
}
.ui-fogc [data-status="running"] {
  --k-bg: var(--ui-fogc-running-bg);
  --k-edge: var(--ui-fogc-running-edge);
  --k-ink: var(--ui-fogc-running-ink);
}
.ui-fogc [data-status="retrying"] {
  --k-bg: var(--ui-fogc-retrying-bg);
  --k-edge: var(--ui-fogc-retrying-edge);
  --k-ink: var(--ui-fogc-retrying-ink);
}
.ui-fogc [data-status="done"] {
  --k-bg: var(--ui-fogc-done-bg);
  --k-edge: var(--ui-fogc-done-edge);
  --k-ink: var(--ui-fogc-done-ink);
}
.ui-fogc [data-status="failed"] {
  --k-bg: var(--ui-fogc-failed-bg);
  --k-edge: var(--ui-fogc-failed-edge);
  --k-ink: var(--ui-fogc-failed-ink);
}
.ui-fogc__grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, var(--ui-fogc-cell));
  gap: var(--ui-fogc-gap);
  justify-content: space-between;
  padding: 2px;
  margin: -2px;
  border-radius: 6px;
  outline: none;
}
.ui-fogc__grid:focus-visible {
  outline: 2px solid var(--ui-fogc-focus);
  outline-offset: 2px;
}
.ui-fogc__cell {
  position: relative;
  width: var(--ui-fogc-cell);
  height: var(--ui-fogc-cell);
  border-radius: 3px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 0.5px var(--k-edge);
  overflow: hidden;
  cursor: pointer;
  transition:
    background-color 360ms ease,
    box-shadow 200ms ease,
    opacity 220ms ease,
    transform 160ms ease;
  animation: ui-fogc-cell-in 420ms var(--ui-fogc-ease) calc(var(--d, 0) * 2ms)
    backwards;
}
.ui-fogc__cell[data-status="running"]::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      110deg,
      transparent 25%,
      var(--ui-fogc-shine) 50%,
      transparent 75%
    )
    0 0 / 300% 100%;
  opacity: 0.75;
  animation: ui-fogc-cell-sweep 1300ms linear calc(var(--i, 0) * -97ms) infinite;
}
.ui-fogc__cell[data-status="retrying"] {
  animation: ui-fogc-breathe 1100ms ease-in-out infinite alternate;
}
.ui-fogc__cell:is([data-status="done"], [data-status="failed"]) {
  animation: ui-fogc-pop 420ms var(--ui-fogc-ease);
}
.ui-fogc__cell:hover,
.ui-fogc__cell[data-on] {
  box-shadow: inset 0 0 0 1px var(--k-ink);
  transform: scale(1.3);
  z-index: 1;
}
.ui-fogc__cell[data-pinned] {
  box-shadow:
    inset 0 0 0 1px var(--k-ink),
    0 0 0 2px var(--ui-fogc-pin);
}
.ui-fogc__cell[data-dim] {
  opacity: 0.18;
}
.ui-fogc__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 5;
  display: grid;
  gap: 3px;
  width: max-content;
  max-width: min(280px, calc(100% - 16px));
  padding: 9px 12px 10px;
  border-radius: 10px;
  background: var(--ui-fogc-card);
  box-shadow: var(--ui-fogc-pop);
  pointer-events: none;
  transform-origin: var(--x, 50%) bottom;
  animation: ui-fogc-tip 160ms var(--ui-fogc-ease) both;
}
.ui-fogc__tip[data-side="below"] {
  transform-origin: var(--x, 50%) top;
}
.ui-fogc__tip-head {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  min-width: 0;
}
.ui-fogc__tip-label {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-fogc-ink);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-fogc__pill {
  flex: none;
  margin-top: 1px;
  height: 18px;
  margin-left: auto;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--k-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--k-ink);
}
.ui-fogc__tip-meta {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fogc-muted);
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.ui-fogc__tip-result {
  display: -webkit-box;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-fogc-text);
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
}
.ui-fogc__tip-error {
  display: -webkit-box;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-fogc-failed-ink);
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 4;
  -webkit-box-orient: vertical;
}
@container ui-fogc (max-width: 520px) {
  .ui-fogc__panel {
    --ui-fogc-cell: 10px;
    --ui-fogc-gap: 3px;
    padding: 12px;
  }
  .ui-fogc__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-fogc__foot {
    align-items: center;
  }
  .ui-fogc__legend {
    display: grid;
    grid-template-columns: repeat(2, max-content);
  }
  .ui-fogc__key[data-zero] {
    display: inline-flex;
    opacity: 0.45;
  }
  .ui-fogc__retry {
    flex: none;
    margin-left: auto;
  }
}
@keyframes ui-fogc-cell-in {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-fogc-pop {
  0% {
    transform: scale(0.7);
  }
  55% {
    transform: scale(1.18);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-fogc-cell-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: -50% 0;
  }
}
@keyframes ui-fogc-breathe {
  from {
    opacity: 0.55;
  }
  to {
    opacity: 1;
  }
}
@keyframes ui-fogc-tip {
  from {
    opacity: 0;
    transform: translateY(3px) scale(0.97);
  }
}
@keyframes ui-fogc-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-fogc *,
  .ui-fogc *::before,
  .ui-fogc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-fogc {
  --ui-fogc-panel: #1c1c1f;
  --ui-fogc-card: #232326;
  --ui-fogc-strong: #ffffff;
  --ui-fogc-ink: rgba(255, 255, 255, 0.9);
  --ui-fogc-text: rgba(255, 255, 255, 0.62);
  --ui-fogc-muted: rgba(255, 255, 255, 0.45);
  --ui-fogc-faint: rgba(255, 255, 255, 0.28);
  --ui-fogc-line: rgba(255, 255, 255, 0.08);
  --ui-fogc-fill: rgba(255, 255, 255, 0.08);
  --ui-fogc-accent: #5b9aff;
  --ui-fogc-focus: rgba(77, 141, 255, 0.8);
  --ui-fogc-pin: rgba(91, 154, 255, 0.45);
  --ui-fogc-queued-bg: rgba(255, 255, 255, 0.05);
  --ui-fogc-queued-edge: rgba(255, 255, 255, 0.09);
  --ui-fogc-running-bg: rgba(60, 130, 255, 0.24);
  --ui-fogc-running-edge: rgba(112, 170, 255, 0.5);
  --ui-fogc-running-ink: #8ab8ff;
  --ui-fogc-retrying-bg: rgba(255, 160, 40, 0.24);
  --ui-fogc-retrying-edge: rgba(255, 180, 70, 0.5);
  --ui-fogc-retrying-ink: #ffb357;
  --ui-fogc-done-bg: rgba(40, 200, 110, 0.22);
  --ui-fogc-done-edge: rgba(60, 220, 130, 0.42);
  --ui-fogc-done-ink: #3dd68c;
  --ui-fogc-failed-bg: rgba(255, 70, 50, 0.24);
  --ui-fogc-failed-edge: rgba(255, 110, 90, 0.5);
  --ui-fogc-failed-ink: #ff977d;
  --ui-fogc-shine: rgba(255, 255, 255, 0.3);
  --ui-fogc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-fogc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
`;export{n as default};
