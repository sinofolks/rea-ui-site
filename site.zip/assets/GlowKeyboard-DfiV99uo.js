const n=`.ui-gk {
  --ui-gk-bg: #fafafa;
  --ui-gk-floor-light: 1;
  --ui-gk-ring: 1;
  --ui-gk-input-border: #fff;
  --ui-gk-input-bg: rgba(255, 255, 255, 0.9);
  --ui-gk-input-inner: #fff;
  --ui-gk-caret: rgba(175, 175, 175, 0.4);
  --ui-gk-text: #676767;
  --ui-gk-placeholder: #afafaf;
  --ui-gk-board-border: rgba(255, 255, 255, 0.55);
  --ui-gk-board-bg: rgba(255, 255, 255, 0.16);
  --ui-gk-board-inner: rgba(255, 255, 255, 0.5);
  --ui-gk-board-shadow: rgba(0, 0, 0, 0.05);
  --ui-gk-key-bg: rgba(255, 255, 255, 0.72);
  --ui-gk-key-edge: inset 0 0 0 transparent;
  --ui-gk-key-drop: rgba(0, 0, 0, 0.05);
  --ui-gk-key-inner: rgba(255, 255, 255, 0.6);
  --ui-gk-key-text: rgba(20, 20, 30, 0.5);
  --ui-gk-touchid: rgba(20, 20, 30, 0.25);
  --ui-gk-key-down-bg: rgba(206, 206, 214, 0.97);
  --ui-gk-key-down-text: rgba(20, 20, 30, 0.9);
  --ui-gk-key-down-inner: rgba(0, 0, 0, 0.08);
  container-type: inline-size;
  width: 100%;
  font-family: inherit;
  -webkit-font-smoothing: antialiased;
  cursor: text;
}
.ui-gk-frame {
  --ui-gk-u: calc(100cqw / 2200);
  position: relative;
  aspect-ratio: 2200 / 1200;
  overflow: hidden;
  isolation: isolate;
  background: var(--ui-gk-bg);
}
.ui-gk-frame > * {
  position: absolute;
  margin: 0;
}
.ui-gk-floor--color {
  left: calc(-290 * var(--ui-gk-u));
  top: calc(753 * var(--ui-gk-u));
  width: calc(2864.5 * var(--ui-gk-u));
  height: calc(931.5 * var(--ui-gk-u));
}
.ui-gk-floor--light {
  left: calc(-65 * var(--ui-gk-u));
  top: calc(922 * var(--ui-gk-u));
  width: calc(2414 * var(--ui-gk-u));
  height: calc(785 * var(--ui-gk-u));
  mix-blend-mode: plus-lighter;
  opacity: var(--ui-gk-floor-light);
}
.ui-gk-bleed {
  position: absolute;
  inset: -31.27% -10.17%;
  transform-origin: 50% 70%;
  will-change: transform;
}
.ui-gk-bleed svg {
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 25%;
  height: 25%;
  overflow: visible;
  transform: scale(4);
  transform-origin: 0 0;
  will-change: transform;
}
.ui-gk-floor--color svg {
  filter: blur(calc(calc(145.65 * var(--ui-gk-u)) / 4));
}
.ui-gk-floor--light svg {
  filter: blur(calc(calc(122.74 * var(--ui-gk-u)) / 4));
}
.ui-gk-floor--color .ui-gk-bleed {
  animation: ui-gk-drift-color 6s ease-in-out infinite;
}
.ui-gk-floor--light .ui-gk-bleed {
  animation: ui-gk-drift-light 6s ease-in-out infinite;
}
@keyframes ui-gk-drift-color {
  0%,
  100% {
    transform: translate(0, 0) scale(1, 1);
  }
  33% {
    transform: translate(
        calc(-120 * var(--ui-gk-u)),
        calc(-20 * var(--ui-gk-u))
      )
      scale(1.05, 1.08);
  }
  66% {
    transform: translate(calc(100 * var(--ui-gk-u)), calc(12 * var(--ui-gk-u)))
      scale(0.98, 0.96);
  }
}
@keyframes ui-gk-drift-light {
  0%,
  100% {
    transform: translate(0, 0) scale(1, 1);
  }
  33% {
    transform: translate(
        calc(-100 * var(--ui-gk-u)),
        calc(-10 * var(--ui-gk-u))
      )
      scale(1.03, 1);
  }
  66% {
    transform: translate(calc(85 * var(--ui-gk-u)), calc(10 * var(--ui-gk-u)))
      scale(0.98, 0.94);
  }
}
.ui-gk-composer {
  inset: 0;
}
.ui-gk-composer > * {
  position: absolute;
}
.ui-gk-glow {
  left: calc(578.36 * var(--ui-gk-u));
  top: calc(230 * var(--ui-gk-u));
  width: calc(1037.79 * var(--ui-gk-u));
  height: calc(152.94 * var(--ui-gk-u));
  border-radius: calc(163.86 * var(--ui-gk-u));
}
.ui-gk-glow::before,
.ui-gk-glow::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  filter: var(--ui-gk-glow-blur);
  will-change: opacity;
}
.ui-gk-glow::before {
  background-image: linear-gradient(
    to right,
    var(--ui-gk-glow-a),
    var(--ui-gk-glow-b)
  );
}
.ui-gk-glow::after {
  background-image: linear-gradient(
    to right,
    var(--ui-gk-glow-b),
    var(--ui-gk-glow-a)
  );
  opacity: 0;
  animation: ui-gk-swap 6s ease-in-out infinite;
}
.ui-gk-glow--soft {
  --ui-gk-glow-a: rgba(255, 119, 0, 0.3);
  --ui-gk-glow-b: rgba(255, 0, 85, 0.3);
  --ui-gk-glow-blur: blur(calc(54 * var(--ui-gk-u)));
}
.ui-gk-glow--hard {
  --ui-gk-glow-a: #f70;
  --ui-gk-glow-b: #f05;
  --ui-gk-glow-blur: blur(calc(9.5 * var(--ui-gk-u)));
}
.ui-gk-glow-mid {
  left: calc(817.25 * var(--ui-gk-u));
  top: calc(230 * var(--ui-gk-u));
  width: calc(560 * var(--ui-gk-u));
  height: calc(152.94 * var(--ui-gk-u));
  border-radius: calc(76.47 * var(--ui-gk-u));
  background: radial-gradient(
    closest-side,
    rgba(255, 60, 45, 0.75),
    rgba(255, 60, 45, 0)
  );
  filter: blur(calc(22 * var(--ui-gk-u)));
  will-change: transform, opacity;
  animation: ui-gk-breathe 4s ease-in-out infinite;
}
.ui-gk-hit {
  top: calc(230 * var(--ui-gk-u));
  width: calc(340 * var(--ui-gk-u));
  height: calc(152.94 * var(--ui-gk-u));
  border-radius: calc(76.47 * var(--ui-gk-u));
  pointer-events: none;
}
@keyframes ui-gk-swap {
  50% {
    opacity: 1;
  }
}
@keyframes ui-gk-breathe {
  0%,
  100% {
    transform: translateY(0) scaleY(1);
    opacity: 0.7;
  }
  25% {
    transform: translateY(calc(-16 * var(--ui-gk-u))) scaleY(1.4);
    opacity: 1;
  }
  50% {
    transform: translateY(0) scaleY(1.1);
    opacity: 0.8;
  }
  75% {
    transform: translateY(calc(16 * var(--ui-gk-u))) scaleY(1.45);
    opacity: 1;
  }
}
.ui-gk-ring {
  left: calc(576.86 * var(--ui-gk-u));
  top: calc(228.5 * var(--ui-gk-u));
  width: calc(1040.79 * var(--ui-gk-u));
  height: calc(155.94 * var(--ui-gk-u));
  border: calc(3 * var(--ui-gk-u)) solid transparent;
  border-radius: calc(77.97 * var(--ui-gk-u));
  background: linear-gradient(
      to right,
      rgba(255, 255, 255, 0) 0.14%,
      #fff 25%,
      #fff 75%,
      rgba(255, 255, 255, 0) 99.86%
    )
    border-box;
  -webkit-mask:
    linear-gradient(#000 0 0) padding-box,
    linear-gradient(#000 0 0) border-box;
  -webkit-mask-composite: xor;
  mask-composite: exclude;
  filter: blur(calc(5.74 * var(--ui-gk-u)));
  mix-blend-mode: plus-lighter;
  opacity: var(--ui-gk-ring);
}
.ui-gk-input {
  left: calc(576.99 * var(--ui-gk-u));
  top: calc(230 * var(--ui-gk-u));
  width: calc(1046.09 * var(--ui-gk-u));
  height: calc(152.94 * var(--ui-gk-u));
  display: flex;
  align-items: center;
  gap: calc(20.59 * var(--ui-gk-u));
  padding: calc(27.31 * var(--ui-gk-u));
  border: calc(1.37 * var(--ui-gk-u)) solid var(--ui-gk-input-border);
  border-radius: calc(109.24 * var(--ui-gk-u));
}
.ui-gk-glass {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
}
.ui-gk-input > .ui-gk-glass {
  background: var(--ui-gk-input-bg);
  -webkit-backdrop-filter: blur(calc(25.48 * var(--ui-gk-u)));
  backdrop-filter: blur(calc(25.48 * var(--ui-gk-u)));
}
.ui-gk-input > .ui-gk-glass--inner {
  background: none;
  -webkit-backdrop-filter: none;
  backdrop-filter: none;
  box-shadow:
    inset 0 0 calc(35.91 * var(--ui-gk-u)) 0 var(--ui-gk-input-inner),
    inset 0 0 calc(35.91 * var(--ui-gk-u)) 0 var(--ui-gk-input-inner);
}
.ui-gk-orb {
  position: relative;
  flex: none;
  width: calc(95.59 * var(--ui-gk-u));
  height: calc(95.59 * var(--ui-gk-u));
}
.ui-gk-field {
  position: relative;
  flex: 1;
  display: flex;
  align-items: center;
  gap: calc(8.19 * var(--ui-gk-u));
  min-width: 0;
}
.ui-gk-caret {
  flex: none;
  width: calc(2.73 * var(--ui-gk-u));
  height: calc(60.08 * var(--ui-gk-u));
  background: var(--ui-gk-caret);
  animation: ui-gk-blink 1.06s step-end infinite;
}
.ui-gk-field:has(.ui-gk-prompt:not(:placeholder-shown)) .ui-gk-caret {
  visibility: hidden;
}
@keyframes ui-gk-blink {
  50% {
    opacity: 0;
  }
}
.ui-gk-prompt {
  flex: 1;
  min-width: 0;
  margin: 0;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: calc(46.43 * var(--ui-gk-u));
  line-height: normal;
  color: var(--ui-gk-text);
  caret-color: var(--ui-gk-placeholder);
}
.ui-gk-prompt::placeholder {
  color: var(--ui-gk-placeholder);
  opacity: 1;
}
.ui-gk-prompt:placeholder-shown {
  caret-color: transparent;
}
.ui-gk .ui-gk-prompt:focus-visible {
  outline: none;
}
.ui-gk-keyboard {
  left: calc(312.5 * var(--ui-gk-u));
  top: calc(440 * var(--ui-gk-u));
  width: calc(1575 * var(--ui-gk-u));
  height: calc(634 * var(--ui-gk-u));
  border: calc(1.5 * var(--ui-gk-u)) solid var(--ui-gk-board-border);
  border-radius: calc(52 * var(--ui-gk-u));
  background: var(--ui-gk-board-bg);
  -webkit-backdrop-filter: blur(calc(24 * var(--ui-gk-u)));
  backdrop-filter: blur(calc(24 * var(--ui-gk-u)));
  box-shadow:
    inset 0 0 calc(30 * var(--ui-gk-u)) var(--ui-gk-board-inner),
    0 calc(22 * var(--ui-gk-u)) calc(48 * var(--ui-gk-u))
      var(--ui-gk-board-shadow);
}
.ui-gk-key {
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: calc(20 * var(--ui-gk-u));
  background-color: var(--ui-gk-key-bg);
  box-shadow:
    var(--ui-gk-key-edge),
    0 calc(1.5 * var(--ui-gk-u)) 0 var(--ui-gk-key-drop),
    inset 0 0 calc(12 * var(--ui-gk-u)) var(--ui-gk-key-inner);
  font-size: calc(44 * var(--ui-gk-u));
  line-height: 1;
  color: var(--ui-gk-key-text);
  user-select: none;
  transition:
    transform 0.28s ease-out,
    background-color 0.28s ease-out,
    color 0.28s ease-out,
    box-shadow 0.28s ease-out;
}
.ui-gk-key--mod {
  font-size: calc(36 * var(--ui-gk-u));
}
.ui-gk-key--sm {
  font-size: calc(26 * var(--ui-gk-u));
}
.ui-gk-key--fkey {
  font-size: calc(22 * var(--ui-gk-u));
  border-radius: calc(14 * var(--ui-gk-u));
}
.ui-gk-key--arrow {
  font-size: calc(28 * var(--ui-gk-u));
}
.ui-gk-key--half {
  font-size: calc(22 * var(--ui-gk-u));
  border-radius: calc(12 * var(--ui-gk-u));
}
.ui-gk-key--touchid {
  border-radius: calc(14 * var(--ui-gk-u));
}
.ui-gk-key--touchid::after {
  content: "";
  width: calc(30 * var(--ui-gk-u));
  height: calc(30 * var(--ui-gk-u));
  border: calc(2 * var(--ui-gk-u)) solid var(--ui-gk-touchid);
  border-radius: 50%;
}
.ui-gk-key[data-down] {
  transform: translateY(calc(3 * var(--ui-gk-u))) scale(0.9);
  background-color: var(--ui-gk-key-down-bg);
  color: var(--ui-gk-key-down-text);
  box-shadow:
    inset 0 0 0 transparent,
    0 0 0 rgba(0, 0, 0, 0),
    inset 0 calc(2 * var(--ui-gk-u)) calc(6 * var(--ui-gk-u))
      var(--ui-gk-key-down-inner);
  transition-duration: 0.06s;
}
.ui-gk:not([data-in]) .ui-gk-composer,
.ui-gk:not([data-in]) .ui-gk-keyboard {
  opacity: 0;
}
.ui-gk[data-in] .ui-gk-composer {
  animation: ui-gk-rise 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) 0.15s backwards;
}
.ui-gk[data-in] .ui-gk-keyboard {
  animation: ui-gk-rise 0.9s cubic-bezier(0.2, 0.8, 0.2, 1) 0.45s backwards;
}
@keyframes ui-gk-rise {
  from {
    opacity: 0;
    transform: translateY(calc(60 * var(--ui-gk-u)));
  }
  to {
    opacity: 1;
    transform: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-gk {
  --ui-gk-bg: #111113;
  --ui-gk-floor-light: 0.3;
  --ui-gk-ring: 0.55;
  --ui-gk-input-border: rgba(255, 255, 255, 0.14);
  --ui-gk-input-bg: rgba(24, 24, 27, 0.88);
  --ui-gk-input-inner: rgba(255, 255, 255, 0.04);
  --ui-gk-caret: rgba(255, 255, 255, 0.3);
  --ui-gk-text: #e4e4e7;
  --ui-gk-placeholder: #737378;
  --ui-gk-board-border: rgba(255, 255, 255, 0.08);
  --ui-gk-board-bg: rgba(14, 14, 16, 0.5);
  --ui-gk-board-inner: rgba(255, 255, 255, 0.03);
  --ui-gk-board-shadow: rgba(0, 0, 0, 0.5);
  --ui-gk-key-bg: rgba(32, 32, 35, 0.86);
  --ui-gk-key-edge: inset 0 calc(1.5 * var(--ui-gk-u)) 0
    rgba(255, 255, 255, 0.08);
  --ui-gk-key-drop: rgba(0, 0, 0, 0.6);
  --ui-gk-key-inner: rgba(0, 0, 0, 0.18);
  --ui-gk-key-text: rgba(235, 235, 245, 0.6);
  --ui-gk-touchid: rgba(235, 235, 245, 0.22);
  --ui-gk-key-down-bg: rgba(56, 56, 62, 0.97);
  --ui-gk-key-down-text: rgba(255, 255, 255, 0.95);
  --ui-gk-key-down-inner: rgba(0, 0, 0, 0.4);
}
.ui-gk[data-paused] * {
  animation-play-state: paused;
}
@media (prefers-reduced-motion: reduce) {
  .ui-gk-bleed,
  .ui-gk-glow::after,
  .ui-gk-glow-mid,
  .ui-gk-caret,
  .ui-gk[data-in] .ui-gk-composer,
  .ui-gk[data-in] .ui-gk-keyboard {
    animation: none;
  }
  .ui-gk-key {
    transition: none;
  }
}

.glow-keyboard-demo {
  width: 100%;
}
.stage .glow-keyboard-demo,
.card__preview .glow-keyboard-demo {
  position: absolute;
  inset: 0;
  overflow: hidden;
  container-type: size;
}
.stage .glow-keyboard-demo .ui-gk,
.card__preview .glow-keyboard-demo .ui-gk {
  width: max(100cqw, 183.333cqh);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
@media (width<=640px) {
  .stage:has(.glow-keyboard-demo) {
    height: 280px;
    min-height: 0;
  }
}
`;export{n as default};
