const n=`.ui-gf {
  position: relative;
  container-type: inline-size;
  overflow: hidden;
  isolation: isolate;
  background: var(--ui-gf-bg, #fafafa);
}
.ui-gf-layer {
  position: absolute;
  pointer-events: none;
}
.ui-gf-layer--color {
  left: calc(-290 * 100cqw / 2200);
  bottom: calc(-484.5 * 100cqw / 2200);
  width: calc(2864.5 * 100cqw / 2200);
  height: calc(931.5 * 100cqw / 2200);
}
.ui-gf-layer--light {
  left: calc(-65 * 100cqw / 2200);
  bottom: calc(-507 * 100cqw / 2200);
  width: calc(2414 * 100cqw / 2200);
  height: calc(785 * 100cqw / 2200);
  mix-blend-mode: plus-lighter;
}
.ui-gf-bleed {
  position: absolute;
  inset: -31.27% -10.17%;
  transform-origin: 50% 70%;
  will-change: transform;
}
.ui-gf-bleed svg {
  position: absolute;
  top: 0;
  left: 0;
  display: block;
  width: 25%;
  height: 25%;
  overflow: visible;
  transform: scale(4);
  transform-origin: 0 0;
  will-change: transform;
}
.ui-gf-layer--color svg {
  filter: blur(calc(calc(145.65 * 100cqw / 2200) / 4));
}
.ui-gf-layer--light svg {
  filter: blur(calc(calc(122.74 * 100cqw / 2200) / 4));
}
.ui-gf-layer--color .ui-gf-bleed {
  animation: ui-gf-drift-color 2.5s ease-in-out infinite;
}
.ui-gf-layer--light .ui-gf-bleed {
  animation: ui-gf-drift-light 2.5s ease-in-out infinite;
}
@keyframes ui-gf-drift-color {
  0%,
  100% {
    transform: translate(0, 0) scale(1, 1);
  }
  33% {
    transform: translate(calc(-120 * 100cqw / 2200), calc(-20 * 100cqw / 2200))
      scale(1.05, 1.08);
  }
  66% {
    transform: translate(calc(100 * 100cqw / 2200), calc(12 * 100cqw / 2200))
      scale(0.98, 0.96);
  }
}
@keyframes ui-gf-drift-light {
  0%,
  100% {
    transform: translate(0, 0) scale(1, 1);
  }
  33% {
    transform: translate(calc(-100 * 100cqw / 2200), calc(-10 * 100cqw / 2200))
      scale(1.03, 1);
  }
  66% {
    transform: translate(calc(85 * 100cqw / 2200), calc(10 * 100cqw / 2200))
      scale(0.98, 0.94);
  }
}
.ui-gf[data-paused] .ui-gf-bleed {
  animation-play-state: paused;
}
.ui-gf-content {
  position: relative;
  z-index: 1;
  height: 100%;
}
:where(.dark, [data-theme="dark"]) .ui-gf {
  --ui-gf-bg: #111113;
}
@media (prefers-reduced-motion: reduce) {
  .ui-gf-bleed {
    animation: none;
  }
}

.gradient-floor-demo {
  width: 100%;
}
.gradient-floor-demo__panel {
  border-radius: 20px;
  height: 360px;
  box-shadow:
    inset 0 0 0 1px #e5e5e5,
    0 1px 2px #0000000a;
}
.card__preview .gradient-floor-demo {
  position: absolute;
  inset: 0;
}
.card__preview .gradient-floor-demo__panel {
  height: 100%;
  box-shadow: none;
  border-radius: 0;
}
:where(.dark, [data-theme="dark"]) .gradient-floor-demo__panel {
  box-shadow: inset 0 0 0 1px #ffffff14;
}
:where(.dark, [data-theme="dark"]) .card__preview .gradient-floor-demo__panel {
  box-shadow: none;
}
`;export{n as default};
