const n=`.ui-gt {
  --ui-gt-c1: #dd0674;
  --ui-gt-c2: #5e3ee0;
  --ui-gt-c3: #ff5fae;
  --ui-gt-c4: #7c5cff;
  --ui-gt-sweep: 1100ms;
  position: relative;
  display: inline-block;
  margin: 0;
  font: inherit;
  letter-spacing: inherit;
}
.ui-gt__base {
  color: inherit;
  transition: color 240ms ease;
}
.ui-gt__fill {
  position: absolute;
  inset: 0;
  pointer-events: none;
  user-select: none;
  color: transparent;
  -webkit-text-fill-color: transparent;
  background-image:
    radial-gradient(closest-side, var(--ui-gt-c3), transparent),
    radial-gradient(closest-side, var(--ui-gt-c4), transparent),
    radial-gradient(closest-side, var(--ui-gt-c1), transparent),
    linear-gradient(100deg, var(--ui-gt-c1) 10%, var(--ui-gt-c2) 90%);
  background-size:
    70% 170%,
    80% 190%,
    60% 160%,
    100% 100%;
  background-repeat: no-repeat;
  background-position:
    -20% 30%,
    120% 70%,
    50% -40%,
    0 0;
  -webkit-background-clip: text;
  background-clip: text;
  clip-path: inset(-0.25em -0.25em -0.25em -0.25em);
  animation: ui-gt-flow var(--ui-gt-speed) ease-in-out infinite;
}
.ui-gt[data-sweep][data-state="idle"] .ui-gt__fill {
  clip-path: inset(-0.25em 100% -0.25em -0.25em);
}
.ui-gt[data-sweep] .ui-gt__fill {
  transition: clip-path var(--ui-gt-sweep) cubic-bezier(0.65, 0, 0.25, 1);
}
.ui-gt[data-state="in"] .ui-gt__base {
  color: transparent;
}
.ui-gt[data-sweep][data-state="in"] .ui-gt__base {
  transition-delay: calc(var(--ui-gt-sweep) - 200ms);
}
@keyframes ui-gt-flow {
  0%,
  100% {
    background-position:
      -20% 30%,
      120% 70%,
      50% -40%,
      0 0;
  }
  25% {
    background-position:
      40% 110%,
      60% -10%,
      110% 60%,
      0 0;
  }
  50% {
    background-position:
      120% 40%,
      -20% 40%,
      40% 140%,
      0 0;
  }
  75% {
    background-position:
      60% -30%,
      30% 120%,
      -10% 30%,
      0 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-gt .ui-gt__fill,
  .ui-gt[data-sweep][data-state="idle"] .ui-gt__fill {
    animation: none;
    transition: none;
    clip-path: inset(-0.25em -0.25em -0.25em -0.25em);
  }
  .ui-gt .ui-gt__base,
  .ui-gt[data-sweep] .ui-gt__base {
    color: transparent;
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-gt {
  --ui-gt-c1: #f472b6;
  --ui-gt-c2: #a78bfa;
  --ui-gt-c3: #f9a8d4;
  --ui-gt-c4: #c4b5fd;
}

.gradient-text-demo {
  text-align: center;
  justify-items: center;
  gap: 28px;
  width: 100%;
  font-family: Inter, system-ui, sans-serif;
  display: grid;
}
.gradient-text-demo__title {
  letter-spacing: -0.035em;
  color: #171717;
  text-wrap: balance;
  max-width: 12em;
  margin: 0;
  font-size: clamp(34px, 6vw, 56px);
  font-weight: 600;
  line-height: 1.08;
}
.gradient-text-demo__replay {
  color: #171717;
  cursor: pointer;
  background: #fff;
  border: 0;
  border-radius: 9px;
  height: 30px;
  padding: 0 12px;
  font:
    500 12.5px/1 Inter,
    system-ui,
    sans-serif;
  box-shadow: 0 0 0 1px #e5e5e5;
}
.gradient-text-demo__replay:hover {
  background: #fafafa;
}
.card__preview .gradient-text-demo {
  place-content: center;
  padding: 0 24px;
  position: absolute;
  inset: 0;
}
.card__preview .gradient-text-demo__title {
  font-size: 30px;
}
.card__preview .gradient-text-demo__replay {
  display: none;
}
:where(.dark, [data-theme="dark"]) .gradient-text-demo__title {
  color: #ededed;
}
:where(.dark, [data-theme="dark"]) .gradient-text-demo__replay {
  color: #ededed;
  background: #232326;
  box-shadow: 0 0 0 1px #ffffff14;
}
:where(.dark, [data-theme="dark"]) .gradient-text-demo__replay:hover {
  background: #2a2a2e;
}
`;export{n as default};
