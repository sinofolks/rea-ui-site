const n=`.ui-df {
  --ui-df-ink: #171717;
  --ui-df-text: #525252;
  --ui-df-muted: #626873;
  --ui-df-tray: #f0f0f0;
  --ui-df-line: #ececec;
  --ui-df-bg: #ffffff;
  --ui-df-soft: #f5f5f5;
  --ui-df-add: rgba(34, 160, 90, 0.1);
  --ui-df-add-strong: rgba(34, 160, 90, 0.18);
  --ui-df-add-ink: #18794e;
  --ui-df-del: rgba(220, 60, 60, 0.08);
  --ui-df-del-strong: rgba(220, 60, 60, 0.15);
  --ui-df-del-ink: #b42318;
  --ui-df-strike: rgba(180, 35, 24, 0.55);
  --ui-df-ok: #1f8a4c;
  --ui-df-pop: #171717;
  --ui-df-pop-ink: #ffffff;
  --ui-df-pop-soft: rgba(255, 255, 255, 0.14);
  --ui-df-pop-kbd: rgba(255, 255, 255, 0.55);
  --ui-df-primary: #171717;
  --ui-df-primary-ink: #ffffff;
  --ui-df-focus: rgba(0, 96, 226, 0.7);
  --ui-df-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-df-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  display: grid;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-df-tray);
  color: var(--ui-df-text);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  -webkit-font-smoothing: antialiased;
  text-align: left;
}
.ui-df *,
.ui-df *::before,
.ui-df *::after {
  box-sizing: border-box;
}
.ui-df__label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  padding: 6px 8px 4px;
  color: var(--ui-df-muted);
  font-size: 12.5px;
  line-height: 1.3;
  letter-spacing: -0.003em;
}
.ui-df__label span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-df__label svg {
  flex: none;
  width: 13px;
  height: 13px;
  fill: currentColor;
}
.ui-df__card {
  position: relative;
  min-width: 0;
  border-radius: 16px;
  background: var(--ui-df-bg);
  box-shadow:
    0 0 0 1px var(--ui-df-line),
    var(--ui-df-shadow);
}
.ui-df__head {
  padding: 10px 10px 10px 16px;
  border-bottom: 1px solid var(--ui-df-line);
}
.ui-df__bar {
  display: grid;
}
.ui-df__layer {
  grid-area: 1 / 1;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-width: 0;
  opacity: 0;
  visibility: hidden;
  transform: translateY(4px);
  filter: blur(2px);
  transition:
    opacity 260ms ease,
    transform 420ms var(--ui-df-ease),
    filter 260ms ease,
    visibility 0s 420ms;
}
.ui-df__layer[data-show] {
  opacity: 1;
  visibility: visible;
  transform: none;
  filter: none;
  transition:
    opacity 320ms ease 80ms,
    transform 460ms var(--ui-df-ease) 80ms,
    filter 320ms ease 80ms,
    visibility 0s;
}
.ui-df__card {
  container: ui-df-card / inline-size;
}
@container ui-df-card (max-width: 400px) {
  .ui-df__word {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
  }
}
.ui-df__count {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  color: var(--ui-df-ink);
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  letter-spacing: -0.006em;
  white-space: nowrap;
}
.ui-df__num {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 999px;
  background: var(--ui-df-add);
  color: var(--ui-df-add-ink);
  font-size: 11.5px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.ui-df__ok {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-df-ok);
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
}
.ui-df[data-done] .ui-df__ok {
  animation: ui-df-draw 420ms var(--ui-df-ease) 220ms forwards;
}
.ui-df__actions {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-left: auto;
}
.ui-df__nav {
  display: inline-flex;
  gap: 2px;
  margin-right: 2px;
}
.ui-df__btn,
.ui-df__icon {
  appearance: none;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 30px;
  margin: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-df-ink);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  letter-spacing: -0.006em;
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 160ms ease,
    transform 160ms var(--ui-df-ease);
  -webkit-tap-highlight-color: transparent;
}
.ui-df__btn {
  padding: 0 11px;
  box-shadow: inset 0 0 0 1px var(--ui-df-line);
}
.ui-df__icon {
  width: 28px;
  color: var(--ui-df-muted);
}
.ui-df__btn svg,
.ui-df__icon svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-df__btn:hover:not(:disabled) {
  background: var(--ui-df-soft);
}
.ui-df__icon:hover:not(:disabled) {
  background: var(--ui-df-soft);
  color: var(--ui-df-ink);
}
.ui-df__btn--primary {
  background: var(--ui-df-primary);
  color: var(--ui-df-primary-ink);
  box-shadow: none;
}
.ui-df__btn--primary:hover:not(:disabled) {
  background: var(--ui-df-primary);
  opacity: 0.88;
}
.ui-df__btn:active:not(:disabled),
.ui-df__icon:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-df__btn:disabled,
.ui-df__icon:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-df__btn:focus-visible,
.ui-df__icon:focus-visible {
  outline: 2px solid var(--ui-df-focus);
  outline-offset: 2px;
}
.ui-df__body {
  padding: 16px 18px 18px;
}
.ui-df__text {
  margin: 0;
  color: var(--ui-df-text);
  font-size: 15px;
  line-height: 1.65;
  letter-spacing: -0.006em;
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-df__chg {
  border-radius: 4px;
  cursor: pointer;
  scroll-margin: 64px 0 24px;
}
.ui-df__chg:not([data-state="pending"]) {
  cursor: auto;
}
.ui-df__chg:focus {
  outline: none;
}
.ui-df__chg:focus-visible {
  outline: 2px solid var(--ui-df-focus);
  outline-offset: 2px;
}
.ui-df__del,
.ui-df__ins {
  padding: 1px 2px;
  border-radius: 4px;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  font-size: 1em;
  transition:
    background-color 360ms ease,
    color 360ms ease,
    text-decoration-color 300ms ease,
    font-size 460ms var(--ui-df-ease),
    padding 460ms var(--ui-df-ease),
    margin 460ms var(--ui-df-ease),
    opacity 300ms ease;
}
.ui-df__del {
  background: var(--ui-df-del);
  color: var(--ui-df-del-ink);
  text-decoration: line-through;
  text-decoration-color: var(--ui-df-strike);
  text-decoration-thickness: 1.2px;
}
.ui-df__ins {
  background: var(--ui-df-add);
  color: var(--ui-df-add-ink);
  text-decoration: none;
}
.ui-df__del + .ui-df__ins {
  margin-left: 3px;
}
.ui-df__chg[data-active] .ui-df__del {
  background: var(--ui-df-del-strong);
}
.ui-df__chg[data-active] .ui-df__ins {
  background: var(--ui-df-add-strong);
}
.ui-df__chg[data-state="accepted"] .ui-df__del,
.ui-df__chg[data-state="rejected"] .ui-df__ins {
  font-size: 0;
  padding: 0;
  margin: 0;
  opacity: 0;
}
.ui-df__chg[data-state="accepted"] .ui-df__ins,
.ui-df__chg[data-state="rejected"] .ui-df__del {
  padding: 0;
  margin: 0;
  background: transparent;
  color: inherit;
  text-decoration-color: transparent;
}
.ui-df__pop {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 3px;
  border-radius: 10px;
  background: var(--ui-df-pop);
  color: var(--ui-df-pop-ink);
  box-shadow:
    0 6px 20px -6px rgba(0, 0, 0, 0.35),
    0 1px 2px rgba(0, 0, 0, 0.2);
  opacity: 0;
  visibility: hidden;
  transform: translateY(4px) scale(0.96);
  transform-origin: 50% 100%;
  pointer-events: none;
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-df-ease),
    left 320ms var(--ui-df-ease),
    top 320ms var(--ui-df-ease),
    visibility 0s 260ms;
}
.ui-df__pop[data-open] {
  opacity: 1;
  visibility: visible;
  transform: none;
  pointer-events: auto;
  transition:
    opacity 180ms ease,
    transform 300ms var(--ui-df-ease),
    left 320ms var(--ui-df-ease),
    top 320ms var(--ui-df-ease),
    visibility 0s;
}
.ui-df__pop[data-below] {
  transform-origin: 50% 0;
}
.ui-df__pop[data-below]:not([data-open]) {
  transform: translateY(-4px) scale(0.96);
}
.ui-df__pop[data-snap] {
  transition-property: opacity, transform, visibility;
}
.ui-df__pbtn {
  appearance: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin: 0;
  padding: 0 8px 0 7px;
  border: 0;
  border-radius: 7px;
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: background-color 140ms ease;
}
.ui-df__pbtn:hover {
  background: var(--ui-df-pop-soft);
}
.ui-df__pbtn svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-df__pbtn kbd {
  display: inline-grid;
  place-items: center;
  min-width: 17px;
  height: 17px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-df-pop-soft);
  color: var(--ui-df-pop-kbd);
  font: inherit;
  font-size: 10.5px;
  font-weight: 500;
}
.ui-df__sep {
  width: 1px;
  height: 16px;
  background: var(--ui-df-pop-soft);
}
.ui-df__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@keyframes ui-df-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@media (max-width: 400px) {
  .ui-df__nav {
    display: none;
  }
  .ui-df__head {
    padding-left: 14px;
  }
  .ui-df__label {
    padding-left: 6px;
  }
  .ui-df__body {
    padding: 14px 14px 16px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-df__pbtn kbd {
    display: none;
  }
  .ui-df__pbtn {
    height: 34px;
    padding: 0 11px 0 9px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-df *,
  .ui-df *::before,
  .ui-df *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
  .ui-df__layer {
    filter: none;
    transform: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-df {
  --ui-df-ink: #ededed;
  --ui-df-text: #b4b4b8;
  --ui-df-muted: #8b8b92;
  --ui-df-tray: #111113;
  --ui-df-line: #2a2a2e;
  --ui-df-bg: #19191b;
  --ui-df-soft: #232326;
  --ui-df-add: rgba(60, 200, 120, 0.13);
  --ui-df-add-strong: rgba(60, 200, 120, 0.22);
  --ui-df-add-ink: #6ee7a8;
  --ui-df-del: rgba(240, 90, 90, 0.12);
  --ui-df-del-strong: rgba(240, 90, 90, 0.2);
  --ui-df-del-ink: #ff8a80;
  --ui-df-strike: rgba(255, 138, 128, 0.6);
  --ui-df-ok: #5fd68f;
  --ui-df-pop: #f4f4f5;
  --ui-df-pop-ink: #171717;
  --ui-df-pop-soft: rgba(0, 0, 0, 0.08);
  --ui-df-pop-kbd: rgba(0, 0, 0, 0.5);
  --ui-df-primary: #ededed;
  --ui-df-primary-ink: #19191b;
  --ui-df-focus: rgba(77, 141, 255, 0.8);
  --ui-df-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
}
`;export{n as default};
