const n=`.ui-dfc {
  --ui-dfc-card: #ffffff;
  --ui-dfc-ink: rgba(0, 0, 0, 0.88);
  --ui-dfc-strong: #000000;
  --ui-dfc-text: rgba(0, 0, 0, 0.65);
  --ui-dfc-muted: rgba(0, 0, 0, 0.65);
  --ui-dfc-faint: rgba(0, 0, 0, 0.27);
  --ui-dfc-icon: rgba(0, 0, 0, 0.65);
  --ui-dfc-line: rgba(0, 0, 0, 0.06);
  --ui-dfc-fill: rgba(0, 0, 0, 0.06);
  --ui-dfc-wash: rgba(0, 0, 0, 0.03);
  --ui-dfc-accent: rgba(0, 96, 226, 0.765);
  --ui-dfc-add: rgba(26, 154, 82, 0.1);
  --ui-dfc-add-strong: rgba(26, 154, 82, 0.16);
  --ui-dfc-del: rgba(229, 72, 77, 0.08);
  --ui-dfc-del-strong: rgba(229, 72, 77, 0.14);
  --ui-dfc-del-ink: rgba(0, 0, 0, 0.65);
  --ui-dfc-strike: rgba(229, 72, 77, 0.6);
  --ui-dfc-ok: #1a9a52;
  --ui-dfc-primary: rgba(0, 0, 0, 0.88);
  --ui-dfc-primary-ink: #fcfcfc;
  --ui-dfc-primary-kbd: rgba(255, 255, 255, 0.16);
  --ui-dfc-primary-kbd-ink: rgba(255, 255, 255, 0.66);
  --ui-dfc-secondary-hover: #fafafa;
  --ui-dfc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dfc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dfc-focus: rgba(0, 96, 226, 0.7);
  --ui-dfc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  display: grid;
  width: 100%;
  min-width: 0;
  color: var(--ui-dfc-ink);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  -webkit-font-smoothing: antialiased;
  text-align: left;
}
.ui-dfc *,
.ui-dfc *::before,
.ui-dfc *::after {
  box-sizing: border-box;
}
:where(.ui-dfc) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-dfc) svg {
  display: block;
  flex: none;
}
.ui-dfc__card {
  position: relative;
  min-width: 0;
  border-radius: 10px;
  background: var(--ui-dfc-card);
  box-shadow: var(--ui-dfc-shadow);
  container: ui-dfc-card / inline-size;
}
.ui-dfc__label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  margin: 0 0 8px;
  color: var(--ui-dfc-text);
  font-size: 12px;
  line-height: 16px;
}
.ui-dfc__label span {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-dfc__label svg {
  width: 16px;
  height: 16px;
  fill: var(--ui-dfc-accent);
}
.ui-dfc__body {
  padding: 16px 16px 18px;
}
.ui-dfc__text {
  margin: 0;
  color: var(--ui-dfc-ink);
  font-size: 13px;
  line-height: 22px;
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-dfc__chg {
  border-radius: 4px;
  cursor: pointer;
  scroll-margin: 64px 0 72px;
}
.ui-dfc__chg:not([data-state="pending"]) {
  cursor: auto;
}
.ui-dfc__chg:focus {
  outline: none;
}
.ui-dfc__chg:focus-visible {
  outline: 2px solid var(--ui-dfc-focus);
  outline-offset: 2px;
}
.ui-dfc__del,
.ui-dfc__ins {
  padding: 1px 2px;
  border-radius: 4px;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  font-size: 1em;
  transition:
    background-color 360ms ease,
    color 360ms ease,
    text-decoration-color 300ms ease,
    font-size 460ms var(--ui-dfc-ease),
    padding 460ms var(--ui-dfc-ease),
    margin 460ms var(--ui-dfc-ease),
    opacity 300ms ease;
}
.ui-dfc__del {
  background: var(--ui-dfc-del);
  color: var(--ui-dfc-del-ink);
  text-decoration: line-through;
  text-decoration-color: var(--ui-dfc-strike);
  text-decoration-thickness: 1px;
}
.ui-dfc__ins {
  background: var(--ui-dfc-add);
  color: var(--ui-dfc-ink);
  text-decoration: none;
}
.ui-dfc__del + .ui-dfc__ins {
  margin-left: 3px;
}
.ui-dfc__chg[data-active] .ui-dfc__del {
  background: var(--ui-dfc-del-strong);
}
.ui-dfc__chg[data-active] .ui-dfc__ins {
  background: var(--ui-dfc-add-strong);
}
.ui-dfc__chg[data-state="accepted"] .ui-dfc__del,
.ui-dfc__chg[data-state="rejected"] .ui-dfc__ins {
  font-size: 0;
  padding: 0;
  margin: 0;
  opacity: 0;
}
.ui-dfc__chg[data-state="accepted"] .ui-dfc__ins,
.ui-dfc__chg[data-state="rejected"] .ui-dfc__del {
  padding: 0;
  margin: 0;
  background: transparent;
  color: inherit;
  text-decoration-color: transparent;
}
.ui-dfc__foot {
  display: grid;
  align-items: center;
  min-height: 44px;
  padding: 8px 8px 8px 16px;
  border-top: 0.5px solid var(--ui-dfc-line);
}
.ui-dfc__bar {
  display: grid;
}
.ui-dfc__layer {
  grid-area: 1 / 1;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-width: 0;
  opacity: 0;
  visibility: hidden;
  transform: translateY(4px);
  filter: blur(2px);
  transition:
    opacity 260ms ease,
    transform 420ms var(--ui-dfc-ease),
    filter 260ms ease,
    visibility 0s 420ms;
}
.ui-dfc__layer[data-show] {
  opacity: 1;
  visibility: visible;
  transform: none;
  filter: none;
  transition:
    opacity 320ms ease 80ms,
    transform 460ms var(--ui-dfc-ease) 80ms,
    filter 320ms ease 80ms,
    visibility 0s;
}
@container ui-dfc-card (max-width: 400px) {
  .ui-dfc__word {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip: rect(0 0 0 0);
    white-space: nowrap;
  }
}
.ui-dfc__count {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: var(--ui-dfc-text);
  font-size: 13px;
  line-height: 20px;
  white-space: nowrap;
}
.ui-dfc__count--done {
  gap: 6px;
  color: var(--ui-dfc-ink);
  font-weight: 500;
}
.ui-dfc__num {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-dfc-fill);
  color: var(--ui-dfc-ink);
  font-size: 12px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-dfc__ok {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-dfc-ok);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
}
.ui-dfc[data-done] .ui-dfc__ok {
  animation: ui-dfc-draw 420ms var(--ui-dfc-ease) 220ms forwards;
}
.ui-dfc__actions {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  margin-left: auto;
}
.ui-dfc__nav {
  display: inline-flex;
  gap: 2px;
}
.ui-dfc__btn,
.ui-dfc__icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 28px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 160ms ease,
    transform 160ms var(--ui-dfc-ease);
}
.ui-dfc__btn {
  padding: 0 10px;
  background: var(--ui-dfc-card);
  box-shadow: var(--ui-dfc-shadow);
  color: var(--ui-dfc-strong);
}
.ui-dfc__btn:has(svg) {
  padding: 0 10px 0 8px;
}
.ui-dfc__icon {
  width: 28px;
  color: var(--ui-dfc-icon);
}
.ui-dfc__btn svg,
.ui-dfc__icon svg,
.ui-dfc__pbtn svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-dfc__btn svg {
  color: var(--ui-dfc-icon);
}
.ui-dfc__btn:hover:not(:disabled) {
  background: var(--ui-dfc-secondary-hover);
}
.ui-dfc__icon:hover:not(:disabled) {
  background: var(--ui-dfc-wash);
  color: var(--ui-dfc-ink);
}
.ui-dfc__btn--primary {
  background: var(--ui-dfc-primary);
  color: var(--ui-dfc-primary-ink);
  box-shadow: none;
}
.ui-dfc__btn--primary:hover:not(:disabled) {
  background: var(--ui-dfc-primary);
  opacity: 0.9;
}
.ui-dfc__btn:active:not(:disabled),
.ui-dfc__icon:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-dfc__btn:disabled,
.ui-dfc__icon:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-dfc__btn:focus-visible,
.ui-dfc__icon:focus-visible {
  outline: 2px solid var(--ui-dfc-focus);
  outline-offset: 2px;
}
.ui-dfc__pop {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-dfc-card);
  box-shadow: var(--ui-dfc-shadow-pop);
  opacity: 0;
  visibility: hidden;
  transform: translateY(4px) scale(0.96);
  transform-origin: 50% 100%;
  pointer-events: none;
  transition:
    opacity 160ms ease,
    transform 240ms var(--ui-dfc-ease),
    left 90ms ease-out,
    top 90ms ease-out,
    visibility 0s 240ms;
}
.ui-dfc__pop[data-open] {
  opacity: 1;
  visibility: visible;
  transform: none;
  pointer-events: auto;
  transition:
    opacity 160ms ease,
    transform 280ms var(--ui-dfc-ease),
    left 90ms ease-out,
    top 90ms ease-out,
    visibility 0s;
}
.ui-dfc__pop[data-below] {
  transform-origin: 50% 0;
}
.ui-dfc__pop[data-below]:not([data-open]) {
  transform: translateY(-4px) scale(0.96);
}
.ui-dfc__pop[data-snap] {
  transition-property: opacity, transform, visibility;
}
.ui-dfc__pbtn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 6px 0 8px;
  border-radius: 6px;
  background: var(--ui-dfc-card);
  box-shadow: var(--ui-dfc-shadow);
  color: var(--ui-dfc-strong);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    opacity 140ms ease;
}
.ui-dfc__pbtn svg {
  color: var(--ui-dfc-icon);
}
.ui-dfc__pbtn:hover {
  background: var(--ui-dfc-secondary-hover);
}
.ui-dfc__pbtn--primary {
  background: var(--ui-dfc-primary);
  box-shadow: none;
  color: var(--ui-dfc-primary-ink);
}
.ui-dfc__pbtn--primary svg {
  color: currentColor;
}
.ui-dfc__pbtn--primary:hover {
  background: var(--ui-dfc-primary);
  opacity: 0.9;
}
.ui-dfc__pbtn kbd {
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-dfc-fill);
  color: var(--ui-dfc-muted);
  font: inherit;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
}
.ui-dfc__pbtn--primary kbd {
  background: var(--ui-dfc-primary-kbd);
  color: var(--ui-dfc-primary-kbd-ink);
}
.ui-dfc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@keyframes ui-dfc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@container ui-dfc-card (max-width: 360px) {
  .ui-dfc__nav {
    display: none;
  }
  .ui-dfc__body {
    padding: 14px 14px 16px;
  }
  .ui-dfc__foot {
    padding-left: 14px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-dfc__pbtn kbd {
    display: none;
  }
  .ui-dfc__pbtn {
    height: 34px;
    padding: 0 12px 0 10px;
  }
  .ui-dfc__btn {
    height: 34px;
  }
  .ui-dfc__icon {
    width: 34px;
    height: 34px;
  }
  .ui-dfc__foot {
    min-height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dfc *,
  .ui-dfc *::before,
  .ui-dfc *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
  .ui-dfc__layer {
    filter: none;
    transform: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-dfc {
  --ui-dfc-card: #1c1c1e;
  --ui-dfc-ink: rgba(255, 255, 255, 0.9);
  --ui-dfc-strong: #ffffff;
  --ui-dfc-text: rgba(255, 255, 255, 0.62);
  --ui-dfc-muted: rgba(255, 255, 255, 0.46);
  --ui-dfc-faint: rgba(255, 255, 255, 0.3);
  --ui-dfc-icon: rgba(255, 255, 255, 0.5);
  --ui-dfc-line: rgba(255, 255, 255, 0.08);
  --ui-dfc-fill: rgba(255, 255, 255, 0.08);
  --ui-dfc-wash: rgba(255, 255, 255, 0.04);
  --ui-dfc-accent: #4d8dff;
  --ui-dfc-add: rgba(62, 194, 122, 0.14);
  --ui-dfc-add-strong: rgba(62, 194, 122, 0.22);
  --ui-dfc-del: rgba(240, 90, 90, 0.14);
  --ui-dfc-del-strong: rgba(240, 90, 90, 0.22);
  --ui-dfc-del-ink: rgba(255, 255, 255, 0.46);
  --ui-dfc-strike: rgba(255, 120, 120, 0.7);
  --ui-dfc-ok: #3ec27a;
  --ui-dfc-primary: rgba(255, 255, 255, 0.9);
  --ui-dfc-primary-ink: #1c1c1e;
  --ui-dfc-primary-kbd: rgba(0, 0, 0, 0.08);
  --ui-dfc-primary-kbd-ink: rgba(28, 28, 30, 0.6);
  --ui-dfc-secondary-hover: #232326;
  --ui-dfc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-dfc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-dfc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-dfc__pop {
  --ui-dfc-card: #232326;
  --ui-dfc-secondary-hover: #2a2a2d;
}
`;export{n as default};
