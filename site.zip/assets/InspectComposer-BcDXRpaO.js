const n=`.ui-icp {
  --ui-icp-blue: #4f8ff7;
  --ui-icp-red: #ff3b30;
  --ui-icp-hatch: rgba(79, 143, 247, 0.3);
  --ui-icp-dash: rgba(79, 143, 247, 0.85);
  --ui-icp-handle: #ffffff;
  position: relative;
  box-sizing: border-box;
  display: inline-block;
  padding: 168px 0 56px 64px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  text-align: left;
  -webkit-font-smoothing: antialiased;
  -webkit-mask-image:
    linear-gradient(90deg, #000 74%, transparent 100%),
    linear-gradient(180deg, #000 40%, transparent 82%);
  -webkit-mask-composite: source-in;
  mask-image:
    linear-gradient(90deg, #000 74%, transparent 100%),
    linear-gradient(180deg, #000 40%, transparent 82%);
  mask-composite: intersect;
}
.ui-icp[data-mirror] {
  padding: 168px 64px 56px 0;
}
.ui-icp *,
.ui-icp *::before,
.ui-icp *::after {
  box-sizing: border-box;
}
.ui-icp svg {
  display: block;
  flex: none;
}
.ui-icp__stage {
  position: relative;
  width: calc(320px + 10px);
  padding: 22px 0 0 10px;
  transform: perspective(1100px) rotateX(30deg) rotateY(-14deg) rotateZ(7deg);
  transform-origin: 0 0;
}
.ui-icp[data-mirror] .ui-icp__stage {
  padding: 22px 10px 0 0;
}
.ui-icp__main {
  position: relative;
}
.ui-icp__above {
  position: absolute;
  left: -56px;
  right: -24px;
  bottom: calc(100% + 6px - 40px);
  padding: 0 40px 40px;
  -webkit-mask-image: linear-gradient(180deg, transparent 15%, #000 85%);
  mask-image: linear-gradient(180deg, transparent 15%, #000 85%);
}
.ui-icp {
  --ui-icp-card: #ffffff;
  --ui-icp-tray: #f5f5f5;
  --ui-icp-hint: rgba(0, 0, 0, 0.36);
  --ui-icp-icon: rgba(0, 0, 0, 0.447);
  --ui-icp-muted: rgba(0, 0, 0, 0.45);
  --ui-icp-faint: rgba(0, 0, 0, 0.27);
  --ui-icp-fill: rgba(0, 0, 0, 0.06);
  --ui-icp-line: rgba(0, 0, 0, 0.06);
  --ui-icp-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  color: var(--ui-icp-muted);
}
.ui-icp__body {
  position: relative;
  width: 320px;
  border-radius: 16px;
  background: var(--ui-icp-tray);
  box-shadow: var(--ui-icp-shadow);
}
.ui-icp__body[data-main] {
  box-shadow:
    var(--ui-icp-shadow),
    0 18px 40px -10px rgba(0, 0, 0, 0.12),
    0 40px 80px -24px rgba(0, 0, 0, 0.1);
}
.ui-icp__write {
  position: relative;
  padding: 14px 10px 10px;
  border-radius: 16px;
  background: var(--ui-icp-card);
  box-shadow:
    0 0 0 0.5px var(--ui-icp-line),
    0 1px 2px 0 rgba(0, 0, 0, 0.04);
}
.ui-icp__field {
  padding: 0 4px;
}
.ui-icp__message {
  display: block;
  height: 40px;
  overflow: hidden;
  color: var(--ui-icp-hint);
}
.ui-icp__tools {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-top: 14px;
}
.ui-icp__group {
  display: flex;
  align-items: center;
  gap: 4px;
}
.ui-icp__icon {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  color: var(--ui-icp-icon);
}
.ui-icp__icon svg {
  width: 16px;
  height: 16px;
}
.ui-icp__icon svg:not([fill="none"]) {
  fill: currentColor;
}
.ui-icp__approval {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 8px;
  white-space: nowrap;
}
.ui-icp__approval-icon {
  width: 16px;
  height: 16px;
  color: var(--ui-icp-icon);
}
.ui-icp__approval-icon svg,
.ui-icp__chevron svg {
  width: 100%;
  height: 100%;
}
.ui-icp__chevron {
  width: 14px;
  height: 14px;
  margin-left: -2px;
  color: var(--ui-icp-faint);
}
.ui-icp__send {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-left: 2px;
  border-radius: 999px;
  background: var(--ui-icp-fill);
  color: var(--ui-icp-faint);
}
.ui-icp__send svg {
  width: 16px;
  height: 16px;
}
.ui-icp__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 36px;
  padding: 0 6px;
}
.ui-icp__row {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 26px;
  padding: 0 8px 0 7px;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
}
.ui-icp__row--apps {
  gap: 10px;
}
.ui-icp__folder {
  width: 16px;
  height: 16px;
}
.ui-icp__folder svg {
  width: 100%;
  height: 100%;
}
.ui-icp__logos {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ui-icp__logos svg {
  width: 13px;
  height: 13px;
}
:where(.dark, [data-theme="dark"]) .ui-icp {
  --ui-icp-card: #1c1c1f;
  --ui-icp-tray: #141416;
  --ui-icp-hint: rgba(255, 255, 255, 0.38);
  --ui-icp-icon: rgba(255, 255, 255, 0.55);
  --ui-icp-muted: rgba(255, 255, 255, 0.5);
  --ui-icp-faint: rgba(255, 255, 255, 0.3);
  --ui-icp-fill: rgba(255, 255, 255, 0.08);
  --ui-icp-line: rgba(255, 255, 255, 0.08);
  --ui-icp-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px rgba(0, 0, 0, 0.4);
}
.ui-icp__marks {
  position: absolute;
  z-index: 2;
  left: var(--x);
  top: var(--y);
  width: var(--w);
  height: var(--h);
  pointer-events: none;
}
.ui-icp__select {
  position: absolute;
  inset: 0;
}
.ui-icp__select > *,
.ui-icp__frame > * {
  opacity: 0;
  transform: scale(0.94);
  transition:
    opacity 160ms ease,
    transform 160ms ease;
}
.ui-icp__select[data-shown] > *,
.ui-icp__select[data-shown] .ui-icp__frame > * {
  opacity: 1;
  transform: none;
  transition:
    opacity 220ms ease var(--d, 0ms),
    transform 260ms cubic-bezier(0.22, 1, 0.36, 1) var(--d, 0ms);
}
.ui-icp__select > .ui-icp__frame {
  opacity: 1;
  transform: none;
  transition: none;
}
.ui-icp__select > .ui-icp__cursor {
  transform: translate(6px, 6px);
  --d: 0ms;
}
.ui-icp__select[data-shown] > .ui-icp__cursor {
  transform: none;
}
.ui-icp__select > .ui-icp__guide {
  transform: scaleY(0);
  transform-origin: 50% 0;
  --d: 280ms;
}
.ui-icp__select[data-shown] > .ui-icp__guide {
  transform: none;
}
.ui-icp__select[data-other] > .ui-icp__guide {
  -webkit-mask-image: linear-gradient(180deg, transparent 10%, #000 75%);
  mask-image: linear-gradient(180deg, transparent 10%, #000 75%);
}
.ui-icp__box {
  --d: 90ms;
}
.ui-icp__handle {
  --d: 160ms;
}
.ui-icp__tag {
  --d: 200ms;
}
.ui-icp__frame > .ui-icp__badge {
  --d: 250ms;
}
.ui-icp__select > .ui-icp__badge,
.ui-icp__select > .ui-icp__size {
  --d: 300ms;
}
.ui-icp__frame {
  position: absolute;
  top: var(--ft);
  left: var(--cx);
  width: var(--cw);
  height: var(--fh);
}
.ui-icp__box {
  position: absolute;
  inset: 0;
  box-shadow: inset 0 0 0 1px var(--ui-icp-blue);
}
.ui-icp__box::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    135deg,
    var(--ui-icp-hatch) 0 0.6px,
    transparent 0.6px 3.5px
  );
  clip-path: polygon(
    evenodd,
    0 0,
    100% 0,
    100% 100%,
    0 100%,
    0 0,
    10px 10px,
    10px calc(100% - 10px),
    calc(100% - 10px) calc(100% - 10px),
    calc(100% - 10px) 10px,
    10px 10px
  );
}
.ui-icp__box::after {
  content: "";
  position: absolute;
  inset: 10px;
  border: 0.6px dashed var(--ui-icp-dash);
  border-radius: 4px;
}
.ui-icp__tag {
  position: absolute;
  left: -0.5px;
  bottom: calc(100% + 3px);
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 14px;
  padding: 0 5px 0 4px;
  border-radius: 3px;
  background: var(--ui-icp-blue);
  color: #fff;
  font-size: 9px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
}
.ui-icp__tag svg {
  width: 9px;
  height: 9px;
}
.ui-icp__handle {
  position: absolute;
  width: 4px;
  height: 4px;
  box-sizing: border-box;
  border: 0.75px solid var(--ui-icp-blue);
  background: var(--ui-icp-handle);
}
.ui-icp__handle--tl {
  top: -1.5px;
  left: -1.5px;
}
.ui-icp__handle--tr {
  top: -1.5px;
  right: -1.5px;
}
.ui-icp__handle--br {
  bottom: -1.5px;
  right: -1.5px;
}
.ui-icp__handle--bl {
  bottom: -1.5px;
  left: -1.5px;
}
.ui-icp__badge {
  position: absolute;
  z-index: 1;
  min-width: 13px;
  height: 13px;
  padding: 0 3px;
  box-sizing: border-box;
  border-radius: 3px;
  color: #fff;
  font-size: 8.5px;
  font-weight: 500;
  line-height: 13px;
  text-align: center;
}
.ui-icp__badge--blue {
  background: var(--ui-icp-blue);
}
.ui-icp__badge--red {
  background: var(--ui-icp-red);
}
.ui-icp__badge--pad-top {
  top: -1.5px;
  left: calc(var(--rx) + var(--rw) - 50px);
}
.ui-icp__badge--pad-side {
  top: calc(var(--fh) / 2 - 6.5px);
  left: -1.5px;
}
.ui-icp__badge--edge {
  top: calc(var(--ft) + var(--fh) + 12px - 6.5px);
  left: -1.5px;
}
.ui-icp__select[data-last] .ui-icp__badge--edge {
  display: none;
}
.ui-icp__guide {
  position: absolute;
  top: var(--cy);
  height: var(--ch);
  left: var(--rx);
  width: 1px;
  background: repeating-linear-gradient(
    180deg,
    var(--ui-icp-red) 0 3px,
    transparent 3px 6px
  );
}
.ui-icp__guide::before,
.ui-icp__guide::after {
  content: "";
  position: absolute;
  left: -3px;
  width: 7px;
  height: 1px;
  background: var(--ui-icp-red);
}
.ui-icp__guide::before {
  top: 0;
}
.ui-icp__guide::after {
  bottom: 0;
}
.ui-icp__cursor {
  position: absolute;
  z-index: 2;
  top: calc(var(--ft) + var(--fh) - 20px);
  left: calc(var(--rx) + var(--rw) - 46px);
  width: 18px;
  height: 18px;
  filter: drop-shadow(0 1px 1px rgba(0, 0, 0, 0.2));
}
.ui-icp__size {
  position: absolute;
  z-index: 1;
  top: calc(var(--ft) + var(--fh) + 7px);
  left: calc(var(--rx) + var(--rw) - 50px);
  height: 14px;
  padding: 0 5px;
  border-radius: 3px;
  background: var(--ui-icp-blue);
  color: rgba(255, 255, 255, 0.75);
  font-size: 9px;
  line-height: 14px;
  white-space: nowrap;
}
.ui-icp__size b {
  color: #fff;
  font-weight: 500;
}
.ui-icp[data-mirror] .ui-icp__stage {
  transform: perspective(1100px) rotateX(30deg) rotateY(14deg) rotateZ(-7deg);
  transform-origin: 100% 0;
}
.ui-icp[data-mirror] {
  -webkit-mask-image:
    linear-gradient(270deg, #000 74%, transparent 100%),
    linear-gradient(180deg, #000 40%, transparent 82%);
  mask-image:
    linear-gradient(270deg, #000 74%, transparent 100%),
    linear-gradient(180deg, #000 40%, transparent 82%);
}
.ui-icp[data-mirror] .ui-icp__above {
  left: -24px;
  right: -56px;
}
.ui-icp[data-mirror] .ui-icp__guide {
  left: calc(var(--rx) + var(--rw));
}
.ui-icp[data-mirror] .ui-icp__tag {
  left: auto;
  right: -0.5px;
}
.ui-icp[data-mirror] .ui-icp__badge--pad-side,
.ui-icp[data-mirror] .ui-icp__badge--edge {
  left: auto;
  right: -1.5px;
}
.ui-icp[data-mirror] .ui-icp__badge--pad-top {
  left: calc(var(--rx) + var(--rw) - 74px);
}
.ui-icp[data-mirror] .ui-icp__cursor {
  left: calc(var(--rx) + var(--rw) - 70px);
}
.ui-icp[data-mirror] .ui-icp__size {
  left: auto;
  right: calc(var(--w) - var(--rx) - var(--rw) + 6px);
}
.ui-icp[data-flat] .ui-icp__stage {
  transform: none;
}
@keyframes ui-icp-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-icp *,
  .ui-icp *::before,
  .ui-icp *::after {
    transition: none !important;
    animation: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-icp {
  --ui-icp-handle: #19191b;
  --ui-icp-hatch: rgba(96, 165, 250, 0.32);
  --ui-icp-dash: rgba(96, 165, 250, 0.85);
  --ui-icp-blue: #3b82f6;
}

.inspect-composer-demo {
  place-items: center;
  width: 100%;
  display: grid;
}
.card__preview .inspect-composer-demo {
  position: absolute;
  inset: 0;
  overflow: hidden;
}
.card__preview .inspect-composer-demo .ui-icp {
  zoom: 0.78;
  margin: -80px 60px 0 0;
}
.stage .inspect-composer-demo .ui-icp {
  zoom: 1.3;
  margin: -80px 60px 0 0;
}
.stage:has(.inspect-composer-demo) {
  height: 480px;
}
@media (width<=760px) {
  .stage .inspect-composer-demo .ui-icp {
    zoom: 0.8;
  }
}
`;export{n as default};
