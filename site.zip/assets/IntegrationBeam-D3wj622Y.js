const n=`.ui-ibm {
  --ui-ibm-ink: #171717;
  --ui-ibm-text: #404040;
  --ui-ibm-muted: #8f8f8f;
  --ui-ibm-faint: #b5b5b5;
  --ui-ibm-line: #e2e2e2;
  --ui-ibm-line-hi: #a9c0ff;
  --ui-ibm-card: #ffffff;
  --ui-ibm-tray: #f0f0f0;
  --ui-ibm-accent: #2f6bff;
  /* Pulse: clear tail, accent body, a pale tip that reads as light */
  --ui-ibm-pulse: #2f6bff;
  --ui-ibm-tip-color: #b9cdff;
  --ui-ibm-ring: rgba(47, 107, 255, 0.2);
  --ui-ibm-glow: rgba(47, 107, 255, 0.26);
  --ui-ibm-hub: #171717;
  --ui-ibm-hub-mark: #ffffff;
  --ui-ibm-hub-edge: rgba(0, 0, 0, 0.9);
  --ui-ibm-tooltip: #171717;
  --ui-ibm-tooltip-text: #ffffff;
  --ui-ibm-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.07), 0 1px 2px rgba(0, 0, 0, 0.04),
    0 8px 18px -10px rgba(0, 0, 0, 0.18);
  --ui-ibm-focus: rgba(23, 23, 23, 0.22);
  --ui-ibm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  width: 100%;
  container-type: inline-size;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    sans-serif;
  font-size: 13px;
  color: var(--ui-ibm-text);
  -webkit-tap-highlight-color: transparent;
}
.ui-ibm *,
.ui-ibm *::before,
.ui-ibm *::after {
  box-sizing: border-box;
}

/* ---------- Beams ---------- */

/* Absolute, so it paints below the (positioned) tiles */
.ui-ibm__beams {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-ibm__line {
  fill: none;
  stroke: var(--ui-ibm-line);
  stroke-width: 1.5;
  stroke-linecap: round;
  transition:
    stroke 300ms var(--ui-ibm-ease),
    opacity 300ms var(--ui-ibm-ease);
}
.ui-ibm__line[data-off] {
  stroke: var(--ui-ibm-faint);
  stroke-dasharray: 2 5;
  opacity: 0.75;
}
.ui-ibm[data-focus] .ui-ibm__line:not([data-focus]) {
  opacity: 0.35;
}
.ui-ibm__line[data-focus]:not([data-off]) {
  stroke: var(--ui-ibm-line-hi);
}

.ui-ibm__pulse {
  opacity: 0;
  transition: opacity 240ms ease;
}
.ui-ibm__pulse path {
  fill: none;
  stroke-linecap: round;
  transition: opacity 300ms var(--ui-ibm-ease);
}
.ui-ibm__core {
  stroke-width: 2;
}
.ui-ibm__glow {
  stroke-width: 6;
  opacity: 0.45;
}
.ui-ibm[data-focus] .ui-ibm__pulse:not([data-focus]) path {
  opacity: 0.25;
}
.ui-ibm__pulse[data-focus] .ui-ibm__glow {
  opacity: 0.7;
}
.ui-ibm__stop-tail {
  stop-color: var(--ui-ibm-pulse);
  stop-opacity: 0;
}
.ui-ibm__stop-mid {
  stop-color: var(--ui-ibm-pulse);
  stop-opacity: 0.9;
}
.ui-ibm__stop-head {
  stop-color: var(--ui-ibm-tip-color);
  stop-opacity: 1;
}

/* ---------- Layout: side by side, stacked on narrow widths ---------- */

.ui-ibm__scene {
  --ui-ibm-stack: 0;
  display: grid;
  grid-template-columns: auto minmax(40px, 1fr) auto minmax(40px, 1fr) auto;
  grid-template-areas: "in . hub . out";
  align-items: center;
  padding: 6px 0;
}
.ui-ibm__group {
  display: flex;
  flex-direction: column;
  gap: 26px;
}
.ui-ibm__group--in {
  grid-area: in;
}
.ui-ibm__group--out {
  grid-area: out;
}

/* ---------- Tools ---------- */

.ui-ibm__tool {
  position: relative;
  display: grid;
  place-items: center;
  width: 60px;
  height: 60px;
  padding: 0;
  border: 0;
  border-radius: 18px;
  background: var(--ui-ibm-card);
  box-shadow: var(--ui-ibm-shadow);
  color: var(--ui-ibm-ink);
  font: inherit;
  cursor: pointer;
  transition:
    background-color 300ms var(--ui-ibm-ease),
    box-shadow 300ms var(--ui-ibm-ease);
}
.ui-ibm__tool:focus-visible {
  outline: 2px solid var(--ui-ibm-focus);
  outline-offset: 3px;
}
.ui-ibm__logo {
  display: grid;
  width: 28px;
  height: 28px;
  transition:
    transform 300ms var(--ui-ibm-ease),
    filter 300ms var(--ui-ibm-ease),
    opacity 300ms var(--ui-ibm-ease);
}
.ui-ibm__logo > svg {
  width: 100%;
  height: 100%;
}
@media (hover: hover) {
  .ui-ibm__tool:hover .ui-ibm__logo {
    transform: scale(1.08);
  }
}
.ui-ibm__tool[data-off] {
  background: var(--ui-ibm-tray);
}
.ui-ibm__tool[data-off] .ui-ibm__logo {
  filter: grayscale(1);
  opacity: 0.4;
}

/* Arrival glow – played with the Web Animations API */
.ui-ibm__ring {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  box-shadow:
    0 0 0 3px var(--ui-ibm-ring),
    0 0 22px 2px var(--ui-ibm-glow);
  opacity: 0;
  pointer-events: none;
}

/* Tooltip: points toward the centre, so it never leaves the scene */
.ui-ibm__tip {
  --ui-ibm-tip-from: translate(-4px, -50%);
  position: absolute;
  z-index: 3;
  top: 50%;
  left: calc(100% + 10px);
  padding: 5px 9px;
  border-radius: 8px;
  background: var(--ui-ibm-tooltip);
  color: var(--ui-ibm-tooltip-text);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transform: var(--ui-ibm-tip-from);
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-ibm-ease);
}
.ui-ibm__group--out .ui-ibm__tip {
  --ui-ibm-tip-from: translate(4px, -50%);
  left: auto;
  right: calc(100% + 10px);
}
.ui-ibm__tip-state {
  opacity: 0.6;
  font-weight: 400;
}
.ui-ibm__tool[data-tip] .ui-ibm__tip {
  opacity: 1;
  transform: translate(0, -50%);
}

/* ---------- Centre ---------- */

.ui-ibm__center {
  grid-area: hub;
  position: relative;
  display: grid;
  place-items: center;
  width: 80px;
  height: 80px;
  border-radius: 24px;
  background: var(--ui-ibm-hub);
  box-shadow:
    0 0 0 1px var(--ui-ibm-hub-edge),
    inset 0 1px 0 rgba(255, 255, 255, 0.12),
    0 14px 28px -12px rgba(0, 0, 0, 0.38);
  color: var(--ui-ibm-hub-mark);
}
.ui-ibm__mark {
  display: grid;
  width: 36px;
  height: 36px;
  fill: currentColor;
}
.ui-ibm__mark > svg {
  width: 100%;
  height: 100%;
}
.ui-ibm__ring--center {
  inset: -1px;
}

/* Status chip under the hub – absolute, so the hub itself stays centred on the beams */
.ui-ibm__chip {
  position: absolute;
  top: calc(100% + 12px);
  left: 50%;
  translate: -50% 0;
  display: block;
  height: 26px;
  overflow: hidden;
  border-radius: 999px;
  background: var(--ui-ibm-card);
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.07),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition: width 320ms var(--ui-ibm-ease);
}
.ui-ibm__chip-inner {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  width: max-content;
  height: 26px;
  padding: 0 11px 0 10px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-ibm-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-ibm__status {
  display: inline-block;
  animation: ui-ibm-in 320ms var(--ui-ibm-ease) both;
}
.ui-ibm__dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-ibm-accent);
  transition: background-color 300ms ease;
}
.ui-ibm__dot[data-idle] {
  background: var(--ui-ibm-faint);
}
.ui-ibm__center[data-syncing] .ui-ibm__dot {
  animation: ui-ibm-breathe 1.1s ease-in-out infinite;
}

.ui-ibm__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

@keyframes ui-ibm-in {
  from {
    opacity: 0;
    transform: translateY(6px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-ibm-breathe {
  50% {
    box-shadow: 0 0 0 3px var(--ui-ibm-ring);
  }
}

/* Narrow: senders above, receivers below, vertical beams */
@container (max-width: 459px) {
  .ui-ibm__scene {
    --ui-ibm-stack: 1;
    grid-template-columns: 1fr;
    grid-template-areas: "in" "hub" "out";
    justify-items: center;
    row-gap: 78px;
    padding: 0 0 4px;
  }
  /* Many tools in a row: the tiles get smaller (down to 36px) instead of running past the edge */
  .ui-ibm__group {
    flex-direction: row;
    justify-content: center;
    width: 100%;
    gap: clamp(8px, 4cqw, 34px);
  }
  .ui-ibm__tool {
    flex: 0 1 56px;
    width: auto;
    min-width: 36px;
    height: auto;
    aspect-ratio: 1;
    border-radius: 17px;
  }
  .ui-ibm__center {
    width: 76px;
    height: 76px;
    border-radius: 23px;
  }
  /* Tooltips sit between the rows; the outer tools align theirs to their edge */
  .ui-ibm__tip,
  .ui-ibm__group--out .ui-ibm__tip {
    --ui-ibm-tip-from: translate(-50%, -4px);
    top: calc(100% + 8px);
    right: auto;
    left: 50%;
  }
  .ui-ibm__group--out .ui-ibm__tip {
    --ui-ibm-tip-from: translate(-50%, 4px);
    top: auto;
    bottom: calc(100% + 8px);
  }
  .ui-ibm__tool[data-tip] .ui-ibm__tip {
    transform: translate(-50%, 0);
  }
  .ui-ibm__tool:first-child .ui-ibm__tip {
    left: 0;
    translate: 50% 0;
  }
  .ui-ibm__tool:last-child .ui-ibm__tip {
    left: 100%;
    translate: -50% 0;
  }
}

/* Touch: the tiles are already 56px+; tooltips are shown after a tap instead of on hover */
@media (hover: none) and (pointer: coarse) {
  .ui-ibm__tool {
    min-width: 44px;
    min-height: 44px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-ibm__line,
  .ui-ibm__tool,
  .ui-ibm__logo,
  .ui-ibm__tip,
  .ui-ibm__chip,
  .ui-ibm__dot {
    transition: none;
  }
  .ui-ibm__status,
  .ui-ibm__center[data-syncing] .ui-ibm__dot {
    animation: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-ibm {
  --ui-ibm-ink: #ededed;
  --ui-ibm-text: #c8c8cc;
  --ui-ibm-muted: #8b8b92;
  --ui-ibm-faint: #5c5c63;
  --ui-ibm-line: #2e2e33;
  --ui-ibm-line-hi: #4b5f9e;
  --ui-ibm-card: #19191b;
  --ui-ibm-tray: #111113;
  --ui-ibm-accent: #6d8bff;
  --ui-ibm-pulse: #6d8bff;
  --ui-ibm-tip-color: #ffffff;
  --ui-ibm-ring: rgba(109, 139, 255, 0.24);
  --ui-ibm-glow: rgba(109, 139, 255, 0.3);
  --ui-ibm-hub: #26262a;
  --ui-ibm-hub-mark: #ffffff;
  --ui-ibm-hub-edge: rgba(255, 255, 255, 0.12);
  --ui-ibm-tooltip: #ededed;
  --ui-ibm-tooltip-text: #111113;
  --ui-ibm-shadow:
    0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.3),
    0 8px 18px -10px rgba(0, 0, 0, 0.6);
  --ui-ibm-focus: rgba(255, 255, 255, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-ibm__chip {
  box-shadow:
    0 0 0 1px #2a2a2e,
    0 1px 2px rgba(0, 0, 0, 0.3);
}

.integration-beam-demo {
  width: 100%;
}
.integration-beam-demo .ui-ibm {
  width: min(100%, 620px);
  margin: 0 auto;
}
.stage .integration-beam-demo,
.card__preview .integration-beam-demo {
  --ib-demo-dot: #00000013;
  border-radius: inherit;
  background-image: radial-gradient(
    circle,
    var(--ib-demo-dot) 1px,
    transparent 1.4px
  );
  background-position: 50%;
  background-size: 18px 18px;
  place-items: center;
  width: auto;
  padding: 52px 24px;
  display: grid;
  position: absolute;
  inset: 0;
  overflow: hidden;
}
.stage .integration-beam-demo:before,
.card__preview .integration-beam-demo:before {
  content: "";
  background: radial-gradient(
    ellipse 70% 70% at 50% 50%,
    transparent 40%,
    var(--preview) 100%
  );
  pointer-events: none;
  position: absolute;
  inset: 0;
}
:where(.dark, [data-theme="dark"]) .integration-beam-demo {
  --ib-demo-dot: #ffffff0f;
}
.card__preview .integration-beam-demo {
  padding: 40px 0 8px;
}
.card__preview .integration-beam-demo .ui-ibm {
  zoom: 0.52;
  width: 520px;
}
@media (width<=760px) {
  .stage:has(.integration-beam-demo) {
    height: 460px;
    min-height: 0;
  }
  .stage .integration-beam-demo {
    padding: 56px 16px 40px;
  }
}
`;export{n as default};
