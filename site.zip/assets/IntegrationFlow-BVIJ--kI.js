const n=`.ui-if {
  --ui-if-bg: #ffffff;
  --ui-if-fade: #ffffff;
  --ui-if-step: 0.9s;
  --ui-if-sweep: 1.1s;
  --ui-if-step-ease: cubic-bezier(0.65, 0.02, 0.25, 1);
  --ui-if-sweep-ease: cubic-bezier(0.55, 0.06, 0.25, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 2400 / 1490;
  overflow: hidden;
  background: var(--ui-if-bg);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    sans-serif;
  -webkit-font-smoothing: antialiased;
}
.ui-if *,
.ui-if *::before,
.ui-if *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.ui-if-defs {
  position: absolute;
  width: 0;
  height: 0;
  overflow: hidden;
}
.ui-if-stage {
  position: absolute;
  left: 0;
  top: 0;
  width: 2400px;
  height: 1490px;
  overflow: hidden;
  transform-origin: 0 0;
}
.ui-if-artboard {
  position: absolute;
  left: 0;
  top: -55px;
  width: 1800px;
  height: 1200px;
  transform: scale(1.33333333);
  transform-origin: 0 0;
}
.ui-if-blobs {
  position: absolute;
  left: -886.5361px;
  top: -811.2378px;
  width: 3316.08px;
  height: 2907.21px;
}
.ui-if-blob {
  position: absolute;
  transform: rotate(var(--rot));
  animation:
    ui-if-drift var(--dur) var(--delay) infinite linear,
    ui-if-breathe var(--fdur) var(--fdelay) infinite ease-in-out;
}
@keyframes ui-if-drift {
  0%,
  100% {
    transform: rotate(var(--rot)) translate(0, 0);
  }
  25% {
    transform: rotate(calc(var(--rot) + var(--r1)))
      translate(var(--dx), var(--dy));
  }
  50% {
    transform: rotate(var(--rot))
      translate(calc(var(--dx) - var(--dy)), calc(var(--dy) + var(--dx)));
  }
  75% {
    transform: rotate(calc(var(--rot) - var(--r1)))
      translate(calc(var(--dy) * -1), var(--dx));
  }
}
@keyframes ui-if-breathe {
  0%,
  100% {
    opacity: var(--o-lo);
  }
  50% {
    opacity: var(--o-hi);
  }
}
.ui-if-blob--283 {
  left: 311px;
  top: 264.6px;
  width: 1931.3px;
  height: 2152.1px;
  --rot: -19.45deg;
  --dx: 237px;
  --dy: -187px;
  --r1: 16deg;
  --dur: 16s;
  --delay: -3s;
  --o-lo: 0.82;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -2s;
  background: radial-gradient(
    closest-side,
    rgba(255, 155, 74, 0.534) 0%,
    rgba(255, 155, 74, 0.516) 10%,
    rgba(255, 155, 74, 0.463) 20%,
    rgba(255, 155, 74, 0.386) 30%,
    rgba(255, 155, 74, 0.299) 40%,
    rgba(255, 155, 74, 0.215) 50%,
    rgba(255, 155, 74, 0.144) 60%,
    rgba(255, 155, 74, 0.089) 70%,
    rgba(255, 155, 74, 0.051) 80%,
    rgba(255, 155, 74, 0.027) 90%,
    rgba(255, 155, 74, 0) 100%
  );
}
.ui-if-blob--292 {
  left: 220.8px;
  top: 437.4px;
  width: 1277.4px;
  height: 1421.8px;
  --rot: -19.45deg;
  --dx: -204px;
  --dy: 253px;
  --r1: -19deg;
  --dur: 16s;
  --delay: -5s;
  --o-lo: 0.8;
  --o-hi: 0.98;
  --fdur: 16s;
  --fdelay: -4s;
  background: radial-gradient(
    closest-side,
    rgba(255, 155, 74, 0.835) 0%,
    rgba(255, 155, 74, 0.805) 10%,
    rgba(255, 155, 74, 0.722) 20%,
    rgba(255, 155, 74, 0.602) 30%,
    rgba(255, 155, 74, 0.467) 40%,
    rgba(255, 155, 74, 0.336) 50%,
    rgba(255, 155, 74, 0.224) 60%,
    rgba(255, 155, 74, 0.139) 70%,
    rgba(255, 155, 74, 0.079) 80%,
    rgba(255, 155, 74, 0.042) 90%,
    rgba(255, 155, 74, 0) 100%
  );
}
.ui-if-blob--291 {
  left: 1461.9px;
  top: 542.4px;
  width: 2011.2px;
  height: 1925px;
  --rot: -19.45deg;
  --dx: 270px;
  --dy: 204px;
  --r1: 14deg;
  --dur: 16s;
  --delay: -8s;
  --o-lo: 0.84;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -6s;
  background: radial-gradient(
    closest-side,
    rgba(255, 155, 74, 0.465) 0%,
    rgba(255, 155, 74, 0.448) 10%,
    rgba(255, 155, 74, 0.402) 20%,
    rgba(255, 155, 74, 0.334) 30%,
    rgba(255, 155, 74, 0.258) 40%,
    rgba(255, 155, 74, 0.185) 50%,
    rgba(255, 155, 74, 0.122) 60%,
    rgba(255, 155, 74, 0.074) 70%,
    rgba(255, 155, 74, 0.042) 80%,
    rgba(255, 155, 74, 0.022) 90%,
    rgba(255, 155, 74, 0) 100%
  );
}
.ui-if-blob--287 {
  left: 194px;
  top: -179.4px;
  width: 1931.3px;
  height: 2152.1px;
  --rot: -19.45deg;
  --dx: -248px;
  --dy: -165px;
  --r1: -15deg;
  --dur: 16s;
  --delay: -6s;
  --o-lo: 0.86;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -3s;
  background: radial-gradient(
    closest-side,
    rgba(255, 155, 74, 0.534) 0%,
    rgba(255, 155, 74, 0.516) 10%,
    rgba(255, 155, 74, 0.463) 20%,
    rgba(255, 155, 74, 0.386) 30%,
    rgba(255, 155, 74, 0.299) 40%,
    rgba(255, 155, 74, 0.215) 50%,
    rgba(255, 155, 74, 0.144) 60%,
    rgba(255, 155, 74, 0.089) 70%,
    rgba(255, 155, 74, 0.051) 80%,
    rgba(255, 155, 74, 0.027) 90%,
    rgba(255, 155, 74, 0) 100%
  );
}
.ui-if-blob--288 {
  left: -163px;
  top: -179.4px;
  width: 1931.3px;
  height: 2152.1px;
  --rot: -19.45deg;
  --dx: 187px;
  --dy: 264px;
  --r1: 18deg;
  --dur: 16s;
  --delay: -11s;
  --o-lo: 0.82;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -8s;
  background: radial-gradient(
    closest-side,
    rgba(255, 134, 134, 0.534) 0%,
    rgba(255, 134, 134, 0.516) 10%,
    rgba(255, 134, 134, 0.463) 20%,
    rgba(255, 134, 134, 0.386) 30%,
    rgba(255, 134, 134, 0.299) 40%,
    rgba(255, 134, 134, 0.215) 50%,
    rgba(255, 134, 134, 0.144) 60%,
    rgba(255, 134, 134, 0.089) 70%,
    rgba(255, 134, 134, 0.051) 80%,
    rgba(255, 134, 134, 0.027) 90%,
    rgba(255, 134, 134, 0) 100%
  );
}
.ui-if-blob--284 {
  left: 551px;
  top: -182.4px;
  width: 1931.3px;
  height: 2152.1px;
  --rot: -19.45deg;
  --dx: -280px;
  --dy: 182px;
  --r1: -17deg;
  --dur: 16s;
  --delay: -9s;
  --o-lo: 0.84;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -5s;
  background: radial-gradient(
    closest-side,
    rgba(255, 98, 98, 0.534) 0%,
    rgba(255, 98, 98, 0.516) 10%,
    rgba(255, 98, 98, 0.463) 20%,
    rgba(255, 98, 98, 0.386) 30%,
    rgba(255, 98, 98, 0.299) 40%,
    rgba(255, 98, 98, 0.215) 50%,
    rgba(255, 98, 98, 0.144) 60%,
    rgba(255, 98, 98, 0.089) 70%,
    rgba(255, 98, 98, 0.051) 80%,
    rgba(255, 98, 98, 0.027) 90%,
    rgba(255, 98, 98, 0) 100%
  );
}
.ui-if-blob--289 {
  left: 737.5px;
  top: 384.6px;
  width: 1913.4px;
  height: 2152.1px;
  --rot: -39.83deg;
  --dx: 209px;
  --dy: -258px;
  --r1: 20deg;
  --dur: 16s;
  --delay: -2s;
  --o-lo: 0.86;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -7s;
  background: radial-gradient(
    closest-side,
    rgba(255, 80, 72, 0.52) 0%,
    rgba(255, 80, 72, 0.502) 10%,
    rgba(255, 80, 72, 0.45) 20%,
    rgba(255, 80, 72, 0.376) 30%,
    rgba(255, 80, 72, 0.292) 40%,
    rgba(255, 80, 72, 0.211) 50%,
    rgba(255, 80, 72, 0.141) 60%,
    rgba(255, 80, 72, 0.088) 70%,
    rgba(255, 80, 72, 0.05) 80%,
    rgba(255, 80, 72, 0.027) 90%,
    rgba(255, 80, 72, 0) 100%
  );
}
.ui-if-blob--293 {
  left: 977.3px;
  top: 245.8px;
  width: 1913.4px;
  height: 2152.1px;
  --rot: -39.83deg;
  --dx: -226px;
  --dy: 220px;
  --r1: -13deg;
  --dur: 16s;
  --delay: -7s;
  --o-lo: 0.8;
  --o-hi: 1;
  --fdur: 8s;
  --fdelay: -3s;
  background: radial-gradient(
    closest-side,
    rgba(255, 255, 255, 0.52) 0%,
    rgba(255, 255, 255, 0.502) 10%,
    rgba(255, 255, 255, 0.45) 20%,
    rgba(255, 255, 255, 0.376) 30%,
    rgba(255, 255, 255, 0.292) 40%,
    rgba(255, 255, 255, 0.211) 50%,
    rgba(255, 255, 255, 0.141) 60%,
    rgba(255, 255, 255, 0.088) 70%,
    rgba(255, 255, 255, 0.05) 80%,
    rgba(255, 255, 255, 0.027) 90%,
    rgba(255, 255, 255, 0) 100%
  );
}
.ui-if-blob--290 {
  left: 1662.3px;
  top: -188.5px;
  width: 1790.4px;
  height: 2279.7px;
  --rot: -19.45deg;
  --dx: 258px;
  --dy: -204px;
  --r1: 16deg;
  --dur: 16s;
  --delay: -4s;
  --o-lo: 0.82;
  --o-hi: 0.98;
  --fdur: 16s;
  --fdelay: -4s;
  background: radial-gradient(
    closest-side,
    rgba(255, 153, 151, 0.443) 0%,
    rgba(255, 153, 151, 0.428) 10%,
    rgba(255, 153, 151, 0.386) 20%,
    rgba(255, 153, 151, 0.325) 30%,
    rgba(255, 153, 151, 0.256) 40%,
    rgba(255, 153, 151, 0.188) 50%,
    rgba(255, 153, 151, 0.129) 60%,
    rgba(255, 153, 151, 0.082) 70%,
    rgba(255, 153, 151, 0.049) 80%,
    rgba(255, 153, 151, 0.027) 90%,
    rgba(255, 153, 151, 0) 100%
  );
}
.ui-if-blob--285 {
  left: 1122.1px;
  top: -196px;
  width: 1876.8px;
  height: 2311.5px;
  --rot: -19.45deg;
  --dx: -182px;
  --dy: -242px;
  --r1: -18deg;
  --dur: 16s;
  --delay: -10s;
  --o-lo: 0.86;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -9s;
  background: radial-gradient(
    closest-side,
    rgba(245, 89, 86, 0.536) 0%,
    rgba(245, 89, 86, 0.517) 10%,
    rgba(245, 89, 86, 0.465) 20%,
    rgba(245, 89, 86, 0.389) 30%,
    rgba(245, 89, 86, 0.303) 40%,
    rgba(245, 89, 86, 0.219) 50%,
    rgba(245, 89, 86, 0.148) 60%,
    rgba(245, 89, 86, 0.092) 70%,
    rgba(245, 89, 86, 0.054) 80%,
    rgba(245, 89, 86, 0.029) 90%,
    rgba(245, 89, 86, 0) 100%
  );
}
.ui-if-blob--286 {
  left: 835.8px;
  top: -412px;
  width: 1596.4px;
  height: 2186.1px;
  --rot: -84.58deg;
  --dx: 292px;
  --dy: 165px;
  --r1: 12deg;
  --dur: 16s;
  --delay: -5s;
  --o-lo: 0.84;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -3s;
  background: radial-gradient(
    closest-side,
    rgba(245, 89, 86, 0.766) 0%,
    rgba(245, 89, 86, 0.739) 10%,
    rgba(245, 89, 86, 0.662) 20%,
    rgba(245, 89, 86, 0.551) 30%,
    rgba(245, 89, 86, 0.426) 40%,
    rgba(245, 89, 86, 0.305) 50%,
    rgba(245, 89, 86, 0.202) 60%,
    rgba(245, 89, 86, 0.124) 70%,
    rgba(245, 89, 86, 0.07) 80%,
    rgba(245, 89, 86, 0.036) 90%,
    rgba(245, 89, 86, 0) 100%
  );
}
.ui-if-blob--294 {
  left: 144.7px;
  top: 959.3px;
  width: 1596.4px;
  height: 2186.1px;
  --rot: 37.72deg;
  --dx: -215px;
  --dy: -226px;
  --r1: -21deg;
  --dur: 16s;
  --delay: -7s;
  --o-lo: 0.82;
  --o-hi: 1;
  --fdur: 8s;
  --fdelay: -6s;
  background: radial-gradient(
    closest-side,
    rgba(245, 89, 86, 0.766) 0%,
    rgba(245, 89, 86, 0.739) 10%,
    rgba(245, 89, 86, 0.662) 20%,
    rgba(245, 89, 86, 0.551) 30%,
    rgba(245, 89, 86, 0.426) 40%,
    rgba(245, 89, 86, 0.305) 50%,
    rgba(245, 89, 86, 0.202) 60%,
    rgba(245, 89, 86, 0.124) 70%,
    rgba(245, 89, 86, 0.07) 80%,
    rgba(245, 89, 86, 0.036) 90%,
    rgba(245, 89, 86, 0) 100%
  );
}
.ui-if-blob--296 {
  left: 1553.2px;
  top: 914.1px;
  width: 1596.4px;
  height: 2186.1px;
  --rot: -63.15deg;
  --dx: 242px;
  --dy: 198px;
  --r1: 14deg;
  --dur: 16s;
  --delay: -12s;
  --o-lo: 0.8;
  --o-hi: 0.98;
  --fdur: 16s;
  --fdelay: -11s;
  background: radial-gradient(
    closest-side,
    rgba(223, 43, 43, 0.766) 0%,
    rgba(223, 43, 43, 0.739) 10%,
    rgba(223, 43, 43, 0.662) 20%,
    rgba(223, 43, 43, 0.551) 30%,
    rgba(223, 43, 43, 0.426) 40%,
    rgba(223, 43, 43, 0.305) 50%,
    rgba(223, 43, 43, 0.202) 60%,
    rgba(223, 43, 43, 0.124) 70%,
    rgba(223, 43, 43, 0.07) 80%,
    rgba(223, 43, 43, 0.036) 90%,
    rgba(223, 43, 43, 0) 100%
  );
}
.ui-if-blob--295 {
  left: 539.4px;
  top: 719px;
  width: 1596.4px;
  height: 2515.3px;
  --rot: 37.72deg;
  --dx: -264px;
  --dy: 176px;
  --r1: -16deg;
  --dur: 16s;
  --delay: -8s;
  --o-lo: 0.86;
  --o-hi: 1;
  --fdur: 16s;
  --fdelay: -5s;
  background: radial-gradient(
    closest-side,
    rgba(251, 112, 56, 0.77) 0%,
    rgba(251, 112, 56, 0.742) 10%,
    rgba(251, 112, 56, 0.665) 20%,
    rgba(251, 112, 56, 0.554) 30%,
    rgba(251, 112, 56, 0.428) 40%,
    rgba(251, 112, 56, 0.307) 50%,
    rgba(251, 112, 56, 0.203) 60%,
    rgba(251, 112, 56, 0.124) 70%,
    rgba(251, 112, 56, 0.07) 80%,
    rgba(251, 112, 56, 0.037) 90%,
    rgba(251, 112, 56, 0) 100%
  );
}
.ui-if-link {
  position: absolute;
  left: 779.639px;
  top: 597px;
  width: 240.361px;
  height: 3px;
  clip-path: inset(-80px 0px -80px 0px);
}
.ui-if-beam {
  position: absolute;
  left: 0;
  width: 150px;
  opacity: 0;
  transform: translateX(240px);
  background: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0) 0%,
    rgba(255, 255, 255, 1) 40%,
    rgba(255, 255, 255, 1) 55%,
    rgba(255, 255, 255, 0.08) 100%
  );
}
.ui-if-beam--core {
  top: 0;
  height: 3px;
}
.ui-if-beam--glow {
  top: -2px;
  height: 5px;
  filter: blur(3px);
}
.ui-if-sweeping .ui-if-beam--core {
  animation: ui-if-sweep var(--ui-if-sweep) var(--ui-if-sweep-ease) both;
}
.ui-if-sweeping .ui-if-beam--glow {
  animation: ui-if-sweep-glow var(--ui-if-sweep) var(--ui-if-sweep-ease) both;
}
@keyframes ui-if-sweep {
  0% {
    transform: translateX(241px);
    opacity: 0;
  }
  18% {
    opacity: 1;
  }
  72% {
    opacity: 1;
  }
  100% {
    transform: translateX(-155px);
    opacity: 0;
  }
}
@keyframes ui-if-sweep-glow {
  0% {
    transform: translateX(241px);
    opacity: 0;
    filter: blur(3px);
  }
  18% {
    opacity: 0.9;
    filter: blur(7.1px);
  }
  72% {
    opacity: 0.9;
    filter: blur(7.1px);
  }
  100% {
    transform: translateX(-155px);
    opacity: 0;
    filter: blur(3px);
  }
}
.ui-if-orbit {
  position: absolute;
  left: 1100.25px;
  top: -178.5px;
  width: 1519.5px;
  height: 1557.75px;
  display: block;
  overflow: visible;
  pointer-events: none;
}
.ui-if-fade {
  position: absolute;
  left: 0;
  bottom: -12px;
  width: 2400px;
  height: 612px;
  background: linear-gradient(
    180deg,
    color-mix(in srgb, var(--ui-if-fade) 0%, transparent) 0%,
    var(--ui-if-fade) 94%
  );
  pointer-events: none;
}
.ui-if-glow {
  position: absolute;
  top: 520.6797px;
  height: 158.639px;
  border-radius: 3600px;
  filter: blur(21.94px);
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.55s ease-out;
}
.ui-if-glow.ui-if-on {
  opacity: 1;
  transition: opacity 0.5s ease-in;
}
.ui-if-glow--out {
  left: 1020px;
  width: 492.639px;
  background: linear-gradient(90deg, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
}
.ui-if-glow--in {
  left: 137px;
  width: 642.639px;
  background: linear-gradient(270deg, #ffffff 0%, rgba(255, 255, 255, 0) 100%);
}
.ui-if-card {
  position: absolute;
  display: flex;
  align-items: center;
  gap: 20px;
  border-radius: 3600px;
  -webkit-backdrop-filter: blur(26.55px);
  backdrop-filter: blur(26.55px);
}
.ui-if-card--icon-left {
  padding: 20px 80px 20px 20px;
}
.ui-if-hub {
  left: 137px;
  top: 520.6797px;
  padding: 20px 20px 20px 60px;
}
.ui-if-card--light {
  background: linear-gradient(
    180deg,
    rgba(255, 255, 255, 0.8) 0%,
    rgba(255, 255, 255, 0.4) 100%
  );
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.1),
    0 16px 36px 0 rgba(0, 0, 0, 0.06);
}
.ui-if-bg {
  position: absolute;
  inset: 0;
  z-index: 0;
  border-radius: inherit;
  transition: opacity var(--ui-if-step) var(--ui-if-step-ease);
}
.ui-if-bg--charge {
  opacity: 0;
  box-shadow: none;
  transition: opacity 0.55s ease-out;
}
.ui-if-bg--charge-out {
  background: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0.4) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}
.ui-if-bg--charge-in {
  background: linear-gradient(
    270deg,
    rgba(255, 255, 255, 0.4) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}
.ui-if-pills.ui-if-charged .ui-if-pill[data-phase="3"] .ui-if-bg--charge,
.ui-if-hub.ui-if-charged .ui-if-bg--charge {
  opacity: 1;
  transition: opacity 0.5s ease-in;
}
.ui-if-badge {
  position: relative;
  z-index: 1;
  flex: 0 0 auto;
  width: 118.639px;
  height: 118.639px;
}
.ui-if-ring {
  position: absolute;
  inset: 0;
  width: 118.639px;
  height: 118.639px;
  display: block;
  overflow: visible;
}
.ui-if-icon {
  position: absolute;
  left: 27.32px;
  top: 27.32px;
  width: 64px;
  height: 64px;
  display: grid;
  place-items: center;
}
.ui-if-icon > svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.ui-if-label {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  gap: 8px;
  align-items: flex-start;
  flex: 0 0 auto;
  white-space: nowrap;
  width: 254px;
}
.ui-if-label--right {
  align-items: flex-end;
  justify-content: center;
  text-align: right;
  width: 424px;
}
.ui-if-label > * {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-if-title {
  display: block;
  font-size: 37px;
  line-height: 40px;
  letter-spacing: -0.02em;
  font-weight: 400;
}
.ui-if-sub {
  display: block;
  font-size: 33.5px;
  line-height: 36px;
  letter-spacing: -0.02em;
  font-weight: 380;
}
.ui-if-hub .ui-if-title {
  color: rgba(0, 0, 0, 0.8);
}
.ui-if-hub .ui-if-sub {
  color: rgba(0, 0, 0, 0.4);
}
.ui-if-pill {
  left: 1020px;
  top: 520.6797px;
  will-change: transform;
  transition:
    transform var(--ui-if-step) var(--ui-if-step-ease),
    opacity var(--ui-if-step) var(--ui-if-step-ease);
}
.ui-if-pill[data-phase="0"] {
  transform: translate(480px, -845.68px);
  opacity: 0;
  transition: none;
}
.ui-if-pill[data-phase="1"] {
  transform: translate(240px, -562.68px);
  opacity: 1;
}
.ui-if-pill[data-phase="2"] {
  transform: translate(80px, -279.68px);
  opacity: 1;
}
.ui-if-pill[data-phase="3"] {
  transform: translate(0px, 0px);
  opacity: 1;
}
.ui-if-pill[data-phase="4"] {
  transform: translate(80px, 279.32px);
  opacity: 1;
}
.ui-if-pill[data-phase="5"] {
  transform: translate(240px, 558.32px);
  opacity: 1;
}
.ui-if-pill[data-phase="6"] {
  transform: translate(480px, 838.32px);
  opacity: 0;
}
.ui-if-bg--ghost {
  opacity: 1;
  background: linear-gradient(
    180deg,
    rgba(255, 255, 255, 0.16) 0%,
    rgba(255, 255, 255, 0.08) 100%
  );
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}
.ui-if-bg--light {
  opacity: 0;
  background: linear-gradient(
    180deg,
    rgba(255, 255, 255, 0.8) 0%,
    rgba(255, 255, 255, 0.4) 100%
  );
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.1),
    0 16px 36px 0 rgba(0, 0, 0, 0.06);
}
.ui-if-pill[data-phase="3"] .ui-if-bg--ghost {
  opacity: 0;
}
.ui-if-pill[data-phase="3"] .ui-if-bg--light {
  opacity: 1;
}
.ui-if-pill .ui-if-ring {
  transition: opacity var(--ui-if-step) var(--ui-if-step-ease);
}
.ui-if-pill .ui-if-ring--ghost {
  opacity: 1;
}
.ui-if-pill .ui-if-ring--light {
  opacity: 0;
}
.ui-if-pill[data-phase="3"] .ui-if-ring--ghost {
  opacity: 0;
}
.ui-if-pill[data-phase="3"] .ui-if-ring--light {
  opacity: 1;
}
.ui-if-pill .ui-if-title,
.ui-if-pill .ui-if-sub {
  transition: color var(--ui-if-step) var(--ui-if-step-ease);
}
.ui-if-pill .ui-if-title {
  color: rgba(255, 255, 255, 0.8);
}
.ui-if-pill .ui-if-sub {
  color: rgba(255, 255, 255, 0.4);
}
.ui-if-pill[data-phase="3"] .ui-if-title {
  color: rgba(0, 0, 0, 0.8);
}
.ui-if-pill[data-phase="3"] .ui-if-sub {
  color: rgba(0, 0, 0, 0.4);
}
.ui-if-pill .ui-if-icon {
  filter: brightness(0) invert(1);
  transition: filter var(--ui-if-step) var(--ui-if-step-ease);
}
.ui-if-pill[data-phase="3"] .ui-if-icon {
  filter: brightness(1) invert(0);
}
.ui-if-pill[data-phase="3"][data-fill="black"] .ui-if-icon {
  filter: brightness(0) invert(0);
}
@media (prefers-reduced-motion: reduce) {
  .ui-if-pill,
  .ui-if-bg,
  .ui-if-ring,
  .ui-if-icon,
  .ui-if-title,
  .ui-if-sub {
    transition: none;
  }
  .ui-if-blob {
    animation: none;
  }
  .ui-if-beam {
    opacity: 1;
    transform: translateX(45px);
  }
}
:where(.dark, [data-theme="dark"]) .ui-if {
  --ui-if-bg: #1f1f21;
  --ui-if-fade: #1f1f21;
}
:where(.dark, [data-theme="dark"]) .ui-if-blobs {
  opacity: 0.8;
}
:where(.dark, [data-theme="dark"]) .ui-if-blob--293 {
  display: none;
}
:where(.dark, [data-theme="dark"]) .ui-if-orbit-stop {
  stop-color: #ffd9cc;
}
:where(.dark, [data-theme="dark"]) .ui-if-glow {
  filter: blur(21.94px) opacity(0.45);
}
:where(.dark, [data-theme="dark"]) .ui-if-card--light,
:where(.dark, [data-theme="dark"]) .ui-if-bg--light {
  background: linear-gradient(
    180deg,
    rgba(38, 38, 41, 0.86) 0%,
    rgba(38, 38, 41, 0.62) 100%
  );
  box-shadow:
    inset 0 0 0 1px rgba(255, 255, 255, 0.08),
    0 16px 36px 0 rgba(0, 0, 0, 0.28);
}
:where(.dark, [data-theme="dark"]) .ui-if-bg--ghost {
  background: linear-gradient(
    180deg,
    rgba(255, 255, 255, 0.1) 0%,
    rgba(255, 255, 255, 0.04) 100%
  );
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-if-bg--charge-out {
  background: linear-gradient(
    90deg,
    rgba(255, 255, 255, 0.14) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-if-bg--charge-in {
  background: linear-gradient(
    270deg,
    rgba(255, 255, 255, 0.14) 0%,
    rgba(255, 255, 255, 0) 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-if-stop-light-a {
  stop-color: #ffffff;
  stop-opacity: 0.06;
}
:where(.dark, [data-theme="dark"]) .ui-if-stop-light-b {
  stop-color: #ffffff;
  stop-opacity: 0.14;
}
:where(.dark, [data-theme="dark"]) .ui-if-ring--light g {
  filter: var(--ui-if-ring-dark);
}
:where(.dark, [data-theme="dark"]) .ui-if-hub-icon {
  fill: rgba(255, 255, 255, 0.92);
}
:where(.dark, [data-theme="dark"]) .ui-if-hub .ui-if-title,
:where(.dark, [data-theme="dark"]) .ui-if-pill[data-phase="3"] .ui-if-title {
  color: rgba(255, 255, 255, 0.92);
}
:where(.dark, [data-theme="dark"]) .ui-if-hub .ui-if-sub,
:where(.dark, [data-theme="dark"]) .ui-if-pill[data-phase="3"] .ui-if-sub {
  color: rgba(255, 255, 255, 0.5);
}
:where(.dark, [data-theme="dark"])
  .ui-if-pill[data-phase="3"][data-fill="black"]
  .ui-if-icon {
  filter: brightness(0) invert(1);
}

.integration-flow-demo {
  width: 100%;
}
.stage .integration-flow-demo,
.card__preview .integration-flow-demo {
  border-radius: inherit;
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
  overflow: hidden;
  container-type: size;
}
.stage .integration-flow-demo .ui-if,
.card__preview .integration-flow-demo .ui-if {
  flex: none;
  width: max(100cqw, 161.074cqh);
}
@media (width<=640px) {
  .stage:has(.integration-flow-demo) {
    height: 270px;
    min-height: 0;
  }
}
.stage .integration-flow-demo:after,
.card__preview .integration-flow-demo:after {
  content: "";
  pointer-events: none;
  background: linear-gradient(#fff0 0%, #fff 92%);
  height: 22%;
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
}
:where(.dark, [data-theme="dark"]) .stage .integration-flow-demo:after,
:where(.dark, [data-theme="dark"]) .card__preview .integration-flow-demo:after {
  background: linear-gradient(#1f1f2100 0%, #1f1f21 92%);
}
`;export{n as default};
