const n=`.ui-is {
  --ui-is-tray: #f0f0f0;
  --ui-is-card: #ffffff;
  --ui-is-line: #f0f0f0;
  --ui-is-ink: #171717;
  --ui-is-text: #404040;
  --ui-is-muted: #626873;
  --ui-is-accent: #2f6bff;
  --ui-is-focus: rgba(0, 96, 226, 0.7);
  --ui-is-ok: #197840;
  --ui-is-danger: #bf383d;
  --ui-is-accent-text: #2a5ee5;
  --ui-is-border: #e5e5e5;
  --ui-is-ring: #e2e2e2;
  --ui-is-ring-strong: #d4d4d4;
  --ui-is-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-is-raised: #fff;
  --ui-is-raised-hover: #f7f7f7;
  --ui-is-well: #f5f5f5;
  --ui-is-well-hover: #efefef;
  --ui-is-field: #fff;
  --ui-is-hover: rgba(0, 0, 0, 0.05);
  --ui-is-switch-off: #d9d9d9;
  --ui-is-ok-soft: #f2fbf6;
  --ui-is-ok-ring: #cfeedd;
  --ui-is-track: #d4d4d4;
  --ui-is-placeholder: #626873;
  --ui-is-menu: #fff;
  --ui-is-menu-hover: #f5f5f5;
  --ui-is-menu-search: #f5f5f5;
  --ui-is-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 560px;
  background: var(--ui-is-tray);
  padding: 6px;
  border-radius: 22px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-is-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-is *,
.ui-is *::before,
.ui-is *::after {
  box-sizing: border-box;
}
.ui-is button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-is button:focus-visible {
  outline: 2px solid var(--ui-is-focus);
  outline-offset: 2px;
}
.ui-is__head {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 14px 16px 14px 14px;
}
.ui-is__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 40px;
  height: 40px;
  border-radius: 11px;
  background: var(--ui-is-raised);
  box-shadow:
    0 0 0 1px var(--ui-is-border),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-is__logo {
  overflow: hidden;
}
.ui-is__logo svg {
  width: 22px;
  height: 22px;
}
.ui-is__logo img {
  display: block;
  width: 22px;
  height: 22px;
  object-fit: contain;
}
.ui-is__initial {
  font-size: 16px;
  font-weight: 600;
  color: var(--ui-is-text);
}
.ui-is__who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-is__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
}
.ui-is__name-text {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-is__count {
  flex: none;
  padding: 0 6px;
  border-radius: 6px;
  background: var(--ui-is-raised);
  box-shadow: inset 0 0 0 1px var(--ui-is-ring);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 18px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-is-text);
}
.ui-is__meta {
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-is-muted);
}
.ui-is__switch {
  position: relative;
  flex: none;
  width: 40px;
  height: 24px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: var(--ui-is-switch-off);
  transition: background-color 220ms ease;
}
.ui-is__switch span {
  position: absolute;
  top: 3px;
  left: 3px;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18);
  transition: transform 280ms var(--ui-is-ease);
}
.ui-is__switch[aria-checked="true"] {
  background: var(--ui-is-accent);
}
.ui-is__switch[aria-checked="true"] span {
  transform: translateX(16px);
}
.ui-is__fold {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  transition:
    grid-template-rows 420ms var(--ui-is-ease),
    opacity 260ms ease;
  opacity: 0;
}
.ui-is__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-is__fold-inner {
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}
.ui-is__fold[data-open] .ui-is__fold-inner {
  overflow: visible;
}
.ui-is__card {
  background: var(--ui-is-card);
  border: 1px solid var(--ui-is-border);
  border-radius: 16px;
  box-shadow: var(--ui-is-shadow);
}
.ui-is__section {
  padding: 16px 18px 18px;
}
.ui-is__section + .ui-is__section {
  border-top: 1px solid var(--ui-is-line);
}
.ui-is__label {
  display: block;
  margin-bottom: 8px;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
}
.ui-is__generate {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: 100%;
  height: 42px;
  padding: 0 14px;
  border: 0;
  border-radius: 11px;
  background: var(--ui-is-well);
  font-size: 14px !important;
  color: var(--ui-is-muted) !important;
  text-align: left;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-is__generate:hover:not(:disabled) {
  background: var(--ui-is-well-hover);
  color: var(--ui-is-ink) !important;
}
.ui-is__generate:disabled {
  cursor: progress;
}
.ui-is__key {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 42px;
  padding: 0 6px 0 14px;
  border-radius: 11px;
  background: var(--ui-is-well);
  animation: ui-is-in 320ms var(--ui-is-ease);
}
.ui-is__key[data-new] {
  background: var(--ui-is-ok-soft);
  box-shadow: inset 0 0 0 1px var(--ui-is-ok-ring);
}
.ui-is__key code {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12.5px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-is-text);
}
.ui-is__mini {
  display: grid;
  place-items: center;
  flex: none;
  width: 30px;
  height: 30px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-is-muted) !important;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-is__mini:hover {
  background: var(--ui-is-hover);
  color: var(--ui-is-ink) !important;
}
.ui-is__regen {
  display: grid;
  place-items: center;
  min-width: 92px;
  height: 30px;
  margin-left: 2px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: var(--ui-is-raised);
  box-shadow: 0 0 0 1px var(--ui-is-border);
  font-size: 12.5px !important;
  font-weight: 500;
}
.ui-is__regen:hover:not(:disabled) {
  background: var(--ui-is-raised-hover);
}
.ui-is__note {
  margin: 8px 0 0;
  font-size: 12.5px;
  color: var(--ui-is-ok);
}
.ui-is__spinner {
  width: 14px;
  height: 14px;
  border: 1.5px solid var(--ui-is-track);
  border-top-color: var(--ui-is-ink);
  border-radius: 50%;
  animation: ui-is-spin 700ms linear infinite;
}
.ui-is__field {
  display: flex;
  align-items: center;
  gap: 4px;
  width: 100%;
  height: 42px;
  padding: 0 14px;
  border: 0;
  border-radius: 11px;
  background: var(--ui-is-field);
  box-shadow:
    0 0 0 1px var(--ui-is-ring),
    0 1px 2px rgba(0, 0, 0, 0.03);
  transition: box-shadow 160ms ease;
}
.ui-is__field:focus-within {
  box-shadow:
    0 0 0 1px color-mix(in srgb, var(--ui-is-muted) 60%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.03);
}
.ui-is__field[data-invalid] {
  box-shadow:
    0 0 0 1px var(--ui-is-danger),
    0 0 0 4px rgba(229, 72, 77, 0.1);
}
.ui-is__prefix {
  font-size: 14px;
  color: var(--ui-is-placeholder);
}
.ui-is__field input {
  flex: 1;
  min-width: 0;
  height: 100%;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  font-size: 14px;
  color: var(--ui-is-ink);
}
.ui-is__field input::placeholder {
  color: var(--ui-is-placeholder);
}
.ui-is__ok {
  display: grid;
  color: var(--ui-is-ok);
  animation: ui-is-in 240ms var(--ui-is-ease);
}
.ui-is__hint {
  overflow-wrap: anywhere;
  margin: 8px 0 0;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-is-muted);
}
.ui-is__hint[data-error] {
  color: var(--ui-is-danger);
}
.ui-is__zone {
  position: relative;
}
.ui-is__zone-value {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-is__zone-btn {
  justify-content: space-between;
  gap: 8px;
  font-size: 14px !important;
  text-align: left;
}
.ui-is__zone-btn:hover {
  box-shadow:
    0 0 0 1px var(--ui-is-ring-strong),
    0 1px 2px rgba(0, 0, 0, 0.03);
}
.ui-is__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 10;
  padding: 6px;
  border-radius: 14px;
  background: var(--ui-is-menu);
  box-shadow:
    0 0 0 1px var(--ui-is-border),
    0 14px 36px -10px rgba(0, 0, 0, 0.22);
  animation: ui-is-drop 180ms var(--ui-is-ease);
}
.ui-is__menu-search {
  width: 100%;
  height: 34px;
  margin-bottom: 4px;
  padding: 0 10px;
  border: 0;
  border-radius: 9px;
  outline: none;
  background: var(--ui-is-menu-search);
  font: inherit;
  font-size: 13px;
}
.ui-is__menu-list {
  display: grid;
  gap: 2px;
  max-height: 200px;
  overflow-y: auto;
  scrollbar-width: thin;
}
.ui-is__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 32px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 13px !important;
  text-align: left;
}
.ui-is__option:hover {
  background: var(--ui-is-menu-hover);
}
.ui-is__option[aria-selected="true"] {
  color: var(--ui-is-accent-text) !important;
  font-weight: 500;
}
.ui-is__menu-empty {
  margin: 0;
  padding: 12px 10px;
  font-size: 13px;
  color: var(--ui-is-muted);
}
.ui-is__save {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  transition: grid-template-rows 360ms var(--ui-is-ease);
}
.ui-is__save[data-open] {
  grid-template-rows: 1fr;
}
.ui-is__save-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 0;
  overflow: hidden;
  padding: 0 8px 0 18px;
  font-size: 13px;
  color: var(--ui-is-text);
}
.ui-is__save[data-open] .ui-is__save-inner {
  padding-top: 8px;
  padding-bottom: 8px;
}
.ui-is__save-actions {
  display: flex;
  gap: 6px;
}
.ui-is__btn {
  height: 32px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-is-raised);
  box-shadow:
    0 0 0 1px var(--ui-is-border),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 13px !important;
  font-weight: 500;
}
.ui-is__btn:hover {
  background: var(--ui-is-raised-hover);
}
.ui-is__btn--primary {
  background: linear-gradient(#323137, #201e25);
  box-shadow:
    0 0 0 1px #0d0d0d,
    0 2px 4px rgba(0, 0, 0, 0.1),
    inset 0 1px 0 rgba(255, 255, 255, 0.12);
  color: #fff !important;
}
.ui-is__btn--primary:hover {
  background: linear-gradient(#3b3a41, #26242b);
}
.ui-is__btn--primary:disabled {
  opacity: 0.5;
  cursor: default;
}
@keyframes ui-is-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@keyframes ui-is-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-is-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-is__fold,
  .ui-is__save,
  .ui-is__switch,
  .ui-is__switch span {
    transition: none;
  }
  .ui-is__key,
  .ui-is__menu,
  .ui-is__ok {
    animation: none;
  }
}
.ui-is input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-is textarea:focus-visible,
.ui-is [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-is {
  --ui-is-tray: #161618;
  --ui-is-card: #232326;
  --ui-is-line: rgba(255, 255, 255, 0.08);
  --ui-is-ink: #ededed;
  --ui-is-text: #c4c4c4;
  --ui-is-muted: #8f8f8f;
  --ui-is-ok: #3dbb6f;
  --ui-is-danger: #ff6369;
  --ui-is-accent-text: #6b95ff;
  --ui-is-border: rgba(255, 255, 255, 0.08);
  --ui-is-ring: rgba(255, 255, 255, 0.08);
  --ui-is-focus: rgba(77, 141, 255, 0.8);
  --ui-is-ring-strong: rgba(255, 255, 255, 0.14);
  --ui-is-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-is-raised: #2a2a2d;
  --ui-is-raised-hover: #313135;
  --ui-is-well: #2a2a2d;
  --ui-is-well-hover: #313135;
  --ui-is-field: #2a2a2d;
  --ui-is-hover: rgba(255, 255, 255, 0.06);
  --ui-is-switch-off: #3a3a3e;
  --ui-is-ok-soft: rgba(61, 187, 111, 0.14);
  --ui-is-ok-ring: rgba(61, 187, 111, 0.3);
  --ui-is-track: rgba(255, 255, 255, 0.14);
  --ui-is-placeholder: #6b6b70;
  --ui-is-menu: #2a2a2d;
  --ui-is-menu-hover: #313135;
  --ui-is-menu-search: #1f1f21;
}
:where(.dark, [data-theme="dark"]) .ui-is__menu {
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.1),
    0 14px 36px -10px rgba(0, 0, 0, 0.55);
}
:where(.dark, [data-theme="dark"]) .ui-is__menu-search {
  color: var(--ui-is-ink);
}
:where(.dark, [data-theme="dark"]) .ui-is__menu-search::placeholder {
  color: var(--ui-is-placeholder);
}
:where(.dark, [data-theme="dark"]) .ui-is__switch span {
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.45);
}
:where(.dark, [data-theme="dark"]) .ui-is__field:focus-within {
  box-shadow:
    0 0 0 1px color-mix(in srgb, var(--ui-is-muted) 60%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-is__field[data-invalid] {
  box-shadow:
    0 0 0 1px var(--ui-is-danger),
    0 0 0 4px rgba(255, 99, 105, 0.16);
}
:where(.dark, [data-theme="dark"]) .ui-is__btn--primary {
  background: linear-gradient(#f4f4f5, #e4e4e7);
  box-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.6),
    0 2px 4px rgba(0, 0, 0, 0.35),
    inset 0 1px 0 #ffffff;
  color: #121213 !important;
}
:where(.dark, [data-theme="dark"]) .ui-is__btn--primary:hover {
  background: linear-gradient(#ffffff, #ececef);
}
`;export{n as default};
