const n=`.ui-isc {
  --ui-isc-card: #ffffff;
  --ui-isc-ink: rgba(0, 0, 0, 0.88);
  --ui-isc-strong: #000000;
  --ui-isc-text: rgba(0, 0, 0, 0.65);
  --ui-isc-muted: rgba(0, 0, 0, 0.65);
  --ui-isc-faint: rgba(0, 0, 0, 0.65);
  --ui-isc-icon: rgba(0, 0, 0, 0.65);
  --ui-isc-line: rgba(0, 0, 0, 0.06);
  --ui-isc-fill: rgba(0, 0, 0, 0.06);
  --ui-isc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-isc-wash: rgba(0, 0, 0, 0.03);
  --ui-isc-accent: #0060e2;
  --ui-isc-ok: #0f783c;
  --ui-isc-ok-soft: rgba(26, 154, 82, 0.08);
  --ui-isc-danger: #bf383d;
  --ui-isc-danger-soft: rgba(229, 72, 77, 0.08);
  --ui-isc-solid: rgba(0, 0, 0, 0.88);
  --ui-isc-solid-hover: rgba(0, 0, 0, 0.8);
  --ui-isc-on-solid: #fcfcfc;
  --ui-isc-switch-off: rgba(0, 0, 0, 0.12);
  --ui-isc-shine: rgba(255, 255, 255, 0.82);
  --ui-isc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-isc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.12), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-isc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-isc-focus: rgba(0, 96, 226, 0.7);
  --ui-isc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 560px;
  border-radius: 10px;
  background: var(--ui-isc-card);
  box-shadow: var(--ui-isc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-isc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-isc *,
.ui-isc *::before,
.ui-isc *::after {
  box-sizing: border-box;
}
:where(.ui-isc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-isc) svg {
  display: block;
  flex: none;
}
.ui-isc button:focus-visible {
  outline: 2px solid var(--ui-isc-focus);
  outline-offset: 2px;
}
.ui-isc__head {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px;
}
.ui-isc__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 40px;
  height: 40px;
  border-radius: 8px;
  background: var(--ui-isc-card);
  box-shadow: var(--ui-isc-shadow);
}
.ui-isc__logo {
  overflow: hidden;
}
.ui-isc__logo svg {
  width: 22px;
  height: 22px;
}
.ui-isc__logo img {
  display: block;
  width: 22px;
  height: 22px;
  object-fit: contain;
}
.ui-isc__initial {
  font-size: 15px;
  font-weight: 600;
  color: var(--ui-isc-text);
}
.ui-isc__who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-isc__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-isc-strong);
}
.ui-isc__name-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-isc__count {
  flex: none;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-isc-fill);
  font-size: 11px;
  line-height: 16px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-isc-text);
}
.ui-isc__meta {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-isc-muted);
}
.ui-isc__switch {
  position: relative;
  flex: none;
  width: 28px;
  height: 16px;
  border-radius: 8px;
  background: var(--ui-isc-switch-off) !important;
  transition: background-color 220ms ease;
}
.ui-isc__switch[aria-checked="true"] {
  background: var(--ui-isc-accent) !important;
}
.ui-isc__switch span {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #fff;
  box-shadow: var(--ui-isc-shadow);
  transition: transform 280ms var(--ui-isc-ease);
}
.ui-isc__switch[aria-checked="true"] span {
  transform: translateX(12px);
}
.ui-isc__switch::after {
  content: "";
  position: absolute;
  inset: -8px -6px;
}
.ui-isc__fold {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-isc-ease),
    opacity 260ms ease;
}
.ui-isc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-isc__fold-inner {
  min-width: 0;
  min-height: 0;
  overflow: hidden;
}
.ui-isc__fold[data-open] .ui-isc__fold-inner {
  overflow: visible;
}
.ui-isc__section {
  padding: 14px 16px 16px;
  border-top: 0.5px solid var(--ui-isc-line);
}
.ui-isc__label {
  display: block;
  margin: 0 0 6px;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-isc-ink);
}
.ui-isc__generate {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px 0 10px !important;
  border-radius: 8px;
  background: var(--ui-isc-wash) !important;
  box-shadow: inset 0 0 0 0.5px var(--ui-isc-line);
  color: var(--ui-isc-text) !important;
  text-align: left;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-isc__generate svg {
  color: var(--ui-isc-icon);
  transition: color 160ms ease;
}
.ui-isc__generate:hover:not(:disabled) {
  background: var(--ui-isc-fill) !important;
  color: var(--ui-isc-ink) !important;
}
.ui-isc__generate:hover:not(:disabled) svg {
  color: var(--ui-isc-ink);
}
.ui-isc__generate:disabled {
  cursor: progress;
}
.ui-isc__key {
  display: flex;
  align-items: center;
  gap: 2px;
  height: 36px;
  padding: 0 4px 0 10px;
  border-radius: 8px;
  background: var(--ui-isc-card);
  box-shadow: var(--ui-isc-shadow);
  transition: background-color 240ms ease;
  animation: ui-isc-in 320ms var(--ui-isc-ease);
}
.ui-isc__key[data-new] {
  background: var(--ui-isc-ok-soft);
  box-shadow: none;
}
.ui-isc__key code {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-isc-ink);
}
.ui-isc__mini {
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-isc-icon) !important;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-isc__mini:hover {
  background: var(--ui-isc-wash) !important;
  color: var(--ui-isc-ink) !important;
}
.ui-isc__key[data-new] .ui-isc__mini:hover {
  background: var(--ui-isc-fill) !important;
}
.ui-isc__regen {
  display: grid;
  place-items: center;
  flex: none;
  min-width: 88px;
  height: 28px;
  margin-left: 2px;
  padding: 0 10px !important;
  border-radius: 6px;
  background: var(--ui-isc-card) !important;
  box-shadow: var(--ui-isc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-isc-strong) !important;
  transition: box-shadow 140ms ease;
}
.ui-isc__regen:hover:not(:disabled) {
  box-shadow: var(--ui-isc-shadow-hover);
}
.ui-isc__regen:disabled {
  cursor: progress;
}
.ui-isc__note {
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-isc-ok);
  animation: ui-isc-in 240ms var(--ui-isc-ease);
}
.ui-isc__spinner {
  width: 14px;
  height: 14px;
  border: 1.5px solid var(--ui-isc-fill-strong);
  border-top-color: var(--ui-isc-ink);
  border-radius: 50%;
  animation: ui-isc-spin 700ms linear infinite;
}
.ui-isc__field {
  display: flex;
  align-items: center;
  gap: 2px;
  width: 100%;
  height: 32px;
  padding: 0 8px 0 10px;
  border-radius: 8px;
  background: var(--ui-isc-card);
  box-shadow: var(--ui-isc-shadow);
  transition:
    box-shadow 160ms ease,
    background-color 160ms ease;
}
.ui-isc__field:hover {
  box-shadow: var(--ui-isc-shadow-hover);
}
.ui-isc__field:focus-within {
  outline: none;
  box-shadow: var(--ui-isc-shadow-hover);
}
.ui-isc__field[data-invalid] {
  background: var(--ui-isc-danger-soft);
  box-shadow: none;
}
.ui-isc__field[data-invalid]:focus-within {
  box-shadow: inset 0 0 0 0.5px rgba(229, 72, 77, 0.35);
}
.ui-isc__prefix {
  flex: none;
  color: var(--ui-isc-faint);
}
.ui-isc__field input {
  flex: 1;
  min-width: 0;
  height: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  color: var(--ui-isc-ink);
}
.ui-isc__field input::placeholder {
  color: var(--ui-isc-faint);
}
.ui-isc__ok {
  display: grid;
  flex: none;
  color: var(--ui-isc-ok);
  animation: ui-isc-in 240ms var(--ui-isc-ease);
}
.ui-isc__hint {
  overflow-wrap: anywhere;
  margin: 6px 0 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-isc-muted);
}
.ui-isc__hint[data-error] {
  color: var(--ui-isc-danger);
}
.ui-isc__zone {
  position: relative;
}
.ui-isc__zone-btn {
  justify-content: space-between;
  gap: 8px;
  padding: 0 8px 0 10px !important;
  text-align: left;
  background: var(--ui-isc-card) !important;
  color: var(--ui-isc-ink) !important;
}
.ui-isc__zone-btn:focus-visible {
  outline-offset: 2px;
}
.ui-isc__zone-value {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-isc__zone-btn svg {
  color: var(--ui-isc-icon);
}
.ui-isc__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 10;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-isc-card);
  box-shadow: var(--ui-isc-shadow-pop);
  transform-origin: top center;
  animation: ui-isc-drop 200ms var(--ui-isc-ease);
}
.ui-isc__menu-search {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 32px;
  margin: 0 0 4px;
  padding: 0 8px;
  border-bottom: 0.5px solid var(--ui-isc-line);
  color: var(--ui-isc-icon);
}
.ui-isc__menu-search input {
  flex: 1;
  min-width: 0;
  height: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  color: var(--ui-isc-ink);
}
.ui-isc__menu-search input::placeholder {
  color: var(--ui-isc-faint);
}
.ui-isc__menu-list {
  display: grid;
  gap: 1px;
  max-height: 200px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-isc__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 32px;
  padding: 0 8px !important;
  border-radius: 6px;
  background: transparent;
  color: var(--ui-isc-ink) !important;
  text-align: left;
  transition: background-color 90ms ease-out;
}
.ui-isc__option:hover {
  background: var(--ui-isc-fill) !important;
}
.ui-isc__option svg {
  color: var(--ui-isc-accent);
  animation: ui-isc-pop 260ms var(--ui-isc-ease);
}
.ui-isc__menu-empty {
  margin: 0;
  padding: 10px 8px;
  text-align: center;
  color: var(--ui-isc-muted);
}
.ui-isc__save {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: 0fr;
  transition: grid-template-rows 360ms var(--ui-isc-ease);
}
.ui-isc__save[data-open] {
  grid-template-rows: 1fr;
}
.ui-isc__save-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 0;
  overflow: hidden;
  padding: 0 12px 0 16px;
  border-top: 0.5px solid var(--ui-isc-line);
  color: var(--ui-isc-text);
}
.ui-isc__save[data-open] .ui-isc__save-inner {
  padding-top: 10px;
  padding-bottom: 10px;
}
.ui-isc__save-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-isc__save-actions {
  display: flex;
  flex: none;
  gap: 6px;
}
.ui-isc__btn {
  height: 28px;
  padding: 0 10px !important;
  border-radius: 6px;
  background: var(--ui-isc-card) !important;
  box-shadow: var(--ui-isc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-isc-strong) !important;
  transition:
    box-shadow 140ms ease,
    background-color 140ms ease;
}
.ui-isc__btn:hover:not(:disabled) {
  box-shadow: var(--ui-isc-shadow-hover);
}
.ui-isc__btn--primary {
  min-width: 56px;
  background: var(--ui-isc-solid) !important;
  box-shadow: none;
  color: var(--ui-isc-on-solid) !important;
}
.ui-isc__btn--primary:hover:not(:disabled) {
  background: var(--ui-isc-solid-hover) !important;
  box-shadow: none;
}
.ui-isc__btn--primary:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-isc__shimmer {
  position: relative;
  display: inline-block;
}
.ui-isc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-isc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-isc-sweep 1.4s linear infinite;
  pointer-events: none;
}
@keyframes ui-isc-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@keyframes ui-isc-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-isc-pop {
  from {
    opacity: 0;
    transform: scale(0.5);
  }
}
@keyframes ui-isc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-isc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 400px) {
  .ui-isc__head {
    gap: 10px;
    padding: 14px 14px 14px 12px;
  }
  .ui-isc__logo {
    width: 36px;
    height: 36px;
  }
  .ui-isc__logo svg {
    width: 20px;
    height: 20px;
  }
  .ui-isc__section {
    padding: 12px 12px 14px;
  }
  .ui-isc__regen {
    min-width: 0;
  }
  .ui-isc__save-inner {
    padding: 0 10px 0 12px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-isc__field,
  .ui-isc__generate {
    height: 40px;
  }
  .ui-isc__field input,
  .ui-isc__menu-search input {
    font-size: 16px;
  }
  .ui-isc__key {
    height: 44px;
  }
  .ui-isc__mini {
    width: 36px;
    height: 36px;
  }
  .ui-isc__regen,
  .ui-isc__btn {
    height: 36px;
  }
  .ui-isc__menu-search {
    height: 40px;
  }
  .ui-isc__option {
    min-height: 44px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-isc *,
  .ui-isc *::before,
  .ui-isc *::after {
    animation: none !important;
    transition: none !important;
  }
}
.ui-isc input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-isc textarea:focus-visible,
.ui-isc [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-isc {
  --ui-isc-card: #1c1c1e;
  --ui-isc-ink: rgba(255, 255, 255, 0.9);
  --ui-isc-strong: #ffffff;
  --ui-isc-text: rgba(255, 255, 255, 0.62);
  --ui-isc-muted: rgba(255, 255, 255, 0.46);
  --ui-isc-faint: rgba(255, 255, 255, 0.3);
  --ui-isc-icon: rgba(255, 255, 255, 0.5);
  --ui-isc-line: rgba(255, 255, 255, 0.08);
  --ui-isc-fill: rgba(255, 255, 255, 0.08);
  --ui-isc-fill-strong: rgba(255, 255, 255, 0.13);
  --ui-isc-wash: rgba(255, 255, 255, 0.04);
  --ui-isc-accent: #4d8dff;
  --ui-isc-ok: #3ec27a;
  --ui-isc-ok-soft: rgba(62, 194, 122, 0.14);
  --ui-isc-danger: #ff6369;
  --ui-isc-danger-soft: rgba(255, 99, 105, 0.14);
  --ui-isc-solid: rgba(255, 255, 255, 0.9);
  --ui-isc-solid-hover: rgba(255, 255, 255, 0.82);
  --ui-isc-on-solid: #161618;
  --ui-isc-switch-off: rgba(255, 255, 255, 0.16);
  --ui-isc-shine: #ffffff;
  --ui-isc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-isc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-isc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-isc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-isc__switch span {
  background: #f4f4f5;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-isc__menu {
  background: #232326;
}
`;export{n as default};
