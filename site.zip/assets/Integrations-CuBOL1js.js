const n=`.ui-fd {
  --ui-fd-ease: cubic-bezier(0.2, 0.85, 0.25, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  overflow: hidden;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    sans-serif;
}
.ui-fd-icon {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 40%;
  aspect-ratio: 6 / 5;
  container-type: inline-size;
  perspective: 220cqw;
  perspective-origin: 50% 60%;
  transform: translate(-50%, -48%);
  transition: transform 0.6s var(--ui-fd-ease);
}
.ui-fd-icon:hover {
  transform: translate(-50%, -48%) scale(1.03);
}
.ui-fd-layer {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.ui-fd-back {
  filter: drop-shadow(0 4cqw 4.6cqw rgba(60, 130, 180, 0.28))
    drop-shadow(0 1.3cqw 2cqw rgba(60, 130, 180, 0.16))
    drop-shadow(0 0.3cqw 0.7cqw rgba(60, 130, 180, 0.1));
}
.ui-fd-doc {
  transform-box: fill-box;
  transform-origin: center;
  filter: drop-shadow(0 3px 4px rgba(0, 30, 60, 0.18));
  transition: transform 0.55s var(--ui-fd-ease);
}
.ui-fd-doc--left {
  transform: translate(40px, 80px) rotate(6deg);
}
.ui-fd-doc--right {
  transform: translate(280px, 80px) rotate(6deg);
}
.ui-fd-doc--middle {
  transform: translate(160px, 66px) rotate(-4deg);
}
.ui-fd-icon:hover .ui-fd-doc--left {
  transform: translate(32px, 70px) rotate(9deg);
}
.ui-fd-icon:hover .ui-fd-doc--right {
  transform: translate(286px, 76px) rotate(5deg);
}
.ui-fd-icon:hover .ui-fd-doc--middle {
  transform: translate(166px, 52px) rotate(-7deg);
}
.ui-fd-front {
  position: absolute;
  inset: 21.6% 0 0;
  border-radius: 6.333cqw;
  background:
    linear-gradient(180deg, rgba(0, 40, 75, 0) 74%, rgba(0, 40, 75, 0.28) 100%),
    linear-gradient(
      180deg,
      rgba(132, 214, 248, 0.45) 0%,
      rgba(69, 170, 220, 0.45) 100%
    );
  box-shadow:
    inset 0 0 0 0.67cqw rgba(255, 255, 255, 0.3),
    inset 0 0.25cqw 0 rgba(255, 255, 255, 0.55);
  -webkit-backdrop-filter: blur(3.3cqw) saturate(1.1);
  backdrop-filter: blur(3.3cqw) saturate(1.1);
  transform-origin: 50% 100%;
  transition:
    top 0.6s var(--ui-fd-ease),
    border-radius 0.6s var(--ui-fd-ease),
    transform 0.6s var(--ui-fd-ease);
}
.ui-fd-icon:hover .ui-fd-front {
  top: 24.8%;
  border-radius: 3cqw 3cqw 6.333cqw 6.333cqw;
  transform: translateZ(2.33cqw) rotateX(-9deg);
}
:where(.dark, [data-theme="dark"]) .ui-fd-back-fill {
  fill: #3d8fc6;
}
:where(.dark, [data-theme="dark"]) .ui-fd-paper-top {
  stop-color: #34363c;
}
:where(.dark, [data-theme="dark"]) .ui-fd-paper-bottom {
  stop-color: #26292f;
}
:where(.dark, [data-theme="dark"]) .ui-fd-paper {
  stroke: rgba(255, 255, 255, 0.1);
}
:where(.dark, [data-theme="dark"]) .ui-fd-line {
  fill: rgba(255, 255, 255, 0.16);
}
:where(.dark, [data-theme="dark"]) .ui-fd-back {
  filter: drop-shadow(0 4cqw 4.6cqw rgba(0, 0, 0, 0.45))
    drop-shadow(0 1.3cqw 2cqw rgba(0, 0, 0, 0.3));
}
:where(.dark, [data-theme="dark"]) .ui-fd-doc {
  filter: drop-shadow(0 3px 4px rgba(0, 0, 0, 0.45));
}
:where(.dark, [data-theme="dark"]) .ui-fd-front {
  background:
    linear-gradient(180deg, rgba(0, 20, 40, 0) 70%, rgba(0, 20, 40, 0.4) 100%),
    linear-gradient(
      180deg,
      rgba(100, 190, 235, 0.42) 0%,
      rgba(45, 130, 190, 0.5) 100%
    );
  box-shadow:
    inset 0 0 0 0.67cqw rgba(255, 255, 255, 0.14),
    inset 0 0.25cqw 0 rgba(255, 255, 255, 0.3);
}
@media (prefers-reduced-motion: reduce) {
  .ui-fd-icon,
  .ui-fd-doc,
  .ui-fd-front {
    transition: none;
  }
}

.ui-agtc {
  --ui-agtc-card: #ffffff;
  --ui-agtc-strong: #000000;
  --ui-agtc-ink: rgba(0, 0, 0, 0.88);
  --ui-agtc-text: rgba(0, 0, 0, 0.61);
  --ui-agtc-muted: rgba(0, 0, 0, 0.45);
  --ui-agtc-faint: rgba(0, 0, 0, 0.27);
  --ui-agtc-line: rgba(0, 0, 0, 0.06);
  --ui-agtc-fill: rgba(0, 0, 0, 0.06);
  --ui-agtc-accent: rgba(0, 96, 226, 0.765);
  --ui-agtc-link: #83c7fe;
  --ui-agtc-link-muted: rgba(0, 0, 0, 0.12);
  --ui-agtc-brand-bg: #008ff519;
  --ui-agtc-brand-fg: #006dcbf2;
  --ui-agtc-ok-bg: #00a43319;
  --ui-agtc-ok-fg: #007d2ee0;
  --ui-agtc-warn-bg: #ff9c0029;
  --ui-agtc-warn-fg: #b25e00;
  --ui-agtc-danger-bg: #f52b0018;
  --ui-agtc-danger-fg: #d72400da;
  --ui-agtc-focus: rgba(0, 96, 226, 0.7);
  --ui-agtc-solid: rgba(0, 0, 0, 0.88);
  --ui-agtc-on-solid: #fcfcfc;
  --ui-agtc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-agtc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-agtc-card-w: 216px;
  --ui-agtc-indent: 32px;
  --ui-agtc-shine: rgba(0, 0, 0, 0.22);
  --ui-agtc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-agtc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-agtc *,
.ui-agtc *::before,
.ui-agtc *::after {
  box-sizing: border-box;
}
:where(.ui-agtc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-agtc button:focus-visible {
  outline: 2px solid var(--ui-agtc-focus);
  outline-offset: 2px;
}
.ui-agtc p {
  margin: 0;
}
.ui-agtc svg {
  display: block;
  flex: none;
}
.ui-agtc__bar {
  position: relative;
  z-index: 3;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  min-width: 0;
  margin-bottom: 16px;
}
.ui-agtc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-agtc-accent);
}
.ui-agtc__title {
  flex: 1 1 0;
  min-width: min(160px, 100%);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-agtc-strong);
}
.ui-agtc__sum {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  align-items: center;
  gap: 4px 10px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agtc__sum-run {
  color: var(--ui-agtc-brand-fg);
}
.ui-agtc__sum-wait {
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__sum-fail {
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__sum-cost {
  min-width: 44px;
  color: var(--ui-agtc-ink);
  font-weight: 500;
  text-align: right;
}
.ui-agtc__sum-btn {
  display: inline-flex;
  flex: none;
  white-space: nowrap;
  align-items: center;
  gap: 2px;
  height: 22px;
  margin: -3px 0;
  padding: 0 4px 0 7px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 500;
  transition: background-color 160ms ease;
}
.ui-agtc__sum-btn[data-kind="waiting"] {
  background: var(--ui-agtc-warn-bg);
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__sum-btn[data-kind="failed"] {
  background: var(--ui-agtc-danger-bg);
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__sum-btn:hover {
  filter: saturate(1.3) brightness(0.97);
}
.ui-agtc__sum-btn > svg {
  transition: transform 220ms var(--ui-agtc-ease);
}
.ui-agtc__sum-btn[aria-expanded="true"] > svg {
  transform: rotate(180deg);
}
.ui-agtc__pop {
  max-height: min(440px, 70vh);
  overflow-y: auto;
  overscroll-behavior: contain;
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  z-index: 5;
  display: grid;
  gap: 4px;
  width: 300px;
  max-width: 100%;
  padding: 6px;
  border-radius: 10px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-pop);
  animation: ui-agtc-pop 200ms var(--ui-agtc-ease) both;
}
.ui-agtc__pop-item {
  min-width: 0;
  display: grid;
  gap: 4px;
  padding: 8px 8px 8px;
  border-radius: 7px;
}
.ui-agtc__pop-item + .ui-agtc__pop-item {
  border-top: 0.5px solid var(--ui-agtc-line);
  border-radius: 0 0 7px 7px;
}
.ui-agtc__pop-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agtc__pop-head .ui-agtc__status {
  width: 20px;
  padding: 0;
  justify-content: center;
}
.ui-agtc__pop-name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-agtc-strong);
}
.ui-agtc__pop-task {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-agtc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__pop-text {
  overflow-wrap: anywhere;
  padding-left: 28px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-text);
}
.ui-agtc__pop-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 4px;
}
.ui-agtc__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-agtc-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-agtc__btn:hover {
  background: var(--ui-agtc-fill);
}
.ui-agtc__btn--primary {
  background: var(--ui-agtc-solid);
  box-shadow: none;
  color: var(--ui-agtc-on-solid);
}
.ui-agtc__btn--primary:hover {
  background: var(--ui-agtc-solid);
  opacity: 0.88;
}
.ui-agtc__tree {
  position: relative;
  display: grid;
  justify-items: center;
}
.ui-agtc__links {
  position: absolute;
  top: 0;
  left: 0;
  overflow: visible;
  pointer-events: none;
}
.ui-agtc__link {
  fill: none;
  stroke: var(--ui-agtc-link);
  stroke-width: 1.5;
  stroke-linecap: round;
  transition: stroke 240ms ease;
}
.ui-agtc__links [data-muted] .ui-agtc__link {
  stroke: var(--ui-agtc-link-muted);
}
.ui-agtc__links [data-fresh] .ui-agtc__link {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 1;
  animation: ui-agtc-draw 420ms var(--ui-agtc-ease) both;
}
.ui-agtc__dots {
  z-index: 2;
}
.ui-agtc__dot {
  fill: var(--ui-agtc-card);
  stroke: var(--ui-agtc-link);
  stroke-width: 1.5;
  transition: stroke 240ms ease;
}
.ui-agtc__dot[data-muted] {
  stroke: var(--ui-agtc-link-muted);
}
.ui-agtc__root {
  position: relative;
  z-index: 1;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside] {
  display: grid;
  grid-template-columns: minmax(0, 1fr) var(--ui-agtc-card-w) minmax(0, 1fr);
  align-items: start;
  width: 100%;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside] > :first-child {
  grid-column: 2;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside]:has(+ .ui-agtc__level) {
  margin-right: 0;
  padding-right: var(--ui-agtc-indent);
}
.ui-agtc__beside {
  width: var(--ui-agtc-card-w);
}
.ui-agtc[data-wide] .ui-agtc__beside {
  grid-column: 3;
  justify-self: start;
  margin-left: 56px;
}
.ui-agtc:not([data-wide]) .ui-agtc__beside {
  width: auto;
  margin: 12px 0 0 var(--ui-agtc-step);
}
.ui-agtc__links [data-dashed] .ui-agtc__link {
  stroke-dasharray: 3 4;
  stroke-dashoffset: 0;
  animation: none;
}
.ui-agtc__level {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  gap: 8px;
  width: 100%;
  margin-top: 40px;
}
.ui-agtc__level > .ui-agtc__hang {
  flex: none;
  width: calc(
    var(--ui-agtc-card-w) + var(--ui-agtc-indent) * var(--ui-agtc-col, 1)
  );
}
.ui-agtc[data-wide] .ui-agtc__root:has(+ .ui-agtc__level) {
  margin-right: var(--ui-agtc-indent);
}
.ui-agtc__hang {
  display: grid;
  align-content: start;
  gap: 12px;
}
.ui-agtc__below {
  display: grid;
  gap: 12px;
  padding-left: var(--ui-agtc-indent);
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  justify-items: stretch;
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  container-type: inline-size;
}
.ui-agtc__node {
  width: var(--ui-agtc-card-w);
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  --ui-agtc-step: min(
    var(--ui-agtc-indent),
    max(12px, (100cqw - 180px) / max(1, var(--ui-agtc-depth, 1)))
  );
}
.ui-agtc:not([data-wide]) .ui-agtc__node {
  width: calc(100cqw - var(--ui-agtc-depth, 0) * var(--ui-agtc-step));
}
.ui-agtc:not([data-wide]) .ui-agtc__below {
  padding-left: var(--ui-agtc-step);
}
.ui-agtc:not([data-wide]) .ui-agtc__level {
  display: grid;
  gap: 12px;
  margin-top: 12px;
  padding-left: var(--ui-agtc-step);
}
.ui-agtc:not([data-wide]) .ui-agtc__level {
  justify-content: stretch;
}
.ui-agtc:not([data-wide]) .ui-agtc__level > .ui-agtc__hang {
  width: auto;
}
.ui-agtc__node {
  position: relative;
  display: grid;
  gap: 6px;
  padding: 10px 10px 8px;
  border-radius: 8px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  animation: ui-agtc-rise 360ms var(--ui-agtc-ease) both;
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-agtc__node[data-leaving] {
  animation: ui-agtc-leave 280ms var(--ui-agtc-ease) forwards;
  pointer-events: none;
}
.ui-agtc__links [data-leaving] .ui-agtc__link {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 0;
  animation: ui-agtc-retract 280ms var(--ui-agtc-ease) forwards;
}
.ui-agtc__dot[data-leaving] {
  animation: ui-agtc-fade 280ms ease forwards;
}
.ui-agtc__node[data-clickable] {
  cursor: pointer;
}
.ui-agtc__lead {
  min-width: 0;
  margin-bottom: 24px;
}
.ui-agtc__extra {
  min-width: 0;
  margin-top: -6px;
}
.ui-agtc__extra-in {
  padding-top: 6px;
}
.ui-agtc[data-picking] .ui-agtc__node:not([data-kept]) {
  opacity: 0.4;
}
.ui-agtc__node:focus-visible {
  outline: 2px solid var(--ui-agtc-focus);
  outline-offset: 2px;
}
.ui-agtc__node[data-clickable]:hover {
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 2px 6px -2px rgba(0, 0, 0, 0.12);
}
.ui-agtc__node[data-status="queued"],
.ui-agtc__node[data-status="stopped"] {
  opacity: 0.6;
}
.ui-agtc__top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agtc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-agtc-text);
}
.ui-agtc__avatar[data-logo] > svg {
  width: 13px;
  height: 13px;
}
.ui-agtc__who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-agtc__name {
  overflow: hidden;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__tools {
  display: inline-flex;
  margin-right: 6px;
  vertical-align: top;
}
.ui-agtc__tool {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
}
.ui-agtc__tool + .ui-agtc__tool {
  margin-left: -4px;
}
.ui-agtc__tool > svg {
  width: 10px;
  height: 10px;
}
.ui-agtc__tool--more {
  width: auto;
  min-width: 16px;
  padding: 0 3px;
  font-size: 9px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agtc__model {
  overflow: hidden;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-agtc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__status {
  display: inline-flex;
  flex: none;
  align-self: start;
  align-items: center;
  gap: 4px;
  height: 18px;
  padding: 0 6px 0 4px;
  border-radius: 4px;
  background: var(--ui-agtc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-text);
  white-space: nowrap;
}
.ui-agtc__status[data-status="running"] {
  background: var(--ui-agtc-brand-bg);
  color: var(--ui-agtc-brand-fg);
}
.ui-agtc__spin {
  animation: ui-agtc-spin 900ms linear infinite;
}
.ui-agtc__status[data-status="waiting"] {
  background: var(--ui-agtc-warn-bg);
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__status[data-status="done"] {
  background: var(--ui-agtc-ok-bg);
  color: var(--ui-agtc-ok-fg);
}
.ui-agtc__status[data-status="failed"] {
  background: var(--ui-agtc-danger-bg);
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__task {
  text-align: start;
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  margin: -2px -2px -3px !important;
  padding: 2px 2px 3px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-text);
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-agtc__meta {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 20px;
}
.ui-agtc__cost {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-agtc__amount[data-live] {
  background: linear-gradient(
      90deg,
      currentColor 0%,
      currentColor 38%,
      var(--ui-agtc-shine) 50%,
      currentColor 62%,
      currentColor 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ui-agtc-shine 1100ms linear infinite;
}
.ui-agtc__time {
  font-weight: 400;
  color: var(--ui-agtc-muted);
}
.ui-agtc__fold {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  height: 20px;
  padding: 0 4px 0 6px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-agtc__fold:hover {
  background: var(--ui-agtc-fill);
  color: var(--ui-agtc-ink);
}
.ui-agtc__fold > svg {
  transition: transform 220ms var(--ui-agtc-ease);
}
.ui-agtc__fold[aria-expanded="false"] > svg {
  transform: rotate(-90deg);
}
@keyframes ui-agtc-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-agtc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-agtc-retract {
  to {
    stroke-dashoffset: 1;
  }
}
@keyframes ui-agtc-leave {
  to {
    opacity: 0;
    transform: translateY(4px) scale(0.97);
  }
}
@keyframes ui-agtc-fade {
  to {
    opacity: 0;
  }
}
@keyframes ui-agtc-rise {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.98);
  }
}
@keyframes ui-agtc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-agtc-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@media (pointer: coarse) {
  .ui-agtc__fold {
    height: 32px;
    padding: 0 8px 0 10px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-agtc *,
  .ui-agtc *::before,
  .ui-agtc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-agtc {
  --ui-agtc-shine: rgba(255, 255, 255, 0.35);
  --ui-agtc-card: #1c1c1f;
  --ui-agtc-strong: #ffffff;
  --ui-agtc-ink: rgba(255, 255, 255, 0.9);
  --ui-agtc-text: rgba(255, 255, 255, 0.62);
  --ui-agtc-muted: rgba(255, 255, 255, 0.45);
  --ui-agtc-faint: rgba(255, 255, 255, 0.28);
  --ui-agtc-line: rgba(255, 255, 255, 0.08);
  --ui-agtc-fill: rgba(255, 255, 255, 0.08);
  --ui-agtc-accent: #4fb0fe;
  --ui-agtc-link: #4fb0fe;
  --ui-agtc-link-muted: rgba(255, 255, 255, 0.14);
  --ui-agtc-brand-bg: #0077ff3a;
  --ui-agtc-brand-fg: #70b8ff;
  --ui-agtc-ok-bg: #00f04a1f;
  --ui-agtc-ok-fg: #5fc88a;
  --ui-agtc-warn-bg: #fb6a0025;
  --ui-agtc-warn-fg: #ffb35c;
  --ui-agtc-danger-bg: #ff35232b;
  --ui-agtc-danger-fg: #ff8a7a;
  --ui-agtc-focus: rgba(77, 141, 255, 0.8);
  --ui-agtc-solid: rgba(255, 255, 255, 0.92);
  --ui-agtc-on-solid: #141416;
  --ui-agtc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-agtc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}

.ui-ccc {
  --ui-ccc-card: var(--aui-surface, #ffffff);
  --ui-ccc-strong: #000000;
  --ui-ccc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-ccc-text: var(--aui-muted, rgba(0, 0, 0, 0.61));
  --ui-ccc-muted: var(--aui-muted, rgba(0, 0, 0, 0.45));
  --ui-ccc-faint: var(--aui-placeholder, rgba(0, 0, 0, 0.27));
  --ui-ccc-hint: var(--aui-placeholder, rgba(0, 0, 0, 0.36));
  --ui-ccc-icon: var(--aui-muted, rgba(0, 0, 0, 0.447));
  --ui-ccc-line: var(--aui-border, rgba(0, 0, 0, 0.06));
  --ui-ccc-fill: rgba(0, 0, 0, 0.06);
  --ui-ccc-wash: rgba(0, 0, 0, 0.03);
  --ui-ccc-tray: #f5f5f5;
  --ui-ccc-tray-hover: rgba(0, 0, 0, 0.04);
  --ui-ccc-solid: var(--aui-primary, rgba(0, 0, 0, 0.88));
  --ui-ccc-on-solid: var(--aui-on-primary, #fcfcfc);
  --ui-ccc-accent: rgba(0, 96, 226, 0.765);
  --ui-ccc-alert: var(--aui-danger, #c4320a);
  --ui-ccc-alert-wash: rgba(240, 68, 56, 0.08);
  --ui-ccc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ccc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ccc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-ccc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-ccc-ease-pop: cubic-bezier(0.34, 1.5, 0.64, 1);
  position: relative;
  container-type: inline-size;
  width: 100%;
  max-width: 560px;
}
.ui-ccc__body {
  position: relative;
  border-radius: 16px;
  background: var(--ui-ccc-tray);
  box-shadow: var(--ui-ccc-shadow);
  font-family: var(
    --aui-font,
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif
  );
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-ccc-text);
  -webkit-font-smoothing: antialiased;
  -webkit-tap-highlight-color: transparent;
}
.ui-ccc__body *,
.ui-ccc__body *::before,
.ui-ccc__body *::after {
  box-sizing: border-box;
}
:where(.ui-ccc__body) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: left;
  cursor: pointer;
}
.ui-ccc__body svg {
  display: block;
  flex: none;
  max-width: none;
}
.ui-ccc__body button:focus-visible {
  outline: 2px solid var(--ui-ccc-focus);
  outline-offset: 2px;
}
.ui-ccc__write {
  position: relative;
  z-index: 2;
  padding: 14px 10px 10px;
  border-radius: calc(var(--aui-radius, 7px) + 9px);
  background: var(--ui-ccc-card);
  box-shadow:
    0 0 0 0.5px var(--ui-ccc-line),
    0 1px 2px 0 rgba(0, 0, 0, 0.04);
  cursor: text;
}
.ui-ccc__field {
  position: relative;
  padding: 0 4px;
}
.ui-ccc__message,
.ui-ccc__draft {
  display: block;
  width: 100%;
  height: calc(var(--ui-ccc-lines, 2) * 20px);
  margin: 0;
  padding: 0;
  border: 0;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ccc-strong);
  white-space: pre-wrap;
  overflow-wrap: break-word;
  text-align: start;
}
.ui-ccc__message {
  outline: 0;
  background: transparent;
  resize: none;
  overflow-y: auto;
  scrollbar-width: none;
  caret-color: var(--ui-ccc-accent);
  transition: height 260ms var(--ui-ccc-ease);
}
.ui-ccc__message::-webkit-scrollbar {
  display: none;
}
.ui-ccc__message::placeholder {
  color: var(--ui-ccc-hint);
  opacity: 1;
}
.ui-ccc__message:focus-visible {
  outline: none;
}
.ui-ccc__draft {
  position: absolute;
  inset: 0 4px;
  width: auto;
  overflow: hidden;
  pointer-events: none;
  visibility: hidden;
}
.ui-ccc__heard {
  color: var(--ui-ccc-faint);
}
.ui-ccc__body[data-recording="true"] .ui-ccc__draft {
  visibility: visible;
}
.ui-ccc__body[data-recording="true"] .ui-ccc__message {
  color: transparent;
  caret-color: transparent;
}
.ui-ccc__body[data-recording="true"] .ui-ccc__message::placeholder {
  color: transparent;
}
.ui-ccc__tools {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin-top: 14px;
}
.ui-ccc__group {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
}
.ui-ccc__swap {
  display: grid;
  justify-items: end;
  min-width: 0;
}
.ui-ccc__swap > * {
  grid-area: 1 / 1;
  max-width: 100%;
}
.ui-ccc__icon-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-ccc-icon);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__icon-btn svg {
  width: 16px;
  height: 16px;
}
.ui-ccc__icon-btn svg:not([fill="none"]) {
  fill: currentColor;
}
.ui-ccc__icon-btn:hover {
  background: var(--ui-ccc-wash);
  color: var(--ui-ccc-ink);
}
.ui-ccc__icon-btn:active {
  transform: scale(0.94);
}
.ui-ccc__approval {
  position: relative;
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 28px;
  padding: 0 10px 0 8px;
  overflow: clip;
  border-radius: 8px;
  font-weight: 400;
  white-space: nowrap;
  color: var(--ui-ccc-muted);
  transition:
    background-color 200ms ease,
    color 160ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__approval:hover,
.ui-ccc__approval[aria-expanded="true"] {
  background: var(--ui-ccc-wash);
  color: var(--ui-ccc-ink);
}
.ui-ccc__approval:active {
  transform: scale(0.97);
}
.ui-ccc__approval-face {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-ccc__approval-face[data-morph] {
  animation: ui-ccc-model-in 460ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-ccc__approval-face[data-morph] .ui-ccc__approval-icon {
  animation: ui-ccc-logo-in 520ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-ccc__approval-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-ccc-icon);
}
.ui-ccc__approval-icon svg {
  width: 100%;
  height: 100%;
}
.ui-ccc__approval[data-tone="alert"],
.ui-ccc__approval[data-tone="alert"] .ui-ccc__approval-icon {
  color: var(--ui-ccc-alert);
}
.ui-ccc__approval[data-tone="alert"]:is(:hover, [aria-expanded="true"]) {
  background: var(--ui-ccc-alert-wash);
}
.ui-ccc__icon-btn[aria-expanded="true"] {
  background: var(--ui-ccc-wash);
  color: var(--ui-ccc-ink);
}
.ui-ccc__model {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 28px;
  min-width: 0;
  max-width: 100%;
  padding: 0 6px 0 8px;
  overflow: clip;
  border-radius: 8px;
  font-weight: 400;
  white-space: nowrap;
  color: var(--ui-ccc-ink);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__model:hover,
.ui-ccc__model[aria-expanded="true"] {
  background: var(--ui-ccc-wash);
  color: var(--ui-ccc-ink);
}
.ui-ccc__model:active {
  transform: scale(0.97);
}
.ui-ccc__model-face {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-ccc__model-name {
  max-width: 160px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ccc__model-face[data-morph] {
  animation: ui-ccc-model-in 460ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-ccc__model-face[data-morph] .ui-ccc__model-logo {
  animation: ui-ccc-logo-in 520ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-ccc__model-logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 14px;
  height: 14px;
  color: var(--ui-ccc-strong);
}
.ui-ccc__model-logo svg,
.ui-ccc__option-logo svg {
  width: 100%;
  height: 100%;
}
.ui-ccc__chevron {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-ccc-icon);
}
.ui-ccc__chevron svg {
  width: 14px;
  height: 14px;
  transition: transform 220ms var(--ui-ccc-ease);
}
.ui-ccc__model[aria-expanded="true"] .ui-ccc__chevron svg {
  transform: rotate(180deg);
}
.ui-ccc__send {
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  margin-left: 2px;
  border-radius: 8px;
  background: var(--ui-ccc-solid) !important;
  color: var(--ui-ccc-on-solid);
  transition:
    background-color 200ms ease,
    color 200ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__send svg {
  width: 16px;
  height: 16px;
}
.ui-ccc__send:disabled {
  background: var(--ui-ccc-fill) !important;
  color: var(--ui-ccc-faint);
  cursor: default;
}
.ui-ccc__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-ccc__group--end {
  transition:
    opacity 220ms ease-out,
    transform 320ms var(--ui-ccc-ease);
}
.ui-ccc__group--voice {
  gap: 6px;
  opacity: 0;
  transform: translateY(6px);
  pointer-events: none;
}
.ui-ccc__body[data-recording="true"]
  .ui-ccc__group--end:not(.ui-ccc__group--voice) {
  opacity: 0;
  transform: translateY(-6px);
  pointer-events: none;
}
.ui-ccc__body[data-recording="true"] .ui-ccc__group--voice {
  opacity: 1;
  transform: none;
  pointer-events: auto;
}
.ui-ccc__trace {
  display: flex;
  align-items: center;
  gap: 3px;
  height: 20px;
  margin-right: 6px;
}
.ui-ccc__trace > span {
  flex: none;
  width: 2px;
  border-radius: 1px;
  background: var(--ui-ccc-accent);
  transition: height 110ms ease-out;
}
.ui-ccc__button {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-ccc-card) !important;
  box-shadow: var(--ui-ccc-shadow);
  color: var(--ui-ccc-ink);
  transition:
    background-color 160ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__button:hover {
  background: #fafafa !important;
}
.ui-ccc__button:active {
  transform: scale(0.94);
}
.ui-ccc__button svg {
  width: 16px;
  height: 16px;
}
.ui-ccc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 36px;
  padding: 0 6px;
}
.ui-ccc[data-tray="off"] .ui-ccc__body {
  background: var(--ui-ccc-card);
}
.ui-ccc[data-tray="off"] .ui-ccc__write {
  box-shadow: none;
}
.ui-ccc__foot[data-custom] {
  display: block;
  height: auto;
  padding: 0;
}
.ui-ccc__row {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
  height: 26px;
  padding: 0 8px 0 7px;
  border-radius: 8px;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  color: var(--ui-ccc-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-ccc-ease);
}
.ui-ccc__row:hover,
.ui-ccc__row[aria-expanded="true"] {
  background: var(--ui-ccc-tray-hover);
  color: var(--ui-ccc-ink);
}
.ui-ccc__row:active {
  transform: scale(0.97);
}
.ui-ccc__row--folder {
  flex: 0 1 auto;
}
.ui-ccc__row-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ccc__row--apps {
  flex: none;
  gap: 10px;
  margin-left: auto;
}
.ui-ccc__logos {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ui-ccc__logo {
  display: grid;
  place-items: center;
  width: 13px;
  height: 13px;
}
.ui-ccc__logo svg {
  width: 13px;
  height: 13px;
}
.ui-ccc__folder {
  flex: none;
  width: 16px;
  height: 16px;
}
.ui-ccc__folder svg {
  width: 100%;
  height: 100%;
}
.ui-ccc__row > :is(.ui-ccc__logos, .ui-ccc__folder) {
  translate: 0 -0.25px;
}
.ui-ccc__menu {
  --morph: 380ms cubic-bezier(0.32, 0.72, 0, 1);
  position: absolute;
  z-index: 5;
  width: 260px;
  transition: visibility 0s linear 0s;
}
.ui-ccc__menu[data-open="false"] {
  visibility: hidden;
  pointer-events: none;
  transition: visibility 0s linear 300ms;
}
.ui-ccc__menu-panel {
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-ccc-card);
  box-shadow: var(--ui-ccc-shadow-pop);
  outline: none;
  clip-path: inset(-40px -40px -40px -40px round 10px);
  transition: clip-path var(--morph);
  max-height: 340px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-ccc__menu[data-placing="true"] .ui-ccc__menu-panel {
  transition: none !important;
}
.ui-ccc__menu[data-open="false"] .ui-ccc__menu-panel {
  clip-path: inset(
    var(--from-top) 0 var(--from-bottom) var(--from-left) round
      var(--from-radius)
  );
  transition: clip-path 260ms cubic-bezier(0.4, 0, 0.2, 1);
}
.ui-ccc__menu-panel > * {
  transition:
    opacity 220ms ease-out 100ms,
    transform 360ms var(--ui-ccc-ease) 60ms;
}
.ui-ccc__menu[data-open="false"] .ui-ccc__menu-panel > * {
  opacity: 0;
  transition: opacity 120ms ease-in;
}
.ui-ccc__menu[data-open="false"] .ui-ccc__option {
  transform: translateY(4px);
}
.ui-ccc__menu[data-open="false"][data-up="false"] .ui-ccc__option {
  transform: translateY(-4px);
}
.ui-ccc__menu-panel:focus-visible {
  outline: none;
}
.ui-ccc__menu[data-above] .ui-ccc__menu-panel {
  border-radius: 16px;
  box-shadow: var(--ui-ccc-shadow);
}
.ui-ccc__menu[data-above]:not([data-open="false"]) .ui-ccc__menu-panel {
  clip-path: inset(-2px round 16px);
}
.ui-ccc__menu[data-above] .ui-ccc__menu-panel[data-more]::after {
  content: "";
  position: sticky;
  bottom: -4px;
  flex: none;
  height: 28px;
  margin: -28px -4px -4px;
  background: linear-gradient(
    to bottom,
    color-mix(in srgb, var(--ui-ccc-card) 0%, transparent),
    var(--ui-ccc-card) 90%
  );
  pointer-events: none;
}
.ui-ccc__menu-fill {
  position: absolute;
  left: 4px;
  right: 4px;
  top: 0;
  border-radius: 6px;
  background: var(--ui-ccc-fill);
  pointer-events: none;
  transition:
    transform 190ms cubic-bezier(0.25, 1, 0.3, 1),
    height 190ms cubic-bezier(0.25, 1, 0.3, 1),
    opacity 160ms ease-out;
}
.ui-ccc__menu-fill[data-glide="false"] {
  transition: opacity 160ms ease-out;
}
.ui-ccc__option {
  position: relative;
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 6px 8px;
  border-radius: 6px;
  cursor: pointer;
}
.ui-ccc__option-logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  color: var(--ui-ccc-icon);
}
.ui-ccc__option-text {
  display: flex;
  flex-direction: column;
  flex: 1;
  min-width: 0;
}
.ui-ccc__option-name {
  overflow: hidden;
  text-align: start;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-ccc-ink);
}
.ui-ccc__option[aria-selected="true"] .ui-ccc__option-name {
  color: var(--ui-ccc-strong);
}
.ui-ccc__option-desc {
  text-align: start;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ccc-hint);
}
.ui-ccc__option-check {
  flex: none;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  color: var(--ui-ccc-ink);
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 160ms ease-out,
    transform 260ms var(--ui-ccc-ease-pop);
}
.ui-ccc__option-check svg {
  width: 100%;
  height: 100%;
}
.ui-ccc__option[data-checked] .ui-ccc__option-check {
  opacity: 1;
  transform: none;
}
.ui-ccc__option[data-tone="alert"]
  :is(.ui-ccc__option-logo, .ui-ccc__option-name) {
  color: var(--ui-ccc-alert);
}
.ui-ccc__menu[data-inline] .ui-ccc__option-text {
  flex-direction: row;
  align-items: baseline;
  gap: 8px;
}
.ui-ccc__menu[data-inline] .ui-ccc__option-desc {
  overflow: hidden;
  font-size: 13px;
  line-height: 20px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ccc__menu-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  padding: 6px 8px 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ccc-hint);
}
.ui-ccc__menu-link {
  flex: none;
  font-size: 12px;
  color: var(--ui-ccc-muted) !important;
  transition: color 140ms ease;
}
.ui-ccc__menu-link:hover {
  color: var(--ui-ccc-ink) !important;
  text-decoration: underline;
  text-underline-offset: 3px;
}
.ui-ccc__menu-section {
  display: flex;
  flex-direction: column;
}
.ui-ccc__menu-section + .ui-ccc__menu-section {
  margin-top: 4px;
}
.ui-ccc__menu-title {
  padding: 6px 8px 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ccc-muted);
}
.ui-ccc__sr-only {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
@keyframes ui-ccc-model-in {
  from {
    opacity: 0;
    filter: blur(3px);
    transform: translateY(30%);
  }
}
@keyframes ui-ccc-logo-in {
  from {
    opacity: 0;
    transform: scale(0.6) rotate(-12deg);
  }
}
@container (max-width: 400px) {
  .ui-ccc__approval {
    padding: 0;
    width: 28px;
    justify-content: center;
  }
  .ui-ccc__approval-text {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
  }
}
@media (pointer: coarse) {
  .ui-ccc__icon-btn,
  .ui-ccc__send,
  .ui-ccc__button {
    width: 34px;
    height: 34px;
  }
  .ui-ccc__model,
  .ui-ccc__approval {
    height: 34px;
  }
  .ui-ccc__foot {
    height: 42px;
  }
  .ui-ccc__row {
    height: 32px;
  }
}
@media (pointer: coarse) {
  @container (max-width: 400px) {
    .ui-ccc__approval {
      width: 34px;
    }
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ccc *,
  .ui-ccc *::after {
    animation: none !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
}
.ui-ccc textarea:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-ccc {
  --ui-ccc-card: var(--aui-surface, #1c1c1e);
  --ui-ccc-strong: #ffffff;
  --ui-ccc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-ccc-text: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-ccc-muted: var(--aui-muted, rgba(255, 255, 255, 0.46));
  --ui-ccc-faint: var(--aui-placeholder, rgba(255, 255, 255, 0.3));
  --ui-ccc-hint: var(--aui-placeholder, rgba(255, 255, 255, 0.36));
  --ui-ccc-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-ccc-line: var(--aui-border, rgba(255, 255, 255, 0.08));
  --ui-ccc-fill: rgba(255, 255, 255, 0.08);
  --ui-ccc-wash: rgba(255, 255, 255, 0.04);
  --ui-ccc-tray: #161618;
  --ui-ccc-tray-hover: rgba(255, 255, 255, 0.05);
  --ui-ccc-solid: var(--aui-primary, rgba(255, 255, 255, 0.92));
  --ui-ccc-on-solid: var(--aui-on-primary, #161618);
  --ui-ccc-accent: #4fb0fe;
  --ui-ccc-alert: var(--aui-danger, #ff8a7a);
  --ui-ccc-alert-wash: rgba(255, 107, 95, 0.14);
  --ui-ccc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-ccc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-ccc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
:where(.dark, [data-theme="dark"]) .ui-ccc__button:hover {
  background: #232326 !important;
}

/* Colors and motion as variables – override them on .ui-buttonc (see Theming in the docs) */
.ui-buttonc {
  --ui-btnc-title: var(--aui-ink, #000);
  --ui-btnc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-btnc-muted: var(--aui-muted, rgba(0, 0, 0, 0.61));
  --ui-btnc-icon: var(--aui-muted, rgba(0, 0, 0, 0.447));
  --ui-btnc-solid: var(--aui-primary, rgba(0, 0, 0, 0.88));
  --ui-btnc-solid-hover: rgba(0, 0, 0, 0.8);
  --ui-btnc-on-solid: var(--aui-on-primary, #fcfcfc);
  --ui-btnc-surface: var(--aui-surface, #ffffff);
  --ui-btnc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.06)),
    0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-btnc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.1)),
    0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 3px 0 rgba(0, 0, 0, 0.07);
  --ui-btnc-wash: rgba(0, 0, 0, 0.03);
  --ui-btnc-danger: var(--aui-danger, #c4320a);
  --ui-btnc-danger-bg: rgba(240, 68, 56, 0.08);
  --ui-btnc-danger-bg-hover: rgba(240, 68, 56, 0.12);
  --ui-btnc-shine: rgba(255, 255, 255, 0.82);
  --ui-btnc-shine-on-solid: #ffffff;
  --ui-btnc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-btnc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-btnc-load: 650ms;

  --h: 28px;
  --px: 10px;
  --gap: 6px;
  --fs: 13px;
  --lh: 20px;
  --icon: 16px;
  --radius: var(--aui-radius, 6px);

  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--gap);
  box-sizing: border-box;
  height: var(--h);
  padding: 0 var(--px);
  margin: 0;
  border: 0;
  border-radius: var(--radius);
  font-family: var(
    --aui-font,
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif
  );
  font-size: var(--fs);
  font-weight: 500;
  line-height: var(--lh);
  letter-spacing: 0;
  max-width: 100%;
  min-width: 0;
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    box-shadow 140ms ease,
    transform 160ms var(--ui-btnc-ease),
    opacity 140ms ease;
}

/* Sizes: 24 · 28 · 32 high (taller on touch screens, see below) */
.ui-buttonc[data-size="sm"] {
  --h: 24px;
  --px: 8px;
  --gap: 4px;
  --fs: 12px;
  --lh: 16px;
  --icon: 14px;
  --radius: var(--aui-radius, 6px);
}
.ui-buttonc[data-size="lg"] {
  --h: 32px;
  --px: 12px;
  --gap: 6px;
  --fs: 13px;
  --icon: 16px;
  --radius: var(--aui-radius, 6px);
}
/* Touch screens: every size grows to a comfortable tap height – 32 · 34 · 36 – the look stays the same */
@media (pointer: coarse) {
  .ui-buttonc[data-size="sm"] {
    --h: 32px;
  }
  .ui-buttonc[data-size="md"] {
    --h: 34px;
  }
  .ui-buttonc[data-size="lg"] {
    --h: 36px;
  }
}
/* An icon sits closer to the edge than the text, so both look evenly spaced */
.ui-buttonc[data-icon-left] {
  padding-left: calc(var(--px) - 2px);
}
.ui-buttonc[data-icon-right] {
  padding-right: calc(var(--px) - 2px);
}
.ui-buttonc[data-icon-only] {
  width: var(--h);
  padding: 0;
}

/* primary: a dark chip */
.ui-buttonc[data-variant="primary"] {
  background: var(--ui-btnc-solid);
  color: var(--ui-btnc-on-solid);
}
.ui-buttonc[data-variant="primary"]:hover:not(:disabled) {
  background: var(--ui-btnc-solid-hover);
}

/* secondary: white with the card's hairline shadow */
.ui-buttonc[data-variant="secondary"] {
  background: var(--ui-btnc-surface);
  color: var(--ui-btnc-title);
  box-shadow: var(--ui-btnc-shadow);
}
.ui-buttonc[data-variant="secondary"] .ui-buttonc__icon {
  color: var(--ui-btnc-icon);
}
.ui-buttonc[data-variant="secondary"]:hover:not(:disabled) {
  box-shadow: var(--ui-btnc-shadow-hover);
}

/* ghost: a muted label, a soft wash appears on hover */
.ui-buttonc[data-variant="ghost"] {
  background: transparent;
  color: var(--ui-btnc-muted);
}
.ui-buttonc[data-variant="ghost"] .ui-buttonc__icon {
  color: var(--ui-btnc-icon);
}
.ui-buttonc[data-variant="ghost"]:hover:not(:disabled) {
  background: var(--ui-btnc-wash);
  color: var(--ui-btnc-ink);
}
.ui-buttonc[data-variant="ghost"]:hover:not(:disabled) .ui-buttonc__icon {
  color: var(--ui-btnc-ink);
}

/* destructive: red label on a minimal red fill, no stroke */
.ui-buttonc[data-variant="destructive"] {
  background: var(--ui-btnc-danger-bg);
  color: var(--ui-btnc-danger);
}
.ui-buttonc[data-variant="destructive"]:hover:not(:disabled) {
  background: var(--ui-btnc-danger-bg-hover);
}

.ui-buttonc .ui-buttonc__icon {
  transition: color 140ms ease;
}
.ui-buttonc:active:not(:disabled):not([data-loading]) {
  transform: scale(0.97);
}
.ui-buttonc:focus-visible {
  outline: 2px solid var(--ui-btnc-focus);
  outline-offset: 2px;
}
.ui-buttonc:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-buttonc[data-loading] {
  cursor: default;
}

.ui-buttonc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: var(--icon);
  height: var(--icon);
}
.ui-buttonc__icon {
  overflow: hidden;
}
.ui-buttonc__icon > svg,
.ui-buttonc__icon > img {
  display: block;
  width: 100%;
  height: 100%;
}
.ui-buttonc__icon > img {
  object-fit: contain;
}

/* Morph: the button clips while its width glides; changed parts blur in */
.ui-buttonc {
  overflow: clip;
}
.ui-buttonc[data-ready] .ui-buttonc__label {
  animation: ui-buttonc-label-in 480ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-buttonc[data-ready] .ui-buttonc__icon {
  animation: ui-buttonc-icon-in 520ms cubic-bezier(0.25, 1, 0.5, 1) both;
}

/* Loading: a light band sweeps across a copy of the dimmed label */
/* A label too long for its parent ends in "…" – the full text shows on hover */
.ui-buttonc__label {
  position: relative;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-buttonc__label::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-btnc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  opacity: 0;
  pointer-events: none;
}
.ui-buttonc[data-variant="primary"] .ui-buttonc__label::after {
  --ui-btnc-shine: var(--ui-btnc-shine-on-solid);
}
.ui-buttonc[data-loading] .ui-buttonc__label {
  color: color-mix(in srgb, currentColor 50%, transparent);
}
.ui-buttonc[data-loading] .ui-buttonc__label::after {
  opacity: 1;
  animation: ui-buttonc-sweep calc(var(--ui-btnc-load) * 1.6) linear infinite;
}
.ui-buttonc__spinner {
  animation: ui-buttonc-spin 900ms linear infinite;
}

@keyframes ui-buttonc-label-in {
  from {
    opacity: 0;
    filter: blur(3px);
    transform: translateY(25%);
  }
}
@keyframes ui-buttonc-icon-in {
  from {
    opacity: 0;
    filter: blur(2px);
    transform: scale(0.7);
  }
}

@keyframes ui-buttonc-spin {
  to {
    transform: rotate(1turn);
  }
}

@keyframes ui-buttonc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-buttonc[data-ready] .ui-buttonc__label,
  .ui-buttonc[data-ready] .ui-buttonc__icon {
    animation: none;
  }
  .ui-buttonc {
    transition-duration: 1ms;
  }
  .ui-buttonc[data-loading] .ui-buttonc__label::after {
    animation: none;
    opacity: 0;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-buttonc {
  /* primary inverts: a light chip with dark text */
  --ui-btnc-solid: var(--aui-primary, rgba(255, 255, 255, 0.9));
  --ui-btnc-solid-hover: rgba(255, 255, 255, 0.82);
  --ui-btnc-on-solid: var(--aui-on-primary, #161618);
  --ui-btnc-shine-on-solid: #ffffff;

  --ui-btnc-title: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-btnc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-btnc-muted: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-btnc-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-btnc-surface: var(--aui-surface, #1c1c1e);
  --ui-btnc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.1)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-btnc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.16)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-btnc-wash: rgba(255, 255, 255, 0.06);
  --ui-btnc-danger: var(--aui-danger, #ff8a7a);
  --ui-btnc-danger-bg: rgba(255, 107, 95, 0.14);
  --ui-btnc-danger-bg-hover: rgba(255, 107, 95, 0.2);
  --ui-btnc-shine: #ffffff;
  --ui-btnc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}

/* Hover of the primary button follows its fill – also a brand color from --aui-primary. Browsers without
   color-mix() (Safari before 16.2) keep the fixed hover above */
@supports (color: color-mix(in srgb, red 50%, transparent)) {
  .ui-buttonc {
    --ui-btnc-solid-hover: color-mix(
      in srgb,
      var(--ui-btnc-solid) 91%,
      transparent
    );
  }
}

/* Colors and motion as variables – override them on .ui-tfc (see Theming in the docs) */
.ui-tfc {
  --ui-tfc-title: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tfc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tfc-muted: var(--aui-muted, rgba(0, 0, 0, 0.61));
  --ui-tfc-subtle: var(--aui-muted, rgba(0, 0, 0, 0.45));
  --ui-tfc-faint: var(--aui-placeholder, rgba(0, 0, 0, 0.3));
  --ui-tfc-icon: var(--aui-muted, rgba(0, 0, 0, 0.447));
  --ui-tfc-surface: var(--aui-surface, #ffffff);
  --ui-tfc-wash: rgba(0, 0, 0, 0.04);
  --ui-tfc-readonly: rgba(0, 0, 0, 0.02);
  --ui-tfc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.08)),
    0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tfc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.13)),
    0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tfc-shadow-focus:
    0 0 0 1px var(--aui-border-strong, rgba(0, 0, 0, 0.28)),
    0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tfc-danger: var(--aui-danger, #c4320a);
  --ui-tfc-danger-edge: rgba(240, 68, 56, 0.55);
  --ui-tfc-danger-edge-focus: rgba(229, 72, 77, 0.8);
  --ui-tfc-success: var(--aui-success, #1e8a4f);
  --ui-tfc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-tfc-ease: cubic-bezier(0.22, 1, 0.36, 1);

  --h: 32px;
  --px: 10px;
  --fs: 13px;
  --radius: var(--aui-radius, 7px);

  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  font-family: var(
    --aui-font,
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif
  );
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-tfc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-tfc[data-size="sm"] {
  --h: 28px;
  --px: 8px;
  --fs: 13px;
  --radius: calc(var(--aui-radius, 7px) - 1px);
}
.ui-tfc[data-size="lg"] {
  --h: 36px;
  --px: 12px;
  --fs: 14px;
  --radius: calc(var(--aui-radius, 7px) + 1px);
}
/* Touch screens: a comfortable tap height, and 16px text so iOS doesn't zoom in on focus */
@media (pointer: coarse) {
  .ui-tfc {
    --fs: 16px;
  }
  .ui-tfc[data-size="sm"] {
    --h: 34px;
  }
  .ui-tfc[data-size="md"] {
    --h: 38px;
  }
  .ui-tfc[data-size="lg"] {
    --h: 40px;
  }
}

.ui-tfc__head {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.ui-tfc__label {
  min-width: 0;
  font-weight: 500;
  color: var(--ui-tfc-title);
  overflow-wrap: anywhere;
  cursor: default;
}
.ui-tfc__optional {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tfc-subtle);
}

/* The box: white, a hairline shadow as its edge; hover and focus only make that edge firmer */
.ui-tfc__box {
  display: flex;
  align-items: center;
  gap: 6px;
  box-sizing: border-box;
  height: var(--h);
  min-width: 0;
  padding-block: 0;
  padding-inline: var(--px) calc(var(--px) - 4px);
  border-radius: var(--radius);
  background: var(--ui-tfc-surface);
  box-shadow: var(--ui-tfc-shadow);
  cursor: text;
  transition:
    box-shadow 140ms ease,
    background-color 140ms ease;
}
/* Without a button at the end, both sides sit at the same distance */
.ui-tfc__box:not(:has(.ui-tfc__action)) {
  padding-inline-end: var(--px);
}
.ui-tfc__box:hover {
  box-shadow: var(--ui-tfc-shadow-hover);
}
.ui-tfc__box:focus-within {
  box-shadow: var(--ui-tfc-shadow-focus);
}
.ui-tfc[data-invalid] .ui-tfc__box {
  box-shadow:
    0 0 0 1px var(--ui-tfc-danger-edge),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
}
.ui-tfc[data-invalid] .ui-tfc__box:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-tfc-danger-edge-focus),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
}
.ui-tfc[data-readonly] .ui-tfc__box {
  background: var(--ui-tfc-readonly);
  box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.08);
  cursor: default;
}
.ui-tfc[data-disabled] .ui-tfc__box {
  background: var(--ui-tfc-readonly);
  box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.06);
  cursor: not-allowed;
}
.ui-tfc[data-disabled] {
  opacity: 0.55;
}
.ui-tfc[data-invalid] .ui-tfc__box {
  animation: ui-tfc-nudge 320ms var(--ui-tfc-ease);
}

.ui-tfc__input {
  flex: 1;
  min-width: 0;
  height: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: var(--fs);
  color: var(--ui-tfc-ink);
  text-overflow: ellipsis;
  -webkit-appearance: none;
  appearance: none;
}
/* Next to a prefix or suffix the value keeps at least 6em – they shrink first */
.ui-tfc__box:has(> .ui-tfc__affix) .ui-tfc__input {
  flex: 1 0 6em;
  min-width: 6em;
}
.ui-tfc__input::placeholder {
  color: var(--ui-tfc-faint);
  opacity: 1;
}
.ui-tfc__input:disabled {
  cursor: not-allowed;
}
.ui-tfc__input[type="search"]::-webkit-search-cancel-button {
  display: none;
}
.ui-tfc__input[type="number"] {
  -moz-appearance: textfield;
  font-variant-numeric: tabular-nums;
}
.ui-tfc__input[type="number"]::-webkit-inner-spin-button,
.ui-tfc__input[type="number"]::-webkit-outer-spin-button {
  -webkit-appearance: none;
  margin: 0;
}
/* Revealing a password: the characters come out of a short blur */
.ui-tfc__input[data-revealed] {
  animation: ui-tfc-reveal 260ms var(--ui-tfc-ease);
}
.ui-tfc__input[data-revealed="false"] {
  animation-name: ui-tfc-reveal-hide;
}

/* Prefix and suffix: quiet text or an icon inside the box */
.ui-tfc__affix {
  display: inline-flex;
  flex: 0 1 auto;
  align-items: center;
  min-width: 0;
  max-width: 70%;
  font-size: var(--fs);
  color: var(--ui-tfc-subtle);
  white-space: nowrap;
  user-select: none;
  overflow: hidden;
  text-overflow: ellipsis;
}
/* Text right against the value, as if it were part of it ("https://" + "acme") */
.ui-tfc__affix[data-side="start"] {
  margin-inline-end: -6px;
}
.ui-tfc__affix[data-side="end"] {
  max-width: 40%;
  margin-inline-start: -6px;
}
/* A long prefix loses its start: "…/workspaces/" stays next to the value */
.ui-tfc__affix-text {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-tfc__affix[data-side="start"]:dir(ltr) .ui-tfc__affix-text {
  direction: rtl;
  text-align: left;
}
.ui-tfc__affix[data-side="start"]:dir(ltr) .ui-tfc__affix-text::after {
  content: "\\200E";
}
/* An icon keeps its distance */
.ui-tfc__affix[data-side]:has(> svg) {
  margin: 0;
  color: var(--ui-tfc-icon);
}
.ui-tfc__affix > svg {
  display: block;
  width: 16px;
  height: 16px;
  flex: none;
}

/* Clear, reveal and copy: small ghost buttons at the end */
.ui-tfc__action {
  display: grid;
  place-items: center;
  flex: none;
  width: calc(var(--h) - 8px);
  height: calc(var(--h) - 8px);
  position: relative;
  max-width: 26px;
  max-height: 26px;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 5px;
  background: transparent;
  color: var(--ui-tfc-icon);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-tfc__action + .ui-tfc__action {
  margin-left: -4px;
}
/* Touch screens: bigger buttons and a hit area that reaches past them */
@media (pointer: coarse) {
  .ui-tfc__action {
    width: 32px;
    height: 32px;
    max-width: none;
    max-height: none;
  }
  .ui-tfc__action::before {
    content: "";
    position: absolute;
    inset: -4px;
  }
}
.ui-tfc__action:hover:not(:disabled) {
  background: var(--ui-tfc-wash);
  color: var(--ui-tfc-ink);
}
.ui-tfc__action:focus-visible {
  outline: 2px solid var(--ui-tfc-focus);
  outline-offset: -2px;
}
.ui-tfc__action:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-tfc__action[data-copied] {
  color: var(--ui-tfc-success);
}
.ui-tfc__action svg {
  display: block;
}
.ui-tfc__swap {
  display: grid;
  animation: ui-tfc-swap 280ms var(--ui-tfc-ease);
}
.ui-tfc__check {
  stroke-dasharray: 1;
  animation: ui-tfc-draw 320ms 60ms var(--ui-tfc-ease) both;
}

/* Under the field: the hint, or the error in its place, and the count */
.ui-tfc__foot {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  min-width: 0;
}
.ui-tfc__message {
  flex: 1;
  min-width: 0;
  margin: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tfc-subtle);
  overflow-wrap: anywhere;
  animation: ui-tfc-message 260ms var(--ui-tfc-ease);
}
.ui-tfc[data-invalid] .ui-tfc__message {
  color: var(--ui-tfc-danger);
}
.ui-tfc__count {
  flex: none;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-tfc-faint);
  transition: color 140ms ease;
}
.ui-tfc__count[data-over] {
  color: var(--ui-tfc-danger);
}
.ui-tfc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-tfc__count[data-full] {
  color: var(--ui-tfc-muted);
}

@keyframes ui-tfc-nudge {
  30% {
    transform: translateX(-3px);
  }
  65% {
    transform: translateX(2px);
  }
}
@keyframes ui-tfc-message {
  from {
    opacity: 0;
    transform: translateY(-3px);
    filter: blur(2px);
  }
}
@keyframes ui-tfc-reveal {
  from {
    filter: blur(4px);
    opacity: 0.4;
  }
}
@keyframes ui-tfc-reveal-hide {
  from {
    filter: blur(3px);
    opacity: 0.5;
  }
}
@keyframes ui-tfc-swap {
  from {
    opacity: 0;
    transform: scale(0.6);
    filter: blur(2px);
  }
}
@keyframes ui-tfc-draw {
  from {
    stroke-dashoffset: 1;
  }
  to {
    stroke-dashoffset: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-tfc *,
  .ui-tfc[data-invalid] .ui-tfc__box {
    animation-duration: 1ms !important;
  }
  .ui-tfc__box {
    transition-duration: 1ms;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-tfc {
  --ui-tfc-title: var(--aui-ink, rgba(255, 255, 255, 0.92));
  --ui-tfc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-tfc-muted: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-tfc-subtle: var(--aui-muted, rgba(255, 255, 255, 0.46));
  --ui-tfc-faint: var(--aui-placeholder, rgba(255, 255, 255, 0.3));
  --ui-tfc-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-tfc-surface: var(--aui-surface, #1c1c1e);
  --ui-tfc-wash: rgba(255, 255, 255, 0.07);
  --ui-tfc-readonly: rgba(255, 255, 255, 0.03);
  --ui-tfc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.14)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tfc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.2)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tfc-shadow-focus:
    0 0 0 1px var(--aui-border-strong, rgba(255, 255, 255, 0.3)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tfc-danger: var(--aui-danger, #ff8a7a);
  --ui-tfc-danger-edge: rgba(255, 107, 95, 0.5);
  --ui-tfc-danger-edge-focus: rgba(255, 99, 105, 0.75);
  --ui-tfc-success: var(--aui-success, #7dcf9f);
  --ui-tfc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
:where(.dark, [data-theme="dark"]) .ui-tfc[data-readonly] .ui-tfc__box,
:where(.dark, [data-theme="dark"]) .ui-tfc[data-disabled] .ui-tfc__box {
  box-shadow: 0 0 0 0.5px rgba(255, 255, 255, 0.12);
}

.ui-cmc {
  --ui-cmc-card: #ffffff;
  --ui-cmc-ink: rgba(0, 0, 0, 0.88);
  --ui-cmc-strong: #000000;
  --ui-cmc-text: rgba(0, 0, 0, 0.61);
  --ui-cmc-muted: rgba(0, 0, 0, 0.45);
  --ui-cmc-faint: rgba(0, 0, 0, 0.27);
  --ui-cmc-icon: rgba(0, 0, 0, 0.447);
  --ui-cmc-line: rgba(0, 0, 0, 0.06);
  --ui-cmc-line-strong: rgba(0, 0, 0, 0.1);
  --ui-cmc-active: rgba(0, 0, 0, 0.06);
  --ui-cmc-tile: #ffffff;
  --ui-cmc-tile-ring: rgba(0, 0, 0, 0.1);
  --ui-cmc-mark: rgba(0, 96, 226, 0.12);
  --ui-cmc-accent: rgba(0, 96, 226, 0.765);
  --ui-cmc-ok: #1e8a4f;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-cmc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 600px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-cmc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cmc *,
.ui-cmc *::before,
.ui-cmc *::after {
  box-sizing: border-box;
}
:where(.ui-cmc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-cmc) svg {
  display: block;
  flex: none;
}
.ui-cmc__card {
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cmc-card);
  box-shadow: var(--ui-cmc-shadow);
}
.ui-cmc__search {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 48px;
  padding: 0 12px 0 14px;
  border-bottom: 0.5px solid var(--ui-cmc-line);
  cursor: text;
}
.ui-cmc__search > svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-icon);
  stroke-width: 1.1;
  stroke-linecap: round;
}
.ui-cmc__search input {
  flex: 1;
  min-width: 0;
  height: 20px;
  padding: 0;
  border: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cmc-ink);
  caret-color: var(--ui-cmc-accent);
  outline: none;
}
.ui-cmc__search input::placeholder {
  color: var(--ui-cmc-faint);
}
.ui-cmc__search input:focus-visible {
  outline: none;
}
.ui-cmc__enter svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__list {
  position: relative;
  max-height: 360px;
  padding: 0 4px 4px;
  overflow-y: auto;
  scrollbar-width: thin;
  transition: height 320ms var(--ui-cmc-ease);
}
.ui-cmc__group {
  display: flex;
  flex-direction: column;
}
.ui-cmc__label {
  padding: 10px 8px 4px;
  overflow-wrap: anywhere;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-cmc-muted);
}
.ui-cmc__group:first-child:not(:has(.ui-cmc__label)) {
  padding-top: 4px;
}
.ui-cmc__pill {
  position: absolute;
  top: 0;
  left: 4px;
  right: 4px;
  border-radius: 6px;
  background: var(--ui-cmc-active);
  opacity: 0;
  transition:
    transform 90ms ease-out,
    height 90ms ease-out,
    opacity 140ms ease;
}
.ui-cmc__pill[data-lit] {
  opacity: 1;
}
.ui-cmc__item {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 36px;
  padding: 0 8px;
  border-radius: 6px;
  text-align: start;
}
.ui-cmc__logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-cmc-tile);
  box-shadow:
    0 0 0 0.5px var(--ui-cmc-tile-ring),
    0 1px 1px -1px rgba(0, 0, 0, 0.1);
  color: var(--ui-cmc-strong);
}
.ui-cmc__logo svg {
  width: 12px;
  height: 12px;
}
.ui-cmc__logo,
.ui-cmc__icon {
  overflow: hidden;
}
.ui-cmc__logo img {
  width: 12px;
  height: 12px;
  object-fit: contain;
}
.ui-cmc__icon img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-cmc__logo[data-broken] > *,
.ui-cmc__icon[data-broken] > * {
  display: none;
}
.ui-cmc__logo[data-broken]::after,
.ui-cmc__icon[data-broken]::after {
  content: attr(data-letter);
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-cmc-text);
}
.ui-cmc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  color: var(--ui-cmc-icon);
  transition: color 140ms ease;
}
.ui-cmc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__glyph path {
  vector-effect: non-scaling-stroke;
}
.ui-cmc__item[aria-selected="true"] .ui-cmc__icon {
  color: var(--ui-cmc-ink);
}
.ui-cmc__text {
  display: flex;
  flex: 1;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-cmc__name {
  overflow: hidden;
  color: var(--ui-cmc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc__hint {
  overflow: hidden;
  color: var(--ui-cmc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmc mark {
  border-radius: 3px;
  background: var(--ui-cmc-mark);
  color: inherit;
}
.ui-cmc__keys {
  display: inline-flex;
  flex: none;
  gap: 2px;
}
.ui-cmc kbd {
  display: inline-grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-cmc-line-strong);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cmc-muted);
  transition: color 140ms ease;
}
.ui-cmc__item[aria-selected="true"] kbd {
  color: var(--ui-cmc-text);
}
.ui-cmc__enter {
  padding: 0 4px;
  color: var(--ui-cmc-icon);
}
.ui-cmc__item[data-ran] {
  animation: ui-cmc-ran 600ms var(--ui-cmc-ease);
}
@keyframes ui-cmc-ran {
  30% {
    transform: scale(0.985);
  }
}
.ui-cmc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 40px;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-cmc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-cmc-muted);
}
.ui-cmc__foot > span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-cmc__done {
  color: var(--ui-cmc-ink);
  animation: ui-cmc-in 260ms var(--ui-cmc-ease);
}
.ui-cmc__done-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cmc__done svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-cmc-ok);
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-cmc__foot-right {
  flex: none;
}
@keyframes ui-cmc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@container (max-width: 480px) {
  .ui-cmc__item .ui-cmc__keys,
  .ui-cmc__foot > .ui-cmc__foot-right,
  .ui-cmc__foot > .ui-cmc__tip,
  .ui-cmc__enter,
  .ui-cmc__hint {
    display: none;
  }
  .ui-cmc__item {
    height: 40px;
  }
  .ui-cmc__list {
    max-height: 360px;
  }
  .ui-cmc__foot:not(:has(.ui-cmc__done)) {
    display: none;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-cmc__item {
    height: 44px;
  }
  .ui-cmc__search {
    height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cmc *,
  .ui-cmc *::before,
  .ui-cmc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cmc {
  --ui-cmc-card: #1c1c1e;
  --ui-cmc-ink: rgba(255, 255, 255, 0.9);
  --ui-cmc-strong: #ffffff;
  --ui-cmc-text: rgba(255, 255, 255, 0.62);
  --ui-cmc-muted: rgba(255, 255, 255, 0.46);
  --ui-cmc-faint: rgba(255, 255, 255, 0.3);
  --ui-cmc-icon: rgba(255, 255, 255, 0.5);
  --ui-cmc-line: rgba(255, 255, 255, 0.08);
  --ui-cmc-line-strong: rgba(255, 255, 255, 0.12);
  --ui-cmc-active: rgba(255, 255, 255, 0.08);
  --ui-cmc-tile: #2a2a2d;
  --ui-cmc-tile-ring: rgba(255, 255, 255, 0.12);
  --ui-cmc-mark: rgba(77, 141, 255, 0.24);
  --ui-cmc-accent: #4fb0fe;
  --ui-cmc-ok: #5fc88a;
  --ui-cmc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}

/* Colors and motion as variables – override them on .ui-fmc */
.ui-fmc {
  --ui-fmc-card: #ffffff;
  --ui-fmc-ink: rgba(0, 0, 0, 0.88);
  --ui-fmc-strong: #000000;
  --ui-fmc-text: rgba(0, 0, 0, 0.61);
  --ui-fmc-muted: rgba(0, 0, 0, 0.45);
  --ui-fmc-faint: rgba(0, 0, 0, 0.27);
  --ui-fmc-icon: rgba(0, 0, 0, 0.447);
  --ui-fmc-line: rgba(0, 0, 0, 0.06);
  --ui-fmc-fill: rgba(0, 0, 0, 0.06);
  --ui-fmc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-fmc-wash: rgba(0, 0, 0, 0.03);
  --ui-fmc-box-ring: rgba(0, 0, 0, 0.22);
  --ui-fmc-accent: rgba(0, 96, 226, 0.765);
  --ui-fmc-check: #ffffff;
  --ui-fmc-focus: rgba(0, 96, 226, 0.7);
  /* Strokes are shadows: a 0.5px hairline plus a soft lift */
  --ui-fmc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-fmc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-fmc-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 400px;
  container-type: inline-size;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-fmc-card);
  box-shadow: var(--ui-fmc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-fmc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-fmc *,
.ui-fmc *::before,
.ui-fmc *::after {
  box-sizing: border-box;
}
:where(.ui-fmc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-fmc) svg {
  display: block;
  flex: none;
}
.ui-fmc button:focus-visible {
  outline: 2px solid var(--ui-fmc-focus);
  outline-offset: 2px;
}

/* ---------- Header ---------- */

.ui-fmc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 10px 8px 16px;
}
.ui-fmc__title {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: start;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-fmc-strong);
}
/* Clear all: a quiet ghost button */
.ui-fmc__clear {
  flex: none;
  height: 28px;
  padding: 0 8px !important;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-fmc-text);
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-fmc__clear:hover:not(:disabled) {
  background: var(--ui-fmc-wash);
  color: var(--ui-fmc-ink);
}
.ui-fmc__clear:disabled {
  color: var(--ui-fmc-faint);
  cursor: default;
}

/* ---------- Chips: one line, the rest go into "+N" ---------- */

.ui-fmc__chips-outer {
  overflow: hidden;
}
.ui-fmc__chips-outer[data-smooth] {
  transition: height 320ms var(--ui-fmc-ease);
}
.ui-fmc__chips {
  position: relative;
  display: flex;
  flex-wrap: nowrap;
  gap: 4px;
  padding: 0 16px 12px;
  overflow: hidden;
}
.ui-fmc__chips[data-empty] {
  padding-bottom: 0;
}
.ui-fmc__measure {
  position: absolute;
  top: 0;
  left: 0;
  display: flex;
  gap: 4px;
  width: max-content;
  visibility: hidden;
  pointer-events: none;
}
.ui-fmc__chip {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  height: 24px;
  padding: 0 3px 0 8px;
  border-radius: 6px;
  background: var(--ui-fmc-fill);
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-fmc-ink);
  white-space: nowrap;
  animation: ui-fmc-chip-in 260ms var(--ui-fmc-ease) both;
}
.ui-fmc__chip-label {
  min-width: 0;
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-fmc__chip-x {
  display: grid;
  place-items: center;
  flex: none;
  width: 18px;
  height: 18px;
  border-radius: 4px;
  color: var(--ui-fmc-icon);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-fmc__chip-x:hover {
  background: var(--ui-fmc-fill);
  color: var(--ui-fmc-ink);
}
.ui-fmc__chip-x svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.4;
  stroke-linecap: round;
}
.ui-fmc__more {
  padding: 0 8px;
  color: var(--ui-fmc-text);
  font-variant-numeric: tabular-nums;
  cursor: default;
}
.ui-fmc__roll {
  display: inline-block;
  animation: ui-fmc-roll 300ms var(--ui-fmc-ease) both;
}

/* ---------- Groups ---------- */

.ui-fmc__groups {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  padding: 4px;
  border-top: 0.5px solid var(--ui-fmc-line);
}
.ui-fmc__group-head {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px !important;
  border-radius: 6px;
  /* Hover comes in crisp and fades out when the pointer moves on */
  transition: background-color 140ms ease;
}
.ui-fmc__group-head:hover {
  background: var(--ui-fmc-wash);
  transition-duration: 90ms;
}
.ui-fmc__group-head:focus-visible,
.ui-fmc__option:focus-visible {
  outline-offset: -2px;
}
.ui-fmc__chevron {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-fmc-icon);
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
  transform: rotate(-90deg);
  transition: transform 260ms var(--ui-fmc-ease);
}
.ui-fmc__group[data-open] .ui-fmc__chevron {
  transform: none;
}
.ui-fmc__group-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
  font-weight: 500;
  color: var(--ui-fmc-ink);
  white-space: nowrap;
}
.ui-fmc__group-count {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fmc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-fmc__group-picked {
  display: inline-flex;
  flex: none;
  margin-left: auto;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fmc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.ui-fmc__panel {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 320ms var(--ui-fmc-ease);
}
.ui-fmc__group[data-open] .ui-fmc__panel {
  grid-template-rows: 1fr;
}
.ui-fmc__panel-inner {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  min-height: 0;
  overflow: hidden;
  padding: 0;
  opacity: 0;
  transition:
    opacity 220ms ease,
    padding 320ms var(--ui-fmc-ease);
}
.ui-fmc__group[data-open] .ui-fmc__panel-inner {
  opacity: 1;
  padding: 0 0 4px;
}
/* A long list scrolls inside the open group, so the card keeps a sane height */
.ui-fmc__group[data-open] .ui-fmc__panel-inner {
  max-height: 320px;
  overflow-x: hidden;
  overflow-y: auto;
  overscroll-behavior: contain;
}

/* Options sit under the group's label, the checkbox lined up with its text */
.ui-fmc__option {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px 0 32px !important;
  border-radius: 6px;
  color: var(--ui-fmc-ink);
  transition: background-color 140ms ease;
}
.ui-fmc__option:hover {
  background: var(--ui-fmc-wash);
  transition-duration: 90ms;
}
.ui-fmc__option-label {
  min-width: 0;
  text-align: start;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
/* Checkbox: 14px with a hairline, blue when picked; the check draws itself in */
.ui-fmc__box {
  display: grid;
  place-items: center;
  flex: none;
  width: 14px;
  height: 14px;
  border-radius: 4px;
  background: var(--ui-fmc-card);
  box-shadow:
    inset 0 0 0 0.5px var(--ui-fmc-box-ring),
    0 1px 1px 0 rgba(0, 0, 0, 0.04);
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-fmc__box svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: var(--ui-fmc-check);
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 12;
  stroke-dashoffset: 12;
  transition: stroke-dashoffset 240ms var(--ui-fmc-ease);
}
.ui-fmc__option[aria-checked="true"] .ui-fmc__box {
  background: var(--ui-fmc-accent);
  box-shadow: none;
}
.ui-fmc__option[aria-checked="true"] .ui-fmc__box svg {
  stroke-dashoffset: 0;
  transition-delay: 40ms;
}

/* ---------- Keyboard hints: the last row of the card ---------- */

.ui-fmc__hints {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 32px;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-fmc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-fmc-muted);
}
.ui-fmc__hint {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  white-space: nowrap;
}
.ui-fmc__hint > span {
  margin-left: 4px;
}
.ui-fmc kbd {
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-fmc-card);
  box-shadow: var(--ui-fmc-shadow);
  font-family: inherit;
  font-size: 10px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-fmc-text);
}

@keyframes ui-fmc-chip-in {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
}
@keyframes ui-fmc-roll {
  from {
    opacity: 0;
    transform: translateY(60%);
  }
  to {
    opacity: 1;
    transform: none;
  }
}

/* Narrow: a bit less side padding, shorter chips */
@container (max-width: 320px) {
  .ui-fmc__head {
    padding-left: 14px;
  }
  .ui-fmc__chips {
    padding-left: 14px;
    padding-right: 14px;
  }
  .ui-fmc__chip-label {
    max-width: 132px;
  }
}
/* Touch screens: taller rows and buttons */
@media (hover: none) and (pointer: coarse) {
  .ui-fmc__clear {
    height: 36px;
  }
  .ui-fmc__chip {
    height: 32px;
  }
  .ui-fmc__chip-x {
    width: 26px;
    height: 26px;
  }
  .ui-fmc__group-head {
    height: 44px;
  }
  .ui-fmc__option {
    height: 44px;
  }
  .ui-fmc__box {
    width: 18px;
    height: 18px;
    border-radius: 5px;
  }
  .ui-fmc__box svg {
    width: 14px;
    height: 14px;
  }
  .ui-fmc__hints {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-fmc *,
  .ui-fmc *::before,
  .ui-fmc *::after {
    animation: none !important;
    transition: none !important;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-fmc {
  --ui-fmc-card: #1c1c1e;
  --ui-fmc-ink: rgba(255, 255, 255, 0.9);
  --ui-fmc-strong: #ffffff;
  --ui-fmc-text: rgba(255, 255, 255, 0.62);
  --ui-fmc-muted: rgba(255, 255, 255, 0.46);
  --ui-fmc-faint: rgba(255, 255, 255, 0.3);
  --ui-fmc-icon: rgba(255, 255, 255, 0.5);
  --ui-fmc-line: rgba(255, 255, 255, 0.08);
  --ui-fmc-fill: rgba(255, 255, 255, 0.08);
  --ui-fmc-fill-strong: rgba(255, 255, 255, 0.13);
  --ui-fmc-wash: rgba(255, 255, 255, 0.04);
  --ui-fmc-box-ring: rgba(255, 255, 255, 0.28);
  --ui-fmc-accent: #4fb0fe;
  --ui-fmc-check: #ffffff;
  --ui-fmc-focus: rgba(77, 141, 255, 0.8);
  --ui-fmc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}

.ui-sgdc {
  --ui-sgdc-card: #ffffff;
  --ui-sgdc-strong: #000000;
  --ui-sgdc-ink: rgba(0, 0, 0, 0.88);
  --ui-sgdc-text: rgba(0, 0, 0, 0.61);
  --ui-sgdc-muted: rgba(0, 0, 0, 0.45);
  --ui-sgdc-faint: rgba(0, 0, 0, 0.27);
  --ui-sgdc-icon: rgba(0, 0, 0, 0.447);
  --ui-sgdc-line: rgba(0, 0, 0, 0.06);
  --ui-sgdc-fill: rgba(0, 0, 0, 0.06);
  --ui-sgdc-ring: rgba(0, 0, 0, 0.2);
  --ui-sgdc-wash: rgba(0, 0, 0, 0.03);
  --ui-sgdc-open: rgba(0, 0, 0, 0.025);
  --ui-sgdc-accent: rgba(0, 96, 226, 0.765);
  --ui-sgdc-on-accent: #ffffff;
  --ui-sgdc-focus: rgba(0, 96, 226, 0.7);
  --ui-sgdc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-sgdc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 320px;
  border-radius: 10px;
  background: var(--ui-sgdc-card);
  box-shadow: var(--ui-sgdc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-sgdc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-sgdc *,
.ui-sgdc *::before,
.ui-sgdc *::after {
  box-sizing: border-box;
}
:where(.ui-sgdc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-sgdc) svg {
  display: block;
  flex: none;
}
.ui-sgdc button:focus-visible {
  outline: 2px solid var(--ui-sgdc-focus);
  outline-offset: 2px;
}
.ui-sgdc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 10px 0 16px;
}
.ui-sgdc__title {
  overflow: hidden;
  min-width: 0;
  margin: 0;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-sgdc-strong);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-sgdc__actions {
  display: flex;
  flex: none;
  align-items: center;
  gap: 2px;
}
.ui-sgdc__edit {
  height: 28px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-sgdc-text);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-sgdc__edit:hover {
  background: var(--ui-sgdc-wash);
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-sgdc-icon);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-sgdc__icon-btn:hover {
  background: var(--ui-sgdc-wash);
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__icon-btn svg {
  width: 16px;
  height: 16px;
}
.ui-sgdc__progress {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 16px 12px;
}
.ui-sgdc__track {
  display: block;
  flex: 1;
  height: 4px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-sgdc-fill);
}
.ui-sgdc__fill {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ui-sgdc-accent);
  transform-origin: left center;
  transition: transform 700ms var(--ui-sgdc-ease);
}
.ui-sgdc__count {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__body {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 420ms var(--ui-sgdc-ease),
    opacity 260ms ease;
}
.ui-sgdc__body[data-hidden] {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-sgdc__groups {
  display: grid;
  gap: 2px;
  min-height: 0;
  overflow: hidden;
  padding: 0 4px;
  border-top: 0.5px solid var(--ui-sgdc-line);
}
.ui-sgdc__groups::before,
.ui-sgdc__groups::after {
  content: "";
  display: block;
  height: 2px;
}
.ui-sgdc__group {
  border-radius: 8px;
  transition: background-color 200ms ease;
}
.ui-sgdc__group[data-open] {
  background: var(--ui-sgdc-open);
}
.ui-sgdc__group-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  padding: 8px 8px 8px 12px;
  border-radius: 8px;
  text-align: left;
  transition: background-color 100ms ease;
}
.ui-sgdc__group-head:hover {
  background: var(--ui-sgdc-wash);
}
.ui-sgdc__group[data-open] .ui-sgdc__group-head:hover {
  background: none;
}
.ui-sgdc__group-title {
  position: relative;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-sgdc-strong);
  text-align: start;
  overflow-wrap: anywhere;
  transition: color 300ms ease;
}
.ui-sgdc__group-title[data-done] {
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__group-title::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  top: 52%;
  height: 1px;
  background: currentColor;
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform 420ms var(--ui-sgdc-ease);
}
.ui-sgdc__group-title[data-done]::after {
  transform: scaleX(1);
}
.ui-sgdc__chevron {
  width: 16px;
  height: 16px;
  margin-top: 2px;
  color: var(--ui-sgdc-icon);
  transition: transform 320ms var(--ui-sgdc-ease);
}
.ui-sgdc__group[data-open] .ui-sgdc__chevron {
  transform: rotate(180deg);
}
.ui-sgdc__panel {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 380ms var(--ui-sgdc-ease);
}
.ui-sgdc__group[data-open] .ui-sgdc__panel {
  grid-template-rows: 1fr;
}
.ui-sgdc__tasks {
  min-height: 0;
  overflow: hidden;
  margin: 0;
  padding: 0 4px;
  list-style: none;
}
.ui-sgdc__tasks li:last-child {
  padding-bottom: 6px;
}
.ui-sgdc__task {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  width: 100%;
  padding: 6px 8px;
  border-radius: 6px;
  text-align: left;
  opacity: 0;
  transform: translateY(-4px);
  transition:
    opacity 260ms ease,
    transform 320ms var(--ui-sgdc-ease),
    color 260ms ease,
    background-color 100ms ease;
}
.ui-sgdc__group[data-open] .ui-sgdc__task {
  opacity: 1;
  transform: none;
  transition-delay: 80ms, 80ms, 0ms, 0ms;
}
.ui-sgdc__task:not(:disabled):hover {
  background: var(--ui-sgdc-wash);
}
.ui-sgdc__task[data-state="current"] {
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__task[data-state="locked"] {
  color: var(--ui-sgdc-muted);
  cursor: default;
}
.ui-sgdc__task[data-state="done"] {
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__mark {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  border-radius: 50%;
  transition: box-shadow 160ms ease;
}
.ui-sgdc__task[data-state="current"] .ui-sgdc__mark {
  box-shadow: inset 0 0 0 1px var(--ui-sgdc-ring);
}
.ui-sgdc__task[data-state="current"]:hover .ui-sgdc__mark {
  box-shadow: inset 0 0 0 1px var(--ui-sgdc-accent);
}
.ui-sgdc__task[data-state="locked"] .ui-sgdc__mark {
  color: var(--ui-sgdc-faint);
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__mark {
  color: var(--ui-sgdc-accent);
}
.ui-sgdc__mark svg {
  width: 16px;
  height: 16px;
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__mark svg {
  animation: ui-sgdc-pop 420ms var(--ui-sgdc-ease);
}
.ui-sgdc__task-label {
  min-width: 0;
  font-size: 13px;
  line-height: 20px;
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  text-decoration-line: line-through;
  text-decoration-color: transparent;
  text-decoration-thickness: 1px;
  transition: text-decoration-color 260ms ease;
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__task-label {
  text-decoration-color: currentColor;
}
@keyframes ui-sgdc-pop {
  from {
    transform: scale(0.5);
    opacity: 0;
  }
}
@container (max-width: 300px) {
  .ui-sgdc__head {
    padding-left: 12px;
  }
  .ui-sgdc__progress {
    padding-inline: 12px;
  }
  .ui-sgdc__group-head {
    padding-left: 10px;
  }
}
@media (pointer: coarse) {
  .ui-sgdc__icon-btn {
    width: 36px;
    height: 36px;
  }
  .ui-sgdc__edit {
    height: 36px;
  }
  .ui-sgdc__group-head {
    padding-block: 12px;
  }
  .ui-sgdc__task {
    padding-block: 9px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-sgdc__fill,
  .ui-sgdc__body,
  .ui-sgdc__panel,
  .ui-sgdc__task,
  .ui-sgdc__chevron,
  .ui-sgdc__group,
  .ui-sgdc__group-title::after {
    transition: none;
  }
  .ui-sgdc__mark svg {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-sgdc {
  --ui-sgdc-card: #1c1c1e;
  --ui-sgdc-strong: #ffffff;
  --ui-sgdc-ink: rgba(255, 255, 255, 0.9);
  --ui-sgdc-text: rgba(255, 255, 255, 0.62);
  --ui-sgdc-muted: rgba(255, 255, 255, 0.46);
  --ui-sgdc-faint: rgba(255, 255, 255, 0.3);
  --ui-sgdc-icon: rgba(255, 255, 255, 0.5);
  --ui-sgdc-line: rgba(255, 255, 255, 0.08);
  --ui-sgdc-fill: rgba(255, 255, 255, 0.08);
  --ui-sgdc-ring: rgba(255, 255, 255, 0.26);
  --ui-sgdc-wash: rgba(255, 255, 255, 0.04);
  --ui-sgdc-open: rgba(255, 255, 255, 0.03);
  --ui-sgdc-accent: #4fb0fe;
  --ui-sgdc-on-accent: #ffffff;
  --ui-sgdc-focus: rgba(77, 141, 255, 0.8);
  --ui-sgdc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}

/* Workspace artifacts: the shared viewers in the work area's tabs – document, sheet, folder, code, image, menus */
.ui-as {
  --asw-out: cubic-bezier(0.23, 1, 0.32, 1);
  --asw-wire-ink: rgba(0, 0, 0, 0.42);
  --asw-wire-mid: rgba(0, 0, 0, 0.16);
  --asw-wire-soft: rgba(0, 0, 0, 0.07);
  --asw-grid: rgba(0, 0, 0, 0.08);
  --asw-rim: rgba(0, 0, 0, 0.025);
  /* Selection in a sheet or a folder – the only place the accent tints anything */
  --asw-sel-bg: rgba(0, 96, 226, 0.07);
  --asw-sel-head: rgba(0, 96, 226, 0.1);
  --asw-err: #c4320a;
  /* File glyphs by type: documents blue, sheets green, code orange, folders amber, images pink */
  --asw-file-doc: #0190fe;
  --asw-file-sheet: #5fc88a;
  --asw-file-code: #f28a2e;
  --asw-file-folder: #e8b000;
  --asw-file-image: #ee3e9e;
}
:where(.dark, [data-theme="dark"]) .ui-as {
  --asw-wire-ink: rgba(255, 255, 255, 0.5);
  --asw-wire-mid: rgba(255, 255, 255, 0.2);
  --asw-wire-soft: rgba(255, 255, 255, 0.08);
  --asw-grid: rgba(255, 255, 255, 0.09);
  --asw-rim: rgba(255, 255, 255, 0.03);
  --asw-sel-bg: rgba(79, 176, 254, 0.13);
  --asw-sel-head: rgba(79, 176, 254, 0.2);
  --asw-err: #ff6b5f;
  --asw-file-doc: #4fb0fe;
  --asw-file-sheet: #7dcf9f;
  --asw-file-code: #f2a15c;
  --asw-file-folder: #e6c24d;
  --asw-file-image: #f06db5;
}
.ui-asw-glyph[data-type] {
  color: var(--asw-file-doc);
}
.ui-asw-glyph[data-type="sheet"] {
  color: var(--asw-file-sheet);
}
.ui-asw-glyph[data-type="code"] {
  color: var(--asw-file-code);
}
.ui-asw-glyph[data-type="folder"] {
  color: var(--asw-file-folder);
}
.ui-asw-glyph[data-type="image"] {
  color: var(--asw-file-image);
}
.ui-asw-num {
  font-variant-numeric: tabular-nums;
}
.ui-asw-sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
  border: 0;
}
/* A tab's content: it fills the white sheet, and nothing in it widens the work area */
.ui-asw-pane {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  min-height: 100%;
}
.ui-asw-pane[hidden] {
  display: none;
}
/* Small buttons in the viewers, e.g. the link field's */
.ui-asw-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ink);
  white-space: nowrap;
  transition:
    box-shadow 140ms ease,
    background-color 140ms ease;
}
.ui-asw-btn:hover {
  box-shadow: var(--card-shadow-hover);
}
.ui-asw-btn--quiet {
  background: none;
  box-shadow: none;
  color: var(--text);
}
.ui-asw-btn--quiet:hover {
  background: var(--chip);
  box-shadow: none;
  color: var(--ink);
}
.ui-asw-btn:active {
  transform: scale(0.97);
}
/* Images as gray blocks */
.ui-asw-wire {
  display: block;
  width: 100%;
  height: auto;
}
.ui-asw-wire__frame {
  fill: var(--card);
  stroke: none;
}
.ui-asw-wire__block[data-tone="ink"] {
  fill: var(--asw-wire-ink);
}
.ui-asw-wire__block[data-tone="mid"] {
  fill: var(--asw-wire-mid);
}
.ui-asw-wire__block[data-tone="soft"] {
  fill: var(--asw-wire-soft);
}
/* Artifacts: soft gray file chips */
.ui-asw-files {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.ui-asw-file {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 26px;
  padding: 0 9px 0 7px;
  border-radius: 6px;
  background: var(--chip);
  font-size: 12px;
  color: var(--ink);
  transition: background-color 140ms ease;
}
.ui-asw-file:hover {
  background: linear-gradient(var(--hover), var(--hover)), var(--chip);
}
.ui-asw-file > svg {
  flex: none;
  color: var(--muted);
}
.ui-asw-file__name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
/* An opened artifact */
.ui-asw-art {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 2px 4px 16px;
}
.ui-asw-art__head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-asw-art__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--chip);
  color: var(--muted);
}
.ui-asw-art__glyph svg {
  width: 14px;
  height: 14px;
}
.ui-asw-art__title {
  display: grid;
  min-width: 0;
}
.ui-asw-art__title b {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ink);
}
.ui-asw-art__title span {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--muted);
}
.ui-asw-art__title i {
  font-style: normal;
  color: var(--faint);
}
/* Content sits right on the white sheet – a document as plain text, a sheet edge to edge */
.ui-asw-art__doc {
  font-size: 13px;
  line-height: 20px;
  color: var(--text);
}
.ui-asw-art__doc h3 {
  margin: 0 0 8px;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ink);
}
.ui-asw-art__doc p {
  margin: 0 0 10px;
}
.ui-asw-art__doc ul {
  display: grid;
  gap: 4px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-asw-art__doc li {
  position: relative;
  padding-left: 16px;
}
.ui-asw-art__doc li::before {
  content: "";
  position: absolute;
  top: 9px;
  left: 4px;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: var(--faint);
}
.ui-asw-art__code {
  margin: 0;
  padding: 14px 16px;
  border-radius: 10px;
  background: var(--chip);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  line-height: 19px;
  color: var(--ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-asw-art__image {
  padding: 16px;
  border-radius: 10px;
  background: var(--card);
  box-shadow: var(--card-shadow);
}
.ui-asw-art__image .ui-asw-wire {
  display: block;
  width: 100%;
  height: auto;
}
.ui-asw-art__files {
  display: grid;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-asw-art__files li {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 34px;
  font-size: 13px;
  color: var(--ink);
}
.ui-asw-art__files li + li {
  box-shadow: inset 0 0.5px 0 var(--line);
}
.ui-asw-art__files svg {
  flex: none;
  color: var(--muted);
}
.ui-asw-art__files span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-asw-art__none {
  margin: 0;
  font-size: 13px;
  color: var(--muted);
}

/* ---------- Artifact toolbars – compact gray tools, groups apart, a hairline under them edge to edge ---------- */
.ui-asw-tb {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  margin: 0 -18px;
  padding: 0 12px 8px;
  box-shadow: inset 0 -0.5px 0 var(--line);
}
.ui-asw-tb__group {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
}
.ui-asw-tool-anchor {
  flex: none;
}
.ui-asw-tool {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-width: 28px;
  height: 28px;
  padding: 0;
  border-radius: 6px;
  color: var(--muted);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-asw-tool--menu {
  gap: 2px;
  padding: 0 4px 0 6px;
}
.ui-asw-tool--menu > svg:last-child {
  color: var(--faint);
}
.ui-asw-tool:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-tool:is([aria-pressed="true"], [aria-expanded="true"]) {
  background: var(--chip);
  color: var(--ink);
}
.ui-asw-tool[aria-disabled] {
  opacity: 0.35;
  cursor: default;
}
.ui-asw-tool[aria-disabled]:hover {
  background: none;
  color: var(--muted);
}
.ui-asw-tool:active:not([aria-disabled]) {
  transform: scale(0.96);
}
.ui-asw-tool__text {
  padding: 0 2px 0 4px;
  font-size: 13px;
  color: var(--text);
  white-space: nowrap;
}
/* The tip under a tool: dark, small, kept inside the toolbar's width */
.ui-asw-tip {
  position: absolute;
  z-index: 40;
  left: 0;
  display: flex;
  gap: 6px;
  padding: 3px 7px;
  border-radius: 6px;
  background: var(--ink);
  font-size: 12px;
  line-height: 16px;
  color: var(--card);
  white-space: nowrap;
  pointer-events: none;
  animation: ui-asw-fade 120ms ease both;
}
.ui-asw-tip kbd {
  font: inherit;
  opacity: 0.6;
}

/* ---------- Document ---------- */
.ui-asw-dc {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
/* The tools stay at the top while the page scrolls under them */
.ui-asw-dc__tools {
  position: sticky;
  top: -16px;
  z-index: 4;
  padding-top: 4px;
  margin-top: -4px;
  background: var(--card);
}
.ui-asw-doc {
  min-height: 220px;
  padding: 16px 0 12px;
  font-size: 13px;
  line-height: 20px;
  color: var(--text);
  outline: none;
  overflow-wrap: anywhere;
  cursor: text;
}
.ui-as .ui-asw-doc:focus-visible {
  outline: none;
}
.ui-asw-doc > :first-child {
  margin-top: 0;
}
.ui-asw-doc :is(h1, h2, h3) {
  color: var(--ink);
  font-weight: 500;
}
.ui-asw-doc h1 {
  margin: 0 0 8px;
  font-size: 18px;
  line-height: 26px;
  letter-spacing: -0.15px;
}
.ui-asw-doc h2 {
  margin: 18px 0 6px;
  font-size: 15px;
  line-height: 22px;
}
.ui-asw-doc h3 {
  margin: 14px 0 4px;
  font-size: 13px;
  line-height: 20px;
}
.ui-asw-doc p {
  margin: 0 0 10px;
}
.ui-asw-doc blockquote {
  margin: 0 0 10px;
  padding-left: 12px;
  box-shadow: inset 2px 0 0 var(--line-strong);
  color: var(--muted);
}
/* Bold in the text is 600: the browser's own bold commands read the weight, so 500 wouldn't toggle off */
.ui-asw-doc :is(b, strong) {
  font-weight: 600;
  color: var(--ink);
}
.ui-asw-doc a {
  color: var(--ink);
  text-decoration: underline;
  text-decoration-color: var(--line-strong);
  text-underline-offset: 2px;
}
.ui-asw-doc code {
  padding: 1px 4px;
  border-radius: 4px;
  background: var(--chip);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px;
  color: var(--ink);
}
.ui-asw-doc :is(ul, ol) {
  margin: 0 0 10px;
  padding-left: 20px;
}
.ui-asw-doc :is(ul, ol) :is(ul, ol) {
  margin: 2px 0 0;
}
.ui-asw-doc li {
  margin: 2px 0;
  padding-left: 2px;
}
.ui-asw-doc li::marker {
  color: var(--faint);
}
/* A checklist: a box in front of each item – click it, or ⌘ Enter; done items go gray */
.ui-asw-doc ul[data-check] {
  padding-left: 0;
  list-style: none;
}
.ui-asw-doc ul[data-check] > li {
  position: relative;
  padding-left: 24px;
}
.ui-asw-doc ul[data-check] > li::before {
  content: "";
  position: absolute;
  top: 3px;
  left: 1px;
  width: 14px;
  height: 14px;
  border-radius: 4px;
  background: var(--card);
  box-shadow:
    inset 0 0 0 1px var(--line-strong),
    0 0.5px 1px rgba(0, 0, 0, 0.06);
  cursor: pointer;
  transition:
    background-color 120ms ease,
    box-shadow 120ms ease;
}
.ui-asw-doc ul[data-check] > li[data-done]::before {
  background: var(--ink);
  box-shadow: none;
}
.ui-asw-doc ul[data-check] > li[data-done]::after {
  content: "";
  position: absolute;
  top: 6px;
  left: 6px;
  width: 3.5px;
  height: 6.5px;
  border: solid var(--card);
  border-width: 0 1.5px 1.5px 0;
  transform: rotate(45deg);
  pointer-events: none;
}
.ui-asw-doc ul[data-check] > li[data-done] {
  color: var(--muted);
  text-decoration: line-through;
  text-decoration-color: var(--faint);
}
.ui-asw-doc--still {
  min-height: 0;
  padding: 0;
  cursor: auto;
}
.ui-asw-dc__foot {
  margin: 0 -18px;
  padding: 8px 18px 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--faint);
  box-shadow: inset 0 0.5px 0 var(--line);
}
.ui-asw-dc__foot i {
  font-style: normal;
}
/* The link field */
.ui-asw-linkpop {
  width: min(280px, 80vw);
  padding: 6px;
  border-radius: 10px;
  background: var(--card);
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 12px 32px -8px rgba(0, 0, 0, 0.16);
}
.ui-asw-linkpop form {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ui-asw-linkpop input {
  flex: 1;
  min-width: 0;
  height: 28px;
  padding: 0 8px;
  border: 0;
  border-radius: 6px;
  background: none;
  box-shadow: inset 0 0 0 0.5px var(--line-strong);
  font: inherit;
  font-size: 13px;
  color: var(--ink);
  outline: none;
}
.ui-asw-linkpop input::placeholder {
  color: var(--placeholder);
}
/* Typing in a field: no ring – the caret shows where you are, the edge only firms up a little */
.ui-asw-linkpop input:is(:focus, :focus-visible) {
  outline: none;
  box-shadow: inset 0 0 0 1px var(--line-strong);
}
.ui-asw-linkpop .ui-asw-btn {
  flex: none;
}

/* ---------- Sheet ---------- */
.ui-asw-sh {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
/* The name box, fx and the formula bar – one hairline field */
.ui-asw-sh__bar {
  display: grid;
  grid-template-columns: 64px 22px minmax(0, 1fr);
  align-items: center;
  height: 28px;
  margin: 10px 0;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--line-strong);
  font-size: 12px;
  transition: box-shadow 120ms ease;
}
.ui-asw-sh__bar:focus-within {
  box-shadow: inset 0 0 0 1px var(--line-strong);
}
.ui-asw-sh__bar input {
  min-width: 0;
  height: 100%;
  padding: 0 8px;
  border: 0;
  background: none;
  font: inherit;
  color: var(--ink);
  outline: none;
}
.ui-asw-sh__ref {
  box-shadow: inset -0.5px 0 0 var(--line-strong);
  text-align: center;
}
.ui-asw-sh__fx {
  font-size: 12px;
  font-style: italic;
  text-align: center;
  color: var(--faint);
}
.ui-asw-sh__formula {
  padding-left: 2px !important;
}
/* The grid edge to edge – it scrolls sideways inside itself, never the panel */
.ui-asw-sh__wrap {
  position: relative;
  margin: 0 -18px;
  overflow-x: auto;
  overflow-y: hidden;
  overscroll-behavior-x: none;
  background: var(--card);
  scrollbar-width: thin;
}
.ui-asw-sh__grid {
  table-layout: fixed;
  border-collapse: collapse;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  outline: none;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
}
.ui-as .ui-asw-sh__grid:focus-visible {
  outline: none;
}
.ui-asw-sh__grid :is(th, td) {
  box-sizing: border-box;
  height: 26px;
  padding: 0 8px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: clip;
  text-align: left;
  box-shadow: inset -0.5px -0.5px 0 var(--asw-grid);
}
.ui-asw-sh__cell {
  position: relative;
  color: var(--ink);
  cursor: cell;
}
.ui-asw-sh__cell[data-num] {
  text-align: right;
}
.ui-asw-sh__cell[data-bold] {
  font-weight: 500;
}
.ui-asw-sh__cell[data-err] {
  color: var(--asw-err);
  text-align: center;
}
.ui-asw-sh__cell[data-sel] {
  background: var(--asw-sel-bg);
}
/* Letters and numbers: a faint gray rim, centered – the selected ones tint */
.ui-asw-sh__grid :is(.ui-asw-sh__corner, .ui-asw-sh__col, .ui-asw-sh__row) {
  padding: 0;
  background: var(--asw-rim);
  font-size: 11px;
  font-weight: 400;
  text-align: center;
  color: var(--faint);
  cursor: default;
  transition:
    background-color 80ms ease,
    color 80ms ease;
}
.ui-asw-sh__grid :is(.ui-asw-sh__col, .ui-asw-sh__corner) {
  position: relative;
  height: 22px;
  overflow: visible;
  box-shadow:
    inset -0.5px -0.5px 0 var(--asw-grid),
    inset 0 0.5px 0 var(--asw-grid);
}
.ui-asw-sh__grid :is(.ui-asw-sh__row, .ui-asw-sh__corner) {
  position: sticky;
  left: 0;
  z-index: 2;
  background: linear-gradient(var(--asw-rim), var(--asw-rim)), var(--card);
}
.ui-asw-sh__grid .ui-asw-sh__col[data-on] {
  background: var(--asw-sel-head);
  color: var(--ink);
}
.ui-asw-sh__grid .ui-asw-sh__row[data-on] {
  background:
    linear-gradient(var(--asw-sel-head), var(--asw-sel-head)), var(--card);
  color: var(--ink);
}
.ui-asw-sh__grid .ui-asw-sh__pad {
  padding: 0;
  box-shadow: inset 0 -0.5px 0 var(--asw-grid);
}
.ui-asw-sh__grid thead .ui-asw-sh__pad {
  background: var(--asw-rim);
  box-shadow:
    inset 0 -0.5px 0 var(--asw-grid),
    inset 0 0.5px 0 var(--asw-grid);
}
/* A column's right edge: drag it, or double-click to fit */
.ui-asw-sh__resize {
  position: absolute;
  top: 0;
  right: -4px;
  z-index: 3;
  width: 8px;
  height: 100%;
  cursor: col-resize;
  touch-action: none;
}
.ui-asw-sh__resize::after {
  content: "";
  position: absolute;
  top: 3px;
  bottom: 3px;
  left: 3.25px;
  width: 1.5px;
  border-radius: 1px;
  background: var(--accent);
  opacity: 0;
  transition: opacity 120ms ease;
}
.ui-asw-sh__resize:hover::after {
  opacity: 1;
}
/* The selection's ring with the fill handle – gray while the sheet doesn't have the focus */
.ui-asw-sh__ring {
  position: absolute;
  z-index: 1;
  box-sizing: border-box;
  box-shadow: inset 0 0 0 2px var(--muted);
  pointer-events: none;
}
.ui-asw-sh:focus-within .ui-asw-sh__ring {
  box-shadow: inset 0 0 0 2px var(--accent);
}
/* A range: a thin ring around it all, the first cell keeps the strong one */
.ui-asw-sh__ring[data-range],
.ui-asw-sh:focus-within .ui-asw-sh__ring[data-range] {
  box-shadow: inset 0 0 0 1px var(--muted);
}
.ui-asw-sh:focus-within .ui-asw-sh__ring[data-range] {
  box-shadow: inset 0 0 0 1px var(--accent);
}
.ui-asw-sh__handle {
  position: absolute;
  right: -3px;
  bottom: -3px;
  width: 6px;
  height: 6px;
  background: var(--muted);
  box-shadow: 0 0 0 1px var(--card);
  pointer-events: auto;
  cursor: crosshair;
  touch-action: none;
}
.ui-asw-sh:focus-within .ui-asw-sh__handle {
  background: var(--accent);
}
.ui-asw-sh__fill {
  position: absolute;
  z-index: 1;
  outline: 1px dashed var(--muted);
  outline-offset: -1px;
  pointer-events: none;
}
/* Writing in a cell: the field sits on it and grows with what you type */
.ui-asw-sh__input {
  position: absolute;
  z-index: 3;
  top: 0;
  left: 0;
  box-sizing: border-box;
  height: 100%;
  padding: 0 7px;
  border: 0;
  background: var(--card);
  box-shadow:
    inset 0 0 0 1.5px var(--accent),
    0 4px 12px -4px rgba(0, 0, 0, 0.16);
  font: inherit;
  color: var(--ink);
  text-align: left;
  outline: none;
}
/* Sum · Average · Count of the selection, like Excel's status bar */
.ui-asw-sh__status {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 14px;
  height: 28px;
  margin: 0 -18px;
  padding: 0 18px;
  overflow: hidden;
  font-size: 12px;
  color: var(--muted);
  white-space: nowrap;
  box-shadow: inset 0 0.5px 0 var(--asw-grid);
}
.ui-asw-sh__status b {
  font-weight: 500;
  color: var(--ink);
}

/* ---------- Folder ---------- */
.ui-asw-fd {
  display: flex;
  flex-direction: column;
  min-width: 0;
}
.ui-asw-fd__tools {
  flex-wrap: nowrap;
}
.ui-asw-fd__crumbs {
  display: flex;
  flex: 1 1 0;
  align-items: center;
  min-width: 0;
  overflow: hidden;
}
.ui-asw-fd__crumb {
  flex: 0 1 auto;
  min-width: 24px;
  max-width: 100%;
  height: 28px;
  padding: 0 6px;
  overflow: hidden;
  border-radius: 6px;
  font-size: 13px;
  color: var(--muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-asw-fd__crumb:not([aria-current]):hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-fd__crumb[aria-current] {
  flex-shrink: 0.2;
  font-weight: 500;
  color: var(--ink);
  cursor: default;
}
.ui-asw-fd__sep {
  display: grid;
  flex: none;
  place-items: center;
  color: var(--faint);
}
.ui-asw-fd__search {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin: 10px 0 6px;
  padding: 0 8px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--line-strong);
  color: var(--faint);
  transition: box-shadow 120ms ease;
}
.ui-asw-fd__search:focus-within {
  box-shadow: inset 0 0 0 1px var(--line-strong);
}
.ui-asw-fd__search > svg {
  flex: none;
}
.ui-asw-fd__search input {
  flex: 1;
  min-width: 0;
  height: 100%;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  font-size: 13px;
  color: var(--ink);
  outline: none;
}
.ui-asw-fd__search input::placeholder {
  color: var(--placeholder);
}
/* The list: Name, Size, Modified – fixed rows, hairlines between them */
.ui-asw-fd__head,
.ui-asw-fd__row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 64px;
  column-gap: 10px;
  align-items: center;
  padding: 0 8px;
}
.ui-asw-fd__head[data-date],
.ui-asw-fd__row[data-date] {
  grid-template-columns: minmax(0, 1fr) 58px 72px;
}
@container (min-width: 420px) {
  .ui-asw-fd__head[data-date],
  .ui-asw-fd__row[data-date] {
    grid-template-columns: minmax(0, 1fr) 64px 112px;
  }
}
.ui-asw-fd {
  container-type: inline-size;
}
.ui-asw-fd__head {
  height: 26px;
  box-shadow: inset 0 -0.5px 0 var(--line);
}
.ui-asw-fd__sort {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  height: 22px;
  padding: 0 4px;
  margin: 0 -4px;
  border-radius: 5px;
  font-size: 12px;
  color: var(--muted);
  justify-self: start;
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-asw-fd__sort:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-fd__sort[data-on] {
  color: var(--ink);
}
.ui-asw-fd__head > .ui-asw-fd__sort:nth-child(2) {
  justify-self: end;
}
/* Free space under the items, like Finder's – a right-click there is about the folder, not an item */
.ui-asw-fd__body {
  position: relative;
  min-height: 236px;
  padding-bottom: 28px;
}
.ui-asw-fd__list,
.ui-asw-fd__grid {
  outline: none;
}
.ui-as .ui-asw-fd__body [role="listbox"]:focus-visible {
  outline: none;
}
.ui-asw-fd__row {
  height: 30px;
  font-size: 13px;
  color: var(--ink);
  cursor: default;
  box-shadow: inset 0 -0.5px 0 var(--line);
}
.ui-asw-fd__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-asw-fd__name > svg {
  flex: none;
  width: 14px;
  height: 14px;
  color: var(--muted);
}
.ui-asw-fd__name > span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-asw-fd__meta {
  overflow: hidden;
  font-size: 12px;
  color: var(--muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-asw-fd__row > .ui-asw-fd__meta:nth-child(2) {
  text-align: right;
}
.ui-asw-fd__row > .ui-asw-fd__meta:nth-child(3),
.ui-asw-fd__head > .ui-asw-fd__sort:nth-child(3) {
  justify-self: end;
  text-align: right;
}
.ui-asw-fd__row[aria-selected="true"],
.ui-asw-fd__tile[aria-selected="true"] {
  background: var(--asw-sel-bg);
}
/* The keyboard's place in the list: an inset ring, only while the list has the keyboard focus */
.ui-asw-fd__body [role="listbox"]:focus-visible [data-cur] {
  outline: 2px solid var(--ui-as-focus);
  outline-offset: -2px;
}
.ui-as .ui-asw-fd__body [role="listbox"]:focus-visible:not(:has([data-cur])) {
  outline: 2px solid var(--ui-as-focus);
  outline-offset: -2px;
}
/* Icons: tiles with the glyph and the name under it */
.ui-asw-fd__grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(84px, 1fr));
  gap: 4px;
  padding: 8px 0 4px;
}
.ui-asw-fd__tile {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: 88px;
  padding: 10px 4px 6px;
  border-radius: 8px;
  cursor: default;
}
.ui-asw-fd__tile .ui-asw-fd__name {
  flex-direction: column;
  gap: 6px;
  width: 100%;
}
.ui-asw-fd__tile .ui-asw-fd__name > svg {
  width: 36px;
  height: 36px;
}
.ui-asw-fd__tile .ui-asw-fd__name > span {
  display: -webkit-box;
  max-width: 100%;
  font-size: 12px;
  line-height: 16px;
  text-align: center;
  white-space: normal;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  color: var(--ink);
}
.ui-asw-fd__empty {
  margin: 0;
  padding: 24px 8px;
  font-size: 13px;
  text-align: center;
  color: var(--muted);
}
.ui-asw-fd__foot {
  margin: 8px -18px 0;
  padding: 8px 18px 0;
  font-size: 12px;
  line-height: 16px;
  text-align: center;
  color: var(--faint);
  box-shadow: inset 0 0.5px 0 var(--line);
}
/* Quick Look: a card over the list */
.ui-asw-ql {
  position: absolute;
  z-index: 5;
  top: 6px;
  left: -6px;
  right: -6px;
  display: flex;
  flex-direction: column;
  max-height: 380px;
  overflow: hidden;
  border-radius: 12px;
  background: var(--card);
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 18px 44px -12px rgba(0, 0, 0, 0.26);
  animation: ui-asw-ql 200ms var(--asw-out) both;
}
.ui-asw-ql__head {
  display: flex;
  flex: none;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 48px;
  padding: 0 8px 0 12px;
  box-shadow: inset 0 -0.5px 0 var(--line);
}
.ui-asw-ql__head .ui-asw-art__title {
  flex: 1;
}
.ui-asw-ql__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--muted);
  transition: background-color 120ms ease;
}
.ui-asw-ql__close:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-ql__body {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 14px 14px 16px;
}
.ui-asw-ql__body .ui-asw-wire {
  display: block;
  width: 100%;
  height: auto;
}
.ui-asw-ql__none {
  margin: 0;
  padding: 28px 0;
  font-size: 13px;
  text-align: center;
  color: var(--muted);
}
.ui-asw-ql__sheet {
  overflow-x: auto;
}
.ui-asw-ql__sheet table {
  border-collapse: collapse;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}
.ui-asw-ql__sheet td {
  height: 24px;
  padding: 0 8px;
  white-space: nowrap;
  color: var(--ink);
  box-shadow: inset -0.5px -0.5px 0 var(--asw-grid);
}
.ui-asw-ql__sheet td[data-num] {
  text-align: right;
}
.ui-asw-ql__sheet tr[data-head] td {
  font-weight: 500;
}
.ui-asw-fd__rename {
  flex: 1;
  min-width: 0;
  height: 22px;
  margin: 0 -4px;
  padding: 0 4px;
  border: 0;
  border-radius: 4px;
  background: var(--card);
  box-shadow: inset 0 0 0 1px var(--line-strong);
  font: inherit;
  font-size: inherit;
  color: var(--ink);
  outline: none;
}
.ui-asw-fd__tile .ui-asw-fd__rename {
  flex: none;
  width: 100%;
  margin: 0;
  text-align: center;
  font-size: 12px;
}
@keyframes ui-asw-ql {
  from {
    opacity: 0;
    transform: scale(0.97) translateY(-4px);
  }
}

/* ---------- Context menus – the shell's menu (.ui-as-menu), placed at the pointer ---------- */
.ui-asw-ctx {
  position: fixed;
  z-index: 80;
  min-width: 200px;
  max-width: min(300px, calc(100vw - 12px));
  animation: ui-asw-ctx 120ms ease both;
}
.ui-asw-ctx__row {
  position: relative;
  display: block;
}
.ui-asw-ctx .ui-as-menu__item[aria-disabled] {
  opacity: 0.4;
  cursor: default;
}
.ui-asw-ctx .ui-as-menu__item[aria-disabled]:is(:hover, :focus-visible) {
  background: none;
}
.ui-asw-ctx .ui-as-menu__item:focus {
  outline: none;
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-ctx .ui-as-menu__item[data-open] {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-ctx .ui-as-menu__item[aria-haspopup] > svg:last-child {
  color: var(--faint);
}
.ui-asw-ctx .ui-as-menu__item[data-danger]:is(:hover, :focus) {
  background: rgba(240, 68, 56, 0.08);
}
.ui-asw-ctx__sub {
  position: absolute;
  z-index: 1;
  top: -4px;
  left: calc(100% + 4px);
  min-width: 224px;
}
.ui-asw-ctx__sub[data-flip] {
  right: calc(100% + 4px);
  left: auto;
}
/* A bridge over the gap, so the pointer can cross to the submenu */
.ui-asw-ctx__sub::before {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: -8px;
  width: 8px;
}
.ui-asw-ctx__sub[data-flip]::before {
  right: -8px;
  left: auto;
}
@keyframes ui-asw-ctx {
  from {
    opacity: 0;
    transform: scale(0.98);
  }
}

@keyframes ui-asw-fade {
  from {
    opacity: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-asw-ql,
  .ui-asw-tip,
  .ui-asw-ctx {
    animation: none !important;
  }
  .ui-asw-tool:active:not([aria-disabled]),
  .ui-asw-btn:active {
    transform: none;
  }
}

/* Touch: every control at least 36px */
@media (pointer: coarse) {
  .ui-asw-btn {
    min-height: 36px;
  }
  .ui-asw-tool,
  .ui-asw-fd__crumb {
    min-width: 36px;
    height: 36px;
  }
  .ui-asw-fd__row {
    height: 40px;
  }
}

.ui-asw {
  display: flex;
  flex-direction: column;
  gap: 22px;
  padding: 0 2px;
}

/* Address field: a white pill with a hairline, like the search fields in the screens */
.ui-asw__address {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 34px;
  padding: 0 12px;
  border-radius: 10px;
  background: var(--card);
  box-shadow:
    inset 0 0 0 0.5px var(--line-strong),
    var(--shadow);
  color: var(--faint);
  cursor: text;
}
.ui-asw__address:focus-within {
  box-shadow:
    inset 0 0 0 1px var(--line-strong),
    var(--shadow);
}
.ui-asw__address input {
  flex: 1;
  min-width: 0;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: 13px;
  color: var(--ink);
}
.ui-asw__address input::placeholder {
  color: var(--placeholder);
}

.ui-asw__section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.ui-asw__label {
  margin: 0;
  padding: 0 4px;
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--muted);
}

/* Rows sit on one white card, split by hairlines – the same card style as the screens */
.ui-asw__list {
  display: flex;
  flex-direction: column;
  padding: 4px;
  border-radius: 12px;
  background: var(--card);
  box-shadow:
    inset 0 0 0 0.5px var(--line-strong),
    var(--shadow);
}
.ui-asw__row {
  position: relative;
  display: flex;
  align-items: center;
  border-radius: 8px;
  transition: background-color 140ms ease;
}
.ui-asw__row + .ui-asw__row::before {
  content: "";
  position: absolute;
  top: -0.5px;
  left: 44px;
  right: 8px;
  height: 1px;
  background: var(--line-soft);
}
.ui-asw__open {
  display: flex;
  flex: 1;
  min-width: 0;
  align-items: center;
  gap: 10px;
  height: 40px;
  padding: 0 8px;
  border-radius: 8px;
  text-align: left;
  transition: background-color 140ms ease;
}
/* The hover fills the whole row, the ⋯ button at its end included */
.ui-asw__row:hover {
  background: var(--hover);
}
.ui-asw__source {
  height: 48px;
  flex: none;
}

.ui-asw__tile {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: var(--chip);
  color: var(--text);
}
.ui-asw__tile--mark {
  font-size: 11.5px;
  font-weight: 500;
  color: var(--muted);
}

.ui-asw__text {
  display: flex;
  flex: 1;
  min-width: 0;
  flex-direction: column;
}
.ui-asw__name {
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  font-weight: 450;
  color: var(--ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-asw__open > .ui-asw__name {
  flex: 1;
}
.ui-asw__meta {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-asw__empty {
  margin: 0;
  padding: 0 4px;
  font-size: 13px;
  line-height: 18px;
  color: var(--faint);
}

.ui-asw__kbd {
  flex: none;
  padding: 1px 6px;
  border-radius: 6px;
  background: var(--chip);
  font: inherit;
  font-size: 11px;
  line-height: 18px;
  color: var(--muted);
  font-variant-numeric: tabular-nums;
  transition: opacity 140ms ease;
}
/* The shortcut sits flush right; on hover the ⋯ button takes its place */
.ui-asw__more {
  position: absolute;
  top: 50%;
  right: 6px;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  color: var(--faint);
  opacity: 0;
  translate: 0 -50%;
  transition:
    opacity 140ms ease,
    background-color 140ms ease;
}
.ui-asw__row:is(:hover, :focus-within) .ui-asw__more {
  opacity: 1;
}
.ui-asw__row:is(:hover, :focus-within) .ui-asw__kbd {
  opacity: 0;
}
.ui-asw__more:hover {
  background: var(--hover);
  color: var(--text);
}
.ui-asw__go {
  flex: none;
  color: var(--faint);
  opacity: 0;
  translate: -2px 0;
  transition:
    opacity 140ms ease,
    translate 200ms var(--ease);
}
.ui-asw__source:hover .ui-asw__go {
  opacity: 1;
  translate: 0 0;
}

.ui-as {
  --tray: #f4f4f4;
  --card: #ffffff;
  --page: #f8f8f8;
  --side-tint: #fcfcfc;
  --panel: #ffffff;
  --radius-panel: 12px;
  --frame-gap: 8px;
  --as-head-h: 48px;
  --as-head-edge: 1px;
  --line: rgba(0, 0, 0, 0.06);
  --line-soft: rgba(0, 0, 0, 0.04);
  --strong: #000000;
  --ink: rgba(0, 0, 0, 0.88);
  --text: rgba(0, 0, 0, 0.61);
  --muted: rgba(0, 0, 0, 0.45);
  --faint: rgba(0, 0, 0, 0.27);
  --placeholder: rgba(0, 0, 0, 0.27);
  --chip: rgba(0, 0, 0, 0.04);
  --chip-hover: rgba(0, 0, 0, 0.06);
  --hover: rgba(0, 0, 0, 0.03);
  --accent: #0070d6;
  --ui-as-focus: rgba(0, 96, 226, 0.7);
  --button: rgba(0, 0, 0, 0.88);
  --button-hover: rgba(0, 0, 0, 0.78);
  --accent-soft: rgba(0, 96, 226, 0.08);
  --shadow: 0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --card-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --card-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 2px 6px -1px rgba(0, 0, 0, 0.08),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --frame: rgba(0, 0, 0, 0.02);
  --line-strong: rgba(0, 0, 0, 0.1);
  --edge-active: rgba(0, 0, 0, 0.14);
  --subtle: #fafafa;
  --disabled: #dcdcdc;
  --on-ink: #ffffff;
  --ink-hover: #3a3a3a;
  --select: rgba(0, 0, 0, 0.055);
  --toggle-off: #e2e2e2;
  --switch-on: #171717;
  --logo-bg: #ffffff;
  --ease: cubic-bezier(0.22, 1, 0.36, 1);
  --font:
    "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto,
    sans-serif;
}
.ui-as .ui-apc__foot .ui-apc__actions {
  flex: 0 0 auto;
  margin-left: auto;
}
:where(.dark, [data-theme="dark"]) .ui-as {
  --tray: #1d1d20;
  --card: #1b1b1e;
  --page: #0e0e10;
  --side-tint: #111113;
  --panel: #141416;
  --line: rgba(255, 255, 255, 0.08);
  --line-soft: rgba(255, 255, 255, 0.05);
  --strong: #ffffff;
  --ink: rgba(255, 255, 255, 0.9);
  --text: rgba(255, 255, 255, 0.62);
  --muted: rgba(255, 255, 255, 0.45);
  --faint: rgba(255, 255, 255, 0.28);
  --placeholder: rgba(255, 255, 255, 0.28);
  --chip: rgba(255, 255, 255, 0.06);
  --chip-hover: rgba(255, 255, 255, 0.09);
  --hover: rgba(255, 255, 255, 0.05);
  --accent: #4fb0fe;
  --ui-as-focus: rgba(77, 141, 255, 0.8);
  --button: #f4f4f5;
  --button-hover: #ffffff;
  --accent-soft: rgba(79, 176, 254, 0.16);
  --shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --card-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px rgba(0, 0, 0, 0.4);
  --card-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 2px 6px rgba(0, 0, 0, 0.4);
  --frame: rgba(255, 255, 255, 0.03);
  --line-strong: rgba(255, 255, 255, 0.14);
  --edge-active: rgba(255, 255, 255, 0.18);
  --subtle: #18181b;
  --disabled: #3a3a3f;
  --on-ink: #111113;
  --ink-hover: #d4d4d8;
  --select: rgba(255, 255, 255, 0.08);
  --toggle-off: #3a3a3f;
  --switch-on: #4fb0fe;
  --logo-bg: #2a2a2e;
  color-scheme: dark;
}
.ui-as,
.ui-as *,
.ui-as *::before,
.ui-as *::after {
  box-sizing: border-box;
}
.ui-as {
  font-family: var(--font);
  font-size: 13px;
  color: var(--text);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
:where(.ui-as) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-as) svg {
  display: block;
  flex: none;
}
.ui-as :where(:focus-visible) {
  outline: 2px solid var(--ui-as-focus);
  outline-offset: 2px;
}
.ui-as textarea:focus-visible,
.ui-as input:focus-visible {
  outline: none;
}
.ui-as-app {
  container: ui-as / inline-size;
  position: relative;
  display: grid;
  --side-col: var(--side-w, 272px);
  --panel-col: 0px;
  grid-template-columns: var(--side-col) minmax(0, 1fr) var(--panel-col);
  height: 100%;
  min-height: 560px;
  background: var(--page);
  transition: grid-template-columns 420ms var(--ease);
}
.ui-as-app[data-panel="open"] {
  --panel-col: var(--panel-w, 360px);
}
.ui-as-app[data-resizing] {
  transition: none;
  cursor: col-resize;
  user-select: none;
}
.ui-as-app[data-resizing] :is(.ui-as-main, .ui-as-side, .ui-as-panel) {
  transition: none;
}
.ui-as-side {
  display: flex;
  flex-direction: column;
  width: var(--side-w, 272px);
  min-height: 0;
  padding: 10px 8px 8px 10px;
  transition:
    opacity 260ms ease,
    translate 420ms var(--ease),
    visibility 0s;
}
.ui-as-app[data-collapsed] {
  --side-col: 48px;
}
.ui-as-app[data-collapsed] > .ui-as-side {
  width: 100%;
  overflow: hidden;
}
.ui-as-app[data-collapsed] > .ui-as-side > * {
  flex-shrink: 0;
  width: calc(var(--side-w, 272px) - 20px);
}
.ui-as-app[data-collapsed]
  :is(
    .ui-as-side__name,
    .ui-as-side__workspace > svg,
    .ui-as-side__text,
    .ui-as-side__count,
    .ui-as-user__name,
    .ui-as-user > svg,
    .ui-as-side__search > span,
    .ui-as-side__search > kbd
  ) {
  display: none;
}
.ui-as-app[data-collapsed]
  :is(
    .ui-as-side__item,
    .ui-as-side__search,
    .ui-as-side__workspace,
    .ui-as-user-menu > .ui-as-user
  ) {
  flex: none;
  width: fit-content;
}
.ui-as-app[data-collapsed] .ui-as-side__search {
  padding-right: 8px;
}
.ui-as-app[data-collapsed] .ui-as-side__label {
  color: transparent;
  white-space: nowrap;
  overflow: hidden;
  background: linear-gradient(var(--line-strong), var(--line-strong)) 0 50% /
    28px 0.5px no-repeat;
}
.ui-as-app[data-collapsed] .ui-as-side__empty {
  visibility: hidden;
}
.ui-as-app[data-collapsed] .ui-as-side__foot > :not(.ui-as-user-menu) {
  display: none;
}
.ui-as-app[data-collapsed] :is(.ui-as-side__head, .ui-as-bar--side) {
  position: relative;
}
.ui-as-app[data-collapsed] .ui-as-side__tools,
.ui-as-app[data-collapsed] > .ui-as-bar--side > .ui-as-icon-btn {
  position: absolute;
  top: 0;
  left: 0;
  opacity: 0;
  transition: opacity 140ms ease;
}
.ui-as-app[data-collapsed] > .ui-as-bar--side > .ui-as-icon-btn {
  top: 10px;
  left: 10px;
  margin: 0;
}
.ui-as-app[data-collapsed]
  :is(.ui-as-side__tools, .ui-as-bar--side)
  .ui-as-icon-btn {
  width: 30px;
}
.ui-as-app[data-collapsed]:has(
    > :is(.ui-as-side, .ui-as-bar--side):hover,
    :is(.ui-as-side__head, .ui-as-bar--side) :focus-visible
  )
  :is(.ui-as-side__tools, .ui-as-bar--side > .ui-as-icon-btn),
.ui-as-app[data-collapsed]
  :is(.ui-as-side__head, .ui-as-bar--side):has(> .ui-as-side__back)
  :is(.ui-as-side__tools, .ui-as-icon-btn) {
  opacity: 1;
}
.ui-as-app[data-collapsed]:has(
    > :is(.ui-as-side, .ui-as-bar--side):hover,
    :is(.ui-as-side__head, .ui-as-bar--side) :focus-visible
  )
  .ui-as-side__logo {
  opacity: 0;
}
.ui-as-app[data-collapsed] .ui-as-side__logo {
  transition: opacity 140ms ease;
}
.ui-as-app[data-collapsed] .ui-as-side__back {
  visibility: hidden;
}
.ui-as-side-open {
  position: fixed;
  z-index: 20;
  top: calc(
    var(--frame-gap) + var(--as-head-edge) + (var(--as-head-h) - 28px) / 2
  );
  left: calc(var(--frame-gap) + 9px);
  visibility: hidden;
  opacity: 0;
  transition:
    opacity 200ms ease,
    visibility 0s 200ms;
}
.ui-as-side__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 28px;
}
.ui-as-side__head {
  gap: 4px;
}
.ui-as-side__head > .ui-as-anchor {
  display: flex;
  min-width: 0;
}
.ui-as-side__workspace {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  text-align: left;
  height: 30px;
  padding: 0 6px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-side__workspace svg {
  color: var(--faint);
}
.ui-as-side__name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-side__tools {
  flex: none;
}
.ui-as-side__workspace:hover {
  background: var(--hover);
}
.ui-as-side__back {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 30px;
  padding: 0 8px 0 4px;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  color: var(--strong);
}
.ui-as-side__back svg {
  color: var(--muted);
  transition: translate 200ms var(--ease);
}
.ui-as-side__back:hover {
  background: var(--hover);
}
.ui-as-side__back:hover svg {
  translate: -2px 0;
}
.ui-as-user-menu {
  display: flex;
}
.ui-as-user-menu > .ui-as-user {
  flex: 1;
  min-width: 0;
}
.ui-as-user-menu .ui-as-menu {
  width: 100%;
}
.ui-as-account {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px 10px;
  margin-bottom: 4px;
  border-bottom: 1px solid var(--line);
}
.ui-as-account img,
.ui-as-account .ui-as-user__initials {
  flex: none;
  width: 30px;
  height: 30px;
  border-radius: 50%;
  font-size: 11px;
}
.ui-as-account__text {
  display: grid;
  min-width: 0;
}
.ui-as-account__text b {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ink);
}
.ui-as-account__text small {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--muted);
}
.ui-as-ws-menu .ui-as-menu {
  width: 240px;
}
.ui-as-side__logo {
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  margin-right: 1px;
  border-radius: 5px;
  background: var(--logo-bg);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 1px 1px rgba(0, 0, 0, 0.12);
}
.ui-as-side__logo svg {
  width: 11px;
  height: auto;
}
.ui-as-side__tools {
  display: flex;
  gap: 2px;
}
.ui-as-icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-as-icon-btn:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-side__nav {
  display: flex;
  flex: 0 1 auto;
  flex-direction: column;
  min-height: 0;
  margin-top: 12px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: none;
}
.ui-as-side__nav::-webkit-scrollbar {
  display: none;
}
.ui-as-side__nav > *,
.ui-as-side__nav .ui-as-side__group > * {
  flex-shrink: 0;
}
.ui-as-side__foot {
  flex: none;
}
.ui-as-side {
  position: relative;
}
.ui-as-chats,
.ui-as-chat-pinned {
  margin-top: 6px;
}
.ui-as-chat-folder-row {
  position: relative;
  display: flex;
  flex: none;
}
.ui-as-chat-folder-row:is(:hover, :has(:focus-visible), [data-menu])
  > .ui-as-chat-folder {
  padding-right: 56px;
  background: var(--hover);
  color: var(--ink);
}
.ui-as-chat-folder-row:is(:hover, :has(:focus-visible), [data-menu])
  .ui-as-chat-row__tools {
  opacity: 1;
}
.ui-as-chat-folder__rename {
  padding-left: 29px;
}
.ui-as-chat-folder-row[draggable="true"] {
  cursor: grab;
}
.ui-as-chat-folder > .ui-as-side__text {
  flex: 0 1 auto;
}
.ui-as-chat-folder__arrow {
  display: grid;
  flex: none;
  place-items: center;
  margin-left: -4px;
  color: var(--faint);
  opacity: 0;
  transition:
    opacity 120ms ease,
    transform 200ms var(--ease);
}
.ui-as-chat-folder[aria-expanded="true"] .ui-as-chat-folder__arrow {
  transform: rotate(90deg);
}
.ui-as-chat-folder-row:is(:hover, :has(:focus-visible))
  .ui-as-chat-folder__arrow {
  opacity: 1;
}
.ui-as-chat-folder-row[data-dragging] {
  opacity: 0.4;
}
.ui-as-chat-folder-row[data-drop]::after {
  content: "";
  position: absolute;
  left: 6px;
  right: 6px;
  height: 2px;
  border-radius: 1px;
  background: var(--accent);
  pointer-events: none;
}
.ui-as-chat-folder-row[data-drop="before"]::after {
  top: -1px;
}
.ui-as-chat-folder-row[data-drop="after"]::after {
  bottom: -1px;
}
.ui-as-chat-row {
  position: relative;
  display: flex;
  flex: none;
}
.ui-as-chat-row > .ui-as-chat-row__link {
  padding-left: 6px;
}
.ui-as-chat-row[data-indent] > .ui-as-chat-row__link {
  padding-left: 30px;
}
.ui-as-chat-folder__chats {
  display: flex;
  flex-direction: column;
}
.ui-as-chat-folder__empty {
  padding-left: 30px;
}
.ui-as-chat-folder[data-drop] {
  background: var(--hover);
  box-shadow: inset 0 0 0 1px var(--accent);
  color: var(--ink);
}
.ui-as-chat-row__link .ui-as-side__text {
  flex: 1;
}
.ui-as-chat-row:is(:hover, :has(:focus-visible), [data-menu])
  .ui-as-chat-row__link {
  padding-right: 56px;
  background: var(--hover);
  color: var(--ink);
}
.ui-as-chat-row > .ui-as-chat-row__link[aria-current="page"] {
  background: var(--hover);
  font-weight: 400;
  color: var(--ink);
}
.ui-as-chat-row__dot {
  flex: none;
  width: 6px;
  height: 6px;
  margin-left: 6px;
  border-radius: 50%;
  background: var(--accent);
}
.ui-as-chat-row__tools {
  position: absolute;
  top: 3px;
  right: 4px;
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity 120ms ease;
}
.ui-as-chat-row:is(:hover, :has(:focus-visible), [data-menu])
  .ui-as-chat-row__tools {
  opacity: 1;
}
.ui-as-chat-row__tool {
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--muted);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-as-chat-row__tool:hover,
.ui-as-chat-row__tool[aria-expanded="true"] {
  background: var(--chip);
  color: var(--ink);
}
.ui-as-chat-row__rename {
  width: 100%;
  height: 30px;
  padding: 0 8px 0 5px;
  border: 0;
  border-radius: 8px;
  outline: 0;
  background: var(--card);
  box-shadow: inset 0 0 0 1px var(--line-strong);
  font: inherit;
  font-size: 13px;
  color: var(--ink);
}
.ui-as-chat-row[data-indent] .ui-as-chat-row__rename {
  padding-left: 29px;
}
.ui-as-chat-row[draggable="true"] {
  cursor: grab;
}
.ui-as-chat-row[data-dragging] {
  opacity: 0.4;
}
.ui-as-chat-row[data-drop]::after {
  content: "";
  position: absolute;
  left: 6px;
  right: 6px;
  height: 2px;
  border-radius: 1px;
  background: var(--accent);
  pointer-events: none;
}
.ui-as-chat-row[data-drop="before"]::after {
  top: -1px;
}
.ui-as-chat-row[data-drop="after"]::after {
  bottom: -1px;
}
.ui-as-chat-menu {
  position: absolute;
  z-index: 30;
  width: 232px;
  animation: ui-as-popover-up 160ms var(--ease) both;
}
.ui-as-chat-menu .ui-as-menu__subpanel {
  min-width: 180px;
}
.ui-as-app[data-collapsed]
  :is(
    .ui-as-chats,
    .ui-as-chat-folder__chats,
    .ui-as-chat-row,
    .ui-as-chat-row__tools
  ) {
  display: none;
}
.ui-as-app[data-collapsed] .ui-as-chat-pinned:not(:has(.ui-as-chat-folder)) {
  display: none;
}
.ui-as-app[data-collapsed] .ui-as-chat-folder__arrow {
  display: none;
}
.ui-as-cmd {
  position: absolute;
  inset: 0;
  z-index: 60;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  padding: min(12vh, 96px) 16px 16px;
  background: rgba(0, 0, 0, 0.12);
  animation: ui-as-cmd-fade 200ms ease both;
}
.ui-as-cmd > * {
  width: 100%;
  max-width: 560px;
  animation: ui-as-cmd-in 260ms var(--ease) both;
}
@keyframes ui-as-cmd-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-as-cmd-in {
  from {
    opacity: 0;
    transform: translateY(-6px) scale(0.98);
  }
}
:where(.dark, [data-theme="dark"]) .ui-as-cmd {
  background: rgba(0, 0, 0, 0.45);
}
.ui-as-side__search {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 30px;
  margin-top: 12px;
  padding: 0 6px 0 8px;
  border-radius: 8px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  font-size: 13px;
  color: var(--muted);
  text-align: left;
  transition:
    box-shadow 140ms ease,
    color 140ms ease;
}
.ui-as-side__search svg {
  color: var(--faint);
}
.ui-as-side__search:hover {
  box-shadow: var(--card-shadow-hover);
  color: var(--text);
}
.ui-as-side__search kbd {
  margin-left: auto;
  padding: 0 5px;
  border-radius: 4px;
  box-shadow: inset 0 0 0 0.5px var(--line-strong);
  font: inherit;
  font-size: 11px;
  line-height: 18px;
  color: var(--faint);
}
.ui-as-side__group {
  display: flex;
  flex-direction: column;
}
.ui-as-side__group + .ui-as-side__group {
  margin-top: 10px;
}
.ui-as-side__group + .ui-as-side__group > .ui-as-side__label:first-child {
  margin-top: 6px;
}
.ui-as-side__count {
  flex: none;
  margin-left: auto;
  font-size: 12px;
  color: var(--faint);
  font-variant-numeric: tabular-nums;
}
.ui-as-side__empty {
  padding: 4px 6px;
  font-size: 13px;
  color: var(--faint);
}
.ui-as-side__item {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 30px;
  padding: 0 6px;
  border-radius: 8px;
  font-size: 13px;
  color: var(--text);
  text-align: left;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-as-side__item svg {
  flex: none;
  color: var(--muted);
}
.ui-as-side__text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-side__item:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-side__item[aria-current="page"] {
  background: var(--select);
  color: var(--ink);
  font-weight: 500;
}
.ui-as-side__item[aria-current="page"] svg {
  color: var(--ink);
}
a.ui-as-side__item {
  text-decoration: none;
  cursor: pointer;
}
.ui-as-side__label {
  margin: 16px 0 4px;
  padding: 0 6px;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--faint);
}
.ui-as-side__foot {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: auto;
}
.ui-as-news {
  position: relative;
  padding-top: 30px;
}
.ui-as-news__card {
  position: relative;
  z-index: 1;
  padding: 10px 10px 0;
  border-radius: 12px;
  background: var(--card);
  box-shadow: var(--card-shadow);
}
.ui-as-news__card--back {
  position: absolute;
  z-index: 0;
  top: 0;
  left: 10px;
  right: 10px;
  height: 48px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  padding: 9px 9px 0;
  background: var(--card);
  color: var(--faint);
}
.ui-as-news[data-count="1"] {
  padding-top: 0;
}
.ui-as-news[data-count="1"] .ui-as-news__card--back {
  display: none;
}
.ui-as-news__top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.ui-as-news__kicker {
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  line-height: 15px;
  font-weight: 500;
  color: var(--accent);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-news__card--back svg,
.ui-as-news__close {
  flex: none;
}
.ui-as-news__close {
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  margin: -2px -2px 0 0;
  border-radius: 6px;
  color: var(--faint);
}
.ui-as-news__close:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-news__title {
  display: block;
  margin-top: 4px;
  font-size: 13px;
  line-height: 18px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-news__more {
  display: flex;
  align-items: center;
  justify-content: space-between;
  width: calc(100% + 20px);
  height: 34px;
  margin: 10px -10px 0;
  padding: 0 10px;
  border-top: 1px solid var(--line-soft);
  border-radius: 0 0 12px 12px;
  font-size: 12.5px;
  color: var(--muted);
}
.ui-as-news__more:hover {
  background: var(--subtle);
  color: var(--ink);
}
.ui-as-guide-slot {
  position: relative;
  flex: none;
}
.ui-as-guide {
  position: absolute;
  z-index: 6;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: hidden;
  border-radius: 12px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  transition:
    height 480ms var(--ease),
    border-radius 480ms var(--ease),
    box-shadow 200ms ease;
}
.ui-as-guide:not([data-open]):hover {
  box-shadow:
    0 0 0 1px var(--line-strong),
    0 2px 6px rgba(0, 0, 0, 0.05);
}
.ui-as-guide[data-open] {
  border-radius: 12px;
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 8px 24px -10px rgba(0, 0, 0, 0.14);
}
.ui-as-guide__content {
  animation: ui-as-guide-in 360ms var(--ease) both;
}
.ui-as-guide[data-state="closing"] .ui-as-guide__content {
  animation: ui-as-guide-out 260ms ease both;
}
.ui-as-guide[data-state="closing"] {
  border-radius: 12px;
  box-shadow: var(--card-shadow);
}
@keyframes ui-as-guide-out {
  to {
    opacity: 0;
  }
}
@keyframes ui-as-guide-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
.ui-as-steps {
  display: grid;
  gap: 3px;
  width: 100%;
  padding: 10px 10px 9px;
  text-align: left;
}
.ui-as-guide .ui-sgdc__icon-btn[aria-expanded] {
  display: none;
}
.ui-as-guide .ui-sgdc {
  zoom: 0.86;
  max-width: none;
  padding: 12px 4px 4px;
  border: 0;
  border-radius: 0;
  background: transparent;
  box-shadow: none;
}
.ui-as-steps__title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 13px;
  line-height: 18px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-steps__title svg {
  color: var(--faint);
}
.ui-as-steps__sub {
  font-size: 12.5px;
  line-height: 17px;
  color: var(--muted);
}
.ui-as-steps__cheer {
  color: var(--accent);
}
.ui-as-steps__bar {
  height: 4px;
  margin-top: 6px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--tray);
}
.ui-as-steps__bar i {
  display: block;
  min-width: 6px;
  height: 100%;
  border-radius: inherit;
  background: var(--accent);
  transition: width 600ms var(--ease);
}
.ui-as-user {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 6px;
  border-radius: 8px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-user__name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-user > :is(img, .ui-as-user__initials) {
  flex: none;
}
.ui-as-user img {
  width: 21px;
  height: 21px;
  border-radius: 50%;
  object-fit: cover;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.06);
}
.ui-as-user svg {
  margin-left: auto;
  color: var(--faint);
}
.ui-as-user:hover {
  background: var(--hover);
}
.ui-as-main {
  container: ui-as-main / inline-size;
  position: relative;
  min-width: 0;
  margin: var(--frame-gap) var(--frame-gap) var(--frame-gap) 0;
  overflow-y: auto;
  overscroll-behavior: none;
  transition: margin-left 420ms var(--ease);
  border: 1px solid var(--line);
  border-radius: var(--radius-panel);
  background: var(--panel);
}
.ui-as-page {
  padding: 46px 32px 56px;
}
.ui-as-page-title {
  margin: 0;
  font-size: 24px;
  line-height: 32px;
  font-weight: 500;
  letter-spacing: -0.24px;
  color: var(--strong);
}
.ui-as-page-sub {
  margin: 4px 0 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--text);
}
.ui-as-page-sub a {
  color: var(--text);
  text-decoration: underline;
  text-decoration-color: var(--line-strong);
  text-underline-offset: 3px;
}
.ui-as-page-sub a:hover {
  color: var(--ink);
  text-decoration-color: currentColor;
}
.ui-as-section-head {
  margin-top: 36px;
}
.ui-as-section-head[data-inline] {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
.ui-as-section-head[data-inline] .ui-as-toolbar {
  margin-top: 0;
}
.ui-as-section-head__title {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  font-size: 11px;
  line-height: 16px;
  font-weight: 500;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--muted);
}
.ui-as-section-head__count {
  font-variant-numeric: tabular-nums;
  color: var(--faint);
}
.ui-as-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin-top: 12px;
}
.ui-as-toolbar__left,
.ui-as-toolbar__right {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ui-as-tabs {
  position: relative;
  display: flex;
  gap: 8px;
}
.ui-as-tabs__pill {
  position: absolute;
  top: 0;
  left: 0;
  height: 28px;
  border-radius: 6px;
  background: var(--select);
  transition:
    transform 340ms var(--ease),
    width 340ms var(--ease);
}
.ui-as-tabs__tab {
  position: relative;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  color: var(--text);
  box-shadow: inset 0 0 0 0.5px var(--line);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-as-tabs__tab:hover {
  color: var(--ink);
}
.ui-as-tabs__tab[aria-selected="true"] {
  color: var(--ink);
}
.ui-as-tool {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  min-width: 28px;
  height: 28px;
  border-radius: 6px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  color: var(--text);
  transition:
    box-shadow 140ms ease,
    color 140ms ease;
}
.ui-as-tool svg {
  color: var(--muted);
}
.ui-as-tool:hover {
  box-shadow: var(--card-shadow-hover);
  color: var(--ink);
}
.ui-as-tool--label {
  padding: 0 10px;
  font-size: 13px;
}
.ui-as-view {
  position: relative;
  display: flex;
  gap: 2px;
  height: 28px;
  padding: 2px;
  border-radius: 6px;
  background: var(--chip);
}
.ui-as-view__btn {
  display: grid;
  place-items: center;
  width: 28px;
  border-radius: 4px;
  color: var(--faint);
}
.ui-as-view__btn:hover {
  color: var(--ink);
}
.ui-as-view__btn {
  position: relative;
  transition: color 160ms ease;
}
.ui-as-view__btn[aria-checked="true"] {
  color: var(--ink);
}
.ui-as-view__pill {
  position: absolute;
  top: 2px;
  bottom: 2px;
  left: 2px;
  width: 28px;
  border-radius: 4px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  transition: transform 320ms var(--ease);
}
.ui-as-view[data-view="list"] .ui-as-view__pill {
  transform: translateX(30px);
}
.ui-as-search {
  display: block;
  min-width: 0;
}
.ui-as-sort svg {
  transition: transform 360ms var(--ease);
}
.ui-as-sort[data-dir="desc"] svg {
  transform: rotate(180deg);
}
.ui-as-tool[data-active] {
  box-shadow: var(--card-shadow-hover);
  color: var(--ink);
}
.ui-as-tool__count {
  display: grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 999px;
  background: var(--ink);
  font-size: 11px;
  font-weight: 500;
  color: var(--on-ink);
  animation: ui-as-pop 220ms var(--ease);
}
.ui-as-anchor {
  position: relative;
  display: inline-flex;
}
.ui-as-popover {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  transform-origin: top left;
  animation: ui-as-popover 220ms var(--ease);
}
.ui-as-popover[data-align="end"] {
  right: 0;
  left: auto;
  transform-origin: top right;
}
.ui-as-popover[data-side="top"] {
  top: auto;
  bottom: calc(100% + 6px);
  transform-origin: bottom left;
  animation-name: ui-as-popover-up;
}
.ui-as-popover[data-side="top"][data-align="end"] {
  transform-origin: bottom right;
}
.ui-as-popover[data-side="right"] {
  top: auto;
  bottom: 0;
  left: calc(100% + 12px);
  transform-origin: bottom left;
}
@keyframes ui-as-popover-up {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(4px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
.ui-as-popover--filter .ui-fmc {
  width: 300px;
}
.ui-as-popover--filter .ui-fmc__title {
  font-size: 13px;
  line-height: 20px;
}
.ui-as-menu {
  min-width: 168px;
  padding: 4px;
  border-radius: 12px;
  background: var(--card);
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 12px 32px -8px rgba(0, 0, 0, 0.16);
}
.ui-as-menu__title {
  display: block;
  padding: 6px 10px 4px;
  font-size: 12px;
  font-weight: 500;
  color: var(--faint);
}
.ui-as-menu__list {
  display: grid;
  gap: 1px;
}
.ui-as-menu__item {
  display: flex;
  align-items: center;
  gap: 9px;
  width: 100%;
  min-height: 32px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 13px;
  color: var(--text);
  text-align: left;
  white-space: nowrap;
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-as-menu__item[data-rich] {
  min-height: 44px;
  padding: 6px 10px;
}
.ui-as-menu__item > svg {
  flex: none;
  color: var(--muted);
}
.ui-as-menu__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
}
.ui-as-menu__logo > svg {
  width: 14px;
  height: 14px;
}
.ui-as-flag,
.ui-as-menu__logo > .ui-as-flag {
  flex: none;
  width: 16px;
  height: 11px;
  overflow: hidden;
  border-radius: 2.5px;
  box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.14);
}
.ui-as-menu__item > svg:last-child:not(:first-child) {
  margin-left: auto;
  color: var(--ink);
}
.ui-as-menu__label {
  display: grid;
  flex: 1;
  gap: 1px;
  min-width: 0;
}
.ui-as-menu__label small {
  font-size: 12px;
  line-height: 16px;
  color: var(--faint);
}
.ui-as-menu__text,
.ui-as-menu__label small {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-menu__item > svg {
  flex: none;
}
.ui-as-menu__empty {
  display: block;
  padding: 6px 8px;
  font-size: 13px;
  color: var(--faint);
}
.ui-as-menu__item:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-menu__item[aria-checked="true"] {
  color: var(--ink);
  font-weight: 500;
}
.ui-as-menu__item[aria-checked="true"] small {
  font-weight: 400;
}
.ui-as-menu__item[data-danger] {
  color: #f04438;
}
.ui-as-menu__kbd {
  flex: none;
  margin-left: auto;
  padding-left: 16px;
  font: inherit;
  font-size: 12px;
  letter-spacing: 0.04em;
  color: var(--faint);
}
.ui-as-menu__item > .ui-as-menu__kbd + svg {
  margin-left: 8px;
}
.ui-as-menu__sep {
  display: block;
  height: 1px;
  margin: 4px 6px;
  background: var(--line);
}
.ui-as-menu__sub {
  position: relative;
  display: block;
}
.ui-as-menu__item > svg:last-child:not(:first-child):is(.ui-as-menu__sub svg) {
  color: var(--faint);
}
.ui-as-menu__subpanel {
  position: absolute;
  z-index: 1;
  top: -4px;
  left: calc(100% + 4px);
  visibility: hidden;
  opacity: 0;
  transition:
    opacity 120ms ease,
    visibility 0s 120ms;
}
.ui-as-menu__subpanel::before {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  left: -8px;
  width: 8px;
}
.ui-as-menu__sub:is(:hover, :focus-within, [data-open])
  > .ui-as-menu__subpanel {
  visibility: visible;
  opacity: 1;
  transition: opacity 120ms ease;
}
.ui-as-menu__sub:is(:hover, :focus-within, [data-open]) > .ui-as-menu__item {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-menu__item[data-danger] > svg {
  color: #f04438;
}
.ui-as-toast {
  max-width: calc(100% - 32px);
  position: absolute;
  z-index: 40;
  left: 50%;
  bottom: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 36px;
  padding: 0 14px 0 12px;
  border-radius: 999px;
  background: var(--ink);
  font-size: 13px;
  color: var(--on-ink);
  box-shadow: 0 10px 24px -8px rgba(0, 0, 0, 0.35);
  translate: -50% 0;
  animation: ui-as-toast 2200ms var(--ease) both;
}
.ui-as-rise {
  animation: ui-as-rise 420ms var(--ease) both;
  animation-delay: calc(var(--i, 0) * 35ms);
}
.ui-as-rise:has(.ui-as-popover) {
  position: relative;
  z-index: 10;
}
@keyframes ui-as-rise {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-as-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-as-popover {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(-4px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-as-toast {
  0% {
    opacity: 0;
    transform: translateY(12px) scale(0.96);
  }
  12%,
  85% {
    opacity: 1;
    transform: none;
  }
  100% {
    opacity: 0;
    transform: translateY(6px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-as *,
  .ui-as *::before,
  .ui-as *::after {
    animation-duration: 1ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
    scroll-behavior: auto !important;
  }
}
.ui-as
  :is(.ui-as-side__nav, .ui-as-menu, .ui-as-panel__body)
  :is(button, [href], [tabindex]):focus-visible {
  outline-offset: -2px;
}
.ui-as-menu__item:focus-visible {
  background: var(--hover);
  color: var(--ink);
}
@media (hover: none) {
  .ui-as-chat-row__tools,
  .ui-as-chat-folder-row .ui-as-chat-row__tools {
    opacity: 1;
  }
  .ui-as-chat-row__pin {
    display: none;
  }
  .ui-as-chat-row .ui-as-chat-row__link,
  .ui-as-chat-folder-row > .ui-as-chat-folder {
    padding-right: 34px;
  }
  .ui-as-chat-row:is(:hover, :has(:focus-visible), [data-menu])
    .ui-as-chat-row__link,
  .ui-as-chat-folder-row:is(:hover, :has(:focus-visible), [data-menu])
    > .ui-as-chat-folder {
    padding-right: 34px;
  }
  .ui-as-chat-row__tool {
    color: var(--faint);
  }
}
@media (pointer: coarse) {
  .ui-as-side__item,
  .ui-as-side__search,
  .ui-as-side__workspace,
  .ui-as-side__back,
  .ui-as-chat-row__rename {
    height: 36px;
  }
  .ui-as-chat-row__tools {
    top: 6px;
  }
  .ui-as-user {
    height: 40px;
  }
  .ui-as-menu__item {
    min-height: 40px;
  }
  :is(
    .ui-as-chat-row__tool,
    .ui-as-news__close,
    .ui-as-tool,
    .ui-asw__more,
    .ui-as-bar__pick
  ) {
    position: relative;
  }
  .ui-as-icon-btn:not(.ui-as-side-open, .ui-as-panel-open) {
    position: relative;
  }
  :is(
    .ui-as-icon-btn,
    .ui-as-chat-row__tool,
    .ui-as-tool,
    .ui-as-view__btn,
    .ui-as-tabs__tab,
    .ui-asw__more
  )::after {
    content: "";
    position: absolute;
    inset: -4px;
  }
  .ui-as-news__close::after {
    content: "";
    position: absolute;
    inset: -7px;
  }
}
.ui-as-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-top: 16px;
  padding: 48px 24px 52px;
  border-radius: 12px;
  background: var(--frame);
  box-shadow: inset 0 0 0 0.5px var(--line);
  text-align: center;
}
.ui-as-empty[data-tall] {
  padding: 48px 24px 48px;
}
.ui-as-empty__icon {
  display: grid;
  place-items: center;
  width: 42px;
  height: 42px;
  border-radius: 11px;
  background: var(--chip);
  color: var(--muted);
}
.ui-as-empty__title {
  margin-top: 16px;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--strong);
}
.ui-as-empty__text {
  max-width: 430px;
  margin: 4px 0 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--muted);
  text-wrap: balance;
}
.ui-as-empty > .ui-buttonc {
  margin-top: 18px;
}
.ui-as-folder-card__icon,
.ui-as-folder-head__icon {
  position: relative;
  flex: none;
  width: 30px;
  height: 25px;
}
.ui-as-folder-card__icon .ui-fd,
.ui-as-folder-head__icon .ui-fd {
  position: absolute;
  top: 50%;
  left: 50%;
  width: 75px;
  translate: -50% -50%;
}
:is(.ui-as-folder-card, .ui-as-folder-head):hover .ui-fd-icon {
  transform: translate(-50%, -48%) scale(1.03);
}
:is(.ui-as-folder-card, .ui-as-folder-head):hover .ui-fd-doc--left {
  transform: translate(32px, 70px) rotate(9deg);
}
:is(.ui-as-folder-card, .ui-as-folder-head):hover .ui-fd-doc--right {
  transform: translate(286px, 76px) rotate(5deg);
}
:is(.ui-as-folder-card, .ui-as-folder-head):hover .ui-fd-doc--middle {
  transform: translate(166px, 52px) rotate(-7deg);
}
:is(.ui-as-folder-card, .ui-as-folder-head):hover .ui-fd-front {
  top: 24.8%;
  border-radius: 3cqw 3cqw 6.333cqw 6.333cqw;
  transform: translateZ(2.33cqw) rotateX(-9deg);
}
.ui-as-meta {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--muted);
}
.ui-as-meta svg {
  color: var(--faint);
}
.ui-as-toast > svg {
  flex: none;
}
.ui-as-toast__text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-template {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 239px;
  text-align: left;
}
.ui-as-template__preview {
  display: block;
  height: 152px;
  padding: 3px;
  border-radius: 12px;
  background: var(--frame);
  box-shadow: inset 0 0 0 0.5px var(--line);
  transition: box-shadow 160ms ease;
}
.ui-as-template__preview .ui-as-doc {
  box-shadow: var(--card-shadow);
}
.ui-as-template:hover .ui-as-template__preview {
  box-shadow: inset 0 0 0 0.5px var(--line-strong);
}
.ui-as-template__name {
  margin-top: 8px;
  overflow: hidden;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-template .ui-as-meta {
  margin-top: 0;
}
.ui-as-doc {
  --doc-tag: #4fb0fe;
  --doc-tag-shade: 30, 64, 175;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
  border-radius: 10px;
  background: var(--card);
}
.ui-as-doc[data-color="rose"] {
  --doc-tag: #f04438;
  --doc-tag-shade: 159, 18, 57;
}
.ui-as-doc[data-color="emerald"] {
  --doc-tag: #13b3a0;
  --doc-tag-shade: 6, 95, 70;
}
.ui-as-doc__art {
  position: relative;
  display: block;
  width: 52px;
  translate: 4px 0;
}
.ui-as-doc__page {
  position: relative;
  z-index: 1;
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px 10px 22px;
  border-radius: 5px 9px 5px 5px;
  corner-top-right-shape: bevel;
  background: var(--card);
  box-shadow:
    0 0 0 1px var(--line-strong),
    0 4px 8px -2px rgba(0, 0, 0, 0.065),
    0 2px 3px -2px rgba(0, 0, 0, 0.065);
  transition: transform 420ms var(--ease);
}
.ui-as-doc__rows {
  display: flex;
  flex-direction: column;
  gap: 5px;
}
.ui-as-doc__row {
  display: flex;
  gap: 3px;
}
.ui-as-doc__row i {
  display: block;
  height: 2px;
  border-radius: 1px;
  background: color-mix(in srgb, var(--ink) 10%, transparent);
}
.ui-as-doc__page[data-type="XLS"] .ui-as-doc__row:first-child i {
  background: color-mix(in srgb, var(--ink) 22%, transparent);
}
.ui-as-doc__image {
  display: block;
  height: 14px;
  border-radius: 2px;
  background: color-mix(in srgb, var(--ink) 6%, transparent);
}
.ui-as-doc__type {
  position: absolute;
  left: -8px;
  bottom: 11px;
  z-index: 2;
  display: block;
  padding: 3.5px 4px 2.5px;
  border-radius: 3px;
  background: var(--doc-tag);
  box-shadow: 0 4px 8px -3px rgba(var(--doc-tag-shade), 0.3);
  font-size: 9px;
  line-height: 1;
  font-weight: 600;
  letter-spacing: 0.03em;
  color: #fff;
  transition: transform 420ms var(--ease);
}
@supports (text-box: trim-both cap alphabetic) {
  .ui-as-doc__type {
    padding: 3.5px 4px;
    text-box: trim-both cap alphabetic;
  }
}
.ui-as-template:hover .ui-as-doc__page {
  transform: translateY(-2px);
}
.ui-as-template:hover .ui-as-doc__type {
  transform: translate(-1px, -3px);
}
.ui-as-side__logo {
  font-size: 10.5px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-user__initials {
  display: grid;
  place-items: center;
  width: 21px;
  height: 21px;
  border-radius: 50%;
  background: var(--accent-soft);
  font-size: 9.5px;
  font-weight: 500;
  color: var(--accent);
}
.ui-as-scrim {
  display: none;
}
.ui-as-resizer {
  position: absolute;
  z-index: 15;
  top: calc(var(--bar-h, 0px) + var(--frame-gap));
  bottom: var(--frame-gap);
  width: 12px;
  cursor: col-resize;
  touch-action: none;
  outline: none;
}
.ui-as-resizer[data-edge="left"] {
  left: calc(var(--side-w, 272px) - 6px);
}
.ui-as-resizer[data-edge="right"] {
  right: calc(var(--panel-w, 360px) - var(--frame-gap) / 2 - 6px);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-resizer[data-edge="right"] {
  right: calc(var(--panel-w, 360px) - 6px);
}
.ui-as-resizer::after {
  content: "";
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: linear-gradient(
    to bottom,
    transparent,
    var(--edge-active) 22%,
    var(--edge-active) 78%,
    transparent
  );
  opacity: 0;
  transition: opacity 180ms ease;
}
.ui-as-resizer[data-edge="left"]::after {
  left: 6px;
}
.ui-as-resizer[data-edge="right"]::after {
  left: 6px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-resizer[data-edge="right"]::after {
  left: 5px;
}
.ui-as-resizer:hover::after {
  opacity: 1;
  transition-delay: 100ms;
}
.ui-as-resizer:focus-visible::after,
.ui-as-resizer[data-dragging]::after {
  opacity: 1;
  transition-delay: 0ms;
}
.ui-as-app[data-panel] > .ui-as-main {
  grid-column: 2;
}
.ui-as-app[data-panel="open"] > .ui-as-main {
  margin-right: 0;
}
.ui-as-panel {
  grid-column: 3;
  grid-row: 1;
  display: flex;
  flex-direction: column;
  width: calc(var(--panel-w, 360px) - 1.5 * var(--frame-gap));
  min-height: 0;
  margin: var(--frame-gap) var(--frame-gap) var(--frame-gap)
    calc(var(--frame-gap) / 2);
  padding: 10px 10px 10px 12px;
  overflow: hidden;
  border: 1px solid var(--line);
  border-radius: var(--radius-panel);
  background: var(--panel);
  transition:
    opacity 260ms ease,
    translate 420ms var(--ease),
    visibility 0s;
}
.ui-as-app[data-panel="closed"] > .ui-as-panel {
  visibility: hidden;
  opacity: 0;
  translate: 16px 0;
  transition:
    opacity 200ms ease,
    translate 420ms var(--ease),
    visibility 0s 420ms;
}
.ui-as-panel__head {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: space-between;
  height: 28px;
  padding-left: 6px;
}
.ui-as-panel__title {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  color: var(--ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-panel__title:not(:has(> *)) {
  display: block;
}
.ui-as-panel__body {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  margin: 0 -2px;
  padding: 12px 2px 4px;
}
.ui-as-panel-open {
  position: fixed;
  z-index: 20;
  top: calc(
    var(--frame-gap) + var(--as-head-edge) + (var(--as-head-h) - 28px) / 2
  );
  right: calc(var(--frame-gap) + 9px);
  visibility: hidden;
  opacity: 0;
  transition:
    opacity 200ms ease,
    visibility 0s 200ms;
}
.ui-as-app[data-panel="closed"] > .ui-as-panel-open {
  visibility: visible;
  opacity: 1;
  transition:
    opacity 260ms ease 160ms,
    visibility 0s;
}
.ui-as-app[data-header] {
  --bar-h: var(--as-head-h);
  grid-template-rows: var(--bar-h) minmax(0, 1fr);
}
.ui-as-app[data-header] > .ui-as-bar--side {
  grid-area: 1 / 1;
}
.ui-as-app[data-header] > .ui-as-bar--main {
  grid-area: 1 / 2;
}
.ui-as-app[data-header] > .ui-as-bar--panel {
  grid-area: 1 / 3;
}
.ui-as-app[data-header] > .ui-as-side {
  grid-area: 2 / 1;
}
.ui-as-app[data-header] > .ui-as-main {
  grid-area: 2 / 2;
  margin-top: 0;
}
.ui-as-app[data-header] > .ui-as-panel {
  grid-area: 2 / 3;
}
.ui-as-bar {
  display: flex;
  align-items: center;
  gap: 2px;
  min-width: 0;
  height: var(--bar-h);
  overflow: hidden;
  transition:
    padding 420ms var(--ease),
    opacity 260ms ease;
}
.ui-as-bar--side {
  padding: 0 10px;
}
.ui-as-bar--side > :last-child {
  margin-left: auto;
}
.ui-as-bar--side > .ui-as-anchor {
  display: flex;
  min-width: 0;
}
.ui-as-app[data-header] > .ui-as-side > .ui-as-side__search {
  margin-top: 0;
}
.ui-as-bar--main {
  justify-content: space-between;
  gap: 12px;
  padding: 0 12px 0 18px;
}
.ui-as-bar--panel {
  justify-content: space-between;
  padding: 0 10px 0 16px;
}
.ui-as-bar__title {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  color: var(--ink);
  white-space: nowrap;
}
.ui-as-bar__title > * {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-as-bar__actions {
  display: flex;
  flex: none;
  align-items: center;
  gap: 2px;
}
.ui-as-bar__pick {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 30px;
  margin-left: -8px;
  padding: 0 8px;
  border-radius: 8px;
  color: var(--ink);
}
.ui-as-bar__pick > span {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-as-bar__pick svg {
  color: var(--faint);
}
.ui-as-bar__pick:hover {
  background: var(--hover);
}
.ui-as-app[data-header] > .ui-as-side > .ui-as-side__head,
.ui-as-app[data-header] > .ui-as-panel > .ui-as-panel__head {
  display: none;
}
.ui-as-app[data-header] > .ui-as-panel > .ui-as-panel__body {
  padding-top: 2px;
}
.ui-as-app[data-header][data-panel="closed"] > .ui-as-bar--panel {
  opacity: 0;
}
.ui-as-app[data-header][data-panel="closed"] > .ui-as-bar--main {
  padding-right: 50px;
}
.ui-as-app[data-header] > :is(.ui-as-side-open, .ui-as-panel-open) {
  top: calc((var(--bar-h) - 28px) / 2);
}
.ui-as-center {
  display: grid;
  place-items: center;
  min-height: 100%;
  padding: 48px 32px;
}
.ui-as-empty[data-bare] {
  margin-top: 0;
  padding: 0;
  border: 0;
  background: none;
  box-shadow: none;
}
.ui-as-app[data-rail] {
  --rail-w: 52px;
  --side-col: calc(var(--rail-w) + var(--side-w, 272px));
}
.ui-as-app[data-rail] > .ui-as-side {
  flex-direction: row;
  width: 100%;
  padding: 0;
  overflow: hidden;
}
.ui-as-app[data-rail] > .ui-as-resizer[data-edge="left"] {
  left: calc(var(--rail-w) + var(--side-w, 272px) - 6px);
}
.ui-as-rail {
  display: flex;
  flex: none;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  width: var(--rail-w);
  min-height: 0;
  padding: calc(var(--frame-gap) + 4px) 0 calc(var(--frame-gap) + 2px);
  overflow-y: auto;
  scrollbar-width: none;
}
.ui-as-rail::-webkit-scrollbar {
  display: none;
}
.ui-as-rail > .ui-as-anchor {
  display: flex;
}
.ui-as-rail__logo {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  margin-bottom: 4px;
  border-radius: 9px;
  background: var(--panel);
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 1px 2px rgba(0, 0, 0, 0.05);
  font-size: 12px;
  font-weight: 600;
  color: var(--ink);
  transition: box-shadow 140ms ease;
}
.ui-as-rail__logo:hover {
  box-shadow:
    0 0 0 0.5px var(--line-strong),
    0 2px 6px -2px rgba(0, 0, 0, 0.14);
}
.ui-as-rail__item {
  position: relative;
  display: grid;
  flex: none;
  place-items: center;
  width: 34px;
  height: 34px;
  border-radius: 9px;
  color: var(--muted);
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-as-rail__item:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-as-rail__item[aria-current="page"] {
  background: var(--select);
  color: var(--ink);
}
.ui-as-rail__dot {
  position: absolute;
  top: 7px;
  right: 7px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--accent);
  box-shadow: 0 0 0 2px var(--page);
}
.ui-as-rail__line {
  flex: none;
  width: 18px;
  height: 1px;
  margin: 6px 0;
  background: var(--line);
}
.ui-as-rail__spacer {
  flex: 1;
}
.ui-as-rail .ui-as-rail__account > .ui-as-user {
  flex: none;
  justify-content: center;
  width: 34px;
  height: 34px;
  padding: 0;
}
.ui-as-rail .ui-as-rail__account > .ui-as-user > svg,
.ui-as-rail .ui-as-rail__account .ui-as-user__name {
  display: none;
}
.ui-as-rail
  .ui-as-rail__account
  > .ui-as-user
  > :is(img, .ui-as-user__initials) {
  width: 24px;
  height: 24px;
}
.ui-as-user-menu.ui-as-rail__account .ui-as-menu {
  width: 244px;
}
.ui-as-side__col {
  display: flex;
  flex: none;
  flex-direction: column;
  width: var(--side-w, 272px);
  min-height: 0;
  margin: var(--frame-gap) 0;
  padding: 10px 8px 8px 10px;
  border: 1px solid var(--line);
  border-radius: var(--radius-panel) 0 0 var(--radius-panel);
  background: var(--side-tint);
}
.ui-as-app[data-rail] > .ui-as-main {
  border-left: 0;
  border-top-left-radius: 0;
  border-bottom-left-radius: 0;
}
.ui-as-side__col > .ui-as-side__nav {
  margin-top: 12px;
}
.ui-as-project-menu .ui-as-menu {
  min-width: 220px;
}
@container ui-as (max-width: 900px) {
  .ui-as-app > .ui-as-main {
    grid-row: 1;
    grid-column: 1 / -1;
    margin-left: var(--frame-gap);
  }
  .ui-as-app > .ui-as-side {
    position: absolute;
    z-index: 50;
    top: 0;
    bottom: 0;
    left: 0;
    width: min(264px, calc(100% - 56px));
    padding: 10px 10px 10px 12px;
    border-radius: 0 18px 18px 0;
    background: var(--page);
    box-shadow:
      0 0 0 0.5px var(--line-strong),
      0 24px 48px -12px rgba(0, 0, 0, 0.28);
  }
  .ui-as-app:not([data-drawer]) > .ui-as-side {
    visibility: hidden;
    translate: calc(-100% - 24px) 0;
    transition:
      translate 380ms var(--ease),
      visibility 0s 380ms;
  }
  .ui-as-app[data-drawer] > .ui-as-side {
    visibility: visible;
    opacity: 1;
    translate: 0 0;
    transition:
      translate 420ms var(--ease),
      visibility 0s;
  }
  .ui-as-app[data-panel] {
    --panel-col: 0px;
  }
  .ui-as-app[data-panel] > .ui-as-main {
    grid-column: 1 / -1;
    margin-right: var(--frame-gap);
  }
  .ui-as-app > .ui-as-panel {
    grid-area: auto;
    position: absolute;
    z-index: 50;
    top: 0;
    right: 0;
    bottom: 0;
    width: min(360px, calc(100% - 56px));
    margin: 0;
    padding: 10px 12px 10px 12px;
    border: 0;
    border-radius: 18px 0 0 18px;
    background: var(--panel);
    box-shadow:
      0 0 0 0.5px var(--line-strong),
      0 24px 48px -12px rgba(0, 0, 0, 0.28);
  }
  .ui-as-app[data-panel="closed"] > .ui-as-panel {
    translate: calc(100% + 24px) 0;
    transition:
      translate 380ms var(--ease),
      visibility 0s 380ms;
  }
  .ui-as-app[data-panel="open"] > .ui-as-panel {
    visibility: visible;
    opacity: 1;
    translate: 0 0;
    transition:
      translate 420ms var(--ease),
      visibility 0s;
  }
  .ui-as-app[data-panel="open"] > .ui-as-scrim {
    visibility: visible;
    opacity: 1;
    transition:
      opacity 300ms ease,
      visibility 0s;
  }
  .ui-as-app > .ui-as-panel-open {
    right: calc(var(--frame-gap) + 9px);
    background: var(--panel);
  }
  .ui-as-app > .ui-as-panel-open:hover {
    background: var(--chip);
  }
  .ui-as-app[data-header] > .ui-as-main {
    grid-area: 2 / 1 / 3 / -1;
  }
  .ui-as-app[data-header] > .ui-as-bar--main {
    grid-area: 1 / 1 / 2 / -1;
    padding-left: 50px;
  }
  .ui-as-app[data-header][data-panel] > .ui-as-bar--main {
    padding-right: 50px;
  }
  .ui-as-app[data-header] > :is(.ui-as-bar--side, .ui-as-bar--panel) {
    display: none;
  }
  .ui-as-app[data-header] > :is(.ui-as-side, .ui-as-panel) {
    grid-area: auto;
  }
  .ui-as-app[data-header] > .ui-as-side > .ui-as-side__head {
    display: flex;
  }
  .ui-as-app[data-header] > .ui-as-side > .ui-as-side__search {
    margin-top: 12px;
  }
  .ui-as-app[data-header] > .ui-as-panel > .ui-as-panel__head {
    display: flex;
  }
  .ui-as-app[data-header] > .ui-as-panel > .ui-as-panel__body {
    padding-top: 12px;
  }
  .ui-as-app > .ui-as-scrim {
    display: block;
    position: absolute;
    z-index: 45;
    inset: 0;
    background: rgba(0, 0, 0, 0.28);
    visibility: hidden;
    opacity: 0;
    transition:
      opacity 300ms ease,
      visibility 0s 300ms;
  }
  .ui-as-app[data-drawer] > .ui-as-scrim {
    visibility: visible;
    opacity: 1;
    transition:
      opacity 300ms ease,
      visibility 0s;
  }
  :where(.dark, [data-theme="dark"]) .ui-as-app > .ui-as-scrim {
    background: rgba(0, 0, 0, 0.55);
  }
  .ui-as-app:not([data-drawer]) > .ui-as-side-open {
    visibility: visible;
    opacity: 1;
    transition:
      opacity 260ms ease 160ms,
      visibility 0s;
  }
  .ui-as-app > .ui-as-side-open {
    left: calc(var(--frame-gap) + 9px);
    background: var(--panel);
  }
  .ui-as-app > .ui-as-side-open:hover {
    background: var(--chip);
  }
  .ui-as-page {
    padding: 46px 24px 48px;
  }
  .ui-as-main .ui-as-file-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  }
  .ui-as-main .ui-as-file-grid .ui-as-template {
    width: 100%;
  }
  .ui-as-main .ui-as-file-grid .ui-as-template__name {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .ui-as-main .ui-as-file-grid .ui-as-meta {
    display: block;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
  }
  .ui-as-main .ui-as-file-grid .ui-as-meta svg {
    display: inline-block;
    vertical-align: -2px;
  }
  .ui-as-toolbar {
    flex-wrap: wrap;
    row-gap: 10px;
  }
  .ui-as-toolbar__right {
    flex-wrap: wrap;
  }
  .ui-as-section-head[data-inline] {
    flex-wrap: wrap;
    row-gap: 12px;
  }
}
@container ui-as (max-width: 600px) {
  .ui-as-app > * {
    --frame-gap: 6px;
  }
  .ui-as-menu__subpanel {
    position: static;
    display: none;
    min-width: 0 !important;
    margin: 2px 0 4px;
    padding: 0 0 0 14px;
    border-radius: 0;
    background: none;
    box-shadow: none;
  }
  .ui-as-menu__subpanel::before {
    display: none;
  }
  .ui-as-menu__sub:is(:focus-within, [data-open]) > .ui-as-menu__subpanel {
    display: block;
  }
  .ui-as-menu__sub:is(:focus-within, [data-open])
    > .ui-as-menu__item
    > svg:last-child {
    transform: rotate(90deg);
  }
  .ui-as-news {
    display: none;
  }
  .ui-as-app > .ui-as-main {
    border-radius: 11px;
  }
  .ui-as-page {
    padding: 52px 16px 40px;
  }
  .ui-as-page-title {
    font-size: 20px;
    line-height: 26px;
  }
  .ui-as-section-head {
    margin-top: 32px;
  }
  .ui-as-toolbar__left,
  .ui-as-toolbar__right {
    width: 100%;
  }
  .ui-as-toolbar__right .ui-as-search {
    order: 9;
    flex: 1 1 100%;
    width: auto !important;
  }
  .ui-as-toolbar__right > .ui-buttonc:last-child {
    margin-left: auto;
  }
  .ui-as-tabs {
    max-width: 100%;
    overflow-x: auto;
    scrollbar-width: none;
  }
  .ui-as-tabs__tab {
    flex: none;
  }
  .ui-as-empty {
    padding: 36px 18px 40px;
  }
  .ui-as-popover--filter .ui-fmc {
    width: 300px;
  }
  .ui-as-main .ui-as-file-grid {
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16px 10px;
  }
  .ui-as-main .ui-as-file-grid .ui-as-template__preview {
    height: 128px;
  }
}
.ui-as-app:is(
  [data-layout="flat"],
  [data-shell="flat"] :not([data-layout="inset"])
) {
  --frame-gap: 0px;
  --as-head-edge: 0px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > * {
  --frame-gap: 0px;
  --as-head-edge: 0px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-main {
  margin: 0;
  border: 0;
  border-left: 1px solid var(--line);
  border-radius: 0;
  background: var(--panel);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-panel="open"]
  > .ui-as-main {
  border-right: 1px solid var(--line);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-panel {
  width: var(--panel-w, 360px);
  margin: 0;
  padding: 10px 10px 10px 10px;
  border: 0;
  border-radius: 0;
  background: var(--panel);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-panel-open {
  right: 12px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-header]
  > .ui-as-bar--main {
  background: var(--panel);
  border-left: 1px solid var(--line);
  transition:
    padding 420ms var(--ease),
    border-color 260ms ease;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-header][data-panel="open"]
  > .ui-as-bar--main {
  border-right: 1px solid var(--line);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-header]
  > .ui-as-bar--panel {
  background: var(--panel);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-header]
  > .ui-as-side {
  padding-top: 2px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )[data-header]
  > .ui-as-panel {
  padding-top: 12px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-side {
  padding: 10px 10px 10px 10px;
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-side-open {
  left: 12px;
}
@container ui-as (max-width: 900px) {
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-main {
    margin: 0;
    border-left: 0;
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-side {
    border-radius: 0;
    box-shadow:
      1px 0 0 var(--line),
      0 24px 48px -12px rgba(0, 0, 0, 0.22);
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-side-open {
    left: 12px;
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )[data-panel]
    > .ui-as-main {
    margin: 0;
    border-right: 0;
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-panel {
    border-radius: 0;
    box-shadow:
      -1px 0 0 var(--line),
      0 24px 48px -12px rgba(0, 0, 0, 0.22);
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-panel-open {
    right: 12px;
  }
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )[data-header]
    > .ui-as-bar--main {
    border-left: 0;
    border-right: 0;
  }
}
@container ui-as (max-width: 600px) {
  .ui-as-app:is(
      [data-layout="flat"],
      [data-shell="flat"] :not([data-layout="inset"])
    )
    > .ui-as-main {
    border-radius: 0;
  }
}
.ui-as-app > .ui-as-panel[data-ws] {
  --asw-tray:
    linear-gradient(rgba(0, 0, 0, 0.012), rgba(0, 0, 0, 0.012)), var(--panel);
  padding: 0;
  background: var(--asw-tray);
}
:where(.dark, [data-theme="dark"]) .ui-as-app > .ui-as-panel[data-ws] {
  --asw-tray:
    linear-gradient(rgba(0, 0, 0, 0.12), rgba(0, 0, 0, 0.12)), var(--panel);
}
.ui-as-app:is(
    [data-layout="flat"],
    [data-shell="flat"] :not([data-layout="inset"])
  )
  > .ui-as-panel[data-ws] {
  padding: 0;
  background: var(--asw-tray);
}
.ui-as-app > .ui-as-panel[data-ws] > .ui-as-panel__head {
  display: flex;
  height: var(--as-head-h);
  padding: 0 6px 0 4px;
}
.ui-as-app > .ui-as-panel[data-ws] > .ui-as-panel__body {
  overflow-x: hidden;
  overscroll-behavior: none;
  margin: 0;
  padding: 16px 14px 14px;
  border-radius: 10px 10px 0 0;
  background: var(--card);
  box-shadow:
    0 -0.5px 0 var(--line),
    0 -1px 2px rgba(0, 0, 0, 0.03);
}
@container ui-as (min-width: 901px) {
  .ui-as-app[data-header] > .ui-as-panel[data-ws] {
    grid-area: 1 / 3 / 3 / 4;
  }
}
.ui-asw-bar {
  display: flex;
  flex: 0 1 auto;
  align-items: center;
  gap: 2px;
  min-width: 0;
}
.ui-asw-ptabs {
  display: flex;
  align-items: center;
  gap: 2px;
  min-width: 0;
  padding: 2px;
  overflow-x: auto;
  overscroll-behavior: none;
  scrollbar-width: none;
  font-weight: 400;
}
.ui-asw-ptabs[data-more] {
  mask-image: linear-gradient(90deg, #000 calc(100% - 16px), transparent);
}
.ui-asw-ptabs::-webkit-scrollbar {
  display: none;
}
.ui-asw-ptab-wrap {
  position: relative;
  display: flex;
  flex: 0 1 auto;
  min-width: 92px;
  border-radius: 7px;
  transition: background-color 140ms ease;
}
.ui-asw-ptab {
  display: inline-flex;
  flex: 0 1 auto;
  align-items: center;
  gap: 6px;
  width: 100%;
  min-width: 0;
  max-width: 156px;
  height: 28px;
  padding: 0 26px 0 10px;
  border-radius: 7px;
  font-size: 13px;
  color: var(--muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-asw-ptab > svg {
  flex: none;
  color: var(--muted);
}
.ui-asw-ptab-wrap:hover > .ui-asw-ptab {
  color: var(--ink);
}
.ui-asw-ptab-wrap:not([data-on]):hover {
  background: var(--hover);
}
.ui-asw-ptab-wrap[data-on] {
  background: var(--card);
  box-shadow: var(--card-shadow);
}
.ui-asw-ptab-wrap[data-on] > .ui-asw-ptab {
  color: var(--ink);
}
.ui-asw-ptab-wrap + .ui-asw-ptab-wrap::before {
  content: "";
  position: absolute;
  top: 8px;
  bottom: 8px;
  left: -1.5px;
  width: 1px;
  background: var(--line-strong);
  pointer-events: none;
  transition: opacity 140ms ease;
}
.ui-asw-ptab-wrap:is([data-on], :hover)::before,
.ui-asw-ptab-wrap:is([data-on], :hover) + .ui-asw-ptab-wrap::before {
  opacity: 0;
}
.ui-asw-ptab:focus-visible {
  outline-offset: -2px;
}
.ui-asw-ptab__name {
  min-width: 0;
  padding-right: 8px;
  overflow: hidden;
  white-space: nowrap;
  mask-image: linear-gradient(90deg, #000 calc(100% - 12px), transparent);
}
.ui-asw-ptab__name > * {
  display: inline;
}
.ui-asw-ptab__count {
  flex: none;
  margin-left: -6px;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--chip);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--muted);
  font-variant-numeric: tabular-nums;
}
.ui-asw-ptab__close {
  position: absolute;
  top: 6px;
  right: 5px;
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  color: var(--muted);
  opacity: 0;
  transition:
    opacity 120ms ease,
    background-color 120ms ease;
}
.ui-asw-ptab-wrap:is(:hover, [data-on], :focus-within) > .ui-asw-ptab__close {
  opacity: 1;
}
.ui-asw-ptab__close:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-ptab-new {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  color: var(--muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-asw-ptab-new:hover {
  background: var(--hover);
  color: var(--ink);
}
.ui-asw-ptab-new:focus-visible {
  outline-offset: -2px;
}
@media (pointer: coarse) {
  .ui-asw-ptab__close {
    opacity: 1;
  }
  .ui-asw-ptab-new {
    width: 36px;
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-asw-ptab-wrap,
  .ui-asw-ptab,
  .ui-asw-ptab__close,
  .ui-asw-ptab-new {
    transition: none;
  }
}
@container ui-as (max-width: 900px) {
  .ui-as-app[data-rail] > .ui-as-side {
    width: min(320px, calc(100% - 40px));
    padding: 0;
  }
  .ui-as-app[data-rail] .ui-as-side__col {
    flex: 1;
    width: auto;
    min-width: 0;
    margin: 0;
    padding: 10px 10px 10px 4px;
    border: 0;
    border-radius: 0;
    background: none;
  }
  .ui-as-app[data-rail] > .ui-as-main {
    border-left: 1px solid var(--line);
    border-radius: var(--radius-panel);
  }
}

.ui-as-integrations {
  width: min(957px, calc(100% - 64px));
  margin: 0 auto;
  padding: 40px 0 64px;
}
.ui-as-integrations__bar {
  position: sticky;
  top: 0;
  z-index: 5;
  margin: 14px -16px 0;
  padding: 26px 16px 12px;
  background: var(--panel);
}
.ui-as-integrations__bar::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  top: 100%;
  height: 32px;
  background: linear-gradient(to bottom, var(--panel), transparent);
  pointer-events: none;
}
.ui-as-int-section {
  margin-top: 38px;
}
.ui-as-int-section + .ui-as-int-section {
  margin-top: 46px;
}
.ui-as-int-section__title {
  margin: 0;
  font-size: 15px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-int-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  column-gap: 32px;
  margin-top: 12px;
}
.ui-as-int-row {
  display: flex;
  align-items: center;
  gap: 12px;
  height: 58px;
  margin: 0 -8px;
  padding: 0 8px;
  border-radius: 12px;
  transition: background-color 140ms ease;
}
.ui-as-int-row:hover {
  background: var(--subtle);
}
.ui-as-int-logo {
  display: grid;
  place-items: center;
  flex: none;
  width: 30px;
  height: 30px;
  border-radius: 8px;
  background: var(--card);
  box-shadow: var(--card-shadow);
}
.ui-as-int-logo svg {
  width: 17px;
  height: 17px;
}
.ui-as-int-logo__letter {
  font-size: 13px;
  line-height: 1;
  font-weight: 500;
  color: var(--text);
}
.ui-as-int-logo__letter[data-tile] {
  color: #fff;
}
.ui-as-int-more__logos .ui-as-int-logo__letter {
  font-size: 10px;
}
.ui-as-int-row__text {
  display: grid;
  gap: 2px;
  flex: 1;
  min-width: 0;
}
.ui-as-int-row__name {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  font-size: 14px;
  line-height: 19px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-int-row__label {
  overflow: clip;
  overflow-clip-margin: 2px;
  min-width: 0;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-int-row__badge {
  display: grid;
  flex: none;
  color: var(--faint);
}
.ui-as-int-row__desc {
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  color: var(--muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-as-int-add {
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--card);
  box-shadow: var(--card-shadow);
  color: var(--text);
  transition:
    box-shadow 140ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-as-int-add:hover {
  box-shadow:
    0 0 0 1px var(--line-strong),
    var(--shadow);
  color: var(--ink);
}
.ui-as-int-add svg {
  animation: ui-as-pop 260ms var(--ease);
}
.ui-as-int-add[data-state="on"] {
  background: var(--ink);
  box-shadow: none;
  color: var(--on-ink);
}
.ui-as-int-add[data-state="on"]:hover {
  background: var(--ink-hover);
  color: var(--on-ink);
}
.ui-as-spinner {
  width: 14px;
  height: 14px;
  border: 2px solid var(--line);
  border-top-color: var(--ink);
  border-radius: 50%;
  animation: ui-as-spin 700ms linear infinite;
}
@keyframes ui-as-spin {
  to {
    transform: rotate(360deg);
  }
}
.ui-as-int-empty {
  margin-top: 24px;
}
.ui-as-request {
  width: 260px;
  padding: 14px;
}
.ui-as-request form {
  display: grid;
  gap: 6px;
}
.ui-as-request b {
  font-size: 13px;
  font-weight: 500;
  color: var(--ink);
}
.ui-as-request form > span {
  font-size: 12.5px;
  color: var(--muted);
}
.ui-as-request__field {
  margin: 6px 0 4px;
}
@media (pointer: coarse) {
  .ui-as-int-add {
    width: 32px;
    height: 32px;
  }
}
.ui-as-int-more {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  max-width: 100%;
  margin-top: 8px;
  padding: 4px 8px 4px 4px;
  border-radius: 10px;
  font-size: 13px;
  color: var(--text);
  transition: background-color 140ms ease;
}
.ui-as-int-more:hover {
  background: var(--chip);
}
.ui-as-int-more > svg {
  color: var(--faint);
}
.ui-as-int-more__logos {
  display: flex;
  padding: 3px;
  border-radius: 9px;
  background: var(--card);
  box-shadow: var(--card-shadow);
}
.ui-as-int-more__logos .ui-as-int-logo {
  width: 20px;
  height: 20px;
  border-radius: 6px;
  box-shadow: 0 0 0 0.5px var(--line-strong);
}
.ui-as-int-more__logos .ui-as-int-logo + .ui-as-int-logo {
  margin-left: 3px;
}
.ui-as-int-more__logos .ui-as-int-logo svg {
  width: 12px;
  height: 12px;
}
@container ui-as-main (max-width: 760px) {
  .ui-as-int-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
@container ui-as (max-width: 900px) {
  .ui-as-integrations {
    width: calc(100% - 48px);
  }
}
@container ui-as (max-width: 600px) {
  .ui-as-integrations {
    width: calc(100% - 32px);
    padding: 52px 0 48px;
  }
  .ui-as-integrations__bar {
    margin: 8px -12px 0;
    padding: 18px 12px 10px;
  }
  .ui-as-int-section {
    margin-top: 30px;
  }
  .ui-as-int-section + .ui-as-int-section {
    margin-top: 36px;
  }
  .ui-as-int-more {
    flex-wrap: wrap;
    text-align: left;
  }
  .ui-as-integrations__bar .ui-as-toolbar__right {
    display: contents;
  }
  .ui-as-integrations__bar .ui-as-anchor {
    margin-left: auto;
  }
}
`;export{n as default};
