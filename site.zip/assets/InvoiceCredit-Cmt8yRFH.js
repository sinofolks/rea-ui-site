const n=`.ui-iv {
  --ui-iv-focus: rgba(0, 96, 226, 0.7);
  --ui-iv-tray: #f0f0f0;
  --ui-iv-paper: #ffffff;
  --ui-iv-card-line: #e5e5e5;
  --ui-iv-line: #ececec;
  --ui-iv-inset: #f6f6f6;
  --ui-iv-ink: #171717;
  --ui-iv-text: #404040;
  --ui-iv-muted: #8f8f8f;
  --ui-iv-accent: #4fb0fe;
  --ui-iv-check: #4fb0fe;
  --ui-iv-ok: #1e8a4f;
  --ui-iv-ok-bg: #e6f5ec;
  --ui-iv-hover: #f5f5f5;
  --ui-iv-btn-top: #323137;
  --ui-iv-btn-bottom: #201e25;
  --ui-iv-btn-ring: #0d0d0d;
  --ui-iv-btn-text: #ffffff;
  --ui-iv-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-iv-ease: cubic-bezier(0.65, 0, 0.25, 1);
  container-type: inline-size;
  width: 100%;
  max-width: 760px;
  padding: 6px;
  border-radius: 24px;
  background: var(--ui-iv-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-iv-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-iv *,
.ui-iv *::before,
.ui-iv *::after {
  box-sizing: border-box;
}
.ui-iv button,
.ui-iv input {
  font: inherit;
  color: inherit;
  margin: 0;
}
.ui-iv button {
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-iv :focus-visible {
  outline: 2px solid var(--ui-iv-focus);
  outline-offset: 2px;
}
.ui-iv svg {
  width: 15px;
  height: 15px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-iv p {
  margin: 0;
}
.ui-iv__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px 10px;
  padding: 6px 4px 12px 6px;
}
.ui-iv__seg {
  position: relative;
  display: grid;
  grid-template-columns: 1fr 1fr;
  padding: 3px;
  border-radius: 10px;
  background: rgba(0, 0, 0, 0.05);
}
.ui-iv__seg-thumb {
  position: absolute;
  top: 3px;
  left: 3px;
  width: calc(50% - 3px);
  height: calc(100% - 6px);
  border-radius: 7px;
  background: var(--ui-iv-paper);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  transition: transform 420ms var(--ui-iv-ease);
}
.ui-iv[data-view="credit"] .ui-iv__seg-thumb {
  transform: translateX(100%);
}
.ui-iv__seg button {
  position: relative;
  height: 30px;
  padding: 0 16px;
  white-space: nowrap;
  border: 0;
  background: none;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-iv-muted);
  transition: color 200ms ease;
}
.ui-iv__seg button[aria-selected="true"] {
  color: var(--ui-iv-ink);
}
.ui-iv__actions {
  display: flex;
  gap: 6px;
}
.ui-iv__btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-iv-paper);
  box-shadow:
    inset 0 0 0 1px var(--ui-iv-card-line),
    0 1px 1px rgba(0, 0, 0, 0.03);
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  animation: ui-iv-fade 240ms ease both;
  transition:
    background-color 160ms ease,
    transform 160ms ease;
}
.ui-iv__btn:hover {
  background: var(--ui-iv-hover);
}
.ui-iv__btn:active {
  transform: scale(0.98);
}
.ui-iv__btn svg {
  color: var(--ui-iv-text);
}
.ui-iv__stack {
  position: relative;
  display: grid;
  padding-top: 14px;
}
.ui-iv__sheet {
  grid-area: 1 / 1;
  min-width: 0;
  padding: 44px 48px 36px;
  border: 1px solid var(--ui-iv-card-line);
  border-radius: 20px;
  background: var(--ui-iv-paper);
  box-shadow: 0 -1px 2px rgba(0, 0, 0, 0.03);
  transition:
    transform 620ms var(--ui-iv-ease),
    opacity 420ms ease,
    box-shadow 420ms ease;
}
.ui-iv__sheet[aria-hidden="true"] {
  z-index: 0;
  transform: translateY(-14px) scale(0.96);
  transform-origin: top center;
  pointer-events: none;
}
.ui-iv__sheet[aria-hidden="true"] > * {
  opacity: 0;
  transition: opacity 200ms ease;
}
.ui-iv__sheet:not([aria-hidden="true"]) {
  z-index: 1;
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.04);
}
.ui-iv__sheet:not([aria-hidden="true"]) > * {
  opacity: 1;
  transition: opacity 360ms ease 200ms;
}
.ui-iv__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 40px;
}
.ui-iv__big {
  font-size: 40px;
  font-weight: 500;
  letter-spacing: -0.035em;
  line-height: 1.1;
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.ui-iv__due {
  display: flex;
  align-items: center;
  gap: 28px;
  margin-top: 10px !important;
  font-size: 14px;
  color: var(--ui-iv-text);
}
.ui-iv__due a {
  color: var(--ui-iv-accent);
  text-decoration: none;
}
.ui-iv__due a:hover {
  text-decoration: underline;
}
.ui-iv__badge {
  margin-left: -16px;
  padding: 2px 8px;
  border-radius: 8px;
  background: var(--ui-iv-ok-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-iv-ok);
}
.ui-iv__head > div:first-child {
  flex: none;
  max-width: 100%;
}
.ui-iv__brand {
  display: inline-flex;
  align-items: center;
  gap: 9px;
  min-width: 0;
  max-width: 100%;
  padding-top: 8px;
  font-size: 15px;
  color: var(--ui-iv-text);
  white-space: nowrap;
}
.ui-iv__brand-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-iv__logo {
  flex: none;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: conic-gradient(from 210deg, #2f6bff, #8fb0ff, #2f6bff);
  -webkit-mask: radial-gradient(circle, transparent 4px, #000 4.5px);
  mask: radial-gradient(circle, transparent 4px, #000 4.5px);
}
.ui-iv__label {
  margin-bottom: 8px !important;
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-iv-ink);
}
.ui-iv__parties {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 24px;
  margin-bottom: 36px;
}
.ui-iv__party {
  min-width: 0;
}
.ui-iv__party p:not(.ui-iv__label) {
  font-size: 14px;
  line-height: 1.6;
  color: var(--ui-iv-text);
  overflow-wrap: anywhere;
}
.ui-iv__terms {
  margin-bottom: 36px;
}
.ui-iv__terms dl {
  display: grid;
  gap: 7px;
  margin: 0;
}
.ui-iv__terms dl > div {
  display: grid;
  grid-template-columns: 140px 1fr;
  font-size: 14px;
}
.ui-iv__terms dt {
  color: var(--ui-iv-muted);
}
.ui-iv__terms dd {
  min-width: 0;
  margin: 0;
  color: var(--ui-iv-text);
  overflow-wrap: anywhere;
}
.ui-iv__ref {
  padding: 0;
  border: 0;
  background: none;
  text-align: left;
  color: var(--ui-iv-accent) !important;
  font-variant-numeric: tabular-nums;
}
button.ui-iv__ref:hover {
  text-decoration: underline;
}
.ui-iv__table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}
.ui-iv__table th {
  padding: 0 0 12px;
  border-bottom: 1px solid var(--ui-iv-line);
  text-align: left;
  font-weight: 500;
  color: var(--ui-iv-ink);
}
.ui-iv__table td {
  padding: 14px 0;
  border-bottom: 1px solid var(--ui-iv-line);
  color: var(--ui-iv-text);
  font-variant-numeric: tabular-nums;
}
.ui-iv__table tr[data-indent] td:first-child {
  padding-left: 24px;
}
.ui-iv__group td {
  color: var(--ui-iv-ink);
}
.ui-iv__num {
  text-align: right !important;
  white-space: nowrap;
}
.ui-iv__name,
.ui-iv__group td {
  overflow-wrap: anywhere;
}
.ui-iv__table td:nth-child(2) {
  white-space: nowrap;
}
@container (min-width: 561px) {
  .ui-iv__table[data-wide] th + th,
  .ui-iv__table[data-wide] td + td {
    padding-left: 16px;
  }
}
.ui-iv__empty td {
  color: var(--ui-iv-muted);
}
.ui-iv__none {
  padding: 18px 0;
  font-size: 14px;
  color: var(--ui-iv-muted);
}
.ui-iv__totals {
  display: grid;
  gap: 12px;
  width: min(100%, 300px);
  margin: 22px 0 0 auto;
  font-size: 14px;
}
.ui-iv__totals > div {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  color: var(--ui-iv-muted);
  font-variant-numeric: tabular-nums;
}
.ui-iv__totals > div > :last-child {
  white-space: nowrap;
}
.ui-iv__totals > div span:last-child {
  color: var(--ui-iv-text);
}
.ui-iv__total {
  margin-top: 4px;
  padding-top: 14px;
  border-top: 1px solid var(--ui-iv-text);
}
.ui-iv__total span {
  font-weight: 500;
  color: var(--ui-iv-text) !important;
}
.ui-iv__total b {
  font-size: 16px;
  font-weight: 600;
  color: var(--ui-iv-ink);
}
.ui-iv__note {
  margin-top: -4px;
}
.ui-iv__tray {
  padding: 0 6px 6px;
  border-radius: 18px;
  background: var(--ui-iv-inset);
  box-shadow: inset 0 0 0 1px var(--ui-iv-line);
}
.ui-iv__tray-title {
  padding: 14px 12px 12px;
  font-size: 15px;
  font-weight: 500;
  color: var(--ui-iv-text);
}
.ui-iv__card {
  padding: 4px 14px;
  border: 1px solid var(--ui-iv-card-line);
  border-radius: 14px;
  background: var(--ui-iv-paper);
  box-shadow: var(--ui-iv-shadow);
}
.ui-iv__crow {
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr) auto minmax(min-content, 0.8fr);
  align-items: center;
  gap: 14px;
  min-height: 60px;
  border-bottom: 1px solid var(--ui-iv-line);
  font-size: 14.5px;
  transition: opacity 220ms ease;
}
.ui-iv__crow:last-child {
  border-bottom: 0;
}
.ui-iv__crow--head {
  min-height: 46px;
  font-size: 13.5px;
  color: var(--ui-iv-muted);
}
.ui-iv__crow[data-off] .ui-iv__cname,
.ui-iv__crow[data-off] > .ui-iv__num:nth-child(3) {
  opacity: 0.45;
}
.ui-iv__crow > .ui-iv__num {
  font-variant-numeric: tabular-nums;
  color: var(--ui-iv-ink);
}
.ui-iv__cname {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  overflow-wrap: break-word;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
}
.ui-iv__check {
  position: relative;
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: var(--ui-iv-inset);
  box-shadow: inset 0 0 0 1px var(--ui-iv-card-line);
  color: #fff !important;
  transition:
    background-color 180ms ease,
    box-shadow 180ms ease;
}
.ui-iv__check svg {
  width: 13px;
  height: 13px;
  stroke-width: 2.4;
  stroke-dasharray: 20;
  stroke-dashoffset: 20;
  transition: stroke-dashoffset 260ms ease;
}
.ui-iv__check[aria-checked="true"] {
  background: var(--ui-iv-check);
  box-shadow: inset 0 0 0 1px var(--ui-iv-check);
}
.ui-iv__check[aria-checked="true"] svg {
  stroke-dashoffset: 0;
}
.ui-iv__check:disabled {
  cursor: default;
}
.ui-iv__amount {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  min-width: 150px;
  max-width: 220px;
  margin-left: auto;
  height: 44px;
  padding: 0 14px;
  border-radius: 12px;
  background: var(--ui-iv-paper);
  box-shadow: inset 0 0 0 1px var(--ui-iv-card-line);
  transition:
    box-shadow 160ms ease,
    opacity 200ms ease;
}
.ui-iv__amount:focus-within {
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-iv-muted) 60%, transparent);
}
.ui-iv__amount span {
  flex: none;
  color: var(--ui-iv-muted);
}
.ui-iv__amount input {
  flex: 1;
  width: 0;
  min-width: calc(var(--ui-iv-chars, 4) * 1ch + 1px);
  border: 0;
  background: none;
  outline: none;
  text-align: right;
  font-size: 14.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-iv-ink);
}
.ui-iv__amount[data-disabled] {
  opacity: 0.5;
}
.ui-iv__issue {
  display: flex;
  justify-content: flex-end;
  margin-top: 24px;
}
.ui-iv__primary {
  height: 38px;
  padding: 0 16px;
  border: 0;
  border-radius: 10px;
  background: linear-gradient(
    180deg,
    var(--ui-iv-btn-top),
    var(--ui-iv-btn-bottom)
  );
  box-shadow:
    0 0 0 1px var(--ui-iv-btn-ring),
    inset 0 1px 0 rgba(255, 255, 255, 0.12);
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-iv-btn-text) !important;
  transition:
    filter 160ms ease,
    opacity 200ms ease,
    transform 160ms ease;
}
.ui-iv__primary:hover:not(:disabled) {
  filter: brightness(1.12);
}
.ui-iv__primary:active:not(:disabled) {
  transform: scale(0.98);
}
.ui-iv__primary:disabled {
  opacity: 0.4;
  cursor: default;
}
@keyframes ui-iv-fade {
  from {
    opacity: 0;
  }
}
@container (max-width: 560px) {
  .ui-iv__sheet {
    padding: 28px 20px 24px;
  }
  .ui-iv__big {
    font-size: clamp(22px, 8.5cqi, 30px);
  }
  .ui-iv__head {
    flex-direction: column-reverse;
    margin-bottom: 28px;
  }
  .ui-iv__parties {
    grid-template-columns: 1fr;
  }
  .ui-iv__terms dl > div {
    grid-template-columns: 120px 1fr;
  }
  .ui-iv__table th:nth-child(4),
  .ui-iv__table td:nth-child(4),
  .ui-iv__table th:nth-child(3),
  .ui-iv__table td:nth-child(3) {
    display: none;
  }
  .ui-iv__table th + th,
  .ui-iv__table td + td {
    padding-left: 12px;
  }
  .ui-iv__crow {
    grid-template-columns: 22px minmax(0, 1fr) minmax(min-content, 0.9fr);
  }
  .ui-iv__amount {
    min-width: 110px;
  }
  .ui-iv__crow > :nth-child(3) {
    display: none;
  }
  .ui-iv__actions .ui-iv__btn:first-child {
    display: none;
  }
  .ui-iv__seg button {
    padding: 0 11px;
  }
  .ui-iv__btn {
    padding: 0 10px;
  }
}
@container (max-width: 400px) {
  .ui-iv__sheet {
    padding: 24px 16px 20px;
  }
  .ui-iv__card {
    padding: 4px 10px;
  }
  .ui-iv__crow {
    gap: 10px;
  }
  .ui-iv__amount {
    gap: 4px;
    padding: 0 10px;
  }
  .ui-iv__terms dl > div {
    grid-template-columns: 112px 1fr;
  }
}
@media (pointer: coarse) {
  .ui-iv__seg button {
    height: 36px;
  }
  .ui-iv__btn {
    height: 38px;
  }
  .ui-iv__primary {
    height: 42px;
    padding: 0 18px;
  }
  .ui-iv__check::before {
    content: "";
    position: absolute;
    inset: -8px;
  }
  .ui-iv__amount input {
    font-size: 16px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-iv__sheet,
  .ui-iv__sheet > *,
  .ui-iv__seg-thumb,
  .ui-iv__check svg {
    transition: none !important;
  }
  .ui-iv__btn {
    animation: none;
  }
}
.ui-iv input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-iv textarea:focus-visible,
.ui-iv [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-iv {
  --ui-iv-focus: rgba(77, 141, 255, 0.8);
  --ui-iv-tray: #161618;
  --ui-iv-paper: #232326;
  --ui-iv-card-line: rgba(255, 255, 255, 0.08);
  --ui-iv-line: rgba(255, 255, 255, 0.07);
  --ui-iv-inset: #1c1c1f;
  --ui-iv-ink: #ededed;
  --ui-iv-text: #c4c4c4;
  --ui-iv-muted: #8f8f8f;
  --ui-iv-accent: #4fb0fe;
  --ui-iv-check: #4fb0fe;
  --ui-iv-ok: #7dcf9f;
  --ui-iv-ok-bg: rgba(125, 207, 159, 0.14);
  --ui-iv-hover: rgba(255, 255, 255, 0.05);
  --ui-iv-btn-top: #f4f4f5;
  --ui-iv-btn-bottom: #e4e4e7;
  --ui-iv-btn-ring: rgba(0, 0, 0, 0.6);
  --ui-iv-btn-text: #121213;
  --ui-iv-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-iv__seg {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-iv__seg-thumb {
  background: #313135;
}

.invoice-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.invoice-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.card__preview .invoice-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.invoice-demo[data-fit="card"] .invoice-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 24px;
}
.invoice-demo__frame {
  min-width: 0;
}
`;export{n as default};
