const n=`.ui-kbc {
  --ui-kbc-card: #fff;
  --ui-kbc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-kbc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 8px 24px -4px rgba(0, 0, 0, 0.1),
    0 2px 6px rgba(0, 0, 0, 0.05);
  --ui-kbc-line: rgba(0, 0, 0, 0.06);
  --ui-kbc-strong: #000;
  --ui-kbc-ink: rgba(0, 0, 0, 0.88);
  --ui-kbc-text: rgba(0, 0, 0, 0.61);
  --ui-kbc-muted: rgba(0, 0, 0, 0.45);
  --ui-kbc-faint: rgba(0, 0, 0, 0.27);
  --ui-kbc-hover: rgba(0, 0, 0, 0.04);
  --ui-kbc-rule: rgba(0, 0, 0, 0.2);
  --ui-kbc-accent: #0070d6;
  --ui-kbc-soft: rgba(0, 96, 226, 0.32);
  --ui-kbc-good: #1e8a4f;
  --ui-kbc-good-bg: rgba(95, 200, 138, 0.1);
  --ui-kbc-bad: #c4320a;
  --ui-kbc-bad-bg: rgba(240, 68, 56, 0.1);
  --ui-kbc-tip: rgba(0, 0, 0, 0.88);
  --ui-kbc-focus: rgba(0, 96, 226, 0.7);
  --ui-kbc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  display: grid;
  grid-template-columns: repeat(6, minmax(0, 1fr));
  gap: 12px;
  width: 100%;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-kbc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-kbc *,
.ui-kbc *::before,
.ui-kbc *::after {
  box-sizing: border-box;
}
:where(.ui-kbc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-kbc button:focus-visible {
  outline: 2px solid var(--ui-kbc-focus);
  outline-offset: 2px;
}
.ui-kbc svg {
  display: block;
}
.ui-kbc b {
  font-weight: 500;
  color: var(--ui-kbc-strong);
}
.ui-kbc i {
  font-style: normal;
}
.ui-kbc__bar {
  grid-column: 1 / -1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 12px;
  min-height: 28px;
}
.ui-kbc__heading {
  flex: 1;
  min-width: 0;
  margin: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-kbc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-kbc__card {
  grid-column: span 2;
  display: flex;
  flex-direction: column;
  min-width: 0;
  padding: 16px;
  border-radius: 10px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  animation: ui-kbc-rise 620ms var(--ui-kbc-ease) both;
  animation-delay: calc(var(--n) * 60ms);
}
.ui-kbc__overview {
  grid-column: span 4;
}
.ui-kbc__row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  min-width: 0;
}
.ui-kbc__pair {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  min-width: 0;
  font-variant-numeric: tabular-nums;
}
.ui-kbc__pair > * {
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-kbc__stat .ui-kbc__pair > b,
.ui-kbc__stat .ui-kbc__pair > .ui-kbc__change {
  overflow: visible;
}
.ui-kbc__stat .ui-kbc__pair:first-child {
  flex: 1 1 0;
}
.ui-kbc__stat .ui-kbc__pair:first-child {
  display: flex;
  flex-direction: column-reverse;
}
.ui-kbc__stat .ui-kbc__pair:first-child b {
  font-size: 20px;
  line-height: 28px;
  letter-spacing: -0.2px;
}
.ui-kbc__pair b {
  font-size: 13px;
}
.ui-kbc__pair span {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kbc-muted);
}
.ui-kbc__stat .ui-kbc__pair:first-child > span {
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-kbc-text);
}
.ui-kbc__pair--end {
  justify-items: end;
  gap: 4px;
  flex: 0 1 auto;
  max-width: 50%;
  padding-top: 2px;
  text-align: right;
}
.ui-kbc .ui-kbc__change {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  width: fit-content;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-kbc-bad-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-kbc-bad);
  font-variant-numeric: tabular-nums;
}
.ui-kbc .ui-kbc__change[data-good] {
  background: var(--ui-kbc-good-bg);
  color: var(--ui-kbc-good);
}
.ui-kbc__change svg {
  width: 7px;
  height: 7px;
}
.ui-kbc__plot {
  position: relative;
  margin-top: 16px;
  box-shadow: inset 0 -0.5px 0 var(--ui-kbc-line);
  cursor: crosshair;
  touch-action: pan-y;
}
.ui-kbc__plot--small {
  height: 64px;
}
.ui-kbc__plot--large {
  flex: 1;
  min-height: 190px;
  margin-top: 16px;
}
.ui-kbc__plot svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  animation: ui-kbc-draw 1100ms var(--ui-kbc-ease) both;
  animation-delay: calc(120ms + var(--n) * 60ms);
}
.ui-kbc__line {
  fill: none;
  stroke: var(--ui-kbc-accent);
  stroke-width: 1.5;
  stroke-linejoin: miter;
  stroke-linecap: round;
  vector-effect: non-scaling-stroke;
}
.ui-kbc__line--soft {
  stroke: var(--ui-kbc-soft);
  stroke-dasharray: 3 3;
}
.ui-kbc__grid {
  fill: none;
  stroke: var(--ui-kbc-line);
  stroke-width: 0.5;
  vector-effect: non-scaling-stroke;
}
.ui-kbc__axis {
  position: relative;
  display: flex;
  justify-content: space-between;
  gap: 12px;
  height: 16px;
  margin-top: 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kbc-muted);
  white-space: nowrap;
}
.ui-kbc__axis > span:not(.ui-kbc__axis-tag) {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-kbc__rule {
  position: absolute;
  bottom: 0;
  width: 0;
  margin-left: -0.25px;
  border-left: 0.5px solid var(--ui-kbc-rule);
  pointer-events: none;
}
.ui-kbc__dot {
  position: absolute;
  z-index: 1;
  width: 8px;
  height: 8px;
  margin: -4px 0 0 -4px;
  border: 1.5px solid var(--ui-kbc-accent);
  border-radius: 50%;
  background: var(--ui-kbc-card);
  pointer-events: none;
}
.ui-kbc__dot--soft {
  border-color: var(--ui-kbc-soft);
}
.ui-kbc__tag {
  position: absolute;
  z-index: 2;
  display: inline-flex;
  gap: 10px;
  height: 24px;
  padding: 0 8px;
  border-radius: 6px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow-pop);
  font-size: 12px;
  line-height: 24px;
  color: var(--ui-kbc-muted);
  white-space: nowrap;
  pointer-events: none;
  transform: translate(var(--ui-kbc-dx, 10px), -130%);
  font-variant-numeric: tabular-nums;
  animation: ui-kbc-in 160ms ease both;
}
.ui-kbc__tag[data-side="left"] {
  transform: translate(var(--ui-kbc-dx, calc(-100% - 10px)), -130%);
}
.ui-kbc__tag b {
  font-size: 12px;
  color: var(--ui-kbc-strong);
}
.ui-kbc__axis-tag {
  position: absolute;
  top: -4px;
  height: 22px;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  line-height: 22px;
  color: var(--ui-kbc-ink);
  transform: translateX(var(--ui-kbc-dx, -50%));
}
.ui-kbc__label {
  overflow: hidden;
  font-size: 13px;
  color: var(--ui-kbc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-kbc__head {
  flex: 1 1 auto;
  min-width: 0;
}
.ui-kbc__figure {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 10px;
  margin-top: 2px;
  font-variant-numeric: tabular-nums;
}
.ui-kbc__figure b {
  font-size: 24px;
  line-height: 32px;
  letter-spacing: -0.24px;
}
.ui-kbc__figure--small b {
  font-size: 20px;
  line-height: 28px;
  letter-spacing: -0.2px;
}
.ui-kbc__vs {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  max-width: 100%;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kbc-muted);
  white-space: nowrap;
}
.ui-kbc__vs-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-kbc__pick {
  position: relative;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
}
.ui-kbc__pick-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  padding: 0 8px 0 7px;
  border-radius: 6px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-kbc-strong);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-kbc__pick-button > span,
.ui-kbc__option > span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-kbc__pick-button svg,
.ui-kbc__option svg {
  flex: none;
}
.ui-kbc__pick-icon {
  display: grid;
  flex: none;
  place-items: center;
  color: var(--ui-kbc-muted);
}
.ui-kbc__pick-button:hover,
.ui-kbc__pick[data-open] .ui-kbc__pick-button {
  background: #fafafa;
}
.ui-kbc__pick-button > svg {
  color: var(--ui-kbc-muted);
  transition: transform 240ms var(--ui-kbc-ease);
}
.ui-kbc__pick[data-open] .ui-kbc__pick-button > svg {
  transform: rotate(180deg);
}
.ui-kbc__menu {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  z-index: 10;
  min-width: max(100%, 160px);
  max-width: min(320px, 86vw);
  margin: 0;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow-pop);
  list-style: none;
  transform-origin: 100% 0;
  animation: ui-kbc-menu 200ms var(--ui-kbc-ease) both;
}
.ui-kbc__option {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 13px;
  color: var(--ui-kbc-ink);
  white-space: nowrap;
  cursor: pointer;
}
.ui-kbc__option > span:not(.ui-kbc__pick-icon) {
  flex: 1;
}
.ui-kbc__option[data-active] {
  background: var(--ui-kbc-hover);
}
.ui-kbc__option svg {
  color: var(--ui-kbc-muted);
}
.ui-kbc__tip {
  position: absolute;
  z-index: 3;
  min-width: 168px;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--ui-kbc-tip);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.16);
  font-size: 12px;
  line-height: 20px;
  color: rgba(255, 255, 255, 0.61);
  pointer-events: none;
  width: max-content;
  max-width: 100%;
  transform: translate(var(--ui-kbc-dx, 14px), calc(-100% - 12px));
  font-variant-numeric: tabular-nums;
  animation: ui-kbc-in 160ms ease both;
}
.ui-kbc__tip[data-side="left"] {
  transform: translate(
    var(--ui-kbc-dx, calc(-100% - 14px)),
    calc(-100% - 12px)
  );
}
.ui-kbc__tip b {
  font-size: 12px;
  font-weight: 500;
  color: #fcfcfc;
}
.ui-kbc__tip-head {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 4px;
  color: #fcfcfc;
}
.ui-kbc__tip-row {
  display: flex;
  align-items: center;
  gap: 7px;
}
.ui-kbc__tip-row span {
  flex: 1;
}
.ui-kbc__tip-row i {
  width: 7px;
  height: 7px;
  border: 1.5px solid #4fb0fe;
  border-radius: 50%;
}
.ui-kbc__tip-row[data-soft] i {
  border-color: rgba(255, 255, 255, 0.35);
  border-style: dashed;
}
.ui-kbc__focus .ui-kbc__row--top {
  align-items: center;
  margin-bottom: 16px;
}
.ui-kbc__focus .ui-kbc__plot--small {
  flex: 1;
  min-height: 64px;
  margin-top: 16px;
}
.ui-kbc__product {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-kbc__product b {
  font-size: 13px;
  font-weight: 500;
}
.ui-kbc__product .ui-kbc__pair span {
  font-size: 12px;
}
.ui-kbc__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  color: var(--ui-kbc-muted);
}
.ui-kbc__focus .ui-kbc__label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kbc-muted);
}
.ui-kbc__legend {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 2px 6px;
  margin-top: 12px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kbc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-kbc__legend b {
  margin-right: 8px;
  font-size: 12px;
  color: var(--ui-kbc-strong);
}
.ui-kbc__legend b[data-soft] {
  color: var(--ui-kbc-muted);
}
.ui-kbc__setup {
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-kbc-strong);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-kbc__setup:hover {
  background: #fafafa;
}
.ui-kbc__setup svg {
  color: var(--ui-kbc-muted);
}
.ui-kbc__action {
  height: 32px;
  margin-top: auto;
  border-radius: 8px;
  background: var(--ui-kbc-card);
  box-shadow: var(--ui-kbc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-kbc-strong);
  transition: background-color 160ms ease;
}
.ui-kbc__legend + .ui-kbc__action {
  margin-top: 16px;
}
.ui-kbc__action:hover {
  background: #fafafa;
}
.ui-kbc__tag {
  width: max-content;
  max-width: 100%;
}
.ui-kbc__tag > span {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-kbc__tag > b {
  flex: none;
}
.ui-kbc__setup svg {
  flex: none;
}
.ui-kbc__setup > span,
.ui-kbc__action > span {
  display: block;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-kbc__action {
  min-width: 0;
  padding: 0 12px;
}
.ui-kbc__plot:focus-visible {
  outline: 2px solid var(--ui-kbc-focus);
  outline-offset: 2px;
}
@keyframes ui-kbc-rise {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}
@keyframes ui-kbc-draw {
  from {
    clip-path: inset(0 100% 0 0);
  }
  to {
    clip-path: inset(-8px -8px -8px -8px);
  }
}
@keyframes ui-kbc-in {
  from {
    opacity: 0;
  }
}
@keyframes ui-kbc-menu {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.97);
  }
}
@container (max-width: 820px) {
  .ui-kbc__overview,
  .ui-kbc__focus {
    grid-column: span 6;
  }
  .ui-kbc__stat .ui-kbc__row {
    flex-direction: column;
    gap: 6px;
  }
  .ui-kbc__stat .ui-kbc__pair--end {
    justify-items: start;
    max-width: 100%;
    padding-top: 0;
    text-align: left;
  }
  .ui-kbc__stat .ui-kbc__pair:first-child {
    flex: none;
  }
  .ui-kbc__stat .ui-kbc__pair--end > span:last-child {
    display: none;
  }
}
@container (max-width: 600px) {
  .ui-kbc {
    gap: 8px;
  }
  .ui-kbc__card {
    grid-column: span 6;
  }
  .ui-kbc__stat .ui-kbc__row {
    flex-direction: row;
    gap: 12px;
  }
  .ui-kbc__stat .ui-kbc__pair--end {
    justify-items: end;
    max-width: 50%;
    padding-top: 2px;
    text-align: right;
  }
  .ui-kbc__stat .ui-kbc__pair:first-child {
    flex: 1 1 0;
  }
  .ui-kbc__stat .ui-kbc__pair--end > span:last-child {
    display: block;
  }
  .ui-kbc__row--top {
    flex-wrap: wrap;
  }
  .ui-kbc__plot--large {
    min-height: 160px;
  }
  .ui-kbc__row--top > .ui-kbc__pick {
    margin-left: auto;
  }
}
@media (pointer: coarse) {
  .ui-kbc__pick-button,
  .ui-kbc__setup {
    height: 36px;
  }
  .ui-kbc__option {
    height: 38px;
  }
  .ui-kbc__action {
    height: 38px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-kbc *,
  .ui-kbc *::before,
  .ui-kbc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-kbc {
  --ui-kbc-card: #1c1c1e;
  --ui-kbc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-kbc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 12px 30px rgba(0, 0, 0, 0.5);
  --ui-kbc-line: rgba(255, 255, 255, 0.08);
  --ui-kbc-strong: #fff;
  --ui-kbc-ink: rgba(255, 255, 255, 0.88);
  --ui-kbc-text: rgba(255, 255, 255, 0.61);
  --ui-kbc-muted: rgba(255, 255, 255, 0.45);
  --ui-kbc-faint: rgba(255, 255, 255, 0.27);
  --ui-kbc-hover: rgba(255, 255, 255, 0.06);
  --ui-kbc-rule: rgba(255, 255, 255, 0.25);
  --ui-kbc-accent: #4fb0fe;
  --ui-kbc-soft: rgba(79, 176, 254, 0.45);
  --ui-kbc-good: #5fc88a;
  --ui-kbc-good-bg: rgba(125, 207, 159, 0.12);
  --ui-kbc-bad: #ff8a7a;
  --ui-kbc-bad-bg: rgba(255, 107, 95, 0.12);
  --ui-kbc-tip: #2c2c2e;
  --ui-kbc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"])
  .ui-kbc
  :is(
    .ui-kbc__pick-button:hover,
    .ui-kbc__pick[data-open] .ui-kbc__pick-button,
    .ui-kbc__setup:hover,
    .ui-kbc__action:hover
  ) {
  background: #232325;
}

.kb-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.kb-demo[data-fit="stage"] {
  justify-items: center;
  padding: 36px 0;
  display: grid;
}
.card__preview .kb-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.kb-demo[data-fit="card"] .kb-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 24px;
}
.kb-demo__frame {
  min-width: 0;
}
@media (width<=760px) {
  .kb-demo {
    padding-top: 96px;
  }
}
`;export{n as default};
