const n=`.ui-crs {
  --ui-crs-tray: #f0f0f0;
  --ui-crs-card: #ffffff;
  --ui-crs-bubble: #f5f5f5;
  --ui-crs-bubble-hover: #efefef;
  --ui-crs-strong: #171717;
  --ui-crs-ink: #171717;
  --ui-crs-text: #5f5f5f;
  --ui-crs-muted: #8a8a8a;
  --ui-crs-faint: #b8b8b8;
  --ui-crs-pixel: #a8a8a8;
  --ui-crs-fill: #ebebeb;
  --ui-crs-well: rgba(0, 0, 0, 0.045);
  --ui-crs-you: #ffffff;
  --ui-crs-you-line: #e6e6e6;
  --ui-crs-line: #ececec;
  --ui-crs-scrim: rgba(240, 240, 240, 0.72);
  --ui-crs-accent: #4fb0fe;
  --ui-crs-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-crs-shadow-hover: 0 0 0 1px #e2e2e2, 0 2px 6px -2px rgba(0, 0, 0, 0.1);
  --ui-crs-pop:
    0 0 0 1px #e8e8e8, 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-crs-shine: rgba(255, 255, 255, 0.82);
  --ui-crs-solid: #171717;
  --ui-crs-on-solid: #ffffff;
  --ui-crs-wait-bg: #fff1e0;
  --ui-crs-wait-fg: #b25e00;
  --ui-crs-focus: rgba(0, 96, 226, 0.7);
  --ui-crs-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-crs-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  letter-spacing: -0.006em;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-crs-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-crs *,
.ui-crs *::before,
.ui-crs *::after {
  box-sizing: border-box;
}
:where(.ui-crs) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-crs button:focus-visible {
  outline: 2px solid var(--ui-crs-focus);
  outline-offset: 2px;
}
.ui-crs p {
  margin: 0;
}
.ui-crs svg {
  display: block;
  flex: none;
}
.ui-crs__live {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-muted);
}
.ui-crs__pulse {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-crs-accent);
  animation: ui-crs-pulse 1400ms ease-in-out infinite;
}
.ui-crs__top {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding: 2px 12px 6px 2px;
}
.ui-crs__tabs {
  display: flex;
  flex: 1;
  gap: 2px;
  min-width: 0;
  padding: 2px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-crs__tabs::-webkit-scrollbar {
  display: none;
}
.ui-crs__tabs[data-more="end"] {
  -webkit-mask: linear-gradient(to right, #000 calc(100% - 32px), transparent);
  mask: linear-gradient(to right, #000 calc(100% - 32px), transparent);
}
.ui-crs__tabs[data-more="start"] {
  -webkit-mask: linear-gradient(to right, transparent, #000 32px);
  mask: linear-gradient(to right, transparent, #000 32px);
}
.ui-crs__tabs[data-more="both"] {
  -webkit-mask: linear-gradient(
    to right,
    transparent,
    #000 32px,
    #000 calc(100% - 32px),
    transparent
  );
  mask: linear-gradient(
    to right,
    transparent,
    #000 32px,
    #000 calc(100% - 32px),
    transparent
  );
}
.ui-crs__tab-name {
  max-width: 160px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-crs__tab {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 8px;
  border-radius: 7px;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-crs-muted);
  white-space: nowrap;
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-crs__tab:hover {
  color: var(--ui-crs-text);
}
.ui-crs__tab[aria-pressed="true"] {
  background: var(--ui-crs-card);
  color: var(--ui-crs-ink);
  box-shadow: var(--ui-crs-shadow);
}
.ui-crs .ui-crs__tab:focus-visible {
  outline-offset: -2px;
}
.ui-crs__mark {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 3px);
  grid-auto-rows: 3px;
  gap: 1.5px;
  place-content: center;
  width: 16px;
  height: 16px;
}
.ui-crs__mark i {
  border-radius: 0.75px;
  background: var(--ui-crs-c, var(--ui-crs-pixel));
  opacity: 0;
  transition: opacity 240ms ease;
}
.ui-crs__mark i[data-on] {
  opacity: 1;
}
.ui-crs__mark[data-you] i {
  background: var(--ui-crs-ink);
}
.ui-crs__mark[data-busy] i {
  animation: ui-crs-pixel 1.2s ease-in-out infinite both;
}
.ui-crs__mark[data-busy] i:not([data-on]) {
  opacity: 0.16;
}
.ui-crs__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
}
.ui-crs__logo > svg {
  width: 14px;
  height: 14px;
}
.ui-crs__logo[data-busy] {
  animation: ui-crs-pulse 1200ms ease-in-out infinite;
}
.ui-crs__panel {
  position: relative;
  border-radius: 16px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-shadow);
}
.ui-crs__scroll {
  padding: 0 12px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  -webkit-mask: linear-gradient(
    transparent,
    #000 24px,
    #000 calc(100% - 24px),
    transparent
  );
  mask: linear-gradient(
    transparent,
    #000 24px,
    #000 calc(100% - 24px),
    transparent
  );
}
.ui-crs__stream {
  display: grid;
  padding: 18px 0 20px;
}
.ui-crs[data-picking] :is(.ui-crs__msg, .ui-crs__system):not([data-kept]) {
  opacity: 0.3;
}
.ui-crs__msg {
  display: grid;
  grid-template-columns: 16px minmax(0, 1fr);
  column-gap: 10px;
  align-items: start;
  margin: 0 -8px;
  padding: 4px 8px;
  border-radius: 14px;
  outline: none;
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-crs__msg[data-you] {
  grid-template-columns: minmax(0, 1fr);
}
.ui-crs__msg[data-you] > .ui-crs__side {
  display: none;
}
.ui-crs__msg[data-you] .ui-crs__body {
  justify-self: end;
  background: var(--ui-crs-you);
  box-shadow: inset 0 0 0 1px var(--ui-crs-you-line);
}
.ui-crs__msg[data-you]:hover .ui-crs__body,
.ui-crs__msg[data-you][data-selected] .ui-crs__body {
  box-shadow: inset 0 0 0 1px var(--ui-crs-you-line);
  filter: brightness(0.985);
}
.ui-crs__msg[data-same] {
  margin-top: -2px;
}
.ui-crs .ui-crs__msg:focus-visible {
  outline: none;
}
.ui-crs__msg:focus-visible .ui-crs__body {
  outline: 2px solid var(--ui-crs-focus);
  outline-offset: 2px;
}
.ui-crs .ui-crs__system:focus-visible {
  outline: 2px solid var(--ui-crs-focus);
  outline-offset: -2px;
}
.ui-crs .ui-crs__quote:focus-visible {
  outline-offset: -2px;
}
.ui-crs__window-body:focus-visible {
  outline: 2px solid var(--ui-crs-focus);
  outline-offset: -2px;
}
.ui-crs__side {
  display: grid;
  height: 38px;
  place-items: center;
}
.ui-crs__body {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 7px;
  justify-self: start;
  min-width: 0;
  max-width: min(100%, 560px);
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-crs-bubble);
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease;
}
.ui-crs__msg:hover .ui-crs__body,
.ui-crs__msg[data-selected] .ui-crs__body {
  background: var(--ui-crs-bubble-hover);
}
.ui-crs__msg[data-flash] .ui-crs__body {
  animation: ui-crs-flash 1400ms ease both;
}
.ui-crs__quote {
  display: grid;
  gap: 1px;
  min-width: 0;
  margin: 0;
  padding: 5px 10px 6px 8px;
  border-radius: 8px;
  background: var(--ui-crs-well);
  text-align: left;
  transition: background-color 140ms ease;
}
.ui-crs__quote:not([data-only]):hover {
  background: var(--ui-crs-fill);
}
.ui-crs__quote[data-only] {
  justify-self: start;
  padding: 4px 10px 4px 8px;
}
.ui-crs__quote-to {
  margin-right: -1px;
  font-weight: 400;
  color: var(--ui-crs-muted);
}
.ui-crs__quote-who {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-crs__quote-who + .ui-crs__quote-to {
  margin-right: -1px;
  font-weight: 400;
  color: var(--ui-crs-muted);
}
.ui-crs__quote-who {
  margin-left: 8px;
}
.ui-crs__quote-who {
  min-width: 0;
}
.ui-crs__quote-more,
.ui-crs__for-more {
  flex: none;
  margin-left: 8px;
  color: var(--ui-crs-muted);
  font-variant-numeric: tabular-nums;
}
.ui-crs__quote-name {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-crs-text);
  white-space: nowrap;
}
.ui-crs__quote-name .ui-crs__mark {
  transform: scale(0.8);
  margin: 0 -1px 0 -3.5px;
}
.ui-crs__quote-text {
  overflow: hidden;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-crs-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crs__head {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.ui-crs__from {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-crs-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: color 160ms ease;
}
.ui-crs__tag {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-crs-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crs-text);
}
.ui-crs__needs {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-crs-wait-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crs-wait-fg);
}
.ui-crs__at {
  flex: none;
  margin-left: auto;
  padding-left: 12px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-faint);
  font-variant-numeric: tabular-nums;
}
.ui-crs__text {
  display: -webkit-box;
  overflow: hidden;
  overflow-wrap: anywhere;
  color: var(--ui-crs-text);
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  transition: color 160ms ease;
}
.ui-crs__msg:hover .ui-crs__text,
.ui-crs__msg[data-selected] .ui-crs__text {
  color: var(--ui-crs-ink);
}
.ui-crs__msg[data-selected] .ui-crs__text {
  -webkit-line-clamp: unset;
}
.ui-crs__files {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding-top: 1px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-crs-text);
}
.ui-crs__file {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  max-width: 100%;
  height: 24px;
  padding: 0 8px 0 7px;
  border-radius: 7px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-shadow);
  transition:
    box-shadow 140ms ease,
    color 140ms ease;
}
.ui-crs__file:hover {
  box-shadow: var(--ui-crs-shadow-hover);
  color: var(--ui-crs-ink);
}
.ui-crs__file:active {
  transform: scale(0.98);
}
.ui-crs__file > svg {
  flex: none;
  color: var(--ui-crs-muted);
}
.ui-crs__preview {
  position: absolute;
  inset: 0;
  z-index: 10;
  border-radius: inherit;
  display: grid;
  place-items: center;
  padding: 24px 16px;
  background: var(--ui-crs-scrim);
  animation: ui-crs-fade 180ms ease both;
}
.ui-crs__window {
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  width: min(100%, 560px);
  max-height: min(100%, 440px);
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-pop);
  animation: ui-crs-pop 260ms var(--ui-crs-ease) both;
}
.ui-crs__window-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 12px 12px 14px;
  box-shadow: 0 0.5px 0 var(--ui-crs-line);
}
.ui-crs__window-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-crs-well);
  color: var(--ui-crs-muted);
}
.ui-crs__window-icon svg {
  width: 14px;
  height: 14px;
}
.ui-crs__window-title {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-crs__window-name {
  display: -webkit-box;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-crs-ink);
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-crs__window-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-muted);
  white-space: pre;
}
.ui-crs__window-meta .ui-crs__mark {
  transform: scale(0.8);
  margin: 0 -1px 0 -2px;
}
.ui-crs__preview-close {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-crs-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-crs__preview-close:hover {
  background: var(--ui-crs-fill);
  color: var(--ui-crs-ink);
}
.ui-crs__preview-close svg {
  width: 16px;
  height: 16px;
}
.ui-crs__window-body {
  min-height: 0;
  overflow: auto;
  padding: 12px 14px 14px;
  outline: none;
  overscroll-behavior: contain;
}
.ui-crs__window-empty {
  margin: 0;
  padding: 20px 0;
  color: var(--ui-crs-muted);
  text-align: center;
}
.ui-crs__doc {
  margin: 0;
  font: inherit;
  color: var(--ui-crs-text);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-crs__doc p {
  margin: 0;
}
.ui-crs__doc-h {
  margin-bottom: 4px !important;
  font-size: 14px;
  font-weight: 600;
  color: var(--ui-crs-ink);
}
.ui-crs__doc[data-code] {
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 12px;
  line-height: 19px;
}
.ui-crs__sheet {
  min-width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
}
.ui-crs__sheet th {
  padding: 0 10px 6px 0;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-crs-muted);
  text-align: left;
  white-space: nowrap;
}
.ui-crs__sheet td {
  padding: 7px 10px 7px 0;
  white-space: nowrap;
  color: var(--ui-crs-text);
  box-shadow: inset 0 0.5px 0 var(--ui-crs-line);
}
.ui-crs__sheet td:first-child {
  font-weight: 500;
  color: var(--ui-crs-ink);
}
.ui-crs__tree {
  display: grid;
  gap: 2px;
  margin: 0;
  padding: 0;
  list-style: none;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 12px;
}
.ui-crs__tree li {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 26px;
  color: var(--ui-crs-text);
}
.ui-crs__tree svg {
  flex: none;
  color: var(--ui-crs-muted);
}
.ui-crs__file-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crs__co {
  display: inline-flex;
  align-items: baseline;
  gap: 4px;
  white-space: nowrap;
}
.ui-crs__co-logo {
  display: inline-grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-shadow);
  align-self: center;
  transform: translateY(1px);
}
.ui-crs__co-logo > svg {
  width: 10px;
  height: 10px;
}
.ui-crs__msg[data-selected] {
  position: relative;
  z-index: 4;
}
.ui-crs__more {
  position: absolute;
  top: calc(100% - 2px);
  left: 34px;
  z-index: 5;
  width: min(calc(100% - 42px), 560px);
  pointer-events: none;
}
.ui-crs__more[data-open] {
  pointer-events: auto;
}
.ui-crs__card {
  display: grid;
  gap: 10px;
  padding: 10px 12px 12px;
  border-radius: 12px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-pop);
  cursor: default;
  scroll-margin-bottom: 28px;
  opacity: 0;
  transform: translateY(-4px) scale(0.98);
  transform-origin: 24px top;
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-crs-ease);
}
.ui-crs__more[data-open] .ui-crs__card {
  opacity: 1;
  transform: none;
}
.ui-crs__facts {
  display: flex;
  flex-wrap: wrap;
  gap: 6px 20px;
  margin: 0;
}
.ui-crs__facts > div {
  display: grid;
  gap: 0;
}
.ui-crs__facts dt {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-crs-muted);
}
.ui-crs__facts dd {
  margin: 0;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crs-ink);
  font-variant-numeric: tabular-nums;
}
.ui-crs__items {
  display: grid;
  gap: 2px;
  margin: 0;
  padding: 8px 0 0;
  list-style: none;
  border-top: 0.5px solid rgba(0, 0, 0, 0.06);
}
.ui-crs__facts:only-child,
.ui-crs__items:first-child {
  border-top: 0;
  padding-top: 0;
}
.ui-crs__item {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 26px;
}
.ui-crs__tile {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-shadow);
}
.ui-crs__tile > svg {
  width: 12px;
  height: 12px;
}
.ui-crs__tile-dot {
  width: 6px;
  height: 6px;
  border-radius: 2px;
  background: var(--ui-crs-faint);
}
.ui-crs__item-label {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-crs-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crs__item-detail {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-crs-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crs__shimmer {
  position: relative;
  justify-self: start;
  color: var(--ui-crs-muted);
}
.ui-crs__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-crs-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-crs-sweep 1.6s linear infinite;
  pointer-events: none;
}
.ui-crs__system {
  display: flex;
  align-items: center;
  min-width: 0;
  height: 30px;
  margin: 0 -8px;
  padding: 0 8px 0 34px;
  border-radius: 8px;
  outline: none;
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-crs__system-text {
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-faint);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crs__system-name {
  color: var(--ui-crs-muted);
}
.ui-crs__reply {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crs-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-crs__reply:hover {
  background: var(--ui-crs-fill);
  color: var(--ui-crs-ink);
}
.ui-crs__composer {
  position: relative;
  padding-top: 4px;
}
.ui-crs__write {
  position: relative;
  display: grid;
  gap: 8px;
  padding: 12px 10px 10px;
  border-radius: 16px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-shadow);
  cursor: text;
  transition: box-shadow 200ms ease;
}
.ui-crs__field {
  display: block;
  width: 100%;
  min-height: 40px;
  max-height: 120px;
  margin: 0;
  padding: 0 4px;
  border: 0;
  background: transparent;
  font: inherit;
  color: var(--ui-crs-strong);
  resize: none;
  outline: none;
  field-sizing: content;
  caret-color: var(--ui-crs-accent);
}
.ui-crs__field::placeholder {
  color: var(--ui-crs-faint);
}
.ui-crs__tools {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-crs__at-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 999px;
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-crs-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-crs__at-btn:hover {
  background: var(--ui-crs-fill);
  color: var(--ui-crs-ink);
}
.ui-crs__for {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-muted);
  white-space: nowrap;
}
.ui-crs__for-who {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: var(--ui-crs-text);
}
.ui-crs__for-who .ui-crs__mark {
  transform: scale(0.8);
  margin: 0 -2px;
}
.ui-crs__send {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-left: auto;
  border-radius: 999px;
  background: var(--ui-crs-solid);
  color: var(--ui-crs-on-solid);
  transition:
    background-color 200ms ease,
    transform 160ms var(--ui-crs-ease);
}
.ui-crs__send svg {
  width: 16px;
  height: 16px;
}
.ui-crs__send:disabled {
  background: var(--ui-crs-fill);
  color: var(--ui-crs-faint);
  cursor: default;
}
.ui-crs__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-crs__quote--draft {
  margin: 0;
}
.ui-crs__unreply {
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  margin-left: auto;
  border-radius: 5px;
  font-size: 14px;
  line-height: 1;
  color: var(--ui-crs-muted);
}
.ui-crs__unreply:hover {
  background: var(--ui-crs-fill);
  color: var(--ui-crs-ink);
}
.ui-crs__menu {
  position: absolute;
  bottom: calc(100% - 2px);
  left: 8px;
  z-index: 6;
  display: grid;
  gap: 1px;
  min-width: 220px;
  margin: 0;
  padding: 4px;
  list-style: none;
  border-radius: 10px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-pop);
  animation: ui-crs-fade 160ms ease both;
}
.ui-crs__option {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12.5px;
  color: var(--ui-crs-ink);
  cursor: pointer;
}
.ui-crs__option[aria-selected="true"] {
  background: var(--ui-crs-fill);
}
.ui-crs__option-model {
  margin-left: auto;
  font-size: 11.5px;
  color: var(--ui-crs-faint);
}
.ui-crs :is(.ui-crs__msg, .ui-crs__system)[data-fresh] {
  animation: ui-crs-in 420ms var(--ui-crs-ease) both;
}
.ui-crs__empty {
  padding: 20px 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crs-muted);
}
.ui-crs__new {
  position: absolute;
  bottom: 8px;
  left: 50%;
  z-index: 3;
  height: 26px;
  padding: 0 10px;
  border-radius: 13px;
  background: var(--ui-crs-card);
  box-shadow: var(--ui-crs-pop);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-crs-ink);
  transform: translateX(-50%);
  animation: ui-crs-fade 260ms ease both;
}
@container (max-width: 480px) {
  .ui-crs__at {
    padding-left: 8px;
  }
  .ui-crs__body {
    max-width: 100%;
  }
}
@media (pointer: coarse) {
  .ui-crs__tab {
    height: 34px;
  }
  .ui-crs__file {
    height: 30px;
    padding-inline: 10px 11px;
  }
  .ui-crs__reply {
    position: relative;
  }
  .ui-crs__reply::after {
    content: "";
    position: absolute;
    inset: -8px -4px;
  }
  .ui-crs :is(.ui-crs__at-btn, .ui-crs__send, .ui-crs__preview-close) {
    width: 34px;
    height: 34px;
  }
  .ui-crs__option {
    height: 40px;
  }
}
@keyframes ui-crs-in {
  from {
    opacity: 0;
    transform: translateY(6px);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-crs-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-crs-pop {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.98);
  }
}
@keyframes ui-crs-flash {
  0%,
  100% {
    box-shadow: 0 0 0 0 transparent;
  }
  20%,
  60% {
    box-shadow: 0 0 0 2px var(--ui-crs-focus);
  }
}
@keyframes ui-crs-pixel {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.2;
  }
}
@keyframes ui-crs-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-crs-pulse {
  50% {
    opacity: 0.35;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-crs *,
  .ui-crs *::before,
  .ui-crs *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-crs {
  --ui-crs-tray: #19191c;
  --ui-crs-card: #232326;
  --ui-crs-bubble: #2c2c30;
  --ui-crs-bubble-hover: #313136;
  --ui-crs-strong: #ededed;
  --ui-crs-ink: #ededed;
  --ui-crs-text: #a1a1a6;
  --ui-crs-muted: #7c7c82;
  --ui-crs-faint: #4a4a50;
  --ui-crs-pixel: #5c5c63;
  --ui-crs-fill: #34343a;
  --ui-crs-well: rgba(255, 255, 255, 0.05);
  --ui-crs-you: #232326;
  --ui-crs-you-line: #34343a;
  --ui-crs-line: #2e2e33;
  --ui-crs-scrim: rgba(25, 25, 28, 0.7);
  --ui-crs-accent: #4fb0fe;
  --ui-crs-shadow: 0 0 0 1px #2e2e33, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-crs-shadow-hover: 0 0 0 1px #3a3a40, 0 2px 6px -2px rgba(0, 0, 0, 0.5);
  --ui-crs-pop: 0 0 0 1px #34343a, 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-crs-shine: rgba(255, 255, 255, 0.95);
  --ui-crs-solid: #ededed;
  --ui-crs-on-solid: #171717;
  --ui-crs-wait-bg: #3a2814;
  --ui-crs-wait-fg: #ffb35c;
  --ui-crs-focus: rgba(77, 141, 255, 0.8);
}

.ui-st {
  --ui-st-tray: #f0f0f0;
  --ui-st-card: #ffffff;
  --ui-st-ink: #171717;
  --ui-st-text: #6b6b6b;
  --ui-st-muted: #8a8a8a;
  --ui-st-faint: #b8b8b8;
  --ui-st-line: #ececec;
  --ui-st-rail: #d4d4d8;
  --ui-st-hover: #e4e4e5;
  --ui-st-chip: #f5f5f5;
  --ui-st-accent: #4fb0fe;
  --ui-st-accent-bg: rgba(1, 144, 254, 0.08);
  --ui-st-amber: #e8b000;
  --ui-st-green: #1e8a4f;
  --ui-st-on-ink: #ffffff;
  --ui-st-focus: rgba(0, 96, 226, 0.7);
  --ui-st-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 460px;
  padding: 4px;
  overflow: hidden;
  border-radius: 20px;
  background: var(--ui-st-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-st-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-st *,
.ui-st *::before,
.ui-st *::after {
  box-sizing: border-box;
}
:where(.ui-st) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-st button:focus-visible {
  outline: 2px solid var(--ui-st-focus);
  outline-offset: 2px;
}
.ui-st ol,
.ui-st ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-st svg {
  display: block;
  flex: none;
}
.ui-st__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-st__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-st__head {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding: 14px 14px 12px 16px;
}
.ui-st__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-st-accent);
}
.ui-st[data-status="paused"] .ui-st__spark {
  color: var(--ui-st-amber);
}
.ui-st[data-status="done"] .ui-st__spark {
  color: var(--ui-st-green);
}
.ui-st__heading {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-st__title {
  text-align: start;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-st-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__sub {
  display: flex;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-st-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__dot {
  flex: none;
  margin: 0 6px;
  color: var(--ui-st-faint);
}
.ui-st__agent {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-st__count {
  flex: none;
  font-variant-numeric: tabular-nums;
}
.ui-st__state {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  height: 26px;
  padding: 0 10px;
  border-radius: 999px;
  background: var(--ui-st-chip);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-st-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-st__pulse {
  position: relative;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-st-accent);
}
.ui-st__pulse::after {
  content: "";
  position: absolute;
  inset: -3px;
  border-radius: 50%;
  background: var(--ui-st-accent);
  opacity: 0;
  animation: ui-st-pulse 1600ms ease-out infinite;
}
.ui-st__state[data-status="paused"] .ui-st__pulse {
  background: var(--ui-st-amber);
}
.ui-st__state[data-status="done"] .ui-st__pulse {
  background: var(--ui-st-green);
}
.ui-st__state:not([data-status="running"]) .ui-st__pulse::after {
  display: none;
}
.ui-st__icon-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--ui-st-muted);
  box-shadow: inset 0 0 0 1px var(--ui-st-line);
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-st__icon-btn:hover {
  color: var(--ui-st-ink);
  background: var(--ui-st-chip);
}
.ui-st__plan {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  padding: 10px 16px 14px !important;
  border-top: 1px solid var(--ui-st-line);
}
.ui-st__step {
  position: relative;
  padding: 6px 0;
  transition: opacity 240ms ease;
}
.ui-st__step[data-faded] {
  opacity: 0.4;
}
.ui-st__step:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 27px;
  bottom: -3px;
  left: 7.5px;
  width: 1px;
  background: var(--ui-st-rail);
}
.ui-st__step-row {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
}
.ui-st__step-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-st-faint);
}
.ui-st__step-icon[data-status="done"] {
  color: var(--ui-st-ink);
  animation: ui-st-pop 360ms var(--ui-st-ease) both;
}
.ui-st__step-icon[data-status="active"] {
  color: var(--ui-st-accent);
}
.ui-st__step-icon[data-status="active"] svg {
  animation: ui-st-spin 900ms linear infinite;
}
.ui-st__step-title {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow: hidden;
  color: var(--ui-st-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-st__step[data-status="done"] .ui-st__step-title {
  color: var(--ui-st-text);
}
.ui-st__step[data-status="pending"] .ui-st__step-title {
  color: var(--ui-st-muted);
}
.ui-st[data-status="running"]
  .ui-st__step[data-status="active"]
  .ui-st__step-title {
  background: linear-gradient(
      90deg,
      var(--ui-st-ink) 0%,
      var(--ui-st-ink) 40%,
      var(--ui-st-faint) 50%,
      var(--ui-st-ink) 60%,
      var(--ui-st-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-st-shimmer 2200ms linear infinite;
}
.ui-st__step[data-status="active"] .ui-st__step-title {
  font-weight: 500;
}
.ui-st__step-time {
  flex: none;
  font-size: 12.5px;
  color: var(--ui-st-faint);
  font-variant-numeric: tabular-nums;
}
.ui-st__note {
  display: flex;
  align-items: flex-start;
  gap: 6px;
  margin: 6px 0 2px 28px;
  padding: 6px 10px 6px 8px;
  border-radius: 10px;
  background: var(--ui-st-chip);
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-st-ink);
}
.ui-st__note > svg {
  margin-top: 3px;
  color: var(--ui-st-muted);
}
.ui-st__note-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-st__note-tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 3px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-st-accent);
  white-space: nowrap;
}
.ui-st__note[data-landed] {
  animation: ui-st-land 1400ms ease both;
}
.ui-st__queue {
  padding: 12px 8px 0;
}
.ui-st__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 4px 8px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-st-muted);
}
.ui-st__label span {
  display: grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-st-hover);
  color: var(--ui-st-text);
  font-variant-numeric: tabular-nums;
}
.ui-st__queued {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
}
.ui-st__chip {
  position: relative;
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 36px;
  padding: 4px 4px 4px 12px;
  border-radius: 12px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-st-ink);
}
.ui-st__chip::before {
  content: "";
  position: absolute;
  top: 9px;
  bottom: 9px;
  left: 0;
  width: 3px;
  border-radius: 0 3px 3px 0;
  background: var(--ui-st-accent);
}
.ui-st__chip-text {
  flex: 1;
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
  font-size: 13px;
  line-height: 18px;
}
.ui-st__chip-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-st-text);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-st__chip-btn:hover {
  background: var(--ui-st-accent-bg);
  color: var(--ui-st-accent);
}
.ui-st__chip-x {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-st-faint);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-st__chip-x:hover {
  background: var(--ui-st-chip);
  color: var(--ui-st-ink);
}
.ui-st__compose {
  padding: 10px 8px 8px;
}
.ui-st__field {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  min-height: 42px;
  padding: 5px 5px 5px 14px;
  border-radius: 14px;
  background: var(--ui-st-card);
  box-shadow:
    0 0 0 1px var(--ui-st-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  cursor: text;
  transition: box-shadow 160ms ease;
}
.ui-st__field:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-st-rail),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-st__field textarea {
  flex: 1;
  min-width: 0;
  height: 20px;
  margin: 6px 0;
  padding: 0;
  border: 0;
  outline: none;
  background: none;
  font: inherit;
  color: var(--ui-st-ink);
  resize: none;
}
.ui-st__field textarea::placeholder {
  color: var(--ui-st-muted);
}
.ui-st__field textarea:focus-visible {
  outline: none;
}
.ui-st__send {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 10px;
  background: var(--ui-st-ink);
  color: var(--ui-st-on-ink);
  transition:
    opacity 160ms ease,
    transform 160ms ease;
}
.ui-st__send:disabled {
  opacity: 0.16;
  cursor: default;
}
.ui-st__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-st__hint {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 14px;
  margin: 8px 6px 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-st-muted);
}
.ui-st__hint > span {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  white-space: nowrap;
}
.ui-st kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-st-card);
  box-shadow: 0 0 0 1px var(--ui-st-line);
  font: inherit;
  font-size: 10.5px;
  color: var(--ui-st-text);
}
.ui-st__compose[data-disabled] .ui-st__field {
  opacity: 0.6;
  cursor: default;
}
@keyframes ui-st-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-st-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-st-pulse {
  from {
    opacity: 0.45;
    transform: scale(0.6);
  }
  to {
    opacity: 0;
    transform: scale(1.8);
  }
}
@keyframes ui-st-shimmer {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-st-land {
  0%,
  30% {
    background-color: var(--ui-st-accent-bg);
    box-shadow: inset 0 0 0 1px var(--ui-st-accent-bg);
  }
}
@container (max-width: 380px) {
  .ui-st__head {
    display: grid;
    grid-template-columns: auto minmax(0, 1fr) auto;
    column-gap: 12px;
    row-gap: 8px;
  }
  .ui-st__spark {
    grid-row: 1;
    align-self: center;
  }
  .ui-st__heading {
    grid-column: 2;
    grid-row: 1;
  }
  .ui-st__state {
    grid-column: 2;
    grid-row: 2;
    justify-self: start;
  }
  .ui-st__head > .ui-st__icon-btn {
    grid-column: 3;
    grid-row: 1;
  }
  .ui-st__head {
    padding-left: 14px;
  }
  .ui-st__plan {
    padding-left: 14px;
    padding-right: 14px;
  }
}
@media (pointer: coarse) {
  .ui-st__icon-btn,
  .ui-st__send {
    width: 36px;
    height: 36px;
  }
  .ui-st__chip-btn,
  .ui-st__chip-x {
    height: 32px;
  }
  .ui-st__chip-x {
    width: 32px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-st *,
  .ui-st *::before,
  .ui-st *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-st[data-status="running"]
    .ui-st__step[data-status="active"]
    .ui-st__step-title {
    background: none;
    color: var(--ui-st-ink);
  }
}
:where(.dark, [data-theme="dark"]) .ui-st {
  --ui-st-tray: #111113;
  --ui-st-card: #19191b;
  --ui-st-ink: #ededed;
  --ui-st-text: #a1a1a1;
  --ui-st-muted: #8b8b92;
  --ui-st-faint: #5c5c63;
  --ui-st-line: #2a2a2e;
  --ui-st-rail: #3a3a40;
  --ui-st-hover: #2a2a2e;
  --ui-st-chip: #232326;
  --ui-st-accent: #4fb0fe;
  --ui-st-accent-bg: rgba(79, 176, 254, 0.14);
  --ui-st-amber: #e6c24d;
  --ui-st-green: #5fc88a;
  --ui-st-on-ink: #19191b;
  --ui-st-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-st__step-icon[data-status="done"] path {
  stroke: #19191b;
}

.ui-cw {
  --ui-cw-tray: #f0f0f0;
  --ui-cw-card: #ffffff;
  --ui-cw-line: #ececec;
  --ui-cw-ink: #171717;
  --ui-cw-text: #404040;
  --ui-cw-muted: #8f8f8f;
  --ui-cw-well: #f4f4f5;
  --ui-cw-free: #ededf0;
  --ui-cw-c1: #26262b;
  --ui-cw-c2: #8d8d95;
  --ui-cw-c3: #c4c4ca;
  --ui-cw-c4: #4fb0fe;
  --ui-cw-c5: #a9d9ff;
  --ui-cw-c6: #5f5f66;
  --ui-cw-warn: #b25e00;
  --ui-cw-warn-bg: rgba(232, 176, 0, 0.14);
  --ui-cw-full: #c4320a;
  --ui-cw-full-bg: rgba(240, 68, 56, 0.1);
  --ui-cw-ok: #1e8a4f;
  --ui-cw-ok-bg: rgba(95, 200, 138, 0.11);
  --ui-cw-focus: rgba(0, 96, 226, 0.7);
  --ui-cw-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 360px;
  min-width: 0;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cw-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cw-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-cw *,
.ui-cw *::before,
.ui-cw *::after {
  box-sizing: border-box;
}
:where(.ui-cw) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-cw button:focus-visible {
  outline: 2px solid var(--ui-cw-focus);
  outline-offset: 2px;
}
.ui-cw svg {
  display: block;
  flex: none;
}
.ui-cw b {
  font-weight: 500;
  color: var(--ui-cw-ink);
}
.ui-cw ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-cw__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-cw__card {
  position: relative;
  padding: 12px 14px 8px;
  border-radius: 16px;
  background: var(--ui-cw-card);
  box-shadow:
    0 0 0 1px var(--ui-cw-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-cw__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 22px;
}
.ui-cw__title {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__model {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  max-width: 62%;
  height: 20px;
  padding: 0 7px 0 6px;
  border-radius: 5px;
  background: var(--ui-cw-well);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11px;
  line-height: 20px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
}
.ui-cw__model > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__model-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-cw__model-icon > * {
  width: 12px;
  height: 12px;
}
.ui-cw__figure {
  display: flex;
  align-items: baseline;
  gap: 7px;
  margin-top: 8px;
}
.ui-cw__big {
  font-size: 24px;
  font-weight: 600;
  line-height: 30px;
  letter-spacing: -0.02em;
  color: var(--ui-cw-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cw__of {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__pill {
  align-self: baseline;
  flex: none;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  font-variant-numeric: tabular-nums;
  transition: color 300ms ease;
}
.ui-cw[data-level="warn"] .ui-cw__pill {
  color: var(--ui-cw-warn);
}
.ui-cw[data-level="full"] .ui-cw__pill {
  color: var(--ui-cw-full);
}
.ui-cw__field {
  display: grid;
  grid-template-columns: repeat(var(--ui-cw-cols), minmax(0, 1fr));
  gap: 2px;
  margin-top: 10px;
}
.ui-cw__cell {
  aspect-ratio: 1;
  border-radius: 26%;
  background: var(--ui-cw-color);
  transition:
    background-color 380ms ease,
    opacity 220ms ease,
    transform 300ms var(--ui-cw-ease);
  transition-delay: calc(var(--i) * 2ms), 0ms, 0ms;
}
.ui-cw__cell[data-free] {
  background: var(--ui-cw-free);
}
.ui-cw__field[data-hot] .ui-cw__cell:not([data-on], [data-free]) {
  opacity: 0.22;
}
.ui-cw__cell[data-on] {
  transform: scale(1.12);
}
.ui-cw__cell[data-busy] {
  animation: ui-cw-wave 900ms ease-in-out infinite;
  animation-delay: calc(var(--i) * 15ms);
}
.ui-cw__parts {
  margin-top: 8px !important;
}
.ui-cw__part {
  margin: 0 -8px;
  padding: 0 8px;
  border-radius: 10px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-cw__part[data-hot] {
  background: var(--ui-cw-well);
}
.ui-cw__part[data-dim] {
  opacity: 0.55;
}
.ui-cw__row {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 30px;
}
.ui-cw__main {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 9px;
  min-width: 0;
  height: 30px;
  border-radius: 8px;
}
.ui-cw__swatch {
  flex: none;
  width: 7px;
  height: 7px;
  border-radius: 26%;
}
.ui-cw__label {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 3px;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__label-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__value {
  flex: none;
  min-width: 52px;
  text-align: right;
  color: var(--ui-cw-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cw__open {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-cw-muted);
}
.ui-cw__chevron {
  transition: transform 300ms var(--ui-cw-ease);
}
.ui-cw__open[data-open] .ui-cw__chevron {
  transform: rotate(180deg);
}
.ui-cw__compact {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 22px;
  margin-right: -10px;
  padding: 0 6px 0 5px;
  border-radius: 7px;
  font-size: 12px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-cw__compact:hover:not(:disabled) {
  background: var(--ui-cw-line);
  color: var(--ui-cw-ink);
}
.ui-cw__compact:disabled {
  cursor: default;
  opacity: 0.5;
}
.ui-cw__compact[data-busy] {
  opacity: 1;
  color: var(--ui-cw-ink);
}
.ui-cw__compact[data-done] {
  opacity: 1;
  color: var(--ui-cw-ok);
}
.ui-cw__compact[data-leaving] {
  animation: ui-cw-leave 400ms var(--ui-cw-ease) both;
}
.ui-cw__compact-icon {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
  animation: ui-cw-swap-in 300ms ease both;
}
.ui-cw__compact-text {
  animation: ui-cw-swap-in 300ms ease both;
}
.ui-cw__spinner {
  width: 12px;
  height: 12px;
  border: 1.5px solid var(--ui-cw-line);
  border-top-color: var(--ui-cw-ink);
  border-radius: 50%;
  animation: ui-cw-spin 700ms linear infinite;
}
.ui-cw__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-cw-ease),
    opacity 240ms ease;
}
.ui-cw__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-cw-ease),
    opacity 320ms ease 80ms;
}
.ui-cw__fold--item {
  transition-duration: 240ms, 180ms;
}
.ui-cw__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-cw__items {
  padding: 0 0 8px 17px !important;
}
.ui-cw__item {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 28px;
  font-size: 12.5px;
}
.ui-cw__item-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  color: var(--ui-cw-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cw__item-value {
  flex: none;
  color: var(--ui-cw-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cw__remove {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 7px;
  color: var(--ui-cw-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-cw__remove:hover {
  background: var(--ui-cw-full-bg);
  color: var(--ui-cw-full);
}
.ui-cw__empty {
  height: 28px;
  font-size: 12.5px;
  line-height: 28px;
  color: var(--ui-cw-muted);
}
.ui-cw__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 38px;
  padding: 4px 4px 0 10px;
}
.ui-cw__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-cw-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-cw__hot {
  display: flex;
  min-width: 0;
}
.ui-cw__hot > b {
  min-width: 32px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__hot > span {
  flex: none;
  white-space: pre;
}
.ui-cw__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cw__swap {
  display: grid;
  min-width: 0;
}
.ui-cw__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-cw-swap-in 320ms ease both;
}
.ui-cw__swap-item[data-out] {
  animation: ui-cw-swap-out 220ms ease both;
}
.ui-cw__swap-item[data-tone="ok"] {
  color: var(--ui-cw-ok);
}
.ui-cw__swap-item[data-tone="ok"] b {
  color: inherit;
}
.ui-cw__action {
  display: inline-flex;
  flex: 0 1 auto;
  align-items: center;
  min-width: 0;
  max-width: 50%;
  gap: 4px;
  height: 26px;
  padding: 0 6px 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-cw-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-cw__action:hover {
  background: var(--ui-cw-card);
  color: var(--ui-cw-ink);
}
.ui-cw__action svg {
  transition: transform 220ms var(--ui-cw-ease);
}
.ui-cw__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-cw-leave {
  to {
    opacity: 0;
    filter: blur(3px);
    transform: scale(0.92);
  }
}
@keyframes ui-cw-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cw-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-cw-wave {
  0%,
  100% {
    opacity: 1;
    transform: none;
  }
  50% {
    opacity: 0.28;
    transform: scale(0.72);
  }
}
@keyframes ui-cw-spin {
  to {
    transform: rotate(360deg);
  }
}
@container (max-width: 310px) {
  .ui-cw__model {
    max-width: 42%;
  }
  .ui-cw__field {
    grid-template-columns: repeat(var(--ui-cw-cols-narrow), minmax(0, 1fr));
  }
  .ui-cw__compact {
    padding: 0 6px;
  }
  .ui-cw__compact-text {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-cw__row {
    min-height: 38px;
  }
  .ui-cw__main {
    height: 38px;
  }
  .ui-cw__compact {
    height: 30px;
    padding: 0 9px 0 7px;
  }
  .ui-cw__item {
    height: 34px;
  }
  .ui-cw__remove {
    width: 30px;
    height: 30px;
  }
  .ui-cw__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cw *,
  .ui-cw *::before,
  .ui-cw *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cw {
  --ui-cw-tray: #111113;
  --ui-cw-card: #19191b;
  --ui-cw-line: #2a2a2e;
  --ui-cw-ink: #ededed;
  --ui-cw-text: #c8c8cc;
  --ui-cw-muted: #8b8b92;
  --ui-cw-well: #222225;
  --ui-cw-free: #2a2a2e;
  --ui-cw-c1: #e4e4e7;
  --ui-cw-c2: #8a8a92;
  --ui-cw-c3: #55555c;
  --ui-cw-c4: #4fb0fe;
  --ui-cw-c5: #90cdfe;
  --ui-cw-warn: #e6c24d;
  --ui-cw-full: #ff8a7a;
  --ui-cw-ok: #7dcf9f;
  --ui-cw-focus: rgba(77, 141, 255, 0.8);
}

.ui-lss {
  --ui-lss-gap: 16px;
  --ui-lss-stream-w: 640px;
  --ui-lss-side-w: 360px;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-lss / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  letter-spacing: -0.006em;
  line-height: 20px;
  -webkit-font-smoothing: antialiased;
}
.ui-lss *,
.ui-lss *::before,
.ui-lss *::after {
  box-sizing: border-box;
}
.ui-lss__grid {
  display: grid;
  grid-template-columns: minmax(0, var(--ui-lss-stream-w)) var(--ui-lss-side-w);
  justify-content: center;
  align-items: stretch;
  gap: var(--ui-lss-gap);
  min-width: 0;
}
.ui-lss__main,
.ui-lss__side {
  min-width: 0;
}
.ui-lss__side {
  display: grid;
  gap: var(--ui-lss-gap);
  align-content: start;
}
.ui-lss__side > * {
  width: 100%;
  max-width: none;
}
.ui-lss__main {
  position: relative;
  min-height: 360px;
}
.ui-lss__main > .ui-crs {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
}
.ui-lss .ui-crs__panel {
  display: flex;
  flex: 1;
  flex-direction: column;
  min-height: 0;
}
.ui-lss .ui-crs__scroll {
  flex: 1;
  min-height: 0;
  height: auto !important;
  max-height: none !important;
}
.ui-lss .ui-crs__top {
  padding-bottom: 10px;
}
.ui-lss .ui-crs__stream {
  padding-top: 26px;
}
@container ui-lss (max-width: 860px) {
  .ui-lss__grid {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-lss__main > .ui-crs {
    position: static;
  }
  .ui-lss .ui-crs__scroll {
    flex: none;
    height: var(--ui-lss-stream-h) !important;
  }
}

.ls-demo {
  width: 100%;
  min-width: 0;
  padding: 40px 24px;
}
:is(.stage:has(> .stage__look > .ls-demo), .stage:has(> .ls-demo)) {
  align-items: start;
}
.ls-demo__frame {
  width: 100%;
  position: relative;
}
.ls-demo__canvas {
  transform-origin: 0 0;
  padding-bottom: 6px;
  position: absolute;
  top: 0;
  left: 0;
}
.card__preview .ls-demo {
  padding: 60px 16px 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask: linear-gradient(#000 80%, #0000 99%);
  mask: linear-gradient(#000 80%, #0000 99%);
}
.ls-demo {
  --ls-demo-memory: #ee3e9e9e;
}
:where(.dark, [data-theme="dark"]) .ls-demo {
  --ls-demo-memory: #f06db5;
}
`;export{n as default};
