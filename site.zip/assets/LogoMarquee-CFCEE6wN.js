const n=`.ui-lm {
  --ui-lm-h: 28px;
  --ui-lm-g: var(--ui-lm-gap, 56px);
  --ui-lm-row-gap: 20px;
  --ui-lm-fade: min(14%, 120px);
  --ui-lm-muted: #9a9a9a;
  --ui-lm-ink: #171717;
  --ui-lm-label: #8f8f8f;
  --ui-lm-dim: 0.75;
  --ui-lm-focus: rgba(0, 96, 226, 0.7);
  --ui-lm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  container-type: inline-size;
  display: grid;
  gap: var(--ui-lm-row-gap);
  width: 100%;
  min-width: 0;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  -webkit-font-smoothing: antialiased;
}
/* Narrow containers (phones): smaller logos, tighter gaps */
@container (max-width: 520px) {
  .ui-lm__row,
  .ui-lm__wrap {
    --ui-lm-h: 22px;
    --ui-lm-g: calc(var(--ui-lm-gap, 56px) * 0.62);
  }
}

.ui-lm__row {
  overflow: hidden;
  /* Vertical page scroll stays native; horizontal swipes scrub the strip */
  touch-action: pan-y;
  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
  -webkit-mask-image: linear-gradient(
    90deg,
    transparent,
    #000 var(--ui-lm-fade),
    #000 calc(100% - var(--ui-lm-fade)),
    transparent
  );
  mask-image: linear-gradient(
    90deg,
    transparent,
    #000 var(--ui-lm-fade),
    #000 calc(100% - var(--ui-lm-fade)),
    transparent
  );
  /* Room for focus rings so they aren't clipped */
  padding-block: 6px;
}
.ui-lm__row[data-dragging] {
  cursor: grabbing;
}
.ui-lm__track {
  display: flex;
  width: max-content;
  will-change: transform;
}
.ui-lm__set,
.ui-lm__wrap {
  display: flex;
  align-items: center;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-lm__set {
  flex: none;
}
/* Every logo carries its gap on the right, so one set's width is exactly the wrap distance */
.ui-lm__item {
  flex: none;
  margin-inline-end: var(--ui-lm-g);
}

.ui-lm__link {
  display: flex;
  align-items: center;
  gap: calc(var(--ui-lm-h) * 0.32);
  border-radius: 8px;
  color: var(--ui-lm-muted);
  text-decoration: none;
  transition:
    color 260ms var(--ui-lm-ease),
    opacity 260ms var(--ui-lm-ease),
    filter 260ms var(--ui-lm-ease);
  -webkit-user-drag: none;
}
.ui-lm[data-labels="below"] .ui-lm__link {
  flex-direction: column;
  gap: 8px;
}
.ui-lm:focus-visible {
  outline: 2px solid var(--ui-lm-focus);
  outline-offset: -2px;
}
.ui-lm__link:focus-visible {
  outline: 2px solid var(--ui-lm-focus);
  outline-offset: 2px;
}

/* Consistent optical height: every mark fills the same box, nudged by its own scale */
.ui-lm__mark {
  display: grid;
  place-items: center;
  height: var(--ui-lm-h);
  transition: color 260ms var(--ui-lm-ease);
}
.ui-lm__mark > svg,
.ui-lm__mark > img {
  display: block;
  height: calc(var(--ui-lm-h) * var(--ui-lm-scale, 1));
  width: auto;
  max-width: calc(var(--ui-lm-h) * 5);
  pointer-events: none;
}
.ui-lm__name {
  /* A long company name ends in an ellipsis; the full name is in the title */
  max-width: calc(var(--ui-lm-h) * 9);
  overflow: hidden;
  font-size: calc(var(--ui-lm-h) * 0.68);
  font-weight: 600;
  letter-spacing: -0.025em;
  line-height: 1.15;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-lm__tile {
  display: grid;
  place-items: center;
  width: var(--ui-lm-h);
  height: var(--ui-lm-h);
  border-radius: calc(var(--ui-lm-h) * 0.26);
  background: color-mix(in srgb, currentColor 14%, transparent);
  font-size: calc(var(--ui-lm-h) * 0.5);
  font-weight: 600;
  line-height: 1;
}
.ui-lm[data-labels="below"] .ui-lm__name {
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0;
  color: var(--ui-lm-label);
}
.ui-lm__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
}

/* Grayscale: muted marks, images without colour – the hovered logo lifts to its brand colour */
.ui-lm[data-grayscale] .ui-lm__mark > img {
  filter: grayscale(1);
  opacity: 0.6;
  transition:
    filter 260ms var(--ui-lm-ease),
    opacity 260ms var(--ui-lm-ease);
}
.ui-lm:not([data-grayscale]) .ui-lm__mark {
  color: var(--ui-lm-brand, var(--ui-lm-ink));
}
.ui-lm:not([data-grayscale]) .ui-lm__link {
  color: var(--ui-lm-ink);
}
@media (hover: hover) {
  .ui-lm__link:hover,
  .ui-lm__link:focus-visible {
    color: var(--ui-lm-ink);
  }
  .ui-lm[data-grayscale] .ui-lm__link:hover .ui-lm__mark,
  .ui-lm[data-grayscale] .ui-lm__link:focus-visible .ui-lm__mark {
    color: var(--ui-lm-brand, var(--ui-lm-ink));
  }
  .ui-lm[data-grayscale] .ui-lm__link:hover img {
    filter: none;
    opacity: 1;
  }
  /* Full colour: the others step back a little while one is hovered */
  .ui-lm:not([data-grayscale])
    .ui-lm__set:has(.ui-lm__link:hover)
    .ui-lm__link:not(:hover) {
    opacity: var(--ui-lm-dim);
  }
  /* No colour flicker under the pointer while scrubbing */
  .ui-lm[data-grayscale] .ui-lm__row[data-dragging] .ui-lm__link {
    color: var(--ui-lm-muted);
  }
  .ui-lm[data-grayscale] .ui-lm__row[data-dragging] .ui-lm__mark {
    color: inherit;
  }
}

/* Reduced motion: a static, centred, wrapping row */
.ui-lm__wrap {
  flex-wrap: wrap;
  justify-content: center;
  row-gap: calc(var(--ui-lm-g) * 0.5);
  padding-inline: 8px;
}
.ui-lm__wrap .ui-lm__item {
  margin-inline: calc(var(--ui-lm-g) * 0.5);
}

@media (hover: none) and (pointer: coarse) {
  /* Bigger touch targets for linked logos */
  a.ui-lm__link {
    min-height: 40px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-lm__link,
  .ui-lm__mark,
  .ui-lm__mark > img {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-lm {
  --ui-lm-muted: #7a7a82;
  --ui-lm-ink: #ededed;
  --ui-lm-label: #8b8b92;
  --ui-lm-focus: rgba(77, 141, 255, 0.8);
}

.logo-marquee-demo {
  -webkit-font-smoothing: antialiased;
  justify-items: center;
  gap: 22px;
  width: 100%;
  min-width: 0;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    sans-serif;
  display: grid;
}
.logo-marquee-demo__caption {
  color: #8f8f8f;
  text-align: center;
  margin: 0;
  padding-inline: 16px;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  animation: 0.6s cubic-bezier(0.22, 1, 0.36, 1) 0.12s both logo-marquee-demo-in;
}
@keyframes logo-marquee-demo-in {
  0% {
    opacity: 0;
    filter: blur(2px);
    transform: translateY(4px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .logo-marquee-demo__caption {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .logo-marquee-demo__caption {
  color: #8b8b92;
}
.card__preview .logo-marquee-demo {
  zoom: 0.9;
  align-content: center;
  gap: 16px;
  padding-top: 24px;
  position: absolute;
  inset: 0;
}
.stage:has(.logo-marquee-demo) {
  height: 420px;
  padding-inline: 0;
}
@media (width<=760px) {
  .stage:has(.logo-marquee-demo) {
    height: 360px;
    min-height: 0;
    padding: 52px 0 24px;
  }
}
.logo-marquee-demo--clean {
  gap: 24px;
}
.logo-marquee-demo--clean .logo-marquee-demo__caption {
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: #00000073;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
}
:where(.dark, [data-theme="dark"])
  .logo-marquee-demo--clean
  .logo-marquee-demo__caption {
  color: #ffffff73;
}
.card__preview .logo-marquee-demo--clean {
  gap: 18px;
}
`;export{n as default};
