const n=`.ui-mp {
  --ui-mp-tray: #f0f0f0;
  --ui-mp-card: #ffffff;
  --ui-mp-line: #ececec;
  --ui-mp-ink: #171717;
  --ui-mp-text: #404040;
  --ui-mp-muted: #626873;
  --ui-mp-well: #f4f4f5;
  --ui-mp-hover: #ececee;
  --ui-mp-track: #dcdce0;
  --ui-mp-accent: #2f6bff;
  --ui-mp-red: #b42318;
  --ui-mp-red-bg: rgba(229, 72, 77, 0.1);
  --ui-mp-tag: #5f5f66;
  --ui-mp-tag-bg: rgba(110, 110, 120, 0.1);
  --ui-mp-focus: rgba(0, 96, 226, 0.7);
  --ui-mp-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 380px;
  min-width: 0;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-mp-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-mp-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mp *,
.ui-mp *::before,
.ui-mp *::after {
  box-sizing: border-box;
}
:where(.ui-mp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-mp) :is(p, h3, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
  font: inherit;
}
.ui-mp button:focus-visible {
  outline: 2px solid var(--ui-mp-focus);
  outline-offset: 2px;
}
.ui-mp :is(input, textarea):focus-visible {
  outline: none;
}
.ui-mp svg {
  display: block;
  flex: none;
}
.ui-mp b {
  font-weight: 500;
  color: var(--ui-mp-ink);
}
.ui-mp__card {
  border-radius: 16px;
  background: var(--ui-mp-card);
  box-shadow:
    0 0 0 1px var(--ui-mp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-mp__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mp-ease),
    opacity 220ms ease;
}
.ui-mp__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mp-ease),
    opacity 320ms ease 80ms;
}
.ui-mp__fold--row[data-leaving] {
  transition:
    grid-template-rows 320ms var(--ui-mp-ease),
    opacity 200ms ease,
    filter 200ms ease;
  filter: blur(2px);
}
.ui-mp__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mp__head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 48px;
  padding: 0 12px 0 14px;
}
.ui-mp__title {
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  color: var(--ui-mp-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mp__count {
  flex: none;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-mp-well);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  text-align: center;
  color: var(--ui-mp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-mp__switch {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  height: 28px;
  margin-left: auto;
  padding: 0 2px 0 8px;
  border-radius: 8px;
  font-size: 12.5px;
  color: var(--ui-mp-text);
  transition: background-color 160ms ease;
}
.ui-mp__switch:hover {
  background: var(--ui-mp-well);
}
.ui-mp__track {
  position: relative;
  width: 28px;
  height: 16px;
  border-radius: 8px;
  background: var(--ui-mp-track);
  transition: background-color 240ms ease;
}
.ui-mp__knob {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
  transition: transform 280ms var(--ui-mp-ease);
}
.ui-mp__switch[aria-checked="true"] .ui-mp__track {
  background: var(--ui-mp-ink);
}
.ui-mp__switch[aria-checked="true"] .ui-mp__knob {
  transform: translateX(12px);
}
.ui-mp__note {
  display: flex;
  gap: 8px;
  margin: 0 12px 10px !important;
  padding: 8px 10px;
  border-radius: 10px;
  background: var(--ui-mp-well);
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-mp-text);
}
.ui-mp__note svg {
  margin-top: 2px;
  color: var(--ui-mp-muted);
}
.ui-mp__filters {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: center;
  gap: 4px;
  padding: 0 10px 10px 12px;
}
.ui-mp__chips,
.ui-mp__search {
  grid-area: 1 / 1;
  transition:
    opacity 220ms ease,
    filter 220ms ease;
}
.ui-mp__chips {
  display: flex;
  gap: 4px;
  min-width: 0;
  margin: -2px -4px;
  padding: 2px 4px;
  overflow-x: auto;
  scrollbar-width: none;
  mask-image: linear-gradient(90deg, #000 calc(100% - 14px), transparent);
}
.ui-mp__chips::-webkit-scrollbar {
  display: none;
}
.ui-mp__chip {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 8px;
  border-radius: 8px;
  font-size: 12.5px;
  color: var(--ui-mp-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-mp__chip:hover {
  background: var(--ui-mp-well);
}
.ui-mp__chip[data-linked] {
  color: var(--ui-mp-ink);
}
.ui-mp__chip[data-linked]:not([aria-checked="true"]) {
  background: var(--ui-mp-well);
}
.ui-mp__chip[aria-checked="true"] {
  background: var(--ui-mp-well);
  color: var(--ui-mp-ink);
  box-shadow: inset 0 0 0 1px var(--ui-mp-line);
}
.ui-mp__chip-count {
  font-size: 11.5px;
  color: var(--ui-mp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-mp__search {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 2px 0 8px;
  border-radius: 8px;
  background: var(--ui-mp-well);
  color: var(--ui-mp-muted);
  opacity: 0;
  visibility: hidden;
}
.ui-mp__input {
  flex: 1;
  min-width: 0;
  height: 28px;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  font-size: 12.5px;
  color: var(--ui-mp-ink);
  outline: none;
}
.ui-mp__input::placeholder {
  color: var(--ui-mp-muted);
}
.ui-mp__search .ui-mp__icon {
  width: 24px;
  height: 24px;
}
.ui-mp__filters[data-searching] .ui-mp__chips {
  opacity: 0;
  filter: blur(2px);
}
.ui-mp__filters[data-searching] .ui-mp__search {
  grid-area: 1 / 1 / 2 / 3;
  opacity: 1;
  visibility: visible;
}
.ui-mp__filters[data-searching] .ui-mp__search-open {
  opacity: 0;
  visibility: hidden;
}
.ui-mp__search-open {
  grid-area: 1 / 2;
  transition:
    opacity 200ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-mp__list {
  max-height: var(--ui-mp-max);
  padding: 2px 6px 6px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--ui-mp-track) transparent;
  border-top: 1px solid var(--ui-mp-line);
  transition: opacity 300ms ease;
}
.ui-mp[data-off] .ui-mp__list,
.ui-mp[data-off] .ui-mp__filters {
  opacity: 0.5;
}
.ui-mp[data-off] .ui-mp__list:hover,
.ui-mp[data-off] .ui-mp__list:focus-within {
  opacity: 0.85;
}
.ui-mp__filters {
  transition: opacity 300ms ease;
}
.ui-mp__group {
  padding: 10px 8px 2px;
  font-size: 12px !important;
  font-weight: 500 !important;
  line-height: 18px !important;
  color: var(--ui-mp-muted);
}
.ui-mp__item {
  padding: 6px 8px 5px;
  border-radius: 10px;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-mp__item[data-hot],
.ui-mp__item[data-editing] {
  background: var(--ui-mp-well);
}
.ui-mp__text {
  color: var(--ui-mp-ink);
  overflow-wrap: anywhere;
  transition: color 240ms ease;
}
.ui-mp__item[data-paused] .ui-mp__text {
  color: var(--ui-mp-muted);
}
.ui-mp__meta {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 24px;
  font-size: 12px;
  color: var(--ui-mp-muted);
}
.ui-mp__source {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mp__tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-mp-tag-bg);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-mp-tag);
  opacity: 0;
  transform: scale(0.9);
  transition:
    opacity 220ms ease,
    transform 280ms var(--ui-mp-ease);
}
.ui-mp__tag:not([data-on]) {
  position: absolute;
  visibility: hidden;
}
.ui-mp__tag[data-on] {
  opacity: 1;
  transform: none;
  animation: ui-mp-in 280ms var(--ui-mp-ease) both;
}
.ui-mp__acts {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  margin: -1px -4px -1px auto;
  opacity: 0;
  transition: opacity 180ms ease;
}
.ui-mp__item:is([data-hot], :focus-within) .ui-mp__acts,
.ui-mp__acts--edit {
  opacity: 1;
}
.ui-mp__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  color: var(--ui-mp-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 200ms ease;
}
.ui-mp__icon:hover {
  background: var(--ui-mp-hover);
  color: var(--ui-mp-ink);
}
.ui-mp__icon--forget:hover {
  background: var(--ui-mp-red-bg);
  color: var(--ui-mp-red);
}
.ui-mp__icon-swap {
  display: grid;
  animation: ui-mp-in 260ms ease both;
}
.ui-mp__text-btn {
  display: inline-flex;
  align-items: center;
  height: 26px;
  padding: 0 9px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-mp-text);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 160ms ease;
}
.ui-mp__text-btn:hover {
  background: var(--ui-mp-hover);
  color: var(--ui-mp-ink);
}
.ui-mp__text-btn--main {
  background: var(--ui-mp-ink);
  color: var(--ui-mp-card);
}
.ui-mp__text-btn--main:hover {
  background: var(--ui-mp-ink);
  color: var(--ui-mp-card);
  opacity: 0.86;
}
.ui-mp__text-btn:disabled {
  cursor: default;
  opacity: 0.35;
}
.ui-mp__edit {
  display: block;
  width: 100%;
  min-height: 20px;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: var(--ui-mp-ink);
  resize: none;
  overflow: hidden;
  outline: none;
}
.ui-mp__edit::placeholder {
  color: var(--ui-mp-muted);
}
.ui-mp__item .ui-mp__edit:focus-visible {
  outline: none;
}
.ui-mp__empty {
  padding: 18px 8px 12px;
  font-size: 12.5px;
  text-align: center;
  color: var(--ui-mp-muted);
}
.ui-mp__bottom {
  padding: 4px 6px 6px;
  border-top: 1px solid var(--ui-mp-line);
}
.ui-mp__add {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px;
  border-radius: 10px;
  font-size: 13px;
  color: var(--ui-mp-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-mp__add:hover {
  background: var(--ui-mp-well);
  color: var(--ui-mp-ink);
}
.ui-mp__new {
  margin: 2px 0 0;
  padding: 8px 8px 6px;
  border-radius: 10px;
  background: var(--ui-mp-well);
}
.ui-mp__new-row {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 8px;
}
.ui-mp__cats {
  display: flex;
  flex: 1 1 auto;
  flex-wrap: wrap;
  gap: 4px;
  min-width: 0;
}
.ui-mp__cat {
  display: inline-flex;
  align-items: center;
  height: 24px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px;
  color: var(--ui-mp-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-mp__cat:hover {
  color: var(--ui-mp-ink);
}
.ui-mp__cat[aria-checked="true"] {
  background: var(--ui-mp-card);
  color: var(--ui-mp-ink);
  box-shadow:
    0 0 0 1px var(--ui-mp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-mp__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 38px;
  padding: 4px 4px 0 10px;
}
.ui-mp__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-mp-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mp__swap {
  display: grid;
  min-width: 0;
}
.ui-mp__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-mp-swap-in 320ms ease both;
}
.ui-mp__swap-item[data-out] {
  animation: ui-mp-swap-out 220ms ease both;
}
.ui-mp__forgot {
  display: flex;
  min-width: 0;
}
.ui-mp__flat {
  flex: none;
  white-space: pre;
}
.ui-mp__quote {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mp__action {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-mp-text);
  white-space: nowrap;
  animation: ui-mp-swap-in 300ms ease both;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-mp__action:hover {
  background: var(--ui-mp-card);
  color: var(--ui-mp-ink);
}
.ui-mp__action--undo {
  padding: 0 9px 0 7px;
  background: var(--ui-mp-card);
  color: var(--ui-mp-ink);
  box-shadow:
    0 0 0 1px var(--ui-mp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-mp__action:not(.ui-mp__action--undo) svg {
  transition: transform 220ms var(--ui-mp-ease);
}
.ui-mp__action:not(.ui-mp__action--undo):hover svg {
  transform: translateX(2px);
}
.ui-mp__source {
  display: flex;
}
.ui-mp__source-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mp__dot,
.ui-mp__date {
  flex: none;
  white-space: pre;
}
.ui-mp__text {
  white-space: pre-line;
  text-align: start;
}
.ui-mp__group,
.ui-mp__empty {
  overflow-wrap: anywhere;
}
.ui-mp__group {
  text-align: start;
}
.ui-mp__action:not(.ui-mp__action--undo) {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
}
.ui-mp__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mp__cat {
  max-width: 100%;
  white-space: nowrap;
}
.ui-mp__cat-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
@keyframes ui-mp-in {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
}
@keyframes ui-mp-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mp-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@container (max-width: 340px) {
  .ui-mp__chip-count {
    display: none;
  }
  .ui-mp__chip {
    padding: 0 7px;
  }
}
@container (max-width: 320px) {
  .ui-mp__switch-label {
    display: none;
  }
  .ui-mp__switch {
    padding: 0 2px;
  }
}
@media (pointer: coarse) {
  .ui-mp__acts {
    opacity: 1;
  }
  .ui-mp__icon {
    width: 32px;
    height: 32px;
  }
  .ui-mp__meta {
    min-height: 32px;
  }
  .ui-mp__chip,
  .ui-mp__text-btn {
    height: 32px;
  }
  .ui-mp__cat {
    height: 30px;
  }
  .ui-mp__switch,
  .ui-mp__add {
    height: 36px;
  }
  .ui-mp__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mp *,
  .ui-mp *::before,
  .ui-mp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mp {
  --ui-mp-tray: #111113;
  --ui-mp-card: #19191b;
  --ui-mp-line: #2a2a2e;
  --ui-mp-ink: #ededed;
  --ui-mp-text: #c8c8cc;
  --ui-mp-muted: #8b8b92;
  --ui-mp-well: #222225;
  --ui-mp-hover: #2c2c30;
  --ui-mp-track: #3a3a40;
  --ui-mp-red: #ff9b93;
  --ui-mp-red-bg: rgba(229, 72, 77, 0.16);
  --ui-mp-tag: #b4b4bb;
  --ui-mp-tag-bg: rgba(160, 160, 170, 0.14);
  --ui-mp-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-mp__knob {
  background: #19191b;
}
:where(.dark, [data-theme="dark"])
  .ui-mp__switch[aria-checked="false"]
  .ui-mp__knob {
  background: #8b8b92;
}
`;export{n as default};
