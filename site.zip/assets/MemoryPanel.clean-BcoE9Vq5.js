const n=`.ui-mpc {
  --ui-mpc-card: #ffffff;
  --ui-mpc-ink: rgba(0, 0, 0, 0.88);
  --ui-mpc-strong: #000000;
  --ui-mpc-text: rgba(0, 0, 0, 0.65);
  --ui-mpc-muted: rgba(0, 0, 0, 0.65);
  --ui-mpc-faint: rgba(0, 0, 0, 0.65);
  --ui-mpc-icon: rgba(0, 0, 0, 0.65);
  --ui-mpc-line: rgba(0, 0, 0, 0.06);
  --ui-mpc-wash: rgba(0, 0, 0, 0.03);
  --ui-mpc-fill: rgba(0, 0, 0, 0.06);
  --ui-mpc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-mpc-accent: rgba(0, 96, 226, 0.765);
  --ui-mpc-focus: rgba(0, 96, 226, 0.7);
  --ui-mpc-red: #bf383d;
  --ui-mpc-red-soft: rgba(229, 72, 77, 0.08);
  --ui-mpc-amber: #8d6000;
  --ui-mpc-amber-soft: rgba(232, 162, 12, 0.12);
  --ui-mpc-solid: rgba(0, 0, 0, 0.88);
  --ui-mpc-on-solid: #fcfcfc;
  --ui-mpc-knob: #ffffff;
  --ui-mpc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-mpc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 400px;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-mpc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mpc *,
.ui-mpc *::before,
.ui-mpc *::after {
  box-sizing: border-box;
}
:where(.ui-mpc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-mpc) :is(p, h3, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
  font: inherit;
}
.ui-mpc button:focus-visible {
  outline: 2px solid var(--ui-mpc-focus);
  outline-offset: 2px;
}
.ui-mpc :is(input, textarea):focus-visible {
  outline: none;
}
:where(.ui-mpc) svg {
  display: block;
  flex: none;
}
.ui-mpc b {
  font-weight: 500;
  color: var(--ui-mpc-ink);
}
.ui-mpc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-mpc__glyph[data-solid] {
  fill: currentColor;
  stroke: none;
}
.ui-mpc__card {
  border-radius: 10px;
  background: var(--ui-mpc-card);
  box-shadow: var(--ui-mpc-shadow);
}
.ui-mpc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mpc-ease),
    opacity 220ms ease;
}
.ui-mpc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mpc-ease),
    opacity 320ms ease 80ms;
}
.ui-mpc__fold--row[data-leaving] {
  transition:
    grid-template-rows 320ms var(--ui-mpc-ease),
    opacity 200ms ease,
    filter 200ms ease;
  filter: blur(2px);
}
.ui-mpc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mpc__head {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 0 16px;
}
.ui-mpc__title {
  min-width: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-mpc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mpc__count {
  flex: none;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-mpc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  text-align: center;
  color: var(--ui-mpc-text);
  font-variant-numeric: tabular-nums;
}
.ui-mpc__switch {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  height: 28px;
  margin-left: auto;
  padding: 0 6px 0 8px;
  border-radius: 6px;
  color: var(--ui-mpc-text);
  transition:
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__switch:hover {
  background: var(--ui-mpc-wash);
  color: var(--ui-mpc-ink);
}
.ui-mpc__track {
  position: relative;
  width: 26px;
  height: 16px;
  border-radius: 5px;
  background: var(--ui-mpc-fill-strong);
  transition: background-color 220ms ease;
}
.ui-mpc__knob {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 3.5px;
  background: var(--ui-mpc-knob);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06),
    0 1px 2px rgba(0, 0, 0, 0.16);
  transition: transform 260ms var(--ui-mpc-ease);
}
.ui-mpc__switch[aria-checked="true"] .ui-mpc__track {
  background: var(--ui-mpc-accent);
}
.ui-mpc__switch[aria-checked="true"] .ui-mpc__knob {
  transform: translateX(10px);
}
.ui-mpc__note {
  display: flex;
  gap: 8px;
  margin: 10px 12px 0 16px !important;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--ui-mpc-wash);
  font-size: 12px !important;
  line-height: 16px !important;
  color: var(--ui-mpc-text);
}
.ui-mpc__note .ui-mpc__glyph {
  color: var(--ui-mpc-icon);
}
.ui-mpc__filters {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  align-items: center;
  gap: 8px;
  padding: 12px 10px 12px 16px;
  border-bottom: 0.5px solid var(--ui-mpc-line);
  transition: opacity 300ms ease;
}
.ui-mpc__chips,
.ui-mpc__search {
  grid-area: 1 / 1;
  transition:
    opacity 220ms ease,
    filter 220ms ease;
}
.ui-mpc__chips {
  display: flex;
  gap: 4px;
  min-width: 0;
  margin: -3px;
  padding: 3px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-mpc__chips[data-more],
.ui-mpc__cats[data-more] {
  -webkit-mask-image: linear-gradient(
    90deg,
    #000 calc(100% - 24px),
    transparent
  );
  mask-image: linear-gradient(90deg, #000 calc(100% - 24px), transparent);
}
.ui-mpc__chips::-webkit-scrollbar {
  display: none;
}
.ui-mpc__chip {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mpc-line);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-mpc-text);
  white-space: nowrap;
  transition:
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__chip:hover {
  background: var(--ui-mpc-wash);
}
.ui-mpc__chip[data-linked] {
  color: var(--ui-mpc-ink);
}
.ui-mpc__chip[aria-checked="true"] {
  background: var(--ui-mpc-fill);
  color: var(--ui-mpc-ink);
}
.ui-mpc__chip-count {
  font-size: 12px;
  font-weight: 400;
  color: var(--ui-mpc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-mpc__chip[aria-checked="true"] .ui-mpc__chip-count {
  color: var(--ui-mpc-text);
}
.ui-mpc__search {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 2px 0 8px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mpc-line);
  background: var(--ui-mpc-wash);
  color: var(--ui-mpc-icon);
  opacity: 0;
  visibility: hidden;
}
.ui-mpc__input {
  flex: 1;
  min-width: 0;
  height: 28px;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  font-size: 13px;
  color: var(--ui-mpc-strong);
  caret-color: var(--ui-mpc-accent);
  outline: none;
}
.ui-mpc__input::placeholder {
  color: var(--ui-mpc-faint);
  opacity: 1;
}
.ui-mpc__search .ui-mpc__icon {
  width: 24px;
  height: 24px;
}
.ui-mpc__filters[data-searching] .ui-mpc__chips {
  opacity: 0;
  filter: blur(2px);
}
.ui-mpc__filters[data-searching] .ui-mpc__search {
  grid-area: 1 / 1 / 2 / 3;
  opacity: 1;
  visibility: visible;
}
.ui-mpc__filters[data-searching] .ui-mpc__search-open {
  opacity: 0;
  visibility: hidden;
}
.ui-mpc__search-open {
  grid-area: 1 / 2;
  transition:
    opacity 200ms ease,
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__list {
  max-height: var(--ui-mpc-max);
  padding: 2px 6px 6px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  scrollbar-color: var(--ui-mpc-fill-strong) transparent;
  transition: opacity 300ms ease;
}
.ui-mpc[data-off] .ui-mpc__list,
.ui-mpc[data-off] .ui-mpc__filters {
  opacity: 0.5;
}
.ui-mpc[data-off] .ui-mpc__list:hover,
.ui-mpc[data-off] .ui-mpc__list:focus-within {
  opacity: 0.85;
}
.ui-mpc__group {
  padding: 12px 10px 4px;
  font-size: 10px !important;
  font-weight: 500 !important;
  line-height: 16px !important;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-mpc-muted);
}
.ui-mpc__item {
  padding: 8px 10px 7px;
  border-radius: 8px;
  transition:
    background-color 90ms ease-out,
    opacity 220ms ease;
}
.ui-mpc__item[data-hot],
.ui-mpc__item[data-editing] {
  background: var(--ui-mpc-wash);
}
.ui-mpc__text {
  color: var(--ui-mpc-ink);
  overflow-wrap: anywhere;
  transition: color 240ms ease;
}
.ui-mpc__item[data-paused] .ui-mpc__text {
  color: var(--ui-mpc-muted);
}
.ui-mpc__meta {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 20px;
  margin-top: 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mpc-muted);
}
.ui-mpc__source {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mpc__dot {
  color: var(--ui-mpc-faint);
}
.ui-mpc__tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-mpc-amber-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-mpc-amber);
  opacity: 0;
  transform: scale(0.9);
  transition:
    opacity 220ms ease,
    transform 280ms var(--ui-mpc-ease);
}
.ui-mpc__tag:not([data-on]) {
  position: absolute;
  visibility: hidden;
}
.ui-mpc__tag[data-on] {
  opacity: 1;
  transform: none;
  animation: ui-mpc-in 280ms var(--ui-mpc-ease) both;
}
.ui-mpc__acts {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  margin: -4px -6px -4px auto;
  opacity: 0;
  transition: opacity 120ms ease;
}
.ui-mpc__item:is([data-hot], :focus-within) .ui-mpc__acts,
.ui-mpc__acts--edit {
  opacity: 1;
}
.ui-mpc__acts--edit {
  gap: 4px;
  margin-top: 4px;
  margin-right: -2px;
  margin-bottom: 0;
}
.ui-mpc__item[data-editing] {
  padding-bottom: 8px;
}
.ui-mpc__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-mpc-icon);
  transition:
    background-color 90ms ease,
    color 90ms ease,
    opacity 200ms ease;
}
.ui-mpc__icon:hover {
  background: var(--ui-mpc-wash);
  color: var(--ui-mpc-ink);
}
.ui-mpc__item .ui-mpc__icon:hover {
  background: var(--ui-mpc-fill);
}
.ui-mpc__item .ui-mpc__icon--forget:hover {
  background: var(--ui-mpc-red-soft);
  color: var(--ui-mpc-red);
}
.ui-mpc__icon-swap {
  display: grid;
  animation: ui-mpc-in 260ms ease both;
}
.ui-mpc__text-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-mpc-text);
  white-space: nowrap;
  transition:
    background-color 90ms ease,
    color 90ms ease,
    opacity 160ms ease;
}
.ui-mpc__text-btn:hover {
  background: var(--ui-mpc-fill);
  color: var(--ui-mpc-ink);
}
.ui-mpc__text-btn--main,
.ui-mpc__text-btn--main:hover {
  background: var(--ui-mpc-solid);
  color: var(--ui-mpc-on-solid);
}
.ui-mpc__text-btn--main:hover {
  opacity: 0.88;
}
.ui-mpc__text-btn:disabled {
  cursor: default;
  opacity: 0.3;
}
.ui-mpc__edit {
  display: block;
  width: 100%;
  min-height: 20px;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: var(--ui-mpc-strong);
  caret-color: var(--ui-mpc-accent);
  resize: none;
  overflow: hidden;
  outline: none;
}
.ui-mpc__edit::placeholder {
  color: var(--ui-mpc-faint);
  opacity: 1;
}
.ui-mpc__empty {
  padding: 20px 8px 14px;
  font-size: 13px;
  text-align: center;
  color: var(--ui-mpc-muted);
}
.ui-mpc__bottom {
  padding: 6px;
  border-top: 0.5px solid var(--ui-mpc-line);
}
.ui-mpc__add {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 10px;
  border-radius: 6px;
  color: var(--ui-mpc-text);
  transition:
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__add .ui-mpc__glyph {
  color: var(--ui-mpc-icon);
  transition: color 90ms ease;
}
.ui-mpc__add:hover {
  background: var(--ui-mpc-wash);
  color: var(--ui-mpc-ink);
}
.ui-mpc__add:hover .ui-mpc__glyph {
  color: var(--ui-mpc-ink);
}
.ui-mpc__new {
  padding: 6px 4px 2px 10px;
}
.ui-mpc__new-row {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-top: 10px;
}
.ui-mpc__cats {
  display: flex;
  flex: 1 1 auto;
  gap: 4px;
  min-width: 0;
  margin: -3px;
  padding: 3px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-mpc__cats::-webkit-scrollbar {
  display: none;
}
.ui-mpc__cat {
  display: inline-flex;
  flex: none;
  align-items: center;
  padding: 4px 8px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mpc-line);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-mpc-text);
  white-space: nowrap;
  transition:
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__cat:hover {
  background: var(--ui-mpc-wash);
}
.ui-mpc__cat[aria-checked="true"] {
  background: var(--ui-mpc-fill);
  color: var(--ui-mpc-ink);
}
.ui-mpc__new .ui-mpc__acts--edit {
  margin: 0;
}
.ui-mpc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 44px;
  padding: 0 8px 0 16px;
  border-top: 0.5px solid var(--ui-mpc-line);
}
.ui-mpc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mpc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mpc__swap {
  display: grid;
  min-width: 0;
}
.ui-mpc__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-mpc-swap-in 320ms ease both;
}
.ui-mpc__swap-item[data-out] {
  animation: ui-mpc-swap-out 220ms ease both;
}
.ui-mpc__forgot {
  display: flex;
  min-width: 0;
}
.ui-mpc__flat {
  flex: none;
  white-space: pre;
}
.ui-mpc__quote {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mpc__action {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 28px;
  padding: 0 6px 0 10px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-mpc-text);
  white-space: nowrap;
  animation: ui-mpc-swap-in 300ms ease both;
  transition:
    background-color 90ms ease,
    color 90ms ease;
}
.ui-mpc__action .ui-mpc__glyph {
  color: var(--ui-mpc-icon);
  transition:
    transform 220ms var(--ui-mpc-ease),
    color 90ms ease;
}
.ui-mpc__action:hover {
  background: var(--ui-mpc-wash);
  color: var(--ui-mpc-ink);
}
.ui-mpc__action:not(.ui-mpc__action--undo):hover .ui-mpc__glyph {
  transform: translateX(2px);
  color: var(--ui-mpc-ink);
}
.ui-mpc__action--undo {
  gap: 6px;
  padding: 0 10px 0 8px;
  background: var(--ui-mpc-card);
  box-shadow: var(--ui-mpc-shadow);
  color: var(--ui-mpc-strong);
}
.ui-mpc__action--undo:hover {
  background: #fafafa;
  color: var(--ui-mpc-strong);
}
.ui-mpc__source {
  display: flex;
}
.ui-mpc__source-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mpc__dot,
.ui-mpc__date {
  flex: none;
  white-space: pre;
}
.ui-mpc__text {
  white-space: pre-line;
  text-align: start;
}
.ui-mpc__group,
.ui-mpc__empty {
  overflow-wrap: anywhere;
}
.ui-mpc__group {
  text-align: start;
}
.ui-mpc__action:not(.ui-mpc__action--undo) {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
}
.ui-mpc__action-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-mpc__cat {
  max-width: 100%;
  white-space: nowrap;
}
.ui-mpc__cat-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
@keyframes ui-mpc-in {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
}
@keyframes ui-mpc-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mpc-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@container (max-width: 360px) {
  .ui-mpc__chip-count {
    display: none;
  }
  .ui-mpc__head {
    padding-left: 14px;
  }
  .ui-mpc__filters {
    padding-left: 14px;
  }
  .ui-mpc__foot {
    padding-left: 14px;
  }
  .ui-mpc__note {
    margin-left: 14px !important;
  }
}
@container (max-width: 320px) {
  .ui-mpc__switch-label {
    display: none;
  }
  .ui-mpc__switch {
    padding: 0 6px;
  }
  .ui-mpc__chip {
    padding: 4px 8px;
  }
}
@media (pointer: coarse) {
  .ui-mpc__acts {
    opacity: 1;
  }
  .ui-mpc__icon {
    width: 34px;
    height: 34px;
  }
  .ui-mpc__acts {
    margin-top: -7px;
    margin-bottom: -7px;
  }
  .ui-mpc__acts--edit {
    margin-top: 4px;
    margin-bottom: 0;
  }
  .ui-mpc__chip {
    padding: 6px 12px;
  }
  .ui-mpc__cat {
    padding: 5px 10px;
  }
  .ui-mpc__text-btn,
  .ui-mpc__action {
    height: 34px;
  }
  .ui-mpc__switch,
  .ui-mpc__add {
    height: 36px;
  }
  .ui-mpc__search,
  .ui-mpc__input {
    height: 34px;
  }
  .ui-mpc__foot {
    min-height: 52px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mpc *,
  .ui-mpc *::before,
  .ui-mpc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mpc {
  --ui-mpc-card: #1c1c1e;
  --ui-mpc-ink: rgba(255, 255, 255, 0.9);
  --ui-mpc-strong: #ffffff;
  --ui-mpc-text: rgba(255, 255, 255, 0.62);
  --ui-mpc-muted: rgba(255, 255, 255, 0.46);
  --ui-mpc-faint: rgba(255, 255, 255, 0.3);
  --ui-mpc-icon: rgba(255, 255, 255, 0.5);
  --ui-mpc-line: rgba(255, 255, 255, 0.08);
  --ui-mpc-wash: rgba(255, 255, 255, 0.04);
  --ui-mpc-fill: rgba(255, 255, 255, 0.08);
  --ui-mpc-fill-strong: rgba(255, 255, 255, 0.14);
  --ui-mpc-accent: #4d8dff;
  --ui-mpc-focus: rgba(77, 141, 255, 0.8);
  --ui-mpc-red: #ff8589;
  --ui-mpc-red-soft: rgba(229, 72, 77, 0.14);
  --ui-mpc-amber: #f0b93a;
  --ui-mpc-amber-soft: rgba(232, 162, 12, 0.14);
  --ui-mpc-solid: rgba(255, 255, 255, 0.9);
  --ui-mpc-on-solid: #1c1c1e;
  --ui-mpc-knob: #ffffff;
  --ui-mpc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-mpc__action--undo:hover {
  background: #232326;
}
:where(.dark, [data-theme="dark"])
  .ui-mpc__switch[aria-checked="false"]
  .ui-mpc__knob {
  background: rgba(255, 255, 255, 0.55);
}
`;export{n as default};
