const n=`.ui-ma {
  --ui-ma-card: #ffffff;
  --ui-ma-line: #ececec;
  --ui-ma-ink: #171717;
  --ui-ma-text: #404040;
  --ui-ma-muted: #626873;
  --ui-ma-well: #f4f4f5;
  --ui-ma-hover: rgba(23, 23, 23, 0.06);
  --ui-ma-accent: #2a5ee5;
  --ui-ma-accent-bg: rgba(47, 107, 255, 0.1);
  --ui-ma-ok: #18794e;
  --ui-ma-ok-bg: rgba(34, 160, 90, 0.11);
  --ui-ma-tip-bg: #171717;
  --ui-ma-tip-text: #ffffff;
  --ui-ma-focus: rgba(0, 96, 226, 0.7);
  --ui-ma-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  display: block;
  width: 100%;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ma-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ma *,
.ui-ma *::before,
.ui-ma *::after {
  box-sizing: border-box;
}
:where(.ui-ma) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ma button:focus-visible {
  outline: 2px solid var(--ui-ma-focus);
  outline-offset: 2px;
}
/* Typing in a field: no ring – the caret shows where you are, the edge only firms up a little */
.ui-ma .ui-ma__input:is(:focus, :focus-visible) {
  outline: none;
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-ma-ink) 14%, transparent);
}
.ui-ma svg {
  display: block;
  flex: none;
}
.ui-ma__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

/* ----- The bar: quiet until the message is hovered, something inside is focused or busy ----- */
/* Wraps to a second row in a very narrow message instead of running out of it */
.ui-ma__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 2px;
  min-height: 30px;
  transition: opacity 240ms ease;
}
.ui-ma[data-quiet] .ui-ma__bar {
  opacity: 0.6;
}
.ui-ma[data-quiet]:hover .ui-ma__bar,
.ui-ma[data-quiet]:focus-within .ui-ma__bar,
.ui-ma[data-quiet][data-active] .ui-ma__bar,
:where([data-ui-message]:hover, [data-ui-message]:focus-within)
  .ui-ma[data-quiet]
  .ui-ma__bar {
  opacity: 1;
}

.ui-ma__item {
  position: relative;
  display: inline-flex;
  flex: none;
}
.ui-ma__btn {
  display: grid;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 8px;
  color: var(--ui-ma-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ma__btn:hover {
  background: var(--ui-ma-hover);
  color: var(--ui-ma-ink);
}
.ui-ma__btn:active .ui-ma__icon {
  transform: scale(0.9);
}
.ui-ma__btn[aria-pressed="true"] {
  color: var(--ui-ma-ink);
}
.ui-ma__btn--speak[aria-pressed="true"] {
  color: var(--ui-ma-accent);
  background: var(--ui-ma-accent-bg);
}
.ui-ma__btn--copy[data-done] {
  color: var(--ui-ma-ok);
}

.ui-ma__icon {
  position: relative;
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  transition: transform 160ms var(--ui-ma-ease);
}
.ui-ma__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}

/* Two icons on top of each other – one blurs away while the other comes in */
.ui-ma__morph {
  display: grid;
}
.ui-ma__layer {
  grid-area: 1 / 1;
  display: grid;
  place-items: center;
  opacity: 0;
  transform: scale(0.6);
  filter: blur(2px);
  transition:
    opacity 200ms ease,
    transform 300ms var(--ui-ma-ease),
    filter 200ms ease;
}
.ui-ma__layer[data-on] {
  opacity: 1;
  transform: none;
  filter: none;
}
.ui-ma__layer--check .ui-ma__glyph {
  stroke-width: 2;
  stroke-dasharray: 22;
  stroke-dashoffset: 22;
}
.ui-ma__layer--check[data-on] .ui-ma__glyph {
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 340ms var(--ui-ma-ease) 60ms;
}

/* Regenerate spins once per press, and keeps going while busy */
.ui-ma__spin {
  display: grid;
  place-items: center;
}
.ui-ma__spin[data-spin] {
  animation: ui-ma-spin 640ms var(--ui-ma-ease);
}
.ui-ma__btn[data-busy] {
  color: var(--ui-ma-ink);
}
.ui-ma__btn[data-busy] .ui-ma__spin {
  animation: ui-ma-spin 900ms linear infinite;
}

/* Thumbs: down is the same glyph turned around; a vote fills it with a little pop */
.ui-ma__btn--down .ui-ma__glyph {
  transform: rotate(180deg);
}
.ui-ma__thumb .ui-ma__glyph {
  transition: fill 200ms ease;
}
.ui-ma__btn[aria-pressed="true"] .ui-ma__thumb {
  animation: ui-ma-pop 420ms var(--ui-ma-ease);
}
.ui-ma__btn[aria-pressed="true"] .ui-ma__thumb .ui-ma__glyph {
  fill: currentColor;
}

/* Read aloud: four bars that bounce while it plays */
.ui-ma__eq {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 2px;
  width: 16px;
  height: 16px;
}
.ui-ma__eq i {
  display: block;
  width: 2px;
  height: 12px;
  border-radius: 1px;
  background: currentColor;
  transform: scaleY(0.3);
}
.ui-ma__eq[data-on] i {
  animation: ui-ma-eq 900ms ease-in-out infinite;
}
.ui-ma__eq[data-on] i:nth-child(2) {
  animation-delay: -300ms;
  animation-duration: 760ms;
}
.ui-ma__eq[data-on] i:nth-child(3) {
  animation-delay: -520ms;
  animation-duration: 1000ms;
}
.ui-ma__eq[data-on] i:nth-child(4) {
  animation-delay: -140ms;
  animation-duration: 820ms;
}

/* ----- Tooltips: above the button, on hover after a beat, on keyboard focus, and briefly after Copy ----- */
.ui-ma__tip {
  position: absolute;
  bottom: calc(100% + 6px);
  left: 50%;
  z-index: 3;
  display: block;
  width: max-content;
  padding: 3px 7px;
  border-radius: 6px;
  background: var(--ui-ma-tip-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-ma-tip-text);
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transform: translate(-50%, 3px);
  transition:
    opacity 140ms ease,
    transform 200ms var(--ui-ma-ease);
}
.ui-ma__btn:focus-visible + .ui-ma__tip,
.ui-ma__item[data-flash] .ui-ma__tip {
  opacity: 1;
  transform: translate(-50%, 0);
  transition-delay: 0ms;
}
@media (hover: hover) {
  .ui-ma__item:hover .ui-ma__tip {
    opacity: 1;
    transform: translate(-50%, 0);
    transition-delay: 380ms;
  }
}

/* ----- Version switcher: unfolds next to Regenerate once there are two versions ----- */
.ui-ma__regen {
  display: inline-flex;
  align-items: center;
  flex: none;
}
.ui-ma__versions {
  display: grid;
  grid-template-columns: 0fr;
  opacity: 0;
  transition:
    grid-template-columns 420ms var(--ui-ma-ease),
    opacity 220ms ease;
}
.ui-ma__versions[data-open] {
  grid-template-columns: 1fr;
  opacity: 1;
  transition:
    grid-template-columns 420ms var(--ui-ma-ease),
    opacity 320ms ease 100ms;
}
.ui-ma__versions-clip {
  display: flex;
  align-items: center;
  min-width: 0;
  overflow: hidden;
  padding-right: 2px;
}
.ui-ma__step {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 30px;
  border-radius: 7px;
  color: var(--ui-ma-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    opacity 160ms ease;
}
.ui-ma__step .ui-ma__glyph {
  width: 14px;
  height: 14px;
}
.ui-ma__step:hover:not(:disabled) {
  background: var(--ui-ma-hover);
  color: var(--ui-ma-ink);
}
.ui-ma__step:disabled {
  cursor: default;
  opacity: 0.4;
}
.ui-ma__count {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  padding: 0 1px;
  font-size: 12px;
  color: var(--ui-ma-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-ma__count-now {
  color: var(--ui-ma-ink);
  font-weight: 500;
}

/* ----- Swapping text ----- */
.ui-ma__swap {
  display: inline-grid;
  min-width: 0;
}
.ui-ma__swap-item {
  grid-area: 1 / 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-width: 0;
  animation: ui-ma-in 300ms ease both;
}
.ui-ma__swap-item[data-out] {
  animation: ui-ma-out 220ms ease both;
}

/* ----- Feedback row: unfolds below the bar ----- */
.ui-ma__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-ma-ease),
    opacity 220ms ease;
}
.ui-ma__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-ma-ease),
    opacity 320ms ease 80ms;
}
.ui-ma__clip {
  min-height: 0;
  overflow: hidden;
  margin: -1px;
  padding: 1px;
} /* the 1px keeps the card's hairline from being clipped */
.ui-ma__panel {
  max-width: 440px;
  margin: 6px 0 0;
  padding: 12px 14px 14px;
  border-radius: 16px;
  background: var(--ui-ma-card);
  box-shadow:
    0 0 0 1px var(--ui-ma-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-ma__panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 24px;
}
.ui-ma__ask {
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ma-ink);
}
.ui-ma__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  margin-right: -4px;
  border-radius: 7px;
  color: var(--ui-ma-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ma__close .ui-ma__glyph {
  width: 14px;
  height: 14px;
}
.ui-ma__close:hover {
  background: var(--ui-ma-hover);
  color: var(--ui-ma-ink);
}
.ui-ma__chips {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px;
  margin-top: 6px;
}
.ui-ma__chip {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  height: 26px;
  padding: 0 9px;
  border-radius: 8px;
  background: var(--ui-ma-well);
  font-size: 12px;
  color: var(--ui-ma-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease,
    opacity 200ms ease;
}
.ui-ma__chip:hover:not(:disabled) {
  background: var(--ui-ma-line);
  color: var(--ui-ma-ink);
}
.ui-ma__chip[aria-pressed="true"],
.ui-ma__chip[aria-pressed="true"]:hover:not(:disabled) {
  background: var(--ui-ma-accent-bg);
  color: var(--ui-ma-accent);
}
.ui-ma__chip:disabled {
  cursor: default;
}
.ui-ma__chip:disabled:not([aria-pressed="true"]) {
  opacity: 0.45;
}
.ui-ma__send {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 58px;
  height: 26px;
  margin-left: auto;
  padding: 0 11px;
  border-radius: 8px;
  background: var(--ui-ma-ink);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-ma-card);
  white-space: nowrap;
  transition:
    background-color 220ms ease,
    color 220ms ease,
    opacity 200ms ease;
}
.ui-ma__send:disabled {
  cursor: default;
  opacity: 0.32;
}
.ui-ma__send[data-sent] {
  cursor: default;
  background: var(--ui-ma-ok-bg);
  color: var(--ui-ma-ok);
}
.ui-ma__send .ui-ma__glyph {
  width: 13px;
  height: 13px;
  stroke-width: 2.2;
}
.ui-ma__input {
  display: block;
  width: 100%;
  height: 30px;
  margin-top: 8px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: var(--ui-ma-well);
  font: inherit;
  font-size: 12.5px;
  color: var(--ui-ma-ink);
  outline: none;
}
.ui-ma__input::placeholder {
  color: var(--ui-ma-muted);
}

/* ----- Message text that crossfades between versions (MessageText) ----- */
.ui-ma-text {
  overflow: hidden;
  transition: height 360ms var(--ui-ma-ease, cubic-bezier(0.32, 0.72, 0.24, 1));
}
.ui-ma-text__swap {
  display: grid;
}
.ui-ma-text__inner {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-ma-text__swap > .ui-ma__swap-item {
  display: block;
  animation: ui-ma-text-in 420ms ease both;
}
.ui-ma-text__swap > .ui-ma__swap-item[data-out] {
  animation: ui-ma-out 260ms ease both;
}

@keyframes ui-ma-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-ma-text-in {
  from {
    opacity: 0;
    filter: blur(3px);
  }
}
@keyframes ui-ma-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-ma-spin {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-ma-pop {
  0% {
    transform: scale(1);
  }
  40% {
    transform: scale(1.28) rotate(-8deg);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-ma-eq {
  0%,
  100% {
    transform: scaleY(0.3);
  }
  50% {
    transform: scaleY(1);
  }
}

/* Narrow: the feedback row stacks its send button under the chips */
@container (max-width: 320px) {
  .ui-ma__send {
    flex-basis: 100%;
  }
}

@media (pointer: coarse) {
  .ui-ma[data-quiet] .ui-ma__bar {
    opacity: 1;
  }
  .ui-ma__btn {
    width: 38px;
    height: 38px;
    border-radius: 10px;
  }
  .ui-ma__step {
    width: 28px;
    height: 38px;
  }
  .ui-ma__chip,
  .ui-ma__send {
    height: 34px;
  }
  .ui-ma__close {
    width: 32px;
    height: 32px;
  }
  .ui-ma__input {
    height: 38px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-ma *,
  .ui-ma *::before,
  .ui-ma *::after,
  .ui-ma-text,
  .ui-ma-text * {
    animation: none !important;
    transition: none !important;
  }
  .ui-ma__eq[data-on] i:nth-child(odd) {
    transform: scaleY(0.8);
  }
  .ui-ma__eq[data-on] i:nth-child(even) {
    transform: scaleY(0.5);
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-ma {
  --ui-ma-card: #19191b;
  --ui-ma-line: #2a2a2e;
  --ui-ma-ink: #ededed;
  --ui-ma-text: #c8c8cc;
  --ui-ma-muted: #8b8b92;
  --ui-ma-well: #222225;
  --ui-ma-hover: rgba(255, 255, 255, 0.07);
  --ui-ma-accent: #8fb1ff;
  --ui-ma-accent-bg: rgba(79, 130, 255, 0.16);
  --ui-ma-ok: #6ee7a8;
  --ui-ma-ok-bg: rgba(110, 231, 168, 0.12);
  --ui-ma-tip-bg: #ededed;
  --ui-ma-tip-text: #171717;
  --ui-ma-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
