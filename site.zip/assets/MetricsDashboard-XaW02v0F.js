const n=`.ui-md {
  --ui-md-focus: rgba(0, 96, 226, 0.7);
  --ui-md-tray: #f0f0f0;
  --ui-md-card: #ffffff;
  --ui-md-card-line: #e5e5e5;
  --ui-md-line: #ececec;
  --ui-md-ink: #171717;
  --ui-md-text: #404040;
  --ui-md-muted: #8f8f8f;
  --ui-md-accent: #4fb0fe;
  --ui-md-area: rgba(1, 144, 254, 0.16);
  --ui-md-prev: #b5b5b5;
  --ui-md-good: #1e8a4f;
  --ui-md-good-bg: #e9f6ee;
  --ui-md-bad: #c21f78;
  --ui-md-bad-bg: #fdecf5;
  --ui-md-bar: #f3f6ff;
  --ui-md-chip: #ffffff;
  --ui-md-thumb: #ffffff;
  --ui-md-hover: rgba(0, 0, 0, 0.04);
  --ui-md-tip: #171717;
  --ui-md-tip-text: #ffffff;
  --ui-md-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-md-ease: cubic-bezier(0.65, 0, 0.25, 1);
  --ui-md-spring: cubic-bezier(0.34, 1.3, 0.64, 1);
  container-type: inline-size;
  padding: 0 6px 6px;
  border-radius: 24px;
  background: var(--ui-md-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-md-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-md *,
.ui-md *::before,
.ui-md *::after {
  box-sizing: border-box;
}
.ui-md button {
  font: inherit;
  color: inherit;
  margin: 0;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-md :focus-visible {
  outline: 2px solid var(--ui-md-focus);
  outline-offset: 2px;
}
.ui-md__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
}
.ui-md__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 8px 12px 14px;
}
.ui-md__heading {
  display: flex;
  flex-direction: column;
  gap: 1px;
  min-width: 0;
}
.ui-md__title,
.ui-md__site {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-md__title {
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
}
.ui-md__site {
  font-size: 12.5px;
  color: var(--ui-md-muted);
}
.ui-md__actions {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
}
.ui-md__range {
  position: relative;
  display: grid;
  grid-template-columns: repeat(3, 64px);
  padding: 3px;
  border-radius: 10px;
  background: rgba(0, 0, 0, 0.05);
}
.ui-md__range-thumb {
  position: absolute;
  top: 3px;
  left: 3px;
  width: 64px;
  height: calc(100% - 6px);
  border-radius: 7px;
  background: var(--ui-md-thumb);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  transition: transform 420ms var(--ui-md-spring);
}
.ui-md__range button {
  position: relative;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 7px;
  background: none;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-md-muted);
  transition: color 200ms ease;
}
.ui-md__range button[aria-checked="true"] {
  color: var(--ui-md-ink);
}
.ui-md__export {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 34px;
  padding: 0 12px 0 10px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-md-chip);
  box-shadow:
    0 0 0 1px var(--ui-md-card-line),
    var(--ui-md-shadow);
  font-size: 13px;
  font-weight: 500;
  transition: background-color 160ms ease;
}
.ui-md__export:hover {
  background: color-mix(in srgb, var(--ui-md-chip) 92%, var(--ui-md-ink));
}
.ui-md__export svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-md__card {
  overflow: hidden;
  border: 1px solid var(--ui-md-card-line);
  border-radius: 20px;
  background: var(--ui-md-card);
  box-shadow: var(--ui-md-shadow);
}
.ui-md__kpis {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 6px;
  margin-bottom: 6px;
}
.ui-md__kpi {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 4px;
  min-width: 0;
  padding: 14px 16px 13px;
  border: 1px solid var(--ui-md-card-line);
  border-radius: 16px;
  background: var(--ui-md-card);
  box-shadow: var(--ui-md-shadow);
  text-align: left;
  opacity: 0.5;
  filter: saturate(0.2);
  transition:
    opacity 260ms ease,
    filter 260ms ease,
    transform 260ms var(--ui-md-spring);
}
.ui-md__kpi:hover {
  opacity: 0.8;
}
.ui-md__kpi[aria-selected="true"] {
  opacity: 1;
  filter: none;
}
.ui-md__kpi:active {
  transform: scale(0.98);
}
.ui-md__kpi-label {
  font-size: 12.5px;
  color: var(--ui-md-text);
}
.ui-md__kpi-value {
  font-size: 24px;
  font-weight: 600;
  letter-spacing: -0.02em;
  line-height: 1.15;
  font-variant-numeric: tabular-nums;
}
.ui-md__delta {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  height: 20px;
  padding: 0 7px 0 4px;
  border-radius: 999px;
  background: var(--ui-md-bad-bg);
  font-size: 11.5px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-md-bad);
}
.ui-md__delta[data-good] {
  background: var(--ui-md-good-bg);
  color: var(--ui-md-good);
}
.ui-md__delta[data-none] {
  visibility: hidden;
}
.ui-md__delta svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-md__chart {
  padding: 16px 18px 12px;
  border-bottom: 1px solid var(--ui-md-line);
}
.ui-md__chart-head {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px 12px;
  margin-bottom: 14px;
}
.ui-md__legend {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-md-text);
}
.ui-md__legend i {
  width: 14px;
  height: 2.5px;
  border-radius: 2px;
  background: var(--ui-md-accent);
}
.ui-md__chart-tools {
  display: flex;
  align-items: center;
  gap: 14px;
}
.ui-md__kind {
  position: relative;
  display: grid;
  grid-template-columns: 30px 30px;
  padding: 2px;
  border-radius: 9px;
  background: rgba(0, 0, 0, 0.05);
}
.ui-md__kind-thumb {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 30px;
  height: calc(100% - 4px);
  border-radius: 7px;
  background: var(--ui-md-thumb);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  transition: transform 380ms var(--ui-md-spring);
}
.ui-md__kind button {
  position: relative;
  display: grid;
  place-items: center;
  height: 24px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ui-md-muted);
  transition: color 200ms ease;
}
.ui-md__kind button[aria-checked="true"] {
  color: var(--ui-md-ink);
}
.ui-md__kind svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-md__kind circle {
  fill: var(--ui-md-thumb);
}
.ui-md__compare {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  font-size: 12.5px;
  color: var(--ui-md-muted);
  cursor: pointer;
  user-select: none;
}
.ui-md__compare input {
  position: absolute;
  opacity: 0;
  pointer-events: none;
}
.ui-md__switch {
  position: relative;
  width: 28px;
  height: 16px;
  border-radius: 999px;
  background: #d9d9d9;
  transition: background-color 200ms ease;
}
.ui-md__switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
  transition: transform 300ms var(--ui-md-spring);
}
.ui-md__compare input:checked + .ui-md__switch {
  background: var(--ui-md-accent);
}
.ui-md__compare input:checked + .ui-md__switch::after {
  transform: translateX(12px);
}
.ui-md__compare input:focus-visible + .ui-md__switch {
  outline: 2px solid var(--ui-md-focus);
  outline-offset: 2px;
}
.ui-md__plot-wrap {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  grid-template-rows: 200px auto;
  column-gap: 10px;
}
.ui-md__axis {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin: -7px 0;
  font-size: 11px;
  font-variant-numeric: tabular-nums;
  text-align: right;
  color: var(--ui-md-muted);
}
.ui-md__plot {
  position: relative;
  outline-offset: 2px;
  border-radius: 4px;
  touch-action: pan-y;
}
.ui-md__plot svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.ui-md__grid {
  stroke: var(--ui-md-line);
  stroke-width: 1;
  stroke-dasharray: 3 4;
  vector-effect: non-scaling-stroke;
}
.ui-md__base {
  stroke: var(--ui-md-line);
  stroke-width: 1;
  vector-effect: non-scaling-stroke;
}
.ui-md__area-a {
  stop-color: var(--ui-md-area);
}
.ui-md__area-b {
  stop-color: var(--ui-md-area);
  stop-opacity: 0;
}
.ui-md__series {
  animation: ui-md-reveal 900ms var(--ui-md-ease) both;
}
.ui-md__line {
  fill: none;
  stroke: var(--ui-md-accent);
  stroke-width: 2;
  stroke-linejoin: round;
  stroke-linecap: round;
  vector-effect: non-scaling-stroke;
}
.ui-md__prev {
  fill: none;
  stroke: var(--ui-md-prev);
  stroke-width: 1.5;
  stroke-dasharray: 4 4;
  vector-effect: non-scaling-stroke;
  animation: ui-md-fade 400ms ease both;
}
.ui-md__dots {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-md__dots span {
  position: absolute;
  width: 7px;
  height: 7px;
  margin: -3.5px 0 0 -3.5px;
  border: 1.5px solid var(--ui-md-accent);
  border-radius: 50%;
  background: var(--ui-md-card);
  animation: ui-md-pop 360ms var(--ui-md-spring) both;
}
.ui-md__bars {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: flex-end;
  pointer-events: none;
}
.ui-md__bar-slot {
  flex: 1;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 2px;
  min-width: 0;
  height: 100%;
}
.ui-md__col {
  position: relative;
  width: 56%;
  max-width: 22px;
  border-radius: 5px 5px 2px 2px;
  background: linear-gradient(
    180deg,
    var(--ui-md-accent),
    color-mix(in srgb, var(--ui-md-accent) 55%, var(--ui-md-card))
  );
  transform-origin: bottom;
  animation: ui-md-grow 620ms var(--ui-md-ease) both;
  animation-delay: var(--d);
  transition: opacity 200ms ease;
}
.ui-md__bars[data-compare] .ui-md__col {
  width: 34%;
  max-width: 12px;
}
.ui-md__col--prev {
  background: var(--ui-md-prev);
  opacity: 0.55;
}
.ui-md__bars:has([data-active])
  .ui-md__bar-slot:not([data-active])
  .ui-md__col {
  opacity: 0.45;
}
.ui-md__guide {
  stroke: var(--ui-md-muted);
  stroke-width: 1;
  stroke-dasharray: 2 3;
  opacity: 0.6;
  vector-effect: non-scaling-stroke;
}
.ui-md__dot {
  position: absolute;
  width: 10px;
  height: 10px;
  margin: -5px 0 0 -5px;
  border: 2px solid var(--ui-md-card);
  border-radius: 50%;
  background: var(--ui-md-accent);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
  pointer-events: none;
}
.ui-md__dot--prev {
  background: var(--ui-md-prev);
}
.ui-md__tip {
  position: absolute;
  top: 6px;
  z-index: 2;
  display: grid;
  gap: 4px;
  width: max-content;
  min-width: 150px;
  max-width: 100%;
  padding: 9px 11px;
  border-radius: 10px;
  background: var(--ui-md-tip);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.16);
  font-size: 12px;
  color: var(--ui-md-tip-text);
  pointer-events: none;
}
.ui-md__tip[data-side="right"] {
  transform: translateX(var(--ui-md-dx, 14px));
}
.ui-md__tip[data-side="left"] {
  transform: translateX(var(--ui-md-dx, calc(-100% - 14px)));
}
.ui-md__tip-date {
  font-size: 11.5px;
  opacity: 0.6;
}
.ui-md__tip-row {
  display: flex;
  align-items: center;
  gap: 7px;
}
.ui-md__tip-row i {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ui-md-accent);
}
.ui-md__tip-row--prev i {
  background: var(--ui-md-prev);
}
.ui-md__tip-row b {
  margin-left: auto;
  padding-left: 12px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
.ui-md__dates {
  position: relative;
  grid-column: 2;
  height: 26px;
  font-size: 11px;
  color: var(--ui-md-muted);
}
.ui-md__dates span {
  position: absolute;
  top: 9px;
  transform: translateX(-50%);
  white-space: nowrap;
}
.ui-md__dates span[data-start] {
  transform: none;
}
.ui-md__dates span[data-end] {
  transform: translateX(-100%);
}
.ui-md__lists {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
}
.ui-md__list {
  min-width: 0;
  padding: 14px 12px 12px;
}
.ui-md__list + .ui-md__list {
  border-left: 1px solid var(--ui-md-line);
}
.ui-md__list-head {
  display: flex;
  justify-content: space-between;
  padding: 0 8px 8px;
  font-size: 12.5px;
  font-weight: 500;
}
.ui-md__list-head span + span {
  font-weight: 400;
  color: var(--ui-md-muted);
}
.ui-md__list ul {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 2px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-md__row {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 32px;
  padding: 6px 8px;
  font-size: 13px;
  line-height: 20px;
}
.ui-md__row-bar {
  position: absolute;
  inset: 0 auto 0 0;
  border-radius: 8px;
  background: var(--ui-md-bar);
  transition: width 600ms var(--ui-md-ease);
}
.ui-md__row-name {
  position: relative;
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow-wrap: anywhere;
  color: var(--ui-md-text);
}
.ui-md__row-value {
  position: relative;
  flex: none;
  font-variant-numeric: tabular-nums;
  color: var(--ui-md-ink);
}
.ui-md__empty {
  margin: 0;
  padding: 6px 8px 8px;
  font-size: 13px;
  color: var(--ui-md-muted);
}
.ui-md__nodata {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 13px;
  color: var(--ui-md-muted);
}
@keyframes ui-md-reveal {
  from {
    clip-path: inset(-10% 100% -10% 0);
  }
  to {
    clip-path: inset(-10% -1% -10% 0);
  }
}
@keyframes ui-md-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-md-pop {
  from {
    transform: scale(0);
  }
}
@keyframes ui-md-grow {
  from {
    transform: scaleY(0);
  }
}
@container (max-width: 640px) {
  .ui-md__kpis {
    grid-template-columns: 1fr 1fr;
  }
  .ui-md__lists {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-md__list + .ui-md__list {
    border-left: 0;
    border-top: 1px solid var(--ui-md-line);
  }
  .ui-md__compare {
    font-size: 0;
    gap: 0;
  }
  .ui-md__compare::after {
    content: "Compare";
    font-size: 12.5px;
    margin-left: 8px;
  }
}
@container (max-width: 460px) {
  .ui-md__bar {
    flex-wrap: wrap;
    padding: 12px 4px 12px 10px;
  }
  .ui-md__actions {
    width: 100%;
  }
  .ui-md__range {
    flex: 1;
    grid-template-columns: repeat(3, 1fr);
  }
  .ui-md__range-thumb {
    width: calc((100% - 6px) / 3);
  }
  .ui-md__kpi {
    padding: 12px 14px;
  }
  .ui-md__kpi-value {
    font-size: 20px;
  }
  .ui-md__chart {
    padding: 14px 12px 10px;
  }
  .ui-md__plot-wrap {
    grid-template-rows: 168px auto;
  }
  .ui-md__dates span:nth-child(even) {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-md__range button {
    height: 30px;
  }
  .ui-md__export {
    height: 36px;
  }
  .ui-md__kind {
    grid-template-columns: 34px 34px;
  }
  .ui-md__kind-thumb {
    width: 34px;
  }
  .ui-md__kind button {
    height: 32px;
  }
  .ui-md__compare {
    min-height: 36px;
  }
  .ui-md__switch {
    width: 36px;
    height: 20px;
  }
  .ui-md__switch::after {
    width: 16px;
    height: 16px;
  }
  .ui-md__compare input:checked + .ui-md__switch::after {
    transform: translateX(16px);
  }
  .ui-md__row {
    min-height: 36px;
    padding-block: 8px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-md__range-thumb,
  .ui-md__kind-thumb,
  .ui-md__kpi,
  .ui-md__row-bar,
  .ui-md__switch::after {
    transition: none;
  }
  .ui-md__series,
  .ui-md__prev,
  .ui-md__dots span,
  .ui-md__col {
    animation: none;
  }
}
.ui-md input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-md textarea:focus-visible,
.ui-md [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-md {
  --ui-md-focus: rgba(77, 141, 255, 0.8);
  --ui-md-tray: #161618;
  --ui-md-card: #232326;
  --ui-md-card-line: rgba(255, 255, 255, 0.08);
  --ui-md-line: rgba(255, 255, 255, 0.07);
  --ui-md-ink: #ededed;
  --ui-md-text: #c4c4c4;
  --ui-md-muted: #8f8f8f;
  --ui-md-accent: #4fb0fe;
  --ui-md-area: rgba(79, 176, 254, 0.2);
  --ui-md-prev: #5c5c61;
  --ui-md-good: #41bd74;
  --ui-md-good-bg: rgba(125, 207, 159, 0.14);
  --ui-md-bad: #ff6b5f;
  --ui-md-bad-bg: rgba(255, 107, 95, 0.14);
  --ui-md-bar: rgba(79, 176, 254, 0.12);
  --ui-md-chip: #2a2a2d;
  --ui-md-thumb: #313135;
  --ui-md-hover: rgba(255, 255, 255, 0.04);
  --ui-md-tip: #ededed;
  --ui-md-tip-text: #121213;
  --ui-md-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-md__range,
:where(.dark, [data-theme="dark"]) .ui-md__kind {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-md__switch {
  background: #3a3a3e;
}

.metrics-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.metrics-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.card__preview .metrics-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.metrics-demo[data-fit="card"] .metrics-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 40px;
  left: 24px;
}
.metrics-demo__frame {
  min-width: 0;
}
`;export{n as default};
