const n=`.ui-rca {
  --ui-rca-tray: #f0f0f0;
  --ui-rca-card: #ffffff;
  --ui-rca-strong: #171717;
  --ui-rca-ink: #171717;
  --ui-rca-text: #6b6b6b;
  --ui-rca-muted: #8a8a8a;
  --ui-rca-faint: #b5b5b5;
  --ui-rca-line: #ececec;
  --ui-rca-soft: #f4f4f4;
  --ui-rca-grid: #f0f0f0;
  --ui-rca-stroke: #8a8a8a;
  --ui-rca-area: rgba(23, 23, 23, 0.06);
  --ui-rca-dot: #525252;
  --ui-rca-cursor: #d4d4d4;
  --ui-rca-needs: #4fb0fe;
  --ui-rca-failed: #b25e00;
  --ui-rca-ok: #1e8a4f;
  --ui-rca-ok-bg: #e6f6ed;
  --ui-rca-primary: #171717;
  --ui-rca-primary-hover: #2e2e2e;
  --ui-rca-primary-ink: #ffffff;
  --ui-rca-hover-ring: #dcdcdc;
  --ui-rca-tip: #171717;
  --ui-rca-tip-text: #fafafa;
  --ui-rca-card-h: 96px;
  --ui-rca-focus-ring: rgba(47, 107, 255, 0.35);
  --ui-rca-focus: rgba(0, 96, 226, 0.7);
  --ui-rca-ring: 0 0 0 1px var(--ui-rca-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-rca-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-rca-tray);
  container: ui-rca / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-rca-text);
  -webkit-font-smoothing: antialiased;
  --ui-rca-dot-needs: #e6730e;
  --ui-rca-dot-failed: var(--ui-rca-failed);
}
.ui-rca *,
.ui-rca *::before,
.ui-rca *::after {
  box-sizing: border-box;
}
:where(.ui-rca) :where(h2, h3, p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-rca) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  cursor: pointer;
}
.ui-rca button:focus-visible {
  outline: 2px solid var(--ui-rca-focus);
  outline-offset: 2px;
}
.ui-rca__panel {
  padding: 16px 16px 12px;
  border-radius: 16px;
  background: var(--ui-rca-card);
  box-shadow: var(--ui-rca-ring);
}
.ui-rca__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px 16px;
}
.ui-rca__title {
  font-size: 15px;
  font-weight: 600;
  line-height: 22px;
  color: var(--ui-rca-strong);
}
.ui-rca__since {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 2px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-rca-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rca__pill {
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-rca-soft);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rca-text);
}
.ui-rca__counts {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 14px;
  min-width: 0;
  padding-top: 3px;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
}
.ui-rca__counts li {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.ui-rca__counts b {
  font-weight: 600;
  color: var(--ui-rca-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rca__kind {
  flex: none;
  width: 15px;
  height: 15px;
  color: var(--ui-rca-muted);
}
.ui-rca__chart {
  position: relative;
  height: 96px;
  margin-top: 14px;
  cursor: crosshair;
}
.ui-rca__chart svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.ui-rca__grid line {
  stroke: var(--ui-rca-grid);
  stroke-width: 1;
}
.ui-rca__line {
  fill: none;
  stroke: var(--ui-rca-stroke);
  stroke-width: 1.5;
  stroke-linejoin: round;
}
.ui-rca__cursor {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  margin-left: -0.5px;
  background: var(--ui-rca-cursor);
  pointer-events: none;
}
.ui-rca__frame {
  position: absolute;
  inset: 0;
  border-top: 1px solid var(--ui-rca-grid);
  border-bottom: 1px solid var(--ui-rca-grid);
  pointer-events: none;
}
.ui-rca__dot {
  position: absolute;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-rca-dot);
  box-shadow: 0 0 0 2px var(--ui-rca-card);
  transform: translate(-50%, -50%) scale(0);
  transition: transform 360ms var(--ui-rca-ease);
}
.ui-rca__dot[data-on] {
  transform: translate(-50%, -50%) scale(1);
}
@starting-style {
  .ui-rca__dot[data-on] {
    transform: translate(-50%, -50%) scale(0);
  }
}
.ui-rca__dot[data-hot] {
  transform: translate(-50%, -50%) scale(1.5);
}
.ui-rca__dot::after {
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 50%;
}
.ui-rca__dot[data-kind="needs"] {
  background: var(--ui-rca-dot-needs);
}
.ui-rca__dot[data-kind="failed"] {
  background: var(--ui-rca-dot-failed);
}
.ui-rca__tip {
  position: absolute;
  z-index: 2;
  max-width: 280px;
  overflow: hidden;
  margin-top: -12px;
  padding: 4px 9px;
  border-radius: 8px;
  background: var(--ui-rca-tip);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rca-tip-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  transform: translate(-50%, -100%);
  pointer-events: none;
  animation: ui-rca-pop 140ms ease both;
}
.ui-rca__tip[data-edge="start"] {
  transform: translate(-12px, -100%);
}
.ui-rca__tip[data-edge="end"] {
  transform: translate(calc(-100% + 12px), -100%);
}
.ui-rca__ends {
  display: flex;
  justify-content: space-between;
  margin-top: 4px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-rca-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rca__board {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 4px;
  align-items: stretch;
  margin-top: 4px;
}
.ui-rca__lane {
  min-width: 0;
}
.ui-rca__lane-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 38px;
  padding: 0 12px 0 10px;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rca-text);
}
.ui-rca__lane-head > span:first-child {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ui-rca__lane-head .ui-rca__kind {
  width: 20px;
}
.ui-rca__lane-n {
  display: grid;
  place-items: center;
  min-width: 22px;
  height: 20px;
  padding: 0 6px;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.06);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-rca-text);
  font-variant-numeric: tabular-nums;
}
.ui-rca__cards {
  display: grid;
  grid-auto-rows: var(--ui-rca-card-h);
  align-content: start;
  gap: 4px;
  min-height: calc(
    var(--ui-rca-limit) * var(--ui-rca-card-h) + (var(--ui-rca-limit) - 1) * 4px
  );
}
.ui-rca__card {
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 10px 12px 10px 10px;
  border-radius: 14px;
  background: var(--ui-rca-card);
  box-shadow: var(--ui-rca-ring);
  opacity: 0;
  filter: blur(2px);
  transform: translateY(4px);
  transition:
    opacity 320ms ease,
    filter 320ms ease,
    transform 420ms var(--ui-rca-ease),
    box-shadow 160ms ease;
}
.ui-rca__card[data-seen] {
  opacity: 1;
  filter: none;
  transform: none;
}
.ui-rca__card[data-hot] {
  box-shadow:
    0 0 0 1px var(--ui-rca-hover-ring),
    0 2px 6px rgba(0, 0, 0, 0.05);
}
.ui-rca__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 22px;
}
.ui-rca__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-rca-card);
  box-shadow: inset 0 0 0 1px var(--ui-rca-line);
  font-size: 10.5px;
  font-weight: 600;
  color: var(--ui-rca-ink);
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-rca__mark > svg {
  width: 12px;
  height: 12px;
}
.ui-rca__card[data-state="resolved"] .ui-rca__mark {
  background: var(--ui-rca-ok-bg);
  box-shadow: none;
  color: var(--ui-rca-ok);
}
.ui-rca__card-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-rca-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__card:is([data-state="resolved"], [data-state="undone"])
  .ui-rca__card-title {
  color: var(--ui-rca-muted);
}
.ui-rca__card-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 18px;
  padding-left: 28px;
}
.ui-rca__detail {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__card[data-kind="failed"][data-state="open"] .ui-rca__detail {
  color: var(--ui-rca-failed);
}
.ui-rca__tag {
  flex: none;
  padding: 0 6px;
  border-radius: 999px;
  background: var(--ui-rca-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rca-text);
  font-variant-numeric: tabular-nums;
}
.ui-rca__time {
  flex: none;
  font-size: 11.5px;
  color: var(--ui-rca-faint);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-rca__card-foot {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  height: 28px;
  margin-top: 6px;
}
.ui-rca__status {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-rca-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rca__state {
  padding: 0 8px;
  border-radius: 999px;
  background: var(--ui-rca-ok-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ui-rca-ok);
}
.ui-rca__state[data-off] {
  background: var(--ui-rca-soft);
  color: var(--ui-rca-text);
}
.ui-rca__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-rca-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-rca-ease),
    opacity 160ms ease;
}
.ui-rca__btn:hover:not(:disabled) {
  background: var(--ui-rca-soft);
  color: var(--ui-rca-ink);
}
.ui-rca__btn--main {
  background: var(--ui-rca-primary);
  color: var(--ui-rca-primary-ink);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.12);
}
.ui-rca__btn--main:hover:not(:disabled) {
  background: var(--ui-rca-primary-hover);
  color: var(--ui-rca-primary-ink);
}
.ui-rca__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-rca__btn:disabled {
  opacity: 0.7;
  cursor: default;
}
.ui-rca__spin {
  width: 11px;
  height: 11px;
  border: 1.5px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ui-rca-spin 700ms linear infinite;
}
.ui-rca__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-rca__cards {
  position: relative;
}
.ui-rca__empty {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 12px;
  color: var(--ui-rca-faint);
}
.ui-rca__card {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rca__card:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-rca-focus-ring),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rca__btn {
  flex: none;
}
.ui-rca__btn--main {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 70%;
}
.ui-rca__btn-label {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rca button:focus-visible {
  outline: 2px solid var(--ui-rca-focus);
  outline-offset: 2px;
}
@keyframes ui-rca-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-rca-spin {
  to {
    transform: rotate(360deg);
  }
}
@container ui-rca (max-width: 640px) {
  .ui-rca__board {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rca *,
  .ui-rca *::before,
  .ui-rca *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rca {
  --ui-rca-tray: #141416;
  --ui-rca-card: #1f1f22;
  --ui-rca-strong: #fafafa;
  --ui-rca-ink: #ededed;
  --ui-rca-text: #a1a1aa;
  --ui-rca-muted: #8a8a93;
  --ui-rca-faint: #5a5a62;
  --ui-rca-line: #2c2c31;
  --ui-rca-soft: #2a2a2e;
  --ui-rca-grid: #2a2a2e;
  --ui-rca-stroke: #8a8a93;
  --ui-rca-area: rgba(255, 255, 255, 0.07);
  --ui-rca-dot: #d4d4d8;
  --ui-rca-cursor: #45454c;
  --ui-rca-needs: #4fb0fe;
  --ui-rca-failed: #f2a15c;
  --ui-rca-ok: #5fc88a;
  --ui-rca-ok-bg: rgba(125, 207, 159, 0.14);
  --ui-rca-primary: #fafafa;
  --ui-rca-primary-hover: #e4e4e7;
  --ui-rca-primary-ink: #111113;
  --ui-rca-hover-ring: #3a3a40;
  --ui-rca-focus-ring: rgba(91, 154, 255, 0.45);
  --ui-rca-focus: rgba(77, 141, 255, 0.8);
  --ui-rca-tip: #fafafa;
  --ui-rca-tip-text: #111113;
  --ui-rca-ring: 0 0 0 1px var(--ui-rca-line), 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-rca-dot-needs: #f2a15c;
  --ui-rca-dot-failed: var(--ui-rca-failed);
}
:where(.dark, [data-theme="dark"]) .ui-rca__lane-n {
  background: rgba(255, 255, 255, 0.08);
}

.ui-ai {
  --ui-ai-tray: #f0f0f0;
  --ui-ai-card: #ffffff;
  --ui-ai-line: #ececec;
  --ui-ai-chip: #f5f5f5;
  --ui-ai-track: #e6e6e6;
  --ui-ai-ink: #171717;
  --ui-ai-text: #6b6b6b;
  --ui-ai-muted: #8a8a8a;
  --ui-ai-faint: #b8b8b8;
  --ui-ai-blue: #4fb0fe;
  --ui-ai-amber: #e8b000;
  --ui-ai-green: #1e8a4f;
  --ui-ai-red: #f04438;
  --ui-ai-brand-bg: #eaf1ff;
  --ui-ai-brand-fg: #2456d6;
  --ui-ai-warn-bg: #fff1e0;
  --ui-ai-warn-fg: #b25e00;
  --ui-ai-ok-bg: #e6f6ed;
  --ui-ai-ok-fg: #1e8a4f;
  --ui-ai-danger-bg: #fdecea;
  --ui-ai-danger-fg: #c4320a;
  --ui-ai-focus: rgba(0, 96, 226, 0.7);
  --ui-ai-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-ai-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-ai-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-ai *,
.ui-ai *::before,
.ui-ai *::after {
  box-sizing: border-box;
}
:where(.ui-ai) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-ai button:focus-visible {
  outline: 2px solid var(--ui-ai-focus);
  outline-offset: 2px;
}
.ui-ai ul,
.ui-ai ol {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ai svg {
  display: block;
  flex: none;
}
.ui-ai__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-ai__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 8px 8px 10px 14px;
}
.ui-ai__heading {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 14px;
  font-weight: 600;
  color: var(--ui-ai-ink);
  white-space: nowrap;
}
.ui-ai__crumb {
  flex: none;
  color: var(--ui-ai-muted);
  font-weight: 500;
}
.ui-ai__slash {
  flex: none;
  color: var(--ui-ai-faint);
  font-weight: 400;
}
.ui-ai__heading-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ai__tools {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
}
.ui-ai__action-label {
  max-width: 200px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ai__action {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 30px;
  padding: 0 12px 0 10px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ai-ink);
  transition: background-color 160ms ease;
}
.ui-ai__action:hover {
  background: var(--ui-ai-track);
}
.ui-ai__views {
  display: flex;
  flex: none;
  padding: 3px;
  border-radius: 12px;
  background: var(--ui-ai-track);
}
.ui-ai__view {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 12px;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ai-muted);
  transition:
    background-color 200ms ease,
    color 200ms ease,
    box-shadow 200ms ease;
}
.ui-ai__view:hover {
  color: var(--ui-ai-ink);
}
.ui-ai__view[aria-checked="true"] {
  background: var(--ui-ai-card);
  color: var(--ui-ai-ink);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
}
.ui-ai__lanes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 4px;
  align-items: start;
}
.ui-ai__lane {
  min-width: 0;
}
.ui-ai__lane-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 32px;
  padding: 0 10px;
}
.ui-ai__lane-spark {
  display: grid;
  color: var(--ui-ai-blue);
}
.ui-ai__lane[aria-label="Needs you"] .ui-ai__lane-spark {
  color: var(--ui-ai-amber);
}
.ui-ai__lane[aria-label="Done"] .ui-ai__lane-spark {
  color: var(--ui-ai-green);
}
.ui-ai__lane-name {
  overflow: hidden;
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-ai-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ai__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 6px;
  border-radius: 999px;
  background: var(--ui-ai-card);
  box-shadow: 0 0 0 1px var(--ui-ai-line);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-ai-text);
  font-variant-numeric: tabular-nums;
}
.ui-ai__cards {
  display: grid;
  gap: 4px;
}
.ui-ai__empty {
  padding: 18px 0 20px;
  border-radius: 16px;
  box-shadow: inset 0 0 0 1px var(--ui-ai-track);
  font-size: 13px;
  text-align: center;
  color: var(--ui-ai-muted);
}
.ui-ai__card[data-faded] {
  opacity: 0.4;
}
.ui-ai__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-ai-card);
  box-shadow:
    0 0 0 1px var(--ui-ai-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-ai__card:hover,
.ui-ai__card[data-open] {
  box-shadow:
    0 0 0 1px #e0e0e0,
    0 6px 16px -8px rgba(0, 0, 0, 0.14);
}
.ui-ai__card-main {
  display: grid;
  gap: 6px;
  width: 100%;
  padding: 14px 14px 12px;
  border-radius: 16px;
  container: ai-card / inline-size;
}
.ui-ai__title-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}
.ui-ai__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 20px;
  color: var(--ui-ai-blue);
  transition: color 300ms ease;
}
.ui-ai__card[data-status="waiting"] .ui-ai__spark {
  color: var(--ui-ai-amber);
}
.ui-ai__card[data-status="failed"] .ui-ai__spark {
  color: var(--ui-ai-red);
}
.ui-ai__card[data-status="done"] .ui-ai__spark {
  color: var(--ui-ai-green);
}
.ui-ai__title {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-ai-ink);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow-wrap: anywhere;
}
.ui-ai__desc {
  display: -webkit-box;
  padding-left: 26px;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-ai-text);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-ai__card[data-open] .ui-ai__title {
  white-space: normal;
}
.ui-ai__card[data-open] .ui-ai__desc {
  -webkit-line-clamp: unset;
}
.ui-ai__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  margin-top: 6px;
  padding-left: 26px;
}
.ui-ai__state {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 24px;
  padding: 0 10px 0 8px;
  border-radius: 999px;
  background: var(--ui-ai-brand-bg);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ai-brand-fg);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-ai__state[data-status="waiting"] {
  background: var(--ui-ai-warn-bg);
  color: var(--ui-ai-warn-fg);
}
.ui-ai__state[data-status="done"] {
  background: var(--ui-ai-ok-bg);
  color: var(--ui-ai-ok-fg);
}
.ui-ai__state[data-status="failed"] {
  background: var(--ui-ai-danger-bg);
  color: var(--ui-ai-danger-fg);
}
.ui-ai__state-word {
  min-width: 2.6em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: pre;
  margin-right: calc(0.28em - 6px);
}
.ui-ai__time {
  flex: none;
}
.ui-ai__state-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  color: currentColor;
  animation: ui-ai-pop 360ms var(--ui-ai-ease) both;
}
.ui-ai__state-icon[data-status="running"] svg {
  animation: ui-ai-spin 900ms linear infinite;
}
.ui-ai__meta {
  display: inline-flex;
  flex: none;
  align-items: center;
  font-size: 12.5px;
  color: var(--ui-ai-muted);
  font-variant-numeric: tabular-nums;
}
.ui-ai__meta > span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 9px;
}
.ui-ai__meta > span + span {
  border-left: 1px solid var(--ui-ai-line);
}
.ui-ai__meta > span:last-child {
  padding-right: 0;
}
.ui-ai__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 460ms var(--ui-ai-ease),
    opacity 240ms ease;
}
.ui-ai__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 460ms var(--ui-ai-ease),
    opacity 320ms ease 100ms;
}
.ui-ai__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-ai__more {
  margin: 0 14px;
  padding: 12px 0 14px;
  border-top: 1px solid var(--ui-ai-line);
}
.ui-ai__agent {
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ai-muted);
}
.ui-ai__steps {
  position: relative;
  display: grid;
  gap: 6px;
  margin-top: 8px !important;
  padding-left: 14px !important;
}
.ui-ai__steps li {
  position: relative;
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ai-text);
}
.ui-ai__steps li::before {
  content: "";
  position: absolute;
  top: 6px;
  left: -14px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-ai-faint);
}
.ui-ai__steps li:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 15px;
  bottom: -9px;
  left: -11.5px;
  width: 1px;
  background: var(--ui-ai-line);
}
.ui-ai__steps li[data-last]::before {
  background: var(--ui-ai-ink);
}
.ui-ai__steps li > span {
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-ai__steps time {
  flex: none;
  max-width: 45%;
  color: var(--ui-ai-muted);
  text-align: end;
}
.ui-ai__actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 12px;
}
.ui-ai__actions:empty {
  display: none;
}
.ui-ai__btn {
  display: inline-flex;
  align-items: center;
  height: 32px;
  padding: 0 14px;
  border-radius: 10px;
  background: var(--ui-ai-card);
  box-shadow:
    0 0 0 1px var(--ui-ai-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-ai-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-ai__btn:hover {
  background: var(--ui-ai-chip);
}
.ui-ai__btn--primary {
  background: var(--ui-ai-ink);
  box-shadow: none;
  color: var(--ui-ai-card);
}
.ui-ai__btn--primary:hover {
  background: var(--ui-ai-ink);
  opacity: 0.88;
}
.ui-ai[data-view="list"] .ui-ai__lanes {
  grid-template-columns: minmax(0, 1fr);
  gap: 8px;
}
.ui-ai__lanes {
  animation: ui-ai-in 320ms ease both;
}
@keyframes ui-ai-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-ai-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-ai-in {
  from {
    opacity: 0.4;
  }
}
@container (max-width: 620px) {
  .ui-ai__views {
    display: none;
  }
  .ui-ai__action {
    justify-content: center;
    width: 30px;
    padding: 0;
    background: var(--ui-ai-track);
  }
  .ui-ai__action-label {
    display: none;
  }
  .ui-ai .ui-ai__lanes {
    grid-template-columns: minmax(0, 1fr);
    gap: 8px;
  }
}
@container ai-card (max-width: 300px) {
  .ui-ai__desc,
  .ui-ai__foot {
    padding-left: 0;
  }
  .ui-ai__state:not([data-status="failed"]):not([data-bare])
    .ui-ai__state-word {
    display: none;
  }
}
@container (max-width: 360px) {
  .ui-ai__desc,
  .ui-ai__foot {
    padding-left: 0;
  }
  .ui-ai__title {
    white-space: normal;
  }
  .ui-ai__card:not([data-open]) .ui-ai__title {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
}
@media (pointer: coarse) {
  .ui-ai__view {
    height: 34px;
  }
  .ui-ai__btn {
    height: 40px;
    padding: 0 18px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ai *,
  .ui-ai *::before,
  .ui-ai *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ai {
  --ui-ai-tray: #111113;
  --ui-ai-card: #1c1c1f;
  --ui-ai-line: #2a2a2e;
  --ui-ai-chip: #26262a;
  --ui-ai-track: #1f1f22;
  --ui-ai-ink: #ededed;
  --ui-ai-text: #a1a1a6;
  --ui-ai-muted: #7c7c82;
  --ui-ai-faint: #4a4a50;
  --ui-ai-blue: #4fb0fe;
  --ui-ai-amber: #e6c24d;
  --ui-ai-green: #5fc88a;
  --ui-ai-red: #ff6b5f;
  --ui-ai-brand-bg: #16243f;
  --ui-ai-brand-fg: #8ab4ff;
  --ui-ai-warn-bg: #3a2610;
  --ui-ai-warn-fg: #ffb35c;
  --ui-ai-ok-bg: #123020;
  --ui-ai-ok-fg: #5fc88a;
  --ui-ai-danger-bg: #3b1c14;
  --ui-ai-danger-fg: #ff8a7a;
  --ui-ai-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ai__card:hover,
:where(.dark, [data-theme="dark"]) .ui-ai__card[data-open] {
  box-shadow:
    0 0 0 1px #34343a,
    0 6px 18px -8px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-ai__view[aria-checked="true"] {
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.4),
    0 0 0 1px rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"])
  .ui-ai__state-icon[data-status="failed"]
  path {
  stroke: var(--ui-ai-danger-bg);
}

.ui-al {
  --ui-al-tray: #f0f0f0;
  --ui-al-card: #ffffff;
  --ui-al-strong: #171717;
  --ui-al-ink: #171717;
  --ui-al-text: #6b6b6b;
  --ui-al-muted: #8a8a8a;
  --ui-al-faint: #b8b8b8;
  --ui-al-line: #ececec;
  --ui-al-rail: #c4c4c8;
  --ui-al-wash: #f6f6f6;
  --ui-al-fill: #ececec;
  --ui-al-done: #f2f2f3;
  --ui-al-solid: #171717;
  --ui-al-on-solid: #ffffff;
  --ui-al-run-bg: rgba(1, 144, 254, 0.1);
  --ui-al-run-fg: #4fb0fe;
  --ui-al-run-edge: rgba(1, 144, 254, 0.55);
  --ui-al-warn-bg: #fff1e0;
  --ui-al-warn-fg: #b25e00;
  --ui-al-danger-bg: #fdecea;
  --ui-al-danger-fg: #c4320a;
  --ui-al-focus: rgba(0, 96, 226, 0.7);
  --ui-al-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-al-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-al-row: 48px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 760px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-al-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-al-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-al *,
.ui-al *::before,
.ui-al *::after {
  box-sizing: border-box;
}
:where(.ui-al) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-al button:focus-visible {
  outline: 2px solid var(--ui-al-focus);
  outline-offset: 2px;
}
.ui-al ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-al svg {
  display: block;
  flex: none;
}
.ui-al__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-al__card {
  border-radius: 16px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
}
.ui-al__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 10px 10px 12px 14px;
}
.ui-al__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: rgba(0, 96, 226, 0.765);
}
.ui-al__title {
  font-weight: 600;
  color: var(--ui-al-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__summary {
  display: flex;
  flex: 1;
  gap: 12px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-muted);
  white-space: nowrap;
}
.ui-al__summary span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-al__summary span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-al-run-fg);
}
.ui-al__summary [data-kind="needs"] {
  color: var(--ui-al-warn-fg);
}
.ui-al__summary [data-kind="needs"]::before {
  background: var(--ui-al-warn-fg);
  animation: ui-al-pulse 1600ms ease-in-out infinite;
}
.ui-al__window {
  flex: none;
  padding: 3px 10px;
  border-radius: 999px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
}
.ui-al__body {
  display: grid;
  grid-template-columns: 168px minmax(0, 1fr);
  padding: 26px 16px 12px 0;
}
.ui-al__agents {
  display: grid;
  grid-auto-rows: var(--ui-al-row);
}
.ui-al__agent {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 0 12px 0 16px;
}
.ui-al__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  overflow: hidden;
  border-radius: 50%;
  background: var(--ui-al-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-al-text);
}
.ui-al__avatar[data-logo] {
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
}
.ui-al__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-al__who {
  display: grid;
  min-width: 0;
}
.ui-al__name {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-al-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-al__name-line {
  display: flex;
  align-items: center;
  min-width: 0;
}
.ui-al__model {
  display: flex;
  align-items: center;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-muted);
  white-space: nowrap;
}
.ui-al__model-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__state {
  display: inline-grid;
  flex: none;
  grid-template-columns: 0fr;
  margin-left: 0;
  opacity: 0;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 220ms ease;
}
.ui-al__state[data-show] {
  grid-template-columns: 1fr;
  margin-left: 6px;
  opacity: 1;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 260ms ease 80ms;
}
.ui-al__state > span {
  min-width: 0;
  overflow: hidden;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-al-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
  white-space: nowrap;
}
.ui-al__who[data-state="waiting"] .ui-al__state > span {
  background: var(--ui-al-warn-bg);
  color: var(--ui-al-warn-fg);
}
.ui-al__track {
  position: relative;
  height: calc(var(--rows) * var(--ui-al-row));
}
.ui-al__track::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    transparent 0,
    transparent calc(var(--ui-al-row) - 0.5px),
    var(--ui-al-line) calc(var(--ui-al-row) - 0.5px),
    var(--ui-al-line) var(--ui-al-row)
  );
  pointer-events: none;
}
.ui-al__grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-al__tick {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 0;
  border-left: 0.5px dashed var(--ui-al-line);
}
.ui-al__tick > span {
  position: absolute;
  bottom: 100%;
  left: 0;
  margin-bottom: 6px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-al-faint);
  white-space: nowrap;
  transform: translateX(-50%);
  font-variant-numeric: tabular-nums;
}
.ui-al__clip {
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(to right, transparent 0, #000 40px);
  mask-image: linear-gradient(to right, transparent 0, #000 40px);
}
.ui-al__layer {
  position: absolute;
  inset: 0;
  will-change: transform;
}
.ui-al__curves {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-al__curves path {
  fill: none;
  stroke: var(--ui-al-rail);
  stroke-width: 1;
  stroke-dasharray: 3 3;
}
.ui-al__curves path[data-live] {
  stroke: var(--ui-al-run-edge);
  animation: ui-al-flow 900ms linear infinite;
}
.ui-al__lane {
  position: absolute;
  left: 0;
  right: 0;
  height: var(--ui-al-row);
  transition: opacity 240ms ease;
}
.ui-al__agent {
  transition: opacity 240ms ease;
}
:is(.ui-al__agent, .ui-al__lane)[data-faded] {
  opacity: 0.4;
}
.ui-al__slot {
  position: absolute;
  top: 10px;
  bottom: 10px;
  min-width: 6px;
}
.ui-al__slot:is([data-status="running"], [data-status="waiting"]),
.ui-al__slot:is([data-status="running"], [data-status="waiting"])
  .ui-al__block {
  min-width: 0;
}
.ui-al__block {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  min-width: 6px;
  padding: 0 10px;
  overflow: hidden;
  border-radius: 8px;
  background: var(--ui-al-done);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-al-text);
  white-space: nowrap;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-al__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: clip;
  text-align: start;
}
.ui-al__tools {
  display: flex;
  flex: none;
  gap: 4px;
  margin-right: 6px;
}
.ui-al__tool {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-al__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-al__block:hover {
  background: var(--ui-al-fill);
}
.ui-al__block[data-status="running"] {
  position: relative;
  background: var(--ui-al-run-bg);
  color: var(--ui-al-run-fg);
  box-shadow: inset -2px 0 0 var(--ui-al-run-edge);
}
.ui-al__block[data-status="running"]::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(255, 255, 255, 0.55) 50%,
      transparent 100%
    )
    0 0 / 50% 100% no-repeat;
  animation: ui-al-shimmer 2200ms ease-in-out infinite;
}
.ui-al__block[data-status="waiting"] {
  background: var(--ui-al-warn-bg);
  color: var(--ui-al-warn-fg);
}
.ui-al__block[data-status="failed"] {
  background: var(--ui-al-danger-bg);
  color: var(--ui-al-danger-fg);
}
.ui-al__block[data-open] {
  filter: brightness(0.97);
}
.ui-al__flag {
  position: absolute;
  top: 50%;
  right: 4px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-al-warn-fg);
  white-space: nowrap;
  transform: translateY(-50%);
  pointer-events: none;
  animation: ui-al-pulse 1600ms ease-in-out infinite;
}
.ui-al__slot:has(.ui-al__block[data-status="waiting"]) {
  z-index: 2;
}
.ui-al__pop {
  position: absolute;
  z-index: 5;
  animation: ui-al-in 180ms ease both;
}
.ui-al__pop[data-up] {
  transform: translateY(-100%);
  animation-name: ui-al-in-up;
}
.ui-al__ask {
  display: grid;
  gap: 2px;
  width: 290px;
  padding: 14px;
  border-radius: 14px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-pop);
  max-width: calc(100cqw - 24px);
  overflow-wrap: anywhere;
}
.ui-al__tip {
  display: grid;
  gap: 4px;
  width: max-content;
  max-width: min(calc(100cqw - 24px), 230px);
  padding: 10px 12px;
  border-radius: 12px;
  background: rgba(23, 23, 23, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 10px 28px -8px rgba(0, 0, 0, 0.35);
  font-size: 12.5px;
  line-height: 17px;
  color: rgba(255, 255, 255, 0.86);
  translate: -50% 0;
  overflow-wrap: anywhere;
}
.ui-al__tip-head {
  display: flex;
  gap: 4px;
  min-width: 0;
  font-size: 11.5px;
  color: rgba(255, 255, 255, 0.55);
  white-space: nowrap;
}
.ui-al__tip-title {
  color: #fff;
}
.ui-al__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-al__tip-head > span:last-child {
  flex: none;
}
.ui-al__tip-list {
  display: grid;
  gap: 2px;
}
.ui-al__tip-list li {
  position: relative;
  padding-left: 10px;
}
.ui-al__tip-list li::before {
  content: "";
  position: absolute;
  top: 8px;
  left: 1px;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
}
.ui-al__tip-open {
  justify-self: start;
  margin-top: 2px;
  font-size: 12.5px;
  font-weight: 500;
  color: #fff;
  text-decoration: underline;
  text-decoration-color: rgba(255, 255, 255, 0.35);
  text-underline-offset: 2px;
}
.ui-al__ask-title {
  font-weight: 500;
  color: var(--ui-al-strong);
}
.ui-al__ask-text {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-al-text);
}
.ui-al__ask-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 8px;
}
.ui-al__btn {
  display: inline-flex;
  align-items: center;
  height: 30px;
  padding: 0 12px;
  border-radius: 9px;
  background: var(--ui-al-card);
  box-shadow: var(--ui-al-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-al-strong);
}
.ui-al__btn:hover {
  background: var(--ui-al-wash);
}
.ui-al__btn--primary {
  background: var(--ui-al-solid);
  box-shadow: none;
  color: var(--ui-al-on-solid);
}
.ui-al__btn--primary:hover {
  background: #33333a;
}
.ui-al__now {
  position: absolute;
  top: -6px;
  right: 0;
  width: 0;
  pointer-events: none;
}
.ui-al__now > span {
  position: absolute;
  bottom: 100%;
  right: 0;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-al-run-bg);
  font-size: 10px;
  font-weight: 500;
  line-height: 14px;
  color: var(--ui-al-run-fg);
}
@keyframes ui-al-pulse {
  50% {
    opacity: 0.55;
  }
}
@keyframes ui-al-shimmer {
  from {
    background-position: -100% 0;
  }
  to {
    background-position: 200% 0;
  }
}
@keyframes ui-al-flow {
  to {
    stroke-dashoffset: -6;
  }
}
@keyframes ui-al-in {
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
}
@keyframes ui-al-in-up {
  from {
    opacity: 0;
    transform: translateY(calc(-100% + 3px));
  }
  to {
    transform: translateY(-100%);
  }
}
@container (max-width: 520px) {
  .ui-al__tip {
    max-width: 200px;
  }
  .ui-al__body {
    grid-template-columns: 48px minmax(0, 1fr);
  }
  .ui-al__who {
    display: none;
  }
  .ui-al__summary [data-kind="running"] {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-al *,
  .ui-al *::before,
  .ui-al *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-al {
  --ui-al-tray: #111113;
  --ui-al-card: #19191b;
  --ui-al-strong: #ffffff;
  --ui-al-ink: rgba(255, 255, 255, 0.9);
  --ui-al-text: rgba(255, 255, 255, 0.62);
  --ui-al-muted: rgba(255, 255, 255, 0.45);
  --ui-al-faint: rgba(255, 255, 255, 0.28);
  --ui-al-line: rgba(255, 255, 255, 0.08);
  --ui-al-rail: rgba(255, 255, 255, 0.2);
  --ui-al-wash: rgba(255, 255, 255, 0.04);
  --ui-al-fill: rgba(255, 255, 255, 0.08);
  --ui-al-done: rgba(255, 255, 255, 0.06);
  --ui-al-solid: rgba(255, 255, 255, 0.92);
  --ui-al-on-solid: #141416;
  --ui-al-run-bg: #0077ff3a;
  --ui-al-run-fg: #4fb0fe;
  --ui-al-run-edge: rgba(79, 176, 254, 0.6);
  --ui-al-warn-bg: #fb6a0025;
  --ui-al-warn-fg: #ffb35c;
  --ui-al-danger-bg: #ff35232b;
  --ui-al-danger-fg: #ff8a7a;
  --ui-al-focus: rgba(77, 141, 255, 0.8);
  --ui-al-shadow: 0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-al-pop: 0 0 0 1px #2a2a2e, 0 16px 36px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-al__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"]) .ui-al__block[data-status="running"]::after {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.12) 50%,
    transparent 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-al__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-head {
  color: rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-title,
:where(.dark, [data-theme="dark"]) .ui-al__tip-open {
  color: #000;
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-open {
  text-decoration-color: rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-al__tip-list li::before {
  background: rgba(0, 0, 0, 0.4);
}

.ui-mt {
  --ui-mt-ink: #171717;
  --ui-mt-text: #6b6b6b;
  --ui-mt-muted: #8a8a8a;
  --ui-mt-track: #f0f0f0;
  --ui-mt-card: #ffffff;
  --ui-mt-panel: #ffffff;
  --ui-mt-line: #ececec;
  --ui-mt-shadow: 0 0 0 1px #e6e6e6, 0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-mt-stroke: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-mt-focus: rgba(0, 96, 226, 0.7);
  --ui-mt-gap: 16px;
  --ui-mt-side-w: 340px;
  box-sizing: border-box;
  display: grid;
  gap: var(--ui-mt-gap);
  width: 100%;
  min-width: 0;
  container: ui-mt / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  letter-spacing: -0.006em;
  line-height: 20px;
  color: var(--ui-mt-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-mt *,
.ui-mt *::before,
.ui-mt *::after {
  box-sizing: border-box;
}
.ui-mt__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 16px;
  min-width: 0;
}
.ui-mt__title {
  flex: 1 1 0;
  min-width: min(160px, 100%);
  margin: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mt__filter {
  display: flex;
  gap: 2px;
  max-width: 100%;
  overflow-x: auto;
  scrollbar-width: none;
  padding: 3px;
  border-radius: 999px;
  background: var(--ui-mt-track);
}
.ui-mt__filter::-webkit-scrollbar {
  display: none;
}
.ui-mt__chip {
  flex: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin: 0;
  padding: 0 12px;
  border: 0;
  border-radius: 999px;
  background: none;
  font: inherit;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-mt-text);
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
  -webkit-tap-highlight-color: transparent;
}
.ui-mt__chip:hover:not(:disabled) {
  color: var(--ui-mt-ink);
}
.ui-mt__chip[aria-checked="true"] {
  background: var(--ui-mt-card);
  color: var(--ui-mt-ink);
  box-shadow: var(--ui-mt-shadow);
}
.ui-mt__chip:disabled {
  opacity: 0.45;
  cursor: default;
}
.ui-mt__chip:focus-visible {
  outline: 2px solid var(--ui-mt-focus);
  outline-offset: -2px;
}
.ui-mt__n {
  font-variant-numeric: tabular-nums;
  color: var(--ui-mt-muted);
}
.ui-mt__grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) var(--ui-mt-side-w);
  align-items: start;
  gap: var(--ui-mt-gap);
  min-width: 0;
}
.ui-mt__side .ui-ai__more {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 10px 10px;
  padding: 6px 6px 6px 10px;
  border: 0;
  border-radius: 8px;
  background: var(--ui-mt-track);
}
.ui-mt__side .ui-ai__agent {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mt__side .ui-ai__actions {
  flex: none;
  margin-top: 0;
}
.ui-mt__side .ui-ai__btn {
  height: 26px;
  padding: 0 10px;
  font-size: 12px;
}
.ui-mt__side .ui-ai__bar {
  display: none;
}
.ui-mt__main,
.ui-mt__side {
  min-width: 0;
}
.ui-mt__grid {
  align-items: stretch;
}
.ui-mt__side {
  position: relative;
  min-height: 240px;
}
.ui-mt__side > .ui-ai {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
}
.ui-mt__side .ui-ai__lanes {
  flex: 1;
  grid-template-rows: minmax(0, 1fr);
  align-items: stretch;
  min-height: 0;
}
.ui-mt__side .ui-ai__lane {
  display: flex;
  flex-direction: column;
  min-height: 0;
}
.ui-mt__side .ui-ai__cards {
  flex: 1;
  align-content: start;
  min-height: 0;
  margin: -1px;
  padding: 1px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
@container ui-mt (min-width: 861px) {
  .ui-mt .ui-al__body {
    grid-template-columns: 196px minmax(0, 1fr);
  }
}
.ui-mt :is(.ui-rca__title, .ui-ai__heading, .ui-al__title) {
  font-size: 14px;
  line-height: 20px;
}
.ui-mt :is(.ui-ai__title, .ui-al__name) {
  font-size: 13px;
  line-height: 18px;
}
.ui-mt .ui-ai__desc {
  font-size: 12.5px;
  line-height: 17px;
}
.ui-mt .ui-ai__foot {
  font-size: 12.5px;
  line-height: 17px;
  margin-top: 2px;
}
.ui-mt .ui-ai__card-main {
  gap: 4px;
  padding: 10px 12px;
}
.ui-mt :is(.ui-rca, .ui-al__card) {
  box-shadow: var(--ui-mt-stroke);
}
@container ui-mt (max-width: 860px) {
  .ui-mt__grid {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-mt__side {
    min-height: 0;
  }
  .ui-mt__side > .ui-ai {
    position: static;
  }
}
@container ui-mt (max-width: 600px) {
  .ui-mt .ui-al__flag {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mt__chip {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mt {
  --ui-mt-ink: #ededed;
  --ui-mt-text: #a1a1a6;
  --ui-mt-muted: #7c7c82;
  --ui-mt-track: #26262a;
  --ui-mt-card: #2e2e33;
  --ui-mt-panel: #232326;
  --ui-mt-line: #2a2a2e;
  --ui-mt-shadow: 0 0 0 1px #34343a, 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-mt-stroke: 0 0 0 1px #2a2a2e, 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-mt-focus: rgba(77, 141, 255, 0.8);
}

.mt-demo {
  width: 100%;
  min-width: 0;
  padding: 40px 24px;
}
:is(.stage:has(> .stage__look > .mt-demo), .stage:has(> .mt-demo)) {
  align-items: start;
}
.mt-demo__frame {
  width: 100%;
  position: relative;
}
.mt-demo__canvas {
  transform-origin: 0 0;
  padding-bottom: 6px;
  position: absolute;
  top: 0;
  left: 0;
}
.card__preview .mt-demo {
  padding: 44px 16px 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask: linear-gradient(#000 80%, #0000 99%);
  mask: linear-gradient(#000 80%, #0000 99%);
}
`;export{n as default};
