const n=`.ui-rcp {
  --ui-rcp-card: #ffffff;
  --ui-rcp-strong: #000000;
  --ui-rcp-ink: rgba(0, 0, 0, 0.88);
  --ui-rcp-text: rgba(0, 0, 0, 0.61);
  --ui-rcp-muted: rgba(0, 0, 0, 0.45);
  --ui-rcp-faint: rgba(0, 0, 0, 0.27);
  --ui-rcp-line: rgba(0, 0, 0, 0.06);
  --ui-rcp-lane: #f4f4f5;
  --ui-rcp-stroke: rgba(0, 0, 0, 0.42);
  --ui-rcp-area: rgba(0, 0, 0, 0.07);
  --ui-rcp-done: #a1a1aa;
  --ui-rcp-needs: #0070d6;
  --ui-rcp-failed: #f04438;
  --ui-rcp-ok: #1e8a4f;
  --ui-rcp-grid: rgba(0, 0, 0, 0.045);
  --ui-rcp-hover: #fafafa;
  --ui-rcp-card-h: 90px;
  --ui-rcp-focus-ring: rgba(0, 96, 226, 0.35);
  --ui-rcp-focus: rgba(0, 96, 226, 0.7);
  --ui-rcp-cursor: rgba(0, 0, 0, 0.22);
  --ui-rcp-dot: rgba(0, 0, 0, 0.55);
  --ui-rcp-ok-bg: rgba(95, 200, 138, 0.1);
  --ui-rcp-tip: #18181b;
  --ui-rcp-tip-text: #fafafa;
  --ui-rcp-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-rcp-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 16px 16px 12px;
  border-radius: 14px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  container: ui-rcp / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rcp-text);
  -webkit-font-smoothing: antialiased;
  --ui-rcp-dot-needs: #f28a2e;
  --ui-rcp-dot-failed: var(--ui-rcp-failed);
}
.ui-rcp *,
.ui-rcp *::before,
.ui-rcp *::after {
  box-sizing: border-box;
}
:where(.ui-rcp) :where(h2, h3, p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-rcp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-rcp button:focus-visible {
  outline: 2px solid var(--ui-rcp-focus);
  outline-offset: 2px;
}
.ui-rcp [data-kind="done"] {
  --k: var(--ui-rcp-done);
}
.ui-rcp [data-kind="needs"] {
  --k: var(--ui-rcp-needs);
}
.ui-rcp [data-kind="failed"] {
  --k: var(--ui-rcp-failed);
}
.ui-rcp__head {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-start;
  justify-content: space-between;
  gap: 8px 16px;
}
.ui-rcp__title {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-rcp-strong);
}
.ui-rcp__since {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 2px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-rcp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__pill {
  padding: 0 6px;
  border-radius: 5px;
  background: rgba(0, 0, 0, 0.05);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rcp-text);
}
.ui-rcp__counts {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 12px;
  min-width: 0;
  padding-top: 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
}
.ui-rcp__counts li {
  display: inline-flex;
  align-items: center;
  gap: 5px;
}
.ui-rcp__counts b {
  font-weight: 500;
  color: var(--ui-rcp-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__kind {
  flex: none;
  width: 14px;
  height: 14px;
  color: var(--ui-rcp-muted);
}
.ui-rcp__chart {
  position: relative;
  height: 96px;
  margin: 14px 0 0;
  cursor: crosshair;
}
.ui-rcp__grid line {
  stroke: var(--ui-rcp-grid);
  stroke-width: 1;
}
.ui-rcp__chart svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.ui-rcp__cursor {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  margin-left: -0.5px;
  background: var(--ui-rcp-cursor);
  pointer-events: none;
}
.ui-rcp__frame {
  position: absolute;
  inset: 0;
  border-top: 1px solid var(--ui-rcp-grid);
  border-bottom: 1px solid var(--ui-rcp-grid);
  pointer-events: none;
}
.ui-rcp__line {
  fill: none;
  stroke: var(--ui-rcp-stroke);
  stroke-width: 1.5;
  stroke-linejoin: round;
}
.ui-rcp__dot {
  position: absolute;
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--ui-rcp-dot);
  box-shadow: 0 0 0 1.5px var(--ui-rcp-card);
  transform: translate(-50%, -50%) scale(0);
  transition:
    transform 360ms var(--ui-rcp-ease),
    background-color 240ms ease;
}
.ui-rcp__dot[data-on] {
  transform: translate(-50%, -50%) scale(1);
}
@starting-style {
  .ui-rcp__dot[data-on] {
    transform: translate(-50%, -50%) scale(0);
  }
}
.ui-rcp__dot[data-hot] {
  transform: translate(-50%, -50%) scale(1.6);
}
.ui-rcp__dot::after {
  content: "";
  position: absolute;
  inset: -6px;
  border-radius: 50%;
}
.ui-rcp__dot[data-kind="needs"] {
  background: var(--ui-rcp-dot-needs);
}
.ui-rcp__dot[data-kind="failed"] {
  background: var(--ui-rcp-dot-failed);
}
.ui-rcp__tip {
  position: absolute;
  z-index: 2;
  max-width: 280px;
  overflow: hidden;
  margin-top: -12px;
  padding: 3px 8px;
  border-radius: 6px;
  background: var(--ui-rcp-tip);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-rcp-tip-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  transform: translate(-50%, -100%);
  pointer-events: none;
  animation: ui-rcp-pop 140ms ease both;
}
.ui-rcp__tip[data-edge="start"] {
  transform: translate(-12px, -100%);
}
.ui-rcp__tip[data-edge="end"] {
  transform: translate(calc(-100% + 12px), -100%);
}
.ui-rcp__ends {
  display: flex;
  justify-content: space-between;
  margin: 4px 0 0;
  font-size: 10.5px;
  line-height: 14px;
  color: var(--ui-rcp-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__board {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  align-items: stretch;
  margin-top: 14px;
}
.ui-rcp__lane {
  padding: 4px;
  border-radius: 14px;
  background: var(--ui-rcp-lane);
}
.ui-rcp__lane-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 32px;
  padding: 0 10px 0 9px;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rcp-muted);
}
.ui-rcp__lane-head > span:first-child {
  display: inline-flex;
  align-items: center;
  gap: 8px;
}
.ui-rcp__lane-head .ui-rcp__kind {
  width: 18px;
  height: 14px;
}
.ui-rcp__lane-n {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(166, 81, 240, 0.06);
  font-size: 11px;
  color: var(--ui-rcp-text);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__cards {
  display: grid;
  grid-auto-rows: var(--ui-rcp-card-h);
  align-content: start;
  gap: 4px;
  min-height: calc(
    var(--ui-rcp-limit) * var(--ui-rcp-card-h) + (var(--ui-rcp-limit) - 1) * 4px
  );
}
.ui-rcp__card {
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 9px 10px 9px 9px;
  border-radius: 10px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  opacity: 0;
  filter: blur(2px);
  transform: translateY(4px);
  transition:
    opacity 320ms ease,
    filter 320ms ease,
    transform 420ms var(--ui-rcp-ease),
    box-shadow 160ms ease,
    background-color 160ms ease;
}
.ui-rcp__card[data-seen] {
  opacity: 1;
  filter: none;
  transform: none;
}
.ui-rcp__card[data-hot] {
  background: var(--ui-rcp-hover);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rcp__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 20px;
}
.ui-rcp__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-rcp-card);
  box-shadow: var(--ui-rcp-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-rcp-ink);
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-rcp__mark > svg {
  width: 11px;
  height: 11px;
}
.ui-rcp__card[data-state="resolved"] .ui-rcp__mark {
  background: var(--ui-rcp-ok-bg);
  box-shadow: none;
  color: var(--ui-rcp-ok);
}
.ui-rcp__card-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-rcp-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__card:is([data-state="resolved"], [data-state="undone"])
  .ui-rcp__card-title {
  color: var(--ui-rcp-muted);
}
.ui-rcp__time {
  flex: none;
  font-size: 11px;
  color: var(--ui-rcp-faint);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-rcp__card-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 18px;
  padding-left: 26px;
}
.ui-rcp__detail {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__card[data-kind="failed"][data-state="open"] .ui-rcp__detail {
  color: var(--ui-rcp-failed);
}
.ui-rcp__tag {
  flex: none;
  padding: 0 5px;
  border-radius: 4px;
  background: rgba(0, 0, 0, 0.05);
  font-size: 10.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rcp-text);
  font-variant-numeric: tabular-nums;
}
.ui-rcp__card-foot {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  gap: 4px;
  height: 24px;
  margin-top: 6px;
}
.ui-rcp__status {
  display: flex;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-rcp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rcp__state {
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-rcp-ok-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rcp-ok);
}
.ui-rcp__state[data-off] {
  background: rgba(0, 0, 0, 0.05);
  color: var(--ui-rcp-muted);
}
.ui-rcp__btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px !important;
  font-weight: 500;
  color: var(--ui-rcp-muted) !important;
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms ease,
    opacity 160ms ease;
}
.ui-rcp__btn:hover:not(:disabled) {
  background: rgba(0, 0, 0, 0.04) !important;
  color: var(--ui-rcp-ink) !important;
}
.ui-rcp__btn--main {
  padding: 0 9px;
  background: var(--ui-rcp-card) !important;
  box-shadow: var(--ui-rcp-shadow);
  color: var(--ui-rcp-ink) !important;
}
.ui-rcp__btn--main:hover:not(:disabled) {
  background: var(--ui-rcp-card) !important;
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.12),
    0 1px 3px rgba(0, 0, 0, 0.08);
}
.ui-rcp__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-rcp__btn:disabled {
  opacity: 0.6;
  cursor: default !important;
}
.ui-rcp__spin {
  width: 11px;
  height: 11px;
  border: 1.5px solid currentColor;
  border-right-color: transparent;
  border-radius: 50%;
  animation: ui-rcp-spin 700ms linear infinite;
}
.ui-rcp__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-rcp__cards {
  position: relative;
}
.ui-rcp__empty {
  position: absolute;
  inset: 0;
  display: grid;
  place-items: center;
  font-size: 12px;
  color: var(--ui-rcp-faint);
}
.ui-rcp__card {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rcp__card:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-rcp-focus-ring),
    0 1px 3px rgba(0, 0, 0, 0.06);
}
.ui-rcp__btn {
  flex: none;
}
.ui-rcp__btn--main {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 70%;
}
.ui-rcp__btn-label {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rcp button:focus-visible {
  outline: 2px solid var(--ui-rcp-focus);
  outline-offset: 2px;
}
@keyframes ui-rcp-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-rcp-spin {
  to {
    transform: rotate(360deg);
  }
}
@container ui-rcp (max-width: 640px) {
  .ui-rcp__board {
    grid-template-columns: minmax(0, 1fr);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rcp *,
  .ui-rcp *::before,
  .ui-rcp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rcp {
  --ui-rcp-card: #1c1c1f;
  --ui-rcp-strong: #ffffff;
  --ui-rcp-ink: rgba(255, 255, 255, 0.9);
  --ui-rcp-text: rgba(255, 255, 255, 0.62);
  --ui-rcp-muted: rgba(255, 255, 255, 0.45);
  --ui-rcp-faint: rgba(255, 255, 255, 0.28);
  --ui-rcp-line: rgba(255, 255, 255, 0.08);
  --ui-rcp-lane: #161618;
  --ui-rcp-stroke: rgba(255, 255, 255, 0.5);
  --ui-rcp-area: rgba(255, 255, 255, 0.08);
  --ui-rcp-done: #71717a;
  --ui-rcp-needs: #4fb0fe;
  --ui-rcp-failed: #ff6b5f;
  --ui-rcp-ok: #2fb26a;
  --ui-rcp-grid: rgba(255, 255, 255, 0.05);
  --ui-rcp-hover: #222226;
  --ui-rcp-cursor: rgba(255, 255, 255, 0.28);
  --ui-rcp-focus-ring: rgba(91, 154, 255, 0.45);
  --ui-rcp-focus: rgba(77, 141, 255, 0.8);
  --ui-rcp-dot: rgba(255, 255, 255, 0.65);
  --ui-rcp-ok-bg: rgba(125, 207, 159, 0.16);
  --ui-rcp-tip: #fafafa;
  --ui-rcp-tip-text: #111113;
  --ui-rcp-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-rcp-dot-needs: #f2a15c;
  --ui-rcp-dot-failed: var(--ui-rcp-failed);
}
:where(.dark, [data-theme="dark"]) .ui-rcp__lane-n {
  background: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-rcp__tag,
:where(.dark, [data-theme="dark"]) .ui-rcp__pill,
:where(.dark, [data-theme="dark"]) .ui-rcp__state[data-off] {
  background: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"])
  .ui-rcp__btn:not(.ui-rcp__btn--main):hover:not(:disabled) {
  background: rgba(255, 255, 255, 0.06) !important;
}

.ui-aic {
  --ui-aic-lane: #f4f4f5;
  --ui-aic-card: #ffffff;
  --ui-aic-line: #e9e9ec;
  --ui-aic-ink: #1c1c1f;
  --ui-aic-text: #55555c;
  --ui-aic-muted: #8e8e96;
  --ui-aic-faint: #b4b4bb;
  --ui-aic-blue: #4fb0fe;
  --ui-aic-amber: #e8b000;
  --ui-aic-green: #1e8a4f;
  --ui-aic-red: #f04438;
  --ui-aic-focus: rgba(0, 96, 226, 0.7);
  --ui-aic-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-aic-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-aic *,
.ui-aic *::before,
.ui-aic *::after {
  box-sizing: border-box;
}
:where(.ui-aic) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-aic button:focus-visible {
  outline: 2px solid var(--ui-aic-focus);
  outline-offset: 2px;
}
.ui-aic ul,
.ui-aic ol {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-aic svg {
  display: block;
  flex: none;
}
.ui-aic__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-aic__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
  padding: 0 2px;
}
.ui-aic__heading {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-aic-ink);
  white-space: nowrap;
}
.ui-aic__crumb {
  flex: none;
  color: var(--ui-aic-muted);
  font-weight: 400;
}
.ui-aic__slash {
  flex: none;
  color: var(--ui-aic-faint);
}
.ui-aic__heading-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-aic__views {
  display: flex;
  flex: none;
  gap: 2px;
  padding: 3px;
  border-radius: 10px;
  background: var(--ui-aic-lane);
}
.ui-aic__view {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px;
  border-radius: 7px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-aic-muted);
  transition:
    background-color 180ms ease,
    color 180ms ease,
    box-shadow 180ms ease;
}
.ui-aic__view:hover {
  color: var(--ui-aic-ink);
}
.ui-aic__view[aria-checked="true"] {
  background: var(--ui-aic-card);
  color: var(--ui-aic-ink);
  box-shadow:
    0 1px 2px rgba(166, 81, 240, 0.08),
    0 0 0 1px rgba(166, 81, 240, 0.04);
}
.ui-aic__lanes {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  align-items: start;
}
.ui-aic__lane {
  min-width: 0;
  padding: 4px 4px 4px;
  border-radius: 14px;
  background: var(--ui-aic-lane);
}
.ui-aic__lane-head {
  display: grid;
  grid-template-columns: 20px 1fr minmax(20px, auto);
  align-items: center;
  height: 34px;
  padding: 0 8px 0 10px;
}
.ui-aic__lane-spark {
  color: var(--ui-aic-blue);
  opacity: 0.7;
}
.ui-aic__lane-name {
  overflow: hidden;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.08em;
  text-align: center;
  text-transform: uppercase;
  color: var(--ui-aic-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-aic__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(166, 81, 240, 0.06);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-aic-text);
  font-variant-numeric: tabular-nums;
}
.ui-aic__cards {
  display: grid;
  gap: 6px;
}
.ui-aic__empty {
  padding: 18px 0 20px;
  font-size: 12.5px;
  text-align: center;
  color: var(--ui-aic-faint);
}
.ui-aic__card[data-faded] {
  opacity: 0.4;
}
.ui-aic__card {
  position: relative;
  border-radius: 10px;
  background: var(--ui-aic-card);
  box-shadow:
    0 0 0 1px var(--ui-aic-line),
    0 1px 2px rgba(166, 81, 240, 0.04);
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-aic__card:hover,
.ui-aic__card[data-open] {
  box-shadow:
    0 0 0 1px #dcdce1,
    0 4px 14px -6px rgba(166, 81, 240, 0.12);
}
.ui-aic__card-main {
  display: grid;
  gap: 6px;
  width: 100%;
  padding: 12px 14px 12px 12px;
  border-radius: 10px;
  container: aic-card / inline-size;
}
.ui-aic__title-row {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  min-width: 0;
}
.ui-aic__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 20px;
  color: var(--ui-aic-blue);
  transition: color 300ms ease;
}
.ui-aic__card[data-status="waiting"] .ui-aic__spark {
  color: var(--ui-aic-amber);
}
.ui-aic__card[data-status="failed"] .ui-aic__spark {
  color: var(--ui-aic-red);
}
.ui-aic__card[data-status="done"] .ui-aic__spark {
  color: var(--ui-aic-green);
}
.ui-aic__title {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-aic-ink);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow-wrap: anywhere;
}
.ui-aic__desc {
  display: -webkit-box;
  padding-left: 26px;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-aic-text);
  text-align: start;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-aic__card[data-open] .ui-aic__title {
  white-space: normal;
}
.ui-aic__card[data-open] .ui-aic__desc {
  -webkit-line-clamp: unset;
}
.ui-aic__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  margin-top: 4px;
  padding-left: 26px;
}
.ui-aic__state {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 12.5px;
  color: var(--ui-aic-text);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-aic__state-word {
  min-width: 2.6em;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: pre;
  margin-right: calc(0.28em - 8px);
}
.ui-aic__time {
  flex: none;
}
.ui-aic__state-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  color: var(--ui-aic-blue);
  animation: ui-aic-pop 360ms var(--ui-aic-ease) both;
}
.ui-aic__state-icon[data-status="running"] svg {
  animation: ui-aic-spin 900ms linear infinite;
}
.ui-aic__state-icon[data-status="waiting"] {
  color: var(--ui-aic-amber);
}
.ui-aic__state-icon[data-status="done"] {
  color: var(--ui-aic-green);
}
.ui-aic__state-icon[data-status="failed"] {
  color: var(--ui-aic-red);
}
.ui-aic__meta {
  display: inline-flex;
  flex: none;
  align-items: center;
  font-size: 12px;
  color: var(--ui-aic-muted);
  font-variant-numeric: tabular-nums;
}
.ui-aic__meta > span {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 0 9px;
}
.ui-aic__meta > span + span {
  border-left: 1px solid var(--ui-aic-line);
}
.ui-aic__meta > span:last-child {
  padding-right: 0;
}
.ui-aic__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 460ms var(--ui-aic-ease),
    opacity 240ms ease;
}
.ui-aic__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 460ms var(--ui-aic-ease),
    opacity 320ms ease 100ms;
}
.ui-aic__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-aic__more {
  margin: 0 14px 0 12px;
  padding: 10px 0 12px;
  border-top: 1px solid var(--ui-aic-line);
}
.ui-aic__agent {
  font-size: 12px;
  color: var(--ui-aic-muted);
}
.ui-aic__steps {
  position: relative;
  display: grid;
  gap: 5px;
  margin-top: 6px !important;
  padding-left: 12px !important;
}
.ui-aic__steps li {
  position: relative;
  display: flex;
  justify-content: space-between;
  gap: 10px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-aic-text);
}
.ui-aic__steps li::before {
  content: "";
  position: absolute;
  top: 7px;
  left: -12px;
  width: 4px;
  height: 4px;
  border-radius: 50%;
  background: var(--ui-aic-faint);
}
.ui-aic__steps li:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 15px;
  bottom: -8px;
  left: -10.5px;
  width: 1px;
  background: var(--ui-aic-line);
}
.ui-aic__steps li[data-last]::before {
  background: var(--ui-aic-ink);
}
.ui-aic__steps li > span {
  min-width: 0;
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-aic__steps time {
  flex: none;
  max-width: 45%;
  color: var(--ui-aic-muted);
  text-align: end;
}
.ui-aic__actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 10px;
}
.ui-aic__actions:empty {
  display: none;
}
.ui-aic__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 12px;
  border-radius: 8px;
  box-shadow: inset 0 0 0 1px var(--ui-aic-line);
  background: var(--ui-aic-card);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-aic-ink);
  transition: background-color 160ms ease;
}
.ui-aic__btn:hover {
  background: var(--ui-aic-lane);
}
.ui-aic__btn--primary {
  background: var(--ui-aic-ink);
  box-shadow: none;
  color: var(--ui-aic-card);
}
.ui-aic__btn--primary:hover {
  background: #33333a;
}
.ui-aic[data-view="list"] .ui-aic__lanes {
  grid-template-columns: minmax(0, 1fr);
}
.ui-aic[data-view="list"] .ui-aic__lane-head {
  grid-template-columns: 20px auto 1fr;
  gap: 4px;
}
.ui-aic[data-view="list"] .ui-aic__lane-name {
  text-align: left;
}
.ui-aic[data-view="list"] .ui-aic__count {
  justify-self: start;
}
.ui-aic__lanes {
  animation: ui-aic-in 320ms ease both;
}
@keyframes ui-aic-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-aic-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-aic-in {
  from {
    opacity: 0.4;
  }
}
@container (max-width: 620px) {
  .ui-aic__views {
    display: none;
  }
  .ui-aic .ui-aic__lanes {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-aic .ui-aic__lane-head {
    grid-template-columns: 20px auto 1fr;
    gap: 4px;
  }
  .ui-aic .ui-aic__lane-name {
    text-align: left;
  }
  .ui-aic .ui-aic__count {
    justify-self: start;
  }
}
@container aic-card (max-width: 300px) {
  .ui-aic__desc,
  .ui-aic__foot {
    padding-left: 0;
  }
  .ui-aic__state:is([data-status="running"], [data-status="done"]):not(
      [data-bare]
    )
    .ui-aic__state-word {
    display: none;
  }
  .ui-aic__foot {
    flex-wrap: wrap;
    row-gap: 2px;
  }
  .ui-aic__state[data-status="waiting"] {
    flex: 1 1 110px;
  }
}
@container (max-width: 360px) {
  .ui-aic__desc,
  .ui-aic__foot {
    padding-left: 0;
  }
  .ui-aic__title {
    white-space: normal;
  }
  .ui-aic__card:not([data-open]) .ui-aic__title {
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }
}
@media (pointer: coarse) {
  .ui-aic__view {
    height: 32px;
  }
  .ui-aic__btn {
    height: 36px;
    padding: 0 16px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-aic *,
  .ui-aic *::before,
  .ui-aic *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-aic {
  --ui-aic-lane: #161618;
  --ui-aic-card: #1e1e21;
  --ui-aic-line: #2c2c31;
  --ui-aic-ink: #ededed;
  --ui-aic-text: #b6b6bd;
  --ui-aic-muted: #85858d;
  --ui-aic-faint: #5c5c63;
  --ui-aic-blue: #4fb0fe;
  --ui-aic-amber: #e6c24d;
  --ui-aic-green: #5fc88a;
  --ui-aic-red: #ff6b5f;
  --ui-aic-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-aic__card:hover,
:where(.dark, [data-theme="dark"]) .ui-aic__card[data-open] {
  box-shadow:
    0 0 0 1px #3a3a40,
    0 6px 18px -8px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-aic__count {
  background: rgba(255, 255, 255, 0.07);
}
:where(.dark, [data-theme="dark"]) .ui-aic__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"])
  .ui-aic__state-icon[data-status="failed"]
  path {
  stroke: #1e1e21;
}

.ui-alc {
  --ui-alc-card: #ffffff;
  --ui-alc-strong: #000000;
  --ui-alc-ink: rgba(0, 0, 0, 0.88);
  --ui-alc-text: rgba(0, 0, 0, 0.61);
  --ui-alc-muted: rgba(0, 0, 0, 0.45);
  --ui-alc-faint: rgba(0, 0, 0, 0.27);
  --ui-alc-line: rgba(0, 0, 0, 0.06);
  --ui-alc-rail: rgba(0, 0, 0, 0.15);
  --ui-alc-wash: rgba(0, 0, 0, 0.03);
  --ui-alc-fill: rgba(0, 0, 0, 0.06);
  --ui-alc-done: rgba(0, 0, 0, 0.05);
  --ui-alc-solid: rgba(0, 0, 0, 0.88);
  --ui-alc-on-solid: #fcfcfc;
  --ui-alc-run-bg: #008ff519;
  --ui-alc-run-fg: #006dcbf2;
  --ui-alc-run-edge: rgba(0, 96, 226, 0.5);
  --ui-alc-warn-bg: #ff9c0029;
  --ui-alc-warn-fg: #b25e00;
  --ui-alc-danger-bg: #f52b0018;
  --ui-alc-danger-fg: #d72400da;
  --ui-alc-focus: rgba(0, 96, 226, 0.7);
  --ui-alc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-alc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-alc-row: 48px;
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 760px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-alc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-alc *,
.ui-alc *::before,
.ui-alc *::after {
  box-sizing: border-box;
}
:where(.ui-alc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-alc button:focus-visible {
  outline: 2px solid var(--ui-alc-focus);
  outline-offset: 2px;
}
.ui-alc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-alc svg {
  display: block;
  flex: none;
}
.ui-alc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-alc__card {
  border-radius: 10px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
}
.ui-alc__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 14px 16px;
  border-bottom: 0.5px solid var(--ui-alc-line);
}
.ui-alc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: rgba(0, 96, 226, 0.765);
}
.ui-alc__title {
  font-weight: 500;
  color: var(--ui-alc-strong);
  white-space: nowrap;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__summary {
  display: flex;
  flex: 1;
  gap: 12px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-muted);
  white-space: nowrap;
}
.ui-alc__summary span {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-alc__summary span::before {
  content: "";
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-alc-run-fg);
}
.ui-alc__summary [data-kind="needs"] {
  color: var(--ui-alc-warn-fg);
}
.ui-alc__summary [data-kind="needs"]::before {
  background: var(--ui-alc-warn-fg);
  animation: ui-alc-pulse 1600ms ease-in-out infinite;
}
.ui-alc__window {
  flex: none;
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--ui-alc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
}
.ui-alc__body {
  display: grid;
  grid-template-columns: 168px minmax(0, 1fr);
  padding: 26px 16px 12px 0;
}
.ui-alc__agents {
  display: grid;
  grid-auto-rows: var(--ui-alc-row);
}
.ui-alc__agent {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 0 12px 0 16px;
}
.ui-alc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-alc-fill);
  font-size: 10px;
  font-weight: 500;
  letter-spacing: 0.3px;
  color: var(--ui-alc-text);
}
.ui-alc__avatar[data-logo] {
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
}
.ui-alc__avatar > svg {
  width: 14px;
  height: 14px;
}
.ui-alc__who {
  display: grid;
  min-width: 0;
}
.ui-alc__name {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-alc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-alc__name-line {
  display: flex;
  align-items: center;
  min-width: 0;
}
.ui-alc__model {
  display: flex;
  align-items: center;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-muted);
  white-space: nowrap;
}
.ui-alc__model-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__state {
  display: inline-grid;
  flex: none;
  grid-template-columns: 0fr;
  margin-left: 0;
  opacity: 0;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 220ms ease;
}
.ui-alc__state[data-show] {
  grid-template-columns: 1fr;
  margin-left: 6px;
  opacity: 1;
  transition:
    grid-template-columns 320ms ease,
    margin-left 320ms ease,
    opacity 260ms ease 80ms;
}
.ui-alc__state > span {
  min-width: 0;
  overflow: hidden;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-alc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
  white-space: nowrap;
}
.ui-alc__who[data-state="waiting"] .ui-alc__state > span {
  background: var(--ui-alc-warn-bg);
  color: var(--ui-alc-warn-fg);
}
.ui-alc__track {
  position: relative;
  height: calc(var(--rows) * var(--ui-alc-row));
}
.ui-alc__track::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    transparent 0,
    transparent calc(var(--ui-alc-row) - 0.5px),
    var(--ui-alc-line) calc(var(--ui-alc-row) - 0.5px),
    var(--ui-alc-line) var(--ui-alc-row)
  );
  pointer-events: none;
}
.ui-alc__grid {
  position: absolute;
  inset: 0;
  pointer-events: none;
}
.ui-alc__tick {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 0;
  border-left: 0.5px dashed var(--ui-alc-line);
}
.ui-alc__tick > span {
  position: absolute;
  bottom: 100%;
  left: 0;
  margin-bottom: 6px;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-alc-faint);
  white-space: nowrap;
  transform: translateX(-50%);
  font-variant-numeric: tabular-nums;
}
.ui-alc__clip {
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(to right, transparent 0, #000 40px);
  mask-image: linear-gradient(to right, transparent 0, #000 40px);
}
.ui-alc__layer {
  position: absolute;
  inset: 0;
  will-change: transform;
}
.ui-alc__curves {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-alc__curves path {
  fill: none;
  stroke: var(--ui-alc-rail);
  stroke-width: 1;
  stroke-dasharray: 3 3;
}
.ui-alc__curves path[data-live] {
  stroke: var(--ui-alc-run-edge);
  animation: ui-alc-flow 900ms linear infinite;
}
.ui-alc__lane {
  position: absolute;
  left: 0;
  right: 0;
  height: var(--ui-alc-row);
  transition: opacity 240ms ease;
}
.ui-alc__agent {
  transition: opacity 240ms ease;
}
:is(.ui-alc__agent, .ui-alc__lane)[data-faded] {
  opacity: 0.4;
}
.ui-alc__slot {
  position: absolute;
  top: 10px;
  bottom: 10px;
  min-width: 6px;
}
.ui-alc__slot:is([data-status="running"], [data-status="waiting"]),
.ui-alc__slot:is([data-status="running"], [data-status="waiting"])
  .ui-alc__block {
  min-width: 0;
}
.ui-alc__block {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  min-width: 6px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-alc-done);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-alc-text);
  white-space: nowrap;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-alc__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: clip;
  text-align: start;
}
.ui-alc__tools {
  display: flex;
  flex: none;
  gap: 4px;
  margin-right: 6px;
}
.ui-alc__tool {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
}
.ui-alc__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-alc__block:hover {
  background: var(--ui-alc-fill);
}
.ui-alc__block[data-status="running"] {
  position: relative;
  background: var(--ui-alc-run-bg);
  color: var(--ui-alc-run-fg);
  box-shadow: inset -2px 0 0 var(--ui-alc-run-edge);
}
.ui-alc__block[data-status="running"]::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(255, 255, 255, 0.55) 50%,
      transparent 100%
    )
    0 0 / 50% 100% no-repeat;
  animation: ui-alc-shimmer 2200ms ease-in-out infinite;
}
.ui-alc__block[data-status="waiting"] {
  background: var(--ui-alc-warn-bg);
  color: var(--ui-alc-warn-fg);
}
.ui-alc__block[data-status="failed"] {
  background: var(--ui-alc-danger-bg);
  color: var(--ui-alc-danger-fg);
}
.ui-alc__block[data-open] {
  filter: brightness(0.97);
}
.ui-alc__flag {
  position: absolute;
  top: 50%;
  right: 4px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-alc-warn-fg);
  white-space: nowrap;
  transform: translateY(-50%);
  pointer-events: none;
  animation: ui-alc-pulse 1600ms ease-in-out infinite;
}
.ui-alc__slot:has(.ui-alc__block[data-status="waiting"]) {
  z-index: 2;
}
.ui-alc__pop {
  position: absolute;
  z-index: 5;
  animation: ui-alc-in 180ms ease both;
}
.ui-alc__pop[data-up] {
  transform: translateY(-100%);
  animation-name: ui-alc-in-up;
}
.ui-alc__ask {
  display: grid;
  gap: 2px;
  width: 280px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-pop);
  max-width: calc(100cqw - 24px);
  overflow-wrap: anywhere;
}
.ui-alc__tip {
  display: grid;
  gap: 4px;
  width: max-content;
  max-width: min(calc(100cqw - 24px), 220px);
  padding: 8px 10px;
  border-radius: 8px;
  background: rgba(24, 24, 27, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.35);
  font-size: 12px;
  line-height: 16px;
  color: rgba(255, 255, 255, 0.86);
  translate: -50% 0;
  overflow-wrap: anywhere;
}
.ui-alc__tip-head {
  display: flex;
  gap: 4px;
  min-width: 0;
  font-size: 11px;
  color: rgba(255, 255, 255, 0.55);
  white-space: nowrap;
}
.ui-alc__tip-title {
  color: #fff;
}
.ui-alc__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-alc__tip-head > span:last-child {
  flex: none;
}
.ui-alc__tip-list {
  display: grid;
  gap: 2px;
}
.ui-alc__tip-list li {
  position: relative;
  padding-left: 10px;
}
.ui-alc__tip-list li::before {
  content: "";
  position: absolute;
  top: 7px;
  left: 1px;
  width: 3px;
  height: 3px;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.5);
}
.ui-alc__tip-open {
  justify-self: start;
  margin-top: 2px;
  font-size: 12px;
  font-weight: 500;
  color: #fff;
  text-decoration: underline;
  text-decoration-color: rgba(255, 255, 255, 0.35);
  text-underline-offset: 2px;
}
.ui-alc__ask-title {
  font-weight: 500;
  color: var(--ui-alc-strong);
}
.ui-alc__ask-text {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-alc-text);
}
.ui-alc__ask-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 8px;
}
.ui-alc__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-alc-card);
  box-shadow: var(--ui-alc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-alc-strong);
}
.ui-alc__btn:hover {
  background: var(--ui-alc-wash);
}
.ui-alc__btn--primary {
  background: var(--ui-alc-solid);
  box-shadow: none;
  color: var(--ui-alc-on-solid);
}
.ui-alc__btn--primary:hover {
  background: #33333a;
}
.ui-alc__now {
  position: absolute;
  top: -6px;
  right: 0;
  width: 0;
  pointer-events: none;
}
.ui-alc__now > span {
  position: absolute;
  bottom: 100%;
  right: 0;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-alc-run-bg);
  font-size: 10px;
  font-weight: 500;
  line-height: 14px;
  color: var(--ui-alc-run-fg);
}
@keyframes ui-alc-pulse {
  50% {
    opacity: 0.55;
  }
}
@keyframes ui-alc-shimmer {
  from {
    background-position: -100% 0;
  }
  to {
    background-position: 200% 0;
  }
}
@keyframes ui-alc-flow {
  to {
    stroke-dashoffset: -6;
  }
}
@keyframes ui-alc-in {
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
}
@keyframes ui-alc-in-up {
  from {
    opacity: 0;
    transform: translateY(calc(-100% + 3px));
  }
  to {
    transform: translateY(-100%);
  }
}
@container (max-width: 520px) {
  .ui-alc__tip {
    max-width: 200px;
  }
  .ui-alc__body {
    grid-template-columns: 48px minmax(0, 1fr);
  }
  .ui-alc__who {
    display: none;
  }
  .ui-alc__summary [data-kind="running"] {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-alc *,
  .ui-alc *::before,
  .ui-alc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-alc {
  --ui-alc-card: #1c1c1f;
  --ui-alc-strong: #ffffff;
  --ui-alc-ink: rgba(255, 255, 255, 0.9);
  --ui-alc-text: rgba(255, 255, 255, 0.62);
  --ui-alc-muted: rgba(255, 255, 255, 0.45);
  --ui-alc-faint: rgba(255, 255, 255, 0.28);
  --ui-alc-line: rgba(255, 255, 255, 0.08);
  --ui-alc-rail: rgba(255, 255, 255, 0.2);
  --ui-alc-wash: rgba(255, 255, 255, 0.04);
  --ui-alc-fill: rgba(255, 255, 255, 0.08);
  --ui-alc-done: rgba(255, 255, 255, 0.06);
  --ui-alc-solid: rgba(255, 255, 255, 0.92);
  --ui-alc-on-solid: #141416;
  --ui-alc-run-bg: #0077ff3a;
  --ui-alc-run-fg: #4fb0fe;
  --ui-alc-run-edge: rgba(79, 176, 254, 0.6);
  --ui-alc-warn-bg: #fb6a0025;
  --ui-alc-warn-fg: #ffb35c;
  --ui-alc-danger-bg: #ff35232b;
  --ui-alc-danger-fg: #ff8a7a;
  --ui-alc-focus: rgba(77, 141, 255, 0.8);
  --ui-alc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-alc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-alc__btn--primary:hover {
  background: #d6d6da;
}
:where(.dark, [data-theme="dark"])
  .ui-alc__block[data-status="running"]::after {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.12) 50%,
    transparent 100%
  );
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-head {
  color: rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-title,
:where(.dark, [data-theme="dark"]) .ui-alc__tip-open {
  color: #000;
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-open {
  text-decoration-color: rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-alc__tip-list li::before {
  background: rgba(0, 0, 0, 0.4);
}

.ui-mtc {
  --ui-mtc-ink: rgba(0, 0, 0, 0.88);
  --ui-mtc-text: rgba(0, 0, 0, 0.61);
  --ui-mtc-muted: rgba(0, 0, 0, 0.45);
  --ui-mtc-track: rgba(0, 0, 0, 0.05);
  --ui-mtc-card: #ffffff;
  --ui-mtc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-mtc-focus: rgba(0, 96, 226, 0.7);
  --ui-mtc-stroke:
    0 0 0 1px rgba(0, 0, 0, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-mtc-gap: 16px;
  --ui-mtc-side-w: 340px;
  box-sizing: border-box;
  display: grid;
  gap: var(--ui-mtc-gap);
  width: 100%;
  min-width: 0;
  container: ui-mtc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-mtc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-mtc *,
.ui-mtc *::before,
.ui-mtc *::after {
  box-sizing: border-box;
}
.ui-mtc__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 16px;
  min-width: 0;
}
.ui-mtc__title {
  flex: 1 1 0;
  min-width: min(160px, 100%);
  margin: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 22px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mtc__filter {
  display: flex;
  gap: 2px;
  max-width: 100%;
  overflow-x: auto;
  scrollbar-width: none;
  padding: 2px;
  border-radius: 9px;
  background: var(--ui-mtc-track);
}
.ui-mtc__filter::-webkit-scrollbar {
  display: none;
}
.ui-mtc__chip {
  flex: none;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin: 0;
  padding: 0 10px;
  border: 0;
  border-radius: 7px;
  background: none;
  font: inherit;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-mtc-text);
  white-space: nowrap;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
  -webkit-tap-highlight-color: transparent;
}
.ui-mtc__chip:hover:not(:disabled) {
  color: var(--ui-mtc-ink);
}
.ui-mtc__chip[aria-checked="true"] {
  background: var(--ui-mtc-card);
  color: var(--ui-mtc-ink);
  box-shadow: var(--ui-mtc-shadow);
}
.ui-mtc__chip:disabled {
  opacity: 0.45;
  cursor: default;
}
.ui-mtc__chip:focus-visible {
  outline: 2px solid var(--ui-mtc-focus);
  outline-offset: -2px;
}
.ui-mtc__n {
  font-variant-numeric: tabular-nums;
  color: var(--ui-mtc-muted);
}
.ui-mtc__grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) var(--ui-mtc-side-w);
  align-items: start;
  gap: var(--ui-mtc-gap);
  min-width: 0;
}
.ui-mtc__side .ui-aic__more {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 10px 10px;
  padding: 6px 6px 6px 10px;
  border: 0;
  border-radius: 8px;
  background: var(--ui-mtc-track);
}
.ui-mtc__side .ui-aic__agent {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mtc__side .ui-aic__actions {
  flex: none;
  margin-top: 0;
}
.ui-mtc__side .ui-aic__btn {
  height: 26px;
  padding: 0 10px;
  font-size: 12px;
}
.ui-mtc__side .ui-aic__bar {
  display: none;
}
.ui-mtc__main,
.ui-mtc__side {
  min-width: 0;
}
.ui-mtc__grid {
  align-items: stretch;
}
.ui-mtc__side {
  position: relative;
  min-height: 240px;
}
.ui-mtc__side > .ui-aic {
  position: absolute;
  inset: 0;
  display: flex;
  flex-direction: column;
}
.ui-mtc__side .ui-aic__lanes {
  flex: 1;
  grid-template-rows: minmax(0, 1fr);
  align-items: stretch;
  min-height: 0;
}
.ui-mtc__side .ui-aic__lane {
  display: flex;
  flex-direction: column;
  min-height: 0;
}
.ui-mtc__side .ui-aic__cards {
  flex: 1;
  align-content: start;
  min-height: 0;
  margin: -1px;
  padding: 1px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
@container ui-mtc (min-width: 861px) {
  .ui-mtc .ui-alc__body {
    grid-template-columns: 196px minmax(0, 1fr);
  }
}
.ui-mtc :is(.ui-rcp__title, .ui-aic__heading, .ui-alc__title) {
  font-size: 13px;
  line-height: 20px;
}
.ui-mtc .ui-aic__title {
  font-size: 13px;
  line-height: 18px;
}
.ui-mtc .ui-aic__desc {
  font-size: 12px;
  line-height: 16px;
}
.ui-mtc .ui-aic__foot {
  font-size: 12px;
  line-height: 16px;
  margin-top: 2px;
}
.ui-mtc .ui-aic__card-main {
  gap: 4px;
  padding: 10px 12px;
}
.ui-mtc :is(.ui-rcp, .ui-alc__card) {
  box-shadow: var(--ui-mtc-stroke);
}
@container ui-mtc (max-width: 860px) {
  .ui-mtc__grid {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-mtc__side {
    min-height: 0;
  }
  .ui-mtc__side > .ui-aic {
    position: static;
  }
}
@container ui-mtc (max-width: 600px) {
  .ui-mtc .ui-alc__flag {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mtc__chip {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mtc {
  --ui-mtc-ink: rgba(255, 255, 255, 0.9);
  --ui-mtc-text: rgba(255, 255, 255, 0.62);
  --ui-mtc-muted: rgba(255, 255, 255, 0.45);
  --ui-mtc-track: rgba(255, 255, 255, 0.07);
  --ui-mtc-card: #2a2a2e;
  --ui-mtc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-mtc-focus: rgba(77, 141, 255, 0.8);
  --ui-mtc-stroke:
    0 0 0 1px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}

.mt-demo {
  width: 100%;
  min-width: 0;
  padding: 40px 24px;
}
:is(.stage:has(> .stage__look > .mt-demo), .stage:has(> .mt-demo)) {
  align-items: start;
}
.mt-demo__frame {
  width: 100%;
  position: relative;
}
.mt-demo__canvas {
  transform-origin: 0 0;
  padding-bottom: 6px;
  position: absolute;
  top: 0;
  left: 0;
}
.card__preview .mt-demo {
  padding: 44px 16px 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask: linear-gradient(#000 80%, #0000 99%);
  mask: linear-gradient(#000 80%, #0000 99%);
}
`;export{n as default};
