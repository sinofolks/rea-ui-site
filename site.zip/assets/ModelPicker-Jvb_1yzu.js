const n=`.ui-mdp {
  --ui-mdp-tray: #f0f0f0;
  --ui-mdp-card: #ffffff;
  --ui-mdp-line: #ececec;
  --ui-mdp-ink: #171717;
  --ui-mdp-text: #404040;
  --ui-mdp-muted: #626873;
  --ui-mdp-well: #f4f4f5;
  --ui-mdp-bar: #d4d4d9;
  --ui-mdp-bar-off: #e6e6ea;
  --ui-mdp-switch: #dcdce0;
  --ui-mdp-knob: #ffffff;
  --ui-mdp-focus: rgba(0, 96, 226, 0.7);
  --ui-mdp-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  min-width: 0;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-mdp-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mdp *,
.ui-mdp *::before,
.ui-mdp *::after {
  box-sizing: border-box;
}
:where(.ui-mdp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-mdp button:focus-visible,
.ui-mdp__list:focus-visible {
  outline: 2px solid var(--ui-mdp-focus);
  outline-offset: 2px;
}
.ui-mdp svg {
  display: block;
  flex: none;
}
.ui-mdp b {
  font-weight: 500;
  color: var(--ui-mdp-ink);
}
.ui-mdp__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-mdp__trigger {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  max-width: 100%;
  height: 30px;
  padding: 0 8px 0 6px;
  border-radius: 10px;
  font-weight: 500;
  color: var(--ui-mdp-ink);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-mdp__trigger:hover,
.ui-mdp[data-open] .ui-mdp__trigger {
  background: var(--ui-mdp-well);
}
.ui-mdp__trigger .ui-mdp__glyph {
  width: 18px;
  height: 18px;
}
.ui-mdp__name {
  display: grid;
  min-width: 0;
}
.ui-mdp__chevron {
  color: var(--ui-mdp-muted);
  transition: transform 300ms var(--ui-mdp-ease);
}
.ui-mdp[data-open] .ui-mdp__chevron {
  transform: rotate(180deg);
}
.ui-mdp__flag {
  display: grid;
  grid-template-columns: 0fr;
  margin-left: -7px;
  opacity: 0;
  color: var(--ui-mdp-muted);
  transition:
    grid-template-columns 360ms var(--ui-mdp-ease),
    margin 360ms var(--ui-mdp-ease),
    opacity 220ms ease;
}
.ui-mdp__flag > span {
  min-width: 0;
  overflow: hidden;
}
.ui-mdp__flag[data-on] {
  grid-template-columns: 1fr;
  margin-left: -3px;
  opacity: 1;
  transition:
    grid-template-columns 360ms var(--ui-mdp-ease),
    margin 360ms var(--ui-mdp-ease),
    opacity 280ms ease 80ms;
}
.ui-mdp__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-mdp-card);
  box-shadow: inset 0 0 0 1px var(--ui-mdp-line);
  font-size: 10.5px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-mdp-ink);
}
.ui-mdp__glyph > svg,
.ui-mdp__glyph > img {
  width: 12px;
  height: 12px;
}
.ui-mdp__pop {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  width: min(320px, calc(100vw - 32px));
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-mdp-tray);
  box-shadow:
    0 12px 32px -12px rgba(0, 0, 0, 0.16),
    0 2px 6px rgba(0, 0, 0, 0.04);
  transform-origin: top left;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-4px) scale(0.96);
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-mdp-ease),
    visibility 0s linear 220ms;
}
.ui-mdp[data-align="end"] .ui-mdp__pop {
  left: auto;
  right: 0;
  transform-origin: top right;
}
.ui-mdp[data-side="top"] .ui-mdp__pop {
  top: auto;
  bottom: calc(100% + 6px);
  transform-origin: bottom left;
  transform: translateY(4px) scale(0.96);
}
.ui-mdp[data-side="top"][data-align="end"] .ui-mdp__pop {
  transform-origin: bottom right;
}
.ui-mdp[data-open] .ui-mdp__pop {
  opacity: 1;
  visibility: visible;
  transform: none;
  transition:
    opacity 200ms ease,
    transform 320ms var(--ui-mdp-ease),
    visibility 0s;
}
.ui-mdp__card {
  padding: 6px;
  border-radius: 16px;
  background: var(--ui-mdp-card);
  box-shadow:
    0 0 0 1px var(--ui-mdp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-mdp__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 24px;
  padding: 0 10px;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-mdp-muted);
}
.ui-mdp__cols {
  display: grid;
  grid-template-columns: repeat(3, 34px);
  gap: 8px;
}
.ui-mdp__cols > span {
  display: flex;
  justify-content: center;
  white-space: nowrap;
}
.ui-mdp__list {
  display: grid;
  gap: 1px;
  border-radius: 10px;
  position: relative;
  max-height: min(360px, 50vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-mdp__empty {
  padding: 14px 10px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdp-muted);
  text-align: center;
}
.ui-mdp__option {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 48px;
  padding: 6px 10px;
  border-radius: 10px;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-mdp__list[data-pointing] .ui-mdp__option[data-active] {
  background: var(--ui-mdp-well);
}
.ui-mdp__list:focus-visible {
  outline: none;
}
.ui-mdp__list:focus-visible .ui-mdp__option[data-active] {
  background: var(--ui-mdp-well);
  outline: 2px solid var(--ui-mdp-focus);
  outline-offset: -2px;
}
.ui-mdp__list[data-pointing] .ui-mdp__option:not([data-active]) {
  opacity: 0.5;
}
.ui-mdp__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-mdp__title {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-mdp-ink);
}
.ui-mdp__title-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__check {
  color: var(--ui-mdp-ink);
  animation: ui-mdp-pop 320ms var(--ui-mdp-ease) both;
}
.ui-mdp__desc {
  overflow: hidden;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-mdp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__bars {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 34px);
  gap: 8px;
}
.ui-mdp__meter {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 2px;
  height: 5px;
}
.ui-mdp__seg {
  border-radius: 1.5px;
  background: var(--ui-mdp-bar-off);
  transition:
    background-color 180ms ease,
    transform 260ms var(--ui-mdp-ease);
}
.ui-mdp__seg[data-on] {
  background: var(--ui-mdp-bar);
}
.ui-mdp__option[data-lit] .ui-mdp__seg[data-on] {
  background: var(--ui-mdp-ink);
  transition-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
  animation: ui-mdp-fill 360ms var(--ui-mdp-ease) both;
  animation-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
}
.ui-mdp__varies {
  flex: none;
  width: 118px;
  font-size: 11.5px;
  color: var(--ui-mdp-muted);
  text-align: center;
}
.ui-mdp__settings {
  margin-top: 6px;
  padding-top: 6px;
  border-top: 1px solid var(--ui-mdp-line);
}
.ui-mdp__toggle {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 34px;
  padding: 0 10px;
  border-radius: 10px;
  color: var(--ui-mdp-text);
  transition: background-color 160ms ease;
}
.ui-mdp__toggle:hover {
  background: var(--ui-mdp-well);
}
.ui-mdp__toggle-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  color: var(--ui-mdp-muted);
  transition: color 200ms ease;
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__toggle-icon {
  color: var(--ui-mdp-ink);
}
.ui-mdp__toggle-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__switch {
  position: relative;
  flex: none;
  width: 28px;
  height: 16px;
  border-radius: 8px;
  background: var(--ui-mdp-switch);
  transition: background-color 220ms ease;
}
.ui-mdp__switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--ui-mdp-knob);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
  transition: transform 280ms var(--ui-mdp-ease);
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__switch {
  background: var(--ui-mdp-ink);
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__switch::after {
  transform: translateX(12px);
}
.ui-mdp__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mdp-ease),
    opacity 220ms ease;
}
.ui-mdp__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mdp-ease),
    opacity 320ms ease 100ms;
}
.ui-mdp__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mdp__effort {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 2px 10px 6px 42px;
}
.ui-mdp__effort-label {
  flex: 1;
  min-width: 0;
  font-size: 12.5px;
  color: var(--ui-mdp-muted);
}
.ui-mdp__segmented {
  position: relative;
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 58px);
  padding: 2px;
  border-radius: 9px;
  background: var(--ui-mdp-well);
  box-shadow: inset 0 0 0 1px var(--ui-mdp-line);
}
.ui-mdp__thumb {
  position: absolute;
  top: 2px;
  bottom: 2px;
  left: 2px;
  width: 58px;
  border-radius: 7px;
  background: var(--ui-mdp-card);
  box-shadow:
    0 0 0 1px var(--ui-mdp-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  transform: translateX(calc(var(--i) * 100%));
  transition: transform 320ms var(--ui-mdp-ease);
}
.ui-mdp__seg-btn {
  position: relative;
  height: 24px;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-mdp-muted);
  text-align: center !important;
  transition: color 200ms ease;
}
.ui-mdp__seg-btn[aria-checked="true"] {
  color: var(--ui-mdp-ink);
}
.ui-mdp__seg-btn:hover {
  color: var(--ui-mdp-ink);
}
.ui-mdp__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 38px;
  padding: 4px 8px 0 12px;
}
.ui-mdp__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-mdp-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mdp__dot {
  color: var(--ui-mdp-muted);
}
.ui-mdp__swap {
  display: grid;
  min-width: 0;
}
.ui-mdp__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  animation: ui-mdp-swap-in 320ms ease both;
}
.ui-mdp__swap-item[data-out] {
  animation: ui-mdp-swap-out 220ms ease both;
}
.ui-mdp__caption .ui-mdp__swap-item {
  display: -webkit-box;
  white-space: normal;
  text-overflow: clip;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-mdp__keys {
  display: flex;
  flex: none;
  gap: 3px;
}
.ui-mdp__keys kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-mdp-card);
  box-shadow: 0 0 0 1px var(--ui-mdp-line);
  font-family: inherit;
  font-size: 10.5px;
  line-height: 1;
  color: var(--ui-mdp-muted);
}
@keyframes ui-mdp-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdp-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdp-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-mdp-fill {
  0% {
    transform: scaleY(1);
  }
  45% {
    transform: scaleY(1.6);
  }
  100% {
    transform: scaleY(1);
  }
}
@container (max-width: 300px) {
  .ui-mdp__option .ui-mdp__glyph {
    display: none;
  }
  .ui-mdp__cols,
  .ui-mdp__bars {
    grid-template-columns: repeat(3, 30px);
    gap: 6px;
  }
  .ui-mdp__varies {
    width: 102px;
  }
  .ui-mdp__keys {
    display: none;
  }
  .ui-mdp__effort {
    padding-left: 10px;
  }
  .ui-mdp__segmented {
    grid-template-columns: repeat(3, 52px);
  }
  .ui-mdp__thumb {
    width: 52px;
  }
}
@media (pointer: coarse) {
  .ui-mdp__trigger {
    height: 36px;
  }
  .ui-mdp__option {
    min-height: 54px;
  }
  .ui-mdp__toggle {
    height: 42px;
  }
  .ui-mdp__seg-btn {
    height: 30px;
  }
  .ui-mdp__keys {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mdp *,
  .ui-mdp *::before,
  .ui-mdp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mdp {
  --ui-mdp-tray: #111113;
  --ui-mdp-card: #19191b;
  --ui-mdp-line: #2a2a2e;
  --ui-mdp-ink: #ededed;
  --ui-mdp-text: #c8c8cc;
  --ui-mdp-muted: #8b8b92;
  --ui-mdp-well: #222225;
  --ui-mdp-bar: #55555c;
  --ui-mdp-bar-off: #303035;
  --ui-mdp-switch: #3a3a40;
  --ui-mdp-knob: #ededed;
  --ui-mdp-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-mdp__pop {
  box-shadow:
    0 0 0 1px #222225,
    0 12px 32px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"])
  .ui-mdp__toggle[aria-checked="true"]
  .ui-mdp__switch::after {
  background: #19191b;
}

.ui-mdpc {
  --ui-mdpc-card: #ffffff;
  --ui-mdpc-strong: #000000;
  --ui-mdpc-ink: rgba(0, 0, 0, 0.88);
  --ui-mdpc-text: rgba(0, 0, 0, 0.65);
  --ui-mdpc-muted: rgba(0, 0, 0, 0.65);
  --ui-mdpc-faint: rgba(0, 0, 0, 0.65);
  --ui-mdpc-icon: rgba(0, 0, 0, 0.65);
  --ui-mdpc-line: rgba(0, 0, 0, 0.06);
  --ui-mdpc-line-strong: rgba(0, 0, 0, 0.1);
  --ui-mdpc-fill: rgba(0, 0, 0, 0.06);
  --ui-mdpc-wash: rgba(0, 0, 0, 0.03);
  --ui-mdpc-bar: rgba(0, 0, 0, 0.2);
  --ui-mdpc-bar-off: rgba(0, 0, 0, 0.06);
  --ui-mdpc-switch: rgba(0, 0, 0, 0.1);
  --ui-mdpc-knob: #ffffff;
  --ui-mdpc-accent: #0060e2;
  --ui-mdpc-focus: rgba(0, 96, 226, 0.7);
  --ui-mdpc-shadow-tile:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 1px -1px rgba(0, 0, 0, 0.1);
  --ui-mdpc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-mdpc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  min-width: 0;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-mdpc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mdpc *,
.ui-mdpc *::before,
.ui-mdpc *::after {
  box-sizing: border-box;
}
:where(.ui-mdpc) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-mdpc button:focus-visible {
  outline: 2px solid var(--ui-mdpc-focus);
  outline-offset: 2px;
}
.ui-mdpc svg {
  display: block;
  flex: none;
}
.ui-mdpc b {
  font-weight: 500;
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-mdpc__trigger {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  padding: 0 6px 0 6px;
  border-radius: 6px;
  font-weight: 500;
  color: var(--ui-mdpc-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-mdpc__trigger:hover,
.ui-mdpc[data-open] .ui-mdpc__trigger {
  background: var(--ui-mdpc-wash);
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__trigger .ui-mdpc__glyph {
  width: 18px;
  height: 18px;
  border-radius: 5px;
  font-size: 10px;
}
.ui-mdpc__trigger .ui-mdpc__glyph > svg {
  width: 10px;
  height: 10px;
}
.ui-mdpc__name {
  display: grid;
  min-width: 0;
}
.ui-mdpc__chevron {
  margin-left: -2px;
  color: var(--ui-mdpc-icon);
  transition: transform 300ms var(--ui-mdpc-ease);
}
.ui-mdpc[data-open] .ui-mdpc__chevron {
  transform: rotate(180deg);
}
.ui-mdpc__flag {
  display: grid;
  grid-template-columns: 0fr;
  margin-left: -6px;
  opacity: 0;
  color: var(--ui-mdpc-accent);
  transition:
    grid-template-columns 360ms var(--ui-mdpc-ease),
    margin 360ms var(--ui-mdpc-ease),
    opacity 220ms ease;
}
.ui-mdpc__flag > span {
  min-width: 0;
  overflow: hidden;
}
.ui-mdpc__flag[data-on] {
  grid-template-columns: 1fr;
  margin-left: -2px;
  opacity: 1;
  transition:
    grid-template-columns 360ms var(--ui-mdpc-ease),
    margin 360ms var(--ui-mdpc-ease),
    opacity 280ms ease 80ms;
}
.ui-mdpc__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-mdpc-card);
  box-shadow: var(--ui-mdpc-shadow-tile);
  font-size: 10px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-mdpc-strong);
}
.ui-mdpc__glyph > svg,
.ui-mdpc__glyph > img {
  width: 12px;
  height: 12px;
}
.ui-mdpc__pop {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  width: min(320px, calc(100vw - 32px));
  container-type: inline-size;
  border-radius: 10px;
  background: var(--ui-mdpc-card);
  box-shadow: var(--ui-mdpc-shadow-pop);
  transform-origin: top left;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-4px) scale(0.96);
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-mdpc-ease),
    visibility 0s linear 220ms;
}
.ui-mdpc[data-align="end"] .ui-mdpc__pop {
  left: auto;
  right: 0;
  transform-origin: top right;
}
.ui-mdpc[data-side="top"] .ui-mdpc__pop {
  top: auto;
  bottom: calc(100% + 6px);
  transform-origin: bottom left;
  transform: translateY(4px) scale(0.96);
}
.ui-mdpc[data-side="top"][data-align="end"] .ui-mdpc__pop {
  transform-origin: bottom right;
}
.ui-mdpc[data-open] .ui-mdpc__pop {
  opacity: 1;
  visibility: visible;
  transform: none;
  transition:
    opacity 200ms ease,
    transform 320ms var(--ui-mdpc-ease),
    visibility 0s;
}
.ui-mdpc__card {
  padding: 4px;
}
.ui-mdpc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 28px;
  padding: 4px 8px 0;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-mdpc-muted);
}
.ui-mdpc__cols {
  display: grid;
  grid-template-columns: repeat(3, 40px);
  gap: 8px;
}
.ui-mdpc__cols > span {
  display: flex;
  justify-content: center;
  white-space: nowrap;
}
.ui-mdpc__list {
  display: grid;
  gap: 0;
  border-radius: 6px;
  outline: none;
  position: relative;
  max-height: min(360px, 50vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-mdpc__empty {
  padding: 14px 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  text-align: center;
}
.ui-mdpc__option {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
  padding: 6px 8px;
  border-radius: 6px;
  cursor: pointer;
  transition:
    background-color 90ms ease-out,
    opacity 200ms ease;
}
.ui-mdpc__list[data-pointing] .ui-mdpc__option[data-active] {
  background: var(--ui-mdpc-fill);
}
.ui-mdpc__list:focus-visible {
  outline: none;
}
.ui-mdpc__list:focus-visible .ui-mdpc__option[data-active] {
  background: var(--ui-mdpc-fill);
  outline: 2px solid var(--ui-mdpc-focus);
  outline-offset: -2px;
}
.ui-mdpc__list[data-pointing] .ui-mdpc__option:not([data-active]) {
  opacity: 0.55;
}
.ui-mdpc__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-mdpc__title {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-mdpc-strong);
}
.ui-mdpc__title-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__check {
  color: var(--ui-mdpc-accent);
  animation: ui-mdpc-pop 320ms var(--ui-mdpc-ease) both;
}
.ui-mdpc__desc {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__bars {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 40px);
  gap: 8px;
}
.ui-mdpc__meter {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 2px;
  height: 4px;
}
.ui-mdpc__seg {
  border-radius: 1px;
  background: var(--ui-mdpc-bar-off);
  transition:
    background-color 180ms ease,
    transform 260ms var(--ui-mdpc-ease);
}
.ui-mdpc__seg[data-on] {
  background: var(--ui-mdpc-bar);
}
.ui-mdpc__option[data-lit] .ui-mdpc__seg[data-on] {
  background: var(--ui-mdpc-accent);
  transition-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
  animation: ui-mdpc-fill 360ms var(--ui-mdpc-ease) both;
  animation-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
}
.ui-mdpc__varies {
  flex: none;
  width: 136px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  text-align: center;
}
.ui-mdpc__settings {
  margin: 4px -4px 0;
  padding: 4px 4px 0;
  border-top: 0.5px solid var(--ui-mdpc-line);
}
.ui-mdpc__toggle {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 32px;
  padding: 0 8px;
  border-radius: 6px;
  color: var(--ui-mdpc-ink);
  transition: background-color 90ms ease-out;
}
.ui-mdpc__toggle:hover {
  background: var(--ui-mdpc-fill);
}
.ui-mdpc__toggle-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  color: var(--ui-mdpc-icon);
  transition: color 200ms ease;
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__toggle-icon {
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__toggle-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__switch {
  position: relative;
  flex: none;
  width: 26px;
  height: 16px;
  border-radius: 5px;
  background: var(--ui-mdpc-switch);
  transition: background-color 220ms ease;
}
.ui-mdpc__switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 3.5px;
  background: var(--ui-mdpc-knob);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06),
    0 1px 2px rgba(0, 0, 0, 0.16);
  transition: transform 280ms var(--ui-mdpc-ease);
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__switch {
  background: var(--ui-mdpc-accent);
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__switch::after {
  transform: translateX(10px);
}
.ui-mdpc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mdpc-ease),
    opacity 220ms ease;
}
.ui-mdpc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mdpc-ease),
    opacity 320ms ease 100ms;
}
.ui-mdpc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mdpc__effort {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 2px 8px 6px 38px;
}
.ui-mdpc__effort-label {
  flex: 1;
  min-width: 0;
  color: var(--ui-mdpc-text);
}
.ui-mdpc__segmented {
  position: relative;
  display: flex;
  flex: none;
  gap: 4px;
}
.ui-mdpc__thumb {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: var(--w, 0);
  border-radius: 5px;
  background: var(--ui-mdpc-fill);
  transform: translateX(var(--x, 0));
  transition:
    transform 220ms var(--ui-mdpc-ease),
    width 220ms var(--ui-mdpc-ease);
}
.ui-mdpc__seg-btn {
  position: relative;
  height: 22px;
  padding: 0 7px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mdpc-line);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-mdpc-text);
  text-align: center !important;
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-mdpc__seg-btn[aria-checked="true"] {
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__seg-btn[aria-checked="false"]:hover {
  background: var(--ui-mdpc-wash);
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 36px;
  padding: 6px 8px 6px 12px;
  border-top: 0.5px solid var(--ui-mdpc-line);
}
.ui-mdpc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mdpc__dot {
  color: var(--ui-mdpc-faint);
}
.ui-mdpc__swap {
  display: grid;
  min-width: 0;
}
.ui-mdpc__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  animation: ui-mdpc-swap-in 320ms ease both;
}
.ui-mdpc__swap-item[data-out] {
  animation: ui-mdpc-swap-out 220ms ease both;
}
.ui-mdpc__caption .ui-mdpc__swap-item {
  display: -webkit-box;
  white-space: normal;
  text-overflow: clip;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-mdpc__keys {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-mdpc__keys kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mdpc-line-strong);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
}
@keyframes ui-mdpc-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdpc-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdpc-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-mdpc-fill {
  0% {
    transform: scaleY(1);
  }
  45% {
    transform: scaleY(1.6);
  }
  100% {
    transform: scaleY(1);
  }
}
@container (max-width: 300px) {
  .ui-mdpc__option .ui-mdpc__glyph {
    display: none;
  }
  .ui-mdpc__keys {
    display: none;
  }
  .ui-mdpc__effort {
    padding-left: 8px;
  }
}
@media (pointer: coarse) {
  .ui-mdpc__trigger {
    height: 34px;
  }
  .ui-mdpc__option {
    min-height: 52px;
  }
  .ui-mdpc__toggle {
    height: 40px;
  }
  .ui-mdpc__seg-btn {
    height: 30px;
    padding: 0 10px;
  }
  .ui-mdpc__keys {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mdpc *,
  .ui-mdpc *::before,
  .ui-mdpc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mdpc {
  --ui-mdpc-card: #1c1c1e;
  --ui-mdpc-strong: #ffffff;
  --ui-mdpc-ink: rgba(255, 255, 255, 0.9);
  --ui-mdpc-text: rgba(255, 255, 255, 0.62);
  --ui-mdpc-muted: rgba(255, 255, 255, 0.46);
  --ui-mdpc-faint: rgba(255, 255, 255, 0.3);
  --ui-mdpc-icon: rgba(255, 255, 255, 0.5);
  --ui-mdpc-line: rgba(255, 255, 255, 0.08);
  --ui-mdpc-line-strong: rgba(255, 255, 255, 0.12);
  --ui-mdpc-fill: rgba(255, 255, 255, 0.08);
  --ui-mdpc-wash: rgba(255, 255, 255, 0.04);
  --ui-mdpc-bar: rgba(255, 255, 255, 0.24);
  --ui-mdpc-bar-off: rgba(255, 255, 255, 0.08);
  --ui-mdpc-switch: rgba(255, 255, 255, 0.14);
  --ui-mdpc-knob: #ffffff;
  --ui-mdpc-accent: #4d8dff;
  --ui-mdpc-focus: rgba(77, 141, 255, 0.8);
  --ui-mdpc-shadow-tile:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-mdpc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-mdpc__glyph {
  background: #2a2a2d;
}
`;export{n as default};
