import{r as n,j as e}from"./workbench-model-C4LJxhar.js";const D=[{id:"low",label:"Low"},{id:"medium",label:"Medium"},{id:"high",label:"High"}],Si={low:1.6,medium:2.5,high:4},gi=[{key:"speed",label:"Speed"},{key:"quality",label:"Quality"},{key:"cost",label:"Cost"}];function X(i){return Number.isFinite(i)?Math.max(0,Math.min(5,Math.round(i))):0}function ci(i){return i!==void 0&&Number.isFinite(i)?i:void 0}function Ii(i=""){var r;return(((r=i.match(/[\p{L}\p{N}]/u))==null?void 0:r[0])??"").toUpperCase()}function ui(i){const r=Math.max(0,i)/1e3;if(r<60)return`${r.toFixed(1)}s`;const d=Math.floor(r/60),f=h=>String(h).padStart(2,"0");return d<60?`${d}m ${f(Math.floor(r%60))}s`:`${Math.floor(d/60)}h ${f(d%60)}m`}function li(i,r){if(r>0&&r<.01)return"<$0.01";const d=Number.isInteger(r)?0:2;return new Intl.NumberFormat("en-US",{style:"currency",currency:"USD",minimumFractionDigits:d,maximumFractionDigits:d}).format(i)}function Li({models:i,value:r,defaultValue:d,onChange:f,thinking:h,defaultThinking:b=!1,onThinkingChange:a,webSearch:l,defaultWebSearch:g=!1,onWebSearchChange:c,effort:j,defaultEffort:w="medium",onEffortChange:s,open:m,defaultOpen:_=!1,onOpenChange:k,align:v="start"},$){var di;const P=n.useId(),I=n.useRef(null),T=n.useRef(null),A=n.useRef(null),R=n.useRef(null),[L,Y]=n.useState(d??((di=i[0])==null?void 0:di.id)),[q,G]=n.useState(b),[Q,J]=n.useState(g),[C,ii]=n.useState(w),[ei,ti]=n.useState(_),H=r??L,z=h??q,O=l??Q,E=j??C,x=m??ei,M=Math.max(0,i.findIndex(t=>t.id===H)),U=i[M],[p,y]=n.useState(M),[ai,K]=n.useState(!1),[xi,ri]=n.useState(!1),_i=i[ai?p:M]??U;function B(t,o){var u;t!==x&&(t?(y(M),K(!1)):ri(!1),ti(t),k==null||k(t)),o==="list"&&requestAnimationFrame(()=>{var N;return(N=A.current)==null?void 0:N.focus({preventScroll:!0})}),o==="trigger"&&((u=T.current)==null||u.focus({preventScroll:!0}))}const oi=n.useRef(x);n.useEffect(()=>{x&&!oi.current&&(y(M),K(!1)),oi.current=x},[x,M]);const[bi,wi]=n.useState(0);n.useLayoutEffect(()=>{if(!x)return;function t(){var F,W;const o=(F=T.current)==null?void 0:F.getBoundingClientRect(),u=((W=R.current)==null?void 0:W.offsetWidth)??0;if(!o||!u)return;const N=document.documentElement.clientWidth,S=v==="end"?o.right-u:o.left;wi(S<12?12-S:S+u>N-12?Math.min(0,N-12-(S+u)):0)}return t(),window.addEventListener("resize",t),()=>window.removeEventListener("resize",t)},[x,v]),n.useEffect(()=>{if(!x)return;function t(o){var u;o.target instanceof Node&&!((u=I.current)!=null&&u.contains(o.target))&&B(!1)}return document.addEventListener("pointerdown",t),()=>document.removeEventListener("pointerdown",t)});function ni(t){var u;const o=i[t];o&&(Y(o.id),o.id!==H&&o.id!==void 0&&(f==null||f(o.id)),B(!1,(u=I.current)!=null&&u.contains(document.activeElement)?"trigger":void 0))}function vi(){G(!z),a==null||a(!z)}function yi(){J(!O),c==null||c(!O)}function pi(t){ii(t),t!==E&&(s==null||s(t))}const V=n.useRef({point:t=>{},pick:t=>{}});V.current.point=t=>{y(t),K(!0)},V.current.pick=ni;const ki=n.useCallback(t=>V.current.point(t),[]),$i=n.useCallback(t=>V.current.pick(t),[]);n.useEffect(()=>{const t=A.current,o=t==null?void 0:t.children[p];!x||!t||!(o instanceof HTMLElement)||(o.offsetTop<t.scrollTop?t.scrollTop=o.offsetTop:o.offsetTop+o.offsetHeight>t.scrollTop+t.clientHeight&&(t.scrollTop=o.offsetTop+o.offsetHeight-t.clientHeight))},[p,x]);function ji(t){t.key!=="ArrowDown"&&t.key!=="ArrowUp"||(t.preventDefault(),B(!0,"list"))}function Ni(t){const o=i.length;if(!o)return;function u(N){t.preventDefault(),y((N%o+o)%o),K(!0)}t.key==="ArrowDown"?u(p+1):t.key==="ArrowUp"?u(p-1):t.key==="Home"?u(0):t.key==="End"?u(o-1):(t.key==="Enter"||t.key===" ")&&(t.preventDefault(),ni(p))}const si=n.useRef(null),[Mi,zi]=n.useState(null);n.useLayoutEffect(()=>{var o;if(!$)return;const t=(o=si.current)==null?void 0:o.querySelector(`[data-effort="${E}"]`);t&&zi({x:t.offsetLeft,width:t.offsetWidth})},[$,E,x,z]);function Ri(t){var S,F;const o=D.findIndex(W=>W.id===E),u=t.key==="ArrowRight"||t.key==="ArrowDown"?1:t.key==="ArrowLeft"||t.key==="ArrowUp"?-1:0;if(!u)return;t.preventDefault();const N=D[(o+u+D.length)%D.length];pi(N.id),(F=(S=I.current)==null?void 0:S.querySelector(`[data-effort="${N.id}"]`))==null||F.focus()}function Ei(t){t.key!=="Escape"||!x||(t.stopPropagation(),B(!1,"trigger"))}return{id:P,rootRef:I,triggerRef:T,listRef:A,panelRef:R,selectedModel:U,selectedIndex:M,thinkingEnabled:z,searchEnabled:O,selectedEffort:E,isOpen:x,activeIndex:p,pointing:ai,setPointing:K,searchPreview:xi,setSearchPreview:ri,previewModel:_i,setOpen:B,horizontalOffset:bi,toggleThinking:vi,toggleSearch:yi,chooseEffort:pi,pointOption:ki,pickOption:$i,handleTriggerKeyDown:ji,handleListKeyDown:Ni,effortRef:si,effortBounds:Mi,handleEffortKeyDown:Ri,handleRootKeyDown:Ei}}function Di(i,r=560){const[d,f]=n.useState(i),h=n.useRef(i),{latency:b,price:a}=i;return n.useEffect(()=>{const l={latency:b,price:a},g={...h.current};if(typeof window<"u"&&window.matchMedia("(prefers-reduced-motion: reduce)").matches||g.latency===b&&g.price===a){h.current=l,f(l);return}const j=performance.now();let w=0;function s(m){const _=Math.min(1,(m-j)/r),k=1-(1-_)**4,v={latency:g.latency+(b-g.latency)*k,price:g.price+(a-g.price)*k};h.current=v,f(v),_<1&&(w=requestAnimationFrame(s))}return w=requestAnimationFrame(s),()=>cancelAnimationFrame(w)},[b,a,r]),d}function Pi(i,r,d,f,h,b){const a=ci(i==null?void 0:i.latencyMs),l=ci(i==null?void 0:i.pricePerM),g=(a??0)*(r?Si[d]:1),c=l??0,j=Di({latency:g,price:c});if(f){const m=h?"Looks things up on the web when it helps":"Answers from what it already knows";return{content:m,id:`search-${h}`,announcement:m}}if(a===void 0&&l===void 0){const m=(i==null?void 0:i.description)??(i==null?void 0:i.name)??"";return{content:m,id:`plain-${i==null?void 0:i.id}`,announcement:`${(i==null?void 0:i.name)??""}: ${m}`}}const w=[],s=[];return a!==void 0&&(w.push(e.jsxs("span",{children:["~",e.jsx("b",{children:ui(j.latency)})," first token"]},"l")),s.push(`about ${ui(g)} to the first token`)),l!==void 0&&(w.push(e.jsxs("span",{children:[e.jsx("b",{children:li(j.price,c)})," / M tokens"]},"p")),s.push(`${li(c,c)} per million tokens`)),{content:w.flatMap((m,_)=>_?[e.jsx("span",{className:`${b}__dot`,children:" · "},`d${_}`),m]:[m]),id:"stats",announcement:`${i==null?void 0:i.name}: ${s.join(", ")}`}}function mi({id:i,children:r,prefix:d}){const f=n.useRef({id:i,node:r}),[h,b]=n.useState(i),[a,l]=n.useState(null);return h!==i&&(b(i),l(f.current)),f.current={id:i,node:r},n.useEffect(()=>{if(!a)return;const g=window.setTimeout(()=>l(null),260);return()=>window.clearTimeout(g)},[a]),e.jsxs("span",{className:`${d}__swap`,children:[a&&e.jsx("span",{className:`${d}__swap-item`,"data-out":"","aria-hidden":"true",children:a.node},`out-${a.id}`),e.jsx("span",{className:`${d}__swap-item`,dir:"auto",children:r},i)]})}const Z=i=>({stroke:"currentColor",strokeWidth:i?1.2:1.4,strokeLinecap:"round",strokeLinejoin:"round"});function Ti({clean:i,prefix:r}){return e.jsx("svg",{className:`${r}__chevron`,width:i?"14":"12",height:i?"14":"12",viewBox:"0 0 12 12",fill:"none","aria-hidden":"true",children:e.jsx("path",{d:"m3 4.5 3 3 3-3",...Z(i)})})}function Ai({clean:i,prefix:r}){return e.jsx("svg",{className:`${r}__check`,width:i?"16":"14",height:i?"16":"14",viewBox:"0 0 14 14",fill:"none","aria-hidden":"true",children:e.jsx("path",{d:"m3.4 7.3 2.4 2.4 4.8-5.2",...Z(i),strokeWidth:i?1.3:1.6})})}function fi({clean:i}){return e.jsx("svg",{width:i?"16":"14",height:i?"16":"14",viewBox:"0 0 14 14",fill:"none","aria-hidden":"true",children:e.jsx("path",{d:"M5.3 10.6h3.4M5.8 12.3h2.4M7 1.7a3.9 3.9 0 0 0-2.3 7c.4.3.6.7.6 1.1v.1h3.4v-.1c0-.4.2-.8.6-1.1A3.9 3.9 0 0 0 7 1.7Z",...Z(i)})})}function Oi({clean:i}){return e.jsxs("svg",{width:i?"16":"14",height:i?"16":"14",viewBox:"0 0 14 14",fill:"none","aria-hidden":"true",children:[e.jsx("circle",{cx:"7",cy:"7",r:"5.3",stroke:"currentColor",strokeWidth:i?1.2:1.4,strokeLinecap:"round",strokeLinejoin:"round"}),e.jsx("path",{d:"M1.9 7h10.2M7 1.7c1.4 1.5 2 3.3 2 5.3s-.6 3.8-2 5.3c-1.4-1.5-2-3.3-2-5.3s.6-3.8 2-5.3Z",...Z(i)})]})}function hi({model:i,prefix:r}){return e.jsx("span",{className:`${r}__glyph`,"aria-hidden":"true",children:i.icon??Ii(i.name)})}const Ki=n.memo(function({model:r,index:d,optionId:f,selected:h,active:b,lit:a,onPoint:l,onPick:g,prefix:c,clean:j}){const w=r.speed!==void 0||r.quality!==void 0||r.cost!==void 0,s=`${r.name}${r.description?`, ${r.description}`:""}${w?`. Speed ${X(r.speed??0)}, quality ${X(r.quality??0)}, cost ${X(r.cost??0)} of 5`:""}`;return e.jsxs("div",{id:f,role:"option","aria-selected":h,"aria-label":s,className:`${c}__option`,"data-active":b?"":void 0,"data-lit":a?"":void 0,onPointerEnter:m=>{m.pointerType==="mouse"&&l(d)},onClick:()=>g(d),children:[e.jsx(hi,{model:r,prefix:c}),e.jsxs("span",{className:`${c}__text`,children:[e.jsxs("span",{className:`${c}__title`,children:[e.jsx("span",{className:`${c}__title-name`,dir:"auto",title:r.name,children:r.name}),h&&e.jsx(Ai,{clean:j,prefix:c})]}),r.description&&e.jsx("span",{className:`${c}__desc`,dir:"auto",title:r.description,children:r.description})]}),w?e.jsx("span",{className:`${c}__bars`,"aria-hidden":"true",children:gi.map((m,_)=>{const k=X(r[m.key]??0);return e.jsx("span",{className:`${c}__meter`,style:{"--c":_},children:[0,1,2,3,4].map(v=>e.jsx("span",{className:`${c}__seg`,"data-on":v<k?"":void 0,style:{"--s":v}},v))},m.key)})}):e.jsx("span",{className:`${c}__varies`,"aria-hidden":"true",children:"Varies"})]})}),Bi=`
.ui-mdp {
  --ui-mdp-tray: #f0f0f0;
  --ui-mdp-card: #ffffff;
  --ui-mdp-line: #ececec;
  --ui-mdp-ink: #171717;
  --ui-mdp-text: #404040;
  --ui-mdp-muted: #626873;
  --ui-mdp-well: #f4f4f5;
  --ui-mdp-bar: #d4d4d9;
  --ui-mdp-bar-off: #e6e6ea;
  --ui-mdp-switch: #dcdce0;
  --ui-mdp-knob: #ffffff;
  --ui-mdp-focus: rgba(0, 96, 226, 0.7);
  --ui-mdp-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  min-width: 0;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-mdp-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mdp *,
.ui-mdp *::before,
.ui-mdp *::after {
  box-sizing: border-box;
}
:where(.ui-mdp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-mdp button:focus-visible,
.ui-mdp__list:focus-visible {
  outline: 2px solid var(--ui-mdp-focus);
  outline-offset: 2px;
}
.ui-mdp svg {
  display: block;
  flex: none;
}
.ui-mdp b {
  font-weight: 500;
  color: var(--ui-mdp-ink);
}
.ui-mdp__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-mdp__trigger {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  max-width: 100%;
  height: 30px;
  padding: 0 8px 0 6px;
  border-radius: 10px;
  font-weight: 500;
  color: var(--ui-mdp-ink);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-mdp__trigger:hover,
.ui-mdp[data-open] .ui-mdp__trigger {
  background: var(--ui-mdp-well);
}
.ui-mdp__trigger .ui-mdp__glyph {
  width: 18px;
  height: 18px;
}
.ui-mdp__name {
  display: grid;
  min-width: 0;
}
.ui-mdp__chevron {
  color: var(--ui-mdp-muted);
  transition: transform 300ms var(--ui-mdp-ease);
}
.ui-mdp[data-open] .ui-mdp__chevron {
  transform: rotate(180deg);
}
.ui-mdp__flag {
  display: grid;
  grid-template-columns: 0fr;
  margin-left: -7px;
  opacity: 0;
  color: var(--ui-mdp-muted);
  transition:
    grid-template-columns 360ms var(--ui-mdp-ease),
    margin 360ms var(--ui-mdp-ease),
    opacity 220ms ease;
}
.ui-mdp__flag > span {
  min-width: 0;
  overflow: hidden;
}
.ui-mdp__flag[data-on] {
  grid-template-columns: 1fr;
  margin-left: -3px;
  opacity: 1;
  transition:
    grid-template-columns 360ms var(--ui-mdp-ease),
    margin 360ms var(--ui-mdp-ease),
    opacity 280ms ease 80ms;
}
.ui-mdp__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-mdp-card);
  box-shadow: inset 0 0 0 1px var(--ui-mdp-line);
  font-size: 10.5px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-mdp-ink);
}
.ui-mdp__glyph > svg,
.ui-mdp__glyph > img {
  width: 12px;
  height: 12px;
}
.ui-mdp__pop {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  width: min(320px, calc(100vw - 32px));
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-mdp-tray);
  box-shadow:
    0 12px 32px -12px rgba(0, 0, 0, 0.16),
    0 2px 6px rgba(0, 0, 0, 0.04);
  transform-origin: top left;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-4px) scale(0.96);
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-mdp-ease),
    visibility 0s linear 220ms;
}
.ui-mdp[data-align="end"] .ui-mdp__pop {
  left: auto;
  right: 0;
  transform-origin: top right;
}
.ui-mdp[data-side="top"] .ui-mdp__pop {
  top: auto;
  bottom: calc(100% + 6px);
  transform-origin: bottom left;
  transform: translateY(4px) scale(0.96);
}
.ui-mdp[data-side="top"][data-align="end"] .ui-mdp__pop {
  transform-origin: bottom right;
}
.ui-mdp[data-open] .ui-mdp__pop {
  opacity: 1;
  visibility: visible;
  transform: none;
  transition:
    opacity 200ms ease,
    transform 320ms var(--ui-mdp-ease),
    visibility 0s;
}
.ui-mdp__card {
  padding: 6px;
  border-radius: 16px;
  background: var(--ui-mdp-card);
  box-shadow:
    0 0 0 1px var(--ui-mdp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-mdp__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 24px;
  padding: 0 10px;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-mdp-muted);
}
.ui-mdp__cols {
  display: grid;
  grid-template-columns: repeat(3, 34px);
  gap: 8px;
}
.ui-mdp__cols > span {
  display: flex;
  justify-content: center;
  white-space: nowrap;
}
.ui-mdp__list {
  display: grid;
  gap: 1px;
  border-radius: 10px;
  position: relative;
  max-height: min(360px, 50vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-mdp__empty {
  padding: 14px 10px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdp-muted);
  text-align: center;
}
.ui-mdp__option {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 48px;
  padding: 6px 10px;
  border-radius: 10px;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    opacity 220ms ease;
}
.ui-mdp__list[data-pointing] .ui-mdp__option[data-active] {
  background: var(--ui-mdp-well);
}
.ui-mdp__list:focus-visible {
  outline: none;
}
.ui-mdp__list:focus-visible .ui-mdp__option[data-active] {
  background: var(--ui-mdp-well);
  outline: 2px solid var(--ui-mdp-focus);
  outline-offset: -2px;
}
.ui-mdp__list[data-pointing] .ui-mdp__option:not([data-active]) {
  opacity: 0.5;
}
.ui-mdp__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-mdp__title {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-mdp-ink);
}
.ui-mdp__title-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__check {
  color: var(--ui-mdp-ink);
  animation: ui-mdp-pop 320ms var(--ui-mdp-ease) both;
}
.ui-mdp__desc {
  overflow: hidden;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-mdp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__bars {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 34px);
  gap: 8px;
}
.ui-mdp__meter {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 2px;
  height: 5px;
}
.ui-mdp__seg {
  border-radius: 1.5px;
  background: var(--ui-mdp-bar-off);
  transition:
    background-color 180ms ease,
    transform 260ms var(--ui-mdp-ease);
}
.ui-mdp__seg[data-on] {
  background: var(--ui-mdp-bar);
}
.ui-mdp__option[data-lit] .ui-mdp__seg[data-on] {
  background: var(--ui-mdp-ink);
  transition-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
  animation: ui-mdp-fill 360ms var(--ui-mdp-ease) both;
  animation-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
}
.ui-mdp__varies {
  flex: none;
  width: 118px;
  font-size: 11.5px;
  color: var(--ui-mdp-muted);
  text-align: center;
}
.ui-mdp__settings {
  margin-top: 6px;
  padding-top: 6px;
  border-top: 1px solid var(--ui-mdp-line);
}
.ui-mdp__toggle {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 34px;
  padding: 0 10px;
  border-radius: 10px;
  color: var(--ui-mdp-text);
  transition: background-color 160ms ease;
}
.ui-mdp__toggle:hover {
  background: var(--ui-mdp-well);
}
.ui-mdp__toggle-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  color: var(--ui-mdp-muted);
  transition: color 200ms ease;
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__toggle-icon {
  color: var(--ui-mdp-ink);
}
.ui-mdp__toggle-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdp__switch {
  position: relative;
  flex: none;
  width: 28px;
  height: 16px;
  border-radius: 8px;
  background: var(--ui-mdp-switch);
  transition: background-color 220ms ease;
}
.ui-mdp__switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: var(--ui-mdp-knob);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.18);
  transition: transform 280ms var(--ui-mdp-ease);
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__switch {
  background: var(--ui-mdp-ink);
}
.ui-mdp__toggle[aria-checked="true"] .ui-mdp__switch::after {
  transform: translateX(12px);
}
.ui-mdp__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mdp-ease),
    opacity 220ms ease;
}
.ui-mdp__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mdp-ease),
    opacity 320ms ease 100ms;
}
.ui-mdp__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mdp__effort {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 2px 10px 6px 42px;
}
.ui-mdp__effort-label {
  flex: 1;
  min-width: 0;
  font-size: 12.5px;
  color: var(--ui-mdp-muted);
}
.ui-mdp__segmented {
  position: relative;
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 58px);
  padding: 2px;
  border-radius: 9px;
  background: var(--ui-mdp-well);
  box-shadow: inset 0 0 0 1px var(--ui-mdp-line);
}
.ui-mdp__thumb {
  position: absolute;
  top: 2px;
  bottom: 2px;
  left: 2px;
  width: 58px;
  border-radius: 7px;
  background: var(--ui-mdp-card);
  box-shadow:
    0 0 0 1px var(--ui-mdp-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  transform: translateX(calc(var(--i) * 100%));
  transition: transform 320ms var(--ui-mdp-ease);
}
.ui-mdp__seg-btn {
  position: relative;
  height: 24px;
  border-radius: 7px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-mdp-muted);
  text-align: center !important;
  transition: color 200ms ease;
}
.ui-mdp__seg-btn[aria-checked="true"] {
  color: var(--ui-mdp-ink);
}
.ui-mdp__seg-btn:hover {
  color: var(--ui-mdp-ink);
}
.ui-mdp__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 38px;
  padding: 4px 8px 0 12px;
}
.ui-mdp__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-mdp-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mdp__dot {
  color: var(--ui-mdp-muted);
}
.ui-mdp__swap {
  display: grid;
  min-width: 0;
}
.ui-mdp__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  animation: ui-mdp-swap-in 320ms ease both;
}
.ui-mdp__swap-item[data-out] {
  animation: ui-mdp-swap-out 220ms ease both;
}
.ui-mdp__caption .ui-mdp__swap-item {
  display: -webkit-box;
  white-space: normal;
  text-overflow: clip;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-mdp__keys {
  display: flex;
  flex: none;
  gap: 3px;
}
.ui-mdp__keys kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-mdp-card);
  box-shadow: 0 0 0 1px var(--ui-mdp-line);
  font-family: inherit;
  font-size: 10.5px;
  line-height: 1;
  color: var(--ui-mdp-muted);
}
@keyframes ui-mdp-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdp-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdp-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-mdp-fill {
  0% {
    transform: scaleY(1);
  }
  45% {
    transform: scaleY(1.6);
  }
  100% {
    transform: scaleY(1);
  }
}
@container (max-width: 300px) {
  .ui-mdp__option .ui-mdp__glyph {
    display: none;
  }
  .ui-mdp__cols,
  .ui-mdp__bars {
    grid-template-columns: repeat(3, 30px);
    gap: 6px;
  }
  .ui-mdp__varies {
    width: 102px;
  }
  .ui-mdp__keys {
    display: none;
  }
  .ui-mdp__effort {
    padding-left: 10px;
  }
  .ui-mdp__segmented {
    grid-template-columns: repeat(3, 52px);
  }
  .ui-mdp__thumb {
    width: 52px;
  }
}
@media (pointer: coarse) {
  .ui-mdp__trigger {
    height: 36px;
  }
  .ui-mdp__option {
    min-height: 54px;
  }
  .ui-mdp__toggle {
    height: 42px;
  }
  .ui-mdp__seg-btn {
    height: 30px;
  }
  .ui-mdp__keys {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mdp *,
  .ui-mdp *::before,
  .ui-mdp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mdp {
  --ui-mdp-tray: #111113;
  --ui-mdp-card: #19191b;
  --ui-mdp-line: #2a2a2e;
  --ui-mdp-ink: #ededed;
  --ui-mdp-text: #c8c8cc;
  --ui-mdp-muted: #8b8b92;
  --ui-mdp-well: #222225;
  --ui-mdp-bar: #55555c;
  --ui-mdp-bar-off: #303035;
  --ui-mdp-switch: #3a3a40;
  --ui-mdp-knob: #ededed;
  --ui-mdp-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-mdp__pop {
  box-shadow:
    0 0 0 1px #222225,
    0 12px 32px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"])
  .ui-mdp__toggle[aria-checked="true"]
  .ui-mdp__switch::after {
  background: #19191b;
}
`,Fi=`
.ui-mdpc {
  --ui-mdpc-card: #ffffff;
  --ui-mdpc-strong: #000000;
  --ui-mdpc-ink: rgba(0, 0, 0, 0.88);
  --ui-mdpc-text: rgba(0, 0, 0, 0.65);
  --ui-mdpc-muted: rgba(0, 0, 0, 0.65);
  --ui-mdpc-faint: rgba(0, 0, 0, 0.65);
  --ui-mdpc-icon: rgba(0, 0, 0, 0.65);
  --ui-mdpc-line: rgba(0, 0, 0, 0.06);
  --ui-mdpc-line-strong: rgba(0, 0, 0, 0.1);
  --ui-mdpc-fill: rgba(0, 0, 0, 0.06);
  --ui-mdpc-wash: rgba(0, 0, 0, 0.03);
  --ui-mdpc-bar: rgba(0, 0, 0, 0.2);
  --ui-mdpc-bar-off: rgba(0, 0, 0, 0.06);
  --ui-mdpc-switch: rgba(0, 0, 0, 0.1);
  --ui-mdpc-knob: #ffffff;
  --ui-mdpc-accent: #0060e2;
  --ui-mdpc-focus: rgba(0, 96, 226, 0.7);
  --ui-mdpc-shadow-tile:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 1px -1px rgba(0, 0, 0, 0.1);
  --ui-mdpc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-mdpc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  min-width: 0;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-mdpc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-mdpc *,
.ui-mdpc *::before,
.ui-mdpc *::after {
  box-sizing: border-box;
}
:where(.ui-mdpc) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-mdpc button:focus-visible {
  outline: 2px solid var(--ui-mdpc-focus);
  outline-offset: 2px;
}
.ui-mdpc svg {
  display: block;
  flex: none;
}
.ui-mdpc b {
  font-weight: 500;
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-mdpc__trigger {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  padding: 0 6px 0 6px;
  border-radius: 6px;
  font-weight: 500;
  color: var(--ui-mdpc-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-mdpc__trigger:hover,
.ui-mdpc[data-open] .ui-mdpc__trigger {
  background: var(--ui-mdpc-wash);
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__trigger .ui-mdpc__glyph {
  width: 18px;
  height: 18px;
  border-radius: 5px;
  font-size: 10px;
}
.ui-mdpc__trigger .ui-mdpc__glyph > svg {
  width: 10px;
  height: 10px;
}
.ui-mdpc__name {
  display: grid;
  min-width: 0;
}
.ui-mdpc__chevron {
  margin-left: -2px;
  color: var(--ui-mdpc-icon);
  transition: transform 300ms var(--ui-mdpc-ease);
}
.ui-mdpc[data-open] .ui-mdpc__chevron {
  transform: rotate(180deg);
}
.ui-mdpc__flag {
  display: grid;
  grid-template-columns: 0fr;
  margin-left: -6px;
  opacity: 0;
  color: var(--ui-mdpc-accent);
  transition:
    grid-template-columns 360ms var(--ui-mdpc-ease),
    margin 360ms var(--ui-mdpc-ease),
    opacity 220ms ease;
}
.ui-mdpc__flag > span {
  min-width: 0;
  overflow: hidden;
}
.ui-mdpc__flag[data-on] {
  grid-template-columns: 1fr;
  margin-left: -2px;
  opacity: 1;
  transition:
    grid-template-columns 360ms var(--ui-mdpc-ease),
    margin 360ms var(--ui-mdpc-ease),
    opacity 280ms ease 80ms;
}
.ui-mdpc__glyph {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-mdpc-card);
  box-shadow: var(--ui-mdpc-shadow-tile);
  font-size: 10px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-mdpc-strong);
}
.ui-mdpc__glyph > svg,
.ui-mdpc__glyph > img {
  width: 12px;
  height: 12px;
}
.ui-mdpc__pop {
  position: absolute;
  z-index: 30;
  top: calc(100% + 6px);
  left: 0;
  width: min(320px, calc(100vw - 32px));
  container-type: inline-size;
  border-radius: 10px;
  background: var(--ui-mdpc-card);
  box-shadow: var(--ui-mdpc-shadow-pop);
  transform-origin: top left;
  opacity: 0;
  visibility: hidden;
  transform: translateY(-4px) scale(0.96);
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-mdpc-ease),
    visibility 0s linear 220ms;
}
.ui-mdpc[data-align="end"] .ui-mdpc__pop {
  left: auto;
  right: 0;
  transform-origin: top right;
}
.ui-mdpc[data-side="top"] .ui-mdpc__pop {
  top: auto;
  bottom: calc(100% + 6px);
  transform-origin: bottom left;
  transform: translateY(4px) scale(0.96);
}
.ui-mdpc[data-side="top"][data-align="end"] .ui-mdpc__pop {
  transform-origin: bottom right;
}
.ui-mdpc[data-open] .ui-mdpc__pop {
  opacity: 1;
  visibility: visible;
  transform: none;
  transition:
    opacity 200ms ease,
    transform 320ms var(--ui-mdpc-ease),
    visibility 0s;
}
.ui-mdpc__card {
  padding: 4px;
}
.ui-mdpc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  height: 28px;
  padding: 4px 8px 0;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-mdpc-muted);
}
.ui-mdpc__cols {
  display: grid;
  grid-template-columns: repeat(3, 40px);
  gap: 8px;
}
.ui-mdpc__cols > span {
  display: flex;
  justify-content: center;
  white-space: nowrap;
}
.ui-mdpc__list {
  display: grid;
  gap: 0;
  border-radius: 6px;
  outline: none;
  position: relative;
  max-height: min(360px, 50vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-mdpc__empty {
  padding: 14px 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  text-align: center;
}
.ui-mdpc__option {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 44px;
  padding: 6px 8px;
  border-radius: 6px;
  cursor: pointer;
  transition:
    background-color 90ms ease-out,
    opacity 200ms ease;
}
.ui-mdpc__list[data-pointing] .ui-mdpc__option[data-active] {
  background: var(--ui-mdpc-fill);
}
.ui-mdpc__list:focus-visible {
  outline: none;
}
.ui-mdpc__list:focus-visible .ui-mdpc__option[data-active] {
  background: var(--ui-mdpc-fill);
  outline: 2px solid var(--ui-mdpc-focus);
  outline-offset: -2px;
}
.ui-mdpc__list[data-pointing] .ui-mdpc__option:not([data-active]) {
  opacity: 0.55;
}
.ui-mdpc__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-mdpc__title {
  display: flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-mdpc-strong);
}
.ui-mdpc__title-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__check {
  color: var(--ui-mdpc-accent);
  animation: ui-mdpc-pop 320ms var(--ui-mdpc-ease) both;
}
.ui-mdpc__desc {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__bars {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 40px);
  gap: 8px;
}
.ui-mdpc__meter {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 2px;
  height: 4px;
}
.ui-mdpc__seg {
  border-radius: 1px;
  background: var(--ui-mdpc-bar-off);
  transition:
    background-color 180ms ease,
    transform 260ms var(--ui-mdpc-ease);
}
.ui-mdpc__seg[data-on] {
  background: var(--ui-mdpc-bar);
}
.ui-mdpc__option[data-lit] .ui-mdpc__seg[data-on] {
  background: var(--ui-mdpc-accent);
  transition-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
  animation: ui-mdpc-fill 360ms var(--ui-mdpc-ease) both;
  animation-delay: calc(var(--c) * 70ms + var(--s) * 45ms);
}
.ui-mdpc__varies {
  flex: none;
  width: 136px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  text-align: center;
}
.ui-mdpc__settings {
  margin: 4px -4px 0;
  padding: 4px 4px 0;
  border-top: 0.5px solid var(--ui-mdpc-line);
}
.ui-mdpc__toggle {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 32px;
  padding: 0 8px;
  border-radius: 6px;
  color: var(--ui-mdpc-ink);
  transition: background-color 90ms ease-out;
}
.ui-mdpc__toggle:hover {
  background: var(--ui-mdpc-fill);
}
.ui-mdpc__toggle-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  color: var(--ui-mdpc-icon);
  transition: color 200ms ease;
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__toggle-icon {
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__toggle-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-mdpc__switch {
  position: relative;
  flex: none;
  width: 26px;
  height: 16px;
  border-radius: 5px;
  background: var(--ui-mdpc-switch);
  transition: background-color 220ms ease;
}
.ui-mdpc__switch::after {
  content: "";
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 3.5px;
  background: var(--ui-mdpc-knob);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06),
    0 1px 2px rgba(0, 0, 0, 0.16);
  transition: transform 280ms var(--ui-mdpc-ease);
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__switch {
  background: var(--ui-mdpc-accent);
}
.ui-mdpc__toggle[aria-checked="true"] .ui-mdpc__switch::after {
  transform: translateX(10px);
}
.ui-mdpc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 420ms var(--ui-mdpc-ease),
    opacity 220ms ease;
}
.ui-mdpc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows 420ms var(--ui-mdpc-ease),
    opacity 320ms ease 100ms;
}
.ui-mdpc__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-mdpc__effort {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 2px 8px 6px 38px;
}
.ui-mdpc__effort-label {
  flex: 1;
  min-width: 0;
  color: var(--ui-mdpc-text);
}
.ui-mdpc__segmented {
  position: relative;
  display: flex;
  flex: none;
  gap: 4px;
}
.ui-mdpc__thumb {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  width: var(--w, 0);
  border-radius: 5px;
  background: var(--ui-mdpc-fill);
  transform: translateX(var(--x, 0));
  transition:
    transform 220ms var(--ui-mdpc-ease),
    width 220ms var(--ui-mdpc-ease);
}
.ui-mdpc__seg-btn {
  position: relative;
  height: 22px;
  padding: 0 7px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mdpc-line);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-mdpc-text);
  text-align: center !important;
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-mdpc__seg-btn[aria-checked="true"] {
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__seg-btn[aria-checked="false"]:hover {
  background: var(--ui-mdpc-wash);
  color: var(--ui-mdpc-ink);
}
.ui-mdpc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 36px;
  padding: 6px 8px 6px 12px;
  border-top: 0.5px solid var(--ui-mdpc-line);
}
.ui-mdpc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-mdpc__dot {
  color: var(--ui-mdpc-faint);
}
.ui-mdpc__swap {
  display: grid;
  min-width: 0;
}
.ui-mdpc__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  animation: ui-mdpc-swap-in 320ms ease both;
}
.ui-mdpc__swap-item[data-out] {
  animation: ui-mdpc-swap-out 220ms ease both;
}
.ui-mdpc__caption .ui-mdpc__swap-item {
  display: -webkit-box;
  white-space: normal;
  text-overflow: clip;
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-mdpc__keys {
  display: flex;
  flex: none;
  gap: 2px;
}
.ui-mdpc__keys kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 5px;
  box-shadow: inset 0 0 0 0.5px var(--ui-mdpc-line-strong);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-mdpc-muted);
}
@keyframes ui-mdpc-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdpc-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-mdpc-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-mdpc-fill {
  0% {
    transform: scaleY(1);
  }
  45% {
    transform: scaleY(1.6);
  }
  100% {
    transform: scaleY(1);
  }
}
@container (max-width: 300px) {
  .ui-mdpc__option .ui-mdpc__glyph {
    display: none;
  }
  .ui-mdpc__keys {
    display: none;
  }
  .ui-mdpc__effort {
    padding-left: 8px;
  }
}
@media (pointer: coarse) {
  .ui-mdpc__trigger {
    height: 34px;
  }
  .ui-mdpc__option {
    min-height: 52px;
  }
  .ui-mdpc__toggle {
    height: 40px;
  }
  .ui-mdpc__seg-btn {
    height: 30px;
    padding: 0 10px;
  }
  .ui-mdpc__keys {
    display: none;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-mdpc *,
  .ui-mdpc *::before,
  .ui-mdpc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-mdpc {
  --ui-mdpc-card: #1c1c1e;
  --ui-mdpc-strong: #ffffff;
  --ui-mdpc-ink: rgba(255, 255, 255, 0.9);
  --ui-mdpc-text: rgba(255, 255, 255, 0.62);
  --ui-mdpc-muted: rgba(255, 255, 255, 0.46);
  --ui-mdpc-faint: rgba(255, 255, 255, 0.3);
  --ui-mdpc-icon: rgba(255, 255, 255, 0.5);
  --ui-mdpc-line: rgba(255, 255, 255, 0.08);
  --ui-mdpc-line-strong: rgba(255, 255, 255, 0.12);
  --ui-mdpc-fill: rgba(255, 255, 255, 0.08);
  --ui-mdpc-wash: rgba(255, 255, 255, 0.04);
  --ui-mdpc-bar: rgba(255, 255, 255, 0.24);
  --ui-mdpc-bar-off: rgba(255, 255, 255, 0.08);
  --ui-mdpc-switch: rgba(255, 255, 255, 0.14);
  --ui-mdpc-knob: #ffffff;
  --ui-mdpc-accent: #4d8dff;
  --ui-mdpc-focus: rgba(77, 141, 255, 0.8);
  --ui-mdpc-shadow-tile:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-mdpc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-mdpc__glyph {
  background: #2a2a2d;
}
`;function qi({clean:i=!1,...r}){const{models:d,align:f="start",side:h="bottom",className:b}=r,a=i?"ui-mdpc":"ui-mdp",{id:l,rootRef:g,triggerRef:c,listRef:j,panelRef:w,selectedModel:s,selectedIndex:m,thinkingEnabled:_,searchEnabled:k,selectedEffort:v,isOpen:$,activeIndex:P,pointing:I,setPointing:T,searchPreview:A,setSearchPreview:R,previewModel:L,setOpen:Y,horizontalOffset:q,toggleThinking:G,toggleSearch:Q,chooseEffort:J,pointOption:C,pickOption:ii,handleTriggerKeyDown:ei,handleListKeyDown:ti,effortRef:H,effortBounds:z,handleEffortKeyDown:O,handleRootKeyDown:E}=Li(r,i),x=Pi(L,_,v,A,k,a),M=d[P]?`${l}-opt-${P}`:void 0,U=i?z?{"--x":`${z.x}px`,"--w":`${z.width}px`}:void 0:{"--i":D.findIndex(p=>p.id===v)};return e.jsxs("div",{ref:g,className:[a,b].filter(Boolean).join(" "),"data-open":$?"":void 0,"data-align":f,"data-side":h,onKeyDown:E,onBlur:p=>{var y;$&&p.relatedTarget&&!((y=g.current)!=null&&y.contains(p.relatedTarget))&&Y(!1)},children:[e.jsx("style",{href:i?"ui-model-picker-clean":"ui-model-picker",precedence:"default",children:i?Fi:Bi}),e.jsxs("button",{ref:c,type:"button",className:`${a}__trigger`,"aria-haspopup":"dialog","aria-expanded":$,"aria-controls":`${l}-menu`,"aria-label":`Model: ${(s==null?void 0:s.name)??"none"}${_?", extended thinking":""}`,onClick:()=>Y(!$,$?void 0:"list"),onKeyDown:ei,children:[s&&e.jsx(hi,{model:s,prefix:a}),e.jsx("span",{className:`${a}__name`,title:s==null?void 0:s.name,children:e.jsx(mi,{id:(s==null?void 0:s.id)??"none",prefix:a,children:(s==null?void 0:s.name)??"Choose a model"})}),e.jsx("span",{className:`${a}__flag`,"data-on":_?"":void 0,"aria-hidden":"true",children:e.jsx("span",{children:e.jsx(fi,{clean:i})})}),e.jsx(Ti,{clean:i,prefix:a})]}),e.jsxs("div",{id:`${l}-menu`,ref:w,className:`${a}__pop`,style:q?{translate:`${q}px 0`}:void 0,role:"dialog","aria-label":"Model settings",inert:!$,children:[e.jsxs("div",{className:`${a}__card`,children:[e.jsxs("div",{className:`${a}__head`,"aria-hidden":"true",children:[e.jsx("span",{children:"Model"}),e.jsx("span",{className:`${a}__cols`,children:gi.map(p=>e.jsx("span",{children:p.label},p.key))})]}),d.length===0&&e.jsx("div",{className:`${a}__empty`,children:"No models available"}),e.jsx("div",{ref:j,className:`${a}__list`,role:"listbox","aria-label":"Model",tabIndex:0,"aria-activedescendant":$?M:void 0,"data-pointing":I?"":void 0,onKeyDown:ti,onPointerLeave:()=>T(!1),children:d.map((p,y)=>e.jsx(Ki,{model:p,index:y,optionId:`${l}-opt-${y}`,selected:y===m,active:y===P,lit:p.id===(L==null?void 0:L.id),onPoint:C,onPick:ii,prefix:a,clean:i},p.id))}),e.jsxs("div",{className:`${a}__settings`,children:[e.jsxs("button",{type:"button",role:"switch","aria-checked":_,className:`${a}__toggle`,onClick:G,children:[e.jsx("span",{className:`${a}__toggle-icon`,children:e.jsx(fi,{clean:i})}),e.jsx("span",{className:`${a}__toggle-label`,children:"Extended thinking"}),e.jsx("span",{className:`${a}__switch`,"aria-hidden":"true"})]}),e.jsx("div",{className:`${a}__fold`,"data-open":_?"":void 0,inert:!_,children:e.jsx("div",{className:`${a}__clip`,children:e.jsxs("div",{className:`${a}__effort`,children:[e.jsx("span",{className:`${a}__effort-label`,id:`${l}-effort`,children:"Effort"}),e.jsxs("div",{ref:i?H:void 0,className:`${a}__segmented`,role:"radiogroup","aria-labelledby":`${l}-effort`,style:U,onKeyDown:O,children:[e.jsx("span",{className:`${a}__thumb`,"aria-hidden":"true"}),D.map(p=>e.jsx("button",{type:"button",role:"radio","aria-checked":p.id===v,tabIndex:p.id===v?0:-1,"data-effort":p.id,className:`${a}__seg-btn`,onClick:()=>J(p.id),children:p.label},p.id))]})]})})}),e.jsxs("button",{type:"button",role:"switch","aria-checked":k,className:`${a}__toggle`,onClick:Q,onPointerEnter:p=>{p.pointerType==="mouse"&&R(!0)},onPointerLeave:()=>R(!1),onFocus:()=>R(!0),onBlur:()=>R(!1),children:[e.jsx("span",{className:`${a}__toggle-icon`,children:e.jsx(Oi,{clean:i})}),e.jsx("span",{className:`${a}__toggle-label`,children:"Web search"}),e.jsx("span",{className:`${a}__switch`,"aria-hidden":"true"})]})]})]}),e.jsxs("div",{className:`${a}__foot`,children:[e.jsx("span",{className:`${a}__caption`,"aria-hidden":"true",children:e.jsx(mi,{id:x.id,prefix:a,children:x.content})}),e.jsxs("span",{className:`${a}__keys`,"aria-hidden":"true",children:[e.jsx("kbd",{children:"↑↓"}),e.jsx("kbd",{children:"↵"})]}),e.jsx("span",{className:`${a}__sr`,"aria-live":"polite",children:$?x.announcement:""})]})]})]})}export{qi as M};
