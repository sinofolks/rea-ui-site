const n=`.ui-mw {
  touch-action: none;
  cursor: grab;
  --ui-mw-ink: #171717;
  --ui-mw-muted: #8f8f8f;
  --ui-mw-fill: rgba(0, 0, 0, 0.05);
  --ui-mw-mark: #171717;
  position: relative;
  display: grid;
  place-items: center;
  width: 100%;
  height: 308px;
  font-family: inherit;
  -webkit-font-smoothing: antialiased;
  user-select: none;
}
/* The selected model sits on a soft gray fill that follows the length of its name */
.ui-mw-fill {
  position: absolute;
  top: 50%;
  left: 50%;
  width: var(--ui-mw-fill-w, 140px);
  height: 38px;
  translate: -50% -50%;
  border-radius: 11px;
  background: var(--ui-mw-fill);
  transition: width 420ms cubic-bezier(0.22, 1, 0.36, 1);
}
.ui-mw-drum {
  position: absolute;
  inset: 0;
  perspective: 560px;
  transform-style: preserve-3d;
  /* Rows fade out softly at both ends of the drum */
  -webkit-mask-image: linear-gradient(
    to bottom,
    transparent,
    #000 22%,
    #000 78%,
    transparent
  );
  mask-image: linear-gradient(
    to bottom,
    transparent,
    #000 22%,
    #000 78%,
    transparent
  );
}
.ui-mw-row {
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  height: 44px;
  margin-top: -22px;
  backface-visibility: hidden;
  font-size: 16px;
  font-weight: 450;
  letter-spacing: -0.01em;
  color: var(--ui-mw-muted);
  will-change: transform, opacity;
}
.ui-mw[data-dragging] {
  cursor: grabbing;
}
.ui-mw-label {
  display: inline-flex;
  align-items: center;
  gap: 10px;
}
.ui-mw-row svg {
  flex: none;
  width: 18px;
  height: 18px;
  color: var(--ui-mw-mark);
}
.ui-mw-row[data-active] {
  font-weight: 500;
  color: var(--ui-mw-ink);
}

/* Reduced motion: the fill jumps to the new name instead of gliding */
@media (prefers-reduced-motion: reduce) {
  .ui-mw-fill {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor */
:where(.dark, [data-theme="dark"]) .ui-mw {
  --ui-mw-ink: #ededed;
  --ui-mw-muted: #8a8a8f;
  --ui-mw-fill: rgba(255, 255, 255, 0.07);
  --ui-mw-mark: #ededed;
}

.model-wheel-demo {
  width: min(100%, 360px);
}
.card__preview .model-wheel-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .model-wheel-demo .ui-mw {
  zoom: 0.8;
}
`;export{n as default};
