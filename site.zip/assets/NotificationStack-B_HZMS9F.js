const n=`.ui-ns {
  --ui-ns-card: #ffffff;
  --ui-ns-line: #e5e5e5;
  --ui-ns-ink: #171717;
  --ui-ns-muted: #626873;
  --ui-ns-art: #e3e3e3;
  --ui-ns-accent: #2f6bff;
  --ui-ns-focus: rgba(0, 96, 226, 0.7);
  --ui-ns-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 380px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-ns-ink);
  -webkit-font-smoothing: antialiased;
  transition: height 460ms var(--ui-ns-ease);
}
.ui-ns *,
.ui-ns *::before,
.ui-ns *::after {
  box-sizing: border-box;
}

.ui-ns__card {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  overflow: hidden;
  background: var(--ui-ns-card);
  border: 1px solid var(--ui-ns-line);
  border-radius: 20px;
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.03),
    0 8px 24px rgba(0, 0, 0, 0.035);
  transform-origin: 50% 100%;
  transition:
    transform 460ms var(--ui-ns-ease),
    opacity 300ms ease,
    box-shadow 300ms ease;
}
/* Cards behind show only their edge */
.ui-ns__card > * {
  transition: opacity 260ms ease;
}
.ui-ns__card:not([data-depth="0"]) > * {
  opacity: 0;
}
.ui-ns__card[data-leaving] {
  opacity: 0;
  transform: translateX(40px) scale(0.98) !important;
  transition:
    transform 320ms var(--ui-ns-ease),
    opacity 240ms ease;
}

.ui-ns__pattern {
  position: absolute;
  top: 0;
  right: 0;
  width: 220px;
  height: 160px;
  stroke: var(--ui-ns-art);
  stroke-width: 1;
  pointer-events: none;
  /* Only the top-right corner, fading out towards the text */
  -webkit-mask-image: radial-gradient(
    120% 110% at 100% 0%,
    #000 20%,
    transparent 70%
  );
  mask-image: radial-gradient(120% 110% at 100% 0%, #000 20%, transparent 70%);
}
.ui-ns__dot {
  fill: #d4d4d4;
  stroke: none;
}
.ui-ns__fill {
  fill: #f5f5f5;
}

.ui-ns__body {
  position: relative;
  padding: 18px 20px 20px;
}
.ui-ns__top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 26px;
  margin-bottom: 14px;
}
.ui-ns__badge {
  padding: 2px 9px;
  border-radius: 999px;
  background: #fff;
  box-shadow: inset 0 0 0 1px var(--ui-ns-line);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: #525252;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ns__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin: -2px -6px 0 0;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-ns-muted);
  cursor: pointer;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-ns__close:hover {
  background: rgba(0, 0, 0, 0.05);
  color: var(--ui-ns-ink);
}
.ui-ns__title {
  margin: 0;
  font-size: 16px;
  font-weight: 500;
  line-height: 22px;
  letter-spacing: -0.01em;
  text-align: start;
  overflow-wrap: anywhere;
}
.ui-ns__text {
  margin: 6px 0 0;
  max-width: 34ch;
  font-size: 14px;
  line-height: 21px;
  color: var(--ui-ns-muted);
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-ns__btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  /* Grows with a long label instead of leaving the card */
  min-height: 32px;
  max-width: 100%;
  margin-top: 16px;
  padding: 6px 12px;
  border: 0;
  border-radius: 9px;
  background: #fff;
  box-shadow:
    0 0 0 1px var(--ui-ns-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-ns-ink);
  text-align: start;
  overflow-wrap: anywhere;
  text-decoration: none;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    transform 160ms ease;
}
.ui-ns__btn:hover {
  background: #f7f7f7;
}
.ui-ns__btn:active {
  transform: scale(0.98);
}
.ui-ns__btn svg {
  flex: none;
  color: var(--ui-ns-muted);
}
.ui-ns button:focus-visible,
.ui-ns a:focus-visible {
  outline: 2px solid var(--ui-ns-focus);
  outline-offset: 2px;
}

@media (prefers-reduced-motion: reduce) {
  .ui-ns,
  .ui-ns__card,
  .ui-ns__card > * {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-ns {
  --ui-ns-card: #232326;
  --ui-ns-line: rgba(255, 255, 255, 0.1);
  --ui-ns-ink: #ededed;
  --ui-ns-muted: #8f8f8f;
  --ui-ns-art: rgba(255, 255, 255, 0.08);
  --ui-ns-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-ns__card {
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.4),
    0 8px 24px rgba(0, 0, 0, 0.35);
}
:where(.dark, [data-theme="dark"]) .ui-ns__dot {
  fill: rgba(255, 255, 255, 0.22);
}
:where(.dark, [data-theme="dark"]) .ui-ns__fill {
  fill: rgba(255, 255, 255, 0.04);
}
:where(.dark, [data-theme="dark"]) .ui-ns__badge {
  background: #2a2a2d;
  color: #c4c4c4;
}
:where(.dark, [data-theme="dark"]) .ui-ns__close:hover {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-ns__btn {
  background: #2a2a2d;
  box-shadow:
    0 0 0 1px var(--ui-ns-line),
    0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-ns__btn:hover {
  background: #313135;
}
`;export{n as default};
