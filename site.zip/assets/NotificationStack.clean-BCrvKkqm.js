const n=`/* Colors and motion as variables – override them on .ui-nsc */
.ui-nsc {
  --ui-nsc-card: #ffffff;
  --ui-nsc-strong: #000000;
  --ui-nsc-ink: rgba(0, 0, 0, 0.88);
  --ui-nsc-text: rgba(0, 0, 0, 0.65);
  --ui-nsc-icon: rgba(0, 0, 0, 0.65);
  --ui-nsc-line: rgba(0, 0, 0, 0.06);
  --ui-nsc-wash: rgba(0, 0, 0, 0.03);
  --ui-nsc-fill: rgba(0, 0, 0, 0.06);
  --ui-nsc-art: rgba(0, 0, 0, 0.07);
  --ui-nsc-accent: rgba(0, 96, 226, 0.765);
  --ui-nsc-accent-bg: rgba(0, 96, 226, 0.05);
  --ui-nsc-focus: rgba(0, 96, 226, 0.7);
  /* Strokes are shadows: a 0.5px hairline plus a soft lift */
  --ui-nsc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-nsc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 1px -1px rgba(0, 0, 0, 0.12),
    0 1px 3px 0 rgba(0, 0, 0, 0.07);
  --ui-nsc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 380px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-nsc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
  transition: height 460ms var(--ui-nsc-ease);
}
.ui-nsc *,
.ui-nsc *::before,
.ui-nsc *::after {
  box-sizing: border-box;
}
:where(.ui-nsc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-nsc) svg {
  flex: none;
}
.ui-nsc button:focus-visible,
.ui-nsc a:focus-visible {
  outline: 2px solid var(--ui-nsc-focus);
  outline-offset: 2px;
}

/* One white card per notice – the edge is a shadow, not a border */
.ui-nsc__card {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-nsc-card);
  box-shadow: var(--ui-nsc-shadow);
  transform-origin: 50% 100%;
  transition:
    transform 460ms var(--ui-nsc-ease),
    opacity 300ms ease,
    box-shadow 300ms ease;
}
/* Cards behind show only their edge */
.ui-nsc__card > * {
  transition: opacity 260ms ease;
}
.ui-nsc__card:not([data-depth="0"]) > * {
  opacity: 0;
}
.ui-nsc__card[data-leaving] {
  opacity: 0;
  transform: translateX(40px) scale(0.98) !important;
  transition:
    transform 320ms var(--ui-nsc-ease),
    opacity 240ms ease;
}

/* Quiet hairline art in the top-right corner, with one blue mark */
.ui-nsc__pattern {
  position: absolute;
  top: 0;
  right: 0;
  width: 220px;
  height: 160px;
  stroke: var(--ui-nsc-art);
  stroke-width: 0.75;
  pointer-events: none;
  -webkit-mask-image: radial-gradient(
    120% 110% at 100% 0%,
    #000 20%,
    transparent 70%
  );
  mask-image: radial-gradient(120% 110% at 100% 0%, #000 20%, transparent 70%);
}
.ui-nsc__dot {
  fill: var(--ui-nsc-accent);
  stroke: none;
}
.ui-nsc__fill {
  fill: var(--ui-nsc-accent-bg);
}

.ui-nsc__body {
  position: relative;
  padding: 12px 12px 16px 16px;
}
.ui-nsc__top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 28px;
  margin-bottom: 8px;
}
/* Tiny label: tinted fill, 10px uppercase */
.ui-nsc__badge {
  padding: 2px 6px;
  border-radius: 5px;
  background: var(--ui-nsc-fill);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-nsc-text);
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
/* Ghost icon button */
.ui-nsc__close {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
:where(.ui-nsc) .ui-nsc__close {
  color: var(--ui-nsc-icon);
}
.ui-nsc__close:hover {
  background: var(--ui-nsc-wash);
  color: var(--ui-nsc-ink);
}
.ui-nsc__title {
  margin: 0;
  padding-right: 4px;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-nsc-strong);
  text-align: start;
  overflow-wrap: anywhere;
}
.ui-nsc__text {
  margin: 2px 0 0;
  padding-right: 4px;
  max-width: 38ch;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-nsc-text);
  text-align: start;
  overflow-wrap: anywhere;
  white-space: pre-line;
}
/* Secondary button: white with the card's hairline shadow */
.ui-nsc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  /* Grows with a long label instead of leaving the card */
  min-height: 28px;
  max-width: 100%;
  margin-top: 12px;
  padding: 4px 10px;
  border-radius: 6px;
  text-align: start;
  overflow-wrap: anywhere;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  text-decoration: none;
  transition:
    background-color 140ms ease,
    box-shadow 140ms ease,
    transform 160ms var(--ui-nsc-ease);
}
:where(.ui-nsc) .ui-nsc__btn {
  background: var(--ui-nsc-card);
  box-shadow: var(--ui-nsc-shadow);
  color: var(--ui-nsc-strong);
}
.ui-nsc__btn:has(svg) {
  padding: 4px 8px 4px 10px;
}
.ui-nsc__btn:hover {
  box-shadow: var(--ui-nsc-shadow-hover);
}
.ui-nsc__btn:active {
  transform: scale(0.97);
}
.ui-nsc__btn svg {
  color: var(--ui-nsc-icon);
}

/* Narrow stacks (phones) */
@container (max-width: 340px) {
  .ui-nsc__body {
    padding: 10px 10px 14px 14px;
  }
  .ui-nsc__text {
    max-width: none;
  }
}
/* Touch screens: bigger tap targets */
@media (pointer: coarse) {
  .ui-nsc__close {
    width: 36px;
    height: 36px;
    margin: -4px -4px -4px 0;
  }
  .ui-nsc__btn {
    min-height: 36px;
    padding: 8px 14px;
  }
  .ui-nsc__btn:has(svg) {
    padding: 8px 12px 8px 14px;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-nsc,
  .ui-nsc__card,
  .ui-nsc__card > * {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-nsc {
  --ui-nsc-card: #1c1c1e;
  --ui-nsc-strong: #ffffff;
  --ui-nsc-ink: rgba(255, 255, 255, 0.9);
  --ui-nsc-text: rgba(255, 255, 255, 0.62);
  --ui-nsc-icon: rgba(255, 255, 255, 0.46);
  --ui-nsc-line: rgba(255, 255, 255, 0.08);
  --ui-nsc-wash: rgba(255, 255, 255, 0.04);
  --ui-nsc-fill: rgba(255, 255, 255, 0.08);
  --ui-nsc-art: rgba(255, 255, 255, 0.07);
  --ui-nsc-accent: #4d8dff;
  --ui-nsc-accent-bg: rgba(77, 141, 255, 0.1);
  --ui-nsc-focus: rgba(77, 141, 255, 0.8);
  --ui-nsc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-nsc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-nsc .ui-nsc__btn {
  background: rgba(255, 255, 255, 0.04);
}
`;export{n as default};
