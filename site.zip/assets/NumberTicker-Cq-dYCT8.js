const n=`.ui-nt {
  --ui-nt-lh: 1.15em;
  --ui-nt-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  display: inline-flex;
  line-height: var(--ui-nt-lh);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-nt__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-nt__track {
  display: inline-flex;
  align-items: flex-start;
  height: var(--ui-nt-lh);
  line-height: var(--ui-nt-lh);
}
.ui-nt__col {
  display: inline-block;
  height: var(--ui-nt-lh);
  overflow: hidden;
  /* Soft top and bottom edges while digits pass through */
  -webkit-mask-image: linear-gradient(
    transparent,
    #000 14%,
    #000 86%,
    transparent
  );
  mask-image: linear-gradient(transparent, #000 14%, #000 86%, transparent);
}
.ui-nt__col[data-enter] {
  animation: ui-nt-in 450ms var(--ui-nt-ease) both;
}
.ui-nt__stack {
  display: flex;
  flex-direction: column;
  will-change: transform;
}
.ui-nt__cell,
.ui-nt__static {
  display: block;
  height: var(--ui-nt-lh);
  text-align: center;
}
.ui-nt__static {
  white-space: pre;
}

@keyframes ui-nt-in {
  from {
    opacity: 0;
    transform: translateY(-35%);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-nt__col[data-enter] {
    animation: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html>.
   The ticker inherits its color, so nothing needs to change here. */
:where(.dark, [data-theme="dark"]) .ui-nt {
  --ui-nt-lh: 1.15em;
}

.number-ticker-demo {
  -webkit-font-smoothing: antialiased;
  place-items: center;
  width: 100%;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    sans-serif;
  display: grid;
}
.ntd-card {
  color: #171717;
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  width: min(100%, 300px);
  padding: 20px 20px 16px;
  box-shadow: 0 1px 2px #0000000f;
}
.ntd-head {
  justify-content: space-between;
  align-items: baseline;
  gap: 12px;
  font-size: 13px;
  line-height: 18px;
  display: flex;
}
.ntd-label {
  font-weight: 500;
}
.ntd-period {
  color: #8f8f8f;
}
.ntd-value {
  letter-spacing: -0.03em;
  margin-top: 10px;
  font-size: 38px;
  font-weight: 600;
  line-height: 1;
}
.ntd-meta {
  align-items: center;
  gap: 8px;
  margin-top: 12px;
  font-size: 12.5px;
  display: flex;
}
.ntd-delta {
  color: #15803d;
  background: #e9f9ef;
  border-radius: 999px;
  align-items: center;
  gap: 4px;
  height: 22px;
  padding: 0 8px 0 7px;
  font-weight: 500;
  display: inline-flex;
}
.ntd-delta svg {
  transition: transform 0.3s cubic-bezier(0.22, 1, 0.36, 1);
}
.ntd-delta[data-down] {
  color: #c02626;
  background: #fdecec;
}
.ntd-delta[data-down] svg {
  transform: rotate(180deg);
}
.ntd-vs {
  color: #8f8f8f;
}
.ntd-actions {
  border-top: 1px solid #f0f0f0;
  gap: 6px;
  margin-top: 18px;
  padding-top: 14px;
  display: flex;
}
.ntd-btn {
  color: #171717;
  height: 30px;
  font: inherit;
  cursor: pointer;
  background: #fff;
  border: 0;
  border-radius: 9px;
  flex: 1;
  margin: 0;
  padding: 0 12px;
  font-size: 15px;
  font-weight: 500;
  line-height: 1;
  transition: background-color 0.15s;
  box-shadow: 0 0 0 1px #e5e5e5;
}
.ntd-btn:hover {
  background: #f7f7f7;
}
.ntd-btn:focus-visible {
  outline-offset: 2px;
  outline: 2px solid #2f6bff;
}
:where(.dark, [data-theme="dark"]) .ntd-card {
  color: #ededed;
  background: #232326;
  border-color: #ffffff14;
}
:where(.dark, [data-theme="dark"]) .ntd-delta {
  color: #4ade80;
  background: #22c55e24;
}
:where(.dark, [data-theme="dark"]) .ntd-delta[data-down] {
  color: #f87171;
  background: #ef444429;
}
:where(.dark, [data-theme="dark"]) .ntd-actions {
  border-top-color: #ffffff12;
}
:where(.dark, [data-theme="dark"]) .ntd-btn {
  color: #ededed;
  background: #2c2c30;
  box-shadow: 0 0 0 1px #ffffff1a;
}
:where(.dark, [data-theme="dark"]) .ntd-btn:hover {
  background: #343439;
}
.card__preview .number-ticker-demo {
  position: absolute;
  inset: 0;
}
.card__preview .number-ticker-demo .ntd-card {
  zoom: 0.7;
}
`;export{n as default};
