const n=`/* Colors, size and motion as variables – override them on .ui-otp */
.ui-otp {
  --ui-otp-box: 48px;
  --ui-otp-gap: 8px;
  --ui-otp-bg: #fafafa;
  --ui-otp-card: #ffffff;
  --ui-otp-line: #e4e4e7;
  --ui-otp-line-strong: #cfcfd4;
  --ui-otp-ink: #171717;
  --ui-otp-text: #404040;
  --ui-otp-muted: #626873;
  --ui-otp-faint: #c4c4c8;
  --ui-otp-halo: rgba(23, 23, 23, 0.07);
  --ui-otp-wait: #f2f2f3;
  --ui-otp-shine: rgba(255, 255, 255, 0.95);
  --ui-otp-danger: #e5484d;
  --ui-otp-danger-line: rgba(229, 72, 77, 0.6);
  --ui-otp-danger-halo: rgba(229, 72, 77, 0.12);
  --ui-otp-success: #2f9e5b;
  --ui-otp-accent: #2a5ee5;
  --ui-otp-focus: rgba(0, 96, 226, 0.7);
  --ui-otp-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  justify-self: stretch; /* it sizes the boxes from its own width, so it must never shrink to fit them */
  width: 100%;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.45;
  color: var(--ui-otp-text);
  -webkit-font-smoothing: antialiased;
}
.ui-otp *,
.ui-otp *::before,
.ui-otp *::after {
  box-sizing: border-box;
}
.ui-otp[data-align="center"] {
  justify-items: center;
  text-align: center;
}
.ui-otp[data-disabled] {
  opacity: 0.55;
}

.ui-otp__field {
  display: flex;
  min-width: 0;
}
.ui-otp[data-align="center"] .ui-otp__field {
  justify-content: center;
}

/* The boxes scale down to fit their container (phones at 320px), up to --ui-otp-box */
.ui-otp__slots {
  --size: min(
    var(--ui-otp-box),
    calc(
      (100cqi - (var(--n) - 1) * var(--ui-otp-gap) - var(--sep-w)) / var(--n)
    )
  );
  position: relative;
  display: flex;
  align-items: center;
  gap: var(--ui-otp-gap);
}
.ui-otp__box {
  position: relative;
  display: grid;
  place-items: center;
  flex: none;
  width: var(--size);
  height: calc(var(--size) * 1.18);
  overflow: hidden;
  border-radius: calc(var(--size) * 0.24);
  background: var(--ui-otp-bg);
  box-shadow: inset 0 0 0 1px var(--ui-otp-line);
  font-size: calc(var(--size) * 0.46);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-otp-ink);
  transition:
    box-shadow 220ms ease,
    background-color 220ms ease,
    transform 380ms var(--ui-otp-ease),
    opacity 260ms ease;
}
.ui-otp__box[data-filled] {
  background: var(--ui-otp-card);
  box-shadow: inset 0 0 0 1px var(--ui-otp-line-strong);
}
.ui-otp__sep {
  flex: none;
  width: 10px;
  height: 2px;
  border-radius: 1px;
  background: var(--ui-otp-faint);
  transition: opacity 200ms ease;
}

/* Digits pop in – a small lift out of a blur, no bounce */
.ui-otp__char {
  display: block;
  animation: ui-otp-pop 280ms var(--ui-otp-ease) both;
}
.ui-otp__slots[data-clearing] .ui-otp__char {
  animation: ui-otp-out 240ms ease both;
  animation-delay: calc((var(--n) - var(--i)) * 22ms) !important;
}

/* One ring glides from box to box; its caret blinks softly in an empty box */
.ui-otp__ring {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
  display: grid;
  place-items: center;
  border-radius: calc(var(--size) * 0.24);
  box-shadow:
    inset 0 0 0 1.5px var(--ui-otp-ink),
    0 0 0 4px var(--ui-otp-halo);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 260ms var(--ui-otp-ease),
    width 260ms var(--ui-otp-ease),
    opacity 180ms ease,
    box-shadow 220ms ease;
}
.ui-otp__ring[data-show] {
  opacity: 1;
}
.ui-otp__caret {
  width: 1.5px;
  height: 40%;
  border-radius: 1px;
  background: var(--ui-otp-ink);
  opacity: 0;
}
.ui-otp__caret[data-show] {
  animation: ui-otp-blink 1.1s ease-in-out infinite;
}

/* The real input lies over the boxes, invisible – it takes taps, keys, paste and SMS autofill */
.ui-otp__input {
  position: absolute;
  inset: 0;
  z-index: 2;
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
  border: 0;
  outline: none;
  background: transparent;
  color: transparent;
  -webkit-text-fill-color: transparent;
  caret-color: transparent;
  font-size: 16px; /* iOS doesn't zoom into inputs of 16px and up */
  letter-spacing: -1em;
  cursor: text;
  appearance: none;
}
.ui-otp__input::selection {
  background: transparent;
}
.ui-otp__input:-webkit-autofill {
  -webkit-box-shadow: 0 0 0 100px transparent inset;
  transition: background-color 9999s;
}
.ui-otp__input[readonly],
.ui-otp__input:disabled {
  cursor: default;
}

/* Verifying: a soft light passes over the boxes, one after another */
.ui-otp__box::after {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
    100deg,
    transparent 20%,
    var(--ui-otp-shine) 50%,
    transparent 80%
  );
  transform: translateX(-120%);
  opacity: 0;
  pointer-events: none;
}
.ui-otp[data-status="verifying"] .ui-otp__box::after {
  opacity: 1;
  animation: ui-otp-shimmer 1.3s ease-in-out infinite;
  animation-delay: calc(var(--i) * 70ms);
}
.ui-otp[data-status="verifying"] .ui-otp__box {
  background: var(--ui-otp-wait);
  box-shadow: inset 0 0 0 1px var(--ui-otp-line);
  color: var(--ui-otp-text);
}

/* Error: only the borders turn red */
.ui-otp[data-error] .ui-otp__box {
  box-shadow: inset 0 0 0 1px var(--ui-otp-danger-line);
}
.ui-otp[data-error] .ui-otp__ring {
  box-shadow:
    inset 0 0 0 1.5px var(--ui-otp-danger),
    0 0 0 4px var(--ui-otp-danger-halo);
}
.ui-otp[data-error] .ui-otp__caret {
  background: var(--ui-otp-danger);
}

/* Success: the boxes slide together and fade while one frame morphs into the "Verified" pill */
.ui-otp__pill {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 1;
  display: grid;
  place-items: center;
  height: calc(var(--size) * 1.18);
  overflow: hidden;
  border-radius: calc(var(--size) * 0.24);
  background: var(--ui-otp-card);
  box-shadow: inset 0 0 0 1px var(--ui-otp-line-strong);
  opacity: 0;
  transform: translate(-50%, -50%);
  pointer-events: none;
  transition:
    width 300ms var(--ui-otp-ease),
    height 300ms var(--ui-otp-ease),
    border-radius 300ms var(--ui-otp-ease),
    opacity 160ms ease 140ms;
}
.ui-otp__pill-inner {
  display: inline-flex;
  max-width: 100cqi; /* a long label shortens instead of leaving the field */
  align-items: center;
  gap: 6px;
  padding: 0 15px 0 12px;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  color: var(--ui-otp-ink);
  opacity: 0;
  transition: opacity 160ms ease;
}
.ui-otp__pill-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-otp__check {
  flex: none;
  width: 17px;
  height: 17px;
  fill: none;
  stroke: var(--ui-otp-success);
  stroke-width: 2.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-otp__check path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  transition: stroke-dashoffset 120ms ease;
}
.ui-otp[data-status="success"] .ui-otp__box {
  transform: translateX(
      calc(((var(--n) - 1) / 2 - var(--i)) * (var(--size) + var(--ui-otp-gap)))
    )
    scale(0.7);
  opacity: 0;
  transition:
    transform 340ms var(--ui-otp-ease),
    opacity 220ms ease 120ms;
}
.ui-otp[data-status="success"] .ui-otp__sep {
  opacity: 0;
}
/* The pill settles at a compact height, not the height of the boxes */
.ui-otp[data-status="success"] .ui-otp__pill {
  height: 36px;
  border-radius: 999px;
  opacity: 1;
  transition:
    width 460ms var(--ui-otp-ease) 220ms,
    height 460ms var(--ui-otp-ease) 220ms,
    border-radius 460ms var(--ui-otp-ease) 220ms,
    opacity 160ms ease 120ms;
}
.ui-otp[data-status="success"] .ui-otp__pill-inner {
  opacity: 1;
  transition: opacity 240ms ease 460ms;
}
.ui-otp[data-status="success"] .ui-otp__check path {
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 380ms var(--ui-otp-ease) 560ms;
}

/* The error message grows in below, then folds away */
.ui-otp__msg {
  display: grid;
  grid-template-rows: 0fr;
  width: 100%;
  transition: grid-template-rows 300ms var(--ui-otp-ease);
}
.ui-otp__msg[data-show] {
  grid-template-rows: 1fr;
}
.ui-otp__msg-inner {
  min-height: 0;
  overflow: hidden;
}
.ui-otp__msg-text {
  margin: 0;
  overflow-wrap: anywhere;
  padding-top: 10px;
  font-size: 13px;
  text-wrap: balance;
  color: var(--ui-otp-text);
  opacity: 0;
  transform: translateY(-4px);
  transition:
    opacity 200ms ease,
    transform 300ms var(--ui-otp-ease);
}
.ui-otp__msg[data-show] .ui-otp__msg-text {
  opacity: 1;
  transform: none;
  transition-delay: 60ms;
}
/* The icon sits inline, so a wrapped message stays centered with it */
.ui-otp__alert {
  display: inline-block;
  width: 15px;
  height: 15px;
  margin-right: 6px;
  vertical-align: -3px;
  fill: none;
  stroke: var(--ui-otp-danger);
  stroke-width: 2;
  stroke-linecap: round;
}

/* Resend: a countdown that turns into a button */
.ui-otp__resend {
  margin-top: 14px;
  font-size: 13px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-otp-muted);
  transition: opacity 220ms ease;
}
.ui-otp__resend[data-hidden] {
  opacity: 0;
  visibility: hidden;
  transition:
    opacity 220ms ease,
    visibility 0s 220ms;
}
.ui-otp__swap {
  display: inline-block;
  animation: ui-otp-in 260ms var(--ui-otp-ease) both;
}
.ui-otp__wait {
  color: var(--ui-otp-text);
}
.ui-otp__time {
  display: inline-block;
  min-width: 3.4ch;
  text-align: left;
}
.ui-otp__resend-btn {
  position: relative;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  font-weight: 500;
  border-radius: 4px;
  color: var(--ui-otp-accent);
  cursor: pointer;
}
.ui-otp__resend-btn::before {
  content: "";
  position: absolute;
  inset: -6px -8px;
  border-radius: 8px;
}
.ui-otp__resend-btn:hover {
  text-decoration: underline;
  text-underline-offset: 3px;
}
.ui-otp__resend-btn:focus-visible {
  outline: 2px solid var(--ui-otp-focus);
  outline-offset: 2px;
}
.ui-otp__resend-btn:disabled {
  color: var(--ui-otp-muted);
  cursor: default;
  text-decoration: none;
}
.ui-otp__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

@keyframes ui-otp-pop {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.7);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-otp-out {
  to {
    opacity: 0;
    transform: translateY(-4px) scale(0.8);
    filter: blur(2px);
  }
}
@keyframes ui-otp-blink {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
}
@keyframes ui-otp-shimmer {
  0% {
    transform: translateX(-120%);
  }
  55%,
  100% {
    transform: translateX(120%);
  }
}
@keyframes ui-otp-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}

/* Narrow containers (phones): tighter gaps, the question before "Resend" drops first */
@container (max-width: 360px) {
  .ui-otp__slots {
    --ui-otp-gap: 6px;
  }
  .ui-otp__sep {
    width: 8px;
  }
}
@container (max-width: 250px) {
  .ui-otp__resend-q {
    display: none;
  }
}
/* Touch screens: a bigger target for Resend */
@media (hover: none) and (pointer: coarse) {
  .ui-otp__resend-btn::before {
    inset: -11px -12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-otp *,
  .ui-otp *::before,
  .ui-otp *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-otp__caret[data-show] {
    opacity: 1;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-otp {
  --ui-otp-bg: #1d1d20;
  --ui-otp-card: #19191b;
  --ui-otp-line: #2a2a2e;
  --ui-otp-line-strong: #3a3a40;
  --ui-otp-ink: #ededed;
  --ui-otp-text: #c8c8cc;
  --ui-otp-muted: #8b8b92;
  --ui-otp-faint: #4a4a50;
  --ui-otp-halo: rgba(255, 255, 255, 0.08);
  --ui-otp-wait: #1d1d20;
  --ui-otp-shine: rgba(255, 255, 255, 0.07);
  --ui-otp-danger: #ff6369;
  --ui-otp-danger-line: rgba(255, 99, 105, 0.55);
  --ui-otp-danger-halo: rgba(255, 99, 105, 0.14);
  --ui-otp-success: #4cc38a;
  --ui-otp-accent: #6d8bff;
  --ui-otp-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
