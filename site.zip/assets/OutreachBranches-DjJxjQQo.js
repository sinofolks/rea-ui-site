const n=`.ui-ob {
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  overflow: hidden;
}
.ui-ob-art {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
}
.ui-ob-flow,
.ui-ob-wrap {
  fill: none;
  stroke-linecap: round;
  stroke-dashoffset: var(--from);
  opacity: 0;
  animation-duration: 4.2s;
  animation-iteration-count: infinite;
}
.ui-ob-flow {
  stroke-width: 1;
  animation-name: ui-ob-flow;
}
.ui-ob-wrap {
  stroke-width: 0.8;
  animation-name: ui-ob-wrap;
}
@keyframes ui-ob-flow {
  0% {
    stroke-dashoffset: var(--from);
    opacity: 0.8;
    animation-timing-function: cubic-bezier(0.7, 0, 0.3, 1);
  }
  40% {
    stroke-dashoffset: var(--to);
    opacity: 0.8;
  }
  40.1%,
  100% {
    stroke-dashoffset: var(--to);
    opacity: 0;
  }
}
@keyframes ui-ob-wrap {
  0%,
  23.2% {
    stroke-dashoffset: var(--from);
    opacity: 0;
  }
  23.3% {
    stroke-dashoffset: var(--from);
    opacity: 0.45;
    animation-timing-function: cubic-bezier(0.7, 0, 0.3, 1);
  }
  61.8% {
    stroke-dashoffset: var(--to);
    opacity: 0.45;
  }
  61.9%,
  100% {
    stroke-dashoffset: var(--to);
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ob-flow,
  .ui-ob-wrap {
    animation: none;
    opacity: 0;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ob-lines {
  stroke: rgba(255, 255, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-ob-tile {
  fill: #232326;
  stroke: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-ob-drop {
  flood-opacity: 0.4;
}
:where(.dark, [data-theme="dark"]) .ui-ob-sliver {
  flood-color: #1a1a1c;
}
:where(.dark, [data-theme="dark"]) .ui-ob-gray {
  stop-color: #3a3a3f;
}
:where(.dark, [data-theme="dark"]) .ui-ob-notion-page {
  fill: #191919;
}
:where(.dark, [data-theme="dark"]) .ui-ob-mark {
  fill: #ededed;
}

.outreach-branches-demo {
  width: 100%;
}
.stage .outreach-branches-demo {
  width: min(100%, 560px);
}
.card__preview .outreach-branches-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .outreach-branches-demo .ui-ob {
  width: auto;
  height: 100%;
}
`;export{n as default};
