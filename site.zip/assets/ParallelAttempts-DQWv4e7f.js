const n=`.ui-pa {
  --ui-pa-tray: #f0f0f0;
  --ui-pa-panel: #ffffff;
  --ui-pa-card: #ffffff;
  --ui-pa-strong: #171717;
  --ui-pa-ink: #171717;
  --ui-pa-text: #6b6b6b;
  --ui-pa-muted: #626873;
  --ui-pa-faint: #6b6b6b;
  --ui-pa-line: #ececec;
  --ui-pa-fill: rgba(0, 0, 0, 0.05);
  --ui-pa-track: #f2f2f2;
  --ui-pa-accent: #2a5ee5;
  --ui-pa-focus: rgba(0, 96, 226, 0.7);
  --ui-pa-running-bg: #e3ecff;
  --ui-pa-running-edge: #a9c2ff;
  --ui-pa-running-ink: #2456d6;
  --ui-pa-done-bg: #dcf3e4;
  --ui-pa-done-edge: #9fd9b4;
  --ui-pa-done-ink: #187941;
  --ui-pa-failed-bg: #fde3df;
  --ui-pa-failed-edge: #f1a397;
  --ui-pa-failed-ink: #c2331f;
  --ui-pa-best-bg: #c4ebd1;
  --ui-pa-best-edge: #6fc590;
  --ui-pa-shine: rgba(255, 255, 255, 0.9);
  --ui-pa-wash: #f3fbf6;
  --ui-pa-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-pa-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-pa-tray);
  container: ui-pa / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-pa-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pa *,
.ui-pa *::before,
.ui-pa *::after {
  box-sizing: border-box;
}
:where(.ui-pa) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-pa button:focus-visible {
  outline: 2px solid var(--ui-pa-focus);
  outline-offset: 2px;
}
.ui-pa svg {
  display: block;
  flex: none;
}
.ui-pa__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  padding: 8px 12px 12px;
}
.ui-pa__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-pa-accent);
}
.ui-pa__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 600;
  color: var(--ui-pa-strong);
}
.ui-pa__task {
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  color: var(--ui-pa-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pa__sum {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-left: auto;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-pa-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-pa__sum b {
  font-weight: 600;
  color: var(--ui-pa-ink);
}
.ui-pa__panel {
  display: grid;
  gap: 4px;
}
.ui-pa__row {
  position: relative;
  display: grid;
  grid-template-columns: 32px minmax(0, 1fr) minmax(120px, 36%) minmax(
      100px,
      auto
    );
  align-items: center;
  column-gap: 14px;
  padding: 14px 18px 14px 14px;
  border-radius: 16px;
  background: var(--ui-pa-panel);
  box-shadow: var(--ui-pa-shadow);
  transition:
    opacity 320ms ease,
    background-color 500ms ease,
    box-shadow 300ms ease;
  animation: ui-pa-in 420ms var(--ui-pa-ease) calc(min(var(--i, 0), 12) * 70ms)
    backwards;
}
.ui-pa__row > .ui-pa__lane {
  margin-left: 6px;
}
.ui-pa__icon {
  display: grid;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 9px;
  background: var(--ui-pa-card);
  box-shadow: var(--ui-pa-shadow);
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-pa-text);
}
.ui-pa__icon > svg {
  width: 16px;
  height: 16px;
}
.ui-pa__row[data-picked] {
  background: var(--ui-pa-wash);
  box-shadow:
    0 0 0 1px var(--ui-pa-done-edge),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pa__row[data-quiet] {
  opacity: 0.55;
}
.ui-pa__row[data-quiet]:hover,
.ui-pa__row[data-quiet]:focus-within {
  opacity: 1;
}
.ui-pa__who {
  display: grid;
  min-width: 0;
}
.ui-pa__name {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-pa-ink);
  white-space: nowrap;
}
.ui-pa__model {
  flex: 0 10 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 400;
  color: var(--ui-pa-muted);
}
.ui-pa__name-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pa__approach {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 400;
  color: var(--ui-pa-muted);
  text-overflow: ellipsis;
}
.ui-pa__approach::before {
  content: "·";
  margin-right: 6px;
  color: var(--ui-pa-faint);
}
.ui-pa__line {
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-pa-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-pa-fade 320ms ease both;
}
.ui-pa__row[data-status="running"] .ui-pa__line {
  color: var(--k-ink);
}
.ui-pa__row[data-status="failed"] .ui-pa__line {
  color: var(--ui-pa-failed-ink);
}
.ui-pa__lane {
  position: relative;
  height: 10px;
  border-radius: 5px;
  background: var(--ui-pa-track);
}
.ui-pa__fill {
  position: absolute;
  inset: 0 auto 0 0;
  width: calc(var(--p) * 100%);
  border-radius: 5px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 1px var(--k-edge);
  overflow: hidden;
  transition:
    width 600ms var(--ui-pa-ease),
    background-color 400ms ease,
    box-shadow 400ms ease;
}
.ui-pa__row[data-status="running"] .ui-pa__fill::before {
  content: "";
  position: absolute;
  inset: 0 auto 0 0;
  width: 60px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--ui-pa-shine),
    transparent
  );
  opacity: 0.85;
  animation: ui-pa-sweep 1500ms linear infinite;
}
.ui-pa__row[data-status="running"] .ui-pa__fill::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 24px;
  background: linear-gradient(90deg, transparent, var(--k-edge));
  animation: ui-pa-glow 1100ms ease-in-out infinite alternate;
}
.ui-pa__row[data-best] .ui-pa__fill {
  background: var(--ui-pa-best-bg);
  box-shadow: inset 0 0 0 1px var(--ui-pa-best-edge);
}
.ui-pa__end {
  display: grid;
  justify-items: end;
  min-width: 0;
  text-align: right;
}
.ui-pa__score {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-pa-ink);
  font-variant-numeric: tabular-nums;
  animation: ui-pa-fade 320ms ease both;
}
.ui-pa__pct {
  font-weight: 400;
  color: var(--ui-pa-muted);
}
.ui-pa__failed {
  font-weight: 500;
  color: var(--ui-pa-failed-ink);
}
.ui-pa__best {
  height: 20px;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--ui-pa-done-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-pa-done-ink);
  animation: ui-pa-pop 420ms var(--ui-pa-ease) both;
}
.ui-pa__meta-slot {
  position: relative;
  display: grid;
  justify-items: end;
  height: 19px;
}
.ui-pa__meta {
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-pa-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  transition: opacity 160ms ease;
}
.ui-pa__use {
  position: absolute;
  top: -4px;
  right: -8px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 26px;
  padding: 0 9px;
  border-radius: 999px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-pa-text);
  white-space: nowrap;
  opacity: 0;
  transition:
    opacity 160ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-pa__row:hover .ui-pa__meta[data-hide],
.ui-pa__row:focus-within .ui-pa__meta[data-hide],
.ui-pa__row[data-picked] .ui-pa__meta[data-hide] {
  opacity: 0;
}
.ui-pa__row:hover .ui-pa__use,
.ui-pa__use:focus-visible,
.ui-pa__use[data-on] {
  opacity: 1;
}
.ui-pa__use:hover {
  background: var(--ui-pa-fill);
  color: var(--ui-pa-ink);
}
.ui-pa__use[data-on] {
  color: var(--ui-pa-done-ink);
  cursor: default;
}
.ui-pa__use[data-on]:hover {
  background: none;
}
.ui-pa [data-status="running"] {
  --k-bg: var(--ui-pa-running-bg);
  --k-edge: var(--ui-pa-running-edge);
  --k-ink: var(--ui-pa-running-ink);
}
.ui-pa [data-status="done"] {
  --k-bg: var(--ui-pa-done-bg);
  --k-edge: var(--ui-pa-done-edge);
  --k-ink: var(--ui-pa-done-ink);
}
.ui-pa [data-status="failed"] {
  --k-bg: var(--ui-pa-failed-bg);
  --k-edge: var(--ui-pa-failed-edge);
  --k-ink: var(--ui-pa-failed-ink);
}
@container ui-pa (max-width: 560px) {
  .ui-pa__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-pa__row {
    grid-template-columns: 32px minmax(0, 1fr) minmax(88px, auto);
    grid-template-areas: "icon who end" "lane lane lane";
    row-gap: 12px;
    column-gap: 12px;
    padding: 14px 16px 16px 14px;
  }
  .ui-pa__icon {
    grid-area: icon;
  }
  .ui-pa__who {
    grid-area: who;
  }
  .ui-pa__end {
    grid-area: end;
  }
  .ui-pa__row > .ui-pa__lane {
    grid-area: lane;
    margin-left: 0;
  }
  .ui-pa__approach {
    display: none;
  }
  .ui-pa__line {
    display: -webkit-box;
    min-height: 38px;
    white-space: normal;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }
}
@keyframes ui-pa-in {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
}
@keyframes ui-pa-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-pa-pop {
  0% {
    opacity: 0;
    transform: scale(0.8);
  }
  60% {
    opacity: 1;
    transform: scale(1.06);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-pa-sweep {
  from {
    transform: translateX(-60px);
  }
  to {
    transform: translateX(900px);
  }
}
@keyframes ui-pa-glow {
  from {
    opacity: 0.45;
  }
  to {
    opacity: 1;
  }
}
@media (hover: none) {
  .ui-pa__use {
    opacity: 1;
  }
  .ui-pa__meta[data-hide] {
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pa *,
  .ui-pa *::before,
  .ui-pa *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pa {
  --ui-pa-tray: #1a1a1c;
  --ui-pa-panel: #232326;
  --ui-pa-card: #2a2a2e;
  --ui-pa-strong: #f5f5f5;
  --ui-pa-ink: #f0f0f0;
  --ui-pa-text: #a1a1a1;
  --ui-pa-muted: #8a8a8a;
  --ui-pa-faint: #5c5c5c;
  --ui-pa-line: #2e2e31;
  --ui-pa-fill: rgba(255, 255, 255, 0.06);
  --ui-pa-track: #2b2b2f;
  --ui-pa-accent: #6d93ff;
  --ui-pa-focus: rgba(77, 141, 255, 0.8);
  --ui-pa-running-bg: #1d2b4d;
  --ui-pa-running-edge: #3c5fb3;
  --ui-pa-running-ink: #8aaeff;
  --ui-pa-done-bg: #15321f;
  --ui-pa-done-edge: #2f7a4b;
  --ui-pa-done-ink: #55d68c;
  --ui-pa-failed-bg: #3d1a16;
  --ui-pa-failed-edge: #8f3a2e;
  --ui-pa-failed-ink: #ff8a76;
  --ui-pa-best-bg: #1d4a2d;
  --ui-pa-best-edge: #3f9a62;
  --ui-pa-shine: rgba(255, 255, 255, 0.28);
  --ui-pa-wash: #1c2b22;
  --ui-pa-shadow: 0 0 0 1px #2e2e31, 0 1px 2px rgba(0, 0, 0, 0.4);
}
`;export{n as default};
