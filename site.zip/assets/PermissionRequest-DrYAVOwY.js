const n=`.ui-pr {
  --ui-pr-tray: #f0f0f0;
  --ui-pr-card: #ffffff;
  --ui-pr-ink: #171717;
  --ui-pr-text: #6b6b6b;
  --ui-pr-muted: #59616c;
  --ui-pr-faint: #b8b8b8;
  --ui-pr-line: #ececec;
  --ui-pr-chip: #f5f5f5;
  --ui-pr-track: #e6e6e6;
  --ui-pr-accent: #2f6bff;
  --ui-pr-ok-bg: #e6f6ec;
  --ui-pr-ok-fg: #187941;
  --ui-pr-warn-bg: #fff3e0;
  --ui-pr-warn-fg: #a45200;
  --ui-pr-danger-bg: #fdecea;
  --ui-pr-danger-fg: #c2331f;
  --ui-pr-primary: #171717;
  --ui-pr-on-primary: #ffffff;
  --ui-pr-focus: rgba(0, 96, 226, 0.7);
  --ui-pr-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 420px;
  padding: 4px;
  overflow: hidden;
  border-radius: 20px;
  background: var(--ui-pr-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-pr-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pr *,
.ui-pr *::before,
.ui-pr *::after {
  box-sizing: border-box;
}
:where(.ui-pr) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-pr button:focus-visible {
  outline: 2px solid var(--ui-pr-focus);
  outline-offset: 2px;
}
.ui-pr ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-pr h4,
.ui-pr p {
  margin: 0;
}
.ui-pr svg {
  display: block;
  flex: none;
}
.ui-pr__card {
  overflow: hidden;
  border-radius: 16px;
}
.ui-pr__ask {
  animation: ui-pr-in 260ms var(--ui-pr-ease) both;
}
.ui-pr__body {
  border-radius: 16px;
  background: var(--ui-pr-card);
  box-shadow:
    0 0 0 1px var(--ui-pr-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pr__head {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 16px 0;
}
.ui-pr__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
  border-radius: 10px;
  background: var(--ui-pr-card);
  box-shadow:
    0 0 0 1px var(--ui-pr-line),
    0 1px 2px rgba(0, 0, 0, 0.05);
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-pr-text);
  overflow: hidden;
}
.ui-pr__avatar[data-logo] > svg {
  width: 18px;
  height: 18px;
}
.ui-pr__heading {
  display: grid;
  flex: 1;
  grid-template-columns: minmax(0, 1fr);
  min-width: 0;
}
.ui-pr__title {
  color: var(--ui-pr-text);
  overflow-wrap: anywhere;
}
.ui-pr__title b {
  font-weight: 600;
  color: var(--ui-pr-ink);
}
.ui-pr__sub {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-pr-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pr__tool {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  overflow: hidden;
}
.ui-pr__sub-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pr__tool > img {
  width: 12px;
  height: 12px;
  object-fit: contain;
}
.ui-pr__avatar > img {
  width: 18px;
  height: 18px;
  object-fit: contain;
}
.ui-pr__item-icon > img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-pr__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-pr__risk {
  display: inline-flex;
  flex: none;
  align-self: start;
  align-items: center;
  gap: 4px;
  height: 22px;
  margin-top: 1px;
  padding: 0 8px 0 6px;
  border-radius: 999px;
  background: var(--ui-pr-warn-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-pr-warn-fg);
}
.ui-pr__risk[data-risk="destructive"] {
  background: var(--ui-pr-danger-bg);
  color: var(--ui-pr-danger-fg);
}
.ui-pr__why {
  margin: 12px 16px 0 60px !important;
  padding-left: 10px;
  border-left: 2px solid var(--ui-pr-line);
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-pr-text);
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-pr__preview {
  margin-top: 14px;
  padding: 12px 8px 6px;
  border-top: 1px solid var(--ui-pr-line);
}
.ui-pr__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 8px 4px !important;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-pr-muted);
}
.ui-pr__count {
  display: grid;
  flex: none;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-pr-chip);
  font-size: 11px;
  color: var(--ui-pr-text);
  font-variant-numeric: tabular-nums;
}
.ui-pr__label-text {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-pr__preview[data-open] .ui-pr__list {
  max-height: 320px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-pr__list {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
}
.ui-pr__item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 32px;
  padding: 0 8px;
  border-radius: 8px;
  animation: ui-pr-in 260ms var(--ui-pr-ease) both;
}
.ui-pr__item-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-pr-muted);
  overflow: hidden;
}
.ui-pr__item-icon > svg {
  width: 16px;
  height: 16px;
}
.ui-pr__item-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  color: var(--ui-pr-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pr__item-meta {
  flex: none;
  font-size: 12.5px;
  color: var(--ui-pr-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-pr__more {
  margin: 0 0 6px 34px;
  padding: 2px 0;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-pr-muted);
  transition: color 160ms ease;
}
.ui-pr__more:hover {
  color: var(--ui-pr-ink);
}
.ui-pr__body:not(:has(.ui-pr__preview)) {
  padding-bottom: 16px;
}
.ui-pr__answer {
  display: grid;
  gap: 12px;
  padding: 12px 8px 8px;
}
.ui-pr__scopes {
  display: flex;
  padding: 3px;
  border-radius: 12px;
  background: var(--ui-pr-track);
}
.ui-pr__scope {
  flex: 1;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-pr-muted);
  text-align: center !important;
  white-space: nowrap;
  transition:
    color 200ms ease,
    background-color 200ms ease,
    box-shadow 200ms ease;
}
.ui-pr__scope[aria-checked="true"] {
  background: var(--ui-pr-card);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  color: var(--ui-pr-ink);
}
.ui-pr__scope[aria-checked="false"]:hover {
  color: var(--ui-pr-ink);
}
.ui-pr__hint {
  margin: -6px 4px 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pr-muted);
}
.ui-pr__buttons {
  display: flex;
  gap: 8px;
}
.ui-pr__btn {
  display: inline-flex;
  flex: 1;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 40px;
  padding: 0 14px;
  border-radius: 12px;
  background: var(--ui-pr-card);
  box-shadow:
    0 0 0 1px var(--ui-pr-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-pr-ink);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    transform 120ms ease,
    opacity 160ms ease;
}
.ui-pr__btn:hover {
  background: #fafafa;
}
.ui-pr__btn:active {
  transform: scale(0.98);
}
.ui-pr__btn--primary {
  flex: 1.4;
  background: var(--ui-pr-primary);
  box-shadow: none;
  color: var(--ui-pr-on-primary);
}
.ui-pr__btn--primary:hover {
  background: var(--ui-pr-primary);
  opacity: 0.88;
}
.ui-pr[data-risk="destructive"] .ui-pr__btn--primary {
  background: var(--ui-pr-danger-fg);
}
.ui-pr__btn-label {
  animation: ui-pr-swap 220ms var(--ui-pr-ease) both;
}
.ui-pr__kbd {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 20px;
  padding: 0 5px;
  border-radius: 6px;
  background: var(--ui-pr-chip);
  font-family: inherit;
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-pr-muted);
}
.ui-pr__btn--primary .ui-pr__kbd {
  background: rgba(255, 255, 255, 0.16);
  color: rgba(255, 255, 255, 0.72);
}
.ui-pr__result {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 60px;
  padding: 10px 10px 10px 16px;
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-pr-card);
  box-shadow:
    0 0 0 1px var(--ui-pr-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  animation: ui-pr-in 300ms var(--ui-pr-ease) both;
}
.ui-pr__result-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  animation: ui-pr-pop 360ms var(--ui-pr-ease) both;
}
.ui-pr__result-icon > svg {
  width: 18px;
  height: 18px;
}
.ui-pr__result[data-kind="allowed"] .ui-pr__result-icon {
  color: var(--ui-pr-ok-fg);
}
.ui-pr__result[data-kind="denied"] .ui-pr__result-icon {
  color: var(--ui-pr-danger-fg);
}
.ui-pr__result[data-kind="expired"] .ui-pr__result-icon {
  color: var(--ui-pr-muted);
}
.ui-pr__result-text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-pr__result-head {
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-pr-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pr__result-action {
  font-weight: 400;
  color: var(--ui-pr-muted);
}
.ui-pr__result-note {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-pr-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-pr__ghost {
  flex: none;
  height: 32px;
  padding: 0 12px;
  border-radius: 999px;
  background: var(--ui-pr-chip);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-pr-ink);
  transition: background-color 160ms ease;
}
.ui-pr__ghost:hover {
  background: var(--ui-pr-line);
}
.ui-pr__drain {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  height: 3px;
  background: var(--ui-pr-chip);
}
.ui-pr__drain > span {
  display: block;
  height: 100%;
  background: var(--ui-pr-ok-fg);
  opacity: 0.6;
  transform-origin: left;
  transition: transform 900ms linear;
}
@keyframes ui-pr-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-pr-swap {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@keyframes ui-pr-pop {
  0% {
    opacity: 0;
    transform: scale(0.5);
  }
  60% {
    opacity: 1;
    transform: scale(1.12);
  }
}
@container (max-width: 360px) {
  .ui-pr__why {
    margin-left: 16px !important;
  }
  .ui-pr__scope {
    padding: 0 6px;
    font-size: 12.5px;
  }
  .ui-pr__kbd {
    display: none;
  }
}
@media (hover: none) {
  .ui-pr__kbd {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-pr__scope {
    height: 38px;
  }
  .ui-pr__btn {
    height: 46px;
  }
  .ui-pr__ghost {
    height: 40px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pr *,
  .ui-pr *::before,
  .ui-pr *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pr__btn:hover {
  background: #26262a;
}
:where(.dark, [data-theme="dark"]) .ui-pr__btn--primary:hover {
  background: var(--ui-pr-primary);
}
:where(.dark, [data-theme="dark"]) .ui-pr__btn--primary .ui-pr__kbd {
  background: rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.55);
}
:where(.dark, [data-theme="dark"])
  .ui-pr[data-risk="destructive"]
  .ui-pr__btn--primary {
  background: #e5484d;
  color: #ffffff;
}
:where(.dark, [data-theme="dark"])
  .ui-pr[data-risk="destructive"]
  .ui-pr__btn--primary
  .ui-pr__kbd {
  background: rgba(255, 255, 255, 0.18);
  color: rgba(255, 255, 255, 0.75);
}
:where(.dark, [data-theme="dark"]) .ui-pr__scope[aria-checked="true"] {
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.4),
    0 0 0 1px rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-pr {
  --ui-pr-tray: #111113;
  --ui-pr-card: #1c1c1f;
  --ui-pr-ink: #ededed;
  --ui-pr-text: #a1a1a6;
  --ui-pr-muted: #7c7c82;
  --ui-pr-faint: #4a4a50;
  --ui-pr-line: #2a2a2e;
  --ui-pr-chip: #26262a;
  --ui-pr-track: #1f1f22;
  --ui-pr-accent: #5b9aff;
  --ui-pr-ok-bg: #12301f;
  --ui-pr-ok-fg: #3dd68c;
  --ui-pr-warn-bg: #3a2410;
  --ui-pr-warn-fg: #ffa057;
  --ui-pr-danger-bg: #3b1714;
  --ui-pr-danger-fg: #ff977d;
  --ui-pr-primary: #ededed;
  --ui-pr-on-primary: #111113;
  --ui-pr-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
