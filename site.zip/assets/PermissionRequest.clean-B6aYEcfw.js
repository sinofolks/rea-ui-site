const n=`.ui-prc {
  --ui-prc-card: #ffffff;
  --ui-prc-strong: #000000;
  --ui-prc-ink: rgba(0, 0, 0, 0.88);
  --ui-prc-text: rgba(0, 0, 0, 0.65);
  --ui-prc-muted: rgba(0, 0, 0, 0.65);
  --ui-prc-faint: rgba(0, 0, 0, 0.27);
  --ui-prc-icon: rgba(0, 0, 0, 0.65);
  --ui-prc-line: rgba(0, 0, 0, 0.06);
  --ui-prc-wash: rgba(0, 0, 0, 0.03);
  --ui-prc-fill: rgba(0, 0, 0, 0.06);
  --ui-prc-accent: rgba(0, 96, 226, 0.765);
  --ui-prc-ok-bg: #00a43319;
  --ui-prc-ok-fg: #007a2d;
  --ui-prc-warn-bg: #ff9c0029;
  --ui-prc-warn-fg: #b74400;
  --ui-prc-danger-bg: #f52b0018;
  --ui-prc-danger-fg: #cd2200;
  --ui-prc-primary: #171717;
  --ui-prc-on-primary: #ffffff;
  --ui-prc-focus: rgba(0, 96, 226, 0.7);
  --ui-prc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-prc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 400px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-prc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-prc *,
.ui-prc *::before,
.ui-prc *::after {
  box-sizing: border-box;
}
:where(.ui-prc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-prc button:focus-visible {
  outline: 2px solid var(--ui-prc-focus);
  outline-offset: 2px;
}
.ui-prc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-prc h4,
.ui-prc p {
  margin: 0;
}
.ui-prc svg {
  display: block;
  flex: none;
}
.ui-prc__card {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-prc-card);
  box-shadow: var(--ui-prc-shadow);
}
.ui-prc__card:focus-within {
  outline: none;
}
.ui-prc__ask {
  animation: ui-prc-in 260ms var(--ui-prc-ease) both;
}
.ui-prc__head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 14px 14px 0 16px;
}
.ui-prc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--ui-prc-card);
  box-shadow: var(--ui-prc-shadow);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-prc-text);
  overflow: hidden;
}
.ui-prc__avatar[data-logo] > svg {
  width: 16px;
  height: 16px;
}
.ui-prc__heading {
  display: grid;
  flex: 1;
  grid-template-columns: minmax(0, 1fr);
  min-width: 0;
}
.ui-prc__title {
  color: var(--ui-prc-text);
  overflow-wrap: anywhere;
}
.ui-prc__title b {
  font-weight: 500;
  color: var(--ui-prc-strong);
}
.ui-prc__sub {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-prc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-prc__tool {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  overflow: hidden;
}
.ui-prc__sub-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-prc__tool > img {
  width: 12px;
  height: 12px;
  object-fit: contain;
}
.ui-prc__avatar > img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-prc__item-icon > img {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-prc__tool > svg {
  width: 12px;
  height: 12px;
}
.ui-prc__risk {
  display: inline-flex;
  flex: none;
  align-self: start;
  align-items: center;
  gap: 3px;
  height: 18px;
  margin-top: 1px;
  padding: 0 6px 0 4px;
  border-radius: 4px;
  background: var(--ui-prc-warn-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-prc-warn-fg);
}
.ui-prc__risk[data-risk="destructive"] {
  background: var(--ui-prc-danger-bg);
  color: var(--ui-prc-danger-fg);
}
.ui-prc__why {
  margin: 12px 16px 0 54px !important;
  padding-left: 10px;
  border-left: 2px solid var(--ui-prc-fill);
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-prc-text);
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-prc__preview {
  margin-top: 14px;
  padding: 12px 10px 4px;
  border-top: 0.5px solid var(--ui-prc-line);
}
.ui-prc__label {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 6px 4px !important;
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  color: var(--ui-prc-muted);
}
.ui-prc__count {
  display: grid;
  flex: none;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-prc-card);
  box-shadow: var(--ui-prc-shadow);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-prc-text);
  font-variant-numeric: tabular-nums;
}
.ui-prc__label-text {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-prc__preview[data-open] .ui-prc__list {
  max-height: 320px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-prc__list {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
}
.ui-prc__item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 30px;
  padding: 0 6px;
  border-radius: 6px;
  animation: ui-prc-in 260ms var(--ui-prc-ease) both;
}
.ui-prc__item-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-prc-icon);
  overflow: hidden;
}
.ui-prc__item-icon > svg {
  width: 16px;
  height: 16px;
}
.ui-prc__item-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-prc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-prc__item-meta {
  flex: none;
  font-size: 12px;
  color: var(--ui-prc-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-prc__more {
  margin: 0 0 4px 32px;
  padding: 2px 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-prc-muted);
  transition: color 160ms ease;
}
.ui-prc__more:hover {
  color: var(--ui-prc-ink);
}
.ui-prc__answer {
  display: grid;
  gap: 12px;
  padding: 12px 16px 16px;
  border-top: 0.5px solid var(--ui-prc-line);
}
.ui-prc__body:not(:has(.ui-prc__preview)) {
  padding-bottom: 14px;
}
.ui-prc__scopes {
  display: flex;
  gap: 8px;
}
.ui-prc__scope {
  flex: 1;
  padding: 3px 8px;
  border-radius: 6px;
  background: var(--ui-prc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-prc-text);
  text-align: center !important;
  white-space: nowrap;
  transition:
    color 180ms ease,
    background-color 180ms ease,
    box-shadow 180ms ease;
}
.ui-prc__scope[aria-checked="true"] {
  background: var(--ui-prc-card);
  box-shadow: var(--ui-prc-shadow);
  color: var(--ui-prc-strong);
}
.ui-prc__scope[aria-checked="false"]:hover {
  background: rgba(0, 0, 0, 0.08);
  color: var(--ui-prc-ink);
}
.ui-prc__hint {
  margin-top: -6px;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-prc-muted);
}
.ui-prc__buttons {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.ui-prc__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  height: 28px;
  padding: 0 8px 0 12px;
  border-radius: 6px;
  background: var(--ui-prc-card);
  box-shadow: var(--ui-prc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-prc-ink);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    transform 120ms ease;
}
.ui-prc__btn:hover {
  background: var(--ui-prc-wash);
}
.ui-prc__btn:active {
  transform: scale(0.98);
}
.ui-prc__btn--primary {
  background: var(--ui-prc-primary);
  box-shadow: none;
  color: var(--ui-prc-on-primary);
}
.ui-prc__btn--primary:hover {
  background: var(--ui-prc-primary);
  opacity: 0.88;
}
.ui-prc[data-risk="destructive"] .ui-prc__btn--primary {
  background: var(--ui-prc-danger-fg);
}
.ui-prc__btn-label {
  animation: ui-prc-swap 220ms var(--ui-prc-ease) both;
}
.ui-prc__kbd {
  display: grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-prc-fill);
  font-family: inherit;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-prc-muted);
}
.ui-prc__btn--primary .ui-prc__kbd {
  background: rgba(255, 255, 255, 0.16);
  color: rgba(255, 255, 255, 0.72);
}
.ui-prc__result {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 56px;
  padding: 10px 10px 10px 16px;
  animation: ui-prc-in 300ms var(--ui-prc-ease) both;
}
.ui-prc__result-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  animation: ui-prc-pop 360ms var(--ui-prc-ease) both;
}
.ui-prc__result[data-kind="allowed"] .ui-prc__result-icon {
  color: var(--ui-prc-ok-fg);
}
.ui-prc__result[data-kind="denied"] .ui-prc__result-icon {
  color: var(--ui-prc-danger-fg);
}
.ui-prc__result[data-kind="expired"] .ui-prc__result-icon {
  color: var(--ui-prc-muted);
}
.ui-prc__result-text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-prc__result-head {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-prc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-prc__result-action {
  font-weight: 400;
  color: var(--ui-prc-muted);
}
.ui-prc__result-note {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-prc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-prc__ghost {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-prc-text);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-prc__ghost:hover {
  background: var(--ui-prc-fill);
  color: var(--ui-prc-ink);
}
.ui-prc__drain {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  height: 2px;
  background: var(--ui-prc-wash);
}
.ui-prc__drain > span {
  display: block;
  height: 100%;
  background: var(--ui-prc-ok-fg);
  opacity: 0.7;
  transform-origin: left;
  transition: transform 900ms linear;
}
@keyframes ui-prc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-prc-swap {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@keyframes ui-prc-pop {
  0% {
    opacity: 0;
    transform: scale(0.5);
  }
  60% {
    opacity: 1;
    transform: scale(1.12);
  }
}
@container (max-width: 340px) {
  .ui-prc__why {
    margin-left: 16px !important;
  }
  .ui-prc__scopes {
    gap: 4px;
  }
  .ui-prc__scope {
    padding: 4px 4px;
  }
  .ui-prc__buttons > .ui-prc__btn {
    flex: 1;
  }
  .ui-prc__kbd {
    display: none;
  }
}
@media (hover: none) {
  .ui-prc__kbd {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-prc__scope {
    padding: 8px 10px;
  }
  .ui-prc__btn,
  .ui-prc__ghost {
    height: 40px;
  }
  .ui-prc__btn {
    padding: 0 16px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-prc *,
  .ui-prc *::before,
  .ui-prc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-prc__scope[aria-checked="false"]:hover {
  background: rgba(255, 255, 255, 0.11);
}
:where(.dark, [data-theme="dark"]) .ui-prc__btn--primary .ui-prc__kbd {
  background: rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.55);
}
:where(.dark, [data-theme="dark"])
  .ui-prc[data-risk="destructive"]
  .ui-prc__btn--primary {
  background: #e5484d;
  color: #ffffff;
}
:where(.dark, [data-theme="dark"])
  .ui-prc[data-risk="destructive"]
  .ui-prc__btn--primary
  .ui-prc__kbd {
  background: rgba(255, 255, 255, 0.18);
  color: rgba(255, 255, 255, 0.75);
}
:where(.dark, [data-theme="dark"]) .ui-prc {
  --ui-prc-card: #1c1c1f;
  --ui-prc-strong: #ffffff;
  --ui-prc-ink: rgba(255, 255, 255, 0.9);
  --ui-prc-text: rgba(255, 255, 255, 0.62);
  --ui-prc-muted: rgba(255, 255, 255, 0.45);
  --ui-prc-faint: rgba(255, 255, 255, 0.28);
  --ui-prc-icon: rgba(255, 255, 255, 0.5);
  --ui-prc-line: rgba(255, 255, 255, 0.08);
  --ui-prc-wash: rgba(255, 255, 255, 0.04);
  --ui-prc-fill: rgba(255, 255, 255, 0.08);
  --ui-prc-accent: #5b9aff;
  --ui-prc-ok-bg: #00f04a1f;
  --ui-prc-ok-fg: #3dd68c;
  --ui-prc-warn-bg: #fb6a0025;
  --ui-prc-warn-fg: #ffa057;
  --ui-prc-danger-bg: #ff35232b;
  --ui-prc-danger-fg: #ff977d;
  --ui-prc-primary: #ededed;
  --ui-prc-on-primary: #111113;
  --ui-prc-focus: rgba(77, 141, 255, 0.8);
  --ui-prc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
