const n=`.ui-ppc {
  --ui-ppc-focus: rgba(0, 96, 226, 0.7);
  --ui-ppc-card: #fff;
  --ui-ppc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-ppc-line: rgba(0, 0, 0, 0.06);
  --ui-ppc-ink: rgba(0, 0, 0, 0.88);
  --ui-ppc-strong: #000;
  --ui-ppc-text: rgba(0, 0, 0, 0.61);
  --ui-ppc-muted: rgba(0, 0, 0, 0.45);
  --ui-ppc-faint: rgba(0, 0, 0, 0.27);
  --ui-ppc-accent: #0070d6;
  --ui-ppc-accent-soft: rgba(0, 96, 226, 0.08);
  --ui-ppc-featured: rgba(0, 96, 226, 0.32);
  --ui-ppc-track: rgba(0, 0, 0, 0.04);
  --ui-ppc-thumb: #fff;
  --ui-ppc-wash: rgba(0, 0, 0, 0.04);
  --ui-ppc-dark: rgba(0, 0, 0, 0.88);
  --ui-ppc-dark-hover: rgba(0, 0, 0, 0.78);
  --ui-ppc-on-dark: #fcfcfc;
  --ui-ppc-tile: #fff;
  --ui-ppc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  padding: 48px 16px 56px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ppc-ink);
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
  container-type: inline-size;
}
.ui-ppc *,
.ui-ppc *::before,
.ui-ppc *::after {
  box-sizing: border-box;
}
.ui-ppc button {
  margin: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-ppc button:focus-visible {
  outline: 2px solid var(--ui-ppc-focus);
  outline-offset: 2px;
}
.ui-ppc__head {
  text-align: center;
}
.ui-ppc__title {
  margin: 0;
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.24px;
  color: var(--ui-ppc-strong);
  text-wrap: balance;
  overflow-wrap: anywhere;
}
.ui-ppc__subtitle {
  margin: 4px 0 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ppc-text);
  text-wrap: balance;
  overflow-wrap: anywhere;
}
.ui-ppc__switch {
  position: relative;
  display: grid;
  grid-template-columns: auto auto;
  width: fit-content;
  margin: 20px auto 0;
  padding: 2px;
  border-radius: 8px;
  background: var(--ui-ppc-track);
}
.ui-ppc__thumb {
  position: absolute;
  top: 2px;
  bottom: 2px;
  left: 2px;
  width: var(--ui-ppc-thumb-w, 0);
  border-radius: 6px;
  background: var(--ui-ppc-thumb);
  box-shadow: var(--ui-ppc-shadow);
  transition:
    transform 380ms var(--ui-ppc-ease),
    width 380ms var(--ui-ppc-ease);
}
.ui-ppc__option {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 28px;
  padding: 0 12px;
  border-radius: 6px;
  font-size: 13px !important;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-ppc-text) !important;
  transition: color 240ms ease;
}
.ui-ppc__option[aria-checked="true"] {
  color: var(--ui-ppc-ink) !important;
}
.ui-ppc__switch:has(.ui-ppc__option:first-of-type[aria-checked="true"])
  .ui-ppc__thumb {
  width: var(--ui-ppc-w1);
}
.ui-ppc__switch:has(.ui-ppc__option:last-of-type[aria-checked="true"])
  .ui-ppc__thumb {
  width: var(--ui-ppc-w2);
  transform: translateX(var(--ui-ppc-w1));
}
.ui-ppc__save {
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-ppc-accent-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-ppc-accent);
}
.ui-ppc__plans {
  display: grid;
  grid-template-columns: repeat(var(--ui-ppc-cols, 3), minmax(0, 1fr));
  gap: 12px;
  align-items: start;
  max-width: calc((1152px + 12px) / 3 * var(--ui-ppc-cols, 3) - 12px);
  margin: 28px auto 0;
}
@container (max-width: 828px) {
  .ui-ppc__plans {
    grid-template-columns: minmax(0, 1fr);
    max-width: 420px;
  }
}
.ui-ppc__card {
  padding: 20px;
  border-radius: 12px;
  background: var(--ui-ppc-card);
  box-shadow: var(--ui-ppc-shadow);
}
.ui-ppc__card[data-featured] {
  box-shadow:
    0 0 0 0.5px var(--ui-ppc-featured),
    0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
}
.ui-ppc__clip {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-ppc__wrap {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow-wrap: anywhere;
}
.ui-ppc__empty {
  margin: 24px 0 0;
  text-align: center;
  color: var(--ui-ppc-muted);
}
.ui-ppc__name {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  margin: 0;
  font-weight: 500;
  color: var(--ui-ppc-text);
}
.ui-ppc__badge {
  flex: none;
  max-width: 45%;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-ppc-accent-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-ppc-accent);
}
.ui-ppc__price {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 6px;
  margin: 10px 0 0;
}
.ui-ppc__amount {
  display: inline-flex;
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.24px;
  color: var(--ui-ppc-strong);
}
.ui-ppc__digit {
  display: inline-block;
  animation: ui-ppc-roll 520ms var(--ui-ppc-ease) both;
}
.ui-ppc__per {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ppc-muted);
}
.ui-ppc__billed {
  margin: 2px 0 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ppc-muted);
}
.ui-ppc .ui-ppc__cta {
  display: grid;
  place-items: center;
  width: 100%;
  height: 32px;
  margin-top: 16px;
  border-radius: 8px;
  background: var(--ui-ppc-card) !important;
  box-shadow: var(--ui-ppc-shadow);
  font-size: 13px !important;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-ppc-strong) !important;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    transform 160ms ease;
}
.ui-ppc__cta:hover {
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 1px 1px -1px rgba(0, 0, 0, 0.12),
    0 2px 4px 0 rgba(0, 0, 0, 0.07);
}
.ui-ppc__cta[data-primary] {
  background: var(--ui-ppc-dark) !important;
  box-shadow: none;
  color: var(--ui-ppc-on-dark) !important;
}
.ui-ppc__cta[data-primary]:hover {
  background: var(--ui-ppc-dark-hover) !important;
}
.ui-ppc__cta > span {
  max-width: 100%;
  padding: 0 12px;
}
.ui-ppc__cta:active {
  transform: scale(0.99);
}
.ui-ppc__limits {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 10px;
  margin: 20px 0 0;
  padding: 16px 0 0;
  box-shadow: inset 0 0.5px 0 var(--ui-ppc-line);
  list-style: none;
}
.ui-ppc__limits li {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.ui-ppc__limit-label {
  display: flex;
  min-width: 0;
  align-items: center;
  gap: 8px;
  color: var(--ui-ppc-text);
}
.ui-ppc__icon {
  display: grid;
  flex: none;
  color: var(--ui-ppc-muted);
}
.ui-ppc__limit-value {
  flex: none;
  max-width: 60%;
  font-weight: 500;
  color: var(--ui-ppc-ink);
}
.ui-ppc .ui-ppc__toggle {
  display: flex;
  align-items: center;
  gap: 4px;
  width: fit-content;
  height: 24px;
  margin: 12px auto 0;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px !important;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-ppc-muted) !important;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-ppc__toggle:hover {
  background: var(--ui-ppc-wash) !important;
  color: var(--ui-ppc-text) !important;
}
.ui-ppc__chevron {
  width: 12px;
  height: 12px;
  transition: transform 320ms var(--ui-ppc-ease);
}
.ui-ppc__toggle[aria-expanded="false"] .ui-ppc__chevron {
  transform: rotate(180deg);
}
.ui-ppc__details {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 460ms var(--ui-ppc-ease),
    opacity 280ms ease;
}
.ui-ppc__details[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-ppc__details-inner {
  min-height: 0;
  overflow: hidden;
  margin-top: 12px;
  padding-top: 16px;
  box-shadow: inset 0 0.5px 0 var(--ui-ppc-line);
}
.ui-ppc__section-head,
.ui-ppc__section-sub {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.ui-ppc__eyebrow {
  flex: none;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-ppc-muted);
}
.ui-ppc__chip {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ppc-muted);
}
.ui-ppc__section-sub {
  margin-top: 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ppc-muted);
}
.ui-ppc__tag {
  flex: none;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-ppc-accent-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-ppc-accent);
}
.ui-ppc__apps {
  display: grid;
  grid-template-columns: repeat(7, minmax(0, 20px));
  gap: 6px;
  margin-top: 12px;
}
.ui-ppc__app {
  position: relative;
  display: grid;
  place-items: center;
  aspect-ratio: 1;
  border-radius: 5px;
  background: var(--ui-ppc-tile);
  box-shadow: var(--ui-ppc-shadow);
  color: var(--ui-ppc-ink);
}
.ui-ppc__app svg {
  max-width: 60%;
  height: auto;
}
.ui-ppc__features {
  display: grid;
  gap: 8px;
  margin: 20px 0 0;
  padding: 0;
  list-style: none;
}
.ui-ppc__features li {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  color: var(--ui-ppc-muted);
}
.ui-ppc__features li[data-included] {
  color: var(--ui-ppc-ink);
}
.ui-ppc__mark {
  flex: none;
  margin-top: 2px;
  color: var(--ui-ppc-faint);
}
.ui-ppc__features li[data-included] .ui-ppc__mark {
  color: var(--ui-ppc-text);
}
.ui-ppc__feature {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-ppc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-ppc-roll {
  from {
    opacity: 0;
    transform: translateY(40%);
    filter: blur(2px);
  }
}
@media (pointer: coarse) {
  .ui-ppc__option {
    height: 36px;
  }
  .ui-ppc .ui-ppc__cta {
    height: 36px;
  }
  .ui-ppc .ui-ppc__toggle {
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ppc__thumb,
  .ui-ppc__details,
  .ui-ppc__chevron {
    transition: none;
  }
  .ui-ppc__digit {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ppc {
  --ui-ppc-focus: rgba(77, 141, 255, 0.8);
  --ui-ppc-card: #1c1c1e;
  --ui-ppc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.08), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-ppc-line: rgba(255, 255, 255, 0.08);
  --ui-ppc-ink: rgba(255, 255, 255, 0.88);
  --ui-ppc-strong: #fff;
  --ui-ppc-text: rgba(255, 255, 255, 0.61);
  --ui-ppc-muted: rgba(255, 255, 255, 0.45);
  --ui-ppc-faint: rgba(255, 255, 255, 0.27);
  --ui-ppc-accent: #4fb0fe;
  --ui-ppc-accent-soft: rgba(79, 176, 254, 0.14);
  --ui-ppc-featured: rgba(79, 176, 254, 0.45);
  --ui-ppc-track: rgba(255, 255, 255, 0.06);
  --ui-ppc-thumb: #2c2c2e;
  --ui-ppc-wash: rgba(255, 255, 255, 0.06);
  --ui-ppc-dark: rgba(255, 255, 255, 0.9);
  --ui-ppc-dark-hover: #fff;
  --ui-ppc-on-dark: #111;
  --ui-ppc-tile: #2a2a2d;
}

.pricing-plans-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
}
.pricing-plans-demo :is(.ui-pp, .ui-ppc) {
  background: 0 0;
}
.pricing-plans-demo[data-fit="stage"] {
  justify-items: center;
  padding: 8px 0 24px;
  display: grid;
}
.pricing-plans-demo[data-fit] :is(.ui-pp__plans, .ui-ppc__plans) {
  grid-template-columns: repeat(
    var(--ui-pp-cols, var(--ui-ppc-cols, 3)),
    minmax(0, 1fr)
  );
  max-width: none;
}
.card__preview .pricing-plans-demo {
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.pricing-plans-demo[data-fit="card"] .pricing-plans-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 0;
  left: 24px;
}
.card__preview .pricing-plans-demo :is(.ui-pp, .ui-ppc) {
  padding: 36px 0 0;
}
.pricing-plans-demo__frame {
  min-width: 0;
}
`;export{n as default};
