const n=`/* Colors and motion as variables – override them on .ui-pmc */
.ui-pmc {
  --ui-pmc-card: #ffffff;
  --ui-pmc-strong: #000000;
  --ui-pmc-ink: rgba(0, 0, 0, 0.88);
  --ui-pmc-text: rgba(0, 0, 0, 0.65);
  --ui-pmc-muted: rgba(0, 0, 0, 0.65);
  --ui-pmc-faint: rgba(0, 0, 0, 0.27);
  --ui-pmc-icon: rgba(0, 0, 0, 0.65);
  --ui-pmc-line: rgba(0, 0, 0, 0.06);
  --ui-pmc-wash: rgba(0, 0, 0, 0.03);
  --ui-pmc-hover: rgba(0, 0, 0, 0.06);
  --ui-pmc-track: rgba(0, 0, 0, 0.06);
  --ui-pmc-accent: #0060e2;
  --ui-pmc-focus: rgba(0, 96, 226, 0.7);
  --ui-pmc-badge: #cd1940;
  --ui-pmc-badge-wash: rgba(225, 29, 72, 0.08);
  /* Strokes are shadows: a 0.5px hairline plus a soft lift, like a popover */
  --ui-pmc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-pmc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 260px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-pmc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-pmc *,
.ui-pmc *::before,
.ui-pmc *::after {
  box-sizing: border-box;
}
:where(.ui-pmc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: left;
  cursor: pointer;
}
:where(.ui-pmc) svg {
  display: block;
  flex: none;
}

/* One white menu card – the edge is a shadow, not a border */
.ui-pmc__card {
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-pmc-card);
  box-shadow: var(--ui-pmc-shadow);
}

/* The signed-in user, separated from the actions by a hairline */
.ui-pmc__user {
  display: flex;
  align-items: center;
  gap: 10px;
  margin: 0 -4px 4px;
  padding: 8px 12px 10px;
  border-bottom: 0.5px solid var(--ui-pmc-line);
}
.ui-pmc__avatar {
  flex: none;
  width: 32px;
  height: 32px;
  overflow: hidden;
  border-radius: 50%;
  color: var(--ui-pmc-accent);
}
.ui-pmc__avatar > * {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-pmc__who {
  display: grid;
  min-width: 0;
}
.ui-pmc__name {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-pmc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pmc__email {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pmc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}

/* Actions: quiet rows, a subtle fill on hover that fades out again */
/* The column may shrink, so long labels shorten instead of widening the card; a long list scrolls */
.ui-pmc__items {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
  max-height: 320px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-pmc__item {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  height: 32px;
  padding: 0 8px;
  border-radius: 6px;
  color: var(--ui-pmc-ink);
  transition: background-color 140ms ease;
}
.ui-pmc__item:hover {
  background: var(--ui-pmc-hover);
  transition-duration: 60ms;
}
.ui-pmc__item:focus-visible {
  background: var(--ui-pmc-hover);
  outline: none;
}
.ui-pmc__item:active {
  background: rgba(0, 0, 0, 0.08);
}

.ui-pmc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 16px;
  color: var(--ui-pmc-icon);
  transition: color 140ms ease;
}
.ui-pmc__icon svg {
  width: 16px;
  height: 16px;
}
.ui-pmc__icon svg * {
  vector-effect: non-scaling-stroke;
}
.ui-pmc__item:hover .ui-pmc__icon,
.ui-pmc__item:focus-visible .ui-pmc__icon {
  color: var(--ui-pmc-ink);
}

.ui-pmc__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pmc__badge {
  flex: none;
  max-width: 50%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-pmc-badge-wash);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-pmc-badge);
}

/* Profile setup: the last row of the card, under a hairline */
.ui-pmc__setup {
  margin: 4px -4px -4px;
  padding: 10px 12px 12px;
  border-top: 0.5px solid var(--ui-pmc-line);
}
.ui-pmc__setup:has(.ui-pmc__next) {
  padding-bottom: 6px;
}
.ui-pmc__setup-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  font-size: 12px;
  line-height: 16px;
}
.ui-pmc__setup-title {
  color: var(--ui-pmc-text);
  font-weight: 500;
}
.ui-pmc__setup-count {
  font-variant-numeric: tabular-nums;
  color: var(--ui-pmc-muted);
}
.ui-pmc__track {
  display: block;
  height: 4px;
  margin-top: 8px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-pmc-track);
}
.ui-pmc__fill {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ui-pmc-accent);
  transform-origin: left center;
  scale: 0 1;
  transition: scale 900ms var(--ui-pmc-ease) 150ms;
}
.ui-pmc[data-filled] .ui-pmc__fill {
  scale: 1 1;
}
.ui-pmc__next {
  display: flex;
  align-items: center;
  gap: 8px;
  width: calc(100% + 16px);
  height: 28px;
  margin: 6px -8px 0;
  padding: 0 8px;
  border-radius: 6px;
  color: var(--ui-pmc-ink);
  transition: background-color 140ms ease;
}
.ui-pmc__next:hover {
  background: var(--ui-pmc-wash);
}
.ui-pmc__next:focus-visible {
  outline: 2px solid var(--ui-pmc-focus);
  outline-offset: 2px;
}
.ui-pmc__next-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pmc__next-hint {
  color: var(--ui-pmc-muted);
}
.ui-pmc__next svg {
  width: 16px;
  height: 16px;
  color: var(--ui-pmc-icon);
  transition:
    transform 200ms var(--ui-pmc-ease),
    color 140ms ease;
}
.ui-pmc__next svg * {
  vector-effect: non-scaling-stroke;
}
.ui-pmc__next:hover svg {
  transform: translateX(2px);
  color: var(--ui-pmc-ink);
}

/* Touch screens: taller rows */
@media (hover: none) and (pointer: coarse) {
  .ui-pmc__item {
    height: 40px;
  }
  .ui-pmc__next {
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pmc__item,
  .ui-pmc__icon,
  .ui-pmc__fill,
  .ui-pmc__next,
  .ui-pmc__next svg {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-pmc {
  --ui-pmc-card: #1c1c1e;
  --ui-pmc-strong: #ffffff;
  --ui-pmc-ink: rgba(255, 255, 255, 0.9);
  --ui-pmc-text: rgba(255, 255, 255, 0.62);
  --ui-pmc-muted: rgba(255, 255, 255, 0.46);
  --ui-pmc-faint: rgba(255, 255, 255, 0.3);
  --ui-pmc-icon: rgba(255, 255, 255, 0.46);
  --ui-pmc-line: rgba(255, 255, 255, 0.08);
  --ui-pmc-wash: rgba(255, 255, 255, 0.04);
  --ui-pmc-hover: rgba(255, 255, 255, 0.08);
  --ui-pmc-track: rgba(255, 255, 255, 0.1);
  --ui-pmc-accent: #4d8dff;
  --ui-pmc-focus: rgba(77, 141, 255, 0.8);
  --ui-pmc-badge: #fb7185;
  --ui-pmc-badge-wash: rgba(225, 29, 72, 0.14);
  --ui-pmc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-pmc__item:active {
  background: rgba(255, 255, 255, 0.1);
}
`;export{n as default};
