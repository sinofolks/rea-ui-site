const n=`/* Colors and motion as variables – override them on .ui-progressc (see Theming in the docs) */
.ui-progressc {
  --ui-pgc-card: #ffffff;
  --ui-pgc-strong: #000000;
  --ui-pgc-ink: rgba(0, 0, 0, 0.88);
  --ui-pgc-muted: rgba(0, 0, 0, 0.65);
  --ui-pgc-faint: rgba(0, 0, 0, 0.27);
  --ui-pgc-icon: rgba(0, 0, 0, 0.65);
  --ui-pgc-ring: rgba(0, 0, 0, 0.2);
  --ui-pgc-track: rgba(0, 0, 0, 0.06);
  --ui-pgc-hover: rgba(0, 0, 0, 0.03);
  --ui-pgc-accent: rgba(0, 96, 226, 0.765);
  --ui-pgc-on-accent: #ffffff;
  --ui-pgc-shine: rgba(255, 255, 255, 0.82);
  --ui-pgc-focus: rgba(0, 96, 226, 0.7);
  /* Strokes are shadows: a 0.5px hairline plus a soft lift */
  --ui-pgc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-pgc-ease: cubic-bezier(0.22, 1, 0.36, 1);

  container-type: inline-size;
  box-sizing: border-box;
  width: 100%;
  max-width: 340px;
  padding: 14px 6px 6px;
  background: var(--ui-pgc-card);
  border-radius: 10px;
  box-shadow: var(--ui-pgc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-pgc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-progressc *,
.ui-progressc *::before,
.ui-progressc *::after {
  box-sizing: border-box;
}
:where(.ui-progressc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  letter-spacing: inherit;
  color: inherit;
  cursor: pointer;
}

/* Header: the title and a quiet counter */
.ui-progressc__head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  padding: 0 10px;
}
.ui-progressc__title {
  margin: 0;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--ui-pgc-strong);
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
}
.ui-progressc__count {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pgc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
/* The number rolls in from below whenever it changes */
.ui-progressc__digit {
  display: inline-block;
  color: var(--ui-pgc-ink);
  animation: ui-progressc-roll 560ms var(--ui-pgc-ease);
}

/* A thin blue bar on a gray track */
.ui-progressc__bar {
  position: relative;
  height: 4px;
  margin: 10px 10px 8px;
  border-radius: 2px;
  background: var(--ui-pgc-track);
  overflow: hidden;
}
.ui-progressc__fill {
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-pgc-accent);
  transform-origin: 0 50%;
  overflow: hidden;
  transition: transform 1100ms var(--ui-pgc-ease);
}
/* A light band – always lighter than the bar – sweeps across */
.ui-progressc__shine {
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent 30%,
      var(--ui-pgc-shine) 50%,
      transparent 70%
    )
    0 0 / 220% 100% no-repeat;
  animation: ui-progressc-shine 1400ms ease-out both;
}

.ui-progressc__list {
  display: grid;
  /* One column that never grows past the card, so long labels shorten instead of pushing rows out */
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
  margin: 0;
  padding: 0;
  list-style: none;
}
/* On mount the card settles in, then the rows fade up one after another */
.ui-progressc {
  animation: ui-progressc-in 520ms var(--ui-pgc-ease) both;
}
.ui-progressc__list > li {
  position: relative;
  animation: ui-progressc-row-in 640ms var(--ui-pgc-ease) both;
}

.ui-progressc__step {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 6px 10px;
  border-radius: 6px;
  background: transparent;
  font-size: 13px;
  line-height: 20px;
  text-align: left;
  transition: background-color 90ms ease-out;
}
.ui-progressc__step:hover {
  background: var(--ui-pgc-hover);
}
.ui-progressc__step:focus-visible {
  outline: 2px solid var(--ui-pgc-focus);
  outline-offset: -2px;
}

/* Checkbox: a hairline ring that fills blue and pops, then the tick draws itself */
.ui-progressc__check {
  position: relative;
  flex: none;
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: transparent;
  box-shadow: inset 0 0 0 1px var(--ui-pgc-ring);
  transition:
    background-color 220ms var(--ui-pgc-ease),
    box-shadow 220ms var(--ui-pgc-ease);
}
.ui-progressc__check svg {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: var(--ui-pgc-on-accent);
  stroke-width: 2.2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  transition: stroke-dashoffset 120ms ease-in;
}
.ui-progressc__step[aria-checked="true"] .ui-progressc__check {
  background: var(--ui-pgc-accent);
  box-shadow: inset 0 0 0 1px transparent;
  animation: ui-progressc-pop 560ms var(--ui-pgc-ease);
}
.ui-progressc__step[aria-checked="true"] .ui-progressc__check svg {
  stroke-dashoffset: 0;
  transition: stroke-dashoffset 420ms var(--ui-pgc-ease) 160ms;
}

/* Label: grays out while a thin line strikes through it */
.ui-progressc__label {
  flex: 1;
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  transition: color 300ms ease;
}
.ui-progressc__label > span {
  background: linear-gradient(var(--ui-pgc-faint), var(--ui-pgc-faint)) 0 60% /
    0% 1px no-repeat;
  transition: background-size 380ms var(--ui-pgc-ease);
}
.ui-progressc__step[aria-checked="true"] .ui-progressc__label {
  color: var(--ui-pgc-muted);
}
.ui-progressc__step[aria-checked="true"] .ui-progressc__label > span {
  background-size: 100% 1px;
  transition: background-size 620ms var(--ui-pgc-ease) 220ms;
}

.ui-progressc__icon {
  flex: none;
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-pgc-icon);
  transition: opacity 300ms ease;
}
/* Any icon – an svg or an image of any shape – fits its 16px tile */
.ui-progressc__icon {
  overflow: hidden;
}
.ui-progressc__icon > :is(svg, img) {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.ui-progressc__step[aria-checked="true"] .ui-progressc__icon {
  opacity: 0.45;
}

/* Touch screens: taller rows */
@media (pointer: coarse) {
  .ui-progressc__step {
    padding-top: 10px;
    padding-bottom: 10px;
  }
}
/* Narrow cards: a little less inset */
@container (max-width: 300px) {
  .ui-progressc__head {
    padding: 0 8px;
  }
  .ui-progressc__bar {
    margin-left: 8px;
    margin-right: 8px;
  }
  .ui-progressc__step {
    padding-left: 8px;
    padding-right: 8px;
  }
}

@keyframes ui-progressc-pop {
  0% {
    transform: scale(0.9);
  }
  60% {
    transform: scale(1.08);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-progressc-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}
@keyframes ui-progressc-row-in {
  from {
    opacity: 0;
    filter: blur(3px);
    transform: translateY(8px);
  }
}
@keyframes ui-progressc-roll {
  from {
    opacity: 0;
    transform: translateY(60%);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-progressc-shine {
  from {
    background-position: 120% 0;
    opacity: 1;
  }
  to {
    background-position: -20% 0;
    opacity: 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-progressc,
  .ui-progressc *,
  .ui-progressc *::before,
  .ui-progressc *::after {
    animation: none !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-progressc {
  --ui-pgc-card: #1c1c1e;
  --ui-pgc-strong: #ffffff;
  --ui-pgc-ink: rgba(255, 255, 255, 0.9);
  --ui-pgc-muted: rgba(255, 255, 255, 0.46);
  --ui-pgc-faint: rgba(255, 255, 255, 0.3);
  --ui-pgc-icon: rgba(255, 255, 255, 0.5);
  --ui-pgc-ring: rgba(255, 255, 255, 0.24);
  --ui-pgc-track: rgba(255, 255, 255, 0.08);
  --ui-pgc-hover: rgba(255, 255, 255, 0.04);
  --ui-pgc-accent: #4d8dff;
  --ui-pgc-on-accent: #ffffff;
  --ui-pgc-shine: #ffffff;
  --ui-pgc-focus: rgba(77, 141, 255, 0.8);
  --ui-pgc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;export{n as default};
