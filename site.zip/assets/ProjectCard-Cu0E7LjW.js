const n=`.ui-pc {
  --ui-pc-tray: #f0f0f0;
  --ui-pc-card: #ffffff;
  --ui-pc-line: #ececec;
  --ui-pc-ink: #171717;
  --ui-pc-text: #404040;
  --ui-pc-muted: #626873;
  --ui-pc-well: #f4f4f5;
  --ui-pc-ring: #dcdce0;
  --ui-pc-focus: rgba(0, 96, 226, 0.7);
  --ui-pc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-pc-time: 520ms;
  box-sizing: border-box;
  width: 100%;
  max-width: 320px;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-pc-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-pc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pc *,
.ui-pc *::before,
.ui-pc *::after {
  box-sizing: border-box;
}
:where(.ui-pc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-pc button:focus-visible {
  outline: 2px solid var(--ui-pc-focus);
  outline-offset: 2px;
}
.ui-pc svg {
  display: block;
  flex: none;
}
.ui-pc b {
  font-weight: 500;
  color: var(--ui-pc-ink);
}
.ui-pc [data-tone="red"] {
  --ui-pc-tag: #b42318;
  --ui-pc-tag-bg: rgba(229, 72, 77, 0.1);
  --ui-pc-tag-on: rgba(229, 72, 77, 0.18);
}
.ui-pc [data-tone="amber"] {
  --ui-pc-tag: #96590a;
  --ui-pc-tag-bg: rgba(240, 160, 32, 0.14);
  --ui-pc-tag-on: rgba(240, 160, 32, 0.24);
}
.ui-pc [data-tone="green"] {
  --ui-pc-tag: #18794e;
  --ui-pc-tag-bg: rgba(34, 160, 90, 0.11);
  --ui-pc-tag-on: rgba(34, 160, 90, 0.2);
}
.ui-pc [data-tone="blue"] {
  --ui-pc-tag: #1f55d6;
  --ui-pc-tag-bg: rgba(47, 107, 255, 0.09);
  --ui-pc-tag-on: rgba(47, 107, 255, 0.17);
}
.ui-pc [data-tone="violet"] {
  --ui-pc-tag: #6941c6;
  --ui-pc-tag-bg: rgba(124, 92, 255, 0.1);
  --ui-pc-tag-on: rgba(124, 92, 255, 0.18);
}
.ui-pc [data-tone="gray"] {
  --ui-pc-tag: #5f5f66;
  --ui-pc-tag-bg: rgba(110, 110, 120, 0.09);
  --ui-pc-tag-on: rgba(110, 110, 120, 0.17);
}
.ui-pc__card {
  border-radius: 16px;
  background: var(--ui-pc-card);
  box-shadow:
    0 0 0 1px var(--ui-pc-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows var(--ui-pc-time) var(--ui-pc-ease),
    opacity 260ms ease;
}
.ui-pc__fold > * {
  min-height: 0;
  overflow: hidden;
}
.ui-pc[data-open] > .ui-pc__fold,
.ui-pc[data-open] > .ui-pc__card > .ui-pc__fold,
.ui-pc__fold--status[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows var(--ui-pc-time) var(--ui-pc-ease),
    opacity 380ms ease 120ms;
}
.ui-pc__head {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
}
.ui-pc__toggle {
  position: absolute;
  inset: 0;
  border-radius: 16px;
}
.ui-pc__head > :not(.ui-pc__toggle) {
  position: relative;
  pointer-events: none;
}
.ui-pc[data-open] :is(.ui-pc__status, .ui-pc__member),
.ui-pc__progress[data-live] .ui-pc__seg {
  pointer-events: auto;
}
.ui-pc__progress {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
}
.ui-pc__progress > * {
  grid-area: 1 / 1;
}
.ui-pc__seg {
  fill: none;
  stroke: var(--ui-pc-ring);
  stroke-width: 3;
  stroke-linecap: round;
  cursor: pointer;
  transition:
    stroke 260ms ease,
    stroke-width 260ms var(--ui-pc-ease),
    opacity 240ms ease;
}
.ui-pc__seg[data-done] {
  stroke: var(--ui-pc-ink);
}
.ui-pc__seg[data-hot] {
  stroke-width: 4.5;
  stroke: var(--ui-pc-muted);
}
.ui-pc__seg[data-done][data-hot] {
  stroke: var(--ui-pc-ink);
}
.ui-pc__seg[data-dim] {
  opacity: 0.3;
}
.ui-pc__num {
  font-size: 11.5px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-pc-ink);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  animation: ui-pc-num 320ms var(--ui-pc-ease) both;
}
.ui-pc__titles {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  flex: 1;
  min-width: 0;
}
.ui-pc__name {
  overflow: hidden;
  text-align: start;
  font-size: 13.5px;
  font-weight: 600;
  color: var(--ui-pc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pc__sub {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 20px;
  margin-top: 1px;
  overflow: hidden;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-pc-muted);
  white-space: nowrap;
}
.ui-pc__status {
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 100%;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 7px 0 5px;
  border-radius: 5px;
  background: var(--ui-pc-tag-bg);
  font-weight: 500;
  color: var(--ui-pc-tag);
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-pc[data-open] .ui-pc__status:hover,
.ui-pc__status[aria-expanded="true"] {
  background: var(--ui-pc-tag-on);
}
.ui-pc__status-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-pc__due {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pc__people {
  display: flex;
  flex: none;
}
.ui-pc__member {
  position: relative;
  border-radius: 50%;
  transition:
    transform 260ms var(--ui-pc-ease),
    opacity 240ms ease;
}
.ui-pc__member + .ui-pc__member {
  margin-left: -6px;
}
.ui-pc__member[data-on] {
  z-index: 1;
  transform: scale(1.12);
}
.ui-pc__member[data-off] {
  opacity: 0.4;
}
.ui-pc__member[aria-pressed="true"] .ui-pc__avatar {
  box-shadow:
    0 0 0 1.5px var(--ui-pc-card),
    0 0 0 3px var(--ui-pc-ink);
}
.ui-pc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 50%;
  background: hsl(var(--ui-pc-hue) 70% 90%);
  box-shadow: 0 0 0 1.5px var(--ui-pc-card);
  font-size: 9px;
  font-weight: 600;
  line-height: 1;
  color: hsl(var(--ui-pc-hue) 45% 34%);
  transition: box-shadow 200ms ease;
}
.ui-pc__avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-pc__more {
  position: relative;
  margin-left: -5px;
  padding: 0 3px;
  width: auto;
  min-width: 20px;
  border-radius: 10px;
  background: var(--ui-pc-well);
  color: var(--ui-pc-text);
  font-variant-numeric: tabular-nums;
}
.ui-pc[data-open] .ui-pc__more {
  pointer-events: auto;
}
.ui-pc__body {
  padding: 0 12px;
}
.ui-pc__options {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding-bottom: 10px;
}
.ui-pc__option {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 9px 0 7px;
  border-radius: 6px;
  background: var(--ui-pc-tag-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-pc-tag);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
  max-width: 100%;
}
.ui-pc__option-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pc__option:hover {
  background: var(--ui-pc-tag-on);
}
.ui-pc__option[aria-checked="true"] {
  background: var(--ui-pc-tag-on);
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-pc-tag) 34%, transparent);
}
.ui-pc__tasks {
  max-height: 352px;
  margin: 0 -6px;
  padding: 8px 6px;
  border-top: 1px solid transparent;
  overflow-y: auto;
  overscroll-behavior: contain;
  background: linear-gradient(var(--ui-pc-line), var(--ui-pc-line)) 6px 0 /
    calc(100% - 12px) 1px no-repeat border-box;
  list-style: none;
}
.ui-pc__task {
  display: flex;
  align-items: center;
  gap: 9px;
  width: calc(100% + 12px);
  height: 30px;
  margin: 0 -6px;
  padding: 0 6px;
  border-radius: 8px;
  color: var(--ui-pc-text);
  transition:
    background-color 160ms ease,
    color 200ms ease,
    opacity 240ms ease;
}
.ui-pc__task[data-hot] {
  background: var(--ui-pc-well);
}
.ui-pc__task[data-dim] {
  opacity: 0.35;
}
.ui-pc__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-pc__task .ui-pc__avatar {
  width: 18px;
  height: 18px;
  font-size: 8px;
  opacity: 0;
  transform: translateX(4px);
  transition:
    opacity 200ms ease,
    transform 260ms var(--ui-pc-ease);
}
.ui-pc__task:is([data-hot], :focus-visible) .ui-pc__avatar {
  opacity: 1;
  transform: none;
}
.ui-pc__ring {
  fill: none;
  stroke: #c9c9ce;
  stroke-width: 1.4;
  transition: stroke 160ms ease;
}
.ui-pc__task[data-hot] .ui-pc__ring {
  stroke: var(--ui-pc-muted);
}
.ui-pc__disc {
  fill: var(--ui-pc-ink);
  transform-origin: 8px 8px;
  transform: scale(0);
  transition: transform 340ms var(--ui-pc-ease);
}
.ui-pc__tick {
  fill: none;
  stroke: var(--ui-pc-card);
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 9;
  stroke-dashoffset: 9;
  transition: stroke-dashoffset 280ms var(--ui-pc-ease) 80ms;
}
.ui-pc__task[aria-checked="true"] .ui-pc__disc {
  transform: scale(1);
}
.ui-pc__task[aria-checked="true"] .ui-pc__tick {
  stroke-dashoffset: 0;
}
.ui-pc__task[aria-checked="true"] {
  color: var(--ui-pc-muted);
}
.ui-pc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 38px;
  padding: 4px 4px 0 10px;
}
.ui-pc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-align: start;
  font-size: 12.5px;
  color: var(--ui-pc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pc__caption > span {
  display: inline-block;
  animation: ui-pc-in 280ms var(--ui-pc-ease) both;
}
.ui-pc__action {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  height: 26px;
  padding: 0 6px 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-pc-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-pc__action-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pc__action:hover {
  background: var(--ui-pc-card);
  color: var(--ui-pc-ink);
}
.ui-pc__action svg {
  transition: transform 220ms var(--ui-pc-ease);
}
.ui-pc__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-pc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-pc-num {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
}
@container (max-width: 290px) {
  .ui-pc__due-word {
    display: none;
  }
  .ui-pc__member + .ui-pc__member {
    margin-left: -9px;
  }
  .ui-pc__head {
    gap: 8px;
  }
  .ui-pc__sub {
    gap: 4px;
  }
  .ui-pc__status {
    padding: 0 6px 0 4px;
  }
}
@media (pointer: coarse) {
  .ui-pc__task {
    height: 36px;
  }
  .ui-pc__task .ui-pc__avatar {
    opacity: 1;
    transform: none;
  }
  .ui-pc__option {
    height: 30px;
  }
  .ui-pc__action {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pc *,
  .ui-pc *::before,
  .ui-pc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pc {
  --ui-pc-tray: #111113;
  --ui-pc-card: #19191b;
  --ui-pc-line: #2a2a2e;
  --ui-pc-ink: #ededed;
  --ui-pc-text: #c8c8cc;
  --ui-pc-muted: #8b8b92;
  --ui-pc-well: #222225;
  --ui-pc-ring: #3a3a40;
  --ui-pc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-pc__ring {
  stroke: #4a4a50;
}
:where(.dark, [data-theme="dark"]) .ui-pc__avatar {
  background: hsl(var(--ui-pc-hue) 30% 26%);
  color: hsl(var(--ui-pc-hue) 70% 82%);
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="red"] {
  --ui-pc-tag: #ff9b93;
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="amber"] {
  --ui-pc-tag: #f5c264;
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="green"] {
  --ui-pc-tag: #6ee7a8;
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="blue"] {
  --ui-pc-tag: #9bb8ff;
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="violet"] {
  --ui-pc-tag: #c3b1ff;
}
:where(.dark, [data-theme="dark"]) .ui-pc [data-tone="gray"] {
  --ui-pc-tag: #b4b4bb;
}
`;export{n as default};
