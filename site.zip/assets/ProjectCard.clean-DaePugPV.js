const n=`.ui-pcc {
  --ui-pcc-card: #ffffff;
  --ui-pcc-ink: rgba(0, 0, 0, 0.88);
  --ui-pcc-strong: #000000;
  --ui-pcc-text: rgba(0, 0, 0, 0.65);
  --ui-pcc-muted: rgba(0, 0, 0, 0.65);
  --ui-pcc-faint: rgba(0, 0, 0, 0.27);
  --ui-pcc-icon: rgba(0, 0, 0, 0.447);
  --ui-pcc-line: rgba(0, 0, 0, 0.06);
  --ui-pcc-fill: rgba(0, 0, 0, 0.06);
  --ui-pcc-wash: rgba(0, 0, 0, 0.03);
  --ui-pcc-ring: rgba(0, 0, 0, 0.08);
  --ui-pcc-ring-hot: rgba(0, 0, 0, 0.2);
  --ui-pcc-accent: rgba(0, 96, 226, 0.765);
  --ui-pcc-primary: rgba(0, 0, 0, 0.88);
  --ui-pcc-on-primary: #fcfcfc;
  --ui-pcc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-pcc-focus: rgba(0, 96, 226, 0.7);
  --ui-pcc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-pcc-time: 520ms;
  box-sizing: border-box;
  width: 100%;
  max-width: 320px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-pcc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pcc *,
.ui-pcc *::before,
.ui-pcc *::after {
  box-sizing: border-box;
}
:where(.ui-pcc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-pcc button:focus-visible {
  outline: 2px solid var(--ui-pcc-focus);
  outline-offset: 2px;
}
:where(.ui-pcc) svg {
  display: block;
  flex: none;
}
.ui-pcc b {
  font-weight: 500;
  color: var(--ui-pcc-ink);
}
.ui-pcc [data-tone="red"] {
  --ui-pcc-tag: #c13338;
  --ui-pcc-tag-bg: rgba(229, 72, 77, 0.08);
}
.ui-pcc [data-tone="amber"] {
  --ui-pcc-tag: #915f00;
  --ui-pcc-tag-bg: rgba(232, 162, 12, 0.1);
}
.ui-pcc [data-tone="green"] {
  --ui-pcc-tag: #0f783c;
  --ui-pcc-tag-bg: rgba(26, 154, 82, 0.08);
}
.ui-pcc [data-tone="blue"] {
  --ui-pcc-tag: #0060e2;
  --ui-pcc-tag-bg: rgba(0, 96, 226, 0.06);
}
.ui-pcc [data-tone="violet"] {
  --ui-pcc-tag: #5b5bd6;
  --ui-pcc-tag-bg: rgba(91, 91, 214, 0.08);
}
.ui-pcc [data-tone="gray"] {
  --ui-pcc-tag: rgba(0, 0, 0, 0.65);
  --ui-pcc-tag-bg: rgba(0, 0, 0, 0.05);
}
.ui-pcc__card {
  border-radius: 10px;
  background: var(--ui-pcc-card);
  box-shadow: var(--ui-pcc-shadow);
}
.ui-pcc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows var(--ui-pcc-time) var(--ui-pcc-ease),
    opacity 260ms ease;
}
.ui-pcc__fold > * {
  min-height: 0;
  overflow: hidden;
}
.ui-pcc[data-open] > .ui-pcc__card > .ui-pcc__fold,
.ui-pcc__fold--status[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  transition:
    grid-template-rows var(--ui-pcc-time) var(--ui-pcc-ease),
    opacity 380ms ease 120ms;
}
.ui-pcc__head {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px;
}
.ui-pcc__toggle {
  position: absolute;
  inset: 0;
  border-radius: 10px;
}
.ui-pcc__head > :not(.ui-pcc__toggle) {
  position: relative;
  pointer-events: none;
}
.ui-pcc[data-open] :is(.ui-pcc__status, .ui-pcc__member),
.ui-pcc__progress[data-live] .ui-pcc__seg {
  pointer-events: auto;
}
.ui-pcc__progress {
  display: grid;
  flex: none;
  place-items: center;
  width: 32px;
  height: 32px;
}
.ui-pcc__progress > * {
  grid-area: 1 / 1;
}
.ui-pcc__seg {
  fill: none;
  stroke: var(--ui-pcc-ring);
  stroke-width: 3;
  stroke-linecap: round;
  cursor: pointer;
  transition:
    stroke 220ms ease,
    stroke-width 240ms var(--ui-pcc-ease),
    opacity 220ms ease;
}
.ui-pcc__seg[data-done] {
  stroke: var(--ui-pcc-accent);
}
.ui-pcc__seg[data-hot] {
  stroke-width: 4.25;
  stroke: var(--ui-pcc-ring-hot);
}
.ui-pcc__seg[data-done][data-hot] {
  stroke: var(--ui-pcc-accent);
}
.ui-pcc__seg[data-dim] {
  opacity: 0.3;
}
.ui-pcc__num {
  font-size: 12px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-pcc-strong);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  animation: ui-pcc-num 320ms var(--ui-pcc-ease) both;
}
.ui-pcc__titles {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  flex: 1;
  min-width: 0;
}
.ui-pcc__name {
  overflow: hidden;
  text-align: start;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-pcc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pcc__sub {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  height: 20px;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pcc-muted);
  white-space: nowrap;
}
.ui-pcc__status {
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 100%;
  align-items: center;
  gap: 5px;
  height: 20px;
  padding: 0 6px 0 5px;
  border-radius: 5px;
  background: var(--ui-pcc-tag-bg);
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-pcc-tag);
  transition: box-shadow 160ms ease;
}
.ui-pcc[data-open] .ui-pcc__status:hover,
.ui-pcc__status[aria-expanded="true"] {
  box-shadow: inset 0 0 0 0.5px
    color-mix(in srgb, var(--ui-pcc-tag) 35%, transparent);
}
.ui-pcc__status-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-pcc__due {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-pcc__people {
  display: flex;
  flex: none;
}
.ui-pcc__member {
  position: relative;
  border-radius: 50%;
  transition:
    transform 240ms var(--ui-pcc-ease),
    opacity 220ms ease;
}
.ui-pcc__member + .ui-pcc__member {
  margin-left: -5px;
}
.ui-pcc__member[data-on] {
  z-index: 1;
  transform: scale(1.1);
}
.ui-pcc__member[data-off] {
  opacity: 0.4;
}
.ui-pcc__member[aria-pressed="true"] .ui-pcc__avatar {
  box-shadow:
    0 0 0 1.5px var(--ui-pcc-card),
    0 0 0 2.5px var(--ui-pcc-accent);
}
.ui-pcc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  overflow: hidden;
  border-radius: 50%;
  background: hsl(var(--ui-pcc-hue) 60% 92%);
  box-shadow: 0 0 0 1.5px var(--ui-pcc-card);
  font-size: 9px;
  font-weight: 500;
  line-height: 1;
  color: hsl(var(--ui-pcc-hue) 40% 36%);
  transition: box-shadow 200ms ease;
}
.ui-pcc__avatar img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}
.ui-pcc__more {
  position: relative;
  margin-left: -5px;
  padding: 0 3px;
  width: auto;
  min-width: 20px;
  border-radius: 10px;
  background: var(--ui-pcc-fill);
  color: var(--ui-pcc-text);
  font-variant-numeric: tabular-nums;
}
.ui-pcc[data-open] .ui-pcc__more {
  pointer-events: auto;
}
.ui-pcc__body {
  padding: 0 12px;
}
.ui-pcc__options {
  display: flex;
  gap: 4px;
  margin: -2px -12px 0;
  padding: 3px 12px 12px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-pcc__options::-webkit-scrollbar {
  display: none;
}
.ui-pcc__option {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 2px 7px 2px 6px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-pcc-line);
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-pcc-text);
  white-space: nowrap;
  transition:
    background-color 120ms ease-out,
    color 120ms ease-out;
  max-width: 100%;
}
.ui-pcc__option svg {
  color: var(--ui-pcc-tag);
}
.ui-pcc__dot {
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 1.5px;
  background: var(--ui-pcc-tag);
}
.ui-pcc__option-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pcc__option:hover {
  background: var(--ui-pcc-wash);
  color: var(--ui-pcc-ink);
}
.ui-pcc__option[aria-checked="true"] {
  background: var(--ui-pcc-fill);
  color: var(--ui-pcc-ink);
}
.ui-pcc__tasks {
  max-height: 352px;
  margin: 0 -6px;
  padding: 6px 6px;
  border-top: 0.5px solid transparent;
  overflow-y: auto;
  overscroll-behavior: contain;
  background: linear-gradient(var(--ui-pcc-line), var(--ui-pcc-line)) 6px 0 /
    calc(100% - 12px) 0.5px no-repeat border-box;
  list-style: none;
}
.ui-pcc__task {
  display: flex;
  align-items: center;
  gap: 10px;
  width: calc(100% + 12px);
  height: 32px;
  margin: 0 -6px;
  padding: 0 6px;
  border-radius: 6px;
  color: var(--ui-pcc-ink);
  transition:
    background-color 90ms ease-out,
    color 200ms ease,
    opacity 220ms ease;
}
.ui-pcc__task[data-hot] {
  background: var(--ui-pcc-wash);
}
.ui-pcc__task[data-dim] {
  opacity: 0.35;
}
.ui-pcc__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-pcc__task .ui-pcc__avatar {
  width: 18px;
  height: 18px;
  font-size: 8px;
  opacity: 0;
  transform: translateX(4px);
  transition:
    opacity 200ms ease,
    transform 240ms var(--ui-pcc-ease);
}
.ui-pcc__task:is([data-hot], :focus-visible) .ui-pcc__avatar {
  opacity: 1;
  transform: none;
}
.ui-pcc__ring {
  fill: none;
  stroke: var(--ui-pcc-faint);
  stroke-width: 1.1;
  transition: stroke 160ms ease;
}
.ui-pcc__task[data-hot] .ui-pcc__ring {
  stroke: var(--ui-pcc-icon);
}
.ui-pcc__disc {
  fill: var(--ui-pcc-accent);
  transform-origin: 8px 8px;
  transform: scale(0);
  transition: transform 340ms var(--ui-pcc-ease);
}
.ui-pcc__tick {
  fill: none;
  stroke: #ffffff;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 9;
  stroke-dashoffset: 9;
  transition: stroke-dashoffset 280ms var(--ui-pcc-ease) 80ms;
}
.ui-pcc__task[aria-checked="true"] .ui-pcc__disc {
  transform: scale(1);
}
.ui-pcc__task[aria-checked="true"] .ui-pcc__tick {
  stroke-dashoffset: 0;
}
.ui-pcc__task[aria-checked="true"] {
  color: var(--ui-pcc-muted);
}
.ui-pcc__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 44px;
  padding: 0 8px 0 12px;
  border-top: 0.5px solid var(--ui-pcc-line);
}
.ui-pcc__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-align: start;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pcc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-pcc__caption > span {
  display: inline-block;
  animation: ui-pcc-in 280ms var(--ui-pcc-ease) both;
}
.ui-pcc__action {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  height: 28px;
  padding: 0 7px 0 10px;
  border-radius: 6px;
  background: var(--ui-pcc-primary);
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-pcc-on-primary);
  white-space: nowrap;
  transition: opacity 160ms ease;
}
.ui-pcc__action-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pcc__action:hover {
  opacity: 0.9;
}
.ui-pcc__action svg {
  transition: transform 220ms var(--ui-pcc-ease);
}
.ui-pcc__action:hover svg {
  transform: translateX(2px);
}
@keyframes ui-pcc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-pcc-num {
  from {
    opacity: 0;
    transform: scale(0.8);
  }
}
@container (max-width: 290px) {
  .ui-pcc__due-word {
    display: none;
  }
  .ui-pcc__member + .ui-pcc__member {
    margin-left: -8px;
  }
  .ui-pcc__head {
    gap: 8px;
    padding: 10px;
  }
  .ui-pcc__body {
    padding: 0 10px;
  }
  .ui-pcc__sub {
    gap: 4px;
  }
  .ui-pcc__status {
    padding: 0 5px 0 4px;
  }
  .ui-pcc__options {
    margin: -2px -10px 0;
    padding: 3px 10px 10px;
  }
  .ui-pcc__option {
    padding: 2px 6px;
  }
  .ui-pcc__dot {
    display: none;
  }
  .ui-pcc__foot {
    padding: 0 8px 0 10px;
  }
}
@media (pointer: coarse) {
  .ui-pcc__task {
    height: 38px;
  }
  .ui-pcc__task .ui-pcc__avatar {
    opacity: 1;
    transform: none;
  }
  .ui-pcc__option {
    height: 32px;
    padding: 0 7px 0 6px;
  }
  .ui-pcc__foot {
    height: 52px;
  }
  .ui-pcc__action {
    height: 34px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pcc *,
  .ui-pcc *::before,
  .ui-pcc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pcc {
  --ui-pcc-card: #1c1c1e;
  --ui-pcc-ink: rgba(255, 255, 255, 0.9);
  --ui-pcc-strong: #ffffff;
  --ui-pcc-text: rgba(255, 255, 255, 0.62);
  --ui-pcc-muted: rgba(255, 255, 255, 0.46);
  --ui-pcc-faint: rgba(255, 255, 255, 0.3);
  --ui-pcc-icon: rgba(255, 255, 255, 0.5);
  --ui-pcc-line: rgba(255, 255, 255, 0.08);
  --ui-pcc-fill: rgba(255, 255, 255, 0.08);
  --ui-pcc-wash: rgba(255, 255, 255, 0.04);
  --ui-pcc-ring: rgba(255, 255, 255, 0.1);
  --ui-pcc-ring-hot: rgba(255, 255, 255, 0.26);
  --ui-pcc-accent: #4d8dff;
  --ui-pcc-primary: rgba(255, 255, 255, 0.9);
  --ui-pcc-on-primary: #1c1c1e;
  --ui-pcc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-pcc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-pcc__avatar {
  background: hsl(var(--ui-pcc-hue) 26% 26%);
  color: hsl(var(--ui-pcc-hue) 60% 82%);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="red"] {
  --ui-pcc-tag: #ff8a8d;
  --ui-pcc-tag-bg: rgba(229, 72, 77, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="amber"] {
  --ui-pcc-tag: #f5c264;
  --ui-pcc-tag-bg: rgba(232, 162, 12, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="green"] {
  --ui-pcc-tag: #5fd394;
  --ui-pcc-tag-bg: rgba(26, 154, 82, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="blue"] {
  --ui-pcc-tag: #8fb6ff;
  --ui-pcc-tag-bg: rgba(77, 141, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="violet"] {
  --ui-pcc-tag: #ababf5;
  --ui-pcc-tag-bg: rgba(91, 91, 214, 0.18);
}
:where(.dark, [data-theme="dark"]) .ui-pcc [data-tone="gray"] {
  --ui-pcc-tag: rgba(255, 255, 255, 0.62);
  --ui-pcc-tag-bg: rgba(255, 255, 255, 0.08);
}
`;export{n as default};
