const n=`.ui-pf {
  --ui-pf-bg: transparent;
  --ui-pf-fade: #ffffff;
  --ui-pf-dot: #f2f2f2;
  position: relative;
  width: 100%;
  aspect-ratio: 2312 / 1644;
  overflow: hidden;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    sans-serif;
}
.ui-pf[data-theme="dark"] {
  --ui-pf-fade: #141414;
  --ui-pf-dot: #272727;
}
.ui-pf *,
.ui-pf *::before,
.ui-pf *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
.ui-pf .pf-stage {
  position: absolute;
  left: 0;
  top: 0;
  transform-origin: 0 0;
}
.ui-pf[data-theme="light"] .pf-stage {
  width: 2312px;
  height: 1644px;
  overflow: hidden;
  background: var(--ui-pf-bg);
}
.ui-pf[data-theme="light"] .pf-stage img {
  display: block;
}
.ui-pf[data-theme="light"] .pf-abs {
  position: absolute;
}
.ui-pf[data-theme="light"] .pf-dots {
  position: absolute;
  left: -245px;
  top: 122.3px;
  width: 3037px;
  height: 1398.8px;
  background-image: radial-gradient(
    circle 4px at 4px 4px,
    var(--ui-pf-dot) 99%,
    transparent 100%
  );
  background-size: 38px 38px;
  background-position: 14px 30.7px;
  -webkit-mask-image: radial-gradient(
    50% 50% at 50% 50%,
    #000 10.5%,
    transparent 100%
  );
  mask-image: radial-gradient(50% 50% at 50% 50%, #000 10.5%, transparent 100%);
}
.ui-pf[data-theme="light"] .pf-edge-overlay {
  position: absolute;
  inset: 0;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  pointer-events: none;
  z-index: 50;
  -webkit-mask-image: radial-gradient(
    1069.15px 822px at 50% 50%,
    transparent 50.5%,
    #000 100%
  );
  mask-image: radial-gradient(
    1069.15px 822px at 50% 50%,
    transparent 50.5%,
    #000 100%
  );
}
.ui-pf[data-theme="light"] .pf-edge-overlay.pf-one {
  background: color-mix(in srgb, var(--ui-pf-fade) 2%, transparent);
}
.ui-pf[data-theme="light"] .pf-edge-overlay.pf-two {
  background: color-mix(in srgb, var(--ui-pf-fade) 70%, transparent);
}
.ui-pf[data-theme="light"] .pf-card {
  position: absolute;
  background: #fff;
  border: 2px solid #efeeee;
  border-radius: 37.618px;
}
.ui-pf[data-theme="light"] .pf-shadow-sm-card {
  box-shadow:
    0 28px 8px rgba(0, 0, 0, 0),
    0 18px 7px rgba(0, 0, 0, 0.01),
    0 10px 6px rgba(0, 0, 0, 0.02),
    0 5px 5px rgba(0, 0, 0, 0.03),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="light"] .pf-shadow-md-card {
  box-shadow:
    0 56px 16px rgba(0, 0, 0, 0),
    0 36px 14px rgba(0, 0, 0, 0.01),
    0 20px 12px rgba(0, 0, 0, 0.02),
    0 9px 9px rgba(0, 0, 0, 0.03),
    0 2px 5px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="light"] .pf-shadow-sq9 {
  box-shadow:
    0 388px 109px rgba(0, 0, 0, 0),
    0 248px 99px rgba(0, 0, 0, 0.01),
    0 140px 84px rgba(0, 0, 0, 0.03),
    0 62px 62px rgba(0, 0, 0, 0.05),
    0 16px 34px rgba(0, 0, 0, 0.06);
}
.ui-pf[data-theme="light"] .pf-shadow-sq10 {
  box-shadow:
    0 277px 78px rgba(0, 0, 0, 0),
    0 177px 71px rgba(0, 0, 0, 0.01),
    0 100px 60px rgba(0, 0, 0, 0.02),
    0 44px 44px rgba(0, 0, 0, 0.03),
    0 11px 24px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="light"] .pf-t-title {
  font-weight: 500;
  font-size: 37.618px;
  line-height: 37.618px;
  letter-spacing: -0.7524px;
  color: #1b1b1b;
  white-space: nowrap;
}
.ui-pf[data-theme="light"] .pf-t-sub {
  font-weight: 400;
  font-size: 26.333px;
  line-height: 26.333px;
  letter-spacing: -0.5267px;
  color: #989898;
  white-space: nowrap;
}
.ui-pf[data-theme="light"] .pf-pill {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 11.362px 15.506px;
  background: #fdf7e8;
  border: 1.723px solid #ffebb9;
  border-radius: 68.914px;
  flex: none;
}
.ui-pf[data-theme="light"] .pf-pill span {
  font-weight: 500;
  font-size: 20.674px;
  line-height: 20.674px;
  letter-spacing: -0.4135px;
  color: #bf9221;
  white-space: nowrap;
}
.ui-pf[data-theme="light"] .pf-tech-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-pf[data-theme="light"] .pf-icon-row {
  display: flex;
  align-items: center;
  gap: 16px;
}
.ui-pf[data-theme="light"] .pf-icon {
  position: relative;
  width: 55px;
  height: 59.75px;
  flex: none;
}
.ui-pf[data-theme="light"] .pf-icon .pf-tile {
  position: absolute;
  left: 0;
  top: 0;
  width: 53.811px;
  height: 53.811px;
  border-radius: 12.729px;
}
.ui-pf[data-theme="light"] .pf-icon .pf-glow {
  position: absolute;
  width: 53.664px;
  height: 10.6px;
  border-radius: 12.729px;
  filter: blur(9.441px);
}
.ui-pf[data-theme="light"] .pf-tile img {
  position: absolute;
}
.ui-pf[data-theme="light"] .pf-ring {
  position: absolute;
  left: -6px;
  top: -6px;
  width: 65.811px;
  height: 65.811px;
  border-radius: 18.729px;
  pointer-events: none;
}
.ui-pf[data-theme="light"] .pf-ring.pf-grad {
  padding: 6px;
  opacity: 0.1;
  -webkit-mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  -webkit-mask-composite: xor;
  mask:
    linear-gradient(#fff 0 0) content-box,
    linear-gradient(#fff 0 0);
  mask-composite: exclude;
}
.ui-pf[data-theme="light"] .pf-tile.pf-slack {
  background: #4b144b;
}
.ui-pf[data-theme="light"] .pf-ring.pf-slack {
  border: 6px solid rgba(75, 20, 75, 0.1);
}
.ui-pf[data-theme="light"] .pf-glow.pf-slack {
  left: 0.97px;
  top: 48.24px;
  background: rgba(75, 20, 75, 0.6);
}
.ui-pf[data-theme="light"] .pf-slack-glyph {
  position: absolute;
  left: 11.97px;
  top: 12.34px;
  width: 29.474px;
  height: 29.474px;
}
.ui-pf[data-theme="light"] .pf-slack-glyph img {
  position: absolute;
  width: 13.946px;
  height: 13.944px;
}
.ui-pf[data-theme="light"] .pf-tile.pf-gmail {
  background: #fff;
}
.ui-pf[data-theme="light"] .pf-ring.pf-gmail {
  border: 6px solid #f6f6f6;
}
.ui-pf[data-theme="light"] .pf-glow.pf-gmail {
  left: 1.34px;
  top: 48.72px;
  background: rgba(120, 120, 120, 0.4);
}
.ui-pf[data-theme="light"] .pf-glow.pf-gmail.pf-strong {
  background: rgba(120, 120, 120, 0.6);
}
.ui-pf[data-theme="light"] .pf-tile.pf-gmail img {
  left: 11.16px;
  top: 14.34px;
  width: 30.84px;
  height: 24.532px;
}
.ui-pf[data-theme="light"] .pf-tile.pf-figma {
  background: linear-gradient(to bottom, #292c2e, #000);
}
.ui-pf[data-theme="light"] .pf-ring.pf-figma {
  background: linear-gradient(to bottom, #292c2e 4.6%, #000 86.3%);
}
.ui-pf[data-theme="light"] .pf-glow.pf-figma {
  left: 1.34px;
  top: 48.97px;
  background: rgba(68, 68, 68, 0.6);
}
.ui-pf[data-theme="light"] .pf-tile.pf-figma img {
  left: 15.35px;
  top: 9.34px;
  width: 22.823px;
  height: 34.235px;
}
.ui-pf[data-theme="light"] .pf-tile.pf-framer {
  overflow: hidden;
}
.ui-pf[data-theme="light"] .pf-ring.pf-framer {
  background: linear-gradient(to bottom, #23cffd 4.6%, #204ed7 86.3%);
}
.ui-pf[data-theme="light"] .pf-glow.pf-framer {
  left: 1.34px;
  top: 49.09px;
  background: rgba(17, 62, 244, 0.6);
}
.ui-pf[data-theme="light"] .pf-tile.pf-framer .pf-fill {
  position: absolute;
  inset: 0;
  border-radius: 12.729px;
  overflow: hidden;
}
.ui-pf[data-theme="light"] .pf-tile.pf-framer .pf-fill img {
  position: absolute;
  left: -13.85%;
  top: -13.94%;
  width: 127.69%;
  height: 127.69%;
}
.ui-pf[data-theme="light"] .pf-tile.pf-clickup {
  background: #fff;
}
.ui-pf[data-theme="light"] .pf-ring.pf-clickup {
  background: linear-gradient(to bottom, #ff6777 4.6%, #6686fb 86.3%);
}
.ui-pf[data-theme="light"] .pf-glow.pf-clickup {
  left: 1.34px;
  top: 49.15px;
  background: rgba(255, 100, 122, 0.4);
}
.ui-pf[data-theme="light"] .pf-tile.pf-clickup img {
  left: 13.73px;
  top: 11.24px;
  width: 27px;
  height: 32px;
}
.ui-pf[data-theme="light"] .pf-avatar {
  display: flex;
  align-items: center;
  padding: 8.381px;
  width: 50.285px;
  height: 50.285px;
  border-radius: 83.809px;
  flex: none;
}
.ui-pf[data-theme="light"] .pf-avatar img {
  width: 33.523px;
  height: 33.523px;
  object-fit: cover;
}
.ui-pf[data-theme="light"] .pf-avatar-lg {
  display: flex;
  align-items: center;
  padding: 17.706px;
  width: 106.237px;
  height: 106.237px;
  border-radius: 177.062px;
}
.ui-pf[data-theme="light"] .pf-avatar-lg img {
  width: 70.825px;
  height: 70.825px;
  object-fit: cover;
}
.ui-pf[data-theme="light"] .pf-bg-purple {
  background: #f0e8fd;
}
.ui-pf[data-theme="light"] .pf-bg-yellow {
  background: #fdf7e8;
}
.ui-pf[data-theme="light"] .pf-bg-pink {
  background: #fde8e8;
}
.ui-pf[data-theme="light"] .pf-client-icon {
  position: relative;
  width: 61.615px;
  height: 63.6px;
  flex: none;
}
.ui-pf[data-theme="light"] .pf-client-icon .pf-backdrop {
  position: absolute;
  left: 0;
  top: 0;
  width: 61.615px;
  height: 61.615px;
  border-radius: 14.964px;
  background: rgba(189, 189, 189, 0.2);
  backdrop-filter: blur(0.889px);
  -webkit-backdrop-filter: blur(0.889px);
}
.ui-pf[data-theme="light"] .pf-client-icon .pf-glow {
  position: absolute;
  left: 4.64px;
  top: 53px;
  width: 53.664px;
  height: 10.6px;
  border-radius: 12.729px;
  background: rgba(190, 190, 190, 0.6);
  filter: blur(9.441px);
}
.ui-pf[data-theme="light"] .pf-client-icon .pf-face {
  position: absolute;
  left: 4.32px;
  top: 4.32px;
  width: 53.811px;
  height: 53.811px;
  border-radius: 12.729px;
  background: linear-gradient(to bottom, #fff 24.981%, #f8f8f8 99.763%);
}
.ui-pf[data-theme="light"] .pf-client-icon .pf-logo {
  position: absolute;
  left: 18.34px;
  top: 20px;
  width: 24px;
  height: 24px;
}
.ui-pf[data-theme="light"] .pf-vline {
  position: absolute;
  width: 2px;
  height: 60px;
  background: #e8e8e8;
}
.ui-pf[data-theme="light"] .pf-card-unit {
  position: absolute;
  transform: translate(0, 0) rotate(6.86deg) scale(1);
}
.ui-pf[data-theme="light"] .pf-g {
  position: absolute;
  inset: 0;
}
@keyframes ui-pf-slide-down {
  from {
    opacity: 0;
    transform: translateY(-34px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pf-fade-up {
  from {
    opacity: 0;
    transform: translateY(18px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pf-fade-in {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
@keyframes ui-pf-draw-line {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-pf-undraw-line {
  to {
    stroke-dashoffset: -1;
  }
}
@keyframes ui-pf-fade-out {
  to {
    opacity: 0;
  }
}
@keyframes ui-pf-drag-in {
  from {
    opacity: 0;
    transform: translate(-300px, 340px);
  }
  20% {
    opacity: 1;
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-pf-drop-pulse {
  0% {
    transform: scale(1);
  }
  35% {
    transform: scale(0.955);
  }
  70% {
    transform: scale(1.02);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-pf-hand-away {
  0% {
    opacity: 1;
    transform: translate(0, 0) rotate(-0.85deg) scale(1);
  }
  100% {
    opacity: 0;
    transform: translate(-150px, 170px) rotate(-6deg) scale(0.9);
  }
}
@keyframes ui-pf-clear-veil {
  to {
    filter: blur(0);
    opacity: 1;
  }
}
@keyframes ui-pf-straighten-card {
  to {
    transform: translate(0, 0) rotate(0deg) scale(1);
  }
}
@keyframes ui-pf-to-md-shadow {
  to {
    box-shadow:
      0 56px 16px rgba(0, 0, 0, 0),
      0 36px 14px rgba(0, 0, 0, 0.01),
      0 20px 12px rgba(0, 0, 0, 0.02),
      0 9px 9px rgba(0, 0, 0, 0.03),
      0 2px 5px rgba(0, 0, 0, 0.04);
  }
}
.ui-pf[data-theme="light"] .pf-g-client {
  animation: ui-pf-slide-down 0.55s cubic-bezier(0.22, 0.8, 0.36, 1) 0s both;
}
.ui-pf[data-theme="light"] .pf-g-task {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 0.85s both;
}
.ui-pf[data-theme="light"] .pf-g-notes {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 1.75s both;
}
.ui-pf[data-theme="light"] .pf-g-roles {
  animation: ui-pf-fade-in 0.4s ease-out 1.8s both;
}
.ui-pf[data-theme="light"] .pf-g-pm {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 2.1s both;
}
.ui-pf[data-theme="light"] .pf-g-ux {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 2.9s both;
}
.ui-pf[data-theme="light"] .pf-dot {
  opacity: 0;
  animation: ui-pf-fade-in 0.2s ease-out both;
}
.ui-pf[data-theme="light"] .pf-draw {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 1;
  animation: ui-pf-draw-line ease-in-out both;
}
.ui-pf[data-theme="light"] .pf-g-addon {
  z-index: 55;
  animation: ui-pf-drag-in 0.75s cubic-bezier(0.2, 0.75, 0.25, 1) 3.4s both;
}
.ui-pf[data-theme="light"] .pf-addon-pulse {
  transform-origin: 615px 1025px;
  animation: ui-pf-drop-pulse 0.45s ease-in-out 4.18s both;
}
.ui-pf[data-theme="light"] .pf-addon-veil {
  filter: blur(2.2px);
  opacity: 0.82;
  animation: ui-pf-clear-veil 0.45s ease-out 4.18s both;
}
.ui-pf[data-theme="light"] .pf-sq9-unit,
.ui-pf[data-theme="light"] .pf-sq10-unit {
  animation: ui-pf-straighten-card 0.45s cubic-bezier(0.3, 0.9, 0.35, 1) 4.18s
    both;
}
.ui-pf[data-theme="light"] .pf-sq9-unit .pf-card,
.ui-pf[data-theme="light"] .pf-sq10-unit .pf-card {
  animation: ui-pf-to-md-shadow 0.45s cubic-bezier(0.3, 0.9, 0.35, 1) 4.18s both;
}
.ui-pf[data-theme="light"] .pf-hand {
  animation: ui-pf-hand-away 0.45s cubic-bezier(0.5, 0, 0.75, 0.6) 4.63s both;
}
.ui-pf[data-theme="light"] .pf-hand-grab {
  position: absolute;
  inset: 0;
  animation: ui-pf-fade-out 0.08s linear 4.33s both;
}
.ui-pf[data-theme="light"] .pf-hand-open {
  position: absolute;
  left: 6px;
  top: -7px;
  width: 174px;
  height: 174px;
  opacity: 0;
  animation: ui-pf-fade-in 0.08s linear 4.33s both;
}
.ui-pf[data-theme="light"] .pf-arrow-head {
  opacity: 0;
  animation:
    ui-pf-fade-in 0.15s ease-out 4.05s both,
    ui-pf-fade-out 0.25s ease-out 5.15s both;
}
@media (prefers-reduced-motion: reduce) {
  .ui-pf[data-theme="light"] .pf-g,
  .ui-pf[data-theme="light"] .pf-dot,
  .ui-pf[data-theme="light"] .pf-draw,
  .ui-pf[data-theme="light"] .pf-card-unit,
  .ui-pf[data-theme="light"] .pf-card-unit .pf-card,
  .ui-pf[data-theme="light"] .pf-arrow-head,
  .ui-pf[data-theme="light"] .pf-hand,
  .ui-pf[data-theme="light"] .pf-hand-grab,
  .ui-pf[data-theme="light"] .pf-hand-open {
    animation-duration: 0.001s !important;
    animation-delay: 0s !important;
  }
}
.ui-pf[data-theme="dark"] .pf-stage {
  width: 2312px;
  height: 1644px;
  overflow: hidden;
  background: var(--ui-pf-bg);
}
.ui-pf[data-theme="dark"] .pf-stage img {
  display: block;
}
.ui-pf[data-theme="dark"] .pf-abs {
  position: absolute;
}
.ui-pf[data-theme="dark"] .pf-dots {
  position: absolute;
  left: -245px;
  top: 122.3px;
  width: 3037px;
  height: 1398.8px;
  background-image: radial-gradient(
    circle 4px at 4px 4px,
    var(--ui-pf-dot) 99%,
    transparent 100%
  );
  background-size: 38px 38px;
  background-position: 14px 30.7px;
  -webkit-mask-image: radial-gradient(
    50% 50% at 50% 50%,
    #000 10.5%,
    transparent 100%
  );
  mask-image: radial-gradient(50% 50% at 50% 50%, #000 10.5%, transparent 100%);
}
.ui-pf[data-theme="dark"] .pf-edge-overlay {
  position: absolute;
  inset: 0;
  backdrop-filter: blur(4px);
  -webkit-backdrop-filter: blur(4px);
  pointer-events: none;
  z-index: 50;
  -webkit-mask-image: radial-gradient(
    1069.15px 822px at 50% 50%,
    transparent 50.5%,
    #000 100%
  );
  mask-image: radial-gradient(
    1069.15px 822px at 50% 50%,
    transparent 50.5%,
    #000 100%
  );
}
.ui-pf[data-theme="dark"] .pf-edge-overlay.pf-one {
  background: color-mix(in srgb, var(--ui-pf-fade) 2%, transparent);
}
.ui-pf[data-theme="dark"] .pf-edge-overlay.pf-two {
  background: color-mix(in srgb, var(--ui-pf-fade) 70%, transparent);
}
.ui-pf[data-theme="dark"] .pf-card {
  position: absolute;
  background: #1a1a1a;
  border: 3.762px solid #202020;
  border-radius: 37.618px;
}
.ui-pf[data-theme="dark"] .pf-shadow-sm-card {
  box-shadow:
    0 28px 8px rgba(0, 0, 0, 0),
    0 18px 7px rgba(0, 0, 0, 0.01),
    0 10px 6px rgba(0, 0, 0, 0.02),
    0 5px 5px rgba(0, 0, 0, 0.03),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="dark"] .pf-shadow-md-card {
  box-shadow:
    0 56px 16px rgba(0, 0, 0, 0),
    0 36px 14px rgba(0, 0, 0, 0.01),
    0 20px 12px rgba(0, 0, 0, 0.02),
    0 9px 9px rgba(0, 0, 0, 0.03),
    0 2px 5px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="dark"] .pf-shadow-sq9 {
  box-shadow:
    0 388px 109px rgba(0, 0, 0, 0),
    0 248px 99px rgba(0, 0, 0, 0.01),
    0 140px 84px rgba(0, 0, 0, 0.03),
    0 62px 62px rgba(0, 0, 0, 0.05),
    0 16px 34px rgba(0, 0, 0, 0.06);
}
.ui-pf[data-theme="dark"] .pf-shadow-sq10 {
  box-shadow:
    0 277px 78px rgba(0, 0, 0, 0),
    0 177px 71px rgba(0, 0, 0, 0.01),
    0 100px 60px rgba(0, 0, 0, 0.02),
    0 44px 44px rgba(0, 0, 0, 0.03),
    0 11px 24px rgba(0, 0, 0, 0.04);
}
.ui-pf[data-theme="dark"] .pf-t-title {
  font-weight: 500;
  font-size: 37.618px;
  line-height: 37.618px;
  letter-spacing: -0.7524px;
  color: #ffffff;
  white-space: nowrap;
}
.ui-pf[data-theme="dark"] .pf-t-sub {
  font-weight: 400;
  font-size: 26.333px;
  line-height: 26.333px;
  letter-spacing: -0.5267px;
  color: rgba(255, 255, 255, 0.6);
  white-space: nowrap;
}
.ui-pf[data-theme="dark"] .pf-pill {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 13.085px 17.229px;
  background: #352d19;
  border-radius: 68.914px;
  flex: none;
}
.ui-pf[data-theme="dark"] .pf-pill span {
  font-weight: 400;
  font-size: 20.674px;
  line-height: 20.674px;
  letter-spacing: -0.4135px;
  color: #eeb629;
  white-space: nowrap;
}
.ui-pf[data-theme="dark"] .pf-tech-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-pf[data-theme="dark"] .pf-icon-row {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-pf[data-theme="dark"] .pf-icon {
  position: relative;
  width: 61.615px;
  height: 63.6px;
  flex: none;
}
.ui-pf[data-theme="dark"] .pf-icon .pf-backdrop {
  position: absolute;
  left: 0;
  top: 0;
  width: 61.615px;
  height: 61.615px;
  border-radius: 14.964px;
  backdrop-filter: blur(0.889px);
  -webkit-backdrop-filter: blur(0.889px);
}
.ui-pf[data-theme="dark"] .pf-bd-slack {
  background: rgba(75, 20, 75, 0.2);
}
.ui-pf[data-theme="dark"] .pf-bd-gmail {
  background: rgba(153, 153, 153, 0.2);
}
.ui-pf[data-theme="dark"] .pf-bd-figma {
  background: rgba(124, 124, 124, 0.2);
}
.ui-pf[data-theme="dark"] .pf-bd-framer {
  background: rgba(11, 139, 248, 0.2);
}
.ui-pf[data-theme="dark"] .pf-bd-clickup {
  background: rgba(168, 168, 168, 0.2);
}
.ui-pf[data-theme="dark"] .pf-icon .pf-glow {
  position: absolute;
  left: 4.64px;
  top: 53px;
  width: 53.664px;
  height: 10.6px;
  border-radius: 12.729px;
  filter: blur(9.441px);
}
.ui-pf[data-theme="dark"] .pf-glow.pf-slack {
  background: rgba(75, 20, 75, 0.6);
}
.ui-pf[data-theme="dark"] .pf-glow.pf-gmail {
  background: rgba(0, 0, 0, 0.6);
}
.ui-pf[data-theme="dark"] .pf-glow.pf-figma {
  background: rgba(0, 0, 0, 0.6);
}
.ui-pf[data-theme="dark"] .pf-glow.pf-framer {
  background: rgba(11, 139, 248, 0.6);
}
.ui-pf[data-theme="dark"] .pf-glow.pf-clickup {
  background: rgba(0, 0, 0, 0.6);
}
.ui-pf[data-theme="dark"] .pf-icon .pf-tile {
  position: absolute;
  left: 4.32px;
  top: 4.32px;
  width: 53.811px;
  height: 53.811px;
  border-radius: 12.729px;
  overflow: hidden;
}
.ui-pf[data-theme="dark"] .pf-tile img {
  position: absolute;
}
.ui-pf[data-theme="dark"] .pf-tile-shadow {
  box-shadow:
    0 37px 10px rgba(0, 0, 0, 0),
    0 24px 9px rgba(0, 0, 0, 0.03),
    0 13px 8px rgba(0, 0, 0, 0.1),
    0 6px 6px rgba(0, 0, 0, 0.17),
    0 1px 3px rgba(0, 0, 0, 0.2);
}
.ui-pf[data-theme="dark"] .pf-tile.pf-slack {
  background: #4b144b;
}
.ui-pf[data-theme="dark"] .pf-slack-glyph {
  position: absolute;
  left: 11.97px;
  top: 12.34px;
  width: 29.474px;
  height: 29.474px;
}
.ui-pf[data-theme="dark"] .pf-slack-glyph img {
  position: absolute;
  width: 13.946px;
  height: 13.944px;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-gmail {
  background: #292929;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-gmail img {
  left: 11.16px;
  top: 14.34px;
  width: 30.84px;
  height: 24.532px;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-figma {
  background: linear-gradient(to bottom, #292c2e, #000);
}
.ui-pf[data-theme="dark"] .pf-tile.pf-figma img {
  left: 15.35px;
  top: 9.34px;
  width: 22.823px;
  height: 34.235px;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-framer .pf-fill {
  position: absolute;
  inset: 0;
  border-radius: 12.729px;
  overflow: hidden;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-framer .pf-fill img {
  position: absolute;
  left: -13.85%;
  top: -13.94%;
  width: 127.69%;
  height: 127.69%;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-clickup {
  background: #292929;
}
.ui-pf[data-theme="dark"] .pf-tile.pf-clickup img {
  left: 13.73px;
  top: 11.24px;
  width: 27px;
  height: 32px;
}
.ui-pf[data-theme="dark"] .pf-avatar {
  display: flex;
  align-items: center;
  padding: 8.381px;
  width: 50.285px;
  height: 50.285px;
  border-radius: 83.809px;
  flex: none;
}
.ui-pf[data-theme="dark"] .pf-avatar img {
  width: 33.523px;
  height: 33.523px;
  object-fit: cover;
}
.ui-pf[data-theme="dark"] .pf-avatar-lg {
  display: flex;
  align-items: center;
  padding: 17.706px;
  width: 106.237px;
  height: 106.237px;
  border-radius: 177.062px;
}
.ui-pf[data-theme="dark"] .pf-avatar-lg img {
  width: 70.825px;
  height: 70.825px;
  object-fit: cover;
}
.ui-pf[data-theme="dark"] .pf-bg-purple {
  background: #2e2653;
}
.ui-pf[data-theme="dark"] .pf-bg-yellow {
  background: #352d19;
}
.ui-pf[data-theme="dark"] .pf-bg-pink {
  background: #59274b;
}
.ui-pf[data-theme="dark"] .pf-client-icon {
  position: relative;
  width: 61.615px;
  height: 63.6px;
  flex: none;
}
.ui-pf[data-theme="dark"] .pf-client-icon .pf-backdrop {
  position: absolute;
  left: 0;
  top: 0;
  width: 61.615px;
  height: 61.615px;
  border-radius: 14.964px;
  background: rgba(218, 218, 218, 0.2);
  backdrop-filter: blur(0.889px);
  -webkit-backdrop-filter: blur(0.889px);
}
.ui-pf[data-theme="dark"] .pf-client-icon .pf-glow {
  position: absolute;
  left: 4.64px;
  top: 53px;
  width: 53.664px;
  height: 10.6px;
  border-radius: 12.729px;
  background: rgba(0, 0, 0, 0.6);
  filter: blur(9.441px);
}
.ui-pf[data-theme="dark"] .pf-client-icon .pf-face {
  position: absolute;
  left: 4.32px;
  top: 4.32px;
  width: 53.811px;
  height: 53.811px;
  border-radius: 12.729px;
  background: #292929;
}
.ui-pf[data-theme="dark"] .pf-client-icon .pf-logo {
  position: absolute;
  left: 18.34px;
  top: 20px;
  width: 24px;
  height: 24px;
}
.ui-pf[data-theme="dark"] .pf-vline {
  position: absolute;
  width: 2px;
  height: 60px;
  background: rgba(255, 255, 255, 0.8);
}
.ui-pf[data-theme="dark"] .pf-card-unit {
  position: absolute;
  transform: translate(0, 0) rotate(6.86deg) scale(1);
}
.ui-pf[data-theme="dark"] .pf-g {
  position: absolute;
  inset: 0;
}
.ui-pf[data-theme="dark"] .pf-g-client {
  animation: ui-pf-slide-down 0.55s cubic-bezier(0.22, 0.8, 0.36, 1) 0s both;
}
.ui-pf[data-theme="dark"] .pf-g-task {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 0.85s both;
}
.ui-pf[data-theme="dark"] .pf-g-notes {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 1.75s both;
}
.ui-pf[data-theme="dark"] .pf-g-roles {
  animation: ui-pf-fade-in 0.4s ease-out 1.8s both;
}
.ui-pf[data-theme="dark"] .pf-g-pm {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 2.1s both;
}
.ui-pf[data-theme="dark"] .pf-g-ux {
  animation: ui-pf-fade-up 0.45s cubic-bezier(0.22, 0.8, 0.36, 1) 2.9s both;
}
.ui-pf[data-theme="dark"] .pf-dot {
  opacity: 0;
  animation: ui-pf-fade-in 0.2s ease-out both;
}
.ui-pf[data-theme="dark"] .pf-draw {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 1;
  animation: ui-pf-draw-line ease-in-out both;
}
.ui-pf[data-theme="dark"] .pf-g-addon {
  z-index: 55;
  animation: ui-pf-drag-in 0.75s cubic-bezier(0.2, 0.75, 0.25, 1) 3.4s both;
}
.ui-pf[data-theme="dark"] .pf-addon-pulse {
  transform-origin: 615px 1025px;
  animation: ui-pf-drop-pulse 0.45s ease-in-out 4.18s both;
}
.ui-pf[data-theme="dark"] .pf-addon-veil {
  filter: blur(2.2px);
  opacity: 0.82;
  animation: ui-pf-clear-veil 0.45s ease-out 4.18s both;
}
.ui-pf[data-theme="dark"] .pf-sq9-unit,
.ui-pf[data-theme="dark"] .pf-sq10-unit {
  animation: ui-pf-straighten-card 0.45s cubic-bezier(0.3, 0.9, 0.35, 1) 4.18s
    both;
}
.ui-pf[data-theme="dark"] .pf-sq9-unit .pf-card,
.ui-pf[data-theme="dark"] .pf-sq10-unit .pf-card {
  animation: ui-pf-to-md-shadow 0.45s cubic-bezier(0.3, 0.9, 0.35, 1) 4.18s both;
}
.ui-pf[data-theme="dark"] .pf-hand {
  animation: ui-pf-hand-away 0.45s cubic-bezier(0.5, 0, 0.75, 0.6) 4.63s both;
}
.ui-pf[data-theme="dark"] .pf-hand-grab {
  position: absolute;
  inset: 0;
  animation: ui-pf-fade-out 0.08s linear 4.33s both;
}
.ui-pf[data-theme="dark"] .pf-hand-open {
  position: absolute;
  left: 6px;
  top: -7px;
  width: 174px;
  height: 174px;
  opacity: 0;
  animation: ui-pf-fade-in 0.08s linear 4.33s both;
}
.ui-pf[data-theme="dark"] .pf-arrow-head {
  opacity: 0;
  animation:
    ui-pf-fade-in 0.15s ease-out 4.05s both,
    ui-pf-fade-out 0.25s ease-out 5.15s both;
}
@media (prefers-reduced-motion: reduce) {
  .ui-pf[data-theme="dark"] .pf-g,
  .ui-pf[data-theme="dark"] .pf-dot,
  .ui-pf[data-theme="dark"] .pf-draw,
  .ui-pf[data-theme="dark"] .pf-card-unit,
  .ui-pf[data-theme="dark"] .pf-card-unit .pf-card,
  .ui-pf[data-theme="dark"] .pf-arrow-head,
  .ui-pf[data-theme="dark"] .pf-hand,
  .ui-pf[data-theme="dark"] .pf-hand-grab,
  .ui-pf[data-theme="dark"] .pf-hand-open {
    animation-duration: 0.001s !important;
    animation-delay: 0s !important;
  }
}

.project-flow-demo {
  width: 100%;
}
.project-flow-demo .ui-pf[data-theme] {
  --ui-pf-fade: var(--preview);
  --ui-pf-dot: color-mix(in srgb, var(--text) 6%, var(--preview));
}
.stage .project-flow-demo {
  width: min(100%, 600px);
}
.card__preview .project-flow-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .project-flow-demo .ui-pf {
  width: auto;
  height: 106%;
}
`;export{n as default};
