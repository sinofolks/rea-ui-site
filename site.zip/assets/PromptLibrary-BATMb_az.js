const n=`.ui-pli {
  --ui-pli-tray: #f0f0f0;
  --ui-pli-card: #ffffff;
  --ui-pli-line: #ececec;
  --ui-pli-ink: #171717;
  --ui-pli-text: #404040;
  --ui-pli-muted: #626873;
  --ui-pli-well: #f4f4f5;
  --ui-pli-accent: #2f6bff;
  --ui-pli-accent-ink: #1f55d6;
  --ui-pli-accent-bg: rgba(47, 107, 255, 0.09);
  --ui-pli-accent-flash: rgba(47, 107, 255, 0.24);
  --ui-pli-hole: #626873;
  --ui-pli-on-ink: #ffffff;
  --ui-pli-ok: #18794e;
  --ui-pli-blue: #2a5ee5;
  --ui-pli-blue-bg: rgba(47, 107, 255, 0.1);
  --ui-pli-violet: #6941c6;
  --ui-pli-violet-bg: rgba(105, 65, 198, 0.1);
  --ui-pli-amber: #96590a;
  --ui-pli-amber-bg: rgba(240, 160, 32, 0.14);
  --ui-pli-green: #18794e;
  --ui-pli-green-bg: rgba(34, 160, 90, 0.11);
  --ui-pli-red: #b42318;
  --ui-pli-red-bg: rgba(229, 72, 77, 0.1);
  --ui-pli-gray: #5f5f66;
  --ui-pli-gray-bg: #f0f0f2;
  --ui-pli-focus: rgba(0, 96, 226, 0.7);
  --ui-pli-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 640px;
  min-width: 0;
  container-type: inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-pli-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-pli-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pli *,
.ui-pli *::before,
.ui-pli *::after {
  box-sizing: border-box;
}
:where(.ui-pli) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-pli) input {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  outline: none;
}
.ui-pli button:focus-visible,
.ui-pli__option:focus-visible {
  outline: 2px solid var(--ui-pli-focus);
  outline-offset: 2px;
}
.ui-pli svg {
  display: block;
  flex: none;
}
.ui-pli b {
  font-weight: 500;
  color: var(--ui-pli-ink);
}
.ui-pli p {
  margin: 0;
}
.ui-pli__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-pli__card {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  border-radius: 16px;
  background: var(--ui-pli-card);
  box-shadow:
    0 0 0 1px var(--ui-pli-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-pli__side {
  min-width: 0;
  padding: 12px 8px 8px;
  border-right: 1px solid var(--ui-pli-line);
}
.ui-pli__side-head {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 6px;
}
.ui-pli__title {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-pli-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pli__total {
  font-size: 12px;
  color: var(--ui-pli-muted);
  font-variant-numeric: tabular-nums;
}
.ui-pli__search {
  display: flex;
  align-items: center;
  gap: 7px;
  height: 30px;
  margin-top: 8px;
  padding: 0 9px;
  border-radius: 8px;
  background: var(--ui-pli-well);
  color: var(--ui-pli-muted);
  cursor: text;
  transition: box-shadow 160ms ease;
}
.ui-pli__search:focus-within {
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-pli-muted) 45%, transparent);
}
.ui-pli__search input {
  flex: 1;
  min-width: 0;
  height: 100%;
  font-size: 12.5px;
  color: var(--ui-pli-ink);
  -webkit-appearance: none;
  appearance: none;
}
.ui-pli__search input::placeholder {
  color: var(--ui-pli-muted);
}
.ui-pli__search input::-webkit-search-cancel-button {
  -webkit-appearance: none;
}
.ui-pli__list {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin-top: 6px;
}
.ui-pli__glide {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  border-radius: 9px;
  background: var(--ui-pli-well);
  opacity: 0;
  pointer-events: none;
  transition: opacity 180ms ease;
}
.ui-pli__glide[data-on] {
  opacity: 1;
}
.ui-pli__glide[data-moved] {
  transition:
    transform 340ms var(--ui-pli-ease),
    height 340ms var(--ui-pli-ease),
    opacity 180ms ease;
}
.ui-pli__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 34px;
  padding: 0 6px 0 8px;
  border-radius: 9px;
  color: var(--ui-pli-text);
  cursor: pointer;
  user-select: none;
  transition: color 160ms ease;
  -webkit-tap-highlight-color: transparent;
}
.ui-pli__option::before {
  content: "";
  position: absolute;
  inset: 0;
  z-index: -1;
  border-radius: inherit;
  transition: background-color 160ms ease;
}
.ui-pli__list {
  isolation: isolate;
}
.ui-pli__glide {
  z-index: -1;
}
.ui-pli__option:hover:not([aria-selected="true"])::before {
  background: color-mix(in srgb, var(--ui-pli-well) 55%, transparent);
}
.ui-pli__option[aria-selected="true"] {
  color: var(--ui-pli-ink);
}
.ui-pli__option-title {
  text-align: start;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pli__empty {
  height: 34px;
  padding: 0 8px;
  font-size: 12.5px;
  line-height: 34px;
  color: var(--ui-pli-muted);
}
.ui-pli__tag {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
  overflow: hidden;
  text-overflow: ellipsis;
  height: 18px;
  padding: 0 5px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  white-space: nowrap;
  color: var(--ui-pli-gray);
  background: var(--ui-pli-gray-bg);
}
.ui-pli__tag[data-tone="blue"] {
  color: var(--ui-pli-blue);
  background: var(--ui-pli-blue-bg);
}
.ui-pli__tag[data-tone="violet"] {
  color: var(--ui-pli-violet);
  background: var(--ui-pli-violet-bg);
}
.ui-pli__tag[data-tone="amber"] {
  color: var(--ui-pli-amber);
  background: var(--ui-pli-amber-bg);
}
.ui-pli__tag[data-tone="green"] {
  color: var(--ui-pli-green);
  background: var(--ui-pli-green-bg);
}
.ui-pli__tag[data-tone="red"] {
  color: var(--ui-pli-red);
  background: var(--ui-pli-red-bg);
}
.ui-pli__main {
  display: grid;
  min-width: 0;
}
.ui-pli__panel {
  grid-area: 1 / 1;
  min-width: 0;
  padding: 12px 14px 14px;
  animation: ui-pli-in 360ms ease both;
}
.ui-pli__panel[data-out] {
  animation: ui-pli-out 240ms ease both;
  pointer-events: none;
}
.ui-pli__panel-head {
  display: flex;
  flex-wrap: wrap;
  row-gap: 4px;
  align-items: center;
  gap: 8px;
  min-height: 22px;
}
.ui-pli__panel-title {
  flex: 1 1 auto;
  min-width: 0;
  text-align: start;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  color: var(--ui-pli-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pli__count {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  margin-left: auto;
  font-size: 12px;
  color: var(--ui-pli-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-pli__bars {
  display: inline-flex;
  gap: 2px;
}
.ui-pli__bar {
  width: 8px;
  height: 4px;
  border-radius: 2px;
  background: var(--ui-pli-line);
  transition: background-color 300ms ease;
}
.ui-pli__bar[data-on] {
  background: var(--ui-pli-accent);
}
.ui-pli__body {
  margin-top: 10px !important;
  white-space: pre-line;
  text-align: start;
  font-size: 13px;
  line-height: 26px;
  color: var(--ui-pli-text);
  overflow-wrap: anywhere;
}
.ui-pli__glue {
  white-space: nowrap;
}
.ui-pli__preview .ui-pli__glue {
  white-space: inherit;
}
.ui-pli__token {
  position: relative;
  display: inline-grid;
  vertical-align: top;
  max-width: 100%;
  height: 22px;
  margin: 2px 0;
  padding: 0 6px;
  border-radius: 6px;
  background: var(--ui-pli-well);
  box-shadow: inset 0 0 0 1px var(--ui-pli-line);
  line-height: 22px;
  color: var(--ui-pli-muted);
  cursor: text;
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease,
    color 200ms ease;
}
.ui-pli__token:hover {
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-pli-muted) 45%, transparent);
}
.ui-pli__token[data-filled] {
  background: var(--ui-pli-accent-bg);
  box-shadow: none;
  color: var(--ui-pli-accent-ink);
}
.ui-pli__token:focus-within {
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-pli-muted) 70%, transparent);
}
.ui-pli__token[data-flash="a"] {
  animation: ui-pli-flash-a 900ms ease-out;
}
.ui-pli__token[data-flash="b"] {
  animation: ui-pli-flash-b 900ms ease-out;
}
.ui-pli__sizer,
.ui-pli__input {
  grid-area: 1 / 1;
  min-width: 2ch;
  font-size: 13px;
  line-height: 22px;
  white-space: pre;
}
.ui-pli__sizer {
  padding-right: 1px;
  font-weight: 500;
  visibility: hidden;
  overflow: hidden;
}
.ui-pli__input {
  width: 100%;
  height: 22px;
  color: inherit;
  font-weight: 500;
  text-overflow: ellipsis;
}
.ui-pli__input::placeholder {
  color: var(--ui-pli-muted);
  font-weight: 400;
  opacity: 1;
}
.ui-pli__label {
  margin-top: 12px;
  font-size: 12px;
  color: var(--ui-pli-muted);
}
.ui-pli__preview {
  max-height: 168px;
  overflow-y: auto;
  overscroll-behavior: contain;
  text-align: start;
  margin-top: 4px;
  padding: 9px 11px;
  border-radius: 10px;
  background: var(--ui-pli-well);
  font-size: 12.5px;
  line-height: 20px;
  color: var(--ui-pli-text);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-pli__fill {
  border-radius: 4px;
  color: var(--ui-pli-ink);
  font-weight: 500;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
.ui-pli__fill[data-flash="a"] {
  animation: ui-pli-mark-a 1100ms ease-out;
}
.ui-pli__fill[data-flash="b"] {
  animation: ui-pli-mark-b 1100ms ease-out;
}
.ui-pli__hole {
  color: var(--ui-pli-hole);
}
.ui-pli__foot {
  display: flex;
  align-items: center;
  gap: 4px;
  min-height: 40px;
  padding: 4px 2px 0 10px;
}
.ui-pli__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-pli-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-pli__swap {
  display: grid;
  min-width: 0;
}
.ui-pli__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-pli-swap-in 320ms ease both;
}
.ui-pli__swap-item[data-out] {
  animation: ui-pli-swap-out 220ms ease both;
}
.ui-pli__swap-item[data-tone="ok"] {
  color: var(--ui-pli-ok);
}
.ui-pli__copy {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 28px;
  padding: 0 9px 0 8px;
  border-radius: 10px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-pli-text);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-pli__copy:hover:not(:disabled) {
  background: var(--ui-pli-card);
  color: var(--ui-pli-ink);
}
.ui-pli__copy-icon {
  display: grid;
  place-items: center;
  width: 12px;
  height: 12px;
  animation: ui-pli-swap-in 300ms ease both;
}
.ui-pli__use {
  position: relative;
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  align-items: center;
  gap: 5px;
  height: 28px;
  padding: 0 9px 0 11px;
  border-radius: 10px;
  background: var(--ui-pli-ink);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-pli-on-ink);
  white-space: nowrap;
  transition:
    background-color 200ms ease,
    color 200ms ease,
    opacity 200ms ease;
}
.ui-pli__use svg {
  transition: transform 220ms var(--ui-pli-ease);
}
.ui-pli__use:hover:not([aria-disabled="true"]) svg {
  transform: translateX(2px);
}
.ui-pli__use[aria-disabled="true"] {
  background: color-mix(in srgb, var(--ui-pli-ink) 10%, transparent);
  color: var(--ui-pli-muted);
  cursor: default;
}
.ui-pli__use[data-pulse="a"] {
  animation: ui-pli-pulse-a 1400ms ease-out;
}
.ui-pli__use[data-pulse="b"] {
  animation: ui-pli-pulse-b 1400ms ease-out;
}
.ui-pli__use-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pli__list[data-scroll] {
  max-height: 400px;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 3px;
  margin: 3px -3px -3px;
}
.ui-pli__list[data-scroll] .ui-pli__glide {
  left: 3px;
  right: 3px;
}
@keyframes ui-pli-in {
  from {
    opacity: 0;
    filter: blur(2px);
    transform: translateY(3px);
  }
}
@keyframes ui-pli-out {
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-pli-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-pli-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-pli-flash-a {
  from {
    background-color: var(--ui-pli-accent-flash);
  }
}
@keyframes ui-pli-flash-b {
  from {
    background-color: var(--ui-pli-accent-flash);
  }
}
@keyframes ui-pli-mark-a {
  from {
    background-color: var(--ui-pli-accent-flash);
    box-shadow: 0 0 0 2px var(--ui-pli-accent-flash);
  }
  to {
    background-color: transparent;
    box-shadow: 0 0 0 2px transparent;
  }
}
@keyframes ui-pli-mark-b {
  from {
    background-color: var(--ui-pli-accent-flash);
    box-shadow: 0 0 0 2px var(--ui-pli-accent-flash);
  }
  to {
    background-color: transparent;
    box-shadow: 0 0 0 2px transparent;
  }
}
@keyframes ui-pli-pulse-a {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--ui-pli-ink) 30%, transparent);
  }
  60%,
  100% {
    box-shadow: 0 0 0 8px transparent;
  }
}
@keyframes ui-pli-pulse-b {
  0% {
    box-shadow: 0 0 0 0 color-mix(in srgb, var(--ui-pli-ink) 30%, transparent);
  }
  60%,
  100% {
    box-shadow: 0 0 0 8px transparent;
  }
}
@container (max-width: 540px) {
  .ui-pli__card {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-pli__side {
    border-right: 0;
    border-bottom: 1px solid var(--ui-pli-line);
  }
}
@container (max-width: 360px) {
  .ui-pli__copy {
    width: 28px;
    padding: 0;
    justify-content: center;
  }
  .ui-pli__copy-text {
    display: none;
  }
  .ui-pli__count .ui-pli__bars {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-pli__option {
    height: 40px;
  }
  .ui-pli__search {
    height: 36px;
  }
  .ui-pli__copy,
  .ui-pli__use {
    height: 34px;
  }
  .ui-pli__body {
    line-height: 30px;
  }
  .ui-pli__token,
  .ui-pli__input,
  .ui-pli__sizer {
    height: 26px;
    line-height: 26px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pli *,
  .ui-pli *::before,
  .ui-pli *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pli {
  --ui-pli-tray: #111113;
  --ui-pli-card: #19191b;
  --ui-pli-line: #2a2a2e;
  --ui-pli-ink: #ededed;
  --ui-pli-text: #c8c8cc;
  --ui-pli-muted: #8b8b92;
  --ui-pli-well: #222225;
  --ui-pli-accent: #4f82ff;
  --ui-pli-accent-ink: #9dbbff;
  --ui-pli-accent-bg: rgba(79, 130, 255, 0.16);
  --ui-pli-accent-flash: rgba(79, 130, 255, 0.36);
  --ui-pli-hole: #5c5c63;
  --ui-pli-on-ink: #111113;
  --ui-pli-ok: #6ee7a8;
  --ui-pli-blue: #8fb1ff;
  --ui-pli-blue-bg: rgba(79, 130, 255, 0.16);
  --ui-pli-violet: #b9a2f5;
  --ui-pli-violet-bg: rgba(150, 110, 240, 0.16);
  --ui-pli-amber: #f5c264;
  --ui-pli-amber-bg: rgba(240, 160, 32, 0.15);
  --ui-pli-green: #6ee7a8;
  --ui-pli-green-bg: rgba(34, 160, 90, 0.16);
  --ui-pli-red: #ff9b93;
  --ui-pli-red-bg: rgba(229, 72, 77, 0.16);
  --ui-pli-gray: #b4b4ba;
  --ui-pli-gray-bg: #26262a;
  --ui-pli-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
