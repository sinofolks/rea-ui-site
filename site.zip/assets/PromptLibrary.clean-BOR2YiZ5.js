const n=`.ui-plic {
  --ui-plic-card: #ffffff;
  --ui-plic-ink: rgba(0, 0, 0, 0.88);
  --ui-plic-strong: #000000;
  --ui-plic-text: rgba(0, 0, 0, 0.65);
  --ui-plic-muted: rgba(0, 0, 0, 0.65);
  --ui-plic-faint: rgba(0, 0, 0, 0.65);
  --ui-plic-icon: rgba(0, 0, 0, 0.65);
  --ui-plic-line: rgba(0, 0, 0, 0.06);
  --ui-plic-line-strong: rgba(0, 0, 0, 0.1);
  --ui-plic-wash: rgba(0, 0, 0, 0.03);
  --ui-plic-well: rgba(0, 0, 0, 0.025);
  --ui-plic-fill: rgba(0, 0, 0, 0.06);
  --ui-plic-accent: rgba(0, 96, 226, 0.765);
  --ui-plic-accent-bg: rgba(0, 96, 226, 0.05);
  --ui-plic-pulse: rgba(0, 0, 0, 0.2);
  --ui-plic-accent-flash: rgba(0, 96, 226, 0.16);
  --ui-plic-on-ink: #fcfcfc;
  --ui-plic-ok: #0f783c;
  --ui-plic-blue: #1f5fc4;
  --ui-plic-blue-bg: rgba(0, 96, 226, 0.07);
  --ui-plic-violet: #5b45b8;
  --ui-plic-violet-bg: rgba(91, 91, 214, 0.08);
  --ui-plic-amber: #93600a;
  --ui-plic-amber-bg: rgba(232, 162, 12, 0.1);
  --ui-plic-green: #157a46;
  --ui-plic-green-bg: rgba(26, 154, 82, 0.08);
  --ui-plic-red: #c0363b;
  --ui-plic-red-bg: rgba(229, 72, 77, 0.08);
  --ui-plic-gray: rgba(0, 0, 0, 0.65);
  --ui-plic-gray-bg: rgba(0, 0, 0, 0.05);
  --ui-plic-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-plic-focus: rgba(0, 96, 226, 0.7);
  --ui-plic-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 640px;
  min-width: 0;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-plic-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-plic *,
.ui-plic *::before,
.ui-plic *::after {
  box-sizing: border-box;
}
:where(.ui-plic) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-plic) input {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  outline: none;
}
.ui-plic button:focus-visible,
.ui-plic__option:focus-visible {
  outline: 2px solid var(--ui-plic-focus);
  outline-offset: 2px;
}
:where(.ui-plic) svg {
  display: block;
  flex: none;
}
.ui-plic b {
  font-weight: 500;
  color: var(--ui-plic-ink);
}
.ui-plic p {
  margin: 0;
}
.ui-plic__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-plic__card {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-plic-card);
  box-shadow: var(--ui-plic-shadow);
}
.ui-plic__cols {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
}
.ui-plic__side {
  min-width: 0;
  padding: 12px 8px 8px;
  border-right: 0.5px solid var(--ui-plic-line);
}
.ui-plic__side-head {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 20px;
  padding: 0 8px;
}
.ui-plic__title {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-plic-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-plic__total {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-plic-faint);
  font-variant-numeric: tabular-nums;
}
.ui-plic__search {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  margin-top: 10px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-plic-line-strong);
  color: var(--ui-plic-icon);
  cursor: text;
  transition: box-shadow 160ms ease;
}
.ui-plic__search:hover {
  box-shadow: inset 0 0 0 0.5px rgba(0, 0, 0, 0.16);
}
.ui-plic__search:focus-within {
  outline: none;
  box-shadow: inset 0 0 0 1px var(--ui-plic-line-strong);
}
.ui-plic__search input {
  flex: 1;
  min-width: 0;
  height: 100%;
  font-size: 13px;
  color: var(--ui-plic-ink);
  caret-color: var(--ui-plic-accent);
  -webkit-appearance: none;
  appearance: none;
}
.ui-plic__search input::placeholder {
  color: var(--ui-plic-faint);
}
.ui-plic__search input::-webkit-search-cancel-button {
  -webkit-appearance: none;
}
.ui-plic__list {
  position: relative;
  isolation: isolate;
  display: flex;
  flex-direction: column;
  gap: 2px;
  margin-top: 8px;
}
.ui-plic__glide {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  z-index: -1;
  border-radius: 6px;
  background: var(--ui-plic-fill);
  opacity: 0;
  pointer-events: none;
  transition: opacity 140ms ease;
}
.ui-plic__glide[data-on] {
  opacity: 1;
}
.ui-plic__glide[data-moved] {
  transition:
    transform 90ms ease-out,
    height 90ms ease-out,
    opacity 140ms ease;
}
.ui-plic__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  height: 32px;
  padding: 0 6px 0 8px;
  border-radius: 6px;
  color: var(--ui-plic-text);
  cursor: pointer;
  user-select: none;
  transition: color 140ms ease;
  -webkit-tap-highlight-color: transparent;
}
.ui-plic__option::before {
  content: "";
  position: absolute;
  inset: 0;
  z-index: -1;
  border-radius: inherit;
  transition: background-color 140ms ease;
}
.ui-plic__option:hover:not([aria-selected="true"])::before {
  background: var(--ui-plic-wash);
}
.ui-plic__option:hover,
.ui-plic__option[aria-selected="true"] {
  color: var(--ui-plic-ink);
}
.ui-plic__option-title {
  text-align: start;
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-plic__empty {
  height: 32px;
  padding: 0 8px;
  line-height: 32px;
  color: var(--ui-plic-muted);
}
.ui-plic__tag {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
  overflow: hidden;
  text-overflow: ellipsis;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  white-space: nowrap;
  color: var(--ui-plic-gray);
  background: var(--ui-plic-gray-bg);
}
.ui-plic__tag[data-tone="blue"] {
  color: var(--ui-plic-blue);
  background: var(--ui-plic-blue-bg);
}
.ui-plic__tag[data-tone="violet"] {
  color: var(--ui-plic-violet);
  background: var(--ui-plic-violet-bg);
}
.ui-plic__tag[data-tone="amber"] {
  color: var(--ui-plic-amber);
  background: var(--ui-plic-amber-bg);
}
.ui-plic__tag[data-tone="green"] {
  color: var(--ui-plic-green);
  background: var(--ui-plic-green-bg);
}
.ui-plic__tag[data-tone="red"] {
  color: var(--ui-plic-red);
  background: var(--ui-plic-red-bg);
}
.ui-plic__main {
  display: grid;
  min-width: 0;
}
.ui-plic__panel {
  grid-area: 1 / 1;
  min-width: 0;
  padding: 12px 16px 16px;
  animation: ui-plic-in 360ms var(--ui-plic-ease) both;
}
.ui-plic__panel[data-out] {
  animation: ui-plic-out 240ms ease both;
  pointer-events: none;
}
.ui-plic__panel-head {
  display: flex;
  flex-wrap: wrap;
  row-gap: 4px;
  align-items: center;
  gap: 8px;
  min-height: 20px;
}
.ui-plic__panel-title {
  flex: 1 1 auto;
  min-width: 0;
  text-align: start;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-plic-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-plic__count {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-plic-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-plic__bars {
  display: inline-flex;
  gap: 2px;
}
.ui-plic__bar {
  width: 6px;
  height: 6px;
  border-radius: 1.5px;
  background: var(--ui-plic-fill);
  transition: background-color 300ms ease;
}
.ui-plic__bar[data-on] {
  background: var(--ui-plic-accent);
}
.ui-plic__body {
  margin-top: 10px !important;
  white-space: pre-line;
  text-align: start;
  font-size: 13px;
  line-height: 28px;
  color: var(--ui-plic-ink);
  overflow-wrap: anywhere;
}
.ui-plic__glue {
  white-space: nowrap;
}
.ui-plic__preview .ui-plic__glue {
  white-space: inherit;
}
.ui-plic__token {
  position: relative;
  display: inline-grid;
  vertical-align: top;
  max-width: 100%;
  height: 22px;
  margin: 3px 0;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-plic-wash);
  box-shadow: inset 0 0 0 0.5px var(--ui-plic-line-strong);
  line-height: 22px;
  color: var(--ui-plic-ink);
  cursor: text;
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease,
    color 200ms ease;
}
.ui-plic__token:hover {
  background: var(--ui-plic-fill);
}
.ui-plic__token[data-filled] {
  background: var(--ui-plic-accent-bg);
  box-shadow: inset 0 0 0 0.5px transparent;
}
.ui-plic__token:focus-within {
  outline: none;
  background: var(--ui-plic-card);
  box-shadow: inset 0 0 0 1px var(--ui-plic-line-strong);
}
.ui-plic__token[data-flash="a"] {
  animation: ui-plic-flash-a 900ms ease-out;
}
.ui-plic__token[data-flash="b"] {
  animation: ui-plic-flash-b 900ms ease-out;
}
.ui-plic__sizer,
.ui-plic__input {
  grid-area: 1 / 1;
  min-width: 2ch;
  font-size: 13px;
  line-height: 22px;
  white-space: pre;
}
.ui-plic__sizer {
  padding-right: 1px;
  font-weight: 500;
  visibility: hidden;
  overflow: hidden;
}
.ui-plic__input {
  width: 100%;
  height: 22px;
  color: inherit;
  font-weight: 500;
  text-overflow: ellipsis;
  caret-color: var(--ui-plic-accent);
}
.ui-plic__input::placeholder {
  color: var(--ui-plic-muted);
  font-weight: 400;
  opacity: 1;
}
.ui-plic__label {
  margin-top: 12px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-plic-muted);
}
.ui-plic__preview {
  max-height: 168px;
  overflow-y: auto;
  overscroll-behavior: contain;
  text-align: start;
  margin-top: 4px;
  padding: 8px 12px;
  border-radius: 8px;
  background: var(--ui-plic-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-plic-line);
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-plic-text);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-plic__fill {
  border-radius: 4px;
  color: var(--ui-plic-ink);
  font-weight: 500;
  box-decoration-break: clone;
  -webkit-box-decoration-break: clone;
}
.ui-plic__fill[data-flash="a"] {
  animation: ui-plic-mark-a 1100ms ease-out;
}
.ui-plic__fill[data-flash="b"] {
  animation: ui-plic-mark-b 1100ms ease-out;
}
.ui-plic__hole {
  color: var(--ui-plic-faint);
}
.ui-plic__foot {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 44px;
  padding: 0 8px 0 16px;
  border-top: 0.5px solid var(--ui-plic-line);
}
.ui-plic__caption {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-plic-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-plic__swap {
  display: grid;
  min-width: 0;
}
.ui-plic__swap-item {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-plic-swap-in 320ms ease both;
}
.ui-plic__swap-item[data-out] {
  animation: ui-plic-swap-out 220ms ease both;
}
.ui-plic__swap-item[data-tone="ok"] {
  color: var(--ui-plic-ok);
}
.ui-plic__copy {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  background: var(--ui-plic-card);
  box-shadow: var(--ui-plic-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-plic-strong);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-plic__copy:hover:not(:disabled) {
  background: color-mix(in srgb, var(--ui-plic-card), #000 3%);
}
.ui-plic__copy-icon {
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-plic-icon);
  animation: ui-plic-swap-in 300ms ease both;
}
.ui-plic__copy-icon[data-done] {
  color: var(--ui-plic-ok);
}
.ui-plic__use {
  position: relative;
  display: inline-flex;
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 8px 0 10px;
  border-radius: 6px;
  background: var(--ui-plic-ink);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-plic-on-ink);
  white-space: nowrap;
  transition:
    background-color 200ms ease,
    color 200ms ease;
}
.ui-plic__use svg {
  transition: transform 220ms var(--ui-plic-ease);
}
.ui-plic__use:hover:not([aria-disabled="true"]) {
  background: var(--ui-plic-strong);
}
.ui-plic__use:hover:not([aria-disabled="true"]) svg {
  transform: translateX(2px);
}
.ui-plic__use[aria-disabled="true"] {
  background: var(--ui-plic-fill);
  color: var(--ui-plic-muted);
  cursor: default;
}
.ui-plic__use[data-pulse="a"] {
  animation: ui-plic-pulse-a 1400ms ease-out;
}
.ui-plic__use[data-pulse="b"] {
  animation: ui-plic-pulse-b 1400ms ease-out;
}
.ui-plic__use-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-plic__list[data-scroll] {
  max-height: 400px;
  overflow-y: auto;
  overscroll-behavior: contain;
  padding: 3px;
  margin: 5px -3px -3px;
}
.ui-plic__list[data-scroll] .ui-plic__glide {
  left: 3px;
  right: 3px;
}
@keyframes ui-plic-in {
  from {
    opacity: 0;
    filter: blur(2px);
    transform: translateY(3px);
  }
}
@keyframes ui-plic-out {
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-plic-swap-in {
  from {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-plic-swap-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-plic-flash-a {
  from {
    background-color: var(--ui-plic-accent-flash);
  }
}
@keyframes ui-plic-flash-b {
  from {
    background-color: var(--ui-plic-accent-flash);
  }
}
@keyframes ui-plic-mark-a {
  from {
    background-color: var(--ui-plic-accent-flash);
    box-shadow: 0 0 0 2px var(--ui-plic-accent-flash);
  }
  to {
    background-color: transparent;
    box-shadow: 0 0 0 2px transparent;
  }
}
@keyframes ui-plic-mark-b {
  from {
    background-color: var(--ui-plic-accent-flash);
    box-shadow: 0 0 0 2px var(--ui-plic-accent-flash);
  }
  to {
    background-color: transparent;
    box-shadow: 0 0 0 2px transparent;
  }
}
@keyframes ui-plic-pulse-a {
  0% {
    box-shadow: 0 0 0 0 var(--ui-plic-pulse);
  }
  60%,
  100% {
    box-shadow: 0 0 0 6px transparent;
  }
}
@keyframes ui-plic-pulse-b {
  0% {
    box-shadow: 0 0 0 0 var(--ui-plic-pulse);
  }
  60%,
  100% {
    box-shadow: 0 0 0 6px transparent;
  }
}
@container (max-width: 540px) {
  .ui-plic__cols {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-plic__side {
    border-right: 0;
    border-bottom: 0.5px solid var(--ui-plic-line);
  }
}
@container (max-width: 360px) {
  .ui-plic__copy {
    width: 28px;
    padding: 0;
    justify-content: center;
  }
  .ui-plic__copy-text {
    display: none;
  }
  .ui-plic__count .ui-plic__bars {
    display: none;
  }
  .ui-plic__panel {
    padding: 12px 12px 14px;
  }
  .ui-plic__foot {
    padding-left: 12px;
  }
}
@media (pointer: coarse) {
  .ui-plic__option {
    height: 40px;
  }
  .ui-plic__search {
    height: 36px;
  }
  .ui-plic__copy,
  .ui-plic__use {
    height: 34px;
  }
  .ui-plic__copy {
    padding-right: 12px;
  }
  .ui-plic__foot {
    height: 50px;
  }
  .ui-plic__body {
    line-height: 32px;
  }
  .ui-plic__token,
  .ui-plic__input,
  .ui-plic__sizer {
    height: 26px;
    line-height: 26px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-plic *,
  .ui-plic *::before,
  .ui-plic *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-plic {
  --ui-plic-card: #1c1c1e;
  --ui-plic-ink: rgba(255, 255, 255, 0.9);
  --ui-plic-strong: #ffffff;
  --ui-plic-text: rgba(255, 255, 255, 0.62);
  --ui-plic-muted: rgba(255, 255, 255, 0.46);
  --ui-plic-faint: rgba(255, 255, 255, 0.3);
  --ui-plic-icon: rgba(255, 255, 255, 0.5);
  --ui-plic-line: rgba(255, 255, 255, 0.08);
  --ui-plic-line-strong: rgba(255, 255, 255, 0.12);
  --ui-plic-wash: rgba(255, 255, 255, 0.04);
  --ui-plic-well: rgba(255, 255, 255, 0.03);
  --ui-plic-fill: rgba(255, 255, 255, 0.08);
  --ui-plic-accent: #4d8dff;
  --ui-plic-accent-bg: rgba(77, 141, 255, 0.14);
  --ui-plic-pulse: rgba(255, 255, 255, 0.25);
  --ui-plic-accent-flash: rgba(77, 141, 255, 0.3);
  --ui-plic-on-ink: #1c1c1e;
  --ui-plic-ok: #3ec27a;
  --ui-plic-blue: #8fb4ff;
  --ui-plic-blue-bg: rgba(77, 141, 255, 0.14);
  --ui-plic-violet: #b7a6f5;
  --ui-plic-violet-bg: rgba(130, 120, 240, 0.15);
  --ui-plic-amber: #f2c063;
  --ui-plic-amber-bg: rgba(232, 162, 12, 0.14);
  --ui-plic-green: #6fd69c;
  --ui-plic-green-bg: rgba(26, 154, 82, 0.16);
  --ui-plic-red: #ff9a9d;
  --ui-plic-red-bg: rgba(229, 72, 77, 0.15);
  --ui-plic-gray: rgba(255, 255, 255, 0.62);
  --ui-plic-gray-bg: rgba(255, 255, 255, 0.08);
  --ui-plic-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-plic-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-plic__search:hover {
  box-shadow: inset 0 0 0 0.5px rgba(255, 255, 255, 0.18);
}
:where(.dark, [data-theme="dark"]) .ui-plic__copy:hover:not(:disabled) {
  background: #232326;
}
:where(.dark, [data-theme="dark"])
  .ui-plic__use:hover:not([aria-disabled="true"]) {
  background: #ffffff;
}
`;export{n as default};
