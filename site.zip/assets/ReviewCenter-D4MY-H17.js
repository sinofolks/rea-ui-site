const n=`.ui-rvc {
  --ui-rvc-tray: #f0f0f0;
  --ui-rvc-card: #ffffff;
  --ui-rvc-strong: #171717;
  --ui-rvc-ink: #171717;
  --ui-rvc-text: #5f5f5f;
  --ui-rvc-muted: #626873;
  --ui-rvc-faint: #6b6b6b;
  --ui-rvc-line: #ececec;
  --ui-rvc-queue-bg: #fafafa;
  --ui-rvc-line-strong: #dedede;
  --ui-rvc-code-ink: rgba(0, 0, 0, 0.88);
  --ui-rvc-code-num: rgba(0, 0, 0, 0.65);
  --ui-rvc-diff-add: rgba(0, 160, 80, 0.06);
  --ui-rvc-diff-del: rgba(215, 36, 0, 0.05);
  --ui-rvc-diff-add-fg: #297840;
  --ui-rvc-diff-del-fg: #b8412b;
  --ui-rvc-tok-kw: #b82968;
  --ui-rvc-tok-str: color(display-p3 0.38 0.647 0.378);
  --ui-rvc-tok-type: color(display-p3 0.247 0.556 0.969);
  --ui-rvc-tok-fn: color(display-p3 0.587 0.29 0.667);
  --ui-rvc-ring-soft: rgba(47, 107, 255, 0.12);
  --ui-rvc-hover: rgba(0, 0, 0, 0.03);
  --ui-rvc-chip: #f3f3f3;
  --ui-rvc-wash: #f7f7f7;
  --ui-rvc-accent: #2a5ee5;
  --ui-rvc-new: rgba(47, 107, 255, 0.09);
  --ui-rvc-primary: #171717;
  --ui-rvc-primary-fg: #ffffff;
  --ui-rvc-bar-bg: #e9efff;
  --ui-rvc-bar-edge: #bccdfb;
  --ui-rvc-bar-mark: #5b86f5;
  --ui-rvc-track: #f1f1f1;
  --ui-rvc-high-bg: #fde8e5;
  --ui-rvc-high-edge: #f1a397;
  --ui-rvc-high-fg: #c2331f;
  --ui-rvc-mid-bg: #fff3e0;
  --ui-rvc-mid-edge: #f3c98d;
  --ui-rvc-mid-fg: #a45200;
  --ui-rvc-low-bg: #e6f6ec;
  --ui-rvc-low-edge: #a9dcbc;
  --ui-rvc-low-fg: #187941;
  --ui-rvc-flag-bg: #fff2d4;
  --ui-rvc-flag-edge: #f0b44c;
  --ui-rvc-flag-hot: #ffe2a6;
  --ui-rvc-flag-ink: #6e4300;
  --ui-rvc-ins-bg: #dcf5e5;
  --ui-rvc-ins-ink: #11673a;
  --ui-rvc-add-bg: #effaf3;
  --ui-rvc-del-bg: #fdf0ee;
  --ui-rvc-focus: rgba(0, 96, 226, 0.7);
  --ui-rvc-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-rvc-raised: 0 0 0 1px #e8e8e8, 0 1px 3px rgba(0, 0, 0, 0.07);
  --ui-rvc-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-rvc-height: 560px;
  --ui-rvc-queue: 300px;
  --ui-rvc-row: 60px;
  --ui-rvc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-rvc-ease-in: cubic-bezier(0.55, 0, 0.75, 0.3);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-rvc-tray);
  outline: none;
  container: ui-rvc / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-rvc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-rvc *,
.ui-rvc *::before,
.ui-rvc *::after {
  box-sizing: border-box;
}
:where(.ui-rvc) :is(button, input, textarea) {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-rvc) button {
  cursor: pointer;
}
:where(.ui-rvc) button:disabled {
  cursor: default;
}
.ui-rvc :is(button, a, mark):focus-visible {
  outline: 2px solid var(--ui-rvc-focus);
  outline-offset: 2px;
}
.ui-rvc :is(input, textarea):focus-visible {
  outline: none;
}
:where(.ui-rvc) :is(p, dl, dd, h3, ul, ol) {
  margin: 0;
  padding: 0;
}
.ui-rvc svg {
  display: block;
  flex: none;
}
.ui-rvc__kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-rvc-chip);
  font-size: 10.5px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-rvc-muted);
  letter-spacing: 0;
}
.ui-rvc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-rvc__head {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  min-width: 0;
  min-height: 44px;
  padding: 4px 6px 8px 12px;
}
.ui-rvc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  margin-right: -4px;
  color: var(--ui-rvc-accent);
}
.ui-rvc__heading {
  flex: none;
  font-weight: 600;
  color: var(--ui-rvc-strong);
}
.ui-rvc__progress {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
}
.ui-rvc__count {
  font-variant-numeric: tabular-nums;
}
.ui-rvc__count b {
  display: inline-block;
  font-weight: 500;
  color: var(--ui-rvc-ink);
  animation: ui-rvc-tick 420ms var(--ui-rvc-ease) both;
}
.ui-rvc__track {
  position: relative;
  width: 84px;
  height: 8px;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-rvc-card);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-line);
}
.ui-rvc__fill {
  position: absolute;
  inset: 0 auto 0 0;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-rvc-bar-bg);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-bar-edge);
  transition: width 700ms var(--ui-rvc-ease);
}
.ui-rvc__track[data-live] .ui-rvc__fill::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent,
      var(--ui-rvc-card),
      transparent
    ) -40px
    0 / 40px 100% no-repeat;
  opacity: 0.7;
  animation: ui-rvc-sweep 1800ms linear infinite;
}
.ui-rvc__fill::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(18px, 100%);
  background: linear-gradient(90deg, transparent, var(--ui-rvc-bar-mark));
  opacity: 0.55;
  animation: ui-rvc-glow 1100ms ease-in-out infinite alternate;
}
.ui-rvc__oldest {
  flex: none;
  margin-left: -4px;
  font-size: 13px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
}
.ui-rvc__oldest::before {
  content: "·";
  margin-right: 8px;
  color: var(--ui-rvc-faint);
}
.ui-rvc__oldest b {
  font-weight: 500;
  color: var(--ui-rvc-text);
  font-variant-numeric: tabular-nums;
}
.ui-rvc__oldest b[data-sla="near"] {
  color: var(--ui-rvc-mid-fg);
}
.ui-rvc__oldest b[data-sla="over"] {
  color: var(--ui-rvc-high-fg);
}
.ui-rvc__filters {
  display: flex;
  flex: 1;
  gap: 4px;
  min-width: 0;
}
.ui-rvc__filter {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 8px;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-rvc__filter:hover {
  color: var(--ui-rvc-ink);
}
.ui-rvc__filter[aria-pressed="true"] {
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-raised);
  color: var(--ui-rvc-ink);
}
.ui-rvc__filter-count {
  font-size: 11.5px;
  color: var(--ui-rvc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rvc__filter[aria-pressed="true"] .ui-rvc__filter-count {
  color: var(--ui-rvc-muted);
}
.ui-rvc__card {
  position: relative;
  display: grid;
  grid-template-columns: var(--ui-rvc-queue) minmax(0, 1fr);
  height: var(--ui-rvc-height);
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-shadow);
}
.ui-rvc__queue {
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  border-right: 1px solid var(--ui-rvc-line);
  background: var(--ui-rvc-queue-bg);
}
.ui-rvc__queue-head {
  display: flex;
  flex: none;
  align-items: center;
  padding: 8px;
  background: var(--ui-rvc-card);
  border-bottom: 1px solid var(--ui-rvc-line);
}
.ui-rvc__list {
  position: relative;
  flex: 1;
  min-height: 0;
  padding: 8px;
  overflow: hidden auto;
  overscroll-behavior: contain;
  list-style: none;
  scrollbar-width: thin;
}
.ui-rvc__item {
  height: calc(var(--ui-rvc-row) + 4px);
  padding: 2px 0;
  overflow: hidden;
}
.ui-rvc__item[data-enter="first"] {
  animation: ui-rvc-row-in 460ms var(--ui-rvc-ease) var(--d) backwards;
}
.ui-rvc__item:is([data-enter="new"], [data-enter="in"]) {
  animation: ui-rvc-open 520ms var(--ui-rvc-ease) var(--d) backwards;
}
.ui-rvc__item[data-enter="new"] .ui-rvc__row {
  animation: ui-rvc-arrive 2200ms ease-out backwards;
}
.ui-rvc__item[data-leaving] {
  pointer-events: none;
  animation: ui-rvc-close 300ms var(--ui-rvc-ease) var(--d) forwards;
}
.ui-rvc__item[data-leaving][data-decision] {
  animation-delay: calc(var(--d) + 180ms);
}
.ui-rvc__row {
  position: relative;
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr);
  align-items: center;
  column-gap: 10px;
  width: 100%;
  height: var(--ui-rvc-row);
  padding: 0 10px;
  border-radius: 10px;
  transition:
    background-color 160ms ease,
    box-shadow 200ms ease;
}
.ui-rvc__row:hover {
  background: var(--ui-rvc-hover);
}
.ui-rvc__row[aria-current] {
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-raised);
}
.ui-rvc__row:focus-visible {
  outline-offset: -2px;
}
.ui-rvc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-rvc-card);
  box-shadow:
    0 0 0 1px var(--ui-rvc-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-rvc-text);
}
.ui-rvc__avatar > svg {
  width: 15px;
  height: 15px;
}
.ui-rvc__row-main {
  display: grid;
  gap: 3px;
  min-width: 0;
  transition: opacity 200ms ease;
}
.ui-rvc__row-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-rvc__row-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__wait {
  flex: none;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-rvc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rvc__wait[data-sla="near"] {
  color: var(--ui-rvc-mid-fg);
}
.ui-rvc__wait[data-sla="over"] {
  color: var(--ui-rvc-high-fg);
}
.ui-rvc__row-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
}
.ui-rvc__tag {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rvc [data-risk="high"] {
  --k-bg: var(--ui-rvc-high-bg);
  --k-edge: var(--ui-rvc-high-edge);
  --k-fg: var(--ui-rvc-high-fg);
}
.ui-rvc [data-risk="medium"] {
  --k-bg: var(--ui-rvc-mid-bg);
  --k-edge: var(--ui-rvc-mid-edge);
  --k-fg: var(--ui-rvc-mid-fg);
}
.ui-rvc [data-risk="low"] {
  --k-bg: var(--ui-rvc-low-bg);
  --k-edge: var(--ui-rvc-low-edge);
  --k-fg: var(--ui-rvc-low-fg);
}
.ui-rvc__skipped {
  flex: none;
  color: var(--ui-rvc-faint);
}
.ui-rvc__item[data-decision] .ui-rvc__row-main {
  opacity: 0.5;
  transition-delay: var(--d);
}
.ui-rvc__row-done {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--k-bg);
  color: var(--k-fg);
  animation: ui-rvc-fade 160ms ease var(--d) backwards;
}
.ui-rvc__row-done > svg {
  width: 12px;
  height: 12px;
}
:is(.ui-rvc__row-done, .ui-rvc__undo, .ui-rvc__btn)[data-decision="approved"],
.ui-rvc__btn[data-tone="approved"] {
  --k-bg: var(--ui-rvc-low-bg);
  --k-edge: var(--ui-rvc-low-edge);
  --k-fg: var(--ui-rvc-low-fg);
}
:is(.ui-rvc__row-done, .ui-rvc__undo, .ui-rvc__btn)[data-decision="rejected"],
.ui-rvc__btn[data-tone="rejected"] {
  --k-bg: var(--ui-rvc-high-bg);
  --k-edge: var(--ui-rvc-high-edge);
  --k-fg: var(--ui-rvc-high-fg);
}
.ui-rvc__none {
  display: grid;
  place-items: center;
  height: 120px;
  font-size: 12.5px;
  color: var(--ui-rvc-faint);
  list-style: none;
  animation: ui-rvc-fade 300ms ease 300ms backwards;
}
.ui-rvc__main {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}
.ui-rvc__stage {
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  transition: height 420ms var(--ui-rvc-ease);
}
.ui-rvc__detail {
  position: relative;
  display: grid;
  gap: 16px;
  padding: 22px 26px 24px;
  background: var(--ui-rvc-card);
}
.ui-rvc__detail[data-enter="first"] > * {
  animation: ui-rvc-in 420ms var(--ui-rvc-ease) calc(120ms + var(--i, 0) * 40ms)
    backwards;
}
.ui-rvc__detail[data-enter="decide"] {
  animation: ui-rvc-in 320ms var(--ui-rvc-ease) calc(var(--d) + 90ms) backwards;
}
.ui-rvc__detail[data-enter="down"] {
  animation: ui-rvc-in 280ms var(--ui-rvc-ease) backwards;
}
.ui-rvc__detail[data-enter="up"] {
  animation: ui-rvc-in-up 280ms var(--ui-rvc-ease) backwards;
}
.ui-rvc__detail[data-enter="fade"] {
  animation: ui-rvc-fade 240ms ease backwards;
}
.ui-rvc__detail[data-ghost] {
  position: absolute;
  inset: 0 0 auto;
  z-index: 2;
  min-height: 100%;
  pointer-events: none;
  animation: ui-rvc-away 240ms var(--ui-rvc-ease) var(--d) forwards;
}
.ui-rvc__who {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-rvc__who .ui-rvc__avatar {
  width: 34px;
  height: 34px;
  border-radius: 9px;
}
.ui-rvc__who .ui-rvc__avatar > svg {
  width: 17px;
  height: 17px;
}
.ui-rvc__meta {
  display: grid;
  flex: 1;
  gap: 1px;
  min-width: 0;
}
.ui-rvc__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-rvc__agent {
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  line-height: 18px;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__model {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__risk {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 20px;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--k-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--k-fg);
  white-space: nowrap;
}
.ui-rvc__ask {
  display: grid;
  gap: 4px;
}
.ui-rvc__title {
  font-size: 18px;
  font-weight: 600;
  line-height: 24px;
  letter-spacing: -0.012em;
  color: var(--ui-rvc-strong);
  text-wrap: balance;
}
.ui-rvc__why {
  margin-top: -6px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rvc-muted);
  text-wrap: pretty;
}
.ui-rvc__why b {
  font-weight: 500;
  color: var(--ui-rvc-text);
}
.ui-rvc__proposal {
  display: grid;
  gap: 16px;
  min-width: 0;
  padding-top: 2px;
}
.ui-rvc__fields {
  display: flex;
  flex-wrap: wrap;
  gap: 12px 36px;
}
.ui-rvc__fields > div {
  display: grid;
  gap: 1px;
  min-width: 0;
  max-width: 100%;
}
.ui-rvc__fields dt {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvc-muted);
}
.ui-rvc__fields dd {
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-rvc__proposal[data-editing] .ui-rvc__fields dd {
  overflow: visible;
}
.ui-rvc__body {
  display: grid;
  gap: 6px;
  min-width: 0;
}
.ui-rvc__body-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvc-muted);
}
.ui-rvc__text {
  padding-left: 14px;
  box-shadow: inset 1px 0 0 var(--ui-rvc-line-strong);
  font-size: 13.5px;
  line-height: 22px;
  color: var(--ui-rvc-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  text-wrap: pretty;
}
.ui-rvc__code {
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-shadow);
}
.ui-rvc__file + .ui-rvc__file {
  border-top: 1px solid var(--ui-rvc-line);
}
.ui-rvc__file-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 36px;
  padding: 0 12px 0 15.6px;
  font-size: 13px;
  line-height: 20px;
}
.ui-rvc__path {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__dir {
  color: var(--ui-rvc-muted);
}
:is(.ui-rvc__count-add, .ui-rvc__count-del) {
  flex: none;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}
.ui-rvc__count-add {
  color: var(--ui-rvc-diff-add-fg);
}
.ui-rvc__count-del {
  color: var(--ui-rvc-diff-del-fg);
}
.ui-rvc__diff {
  padding: 8px 0 2px;
  overflow-x: auto;
  border-top: 1px solid var(--ui-rvc-line);
  font-family:
    ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: normal;
  white-space: pre;
  scrollbar-width: thin;
}
.ui-rvc__line {
  display: flex;
  min-width: max-content;
  color: var(--ui-rvc-code-ink);
}
.ui-rvc__line[data-diff="add"] {
  background: var(--ui-rvc-diff-add);
}
.ui-rvc__line[data-diff="del"] {
  background: var(--ui-rvc-diff-del);
}
.ui-rvc__ln {
  position: relative;
  flex: none;
  min-width: calc(2ch + 23.4px);
  padding: 0 7.8px 0 15.6px;
  color: var(--ui-rvc-code-num);
  text-align: right;
  font-variant-numeric: tabular-nums;
  user-select: none;
}
.ui-rvc__sign {
  position: absolute;
  left: 4px;
  font-size: 11px;
}
.ui-rvc__line[data-diff="add"] .ui-rvc__sign {
  color: var(--ui-rvc-diff-add-fg);
}
.ui-rvc__line[data-diff="del"] .ui-rvc__sign {
  color: var(--ui-rvc-diff-del-fg);
}
.ui-rvc__src {
  padding: 0 7.8px;
}
.ui-rvc__hunk {
  display: block;
  padding: 0 7.8px 0 calc(2ch + 31.2px);
  color: var(--ui-rvc-code-num);
}
.ui-rvc [data-tok="kw"] {
  color: var(--ui-rvc-tok-kw);
}
.ui-rvc [data-tok="str"] {
  color: var(--ui-rvc-tok-str);
}
.ui-rvc [data-tok="fn"] {
  color: var(--ui-rvc-tok-fn);
}
.ui-rvc [data-tok="type"] {
  color: var(--ui-rvc-tok-type);
}
.ui-rvc [data-tok="com"] {
  color: var(--ui-rvc-code-num);
}
.ui-rvc__line .ui-rvc__flag {
  padding: 1px 1px;
  margin: 0;
}
.ui-rvc__line .ui-rvc__flag [data-tok] {
  color: inherit;
}
.ui-rvc__steps {
  display: grid;
  gap: 12px;
  list-style: none;
}
.ui-rvc__step {
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr);
  column-gap: 12px;
}
.ui-rvc__step-n {
  display: grid;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  box-shadow: inset 0 0 0 1px var(--ui-rvc-line-strong);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-rvc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rvc__step[data-flagged] .ui-rvc__step-n {
  background: var(--ui-rvc-flag-bg);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-flag-edge);
  color: var(--ui-rvc-flag-ink);
}
.ui-rvc__step-main {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 2px 10px;
  min-width: 0;
  padding-top: 1px;
}
.ui-rvc__step-title {
  font-size: 13.5px;
  line-height: 20px;
  color: var(--ui-rvc-ink);
}
.ui-rvc__step-tool {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
}
.ui-rvc__step-detail {
  width: 100%;
  font-size: 12.5px;
  line-height: 19px;
  color: var(--ui-rvc-muted);
}
.ui-rvc__flag {
  padding: 1px 2px;
  margin: 0 -1px;
  border-radius: 4px;
  background: var(--ui-rvc-flag-bg);
  box-shadow: inset 0 -1.5px 0 var(--ui-rvc-flag-edge);
  color: var(--ui-rvc-flag-ink);
  cursor: help;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-rvc__flag:is(:hover, [data-on]) {
  background: var(--ui-rvc-flag-hot);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-flag-edge);
}
.ui-rvc__ins {
  padding: 1px 2px;
  margin: 0 -1px;
  border-radius: 4px;
  background: var(--ui-rvc-ins-bg);
  color: var(--ui-rvc-ins-ink);
  text-decoration: none;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}
.ui-rvc__editor {
  display: grid;
  margin: -6px -8px;
  border-radius: 10px;
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-rvc-muted) 55%, transparent);
}
.ui-rvc__editor > * {
  grid-area: 1 / 1;
  padding: 6px 8px;
  font-size: 13.5px;
  line-height: 22px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-rvc__body[data-format="code"] .ui-rvc__editor > * {
  font-family: ui-monospace, "SF Mono", "JetBrains Mono", Menlo, monospace;
  font-size: 12px;
  line-height: 20px;
  letter-spacing: 0;
}
.ui-rvc__mirror {
  color: transparent;
}
.ui-rvc__mirror .ui-rvc__ins {
  padding: 0;
  margin: 0;
  color: transparent;
  box-shadow: 0 0 0 2px var(--ui-rvc-ins-bg);
}
.ui-rvc__editor textarea {
  width: 100%;
  height: 100%;
  overflow: hidden;
  resize: none;
  color: var(--ui-rvc-ink);
  caret-color: var(--ui-rvc-accent);
  outline: none;
}
.ui-rvc__editor textarea:focus-visible {
  outline: none;
}
.ui-rvc__input {
  width: calc(100% + 12px);
  min-width: 132px;
  height: 24px;
  margin: 0 -6px;
  padding: 0 6px;
  border-radius: 6px;
  background: var(--ui-rvc-wash);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-line);
  font-weight: 500;
  color: var(--ui-rvc-ink);
  outline: none;
}
.ui-rvc__input:focus {
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-rvc-muted) 55%, transparent);
}
.ui-rvc__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px 16px;
}
.ui-rvc__sources {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 14px;
  min-width: 0;
  list-style: none;
}
.ui-rvc__source {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12.5px;
  line-height: 20px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
  text-decoration: none;
  transition: color 160ms ease;
}
a.ui-rvc__source:hover {
  color: var(--ui-rvc-ink);
}
.ui-rvc__source-icon {
  display: grid;
  place-items: center;
  width: 14px;
  height: 14px;
  color: var(--ui-rvc-muted);
}
.ui-rvc__source-icon > svg {
  width: 13px;
  height: 13px;
}
.ui-rvc__empty {
  display: grid;
  place-content: center;
  justify-items: center;
  gap: 4px;
  min-height: 100%;
  padding: 48px 24px;
  text-align: center;
  animation: ui-rvc-in 360ms var(--ui-rvc-ease) 120ms backwards;
}
.ui-rvc__empty[data-after] {
  animation-delay: calc(var(--d) + 120ms);
}
.ui-rvc__empty-mark {
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  margin-bottom: 8px;
  border-radius: 14px;
  background: var(--ui-rvc-low-bg);
  color: var(--ui-rvc-low-fg);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-low-edge);
}
.ui-rvc__empty b {
  font-size: 15px;
  font-weight: 600;
  line-height: 22px;
  color: var(--ui-rvc-strong);
}
.ui-rvc__empty > span:last-child {
  max-width: 280px;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-rvc-muted);
  text-wrap: balance;
}
.ui-rvc__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 6;
  display: grid;
  gap: 4px;
  width: min(300px, calc(100% - 20px));
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-pop);
  pointer-events: none;
  transform-origin: var(--x, 50%) bottom;
  animation: ui-rvc-tip 200ms var(--ui-rvc-ease) both;
}
.ui-rvc__tip[data-side="below"] {
  transform-origin: var(--x, 50%) top;
}
.ui-rvc__tip-head {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 11.5px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-rvc-mid-fg);
}
.ui-rvc__tip p {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-rvc-ink);
  text-wrap: pretty;
}
.ui-rvc__tip-source {
  justify-self: start;
  margin-top: 2px;
  padding: 1px 7px;
  border-radius: 6px;
  background: var(--ui-rvc-chip);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-rvc-text);
}
.ui-rvc__actions {
  position: relative;
  display: flex;
  flex: none;
  align-items: center;
  gap: 12px;
  min-height: 60px;
  padding: 12px 16px;
  border-top: 1px solid var(--ui-rvc-line);
  background: var(--ui-rvc-card);
}
.ui-rvc__btns {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  min-width: 0;
  animation: ui-rvc-swap 220ms var(--ui-rvc-ease) both;
}
.ui-rvc__btn {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 7px 0 10px;
  border-radius: 10px;
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  transition:
    transform 140ms ease,
    box-shadow 200ms ease,
    background-color 200ms ease,
    color 200ms ease,
    opacity 200ms ease;
}
.ui-rvc__btn > svg {
  color: var(--ui-rvc-muted);
}
.ui-rvc__btn:hover:not(:disabled) {
  box-shadow: var(--ui-rvc-raised);
}
.ui-rvc__btn[data-primary] {
  padding-left: 11px;
  background: var(--ui-rvc-primary);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.18),
    inset 0 1px 0 rgba(255, 255, 255, 0.08);
  color: var(--ui-rvc-primary-fg);
}
.ui-rvc__btn[data-primary] > svg {
  color: inherit;
}
.ui-rvc__btn[data-primary] .ui-rvc__kbd {
  background: rgba(255, 255, 255, 0.14);
  color: rgba(255, 255, 255, 0.75);
}
.ui-rvc__btn[data-primary]:hover:not(:disabled) {
  background: #2a2a2a;
}
.ui-rvc__btn:disabled {
  opacity: 0.45;
}
:is(.ui-rvc__btn, .ui-rvc__reason, .ui-rvc__undo-btn)[data-pressed] {
  transform: scale(0.97);
}
.ui-rvc__btn[data-pressed] {
  background: var(--k-bg, var(--ui-rvc-wash));
  box-shadow: inset 0 0 0 1px var(--k-edge, var(--ui-rvc-line));
  color: var(--k-fg, var(--ui-rvc-ink));
}
.ui-rvc__btn[data-pressed] > svg {
  color: inherit;
}
.ui-rvc__why-label {
  margin-right: 2px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvc-ink);
}
.ui-rvc__reason {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  height: 34px;
  padding: 0 11px 0 7px;
  border-radius: 10px;
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvc-ink);
  white-space: nowrap;
  transition:
    transform 140ms ease,
    box-shadow 160ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-rvc__reason:hover {
  box-shadow: inset 0 0 0 1px var(--ui-rvc-high-edge);
}
.ui-rvc__reason[data-pressed] {
  background: var(--ui-rvc-high-bg);
  box-shadow: inset 0 0 0 1px var(--ui-rvc-high-edge);
  color: var(--ui-rvc-high-fg);
}
.ui-rvc__cancel {
  height: 34px;
  padding: 0 8px;
  border-radius: 8px;
  font-size: 12px;
  color: var(--ui-rvc-muted);
}
.ui-rvc__cancel:hover {
  color: var(--ui-rvc-ink);
}
.ui-rvc__undo {
  display: flex;
  flex: 0 1 auto;
  align-items: center;
  gap: 2px;
  min-width: 0;
  height: 30px;
  margin-left: auto;
  padding: 0 2px 0 4px;
  border-radius: 999px;
  background: var(--ui-rvc-tray);
  animation:
    ui-rvc-chip-in 360ms var(--ui-rvc-ease) both,
    ui-rvc-chip-out 300ms ease 5700ms forwards;
}
.ui-rvc__undo-text {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-rvc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__undo-text > svg {
  width: 14px;
  height: 14px;
  color: var(--k-fg);
}
.ui-rvc__undo-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 26px;
  margin-left: 6px;
  padding: 0 4px 0 8px;
  border-radius: 999px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-rvc-ink);
  transition:
    background-color 140ms ease,
    transform 140ms ease;
}
.ui-rvc__undo-btn:hover {
  background: var(--ui-rvc-card);
  box-shadow: var(--ui-rvc-shadow);
}
.ui-rvc__undo-btn > svg {
  color: var(--ui-rvc-muted);
}
.ui-rvc__undo-btn .ui-rvc__kbd {
  min-width: 18px;
  border-radius: 999px;
}
.ui-rvc__detail {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rvc__heading {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvc__title,
.ui-rvc__why,
.ui-rvc__row-title {
  text-align: start;
}
.ui-rvc__title,
.ui-rvc__why,
.ui-rvc__step-title,
.ui-rvc__tip p,
.ui-rvc__tip-source {
  overflow-wrap: anywhere;
}
.ui-rvc__step-detail {
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-rvc__sources > li {
  min-width: 0;
  max-width: 100%;
}
.ui-rvc__source {
  max-width: 100%;
}
.ui-rvc__source-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rvc__source-icon {
  flex: none;
}
.ui-rvc__step-tool {
  min-width: 0;
  max-width: 100%;
}
@container ui-rvc (max-width: 820px) {
  .ui-rvc__card {
    --ui-rvc-queue: 272px;
  }
  .ui-rvc__detail {
    padding: 18px 20px 20px;
  }
}
@container ui-rvc (max-width: 740px) {
  .ui-rvc__btn .ui-rvc__kbd {
    display: none;
  }
  .ui-rvc__btn {
    padding-right: 11px;
  }
  .ui-rvc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvc-faint);
    font-variant-numeric: tabular-nums;
  }
}
@container ui-rvc (max-width: 639px) {
  .ui-rvc__head {
    padding: 4px 4px 8px 10px;
  }
  .ui-rvc__oldest {
    margin-left: auto;
    padding-right: 6px;
  }
  .ui-rvc__oldest::before {
    content: none;
  }
  .ui-rvc__progress {
    order: 5;
    width: 100%;
    padding-right: 8px;
  }
  .ui-rvc__progress .ui-rvc__track {
    flex: 1;
  }
  .ui-rvc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvc-faint);
    font-variant-numeric: tabular-nums;
  }
  .ui-rvc__undo {
    position: absolute;
    top: auto;
    right: 4px;
    bottom: 6px;
    z-index: 2;
    max-width: calc(100% - 8px);
  }
  .ui-rvc__card {
    display: flex;
    flex-direction: column;
    height: auto;
  }
  .ui-rvc__queue {
    border-right: 0;
    border-bottom: 1px solid var(--ui-rvc-line);
  }
  .ui-rvc__list {
    flex: none;
    height: calc(3 * (var(--ui-rvc-row) + 4px) + 16px);
  }
  .ui-rvc__stage {
    flex: none;
    overflow: hidden;
  }
  .ui-rvc__detail {
    gap: 14px;
    padding: 16px 16px 18px;
  }
  .ui-rvc__title {
    font-size: 16px;
    line-height: 22px;
  }
  .ui-rvc__actions {
    flex-wrap: wrap;
    padding: 10px 12px 12px;
  }
  .ui-rvc__btns {
    flex: 1;
    flex-wrap: nowrap;
  }
  .ui-rvc__btns > .ui-rvc__btn {
    flex: 1;
    justify-content: center;
    padding: 0 8px;
  }
  .ui-rvc__btns[role="group"] {
    flex-wrap: wrap;
  }
  .ui-rvc__reason {
    flex: 1 1 40%;
    justify-content: center;
  }
  .ui-rvc__why-label {
    width: 100%;
  }
  .ui-rvc__empty {
    min-height: 220px;
    padding: 36px 20px;
  }
}
@container ui-rvc (max-width: 420px) {
  .ui-rvc__btn > svg {
    display: none;
  }
  .ui-rvc__filter {
    gap: 4px;
    font-size: 12px;
  }
  .ui-rvc__undo-btn .ui-rvc__kbd {
    display: none;
  }
  .ui-rvc__sources {
    width: 100%;
  }
}
@container ui-rvc (max-width: 360px) {
  .ui-rvc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvc-faint);
    font-variant-numeric: tabular-nums;
  }
}
@keyframes ui-rvc-row-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-rvc-open {
  from {
    height: 0;
    padding: 0;
    opacity: 0;
  }
}
@keyframes ui-rvc-close {
  from {
    height: calc(var(--ui-rvc-row) + 4px);
  }
  to {
    height: 0;
    padding: 0;
    opacity: 0;
  }
}
@keyframes ui-rvc-arrive {
  0%,
  40% {
    background: var(--ui-rvc-new);
  }
}
@keyframes ui-rvc-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-rvc-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}
@keyframes ui-rvc-in-up {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
}
@keyframes ui-rvc-away {
  to {
    opacity: 0;
    transform: translateY(-6px);
  }
}
@keyframes ui-rvc-tip {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.96);
  }
}
@keyframes ui-rvc-swap {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-rvc-chip-in {
  from {
    opacity: 0;
    transform: translateX(8px);
  }
}
@keyframes ui-rvc-chip-out {
  to {
    opacity: 0;
    transform: translateX(6px);
  }
}
@keyframes ui-rvc-tick {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
}
@keyframes ui-rvc-sweep {
  to {
    background-position: calc(100% + 40px) 0;
  }
}
@keyframes ui-rvc-glow {
  from {
    opacity: 0.25;
  }
  to {
    opacity: 0.7;
  }
}
@media (pointer: coarse) {
  .ui-rvc .ui-rvc__kbd {
    display: none;
  }
  .ui-rvc__btn {
    padding-right: 11px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rvc *,
  .ui-rvc *::before,
  .ui-rvc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rvc {
  --ui-rvc-tray: #19191c;
  --ui-rvc-card: #232326;
  --ui-rvc-strong: #ededed;
  --ui-rvc-ink: #ededed;
  --ui-rvc-text: #a8a8ad;
  --ui-rvc-muted: #7c7c82;
  --ui-rvc-faint: #55555b;
  --ui-rvc-line: #2e2e33;
  --ui-rvc-queue-bg: #1f1f22;
  --ui-rvc-line-strong: #3a3a40;
  --ui-rvc-code-ink: rgba(255, 255, 255, 0.88);
  --ui-rvc-code-num: rgba(255, 255, 255, 0.42);
  --ui-rvc-diff-add: rgba(60, 220, 130, 0.07);
  --ui-rvc-diff-del: rgba(255, 90, 70, 0.07);
  --ui-rvc-diff-add-fg: #5fd38d;
  --ui-rvc-diff-del-fg: #ff8a73;
  --ui-rvc-tok-kw: color(display-p3 0.98 0.52 0.68);
  --ui-rvc-tok-str: color(display-p3 0.56 0.82 0.54);
  --ui-rvc-tok-type: color(display-p3 0.48 0.7 1);
  --ui-rvc-tok-fn: color(display-p3 0.78 0.56 0.88);
  --ui-rvc-ring-soft: rgba(91, 154, 255, 0.16);
  --ui-rvc-hover: rgba(255, 255, 255, 0.03);
  --ui-rvc-chip: #2e2e32;
  --ui-rvc-wash: #29292d;
  --ui-rvc-accent: #5b9aff;
  --ui-rvc-new: rgba(91, 154, 255, 0.12);
  --ui-rvc-primary: #ededed;
  --ui-rvc-primary-fg: #171717;
  --ui-rvc-bar-bg: #1d2a4a;
  --ui-rvc-bar-edge: #34508f;
  --ui-rvc-bar-mark: #5b9aff;
  --ui-rvc-track: #2c2c30;
  --ui-rvc-high-bg: #3b1714;
  --ui-rvc-high-edge: #74302a;
  --ui-rvc-high-fg: #ff977d;
  --ui-rvc-mid-bg: #3a2610;
  --ui-rvc-mid-edge: #74491c;
  --ui-rvc-mid-fg: #ffb068;
  --ui-rvc-low-bg: #12301f;
  --ui-rvc-low-edge: #23593a;
  --ui-rvc-low-fg: #4fd890;
  --ui-rvc-flag-bg: #3d2b0c;
  --ui-rvc-flag-edge: #a8741f;
  --ui-rvc-flag-hot: #54390c;
  --ui-rvc-flag-ink: #ffd28a;
  --ui-rvc-ins-bg: #173d27;
  --ui-rvc-ins-ink: #7deaa9;
  --ui-rvc-add-bg: #15291e;
  --ui-rvc-del-bg: #2e1916;
  --ui-rvc-focus: rgba(77, 141, 255, 0.8);
  --ui-rvc-shadow: 0 0 0 1px #2e2e33, 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-rvc-raised: 0 0 0 1px #38383e, 0 1px 3px rgba(0, 0, 0, 0.4);
  --ui-rvc-pop: 0 0 0 1px #34343a, 0 16px 36px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-rvc__btn[data-primary] .ui-rvc__kbd {
  background: rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.55);
}
:where(.dark, [data-theme="dark"])
  .ui-rvc__btn[data-primary]:hover:not(:disabled) {
  background: #ffffff;
}
:where(.dark, [data-theme="dark"]) .ui-rvc__row[aria-current] {
  background: #2a2a2e;
}
`;export{n as default};
