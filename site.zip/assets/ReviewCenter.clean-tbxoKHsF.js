const n=`.ui-rvcc {
  --ui-rvcc-card: #ffffff;
  --ui-rvcc-strong: #000000;
  --ui-rvcc-ink: rgba(0, 0, 0, 0.88);
  --ui-rvcc-text: rgba(0, 0, 0, 0.65);
  --ui-rvcc-muted: rgba(0, 0, 0, 0.65);
  --ui-rvcc-faint: rgba(0, 0, 0, 0.65);
  --ui-rvcc-line: rgba(0, 0, 0, 0.06);
  --ui-rvcc-queue-bg: rgba(0, 0, 0, 0.015);
  --ui-rvcc-line-strong: rgba(0, 0, 0, 0.12);
  --ui-rvcc-code-ink: rgba(0, 0, 0, 0.88);
  --ui-rvcc-code-num: rgba(0, 0, 0, 0.65);
  --ui-rvcc-diff-add: rgba(0, 160, 80, 0.06);
  --ui-rvcc-diff-del: rgba(215, 36, 0, 0.05);
  --ui-rvcc-diff-add-fg: #297840;
  --ui-rvcc-diff-del-fg: #b8412b;
  --ui-rvcc-tok-kw: #b82968;
  --ui-rvcc-tok-str: color(display-p3 0.38 0.647 0.378);
  --ui-rvcc-tok-type: color(display-p3 0.247 0.556 0.969);
  --ui-rvcc-tok-fn: color(display-p3 0.587 0.29 0.667);
  --ui-rvcc-ring-soft: rgba(0, 96, 226, 0.1);
  --ui-rvcc-hover: rgba(0, 0, 0, 0.025);
  --ui-rvcc-fill: rgba(0, 0, 0, 0.06);
  --ui-rvcc-wash: rgba(0, 0, 0, 0.025);
  --ui-rvcc-accent: #0060e2;
  --ui-rvcc-new: rgba(0, 96, 226, 0.07);
  --ui-rvcc-primary: rgba(0, 0, 0, 0.88);
  --ui-rvcc-primary-fg: #fcfcfc;
  --ui-rvcc-bar-bg: rgba(0, 96, 226, 0.1);
  --ui-rvcc-bar-edge: rgba(0, 96, 226, 0.32);
  --ui-rvcc-bar-mark: rgba(0, 96, 226, 0.7);
  --ui-rvcc-track: rgba(0, 0, 0, 0.05);
  --ui-rvcc-high-bg: #f52b0018;
  --ui-rvcc-high-edge: rgba(215, 36, 0, 0.34);
  --ui-rvcc-high-fg: #cd2200;
  --ui-rvcc-mid-bg: #ff9c0024;
  --ui-rvcc-mid-edge: rgba(204, 110, 0, 0.4);
  --ui-rvcc-mid-fg: #b74400;
  --ui-rvcc-low-bg: #00a43319;
  --ui-rvcc-low-edge: rgba(0, 140, 50, 0.3);
  --ui-rvcc-low-fg: #007a2d;
  --ui-rvcc-flag-bg: rgba(255, 166, 0, 0.16);
  --ui-rvcc-flag-edge: rgba(214, 130, 0, 0.55);
  --ui-rvcc-flag-hot: rgba(255, 166, 0, 0.28);
  --ui-rvcc-flag-ink: #8a4600;
  --ui-rvcc-ins-bg: rgba(0, 164, 51, 0.13);
  --ui-rvcc-ins-ink: #006b27;
  --ui-rvcc-add-bg: rgba(0, 164, 51, 0.06);
  --ui-rvcc-del-bg: rgba(245, 43, 0, 0.05);
  --ui-rvcc-focus: rgba(0, 96, 226, 0.7);
  --ui-rvcc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-rvcc-raised:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 1px 1px -1px rgba(0, 0, 0, 0.12),
    0 2px 4px 0 rgba(0, 0, 0, 0.05);
  --ui-rvcc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-rvcc-height: 552px;
  --ui-rvcc-queue: 296px;
  --ui-rvcc-row: 56px;
  --ui-rvcc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-rvcc-ease-in: cubic-bezier(0.55, 0, 0.75, 0.3);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  border-radius: 12px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
  outline: none;
  container: ui-rvcc / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-rvcc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-rvcc *,
.ui-rvcc *::before,
.ui-rvcc *::after {
  box-sizing: border-box;
}
:where(.ui-rvcc) :is(button, input, textarea) {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  text-align: inherit;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-rvcc) button {
  cursor: pointer;
}
:where(.ui-rvcc) button:disabled {
  cursor: default;
}
.ui-rvcc :is(button, a, mark):focus-visible {
  outline: 2px solid var(--ui-rvcc-focus);
  outline-offset: 2px;
}
.ui-rvcc :is(input, textarea):focus-visible {
  outline: none;
}
:where(.ui-rvcc) :is(p, dl, dd, h3, ul, ol) {
  margin: 0;
  padding: 0;
}
.ui-rvcc svg {
  display: block;
  flex: none;
}
.ui-rvcc__kbd {
  display: inline-grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-rvcc-fill);
  font-family: inherit;
  font-size: 10px;
  font-weight: 500;
  line-height: 1;
  color: var(--ui-rvcc-muted);
  letter-spacing: 0;
}
.ui-rvcc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-rvcc__head {
  position: relative;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px 12px;
  min-width: 0;
  min-height: 48px;
  padding: 10px 12px 10px 16px;
  border-bottom: 0.5px solid var(--ui-rvcc-line);
}
.ui-rvcc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  margin-right: -4px;
  color: var(--ui-rvcc-accent);
}
.ui-rvcc__heading {
  flex: none;
  font-weight: 500;
  color: var(--ui-rvcc-strong);
}
.ui-rvcc__progress {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
}
.ui-rvcc__count {
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__count b {
  display: inline-block;
  font-weight: 500;
  color: var(--ui-rvcc-ink);
  animation: ui-rvcc-tick 420ms var(--ui-rvcc-ease) both;
}
.ui-rvcc__track {
  position: relative;
  width: 80px;
  height: 6px;
  overflow: hidden;
  border-radius: 3px;
  background: var(--ui-rvcc-track);
}
.ui-rvcc__fill {
  position: absolute;
  inset: 0 auto 0 0;
  overflow: hidden;
  border-radius: 3px;
  background: var(--ui-rvcc-bar-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-rvcc-bar-edge);
  transition: width 700ms var(--ui-rvcc-ease);
}
.ui-rvcc__track[data-live] .ui-rvcc__fill::before {
  content: "";
  position: absolute;
  inset: 0;
  background: linear-gradient(
      90deg,
      transparent,
      var(--ui-rvcc-card),
      transparent
    ) -40px
    0 / 40px 100% no-repeat;
  opacity: 0.7;
  animation: ui-rvcc-sweep 1800ms linear infinite;
}
.ui-rvcc__fill::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(18px, 100%);
  background: linear-gradient(90deg, transparent, var(--ui-rvcc-bar-mark));
  opacity: 0.55;
  animation: ui-rvcc-glow 1100ms ease-in-out infinite alternate;
}
.ui-rvcc__oldest {
  flex: none;
  margin-left: -4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
}
.ui-rvcc__oldest::before {
  content: "·";
  margin-right: 8px;
  color: var(--ui-rvcc-faint);
}
.ui-rvcc__oldest b {
  font-weight: 500;
  color: var(--ui-rvcc-text);
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__oldest b[data-sla="near"] {
  color: var(--ui-rvcc-mid-fg);
}
.ui-rvcc__oldest b[data-sla="over"] {
  color: var(--ui-rvcc-high-fg);
}
.ui-rvcc__filters {
  display: flex;
  flex: 1;
  gap: 4px;
  min-width: 0;
}
.ui-rvcc__filter {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-rvcc__filter:hover {
  color: var(--ui-rvcc-ink);
}
.ui-rvcc__filter[aria-pressed="true"] {
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
  color: var(--ui-rvcc-ink);
}
.ui-rvcc__filter-count {
  font-size: 11.5px;
  color: var(--ui-rvcc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__filter[aria-pressed="true"] .ui-rvcc__filter-count {
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__card {
  position: relative;
  display: grid;
  grid-template-columns: var(--ui-rvcc-queue) minmax(0, 1fr);
  height: var(--ui-rvcc-height);
  overflow: hidden;
  border-radius: 0 0 12px 12px;
}
.ui-rvcc__queue {
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  border-right: 0.5px solid var(--ui-rvcc-line);
  background: var(--ui-rvcc-queue-bg);
}
.ui-rvcc__queue-head {
  display: flex;
  flex: none;
  align-items: center;
  padding: 8px;
  background: var(--ui-rvcc-card);
  border-bottom: 0.5px solid var(--ui-rvcc-line);
}
.ui-rvcc__list {
  position: relative;
  flex: 1;
  min-height: 0;
  padding: 8px;
  overflow: hidden auto;
  overscroll-behavior: contain;
  list-style: none;
  scrollbar-width: thin;
}
.ui-rvcc__item {
  height: calc(var(--ui-rvcc-row) + 2px);
  padding: 1px 0;
  overflow: hidden;
}
.ui-rvcc__item[data-enter="first"] {
  animation: ui-rvcc-row-in 460ms var(--ui-rvcc-ease) var(--d) backwards;
}
.ui-rvcc__item:is([data-enter="new"], [data-enter="in"]) {
  animation: ui-rvcc-open 520ms var(--ui-rvcc-ease) var(--d) backwards;
}
.ui-rvcc__item[data-enter="new"] .ui-rvcc__row {
  animation: ui-rvcc-arrive 2600ms ease-out backwards;
}
.ui-rvcc__item[data-leaving] {
  pointer-events: none;
  animation: ui-rvcc-close 300ms var(--ui-rvcc-ease) var(--d) forwards;
}
.ui-rvcc__item[data-leaving][data-decision] {
  animation-delay: calc(var(--d) + 180ms);
}
.ui-rvcc__row {
  position: relative;
  display: grid;
  grid-template-columns: 24px minmax(0, 1fr);
  align-items: center;
  column-gap: 10px;
  width: 100%;
  height: var(--ui-rvcc-row);
  padding: 0 10px;
  border-radius: 8px;
  transition:
    background-color 160ms ease,
    box-shadow 200ms ease;
}
.ui-rvcc__row:hover {
  background: var(--ui-rvcc-hover);
}
.ui-rvcc__row[aria-current] {
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
}
.ui-rvcc__row:focus-visible {
  outline-offset: -2px;
}
.ui-rvcc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-rvcc-text);
}
.ui-rvcc__avatar > svg {
  width: 13px;
  height: 13px;
}
.ui-rvcc__row-main {
  display: grid;
  gap: 2px;
  min-width: 0;
  transition: opacity 200ms ease;
}
.ui-rvcc__row-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-rvcc__row-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rvcc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__wait {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__wait[data-sla="near"] {
  color: var(--ui-rvcc-mid-fg);
}
.ui-rvcc__wait[data-sla="over"] {
  color: var(--ui-rvcc-high-fg);
}
.ui-rvcc__row-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
}
.ui-rvcc__tag {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rvcc [data-risk="high"] {
  --k-bg: var(--ui-rvcc-high-bg);
  --k-edge: var(--ui-rvcc-high-edge);
  --k-fg: var(--ui-rvcc-high-fg);
}
.ui-rvcc [data-risk="medium"] {
  --k-bg: var(--ui-rvcc-mid-bg);
  --k-edge: var(--ui-rvcc-mid-edge);
  --k-fg: var(--ui-rvcc-mid-fg);
}
.ui-rvcc [data-risk="low"] {
  --k-bg: var(--ui-rvcc-low-bg);
  --k-edge: var(--ui-rvcc-low-edge);
  --k-fg: var(--ui-rvcc-low-fg);
}
.ui-rvcc__skipped {
  flex: none;
  color: var(--ui-rvcc-faint);
}
.ui-rvcc__item[data-decision] .ui-rvcc__row-main {
  opacity: 0.5;
  transition-delay: var(--d);
}
.ui-rvcc__row-done {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--k-bg);
  color: var(--k-fg);
  animation: ui-rvcc-fade 160ms ease var(--d) backwards;
}
.ui-rvcc__row-done > svg {
  width: 12px;
  height: 12px;
}
:is(
  .ui-rvcc__row-done,
  .ui-rvcc__undo,
  .ui-rvcc__btn
)[data-decision="approved"],
.ui-rvcc__btn[data-tone="approved"] {
  --k-bg: var(--ui-rvcc-low-bg);
  --k-edge: var(--ui-rvcc-low-edge);
  --k-fg: var(--ui-rvcc-low-fg);
}
:is(
  .ui-rvcc__row-done,
  .ui-rvcc__undo,
  .ui-rvcc__btn
)[data-decision="rejected"],
.ui-rvcc__btn[data-tone="rejected"] {
  --k-bg: var(--ui-rvcc-high-bg);
  --k-edge: var(--ui-rvcc-high-edge);
  --k-fg: var(--ui-rvcc-high-fg);
}
.ui-rvcc__none {
  display: grid;
  place-items: center;
  height: 120px;
  font-size: 12px;
  color: var(--ui-rvcc-faint);
  list-style: none;
  animation: ui-rvcc-fade 300ms ease 300ms backwards;
}
.ui-rvcc__main {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
}
.ui-rvcc__stage {
  position: relative;
  flex: 1;
  min-height: 0;
  overflow: hidden auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  transition: height 420ms var(--ui-rvcc-ease);
}
.ui-rvcc__detail {
  position: relative;
  display: grid;
  gap: 16px;
  padding: 22px 24px 24px;
  background: var(--ui-rvcc-card);
}
.ui-rvcc__detail[data-enter="first"] > * {
  animation: ui-rvcc-in 420ms var(--ui-rvcc-ease)
    calc(120ms + var(--i, 0) * 40ms) backwards;
}
.ui-rvcc__detail[data-enter="decide"] {
  animation: ui-rvcc-in 320ms var(--ui-rvcc-ease) calc(var(--d) + 90ms)
    backwards;
}
.ui-rvcc__detail[data-enter="down"] {
  animation: ui-rvcc-in 280ms var(--ui-rvcc-ease) backwards;
}
.ui-rvcc__detail[data-enter="up"] {
  animation: ui-rvcc-in-up 280ms var(--ui-rvcc-ease) backwards;
}
.ui-rvcc__detail[data-enter="fade"] {
  animation: ui-rvcc-fade 240ms ease backwards;
}
.ui-rvcc__detail[data-ghost] {
  position: absolute;
  inset: 0 0 auto;
  z-index: 2;
  min-height: 100%;
  pointer-events: none;
  animation: ui-rvcc-away 240ms var(--ui-rvcc-ease) var(--d) forwards;
}
.ui-rvcc__who {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-rvcc__who .ui-rvcc__avatar {
  width: 32px;
  height: 32px;
  border-radius: 8px;
}
.ui-rvcc__who .ui-rvcc__avatar > svg {
  width: 16px;
  height: 16px;
}
.ui-rvcc__meta {
  display: grid;
  flex: 1;
  gap: 0;
  min-width: 0;
}
.ui-rvcc__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-rvcc__agent {
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rvcc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__model {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__risk {
  display: inline-flex;
  flex: none;
  align-items: center;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  background: var(--k-bg);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--k-fg);
  white-space: nowrap;
}
.ui-rvcc__ask {
  display: grid;
  gap: 4px;
}
.ui-rvcc__title {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-rvcc-strong);
  text-wrap: balance;
}
.ui-rvcc__why {
  margin-top: -6px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rvcc-muted);
  text-wrap: pretty;
}
.ui-rvcc__why b {
  font-weight: 500;
  color: var(--ui-rvcc-text);
}
.ui-rvcc__proposal {
  display: grid;
  gap: 16px;
  min-width: 0;
  padding-top: 2px;
}
.ui-rvcc__fields {
  display: flex;
  flex-wrap: wrap;
  gap: 12px 36px;
}
.ui-rvcc__fields > div {
  display: grid;
  gap: 1px;
  min-width: 0;
  max-width: 100%;
}
.ui-rvcc__fields dt {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__fields dd {
  min-width: 0;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 22px;
  color: var(--ui-rvcc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__proposal[data-editing] .ui-rvcc__fields dd {
  overflow: visible;
}
.ui-rvcc__body {
  display: grid;
  gap: 6px;
  min-width: 0;
}
.ui-rvcc__body-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__text {
  padding-left: 14px;
  box-shadow: inset 0.5px 0 0 var(--ui-rvcc-line-strong);
  font-size: 13px;
  line-height: 22px;
  color: var(--ui-rvcc-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  text-wrap: pretty;
}
.ui-rvcc__code {
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
}
.ui-rvcc__file + .ui-rvcc__file {
  border-top: 0.5px solid var(--ui-rvcc-line);
}
.ui-rvcc__file-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 36px;
  padding: 0 12px 0 15.6px;
  font-size: 13px;
  line-height: 20px;
}
.ui-rvcc__path {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-rvcc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__dir {
  color: var(--ui-rvcc-muted);
}
:is(.ui-rvcc__count-add, .ui-rvcc__count-del) {
  flex: none;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__count-add {
  color: var(--ui-rvcc-diff-add-fg);
}
.ui-rvcc__count-del {
  color: var(--ui-rvcc-diff-del-fg);
}
.ui-rvcc__diff {
  padding: 8px 0 2px;
  overflow-x: auto;
  border-top: 0.5px solid var(--ui-rvcc-line);
  font-family:
    ui-monospace, "SF Mono", SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  letter-spacing: normal;
  white-space: pre;
  scrollbar-width: thin;
}
.ui-rvcc__line {
  display: flex;
  min-width: max-content;
  color: var(--ui-rvcc-code-ink);
}
.ui-rvcc__line[data-diff="add"] {
  background: var(--ui-rvcc-diff-add);
}
.ui-rvcc__line[data-diff="del"] {
  background: var(--ui-rvcc-diff-del);
}
.ui-rvcc__ln {
  position: relative;
  flex: none;
  min-width: calc(2ch + 23.4px);
  padding: 0 7.8px 0 15.6px;
  color: var(--ui-rvcc-code-num);
  text-align: right;
  font-variant-numeric: tabular-nums;
  user-select: none;
}
.ui-rvcc__sign {
  position: absolute;
  left: 4px;
  font-size: 11px;
}
.ui-rvcc__line[data-diff="add"] .ui-rvcc__sign {
  color: var(--ui-rvcc-diff-add-fg);
}
.ui-rvcc__line[data-diff="del"] .ui-rvcc__sign {
  color: var(--ui-rvcc-diff-del-fg);
}
.ui-rvcc__src {
  padding: 0 7.8px;
}
.ui-rvcc__hunk {
  display: block;
  padding: 0 7.8px 0 calc(2ch + 31.2px);
  color: var(--ui-rvcc-code-num);
}
.ui-rvcc [data-tok="kw"] {
  color: var(--ui-rvcc-tok-kw);
}
.ui-rvcc [data-tok="str"] {
  color: var(--ui-rvcc-tok-str);
}
.ui-rvcc [data-tok="fn"] {
  color: var(--ui-rvcc-tok-fn);
}
.ui-rvcc [data-tok="type"] {
  color: var(--ui-rvcc-tok-type);
}
.ui-rvcc [data-tok="com"] {
  color: var(--ui-rvcc-code-num);
}
.ui-rvcc__line .ui-rvcc__flag {
  padding: 1px 1px;
  margin: 0;
}
.ui-rvcc__line .ui-rvcc__flag [data-tok] {
  color: inherit;
}
.ui-rvcc__steps {
  display: grid;
  gap: 12px;
  list-style: none;
}
.ui-rvcc__step {
  display: grid;
  grid-template-columns: 22px minmax(0, 1fr);
  column-gap: 12px;
}
.ui-rvcc__step-n {
  display: grid;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  box-shadow: inset 0 0 0 0.5px var(--ui-rvcc-line-strong);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-rvcc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rvcc__step[data-flagged] .ui-rvcc__step-n {
  background: var(--ui-rvcc-flag-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-rvcc-flag-edge);
  color: var(--ui-rvcc-flag-ink);
}
.ui-rvcc__step-main {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  gap: 2px 10px;
  min-width: 0;
  padding-top: 1px;
}
.ui-rvcc__step-title {
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rvcc-ink);
}
.ui-rvcc__step-tool {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
}
.ui-rvcc__step-detail {
  width: 100%;
  font-size: 12.5px;
  line-height: 19px;
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__flag {
  padding: 1px 2px;
  margin: 0 -1px;
  border-radius: 3px;
  background: var(--ui-rvcc-flag-bg);
  box-shadow: inset 0 -1px 0 var(--ui-rvcc-flag-edge);
  color: var(--ui-rvcc-flag-ink);
  cursor: help;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-rvcc__flag:is(:hover, [data-on]) {
  background: var(--ui-rvcc-flag-hot);
  box-shadow: inset 0 0 0 0.5px var(--ui-rvcc-flag-edge);
}
.ui-rvcc__ins {
  padding: 1px 2px;
  margin: 0 -1px;
  border-radius: 3px;
  background: var(--ui-rvcc-ins-bg);
  color: var(--ui-rvcc-ins-ink);
  text-decoration: none;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}
.ui-rvcc__editor {
  display: grid;
  margin: -6px -8px;
  border-radius: 8px;
  box-shadow: inset 0 0 0 1px var(--ui-rvcc-faint);
}
.ui-rvcc__editor > * {
  grid-area: 1 / 1;
  padding: 6px 8px;
  font-size: 13px;
  line-height: 22px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-rvcc__body[data-format="code"] .ui-rvcc__editor > * {
  font-family: ui-monospace, "SF Mono", "JetBrains Mono", Menlo, monospace;
  font-size: 12px;
  line-height: 20px;
  letter-spacing: 0;
}
.ui-rvcc__mirror {
  color: transparent;
}
.ui-rvcc__mirror .ui-rvcc__ins {
  padding: 0;
  margin: 0;
  color: transparent;
  box-shadow: 0 0 0 2px var(--ui-rvcc-ins-bg);
}
.ui-rvcc__editor textarea {
  width: 100%;
  height: 100%;
  overflow: hidden;
  resize: none;
  color: var(--ui-rvcc-ink);
  caret-color: var(--ui-rvcc-accent);
  outline: none;
}
.ui-rvcc__editor textarea:focus-visible {
  outline: none;
}
.ui-rvcc__input {
  width: calc(100% + 12px);
  min-width: 132px;
  height: 24px;
  margin: 0 -6px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-rvcc-wash);
  box-shadow: inset 0 0 0 1px var(--ui-rvcc-line);
  font-weight: 500;
  color: var(--ui-rvcc-ink);
  outline: none;
}
.ui-rvcc__input:focus {
  box-shadow: inset 0 0 0 1px var(--ui-rvcc-faint);
}
.ui-rvcc__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 10px 16px;
}
.ui-rvcc__sources {
  display: flex;
  flex-wrap: wrap;
  gap: 4px 14px;
  min-width: 0;
  list-style: none;
}
.ui-rvcc__source {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
  text-decoration: none;
  transition: color 160ms ease;
}
a.ui-rvcc__source:hover {
  color: var(--ui-rvcc-ink);
}
.ui-rvcc__source-icon {
  display: grid;
  place-items: center;
  width: 14px;
  height: 14px;
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__source-icon > svg {
  width: 12px;
  height: 12px;
}
.ui-rvcc__empty {
  display: grid;
  place-content: center;
  justify-items: center;
  gap: 2px;
  min-height: 100%;
  padding: 48px 24px;
  text-align: center;
  animation: ui-rvcc-in 360ms var(--ui-rvcc-ease) 120ms backwards;
}
.ui-rvcc__empty[data-after] {
  animation-delay: calc(var(--d) + 120ms);
}
.ui-rvcc__empty-mark {
  display: grid;
  place-items: center;
  width: 40px;
  height: 40px;
  margin-bottom: 10px;
  border-radius: 10px;
  background: var(--ui-rvcc-card);
  color: var(--ui-rvcc-low-fg);
  box-shadow:
    var(--ui-rvcc-shadow),
    0 0 0 4px var(--ui-rvcc-low-bg);
}
.ui-rvcc__empty b {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-rvcc-strong);
}
.ui-rvcc__empty > span:last-child {
  max-width: 280px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rvcc-muted);
  text-wrap: balance;
}
.ui-rvcc__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 6;
  display: grid;
  gap: 2px;
  width: min(300px, calc(100% - 20px));
  padding: 10px 12px;
  border-radius: 10px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-pop);
  pointer-events: none;
  transform-origin: var(--x, 50%) bottom;
  animation: ui-rvcc-tip 200ms var(--ui-rvcc-ease) both;
}
.ui-rvcc__tip[data-side="below"] {
  transform-origin: var(--x, 50%) top;
}
.ui-rvcc__tip-head {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-rvcc-mid-fg);
}
.ui-rvcc__tip-head > svg {
  width: 12px;
  height: 12px;
}
.ui-rvcc__tip p {
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-rvcc-ink);
  text-wrap: pretty;
}
.ui-rvcc__tip-source {
  justify-self: start;
  margin-top: 4px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-rvcc-fill);
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-rvcc-text);
}
.ui-rvcc__actions {
  position: relative;
  display: flex;
  flex: none;
  align-items: center;
  gap: 12px;
  min-height: 52px;
  padding: 12px 16px;
  border-top: 0.5px solid var(--ui-rvcc-line);
  background: var(--ui-rvcc-card);
}
.ui-rvcc__btns {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  min-width: 0;
  animation: ui-rvcc-swap 220ms var(--ui-rvcc-ease) both;
}
.ui-rvcc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 6px 0 6px;
  border-radius: 6px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvcc-strong);
  white-space: nowrap;
  transition:
    transform 140ms ease,
    box-shadow 200ms ease,
    background-color 200ms ease,
    color 200ms ease,
    opacity 200ms ease;
}
.ui-rvcc__btn > svg {
  color: rgba(0, 0, 0, 0.65);
}
.ui-rvcc__btn > span {
  margin-right: 2px;
}
.ui-rvcc__btn:hover:not(:disabled) {
  box-shadow: var(--ui-rvcc-raised);
}
.ui-rvcc__btn[data-primary] {
  background: var(--ui-rvcc-primary);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.16);
  color: var(--ui-rvcc-primary-fg);
}
.ui-rvcc__btn[data-primary] > svg {
  color: inherit;
}
.ui-rvcc__btn[data-primary] .ui-rvcc__kbd {
  background: rgba(255, 255, 255, 0.16);
  color: rgba(255, 255, 255, 0.72);
}
.ui-rvcc__btn[data-primary]:hover:not(:disabled) {
  background: #000000;
}
.ui-rvcc__btn:disabled {
  opacity: 0.45;
}
:is(.ui-rvcc__btn, .ui-rvcc__reason, .ui-rvcc__undo-btn)[data-pressed] {
  transform: scale(0.97);
}
.ui-rvcc__btn[data-pressed] {
  background: var(--k-bg, var(--ui-rvcc-wash));
  box-shadow: inset 0 0 0 0.5px var(--k-edge, var(--ui-rvcc-line));
  color: var(--k-fg, var(--ui-rvcc-strong));
}
.ui-rvcc__btn[data-pressed] > svg {
  color: inherit;
}
.ui-rvcc__why-label {
  margin-right: 2px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvcc-strong);
}
.ui-rvcc__reason {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 6px;
  border-radius: 6px;
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-rvcc-strong);
  white-space: nowrap;
  transition:
    transform 140ms ease,
    box-shadow 160ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-rvcc__reason:hover {
  box-shadow:
    inset 0 0 0 0.5px var(--ui-rvcc-high-edge),
    0 1px 2px rgba(0, 0, 0, 0.05);
}
.ui-rvcc__reason[data-pressed] {
  background: var(--ui-rvcc-high-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-rvcc-high-edge);
  color: var(--ui-rvcc-high-fg);
}
.ui-rvcc__cancel {
  height: 28px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px;
  color: var(--ui-rvcc-muted);
}
.ui-rvcc__cancel:hover {
  color: var(--ui-rvcc-ink);
}
.ui-rvcc__undo {
  display: flex;
  flex: 0 1 auto;
  align-items: center;
  gap: 2px;
  min-width: 0;
  height: 28px;
  margin-left: auto;
  padding: 0 0 0 4px;
  border-radius: 6px;
  background: var(--ui-rvcc-card);
  animation:
    ui-rvcc-chip-in 360ms var(--ui-rvcc-ease) both,
    ui-rvcc-chip-out 300ms ease 5700ms forwards;
}
.ui-rvcc__undo-text {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-rvcc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__undo-text > svg {
  width: 14px;
  height: 14px;
  color: var(--k-fg);
}
.ui-rvcc__undo-btn {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 24px;
  margin-left: 4px;
  padding: 0 4px 0 6px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-rvcc-strong);
  transition:
    background-color 140ms ease,
    transform 140ms ease;
}
.ui-rvcc__undo-btn:hover {
  background: var(--ui-rvcc-card);
  box-shadow: var(--ui-rvcc-shadow);
}
.ui-rvcc__undo-btn > svg {
  color: rgba(0, 0, 0, 0.65);
}
.ui-rvcc__detail {
  grid-template-columns: minmax(0, 1fr);
}
.ui-rvcc__heading {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rvcc__title,
.ui-rvcc__why,
.ui-rvcc__row-title {
  text-align: start;
}
.ui-rvcc__title,
.ui-rvcc__why,
.ui-rvcc__step-title,
.ui-rvcc__tip p,
.ui-rvcc__tip-source {
  overflow-wrap: anywhere;
}
.ui-rvcc__step-detail {
  overflow-wrap: anywhere;
  white-space: pre-line;
}
.ui-rvcc__sources > li {
  min-width: 0;
  max-width: 100%;
}
.ui-rvcc__source {
  max-width: 100%;
}
.ui-rvcc__source-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-rvcc__source-icon {
  flex: none;
}
.ui-rvcc__step-tool {
  min-width: 0;
  max-width: 100%;
}
@container ui-rvcc (max-width: 820px) {
  .ui-rvcc__card {
    --ui-rvcc-queue: 268px;
  }
  .ui-rvcc__detail {
    padding: 18px 20px 20px;
  }
}
@container ui-rvcc (max-width: 740px) {
  .ui-rvcc__btn .ui-rvcc__kbd {
    display: none;
  }
  .ui-rvcc__btn {
    padding-right: 10px;
  }
  .ui-rvcc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvcc-faint);
    font-variant-numeric: tabular-nums;
  }
}
@container ui-rvcc (max-width: 639px) {
  .ui-rvcc__head {
    padding: 10px 10px 10px 14px;
  }
  .ui-rvcc__oldest {
    margin-left: auto;
    padding-right: 4px;
  }
  .ui-rvcc__oldest::before {
    content: none;
  }
  .ui-rvcc__progress {
    order: 5;
    width: 100%;
    padding-right: 4px;
  }
  .ui-rvcc__progress .ui-rvcc__track {
    flex: 1;
  }
  .ui-rvcc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvcc-faint);
    font-variant-numeric: tabular-nums;
  }
  .ui-rvcc__undo {
    position: absolute;
    top: auto;
    right: 10px;
    bottom: 8px;
    z-index: 2;
    max-width: calc(100% - 20px);
  }
  .ui-rvcc__card {
    display: flex;
    flex-direction: column;
    height: auto;
  }
  .ui-rvcc__queue {
    border-right: 0;
    border-bottom: 0.5px solid var(--ui-rvcc-line);
  }
  .ui-rvcc__list {
    flex: none;
    height: calc(3 * (var(--ui-rvcc-row) + 2px) + 16px);
  }
  .ui-rvcc__stage {
    flex: none;
    overflow: hidden;
  }
  .ui-rvcc__detail {
    gap: 14px;
    padding: 16px 14px 18px;
  }
  .ui-rvcc__actions {
    flex-wrap: wrap;
    padding: 10px 12px 12px;
  }
  .ui-rvcc__btns {
    flex: 1;
    flex-wrap: nowrap;
  }
  .ui-rvcc__btns > .ui-rvcc__btn {
    flex: 1;
    justify-content: center;
    padding: 0 8px;
  }
  .ui-rvcc__btns[role="group"] {
    flex-wrap: wrap;
  }
  .ui-rvcc__reason {
    flex: 1 1 40%;
    justify-content: center;
  }
  .ui-rvcc__why-label {
    width: 100%;
  }
  .ui-rvcc__empty {
    min-height: 220px;
    padding: 36px 20px;
  }
}
@container ui-rvcc (max-width: 420px) {
  .ui-rvcc__btn > svg {
    display: none;
  }
  .ui-rvcc__filter {
    gap: 4px;
  }
  .ui-rvcc__undo-btn .ui-rvcc__kbd {
    display: none;
  }
  .ui-rvcc__sources {
    width: 100%;
  }
}
@container ui-rvcc (max-width: 360px) {
  .ui-rvcc__filter-count {
    font-size: 11.5px;
    color: var(--ui-rvcc-faint);
    font-variant-numeric: tabular-nums;
  }
}
@keyframes ui-rvcc-row-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-rvcc-open {
  from {
    height: 0;
    padding: 0;
    opacity: 0;
  }
}
@keyframes ui-rvcc-close {
  from {
    height: calc(var(--ui-rvcc-row) + 2px);
  }
  to {
    height: 0;
    padding: 0;
    opacity: 0;
  }
}
@keyframes ui-rvcc-arrive {
  0%,
  40% {
    background: var(--ui-rvcc-new);
  }
}
@keyframes ui-rvcc-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-rvcc-in {
  from {
    opacity: 0;
    transform: translateY(8px);
  }
}
@keyframes ui-rvcc-in-up {
  from {
    opacity: 0;
    transform: translateY(-8px);
  }
}
@keyframes ui-rvcc-away {
  to {
    opacity: 0;
    transform: translateY(-6px);
  }
}
@keyframes ui-rvcc-tip {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.96);
  }
}
@keyframes ui-rvcc-swap {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-rvcc-chip-in {
  from {
    opacity: 0;
    transform: translateX(8px);
  }
}
@keyframes ui-rvcc-chip-out {
  to {
    opacity: 0;
    transform: translateX(6px);
  }
}
@keyframes ui-rvcc-tick {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
}
@keyframes ui-rvcc-sweep {
  to {
    background-position: calc(100% + 40px) 0;
  }
}
@keyframes ui-rvcc-glow {
  from {
    opacity: 0.25;
  }
  to {
    opacity: 0.7;
  }
}
@media (pointer: coarse) {
  .ui-rvcc .ui-rvcc__kbd {
    display: none;
  }
  .ui-rvcc__btn {
    padding-right: 10px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rvcc *,
  .ui-rvcc *::before,
  .ui-rvcc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rvcc {
  --ui-rvcc-card: #1c1c1f;
  --ui-rvcc-strong: #ffffff;
  --ui-rvcc-ink: rgba(255, 255, 255, 0.9);
  --ui-rvcc-text: rgba(255, 255, 255, 0.62);
  --ui-rvcc-muted: rgba(255, 255, 255, 0.45);
  --ui-rvcc-faint: rgba(255, 255, 255, 0.28);
  --ui-rvcc-line: rgba(255, 255, 255, 0.08);
  --ui-rvcc-queue-bg: rgba(255, 255, 255, 0.015);
  --ui-rvcc-line-strong: rgba(255, 255, 255, 0.16);
  --ui-rvcc-code-ink: rgba(255, 255, 255, 0.88);
  --ui-rvcc-code-num: rgba(255, 255, 255, 0.42);
  --ui-rvcc-diff-add: rgba(60, 220, 130, 0.07);
  --ui-rvcc-diff-del: rgba(255, 90, 70, 0.07);
  --ui-rvcc-diff-add-fg: #5fd38d;
  --ui-rvcc-diff-del-fg: #ff8a73;
  --ui-rvcc-tok-kw: color(display-p3 0.98 0.52 0.68);
  --ui-rvcc-tok-str: color(display-p3 0.56 0.82 0.54);
  --ui-rvcc-tok-type: color(display-p3 0.48 0.7 1);
  --ui-rvcc-tok-fn: color(display-p3 0.78 0.56 0.88);
  --ui-rvcc-ring-soft: rgba(91, 154, 255, 0.16);
  --ui-rvcc-hover: rgba(255, 255, 255, 0.03);
  --ui-rvcc-fill: rgba(255, 255, 255, 0.08);
  --ui-rvcc-wash: rgba(255, 255, 255, 0.03);
  --ui-rvcc-accent: #5b9aff;
  --ui-rvcc-new: rgba(91, 154, 255, 0.1);
  --ui-rvcc-primary: rgba(255, 255, 255, 0.92);
  --ui-rvcc-primary-fg: #111113;
  --ui-rvcc-bar-bg: rgba(91, 154, 255, 0.16);
  --ui-rvcc-bar-edge: rgba(91, 154, 255, 0.42);
  --ui-rvcc-bar-mark: rgba(112, 170, 255, 0.85);
  --ui-rvcc-track: rgba(255, 255, 255, 0.07);
  --ui-rvcc-high-bg: #ff35232b;
  --ui-rvcc-high-edge: rgba(255, 90, 70, 0.4);
  --ui-rvcc-high-fg: #ff977d;
  --ui-rvcc-mid-bg: #fb6a0025;
  --ui-rvcc-mid-edge: rgba(255, 150, 60, 0.42);
  --ui-rvcc-mid-fg: #ffa057;
  --ui-rvcc-low-bg: #00f04a1f;
  --ui-rvcc-low-edge: rgba(60, 220, 130, 0.36);
  --ui-rvcc-low-fg: #3dd68c;
  --ui-rvcc-flag-bg: rgba(255, 170, 40, 0.16);
  --ui-rvcc-flag-edge: rgba(255, 180, 70, 0.55);
  --ui-rvcc-flag-hot: rgba(255, 170, 40, 0.28);
  --ui-rvcc-flag-ink: #ffcf8a;
  --ui-rvcc-ins-bg: rgba(60, 220, 130, 0.18);
  --ui-rvcc-ins-ink: #7deaa9;
  --ui-rvcc-add-bg: rgba(60, 220, 130, 0.07);
  --ui-rvcc-del-bg: rgba(255, 90, 70, 0.08);
  --ui-rvcc-focus: rgba(77, 141, 255, 0.8);
  --ui-rvcc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-rvcc-raised:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 3px 0 rgba(0, 0, 0, 0.5);
  --ui-rvcc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-rvcc__row[aria-current] {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) :is(.ui-rvcc__btn, .ui-rvcc__undo-btn),
:where(.dark, [data-theme="dark"]) .ui-rvcc__btn[data-primary] > svg {
  color: inherit;
}
:where(.dark, [data-theme="dark"]) .ui-rvcc__btn[data-primary] .ui-rvcc__kbd {
  background: rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.55);
}
:where(.dark, [data-theme="dark"])
  .ui-rvcc__btn[data-primary]:hover:not(:disabled) {
  background: #ffffff;
}
:where(.dark, [data-theme="dark"]) .ui-rvcc__btn:is(:not([data-primary])),
:where(.dark, [data-theme="dark"]) :is(.ui-rvcc__reason) {
  background: #26262a;
}
`;export{n as default};
