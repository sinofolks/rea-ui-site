import{r as d,j as n}from"./workbench-model-C4LJxhar.js";const U={title:"Background tasks",running:"running",needsYou:"need you",needsYouOne:"needs you",needsYouBadge:"Needs you",paused:"Paused",pausedCount:"paused",done:"Done",pause:"Pause",resume:"Resume",open:"Open",openAll:"Open Tasks",empty:"Nothing running right now",idle:"No tasks running"},_=new Intl.NumberFormat("en-US");function J(r){const t={...U};r!=null&&r.needsYou&&!r.needsYouOne&&(t.needsYouOne=r.needsYou);for(const c of Object.keys(U))(r==null?void 0:r[c])!==void 0&&(t[c]=r[c]);return t}function F(r){return typeof r=="number"&&Number.isFinite(r)?r:0}function Q(r){if(r.state==="done")return 1;const t=Math.max(0,F(r.total));return t>0?Math.min(1,Math.max(0,F(r.done)/t)):0}function X(r,t,c){const p=r.state==="done"?"blue":r.state==="paused"?"muted":t<=.25?"orange":t<=.5?"amber":"teal";return`var(--${c}-${p})`}function nn({tasks:r,defaultOpen:t=!1,open:c,onOpenChange:p,align:g="end",labels:u},w){const o=J(u),i=(Array.isArray(r)?r:[]).filter(e=>!!e&&typeof e=="object"&&!!e.id),[l,f]=d.useState(t),h=c??l;function y(e){c===void 0&&f(e),p==null||p(e)}const k=d.useRef(null),M=d.useRef(null),I=d.useRef(null),j=d.useRef(null),Y=d.useId(),v=i.filter(e=>e.state==="running").length,m=i.filter(e=>e.state==="needs-you").length,E=m===1?o.needsYouOne:o.needsYou,R=i.filter(e=>e.state==="paused").length;d.useEffect(()=>{if(!h)return;function e(a){var s;a.target instanceof Node&&!((s=k.current)!=null&&s.contains(a.target))&&y(!1)}return document.addEventListener("pointerdown",e),()=>document.removeEventListener("pointerdown",e)});const[B,V]=d.useState(0);d.useLayoutEffect(()=>{if(!h)return;function e(){const s=j.current,x=k.current;if(!s||!x)return;const $=x.getBoundingClientRect(),C=s.offsetWidth,N=getComputedStyle(x).direction==="rtl",z=g==="start"===N?$.right-C:$.left,H=document.documentElement.clientWidth,G=z<16?16-z:z+C>H-16?Math.max(16-z,H-16-z-C):0;V(Math.round(G))}e(),window.addEventListener("resize",e);const a=typeof ResizeObserver>"u"?null:new ResizeObserver(e);return k.current&&(a==null||a.observe(k.current)),()=>{window.removeEventListener("resize",e),a==null||a.disconnect()}},[h,g]);const[K,O]=d.useState(""),S=d.useRef(null);d.useEffect(()=>{const e=S.current;if(S.current=new Map(i.map(s=>[s.id,s.state])),!e)return;const a=[];for(const s of i){const x=e.get(s.id);x===s.state||x===void 0||(s.state==="needs-you"&&a.push(`${s.title} ${o.needsYouBadge.toLowerCase()}`),s.state==="done"&&a.push(`${s.title}: ${o.done.toLowerCase()}`))}a.length&&O(a.join(". "))});function L(){var e;return[...((e=I.current)==null?void 0:e.querySelectorAll(`.${w}__main`))??[]]}function A(e=!1){requestAnimationFrame(()=>{var s,x;const a=L();(x=a[e?a.length-1:0]??((s=j.current)==null?void 0:s.querySelector("button"))??j.current)==null||x.focus()})}function b(e){e.key!=="ArrowDown"&&e.key!=="ArrowUp"||(e.preventDefault(),h||y(!0),A(e.key==="ArrowUp"))}function D(e){var C,N;if(e.key==="Escape"){e.preventDefault(),y(!1),(C=M.current)==null||C.focus();return}const a=L(),s=e.target instanceof Element?e.target.closest(`.${w}__row`):null,x=a.findIndex(z=>z.parentElement===s);if(x<0)return;const $=e.key==="ArrowDown"?Math.min(a.length-1,x+1):e.key==="ArrowUp"?Math.max(0,x-1):e.key==="Home"?0:e.key==="End"?a.length-1:null;$!==null&&(e.preventDefault(),(N=a[$])==null||N.focus())}const W=d.useRef(null);function q(e){const a=e.target.closest(`.${w}__row`);W.current={element:e.target,id:a==null?void 0:a.dataset.id,index:a?L().findIndex(s=>s.parentElement===a):-1}}d.useLayoutEffect(()=>{var x,$;const e=W.current;if(!h||!e||e.element.isConnected)return;W.current=null;const a=document.activeElement;if(a&&a!==document.body&&a!==e.element)return;const s=L();($=s.find(C=>{var N;return((N=C.parentElement)==null?void 0:N.dataset.id)===e.id})??s[Math.min(e.index,s.length-1)]??((x=j.current)==null?void 0:x.querySelector("button"))??j.current)==null||$.focus()});const Z=v||m?[v?`${_.format(v)} ${o.running}`:"",m?`${_.format(m)} ${E}`:""].filter(Boolean).join(", "):R?`${_.format(R)} ${o.pausedCount}`:o.idle;return{text:o,visibleTasks:i,isOpen:h,setOpen:y,rootRef:k,triggerRef:M,listRef:I,panelRef:j,panelId:Y,runningCount:v,needsYouCount:m,needsYouLabel:E,pausedCount:R,horizontalOffset:B,announcement:K,summary:Z,focusTask:A,handleTriggerKeyDown:b,handlePanelKeyDown:D,handlePanelFocus:q}}function T({value:r,className:t,prefix:c}){const[p,g]=d.useState([{key:0,value:r}]),u=d.useRef(r),w=d.useRef(0);return d.useEffect(()=>{if(r===u.current)return;u.current=r;const o=++w.current;g(l=>[{key:o,value:r,fresh:!0},...l.filter(f=>!f.outgoing).slice(0,1).map(f=>({...f,outgoing:!0,fresh:!1}))]);const i=setTimeout(()=>g(l=>l.filter(f=>!f.outgoing)),360);return()=>clearTimeout(i)},[r]),n.jsx("span",{className:[`${c}__swap`,t].filter(Boolean).join(" "),children:p.map(o=>n.jsx("span",{"data-out":o.outgoing||void 0,"data-fresh":o.fresh||void 0,"aria-hidden":o.outgoing||void 0,dir:"auto",title:o.outgoing?void 0:o.value,children:o.value},o.key))})}const P=({children:r})=>n.jsx("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:r}),rn=()=>n.jsxs(P,{children:[n.jsx("path",{d:"M4 7C4 5.59 4 4.88 4.44 4.44C4.88 4 5.59 4 7 4C8.41 4 9.12 4 9.56 4.44C10 4.88 10 5.59 10 7V17C10 18.41 10 19.12 9.56 19.56C9.12 20 8.41 20 7 20C5.59 20 4.88 20 4.44 19.56C4 19.12 4 18.41 4 17V7Z"}),n.jsx("path",{d:"M14 7C14 5.59 14 4.88 14.44 4.44C14.88 4 15.59 4 17 4C18.41 4 19.12 4 19.56 4.44C20 4.88 20 5.59 20 7V17C20 18.41 20 19.12 19.56 19.56C19.12 20 18.41 20 17 20C15.59 20 14.88 20 14.44 19.56C14 19.12 14 18.41 14 17V7Z"})]}),en=()=>n.jsx(P,{children:n.jsx("path",{d:"M18.89 12.85C18.54 14.19 16.87 15.14 13.53 17.04C10.3 18.87 8.68 19.79 7.38 19.42C6.84 19.27 6.35 18.98 5.96 18.58C5 17.61 5 15.74 5 12C5 8.26 5 6.39 5.96 5.42C6.35 5.02 6.84 4.73 7.38 4.58C8.68 4.21 10.3 5.13 13.53 6.96C16.87 8.86 18.54 9.81 18.89 11.15C19.04 11.71 19.04 12.29 18.89 12.85Z"})}),tn=()=>n.jsx(P,{children:n.jsx("path",{d:"M5 14L8.5 17.5L19 6.5"})}),an=()=>n.jsxs(P,{children:[n.jsx("path",{d:"M13.5 2H8.5C7.67 2 7 2.67 7 3.5C7 4.33 7.67 5 8.5 5H13.5C14.33 5 15 4.33 15 3.5C15 2.67 14.33 2 13.5 2Z"}),n.jsx("path",{d:"M7 15H10.43M7 11H15"}),n.jsx("path",{d:"M19 13.5V9.48C19 6.65 19 5.24 18.12 4.36C17.48 3.72 16.55 3.55 15 3.5M12 22L9 22C6.17 22 4.76 22 3.88 21.12C3 20.24 3 18.83 3 16L3 9.48C3 6.65 3 5.24 3.88 4.36C4.52 3.72 5.44 3.55 7 3.5"}),n.jsx("path",{d:"M14 20C14 20 15 20 16 22C16 22 18.17 17 21 16"})]}),on=({prefix:r})=>n.jsx("svg",{className:`${r}__chev`,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:n.jsx("path",{d:"M18 9C18 9 13.58 15 12 15C10.42 15 6 9 6 9"})}),sn=({prefix:r})=>n.jsx("svg",{className:`${r}__chev`,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:n.jsx("path",{d:"M9 6C9 6 15 10.42 15 12C15 13.58 9 18 9 18"})});function un({value:r,color:t,prefix:c}){const p=2*Math.PI*2;return n.jsxs("svg",{className:`${c}__mark`,viewBox:"0 0 14 14",width:"14",height:"14","aria-hidden":"true",style:{color:t},children:[n.jsx("circle",{cx:"7",cy:"7",r:"6",fill:"none",stroke:"currentColor",strokeWidth:"1.5"}),n.jsx("circle",{className:`${c}__pie`,cx:"7",cy:"7",r:2,fill:"none",stroke:"currentColor",strokeWidth:4,style:{strokeDasharray:`${p*r} ${p}`},transform:"rotate(-90 7 7)"})]})}function cn({task:r,labels:t,onPause:c,onResume:p,onOpen:g,prefix:u}){const w=Q(r),o=Math.max(0,F(r.total)),i=r.state==="done"?o:Math.min(o,Math.max(0,F(r.done))),l=r.state==="done"?t.done:r.state==="paused"?`${t.paused} · ${r.step}`:r.step,f=r.state==="needs-you"?t.needsYouBadge:r.state==="paused"?t.paused:r.state==="done"?t.done:t.running,h=`${r.title} – ${f}. ${r.state==="done"||!r.step?"":`${r.step}. `}${_.format(i)} of ${_.format(o)} steps`;return n.jsxs("li",{className:`${u}__row`,"data-state":r.state,"data-id":r.id,children:[n.jsxs("button",{type:"button",className:`${u}__main`,"aria-label":h,onClick:()=>g==null?void 0:g(r.id),children:[n.jsx(un,{value:w,color:X(r,w,u),prefix:u}),n.jsxs("span",{className:`${u}__text`,children:[n.jsx("span",{className:`${u}__title`,dir:"auto",title:r.title,children:r.title}),n.jsx(T,{className:`${u}__step`,value:l,prefix:u})]}),r.state==="needs-you"?n.jsx("span",{className:`${u}__badge`,children:t.needsYouBadge}):n.jsxs("span",{className:`${u}__steps`,children:[_.format(i),"/",_.format(o)]})]}),n.jsx("span",{className:`${u}__act`,children:r.state==="needs-you"?n.jsx("button",{type:"button",className:`${u}__btn ${u}__btn--text`,"aria-label":`${t.open} ${r.title} – ${t.needsYouBadge.toLowerCase()}`,onClick:()=>g==null?void 0:g(r.id),children:t.open}):r.state==="running"?n.jsx("button",{type:"button",className:`${u}__btn`,"aria-label":`${t.pause} ${r.title}`,title:t.pause,onClick:()=>c==null?void 0:c(r.id),children:n.jsx(rn,{})}):r.state==="paused"?n.jsx("button",{type:"button",className:`${u}__btn`,"aria-label":`${t.resume} ${r.title}`,title:t.resume,onClick:()=>p==null?void 0:p(r.id),children:n.jsx(en,{})}):n.jsx("span",{className:`${u}__btn`,"aria-hidden":"true",children:n.jsx(tn,{})})})]})}const dn=`
.ui-rn {
  --ui-rn-tray: #f0f0f0;
  --ui-rn-tray-hover: #e8e8e8;
  --ui-rn-card: #ffffff;
  --ui-rn-strong: #171717;
  --ui-rn-ink: #171717;
  --ui-rn-text: #6b6b6b;
  --ui-rn-muted: #626873;
  --ui-rn-faint: #6b6b6b;
  --ui-rn-icon: #626873;
  --ui-rn-line: #ececec;
  --ui-rn-hover: #f5f5f5;
  --ui-rn-press: #ededed;
  --ui-rn-fill: #f2f2f2;
  --ui-rn-focus: rgba(0, 96, 226, 0.7);
  --ui-rn-teal: #13b3a0;
  --ui-rn-amber: #e8b000;
  --ui-rn-orange: #f28a2e;
  --ui-rn-blue: #0069be;
  --ui-rn-badge: #866300;
  --ui-rn-badge-wash: #fdf3d2;
  --ui-rn-shadow: 0 0 0 1px var(--ui-rn-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-rn-pop:
    0 0 0 1px var(--ui-rn-line), 0 1px 2px rgba(0, 0, 0, 0.04),
    0 14px 32px -12px rgba(0, 0, 0, 0.18);
  --ui-rn-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  --ui-rn-w: 348px;
  --ui-rn-row: 52px;
  position: relative;
  display: inline-block;
  flex: none;
  box-sizing: border-box;
  max-width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-rn-text);
  text-align: start;
  -webkit-font-smoothing: antialiased;
}
.ui-rn *,
.ui-rn *::before,
.ui-rn *::after {
  box-sizing: border-box;
}
:where(.ui-rn) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-rn button:focus-visible {
  outline: 2px solid var(--ui-rn-focus);
  outline-offset: 2px;
}
.ui-rn :is(p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-rn svg {
  display: block;
  flex: none;
}
.ui-rn__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-rn__trigger {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  max-width: 100%;
  height: 30px;
  padding: 0 9px 0 11px;
  border-radius: 8px;
  background: var(--ui-rn-tray);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rn-muted);
  white-space: nowrap;
  transition: background-color 140ms ease;
}
.ui-rn__trigger:hover,
.ui-rn[data-open] .ui-rn__trigger {
  background: var(--ui-rn-tray-hover);
}
.ui-rn__part {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
}
.ui-rn__n {
  flex: none;
  font-weight: 500;
  color: var(--ui-rn-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rn__sep {
  flex: none;
  color: var(--ui-rn-faint);
}
.ui-rn__ring {
  flex: none;
  width: 8px;
  height: 8px;
  margin-right: 2px;
  border-radius: 50%;
  box-shadow: inset 0 0 0 1.5px var(--ui-rn-teal);
}
.ui-rn__ring[data-idle] {
  box-shadow: inset 0 0 0 1.5px var(--ui-rn-faint);
}
.ui-rn__dot {
  flex: none;
  width: 6px;
  height: 6px;
  margin: 0 3px 0 1px;
  border-radius: 50%;
  background: var(--ui-rn-amber);
}
.ui-rn__trigger > .ui-rn__chev {
  width: 12px;
  height: 12px;
  margin-left: -2px;
  color: var(--ui-rn-icon);
  transition: rotate 200ms var(--ui-rn-ease);
}
.ui-rn[data-open] .ui-rn__trigger > .ui-rn__chev {
  rotate: 180deg;
}
.ui-rn__panel {
  position: absolute;
  top: calc(100% + 6px);
  inset-inline-end: 0;
  z-index: 50;
  width: min(var(--ui-rn-w), calc(100vw - 32px));
  padding: 4px;
  border-radius: 16px;
  background: var(--ui-rn-tray);
  box-shadow: var(--ui-rn-pop);
  transform-origin: top right;
  animation: ui-rn-pop 200ms var(--ui-rn-ease) both;
}
.ui-rn[data-align="start"] .ui-rn__panel {
  inset-inline: 0 auto;
  transform-origin: top left;
}
.ui-rn:dir(rtl) .ui-rn__panel {
  transform-origin: top left;
}
.ui-rn[data-align="start"]:dir(rtl) .ui-rn__panel {
  transform-origin: top right;
}
.ui-rn__panel[hidden] {
  display: none;
}
.ui-rn__panel:focus {
  outline: none;
}
.ui-rn__head {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 32px;
  padding: 0 10px 2px;
}
.ui-rn__label {
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rn-strong);
}
.ui-rn__count {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rn-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rn__body {
  padding: 4px;
  border-radius: 12px;
  background: var(--ui-rn-card);
  box-shadow: var(--ui-rn-shadow);
}
.ui-rn__list {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  max-height: min(
    calc(var(--ui-rn-row) * 5.5),
    max(calc(var(--ui-rn-row) * 2.5), calc(100dvh - 200px))
  );
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-rn__empty {
  padding: 14px 8px 16px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rn-muted);
}
.ui-rn__row {
  position: relative;
  display: flex;
  align-items: center;
  flex: none;
  height: var(--ui-rn-row);
  border-radius: 8px;
  transition: background-color 140ms ease;
}
.ui-rn__row:hover {
  background: var(--ui-rn-hover);
}
.ui-rn__main {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 100%;
  padding: 0 6px 0 9px;
  border-radius: 8px;
}
.ui-rn__main:focus-visible {
  background: var(--ui-rn-hover);
  outline: 2px solid var(--ui-rn-focus);
  outline-offset: -2px;
}
.ui-rn__mark {
  flex: none;
  transition: color 400ms ease;
}
.ui-rn__pie {
  transition: stroke-dasharray 700ms var(--ui-rn-ease);
}
.ui-rn__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-rn__title {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-rn-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rn__step {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rn-muted);
}
.ui-rn__row[data-state="done"] .ui-rn__title {
  color: var(--ui-rn-text);
}
.ui-rn__steps {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rn-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rn__badge {
  flex: none;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  background: var(--ui-rn-badge-wash);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-rn-badge);
  white-space: nowrap;
  animation: ui-rn-in 260ms var(--ui-rn-ease) both;
}
.ui-rn__act {
  display: flex;
  flex: none;
  justify-content: flex-end;
  min-width: 40px;
  padding-right: 6px;
}
.ui-rn__btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  color: var(--ui-rn-icon);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-rn__btn svg {
  width: 14px;
  height: 14px;
}
button.ui-rn__btn:hover {
  background: var(--ui-rn-press);
  color: var(--ui-rn-ink);
}
span.ui-rn__btn {
  color: var(--ui-rn-blue);
}
.ui-rn__btn--text {
  width: auto;
  padding: 0 9px;
  background: var(--ui-rn-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rn-ink);
  animation: ui-rn-in 260ms var(--ui-rn-ease) both;
}
button.ui-rn__btn--text:hover {
  background: var(--ui-rn-press);
}
.ui-rn__swap {
  display: inline-grid;
  min-width: 0;
  overflow: hidden;
}
.ui-rn__swap > * {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rn__swap > [data-fresh] {
  animation: ui-rn-swap-in 340ms var(--ui-rn-ease) both;
}
.ui-rn__swap > [data-out] {
  animation: ui-rn-swap-out 340ms var(--ui-rn-ease) both;
}
.ui-rn__foot {
  padding: 4px 0 0;
}
.ui-rn__all {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 9px 0 13px;
  border-radius: 10px;
  color: var(--ui-rn-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-rn__all:hover {
  background: var(--ui-rn-tray-hover);
  color: var(--ui-rn-ink);
}
.ui-rn__all > svg:first-child {
  width: 14px;
  height: 14px;
  color: var(--ui-rn-icon);
}
.ui-rn__all > span {
  flex: 1;
  font-weight: 500;
}
.ui-rn__all > .ui-rn__chev {
  width: 12px;
  height: 12px;
  color: var(--ui-rn-icon);
  transition: translate 200ms var(--ui-rn-ease);
}
.ui-rn__all:hover > .ui-rn__chev {
  translate: 2px 0;
}
.ui-rn:dir(rtl) .ui-rn__all > .ui-rn__chev {
  scale: -1 1;
}
.ui-rn:dir(rtl) .ui-rn__all:hover > .ui-rn__chev {
  translate: -2px 0;
}
@keyframes ui-rn-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-rn-in {
  from {
    opacity: 0;
    transform: scale(0.92);
  }
}
@keyframes ui-rn-swap-in {
  from {
    opacity: 0;
    transform: translateY(60%);
  }
}
@keyframes ui-rn-swap-out {
  to {
    opacity: 0;
    transform: translateY(-60%);
  }
}
@media (max-width: 359px) {
  .ui-rn[data-both] .ui-rn__word {
    display: none;
  }
}
@media (max-width: 419px) {
  .ui-rn[data-both][data-long] .ui-rn__word {
    display: none;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-rn__trigger {
    height: 36px;
  }
  .ui-rn {
    --ui-rn-row: 56px;
  }
  .ui-rn__btn {
    width: 36px;
    height: 36px;
  }
  .ui-rn__btn--text {
    width: auto;
  }
  .ui-rn__all {
    height: 40px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rn *,
  .ui-rn *::before,
  .ui-rn *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-rn__swap > [data-out] {
    visibility: hidden;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rn {
  --ui-rn-tray: #19191c;
  --ui-rn-tray-hover: #222226;
  --ui-rn-card: #232326;
  --ui-rn-strong: #ededed;
  --ui-rn-ink: #ededed;
  --ui-rn-text: #a1a1a6;
  --ui-rn-muted: #7c7c82;
  --ui-rn-faint: #4a4a50;
  --ui-rn-icon: #8a8a90;
  --ui-rn-line: #2f2f34;
  --ui-rn-hover: #2a2a2e;
  --ui-rn-press: #323237;
  --ui-rn-fill: #2c2c30;
  --ui-rn-focus: rgba(77, 141, 255, 0.8);
  --ui-rn-teal: #4fc3b4;
  --ui-rn-amber: #e6c24d;
  --ui-rn-orange: #f5a05a;
  --ui-rn-blue: #4aa8ff;
  --ui-rn-badge: #e6c24d;
  --ui-rn-badge-wash: #33290f;
  --ui-rn-shadow: 0 0 0 1px var(--ui-rn-line), 0 1px 2px rgba(0, 0, 0, 0.3);
  --ui-rn-pop:
    0 0 0 1px var(--ui-rn-line), 0 16px 32px -12px rgba(0, 0, 0, 0.7);
}
`,ln=`
.ui-rnc {
  --ui-rnc-card: #ffffff;
  --ui-rnc-strong: #000000;
  --ui-rnc-ink: rgba(0, 0, 0, 0.88);
  --ui-rnc-text: rgba(0, 0, 0, 0.65);
  --ui-rnc-muted: rgba(0, 0, 0, 0.65);
  --ui-rnc-faint: rgba(0, 0, 0, 0.65);
  --ui-rnc-icon: rgba(0, 0, 0, 0.65);
  --ui-rnc-line: rgba(0, 0, 0, 0.06);
  --ui-rnc-hover: rgba(0, 0, 0, 0.04);
  --ui-rnc-press: rgba(0, 0, 0, 0.07);
  --ui-rnc-focus: rgba(0, 96, 226, 0.7);
  --ui-rnc-teal: #13b3a0;
  --ui-rnc-amber: #e8b000;
  --ui-rnc-orange: #f28a2e;
  --ui-rnc-blue: #0069be;
  --ui-rnc-badge: #866300;
  --ui-rnc-badge-wash: rgba(232, 176, 0, 0.14);
  --ui-rnc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-rnc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-rnc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-rnc-w: 340px;
  --ui-rnc-row: 52px;
  position: relative;
  display: inline-block;
  flex: none;
  box-sizing: border-box;
  max-width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-rnc-ink);
  text-align: start;
  -webkit-font-smoothing: antialiased;
}
.ui-rnc *,
.ui-rnc *::before,
.ui-rnc *::after {
  box-sizing: border-box;
}
:where(.ui-rnc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-rnc button:focus-visible {
  outline: 2px solid var(--ui-rnc-focus);
  outline-offset: 2px;
}
.ui-rnc :is(p, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-rnc svg {
  display: block;
  flex: none;
}
.ui-rnc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-rnc__trigger {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  max-width: 100%;
  height: 28px;
  padding: 0 8px 0 10px;
  border-radius: 6px;
  background: var(--ui-rnc-card);
  box-shadow: var(--ui-rnc-shadow);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rnc-text);
  white-space: nowrap;
  transition: background-color 140ms ease;
}
.ui-rnc__trigger:hover {
  background: color-mix(in srgb, var(--ui-rnc-card), #000 2%);
}
.ui-rnc__part {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
}
.ui-rnc__n {
  flex: none;
  font-weight: 500;
  color: var(--ui-rnc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-rnc__sep {
  flex: none;
  color: var(--ui-rnc-faint);
}
.ui-rnc__ring {
  flex: none;
  width: 8px;
  height: 8px;
  margin-right: 2px;
  border-radius: 50%;
  box-shadow: inset 0 0 0 1.5px var(--ui-rnc-teal);
}
.ui-rnc__ring[data-idle] {
  box-shadow: inset 0 0 0 1.5px var(--ui-rnc-faint);
}
.ui-rnc__dot {
  flex: none;
  width: 6px;
  height: 6px;
  margin: 0 3px 0 1px;
  border-radius: 50%;
  background: var(--ui-rnc-amber);
}
.ui-rnc__trigger > .ui-rnc__chev {
  width: 12px;
  height: 12px;
  margin-left: -2px;
  color: var(--ui-rnc-icon);
  transition: rotate 200ms var(--ui-rnc-ease);
}
.ui-rnc[data-open] .ui-rnc__trigger > .ui-rnc__chev {
  rotate: 180deg;
}
.ui-rnc__panel {
  position: absolute;
  top: calc(100% + 6px);
  inset-inline-end: 0;
  z-index: 50;
  width: min(var(--ui-rnc-w), calc(100vw - 32px));
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-rnc-card);
  box-shadow: var(--ui-rnc-pop);
  transform-origin: top right;
  animation: ui-rnc-pop 180ms var(--ui-rnc-ease) both;
}
.ui-rnc[data-align="start"] .ui-rnc__panel {
  inset-inline: 0 auto;
  transform-origin: top left;
}
.ui-rnc:dir(rtl) .ui-rnc__panel {
  transform-origin: top left;
}
.ui-rnc[data-align="start"]:dir(rtl) .ui-rnc__panel {
  transform-origin: top right;
}
.ui-rnc__panel[hidden] {
  display: none;
}
.ui-rnc__panel:focus {
  outline: none;
}
.ui-rnc__head {
  display: flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 8px;
}
.ui-rnc__label {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-rnc-muted);
}
.ui-rnc__count {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rnc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-rnc__body {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
}
.ui-rnc__list {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  max-height: min(
    calc(var(--ui-rnc-row) * 5.5),
    max(calc(var(--ui-rnc-row) * 2.5), calc(100dvh - 200px))
  );
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-rnc__empty {
  padding: 14px 8px 16px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rnc-muted);
}
.ui-rnc__row {
  position: relative;
  display: flex;
  align-items: center;
  flex: none;
  height: var(--ui-rnc-row);
  border-radius: 6px;
  transition: background-color 140ms ease;
}
.ui-rnc__row:hover {
  background: var(--ui-rnc-hover);
}
.ui-rnc__main {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 100%;
  padding: 0 6px 0 9px;
  border-radius: 6px;
}
.ui-rnc__main:focus-visible {
  background: var(--ui-rnc-hover);
  outline: 2px solid var(--ui-rnc-focus);
  outline-offset: -2px;
}
.ui-rnc__mark {
  flex: none;
  transition: color 400ms ease;
}
.ui-rnc__pie {
  transition: stroke-dasharray 700ms var(--ui-rnc-ease);
}
.ui-rnc__text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-rnc__title {
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-rnc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rnc__step {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rnc-muted);
}
.ui-rnc__row[data-state="done"] .ui-rnc__title {
  color: var(--ui-rnc-text);
}
.ui-rnc__steps {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-rnc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-rnc__badge {
  flex: none;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-rnc-badge-wash);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-rnc-badge);
  white-space: nowrap;
  animation: ui-rnc-in 260ms var(--ui-rnc-ease) both;
}
.ui-rnc__act {
  display: flex;
  flex: none;
  justify-content: flex-end;
  min-width: 40px;
  padding-right: 6px;
}
.ui-rnc__btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-rnc-icon);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-rnc__btn svg {
  width: 14px;
  height: 14px;
}
button.ui-rnc__btn:hover {
  background: var(--ui-rnc-press);
  color: var(--ui-rnc-ink);
}
span.ui-rnc__btn {
  color: var(--ui-rnc-blue);
}
.ui-rnc__btn--text {
  width: auto;
  padding: 0 8px;
  background: var(--ui-rnc-card);
  box-shadow: var(--ui-rnc-shadow);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-rnc-ink);
  animation: ui-rnc-in 260ms var(--ui-rnc-ease) both;
}
button.ui-rnc__btn--text:hover {
  background: color-mix(in srgb, var(--ui-rnc-card), #000 3%);
}
.ui-rnc__swap {
  display: inline-grid;
  min-width: 0;
  overflow: hidden;
}
.ui-rnc__swap > * {
  grid-area: 1 / 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-rnc__swap > [data-fresh] {
  animation: ui-rnc-swap-in 340ms var(--ui-rnc-ease) both;
}
.ui-rnc__swap > [data-out] {
  animation: ui-rnc-swap-out 340ms var(--ui-rnc-ease) both;
}
.ui-rnc__foot {
  margin: 4px -4px -4px;
  padding: 4px;
  border-top: 0.5px solid var(--ui-rnc-line);
}
.ui-rnc__all {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px 0 9px;
  border-radius: 6px;
  color: var(--ui-rnc-ink);
  transition: background-color 140ms ease;
}
.ui-rnc__all:hover {
  background: var(--ui-rnc-hover);
}
.ui-rnc__all > svg:first-child {
  width: 14px;
  height: 14px;
  color: var(--ui-rnc-icon);
}
.ui-rnc__all > span {
  flex: 1;
}
.ui-rnc__all > .ui-rnc__chev {
  width: 12px;
  height: 12px;
  color: var(--ui-rnc-icon);
  transition: translate 200ms var(--ui-rnc-ease);
}
.ui-rnc__all:hover > .ui-rnc__chev {
  translate: 2px 0;
}
.ui-rnc:dir(rtl) .ui-rnc__all > .ui-rnc__chev {
  scale: -1 1;
}
.ui-rnc:dir(rtl) .ui-rnc__all:hover > .ui-rnc__chev {
  translate: -2px 0;
}
@keyframes ui-rnc-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-rnc-in {
  from {
    opacity: 0;
    transform: scale(0.92);
  }
}
@keyframes ui-rnc-swap-in {
  from {
    opacity: 0;
    transform: translateY(60%);
  }
}
@keyframes ui-rnc-swap-out {
  to {
    opacity: 0;
    transform: translateY(-60%);
  }
}
@media (max-width: 359px) {
  .ui-rnc[data-both] .ui-rnc__word {
    display: none;
  }
}
@media (max-width: 419px) {
  .ui-rnc[data-both][data-long] .ui-rnc__word {
    display: none;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-rnc__trigger {
    height: 36px;
  }
  .ui-rnc {
    --ui-rnc-row: 56px;
  }
  .ui-rnc__btn {
    width: 36px;
    height: 36px;
  }
  .ui-rnc__btn--text {
    width: auto;
  }
  .ui-rnc__all {
    height: 40px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-rnc *,
  .ui-rnc *::before,
  .ui-rnc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-rnc__swap > [data-out] {
    visibility: hidden;
  }
}
:where(.dark, [data-theme="dark"]) .ui-rnc {
  --ui-rnc-card: #1c1c1e;
  --ui-rnc-strong: #ffffff;
  --ui-rnc-ink: rgba(255, 255, 255, 0.9);
  --ui-rnc-text: rgba(255, 255, 255, 0.62);
  --ui-rnc-muted: rgba(255, 255, 255, 0.46);
  --ui-rnc-faint: rgba(255, 255, 255, 0.3);
  --ui-rnc-icon: rgba(255, 255, 255, 0.46);
  --ui-rnc-line: rgba(255, 255, 255, 0.08);
  --ui-rnc-hover: rgba(255, 255, 255, 0.05);
  --ui-rnc-press: rgba(255, 255, 255, 0.09);
  --ui-rnc-focus: rgba(77, 141, 255, 0.8);
  --ui-rnc-teal: #4fc3b4;
  --ui-rnc-amber: #e6c24d;
  --ui-rnc-orange: #f5a05a;
  --ui-rnc-blue: #4aa8ff;
  --ui-rnc-badge: #e6c24d;
  --ui-rnc-badge-wash: rgba(232, 176, 0, 0.16);
  --ui-rnc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-rnc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 16px 32px -12px rgba(0, 0, 0, 0.7);
}
:where(.dark, [data-theme="dark"]) .ui-rnc__trigger:hover {
  background: color-mix(in srgb, var(--ui-rnc-card), #fff 4%);
}
:where(.dark, [data-theme="dark"]) button.ui-rnc__btn--text:hover {
  background: color-mix(in srgb, var(--ui-rnc-card), #fff 5%);
}
`;function hn({clean:r=!1,...t}){const{align:c="end",className:p,onPause:g,onResume:u,onOpen:w,onOpenAll:o}=t,i=r?"ui-rnc":"ui-rn",{text:l,visibleTasks:f,isOpen:h,setOpen:y,rootRef:k,triggerRef:M,listRef:I,panelRef:j,panelId:Y,runningCount:v,needsYouCount:m,needsYouLabel:E,pausedCount:R,horizontalOffset:B,announcement:V,summary:K,focusTask:O,handleTriggerKeyDown:S,handlePanelKeyDown:L,handlePanelFocus:A}=nn(t,i);return n.jsxs(n.Fragment,{children:[n.jsx("style",{href:r?"ui-running-now-clean":"ui-running-now",precedence:"default",children:r?ln:dn}),n.jsxs("div",{ref:k,className:[i,p].filter(Boolean).join(" "),"data-open":h||void 0,"data-align":c,"data-both":v>0&&m>0||void 0,"data-long":_.format(v).length+_.format(m).length>4||void 0,onKeyDown:b=>{b.key==="Escape"&&h&&b.target===M.current&&y(!1)},onBlur:b=>{var D;h&&b.relatedTarget&&!((D=k.current)!=null&&D.contains(b.relatedTarget))&&y(!1)},children:[n.jsxs("button",{ref:M,type:"button",className:`${i}__trigger`,"aria-haspopup":"dialog","aria-expanded":h,"aria-controls":Y,"aria-label":`${l.title}: ${K}`,onClick:b=>{y(!h),!h&&b.detail===0&&O()},onKeyDown:S,children:[v||m?n.jsxs(n.Fragment,{children:[v>0&&n.jsxs("span",{className:`${i}__part`,children:[n.jsx("span",{className:`${i}__ring`,"aria-hidden":"true"}),n.jsx(T,{className:`${i}__n`,value:_.format(v),prefix:i}),n.jsx("span",{className:`${i}__word`,children:l.running})]}),v>0&&m>0&&n.jsx("span",{className:`${i}__sep`,"aria-hidden":"true",children:"·"}),m>0&&n.jsxs("span",{className:`${i}__part`,children:[n.jsx("span",{className:`${i}__dot`,"aria-hidden":"true"}),n.jsx(T,{className:`${i}__n`,value:_.format(m),prefix:i}),n.jsx("span",{className:`${i}__word`,children:E})]})]}):R>0?n.jsxs("span",{className:`${i}__part`,children:[n.jsx("span",{className:`${i}__ring`,"data-idle":"","aria-hidden":"true"}),n.jsx(T,{className:`${i}__n`,value:_.format(R),prefix:i}),n.jsx("span",{className:`${i}__word`,children:l.pausedCount})]}):n.jsxs("span",{className:`${i}__part`,children:[n.jsx("span",{className:`${i}__ring`,"data-idle":"","aria-hidden":"true"}),n.jsx("span",{className:`${i}__word`,children:l.idle})]}),n.jsx(on,{prefix:i})]}),n.jsxs("div",{ref:j,id:Y,className:`${i}__panel`,style:B?{translate:`${B}px 0`}:void 0,role:"dialog","aria-label":l.title,tabIndex:-1,hidden:!h,onKeyDown:L,onFocus:A,children:[n.jsxs("div",{className:`${i}__head`,children:[n.jsx("span",{className:`${i}__label`,children:l.title}),n.jsx("span",{className:`${i}__count`,children:_.format(f.length)})]}),n.jsx("div",{className:`${i}__body`,children:f.length?n.jsx("ul",{ref:I,className:`${i}__list`,children:f.map(b=>n.jsx(cn,{task:b,labels:l,onPause:g,onResume:u,onOpen:w,prefix:i},b.id))}):n.jsx("p",{className:`${i}__empty`,children:l.empty})}),o&&n.jsx("div",{className:`${i}__foot`,children:n.jsxs("button",{type:"button",className:`${i}__all`,onClick:o,children:[n.jsx(an,{}),n.jsx("span",{children:l.openAll}),n.jsx(sn,{prefix:i})]})})]}),n.jsx("span",{className:`${i}__sr`,role:"status","aria-live":"polite",children:V})]})]})}export{hn as R};
