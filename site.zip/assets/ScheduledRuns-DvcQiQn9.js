const n=`.ui-sch {
  --ui-sch-tray: #f0f0f0;
  --ui-sch-card: #ffffff;
  --ui-sch-strong: #171717;
  --ui-sch-ink: #171717;
  --ui-sch-text: #59616c;
  --ui-sch-muted: #626873;
  --ui-sch-faint: #6b6b6b;
  --ui-sch-line: #ececec;
  --ui-sch-lane: #f4f4f4;
  --ui-sch-well: #fafafa;
  --ui-sch-edge: #ececec;
  --ui-sch-accent: #2f6bff;
  --ui-sch-focus: rgba(0, 96, 226, 0.7);
  --ui-sch-accent-bg: #edf2ff;
  --ui-sch-drop: rgba(47, 107, 255, 0.45);
  --ui-sch-hatch: rgba(0, 0, 0, 0.05);
  --ui-sch-meter: #c2c2c2;
  --ui-sch-track: #ededed;
  --ui-sch-now: #e5484d;
  --ui-sch-track-2: rgba(0, 0, 0, 0.06);
  --ui-sch-amber: #ac4f07;
  --ui-sch-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-sch-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-sch / inline-size;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-sch-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-sch-text);
  -webkit-font-smoothing: antialiased;
}
.ui-sch *,
.ui-sch *::before,
.ui-sch *::after {
  box-sizing: border-box;
}
.ui-sch ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-sch) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  cursor: pointer;
}
.ui-sch button:focus-visible {
  outline: 2px solid var(--ui-sch-focus);
  outline-offset: 2px;
}
.ui-sch__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}
.ui-sch__heading {
  display: flex;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-sch__title {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-sch-strong);
  white-space: nowrap;
}
.ui-sch__note {
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-sch-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-sch__bar {
  flex-wrap: wrap;
}
.ui-sch__tools {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-left: auto;
}
.ui-sch__crew {
  display: flex;
  align-items: center;
  padding-left: 9px;
}
.ui-sch__agent {
  position: relative;
  display: inline-flex;
  align-items: center;
  height: 26px;
  margin-left: -9px;
  padding: 0 5px;
  border-radius: 7px;
  background: var(--ui-sch-card) !important;
  box-shadow: var(--ui-sch-shadow);
  transition:
    margin-left 380ms var(--ui-sch-ease),
    transform 160ms ease,
    opacity 200ms ease;
}
.ui-sch__crew[data-open] .ui-sch__agent {
  margin-left: 4px;
}
.ui-sch__crew[data-open] .ui-sch__agent:not([data-on]) {
  opacity: 0.6;
}
.ui-sch__agent:hover {
  transform: translateY(-1px);
}
.ui-sch__agent-logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-sch-ink);
}
.ui-sch__agent-logo > svg {
  width: 14px;
  height: 14px;
}
.ui-sch__agent-name {
  max-width: 0;
  overflow: hidden;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-sch-ink);
  white-space: nowrap;
  opacity: 0;
  transition:
    max-width 380ms var(--ui-sch-ease),
    margin 380ms var(--ui-sch-ease),
    opacity 240ms ease;
}
.ui-sch__agent[data-on] .ui-sch__agent-name {
  max-width: 120px;
  margin: 0 3px 0 6px;
  opacity: 1;
}
.ui-sch__total {
  font-size: 12px;
  color: var(--ui-sch-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-sch__modes {
  display: flex;
  padding: 2px;
  border-radius: 8px;
  background: var(--ui-sch-track-2);
}
.ui-sch__modes > button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 12.5px !important;
  font-weight: 500;
  color: var(--ui-sch-text) !important;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-sch__modes > button > svg {
  width: 12px;
  height: 12px;
}
.ui-sch__modes > button:focus-visible {
  outline-offset: -2px;
}
.ui-sch__modes > button[aria-checked="true"] {
  background: var(--ui-sch-card) !important;
  color: var(--ui-sch-strong) !important;
  box-shadow: var(--ui-sch-shadow);
}
.ui-sch__body {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  gap: 12px;
  align-items: stretch;
}
.ui-sch__stack {
  position: relative;
  min-height: 240px;
  padding: 4px;
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-sch-lane);
}
.ui-sch__stack-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 30px;
  padding: 0 6px 0 8px;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-sch-muted);
}
.ui-sch__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(16, 16, 24, 0.06);
  font-size: 11px;
  color: var(--ui-sch-text);
  font-variant-numeric: tabular-nums;
}
.ui-sch__cards {
  display: grid;
}
.ui-sch__body > .ui-sch__stack {
  display: flex;
  flex-direction: column;
  height: 0;
  min-height: max(100%, 240px);
}
.ui-sch__stack > .ui-sch__cards {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-sch__tile:focus-visible {
  outline: 2px solid var(--ui-sch-focus);
  outline-offset: 2px;
}
.ui-sch__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-sch__slot {
  height: 68px;
  transition: height 420ms var(--ui-sch-ease) 140ms;
}
.ui-sch__slot[data-gone] {
  height: 0;
  pointer-events: none;
}
.ui-sch__slot[data-gone] > .ui-sch__card {
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition:
    opacity 160ms ease,
    visibility 0s linear 160ms;
}
.ui-sch__card[data-flying] {
  visibility: hidden;
}
.ui-sch__card[data-movable] {
  cursor: grab;
  touch-action: none;
  user-select: none;
}
.ui-sch__card[data-held] {
  opacity: 0.35;
}
.ui-sch__tile {
  display: grid;
  align-content: center;
  gap: 3px;
  height: 64px;
  padding: 0 8px 0 6px;
  overflow: hidden;
  border-radius: 7px;
  background: var(--ui-sch-card);
  box-shadow: var(--ui-sch-shadow);
}
.ui-sch__tile-top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-sch__tile-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 15px;
  color: var(--ui-sch-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-sch__tile-part {
  flex: none;
  font-size: 10px;
  line-height: 15px;
  color: var(--ui-sch-muted);
  font-variant-numeric: tabular-nums;
}
.ui-sch__tile-meta {
  overflow: hidden;
  padding-left: 24px;
  font-size: 10.5px;
  line-height: 14px;
  color: var(--ui-sch-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-sch__tile-meta[data-nope] {
  color: var(--ui-sch-amber);
}
.ui-sch__card {
  height: 64px;
}
.ui-sch__tile-stats {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 16px;
  padding-left: 24px;
  font-size: 10.5px;
  line-height: 16px;
  color: var(--ui-sch-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-sch__stat {
  display: inline-flex;
  align-items: center;
  gap: 3px;
}
.ui-sch__stat > svg {
  flex: none;
  width: 12px;
  height: 12px;
}
.ui-sch__tag {
  margin-left: auto;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-sch-track-2);
  font-size: 10px;
  line-height: 15px;
  color: var(--ui-sch-text);
}
.ui-sch__tile[data-open] {
  box-shadow:
    0 0 0 1.5px var(--ui-sch-drop),
    var(--ui-sch-shadow);
}
.ui-sch__info {
  position: absolute;
  z-index: 7;
  display: grid;
  pointer-events: none;
  gap: 8px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-sch-card);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 14px 32px -10px rgba(16, 16, 24, 0.24),
    0 2px 6px rgba(16, 16, 24, 0.05);
  transform-origin: top left;
  animation: ui-sch-pop 180ms var(--ui-sch-ease) both;
}
.ui-sch__info-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-sch__info-title {
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-sch-strong);
  overflow-wrap: anywhere;
}
.ui-sch__info-text {
  margin: 0;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-sch-text);
}
.ui-sch__info-rows {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  gap: 4px 12px;
  margin: 0;
  padding-top: 8px;
  border-top: 0.5px solid var(--ui-sch-line);
  font-size: 12px;
  line-height: 16px;
}
.ui-sch__info-rows dt {
  color: var(--ui-sch-muted);
}
.ui-sch__info-rows dd {
  margin: 0;
  color: var(--ui-sch-ink);
  font-variant-numeric: tabular-nums;
}
.ui-sch__info-hint {
  margin: 0;
  font-size: 11px;
  line-height: 15px;
  color: var(--ui-sch-faint);
}
@keyframes ui-sch-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
.ui-sch__tile {
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-sch__tile[data-dim] {
  background: var(--ui-sch-well);
}
.ui-sch__tile .ui-sch__mark,
.ui-sch__info .ui-sch__mark {
  width: 18px;
  height: 18px;
  border-radius: 5px;
}
.ui-sch__tile .ui-sch__mark > svg,
.ui-sch__info .ui-sch__mark > svg {
  width: 12px;
  height: 12px;
}
.ui-sch__empty {
  position: absolute;
  inset: 34px 4px 4px;
  display: grid;
  place-items: center;
  margin: 0;
  font-size: 12px;
  color: var(--ui-sch-faint);
  opacity: 0;
  transition: opacity 300ms ease 300ms;
  pointer-events: none;
}
.ui-sch__empty[data-show] {
  opacity: 1;
}
.ui-sch__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-sch-card);
  box-shadow: var(--ui-sch-shadow);
  font-size: 9px;
  font-weight: 500;
  color: var(--ui-sch-ink);
}
.ui-sch__mark > svg {
  width: 10px;
  height: 10px;
}
.ui-sch__flier {
  position: absolute;
  z-index: 5;
  pointer-events: none;
}
.ui-sch__scroll {
  min-width: 0;
  overflow-x: auto;
  user-select: none;
}
.ui-sch__week {
  display: grid;
  gap: 4px;
  min-width: calc(38px + var(--ui-sch-days) * 128px);
}
.ui-sch__row {
  display: grid;
  grid-template-columns: 34px repeat(var(--ui-sch-days), minmax(0, 1fr));
  gap: 4px;
}
.ui-sch__row--head {
  height: 30px;
  align-items: center;
}
.ui-sch__day {
  display: flex;
  align-items: baseline;
  gap: 4px;
  height: 26px;
  padding: 5px 8px 0;
  border-radius: 8px;
  background: var(--ui-sch-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-sch-line);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-sch-muted);
}
.ui-sch__day b {
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0;
  color: var(--ui-sch-text);
  font-variant-numeric: tabular-nums;
}
.ui-sch__time {
  padding-top: 6px;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-sch-faint);
  font-variant-numeric: tabular-nums;
}
.ui-sch__cell {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 156px;
  padding: 4px 4px 20px;
  border-radius: 10px;
  background: var(--ui-sch-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-sch-line);
}
.ui-sch__cell[data-past] {
  background: transparent;
}
.ui-sch__cell[data-past] .ui-sch__tile-title {
  color: var(--ui-sch-muted);
}
.ui-sch__cell {
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    opacity 160ms ease;
}
.ui-sch__cell[data-blocked] {
  background: repeating-linear-gradient(
    135deg,
    var(--ui-sch-well) 0 6px,
    var(--ui-sch-hatch) 6px 7px
  );
}
.ui-sch__cell[data-blocked] > :not(.ui-sch__why) {
  opacity: 1;
}
.ui-sch__cell[data-over] {
  background: var(--ui-sch-accent-bg);
  box-shadow: inset 0 0 0 1px var(--ui-sch-drop);
}
.ui-sch__chips {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 3px;
}
.ui-sch__chip[data-landing] {
  visibility: hidden;
}
.ui-sch__chip[data-movable] {
  cursor: grab;
  touch-action: none;
  user-select: none;
}
.ui-sch__chip[data-held] {
  opacity: 0.35;
}
.ui-sch[data-dragging],
.ui-sch[data-dragging] * {
  cursor: grabbing !important;
}
.ui-sch__ghost {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 6;
  margin: 0;
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 12px 24px -8px rgba(16, 16, 24, 0.28);
  pointer-events: none;
  animation: none;
}
.ui-sch__chip[data-fresh] {
  animation: ui-sch-drop 460ms var(--ui-sch-ease) both;
}
.ui-sch__more {
  height: 64px;
  padding-left: 6px;
  font-size: 11px;
  line-height: 64px;
  color: var(--ui-sch-muted);
}
.ui-sch__now {
  position: absolute;
  top: -2px;
  right: 0;
  left: 0;
  z-index: 2;
  height: 1.5px;
  margin-top: -0.75px;
  background: var(--ui-sch-now);
  pointer-events: none;
}
.ui-sch__now::before {
  content: "";
  position: absolute;
  top: 50%;
  left: -4px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ui-sch-now);
  transform: translateY(-50%);
}
.ui-sch__use {
  position: absolute;
  right: 8px;
  bottom: 9px;
  left: 8px;
  height: 4px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-sch-track);
}
.ui-sch__use > i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ui-sch-meter);
  transition: width 520ms var(--ui-sch-ease);
}
.ui-sch__cell[data-past] .ui-sch__use > i {
  opacity: 0.5;
}
.ui-sch__why {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 3;
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--ui-sch-card);
  box-shadow: var(--ui-sch-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-sch-text);
  white-space: nowrap;
  transform: translate(-50%, -50%);
  pointer-events: none;
  animation: ui-sch-pop 140ms ease both;
}
@keyframes ui-sch-drop {
  from {
    opacity: 0;
    transform: translateY(-6px) scale(0.96);
  }
}
@container ui-sch (max-width: 640px) {
  .ui-sch__body > .ui-sch__stack {
    height: auto;
    min-height: 0;
  }
  .ui-sch__stack > .ui-sch__cards {
    max-height: 320px;
  }
  .ui-sch__body {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-sch__cards {
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    column-gap: 4px;
  }
}
.ui-sch__bar {
  min-height: 48px;
  margin-bottom: 0;
  padding: 6px 8px 8px 12px;
}
.ui-sch__title {
  font-weight: 600;
}
.ui-sch__note {
  font-size: 12.5px;
}
.ui-sch__body {
  padding: 10px;
  border-radius: 16px;
  background: var(--ui-sch-card);
  box-shadow: var(--ui-sch-shadow);
}
.ui-sch__stack {
  border-radius: 12px;
}
.ui-sch__tile {
  border-radius: 10px;
}
.ui-sch__tile-title {
  font-size: 12px;
}
.ui-sch__tile-meta,
.ui-sch__tile-stats {
  font-size: 11.5px;
}
.ui-sch__mark {
  box-shadow: inset 0 0 0 1px var(--ui-sch-line);
}
.ui-sch__cell {
  border-radius: 12px;
  background: var(--ui-sch-well);
  box-shadow: inset 0 0 0 1px #f0f0f0;
}
.ui-sch__day {
  border-radius: 10px;
  background: var(--ui-sch-well);
  box-shadow: inset 0 0 0 1px #f0f0f0;
  font-size: 10.5px;
}
.ui-sch__tag {
  border-radius: 999px;
}
.ui-sch__modes {
  padding: 3px;
  border-radius: 10px;
  background: rgba(0, 0, 0, 0.06);
}
.ui-sch__modes > button {
  height: 26px;
  padding: 0 11px;
  border-radius: 7px;
  font-size: 13px !important;
}
.ui-sch__modes > button[aria-checked="true"] {
  box-shadow:
    0 0 0 1px #e4e4e4,
    0 1px 2px rgba(0, 0, 0, 0.06);
}
.ui-sch__count {
  border-radius: 999px;
}
.ui-sch__info {
  border-radius: 14px;
  box-shadow:
    0 0 0 1px #ececec,
    0 14px 32px -10px rgba(16, 16, 24, 0.22);
}
.ui-sch__why {
  border-radius: 999px;
}
@media (prefers-reduced-motion: reduce) {
  .ui-sch *,
  .ui-sch *::before,
  .ui-sch *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-sch {
  --ui-sch-tray: #141416;
  --ui-sch-card: #1c1c1f;
  --ui-sch-strong: #ffffff;
  --ui-sch-ink: rgba(255, 255, 255, 0.9);
  --ui-sch-text: rgba(255, 255, 255, 0.62);
  --ui-sch-muted: rgba(255, 255, 255, 0.45);
  --ui-sch-faint: rgba(255, 255, 255, 0.28);
  --ui-sch-line: rgba(255, 255, 255, 0.08);
  --ui-sch-lane: #161618;
  --ui-sch-well: rgba(255, 255, 255, 0.03);
  --ui-sch-edge: #2c2c31;
  --ui-sch-accent: #5b9aff;
  --ui-sch-focus: rgba(77, 141, 255, 0.8);
  --ui-sch-accent-bg: rgba(91, 154, 255, 0.1);
  --ui-sch-drop: rgba(91, 154, 255, 0.5);
  --ui-sch-hatch: rgba(255, 255, 255, 0.06);
  --ui-sch-meter: #55555c;
  --ui-sch-track: rgba(255, 255, 255, 0.06);
  --ui-sch-now: #ff6369;
  --ui-sch-track-2: rgba(255, 255, 255, 0.07);
  --ui-sch-amber: #fbbf24;
  --ui-sch-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-sch__count {
  background: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-sch__cell,
:where(.dark, [data-theme="dark"]) .ui-sch__day {
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-sch__modes {
  background: rgba(255, 255, 255, 0.07);
}
`;export{n as default};
