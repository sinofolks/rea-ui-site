const n=`/* Animatable custom properties: the equal segment width and the soft edges glide too */
@property --ui-seg-min {
  syntax: "<length>";
  inherits: true;
  initial-value: 0px;
}
@property --ui-seg-fade-l {
  syntax: "<length>";
  inherits: false;
  initial-value: 0px;
}
@property --ui-seg-fade-r {
  syntax: "<length>";
  inherits: false;
  initial-value: 0px;
}

.ui-seg {
  --ui-seg-tray: #f0f0f0;
  --ui-seg-pill: #ffffff;
  --ui-seg-line: #ececec;
  --ui-seg-ink: #171717;
  --ui-seg-text: #404040;
  --ui-seg-soft: #626873;
  --ui-seg-muted: #8f8f8f;
  --ui-seg-count: rgba(0, 0, 0, 0.06);
  --ui-seg-accent: #2a5ee5;
  --ui-seg-accent-soft: rgba(47, 107, 255, 0.1);
  --ui-seg-pill-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 1px 2px rgba(0, 0, 0, 0.08),
    0 2px 8px -2px rgba(0, 0, 0, 0.06);
  --ui-seg-focus: rgba(0, 96, 226, 0.7);
  --ui-seg-ease: cubic-bezier(0.22, 1, 0.36, 1);
  /* Size: md */
  --ui-seg-h: 30px;
  --ui-seg-px: 12px;
  --ui-seg-fs: 13.5px;
  --ui-seg-r: 11px;
  --ui-seg-pad: 3px;
  --ui-seg-icon: 15px;
  --ui-seg-gap: 20px;
  box-sizing: border-box;
  display: inline-flex;
  max-width: 100%;
  min-width: 0;
  vertical-align: middle;
  border-radius: var(--ui-seg-r);
  background: var(--ui-seg-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: var(--ui-seg-fs);
  line-height: 1;
  color: var(--ui-seg-soft);
  -webkit-font-smoothing: antialiased;
}
.ui-seg[data-size="sm"] {
  --ui-seg-h: 26px;
  --ui-seg-px: 10px;
  --ui-seg-fs: 12.5px;
  --ui-seg-r: 9px;
  --ui-seg-pad: 2px;
  --ui-seg-icon: 14px;
  --ui-seg-gap: 16px;
}
.ui-seg[data-size="lg"] {
  --ui-seg-h: 36px;
  --ui-seg-px: 16px;
  --ui-seg-fs: 14px;
  --ui-seg-r: 13px;
  --ui-seg-pad: 4px;
  --ui-seg-icon: 16px;
  --ui-seg-gap: 24px;
}
.ui-seg[data-full] {
  display: flex;
  width: 100%;
}
.ui-seg[data-disabled] {
  opacity: 0.5;
  pointer-events: none;
}
.ui-seg *,
.ui-seg *::before,
.ui-seg *::after {
  box-sizing: border-box;
}
:where(.ui-seg) button {
  margin: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-seg) svg {
  display: block;
  flex: none;
}

/* Scrolls sideways only when it doesn't fit; the padding keeps focus rings from being cut off */
.ui-seg__scroller {
  position: relative;
  flex: 1;
  min-width: 0;
  overflow-x: auto;
  overflow-y: hidden;
  padding: var(--ui-seg-pad);
  border-radius: inherit;
  overscroll-behavior-x: contain;
  scrollbar-width: none;
  -webkit-mask-image: linear-gradient(
    to right,
    transparent,
    #000 var(--ui-seg-fade-l),
    #000 calc(100% - var(--ui-seg-fade-r)),
    transparent
  );
  mask-image: linear-gradient(
    to right,
    transparent,
    #000 var(--ui-seg-fade-l),
    #000 calc(100% - var(--ui-seg-fade-r)),
    transparent
  );
  transition:
    --ui-seg-fade-l 200ms ease,
    --ui-seg-fade-r 200ms ease;
}
.ui-seg__scroller::-webkit-scrollbar {
  display: none;
}

.ui-seg__track {
  position: relative;
  display: flex;
  width: max-content;
  min-width: 100%;
  /* Horizontal drags move the pill; vertical ones still scroll the page */
  touch-action: pan-y;
  -webkit-user-select: none;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
}
/* When it scrolls, swipes scroll it instead of dragging the pill */
.ui-seg[data-overflow] .ui-seg__track {
  touch-action: pan-x pan-y;
}
/* Equal segments, each as wide as the widest one needs */
.ui-seg[data-full] .ui-seg__track {
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: minmax(var(--ui-seg-min), 1fr);
}
.ui-seg[data-ready] .ui-seg__track {
  transition: --ui-seg-min 320ms var(--ui-seg-ease);
}

/* An option */
.ui-seg__opt {
  position: relative;
  z-index: 1;
  display: flex;
  flex: none;
  align-items: center;
  justify-content: center;
  height: var(--ui-seg-h);
  padding: 0 var(--ui-seg-px);
  overflow: clip;
  border-radius: calc(var(--ui-seg-r) - var(--ui-seg-pad));
  white-space: nowrap;
  transition: color 200ms ease;
}
.ui-seg[data-ready]:not([data-full]) .ui-seg__opt {
  transition:
    color 200ms ease,
    width 320ms var(--ui-seg-ease);
}
.ui-seg__opt[data-active] {
  color: var(--ui-seg-ink);
}
.ui-seg__opt:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.ui-seg__opt:focus-visible {
  outline: 2px solid var(--ui-seg-focus);
  outline-offset: -2px;
}
@media (hover: hover) {
  .ui-seg__opt:not([data-active]):not(:disabled):hover {
    color: var(--ui-seg-text);
  }
}

.ui-seg__content {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
}
.ui-seg__icon {
  display: grid;
  place-items: center;
  width: var(--ui-seg-icon);
  height: var(--ui-seg-icon);
}
.ui-seg__icon svg,
.ui-seg__icon img {
  width: 100%;
  height: 100%;
}
/* Images fill the tile without leaving it, whatever their shape */
.ui-seg__icon {
  overflow: hidden;
}
.ui-seg__icon img {
  display: block;
  object-fit: contain;
}

/* Regular and semibold copies of the label crossfade */
.ui-seg__label {
  display: grid;
  justify-items: center;
}
.ui-seg__text {
  grid-area: 1 / 1;
  font-weight: 500;
  transition: opacity 200ms ease;
}
.ui-seg__text-bold {
  font-weight: 600;
  opacity: 0;
}
.ui-seg__opt[data-active] .ui-seg__text {
  opacity: 0;
}
.ui-seg__opt[data-active] .ui-seg__text-bold {
  opacity: 1;
}

.ui-seg__count {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  border-radius: 9px;
  background: var(--ui-seg-count);
  font-size: 11px;
  font-weight: 600;
  font-variant-numeric: tabular-nums;
  color: var(--ui-seg-text);
  animation: ui-seg-in 260ms var(--ui-seg-ease) both;
}
.ui-seg[data-size="sm"] .ui-seg__count {
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  font-size: 10.5px;
}
.ui-seg__badge {
  display: inline-flex;
  align-items: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 6px;
  background: var(--ui-seg-accent-soft);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-seg-accent);
}

/* The indicator: left and right edges glide separately – the one facing the target leads, so it stretches and settles */
.ui-seg__pill {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 100%;
  z-index: 0;
  border-radius: calc(var(--ui-seg-r) - var(--ui-seg-pad));
  background: var(--ui-seg-pill);
  box-shadow: var(--ui-seg-pill-shadow);
  opacity: 0;
  pointer-events: none;
  transition:
    left 380ms var(--ui-seg-ease),
    right 380ms var(--ui-seg-ease),
    scale 200ms var(--ui-seg-ease),
    opacity 160ms ease;
}
.ui-seg__pill[data-dir="right"] {
  transition-duration: 400ms, 270ms, 200ms, 160ms;
}
.ui-seg__pill[data-dir="left"] {
  transition-duration: 270ms, 400ms, 200ms, 160ms;
}
/* Press feedback: the pill gives a little while held or dragged */
.ui-seg[data-pressed]:not([data-variant="underline"]) .ui-seg__pill {
  scale: 0.97;
}

/* Underline variant: text tabs on a hairline */
.ui-seg[data-variant="underline"] {
  --ui-seg-px: 2px;
  border-radius: 0;
  background: none;
  box-shadow: inset 0 -1px 0 var(--ui-seg-line);
}
.ui-seg[data-variant="underline"] .ui-seg__scroller {
  padding: 0;
}
.ui-seg[data-variant="underline"]:not([data-full]) .ui-seg__track {
  gap: var(--ui-seg-gap);
}
.ui-seg[data-variant="underline"][data-full] {
  --ui-seg-px: 10px;
}
.ui-seg[data-variant="underline"] .ui-seg__opt {
  height: calc(var(--ui-seg-h) + 6px);
  border-radius: 6px;
}
.ui-seg[data-variant="underline"] .ui-seg__opt:focus-visible {
  outline-offset: -2px;
}
.ui-seg[data-variant="underline"] .ui-seg__pill {
  top: auto;
  height: 2px;
  border-radius: 2px 2px 0 0;
  background: var(--ui-seg-ink);
  box-shadow: none;
}

@keyframes ui-seg-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}

/* Touch screens: every option at least 40px tall */
@media (hover: none) and (pointer: coarse) {
  .ui-seg[data-size] {
    --ui-seg-h: 40px;
  }
  .ui-seg[data-size="lg"] {
    --ui-seg-h: 44px;
  }
  .ui-seg[data-variant="underline"] .ui-seg__opt {
    height: var(--ui-seg-h);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-seg *,
  .ui-seg *::before,
  .ui-seg *::after {
    animation: none !important;
    transition: none !important;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-seg {
  --ui-seg-tray: #111113;
  --ui-seg-pill: #26262a;
  --ui-seg-line: #2a2a2e;
  --ui-seg-ink: #ededed;
  --ui-seg-text: #c8c8cc;
  --ui-seg-soft: #8b8b92;
  --ui-seg-muted: #8b8b92;
  --ui-seg-count: rgba(255, 255, 255, 0.08);
  --ui-seg-accent: #6d8bff;
  --ui-seg-accent-soft: rgba(109, 139, 255, 0.14);
  --ui-seg-pill-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.06), 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-seg-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
