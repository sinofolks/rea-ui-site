const n=`.ui-shm,
.ui-shm-text {
  --ui-shm-base: #ececec;
  --ui-shm-glow: rgba(255, 255, 255, 0.9);
  --ui-shm-text: #a3a3a3;
  --ui-shm-text-glow: #ffffff;
  --ui-shm-dur: 2.2s;
}

/* Skeleton: one fixed gradient for the whole viewport, so all blocks sweep together */
.ui-shm {
  display: block;
  /* Fixed sizes keep their size in a row; a % width shrinks to the room that's left */
  flex: 0 1 auto;
  min-width: 0;
  width: 100%;
  height: 12px;
  max-width: 100%;
  border-radius: 6px;
  background-color: var(--ui-shm-base);
  background-image: linear-gradient(
    100deg,
    transparent 0%,
    transparent 30%,
    var(--ui-shm-glow) 50%,
    transparent 70%,
    transparent 100%
  );
  background-size: 150vw 100%;
  background-repeat: repeat-x;
  background-attachment: fixed;
  animation: ui-shm-sweep var(--ui-shm-dur) linear infinite;
}
@keyframes ui-shm-sweep {
  from {
    background-position: -50vw 0;
  }
  to {
    background-position: 100vw 0;
  }
}

/* Text: a highlight band runs through the letters */
.ui-shm-text {
  display: inline-block;
  color: var(--ui-shm-text);
  background-image: linear-gradient(
    90deg,
    var(--ui-shm-text) 0%,
    var(--ui-shm-text) 40%,
    var(--ui-shm-text-glow) 50%,
    var(--ui-shm-text) 60%,
    var(--ui-shm-text) 100%
  );
  background-size: 300% 100%;
  background-position: 100% 0;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ui-shm-text var(--ui-shm-text-dur, 2s) linear infinite;
}
@keyframes ui-shm-text {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-shm {
    animation: none;
    background-image: none;
  }
  .ui-shm-text {
    animation: none;
    background-image: none;
    -webkit-text-fill-color: currentColor;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-shm,
:where(.dark, [data-theme="dark"]) .ui-shm-text {
  --ui-shm-base: #2f2f33;
  --ui-shm-glow: rgba(255, 255, 255, 0.08);
  --ui-shm-text: #6e6e73;
  --ui-shm-text-glow: #f5f5f5;
}

.shimmer-loader-demo {
  -webkit-font-smoothing: antialiased;
  color: #171717;
  justify-items: center;
  gap: 14px;
  width: min(100%, 320px);
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    sans-serif;
  display: grid;
}
.shd-top {
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  width: 100%;
  padding: 0 2px;
  display: flex;
}
.shd-label {
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
}
.shd-btn {
  color: #171717;
  height: 30px;
  font: inherit;
  cursor: pointer;
  background: #fff;
  border: 0;
  border-radius: 9px;
  flex: none;
  margin: 0;
  padding: 0 12px;
  font-size: 12.5px;
  font-weight: 500;
  transition: background-color 0.15s;
  box-shadow: 0 0 0 1px #e5e5e5;
}
.shd-btn:hover {
  background: #f7f7f7;
}
.shd-btn:focus-visible {
  outline-offset: 2px;
  outline: 2px solid #2f6bff;
}
.shd-card {
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  gap: 14px;
  width: 100%;
  padding: 16px;
  display: grid;
  box-shadow: 0 1px 2px #0000000f;
}
.shd-loaded {
  gap: 14px;
  animation: 0.4s cubic-bezier(0.22, 1, 0.36, 1) both shd-in;
  display: grid;
}
@keyframes shd-in {
  0% {
    opacity: 0;
  }
}
.shd-row {
  align-items: center;
  gap: 10px;
  height: 36px;
  display: flex;
}
.shd-meta {
  gap: 6px;
  display: grid;
}
.shd-avatar {
  color: #fff;
  background: linear-gradient(135deg, #a5b4fc, #6366f1);
  border-radius: 50%;
  place-items: center;
  width: 36px;
  height: 36px;
  font-size: 12px;
  font-weight: 600;
  display: grid;
}
.shd-name {
  font-size: 13px;
  font-weight: 600;
  line-height: 14px;
}
.shd-sub {
  color: #8f8f8f;
  font-size: 11.5px;
  line-height: 12px;
}
.shd-lines {
  gap: 10px;
  padding: 4px 0;
  display: grid;
}
.shd-text {
  color: #404040;
  text-wrap: pretty;
  margin: 0;
  font-size: 13px;
  line-height: 18px;
}
.shd-tiles {
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
  display: grid;
}
.shd-tile {
  border-radius: 10px;
  height: 56px;
}
:where(.dark, [data-theme="dark"]) .shimmer-loader-demo {
  color: #ededed;
}
:where(.dark, [data-theme="dark"]) .shd-card {
  background: #232326;
  border-color: #ffffff14;
}
:where(.dark, [data-theme="dark"]) .shd-text {
  color: #c4c4c4;
}
:where(.dark, [data-theme="dark"]) .shd-btn {
  color: #ededed;
  background: #2c2c30;
  box-shadow: 0 0 0 1px #ffffff1a;
}
:where(.dark, [data-theme="dark"]) .shd-btn:hover {
  background: #343439;
}
:where(.dark, [data-theme="dark"]) .shd-tile {
  opacity: 0.85;
}
@media (prefers-reduced-motion: reduce) {
  .shd-loaded {
    animation: none;
  }
}
.card__preview .shimmer-loader-demo {
  zoom: 0.72;
}
`;export{n as default};
