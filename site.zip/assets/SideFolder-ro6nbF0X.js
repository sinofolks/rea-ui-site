const n=`.ui-sf {
  --ui-sf-ease: cubic-bezier(0.2, 0.85, 0.25, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  overflow: hidden;
  container-type: inline-size;
}

/* The folder is drawn on a 440 × 520 grid; cqw keeps every detail in proportion */
.ui-sf-icon {
  position: absolute;
  left: 50%;
  top: 50%;
  width: 37%;
  aspect-ratio: 440 / 520;
  container-type: inline-size;
  perspective: 260cqw;
  perspective-origin: 40% 50%;
  transform: translate(-50%, -50%);
  transition: transform 0.6s var(--ui-sf-ease);
}
.ui-sf-icon:hover {
  transform: translate(-50%, -50%) scale(1.03);
}

.ui-sf-layer {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
}
.ui-sf-back {
  filter: drop-shadow(0 5.4cqw 6.4cqw rgba(60, 130, 180, 0.28))
    drop-shadow(0 1.8cqw 2.7cqw rgba(60, 130, 180, 0.16))
    drop-shadow(0 0.45cqw 0.9cqw rgba(60, 130, 180, 0.1));
}

/* Documents, in the 1.15 scaled space of the stack */
.ui-sf-doc {
  transform-box: fill-box;
  transform-origin: center;
  filter: drop-shadow(0 3px 4px rgba(0, 30, 60, 0.18));
  transition: transform 0.55s var(--ui-sf-ease);
}
.ui-sf-doc--top {
  transform: translate(83px, 43px) rotate(3deg);
}
.ui-sf-doc--bottom {
  transform: translate(78px, 68px) rotate(4deg);
}
.ui-sf-doc--middle {
  transform: translate(73px, 56px) rotate(-2deg);
}
.ui-sf-icon:hover .ui-sf-doc--top {
  transform: translate(100px, 35px) rotate(6deg);
}
.ui-sf-icon:hover .ui-sf-doc--bottom {
  transform: translate(93px, 75px) rotate(7deg);
}
.ui-sf-icon:hover .ui-sf-doc--middle {
  transform: translate(95px, 54px) rotate(0deg);
}

/* Pocket: hinged on its left edge, it swings its right edge towards you on hover */
.ui-sf-front {
  position: absolute;
  left: 0;
  top: 0;
  width: 86.3636%;
  height: 100%;
  -webkit-mask: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%20380%20520'%20preserveAspectRatio%3D'none'%3E%3Cpath%20d%3D'M40%200H290Q330%200%20330%2040V318Q330%20338%20344%20348L364%20362Q380%20372%20380%20396V480Q380%20520%20340%20520H40Q0%20520%200%20480V40Q0%200%2040%200Z'%2F%3E%3C%2Fsvg%3E")
    0 0 / 100% 100% no-repeat;
  mask: url("data:image/svg+xml,%3Csvg%20xmlns%3D'http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg'%20viewBox%3D'0%200%20380%20520'%20preserveAspectRatio%3D'none'%3E%3Cpath%20d%3D'M40%200H290Q330%200%20330%2040V318Q330%20338%20344%20348L364%20362Q380%20372%20380%20396V480Q380%20520%20340%20520H40Q0%20520%200%20480V40Q0%200%2040%200Z'%2F%3E%3C%2Fsvg%3E")
    0 0 / 100% 100% no-repeat;
  background:
    linear-gradient(180deg, rgba(0, 40, 75, 0) 76%, rgba(0, 40, 75, 0.26) 100%),
    linear-gradient(
      160deg,
      rgba(132, 214, 248, 0.45) 0%,
      rgba(69, 170, 220, 0.45) 100%
    );
  -webkit-backdrop-filter: blur(4.5cqw) saturate(1.1);
  backdrop-filter: blur(4.5cqw) saturate(1.1);
  transform-origin: 0 50%;
  transition: transform 0.6s var(--ui-sf-ease);
}
.ui-sf-front svg {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  display: block;
}
.ui-sf-icon:hover .ui-sf-front {
  transform: translateZ(3cqw) rotateY(-12deg);
}

@media (prefers-reduced-motion: reduce) {
  .ui-sf-icon,
  .ui-sf-doc,
  .ui-sf-front {
    transition: none;
  }
}

.side-folder-demo {
  width: 100%;
}
.stage .side-folder-demo {
  width: min(100%, 560px);
}
.card__preview .side-folder-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .side-folder-demo .ui-sf {
  width: auto;
  height: 100%;
}
`;export{n as default};
