const n=`.ui-stp {
  --ui-stp-tray: #f0f0f0;
  --ui-stp-card: #ffffff;
  --ui-stp-line: #ececec;
  --ui-stp-ink: #171717;
  --ui-stp-text: #404040;
  --ui-stp-muted: #626873;
  --ui-stp-faint: #6b6b6b;
  --ui-stp-edge: #dcdcdf;
  --ui-stp-field: #ffffff;
  --ui-stp-hover: #f2f2f3;
  --ui-stp-chip: #f2f2f3;
  --ui-stp-track: #e2e2e5;
  --ui-stp-accent: #2f6bff;
  --ui-stp-accent-soft: rgba(47, 107, 255, 0.05);
  --ui-stp-danger: #bf383d;
  --ui-stp-on-ink: #ffffff;
  --ui-stp-focus: rgba(0, 96, 226, 0.7);
  --ui-stp-ring: rgba(23, 23, 23, 0.08);
  --ui-stp-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 520px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-stp-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.45;
  color: var(--ui-stp-text);
  -webkit-font-smoothing: antialiased;
}
.ui-stp *,
.ui-stp *::before,
.ui-stp *::after {
  box-sizing: border-box;
}
:where(.ui-stp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-stp) svg {
  display: block;
  flex: none;
}
:where(.ui-stp) :is(h2, p, dl, dd, ul, ol) {
  margin: 0;
}
.ui-stp button:focus-visible {
  outline: 2px solid var(--ui-stp-focus);
  outline-offset: 2px;
}
.ui-stp__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-stp__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-stp__draw {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-stp__draw path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-stp-draw 360ms var(--ui-stp-ease) 80ms forwards;
}
.ui-stp__head {
  padding: 6px 6px 4px;
}
.ui-stp__steps {
  position: relative;
}
.ui-stp__list {
  display: grid;
  grid-template-columns: repeat(var(--ui-stp-n), minmax(0, 1fr));
  padding: 0;
  list-style: none;
}
.ui-stp__step {
  position: relative;
  display: grid;
  justify-items: center;
  min-width: 0;
}
.ui-stp__step-btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  max-width: 100%;
  height: 26px;
  padding: 0 6px;
  border-radius: 8px;
  line-height: 1;
  cursor: default;
  transition: background-color 200ms ease;
}
button.ui-stp__step-btn {
  cursor: pointer;
}
button.ui-stp__step-btn:hover {
  background: var(--ui-stp-ring);
}
.ui-stp__mark {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: center;
  min-width: 14px;
  font-size: 12.5px;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  color: var(--ui-stp-faint);
  transition: color 260ms ease;
}
.ui-stp__mark > span {
  line-height: 1;
  animation: ui-stp-in 260ms var(--ui-stp-ease) both;
}
.ui-stp__mark .ui-stp__draw {
  width: 13px;
  height: 13px;
  stroke-width: 2.4;
}
.ui-stp__step[data-state="current"] .ui-stp__mark {
  color: var(--ui-stp-ink);
}
.ui-stp__step[data-state="done"] .ui-stp__mark {
  color: var(--ui-stp-ink);
}
.ui-stp__step-label {
  overflow: hidden;
  max-width: 100%;
  font-size: 12.5px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-stp-muted);
  transition: color 260ms ease;
}
.ui-stp__step[data-state="done"] .ui-stp__step-label {
  color: var(--ui-stp-text);
}
.ui-stp__step[data-state="current"] .ui-stp__step-label {
  color: var(--ui-stp-ink);
  font-weight: 500;
}
button.ui-stp__step-btn:hover .ui-stp__step-label {
  color: var(--ui-stp-ink);
}
.ui-stp__compact {
  display: none;
  gap: 8px;
  padding: 0 6px;
}
.ui-stp__compact-text {
  display: flex;
  align-items: baseline;
  min-width: 0;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-stp-muted);
  white-space: nowrap;
  animation: ui-stp-in 280ms var(--ui-stp-ease) both;
}
.ui-stp__compact-dot {
  margin: 0 6px;
  color: var(--ui-stp-faint);
}
.ui-stp__compact-title {
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--ui-stp-ink);
  font-weight: 500;
}
.ui-stp__card {
  display: grid;
  border-radius: 16px;
  background: var(--ui-stp-card);
  box-shadow:
    0 0 0 1px var(--ui-stp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-stp__viewport {
  position: relative;
  overflow: hidden;
  transition: height 380ms var(--ui-stp-ease);
}
.ui-stp__pane {
  padding: 20px 20px 8px;
  animation: ui-stp-enter 380ms var(--ui-stp-ease) both;
}
.ui-stp__pane[data-dir="-1"] {
  animation-name: ui-stp-enter-back;
}
.ui-stp__pane[data-first] {
  animation: none;
}
.ui-stp__pane[data-pane="leaving"] {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  pointer-events: none;
  animation: ui-stp-leave 300ms var(--ui-stp-ease) both;
}
.ui-stp__pane[data-pane="leaving"][data-dir="-1"] {
  animation-name: ui-stp-leave-back;
}
.ui-stp__heading {
  font-size: 16px;
  font-weight: 600;
  line-height: 1.3;
  letter-spacing: -0.01em;
  color: var(--ui-stp-ink);
  outline: none;
  overflow-wrap: anywhere;
}
.ui-stp__desc {
  margin-top: 4px;
  color: var(--ui-stp-muted);
  text-wrap: pretty;
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-stp__body {
  display: grid;
  gap: 14px;
  margin-top: 18px;
}
.ui-stp__field {
  display: grid;
  min-width: 0;
}
.ui-stp__label {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 8px;
  margin-bottom: 6px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-stp-ink);
}
.ui-stp__label-text {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-stp__optional {
  font-weight: 400;
  color: var(--ui-stp-muted);
}
.ui-stp__control {
  min-width: 0;
}
.ui-stp__input,
.ui-stp__tags {
  display: flex;
  align-items: center;
  min-width: 0;
  min-height: 38px;
  border-radius: 10px;
  background: var(--ui-stp-field);
  box-shadow:
    inset 0 0 0 1px var(--ui-stp-edge),
    0 1px 2px rgba(0, 0, 0, 0.03);
  transition: box-shadow 180ms ease;
  cursor: text;
}
.ui-stp__input:hover,
.ui-stp__tags:hover {
  box-shadow:
    inset 0 0 0 1px var(--ui-stp-faint),
    0 1px 2px rgba(0, 0, 0, 0.03);
}
.ui-stp__input:focus-within,
.ui-stp__tags:focus-within {
  box-shadow:
    inset 0 0 0 1px color-mix(in srgb, var(--ui-stp-muted) 70%, transparent),
    0 1px 2px rgba(0, 0, 0, 0.03);
}
.ui-stp__input[data-invalid],
.ui-stp__tags[data-invalid] {
  box-shadow: inset 0 0 0 1px var(--ui-stp-danger);
}
.ui-stp__input[data-invalid]:focus-within,
.ui-stp__tags[data-invalid]:focus-within {
  box-shadow: inset 0 0 0 1px var(--ui-stp-danger);
}
.ui-stp__input input,
.ui-stp__tags-input {
  flex: 1;
  min-width: 0;
  height: 36px;
  padding: 0 12px;
  border: 0;
  outline: none;
  background: none;
  font: inherit;
  font-size: 14px;
  color: var(--ui-stp-ink);
}
.ui-stp__input input::placeholder,
.ui-stp__tags-input::placeholder {
  color: var(--ui-stp-faint);
}
.ui-stp__prefix {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  overflow: hidden;
  padding-left: 12px;
  font-size: 14px;
  color: var(--ui-stp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  user-select: none;
}
.ui-stp__prefix + input {
  padding-left: 1px;
}
.ui-stp__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 260ms var(--ui-stp-ease),
    opacity 200ms ease;
}
.ui-stp__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-stp__fold > div {
  min-height: 0;
  overflow: hidden;
}
.ui-stp__msg,
.ui-stp__hint {
  padding-top: 6px;
  font-size: 12.5px;
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-stp__msg {
  color: var(--ui-stp-danger);
  animation: ui-stp-in 240ms var(--ui-stp-ease) both;
}
.ui-stp__hint {
  color: var(--ui-stp-muted);
}
.ui-stp__tags {
  flex-wrap: wrap;
  gap: 6px;
  padding: 5px;
}
.ui-stp__chips {
  display: contents;
  padding: 0;
  list-style: none;
}
.ui-stp__chip {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  min-width: 0;
  max-width: 100%;
  height: 28px;
  padding: 0 2px 0 10px;
  overflow: hidden;
  border-radius: 8px;
  background: var(--ui-stp-chip);
  font-size: 13px;
  color: var(--ui-stp-ink);
  white-space: nowrap;
  animation: ui-stp-chip 300ms var(--ui-stp-ease) both;
}
.ui-stp__chip[data-leaving] {
  pointer-events: none;
}
.ui-stp__chip-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-stp__chip-x {
  display: grid;
  place-items: center;
  flex: none;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--ui-stp-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-stp__chip-x .ui-stp__glyph {
  width: 13px;
  height: 13px;
}
.ui-stp__chip-x:hover {
  background: var(--ui-stp-track);
  color: var(--ui-stp-ink);
}
.ui-stp__chip[data-leaving] .ui-stp__chip-x {
  background: none;
}
.ui-stp__tags-input {
  flex: 1 1 140px;
  height: 28px;
  padding: 0 7px;
}
.ui-stp__choices {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, 1fr);
  grid-auto-flow: column;
  gap: 8px;
}
.ui-stp__ring {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  border-radius: 12px;
  box-shadow:
    inset 0 0 0 1.5px var(--ui-stp-accent),
    0 0 0 3px rgba(47, 107, 255, 0.1);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 380ms var(--ui-stp-ease),
    width 380ms var(--ui-stp-ease),
    height 380ms var(--ui-stp-ease),
    opacity 200ms ease;
}
.ui-stp__choice {
  position: relative;
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 12px;
  border-radius: 12px;
  background: var(--ui-stp-field);
  box-shadow: inset 0 0 0 1px var(--ui-stp-edge);
  text-align: left;
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease;
}
.ui-stp__choice:hover {
  box-shadow: inset 0 0 0 1px var(--ui-stp-faint);
}
.ui-stp__choice[aria-checked="true"] {
  background: var(--ui-stp-accent-soft);
  box-shadow: inset 0 0 0 1px transparent;
}
.ui-stp__choice:focus-visible {
  outline-offset: 2px;
}
.ui-stp__choice-top {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 2px 6px;
  min-width: 0;
}
.ui-stp__choice-title {
  min-width: min(100%, 72px);
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-stp-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-stp__badge {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 1px 6px;
  border-radius: 6px;
  background: var(--ui-stp-chip);
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-stp-text);
}
.ui-stp__radio {
  position: relative;
  flex: none;
  width: 16px;
  height: 16px;
  margin-left: auto;
  border-radius: 50%;
  box-shadow: inset 0 0 0 1.5px var(--ui-stp-edge);
  transition: box-shadow 220ms ease;
}
.ui-stp__radio::after {
  content: "";
  position: absolute;
  inset: 4px;
  border-radius: 50%;
  background: var(--ui-stp-accent);
  transform: scale(0);
  transition: transform 300ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-stp__choice[aria-checked="true"] .ui-stp__radio {
  box-shadow: inset 0 0 0 1.5px var(--ui-stp-accent);
}
.ui-stp__choice[aria-checked="true"] .ui-stp__radio::after {
  transform: scale(1);
}
.ui-stp__choice-aside {
  font-size: 13px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-stp-ink);
}
.ui-stp__choice-desc {
  margin-top: 4px;
  font-size: 12px;
  line-height: 1.4;
  color: var(--ui-stp-muted);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-stp__review {
  display: grid;
  border-radius: 12px;
  box-shadow: inset 0 0 0 1px var(--ui-stp-line);
}
.ui-stp__review-row {
  display: grid;
  grid-template-columns: 96px minmax(0, 1fr) auto;
  align-items: baseline;
  gap: 12px;
  padding: 11px 8px 11px 14px;
}
.ui-stp__review-row + .ui-stp__review-row {
  border-top: 1px solid var(--ui-stp-line);
}
.ui-stp__review dt {
  min-width: 0;
  font-size: 12.5px;
  color: var(--ui-stp-muted);
  overflow-wrap: anywhere;
}
.ui-stp__review dd {
  min-width: 0;
  color: var(--ui-stp-ink);
  overflow-wrap: anywhere;
}
.ui-stp__edit {
  height: 26px;
  margin: -4px 0;
  padding: 0 8px;
  border-radius: 7px;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-stp-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-stp__edit:hover {
  background: var(--ui-stp-hover);
  color: var(--ui-stp-ink);
}
.ui-stp__success {
  display: grid;
  justify-items: center;
  padding: 20px 0 14px;
  text-align: center;
}
.ui-stp__success-check {
  display: grid;
  place-items: center;
  width: 44px;
  height: 44px;
  margin-bottom: 14px;
  border-radius: 50%;
  background: var(--ui-stp-ink);
  color: var(--ui-stp-on-ink);
  box-shadow: 0 0 0 6px var(--ui-stp-ring);
  animation: ui-stp-pop 520ms cubic-bezier(0.34, 1.56, 0.64, 1) 120ms both;
}
.ui-stp__success-check .ui-stp__draw {
  width: 20px;
  height: 20px;
}
.ui-stp__success-check .ui-stp__draw path {
  animation-delay: 320ms;
}
.ui-stp__success .ui-stp__heading {
  animation: ui-stp-in 340ms var(--ui-stp-ease) 220ms both;
}
.ui-stp__success .ui-stp__desc {
  max-width: 40ch;
  text-wrap: balance;
  animation: ui-stp-in 340ms var(--ui-stp-ease) 290ms both;
}
.ui-stp__success-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px;
  margin-top: 16px;
  animation: ui-stp-in 340ms var(--ui-stp-ease) 360ms both;
}
.ui-stp__foot-fold {
  position: sticky;
  bottom: 0;
  z-index: 3;
  display: grid;
  grid-template-rows: 1fr;
  border-radius: 0 0 16px 16px;
  background: var(--ui-stp-card);
  transition:
    grid-template-rows 360ms var(--ui-stp-ease),
    opacity 220ms ease;
}
.ui-stp__foot-fold[data-hidden] {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-stp__foot {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 0;
  overflow: hidden;
  padding: 12px 16px 16px;
}
.ui-stp__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  height: 36px;
  border-radius: 10px;
  font-weight: 500;
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    opacity 200ms ease,
    transform 140ms ease,
    width 320ms var(--ui-stp-ease),
    visibility 200ms;
}
.ui-stp__btn-ghost {
  gap: 4px;
  padding: 0 12px 0 8px;
  color: var(--ui-stp-text);
}
.ui-stp__btn-ghost:hover {
  background: var(--ui-stp-hover);
  color: var(--ui-stp-ink);
}
.ui-stp__btn-ghost[data-hidden] {
  opacity: 0;
  visibility: hidden;
}
.ui-stp__btn-primary {
  margin-left: auto;
  overflow: hidden;
  background: var(--ui-stp-ink);
  color: var(--ui-stp-on-ink);
}
.ui-stp__btn-primary:hover {
  opacity: 0.88;
}
.ui-stp__btn-primary:active {
  transform: scale(0.97);
}
.ui-stp__btn-primary[aria-disabled="true"] {
  opacity: 0.4;
}
.ui-stp__btn-primary[data-busy] {
  opacity: 0.75;
  cursor: progress;
}
.ui-stp__btn-inner {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  max-width: calc(100cqw - 120px);
  padding: 0 15px;
}
.ui-stp__btn-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-stp-in 260ms var(--ui-stp-ease) both;
}
.ui-stp__btn-secondary {
  padding: 0 14px;
  color: var(--ui-stp-text);
  box-shadow: inset 0 0 0 1px var(--ui-stp-edge);
}
.ui-stp__btn-secondary:hover {
  background: var(--ui-stp-hover);
  color: var(--ui-stp-ink);
}
.ui-stp__spinner {
  width: 13px;
  height: 13px;
  border-radius: 50%;
  border: 1.8px solid currentColor;
  border-right-color: transparent;
  animation: ui-stp-spin 700ms linear infinite;
}
.ui-stp__submit-error {
  flex: 1 1 auto;
  min-width: 0;
  overflow-wrap: anywhere;
  font-size: 12.5px;
  color: var(--ui-stp-danger);
  animation: ui-stp-in 240ms var(--ui-stp-ease) both;
}
@keyframes ui-stp-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-stp-enter {
  from {
    opacity: 0;
    transform: translateX(28px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stp-enter-back {
  from {
    opacity: 0;
    transform: translateX(-28px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stp-leave {
  to {
    opacity: 0;
    transform: translateX(-28px);
  }
}
@keyframes ui-stp-leave-back {
  to {
    opacity: 0;
    transform: translateX(28px);
  }
}
@keyframes ui-stp-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-stp-pop {
  0% {
    opacity: 0;
    transform: scale(0.4);
  }
  60% {
    opacity: 1;
    transform: scale(1.08);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes ui-stp-chip {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stp-spin {
  to {
    transform: rotate(360deg);
  }
}
@container (max-width: 420px) {
  .ui-stp__head {
    padding: 12px 8px 12px;
  }
  .ui-stp__steps {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
  }
  .ui-stp__compact {
    display: grid;
  }
  .ui-stp__pane {
    padding: 18px 16px 6px;
  }
  .ui-stp__foot {
    padding: 12px 12px 12px;
  }
  .ui-stp__btn {
    height: 40px;
  }
  .ui-stp__choices {
    grid-template-columns: minmax(0, 1fr);
    grid-auto-flow: row;
  }
  .ui-stp__choice {
    grid-template-columns: minmax(0, 1fr) auto;
    column-gap: 10px;
  }
  .ui-stp__choice-top {
    grid-column: 1;
  }
  .ui-stp__choice-aside {
    grid-column: 2;
    grid-row: 1;
    align-self: center;
  }
  .ui-stp__choice-desc {
    grid-column: 1 / -1;
    margin-top: 2px;
  }
  .ui-stp__radio {
    order: -1;
    margin-left: 0;
    margin-right: 2px;
  }
  .ui-stp__review-row {
    grid-template-columns: minmax(0, 1fr) auto;
    row-gap: 2px;
    padding-left: 12px;
  }
  .ui-stp__review dt {
    grid-column: 1;
  }
  .ui-stp__review dd {
    grid-column: 1;
    grid-row: 2;
  }
  .ui-stp__edit {
    grid-column: 2;
    grid-row: 1 / span 2;
    align-self: center;
    margin: 0;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-stp__input input,
  .ui-stp__tags-input,
  .ui-stp__prefix {
    font-size: 16px;
  }
  .ui-stp__input,
  .ui-stp__tags {
    min-height: 44px;
  }
  .ui-stp__input input {
    height: 42px;
  }
  .ui-stp__chip {
    height: 32px;
  }
  .ui-stp__chip-x {
    width: 30px;
    height: 30px;
  }
  .ui-stp__btn {
    height: 42px;
  }
  .ui-stp__edit {
    height: 36px;
    padding: 0 12px;
  }
  .ui-stp__step-btn {
    padding: 4px;
    margin: -4px 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-stp *,
  .ui-stp *::before,
  .ui-stp *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-stp {
  --ui-stp-tray: #111113;
  --ui-stp-card: #19191b;
  --ui-stp-line: #2a2a2e;
  --ui-stp-ink: #ededed;
  --ui-stp-text: #c8c8cc;
  --ui-stp-muted: #8b8b92;
  --ui-stp-faint: #5c5c63;
  --ui-stp-edge: #34343a;
  --ui-stp-field: #1d1d20;
  --ui-stp-hover: #232326;
  --ui-stp-chip: #2a2a2e;
  --ui-stp-track: #2e2e33;
  --ui-stp-accent: #6d8bff;
  --ui-stp-accent-soft: rgba(109, 139, 255, 0.08);
  --ui-stp-danger: #ff6369;
  --ui-stp-on-ink: #111113;
  --ui-stp-focus: rgba(77, 141, 255, 0.8);
  --ui-stp-ring: rgba(255, 255, 255, 0.08);
}
`;export{n as default};
