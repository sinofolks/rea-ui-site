const n=`.ui-to {
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  overflow: hidden;
  /* Fade out towards the right and bottom edge */
  -webkit-mask-image:
    linear-gradient(to right, #000 70%, transparent 100%),
    linear-gradient(to bottom, #000 70%, transparent 100%);
  -webkit-mask-composite: source-in;
  mask-image:
    linear-gradient(to right, #000 70%, transparent 100%),
    linear-gradient(to bottom, #000 70%, transparent 100%);
  mask-composite: intersect;
}
.ui-to-art {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
}

/* Placeholder blocks shimmer softly */
.ui-to-bar {
  animation: ui-to-shimmer 2.4s ease-in-out infinite;
}
@keyframes ui-to-shimmer {
  0%,
  100% {
    fill: #eff1f4;
  }
  50% {
    fill: #dde1e5;
  }
}

/* The highlight follows the hovered window; the front window is active by default */
.ui-to-blobs,
.ui-to-front {
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.3s ease;
}
.ui-to-content {
  opacity: 0.2;
  pointer-events: none;
  transition: opacity 0.3s ease;
}
.ui-to-blobs-3,
.ui-to-front-3,
.ui-to-content-3 {
  opacity: 1;
}

.ui-to-art:has(.ui-to-tab-1:hover) .ui-to-blobs-1,
.ui-to-art:has(.ui-to-tab-1:hover) .ui-to-front-1,
.ui-to-art:has(.ui-to-tab-1:hover) .ui-to-content-1,
.ui-to-art:has(.ui-to-tab-2:hover) .ui-to-blobs-2,
.ui-to-art:has(.ui-to-tab-2:hover) .ui-to-front-2,
.ui-to-art:has(.ui-to-tab-2:hover) .ui-to-content-2 {
  opacity: 1;
}

.ui-to-art:has(.ui-to-tab-1:hover, .ui-to-tab-2:hover) .ui-to-blobs-3,
.ui-to-art:has(.ui-to-tab-1:hover, .ui-to-tab-2:hover) .ui-to-front-3 {
  opacity: 0;
}
.ui-to-art:has(.ui-to-tab-1:hover, .ui-to-tab-2:hover) .ui-to-content-3 {
  opacity: 0.2;
}

@media (prefers-reduced-motion: reduce) {
  .ui-to-bar {
    animation: none;
  }
  .ui-to-blobs,
  .ui-to-front,
  .ui-to-content {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-to-frame {
  fill: #1b1b1d;
  stroke: rgba(255, 255, 255, 0.1);
}
:where(.dark, [data-theme="dark"]) .ui-to-dot {
  fill: #3a3a3f;
}
:where(.dark, [data-theme="dark"]) .ui-to-page {
  fill: #232326;
  stroke: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-to-bar {
  fill: #2e2e32;
}
@media (prefers-reduced-motion: no-preference) {
  :where(.dark, [data-theme="dark"]) .ui-to-bar {
    animation-name: ui-to-shimmer-dark;
  }
}
@keyframes ui-to-shimmer-dark {
  0%,
  100% {
    fill: #2e2e32;
  }
  50% {
    fill: #3a3a3f;
  }
}

.tab-overload-demo {
  width: 100%;
}
.stage .tab-overload-demo {
  width: min(100%, 560px);
}
.card__preview .tab-overload-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .tab-overload-demo .ui-to {
  width: auto;
  height: 100%;
}
`;export{n as default};
