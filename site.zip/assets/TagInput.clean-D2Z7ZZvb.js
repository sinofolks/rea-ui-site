const n=`/* Colors and motion as variables – override them on .ui-tagc (see Theming in the docs) */
.ui-tagc {
  --ui-tagc-title: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tagc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tagc-muted: var(--aui-muted, rgba(0, 0, 0, 0.65));
  --ui-tagc-subtle: var(--aui-muted, rgba(0, 0, 0, 0.65));
  --ui-tagc-faint: var(--aui-placeholder, rgba(0, 0, 0, 0.65));
  --ui-tagc-surface: var(--aui-surface, #ffffff);
  --ui-tagc-chip: rgba(0, 0, 0, 0.045);
  --ui-tagc-chip-edge: rgba(0, 0, 0, 0.06);
  --ui-tagc-chip-armed: rgba(0, 0, 0, 0.1);
  --ui-tagc-avatar: rgba(0, 0, 0, 0.08);
  --ui-tagc-flash: rgba(0, 96, 226, 0.14);
  --ui-tagc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.08)),
    0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tagc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.13)),
    0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tagc-shadow-focus:
    0 0 0 1px var(--aui-border-strong, rgba(0, 0, 0, 0.28)),
    0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tagc-danger: var(--aui-danger, #c13338);
  --ui-tagc-danger-edge: rgba(229, 72, 77, 0.55);
  --ui-tagc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-tagc-ease: cubic-bezier(0.22, 1, 0.36, 1);

  --fs: 13px;

  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  font-family: var(
    --aui-font,
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif
  );
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-tagc-ink);
  -webkit-font-smoothing: antialiased;
}
@media (pointer: coarse) {
  .ui-tagc {
    --fs: 16px;
  }
}

.ui-tagc__head {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.ui-tagc__label {
  min-width: 0;
  font-weight: 500;
  color: var(--ui-tagc-title);
  overflow-wrap: anywhere;
  cursor: default;
}
.ui-tagc__optional {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tagc-subtle);
}

/* The box: the Text Field's look; chips wrap onto new lines and it grows with them */
.ui-tagc__box {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px;
  box-sizing: border-box;
  min-height: 32px;
  min-width: 0;
  max-height: 156px;
  padding: 3px 4px;
  border-radius: var(--aui-radius, 7px);
  background: var(--ui-tagc-surface);
  box-shadow: var(--ui-tagc-shadow);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  cursor: text;
  transition: box-shadow 140ms ease;
}
.ui-tagc__box:hover {
  box-shadow: var(--ui-tagc-shadow-hover);
}
.ui-tagc__box:focus-within {
  box-shadow: var(--ui-tagc-shadow-focus);
}
.ui-tagc[data-invalid] .ui-tagc__box {
  box-shadow:
    0 0 0 1px var(--ui-tagc-danger-edge),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
}
.ui-tagc[data-disabled] {
  opacity: 0.55;
}
.ui-tagc[data-disabled] .ui-tagc__box {
  cursor: not-allowed;
}

/* A chip: a soft gray pill with the text and a small × */
.ui-tagc__chip {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  max-width: 100%;
  height: 24px;
  box-sizing: border-box;
  padding: 0 3px 0 8px;
  border-radius: 5px;
  background: var(--ui-tagc-chip);
  box-shadow: inset 0 0 0 0.5px var(--ui-tagc-chip-edge);
  font-size: 12.5px;
  color: var(--ui-tagc-ink);
  outline: none;
  animation: ui-tagc-in 220ms var(--ui-tagc-ease) both;
  transition: background-color 140ms ease;
}
.ui-tagc__chip:has(.ui-tagc__avatar) {
  padding-left: 3px;
}
.ui-tagc__chip:focus-visible {
  outline: 2px solid var(--ui-tagc-focus);
  outline-offset: 2px;
}
.ui-tagc__chip[data-armed] {
  background: var(--ui-tagc-chip-armed);
}
.ui-tagc__chip[data-flash] {
  animation: ui-tagc-flash 700ms ease;
}
.ui-tagc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--ui-tagc-avatar);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-tagc-muted);
}
.ui-tagc__text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tagc__remove {
  position: relative;
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 4px;
  background: transparent;
  color: var(--ui-tagc-subtle);
  cursor: pointer;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-tagc__remove::before {
  content: "";
  position: absolute;
  inset: -4px;
}
.ui-tagc__remove:hover {
  background: var(--ui-tagc-chip-armed);
  color: var(--ui-tagc-ink);
}
.ui-tagc__remove svg {
  display: block;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
}

.ui-tagc__input {
  flex: 1 0 80px;
  min-width: 80px;
  height: 24px;
  margin: 0;
  padding: 0 6px;
  border: 0;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: var(--fs);
  color: var(--ui-tagc-ink);
}
.ui-tagc__input::placeholder {
  color: var(--ui-tagc-faint);
  opacity: 1;
}
.ui-tagc__input:disabled {
  cursor: not-allowed;
}

.ui-tagc__foot {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  min-width: 0;
}
.ui-tagc__message {
  flex: 1;
  min-width: 0;
  margin: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tagc-subtle);
  overflow-wrap: anywhere;
  animation: ui-tagc-message 260ms var(--ui-tagc-ease);
}
.ui-tagc[data-invalid] .ui-tagc__message {
  color: var(--ui-tagc-danger);
}
.ui-tagc__count {
  flex: none;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-tagc-faint);
}
.ui-tagc__count[data-full] {
  color: var(--ui-tagc-muted);
}
.ui-tagc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}

/* Touch screens: taller chips and a bigger × */
@media (pointer: coarse) {
  .ui-tagc__box {
    min-height: 40px;
  }
  .ui-tagc__chip {
    height: 30px;
    font-size: 14px;
  }
  .ui-tagc__remove {
    width: 24px;
    height: 24px;
  }
  .ui-tagc__input {
    height: 30px;
  }
}

@keyframes ui-tagc-in {
  from {
    opacity: 0;
    transform: scale(0.85);
    filter: blur(2px);
  }
}
@keyframes ui-tagc-flash {
  20%,
  60% {
    background: var(--ui-tagc-flash);
  }
}
@keyframes ui-tagc-message {
  from {
    opacity: 0;
    transform: translateY(-3px);
    filter: blur(2px);
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-tagc * {
    animation-duration: 1ms !important;
    transition-duration: 1ms !important;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-tagc {
  --ui-tagc-title: var(--aui-ink, rgba(255, 255, 255, 0.92));
  --ui-tagc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-tagc-muted: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-tagc-subtle: var(--aui-muted, rgba(255, 255, 255, 0.46));
  --ui-tagc-faint: var(--aui-placeholder, rgba(255, 255, 255, 0.3));
  --ui-tagc-surface: var(--aui-surface, #1c1c1e);
  --ui-tagc-chip: rgba(255, 255, 255, 0.07);
  --ui-tagc-chip-edge: rgba(255, 255, 255, 0.08);
  --ui-tagc-chip-armed: rgba(255, 255, 255, 0.14);
  --ui-tagc-avatar: rgba(255, 255, 255, 0.12);
  --ui-tagc-flash: rgba(77, 141, 255, 0.28);
  --ui-tagc-shadow:
    0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.14)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tagc-shadow-hover:
    0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.2)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tagc-shadow-focus:
    0 0 0 1px var(--aui-border-strong, rgba(255, 255, 255, 0.3)),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tagc-danger: var(--aui-danger, #ff6369);
  --ui-tagc-danger-edge: rgba(255, 99, 105, 0.5);
  --ui-tagc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
`;export{n as default};
