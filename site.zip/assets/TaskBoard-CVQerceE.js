const n=`.ui-bc {
  --ui-bc-tray: #f0f0f0;
  --ui-bc-card: #ffffff;
  --ui-bc-line: #ececec;
  --ui-bc-grid: #ebebeb;
  --ui-bc-ink: #171717;
  --ui-bc-text: #404040;
  --ui-bc-muted: #8f8f8f;
  --ui-bc-accent: #4fb0fe;
  --ui-bc-accent-ink: #4fb0fe;
  --ui-bc-border: #e5e5e5;
  --ui-bc-surface-hover: #f8f8f8;
  --ui-bc-option-hover: #f5f5f5;
  --ui-bc-zero: #dcdcdc;
  --ui-bc-rest: #f2f2f2;
  --ui-bc-head-bg: #fcfcfc;
  --ui-bc-row-active: #f6f6f6;
  --ui-bc-wash: rgba(0, 0, 0, 0.05);
  --ui-bc-accent-wash: rgba(1, 144, 254, 0.08);
  --ui-bc-focus: rgba(0, 96, 226, 0.7);
  --ui-bc-card-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-bc-btn-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-bc-pop-shadow: 0 10px 28px -8px rgba(0, 0, 0, 0.18);
  --ui-bc-tip-shadow: 0 10px 26px -8px rgba(0, 0, 0, 0.18);
  --ui-bc-pill-shadow: 0 2px 6px rgba(0, 0, 0, 0.06);
  --ui-bc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 560px;
  background: var(--ui-bc-tray);
  padding: 6px;
  border-radius: 22px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-bc-ink);
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
}
.ui-bc *,
.ui-bc *::before,
.ui-bc *::after {
  box-sizing: border-box;
}
.ui-bc button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-bc button:focus-visible {
  outline: 2px solid var(--ui-bc-focus);
  outline-offset: 2px;
}
.ui-bc__head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 2px 12px;
  padding: 11px 18px 10px;
  font-size: 14px;
  line-height: 20px;
}
.ui-bc__title {
  flex: 1 1 0;
  min-width: min(120px, 100%);
  overflow: hidden;
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__total {
  flex: none;
  max-width: 100%;
  color: var(--ui-bc-muted);
}
.ui-bc__total strong {
  white-space: nowrap;
  font-size: 15px;
  font-weight: 600;
  color: var(--ui-bc-ink);
}
.ui-bc__card {
  overflow: hidden;
  background: var(--ui-bc-card);
  border: 1px solid var(--ui-bc-border);
  border-radius: 16px;
  box-shadow: var(--ui-bc-card-shadow);
}
.ui-bc__controls {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 10px;
  padding: 16px 18px 4px;
}
.ui-bc__select {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
  min-width: 0;
}
.ui-bc__select-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bc-muted);
}
.ui-bc__select-btn {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 34px;
  padding: 0 10px 0 12px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-btn-shadow);
  font-size: 13px !important;
  font-weight: 500;
  text-align: left;
  transition: background-color 140ms ease;
}
.ui-bc__select-btn span {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__select-btn svg {
  flex: none;
  color: var(--ui-bc-muted);
  transition: transform 200ms var(--ui-bc-ease);
}
.ui-bc__select-btn[aria-expanded="true"] svg {
  transform: rotate(180deg);
}
.ui-bc__select-btn:hover {
  background: var(--ui-bc-surface-hover);
}
.ui-bc__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 6;
  display: grid;
  gap: 2px;
  padding: 4px;
  border-radius: 12px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-pop-shadow);
  animation: ui-bc-drop 180ms var(--ui-bc-ease);
}
.ui-bc__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 13px !important;
  text-align: left;
}
.ui-bc__option {
  gap: 8px;
}
.ui-bc__option span {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__option svg {
  flex: none;
}
.ui-bc__option:hover,
.ui-bc__option:focus-visible {
  background: var(--ui-bc-option-hover);
  outline: none;
}
.ui-bc__option[aria-selected="true"] {
  color: var(--ui-bc-accent-ink) !important;
  font-weight: 500;
}
.ui-bc__chart {
  padding: 22px 18px 12px;
}
.ui-bc__plot {
  position: relative;
  height: 200px;
  margin-right: 30px;
}
.ui-bc__grid {
  position: absolute;
  left: 0;
  right: 0;
  height: 0;
  border-top: 1px dashed var(--ui-bc-grid);
}
.ui-bc__grid[data-zero] {
  border-top-style: solid;
  border-color: var(--ui-bc-zero);
}
.ui-bc__tick {
  position: absolute;
  right: -30px;
  top: -8px;
  width: 26px;
  font-size: 11px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-bc-muted);
}
.ui-bc__bars {
  position: absolute;
  inset: 0;
  display: grid;
  gap: 4px;
}
.ui-bc__col {
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  height: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  transition: opacity 200ms ease;
}
.ui-bc__col:focus-visible {
  outline-offset: 2px;
}
.ui-bc__col[data-dim] {
  opacity: 0.38;
}
.ui-bc__rest {
  position: absolute;
  top: 0;
  left: 50%;
  width: min(10px, 100%);
  transform: translateX(-50%);
  background: var(--ui-bc-rest);
  opacity: 0;
  transition:
    opacity 180ms ease,
    bottom 520ms var(--ui-bc-ease);
}
.ui-bc__col[data-active] .ui-bc__rest {
  opacity: 1;
}
.ui-bc__bar {
  position: relative;
  display: flex;
  flex-direction: column-reverse;
  gap: 1px;
  width: min(10px, 100%);
  min-height: 0;
  overflow: hidden;
  transition: height 520ms var(--ui-bc-ease);
}
.ui-bc__seg {
  flex-basis: 0;
  min-height: 2px;
  transition:
    flex-grow 520ms var(--ui-bc-ease),
    background-color 300ms ease;
}
.ui-bc__tooltip {
  position: absolute;
  z-index: 4;
  min-width: 150px;
  padding: 9px 11px 10px;
  border-radius: 12px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-tip-shadow);
  top: 0;
  pointer-events: none;
  max-width: min(260px, 100%);
  transition: left 200ms var(--ui-bc-ease);
  animation: ui-bc-pop 160ms var(--ui-bc-ease);
}
.ui-bc__tip-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
}
.ui-bc__tip-head > strong {
  flex: none;
}
.ui-bc__tip-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-bc__tip-label > span,
.ui-bc__tip-seg,
.ui-bc__pill > span,
.ui-bc__row-label > span,
.ui-bc__th-seg > span:last-child,
.ui-bc__chip > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-bc__tooltip ul {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 2px;
  margin: 6px 0 0;
  padding: 6px 0 0;
  border-top: 1px solid var(--ui-bc-line);
  list-style: none;
}
.ui-bc__tooltip li {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-bc-text);
}
.ui-bc__tip-seg {
  flex: 1;
  white-space: nowrap;
}
.ui-bc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-bc__xaxis {
  display: grid;
  gap: 4px;
  margin: 8px 30px 0 0;
}
.ui-bc__xlabel {
  display: grid;
  place-items: center;
  height: 24px;
  min-width: 0;
  color: var(--ui-bc-muted);
}
.ui-bc__xlabel {
  position: relative;
  overflow: visible;
}
.ui-bc__pill {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 24px;
  padding: 0 10px 0 7px;
  border-radius: 999px;
  background: var(--ui-bc-card);
  box-shadow:
    0 0 0 1px var(--ui-bc-border),
    var(--ui-bc-pill-shadow);
  font-size: 12px;
  font-weight: 500;
  max-width: min(220px, 80cqw);
  white-space: nowrap;
  color: var(--ui-bc-ink);
  transform: translate(-50%, -50%);
  animation: ui-bc-pill 200ms var(--ui-bc-ease);
}
.ui-bc__xtext {
  overflow: hidden;
  max-width: 100%;
  font-size: 11px;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bc__table-wrap {
  overflow-x: auto;
  border-top: 1px solid var(--ui-bc-line);
  scrollbar-width: thin;
}
.ui-bc__table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  line-height: 18px;
}
.ui-bc__table th,
.ui-bc__table td {
  height: 38px;
  padding: 0 14px;
  border-top: 1px solid var(--ui-bc-line);
  text-align: left;
  white-space: nowrap;
}
.ui-bc__table thead th {
  border-top: 0;
  font-weight: 450;
  color: var(--ui-bc-muted);
  background: var(--ui-bc-head-bg);
}
.ui-bc__table [data-num] {
  text-align: right;
}
.ui-bc__table tbody th {
  position: sticky;
  left: 0;
  z-index: 1;
  background: var(--ui-bc-card);
  font-weight: 450;
}
.ui-bc__table tbody tr {
  transition: background-color 140ms ease;
}
.ui-bc__table tbody tr[data-active] th,
.ui-bc__table tbody tr[data-active] td {
  background: var(--ui-bc-row-active);
}
.ui-bc__table td {
  color: var(--ui-bc-text);
}
.ui-bc__table [data-hidden] {
  opacity: 0.35;
}
.ui-bc__row-label,
.ui-bc__th-seg {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  max-width: 220px;
}
.ui-bc__th-seg {
  max-width: 160px;
}
.ui-bc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 44px;
  padding: 6px 10px 7px 10px;
}
.ui-bc__legend {
  display: flex;
  flex-wrap: wrap;
  gap: 2px;
  min-width: 0;
}
.ui-bc__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  white-space: nowrap;
  padding: 0 9px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 12.5px !important;
  color: var(--ui-bc-text) !important;
  transition:
    background-color 140ms ease,
    opacity 160ms ease;
}
.ui-bc__chip:hover {
  background: var(--ui-bc-wash);
}
.ui-bc__chip[aria-pressed="false"] {
  opacity: 0.45;
  text-decoration: line-through;
}
.ui-bc__hint {
  padding-left: 8px;
  font-size: 12.5px;
  color: var(--ui-bc-muted);
}
.ui-bc__reset {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 12.5px !important;
  font-weight: 500;
  color: var(--ui-bc-accent-ink) !important;
}
.ui-bc__reset:hover {
  background: var(--ui-bc-accent-wash);
}
@keyframes ui-bc-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-bc-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-bc-pill {
  from {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.92);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bc__bar,
  .ui-bc__seg,
  .ui-bc__tooltip,
  .ui-bc__col,
  .ui-bc__rest {
    transition: none;
  }
  .ui-bc__menu,
  .ui-bc__tooltip,
  .ui-bc__pill {
    animation: none;
  }
}
.ui-bc__morph {
  overflow: hidden;
}
.ui-bc__morph[data-smooth] {
  transition: height 380ms cubic-bezier(0.22, 1, 0.36, 1);
}
@media (prefers-reduced-motion: reduce) {
  .ui-bc__morph[data-smooth] {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-bc {
  --ui-bc-tray: #161618;
  --ui-bc-card: #232326;
  --ui-bc-line: rgba(255, 255, 255, 0.08);
  --ui-bc-grid: rgba(255, 255, 255, 0.09);
  --ui-bc-ink: #ededed;
  --ui-bc-text: #c4c4c4;
  --ui-bc-muted: #8f8f8f;
  --ui-bc-accent-ink: #4fb0fe;
  --ui-bc-border: rgba(255, 255, 255, 0.08);
  --ui-bc-surface-hover: #2a2a2d;
  --ui-bc-option-hover: #313135;
  --ui-bc-zero: rgba(255, 255, 255, 0.16);
  --ui-bc-rest: rgba(255, 255, 255, 0.06);
  --ui-bc-head-bg: #262629;
  --ui-bc-row-active: #2a2a2d;
  --ui-bc-wash: rgba(255, 255, 255, 0.06);
  --ui-bc-accent-wash: rgba(79, 176, 254, 0.16);
  --ui-bc-focus: rgba(77, 141, 255, 0.8);
  --ui-bc-card-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-bc-btn-shadow: 0 1px 2px rgba(0, 0, 0, 0.35);
  --ui-bc-pop-shadow: 0 12px 30px -8px rgba(0, 0, 0, 0.5);
  --ui-bc-tip-shadow: 0 12px 28px -8px rgba(0, 0, 0, 0.5);
  --ui-bc-pill-shadow: 0 2px 6px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-bc__menu,
:where(.dark, [data-theme="dark"]) .ui-bc__tooltip,
:where(.dark, [data-theme="dark"]) .ui-bc__pill {
  background: #2a2a2d;
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.1),
    var(--ui-bc-pop-shadow);
}
:where(.dark, [data-theme="dark"]) .ui-bc__select-btn {
  background: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-bc__select-btn:hover {
  background: #313135;
}

.ui-tb {
  --ui-tb-focus: rgba(0, 96, 226, 0.7);
  --ui-tb-tray: #f6f6f6;
  --ui-tb-card: #ffffff;
  --ui-tb-line: #ececec;
  --ui-tb-ink: #171717;
  --ui-tb-text: #404040;
  --ui-tb-muted: #8f8f8f;
  --ui-tb-accent: #4fb0fe;
  --ui-tb-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  overflow: hidden;
  container-type: inline-size;
  background: #fff;
  border: 1px solid #e5e5e5;
  border-radius: 20px;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-tb-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-tb *,
.ui-tb *::before,
.ui-tb *::after {
  box-sizing: border-box;
}
.ui-tb button {
  margin: 0;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-tb button:focus-visible,
.ui-tb [tabindex]:focus-visible {
  outline: 2px solid var(--ui-tb-focus);
  outline-offset: 2px;
}
.ui-tb__top {
  display: flex;
  align-items: center;
  min-height: 48px;
  padding: 0 14px 0 18px;
  border-bottom: 1px solid var(--ui-tb-line);
}
.ui-tb__crumbs {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  font-size: 14px;
}
.ui-tb__clip {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-tb__logo {
  display: inline-flex;
  align-items: flex-end;
  gap: 2px;
  height: 14px;
  margin-right: 4px;
}
.ui-tb__logo i {
  width: 3px;
  border-radius: 1px;
  background: var(--ui-tb-accent);
}
.ui-tb__logo i:nth-child(1) {
  height: 6px;
  opacity: 0.45;
}
.ui-tb__logo i:nth-child(2) {
  height: 10px;
  opacity: 0.7;
}
.ui-tb__logo i:nth-child(3) {
  height: 14px;
}
.ui-tb__crumb {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
  color: var(--ui-tb-muted);
}
.ui-tb__crumb svg,
.ui-tb__logo,
.ui-tb__crumbs > .ui-tb__icon {
  flex: none;
}
.ui-tb__crumb[aria-current] {
  flex-shrink: 0;
  max-width: 60%;
}
@container (max-width: 420px) {
  .ui-tb__crumb:not(:nth-last-of-type(-n + 2)) {
    display: none;
  }
}
.ui-tb__crumb svg {
  color: #c4c4c4;
}
.ui-tb__crumb[aria-current] {
  color: var(--ui-tb-ink);
  font-weight: 500;
}
.ui-tb__icon {
  position: relative;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  padding: 0;
  border: 0;
  border-radius: 8px;
  background: transparent;
  color: var(--ui-tb-muted) !important;
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-tb__icon:hover {
  background: #f3f3f3;
  color: var(--ui-tb-ink) !important;
}
.ui-tb__icon[aria-pressed="true"],
.ui-tb__icon[data-active] {
  background: #eef7ff;
  color: var(--ui-tb-accent) !important;
}
.ui-tb__dot {
  position: absolute;
  top: 4px;
  right: 4px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-tb-accent);
}
.ui-tb__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  min-height: 46px;
  padding: 0 12px 0 18px;
}
.ui-tb__count {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 13px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  color: var(--ui-tb-text);
}
.ui-tb__count span {
  color: var(--ui-tb-muted);
}
.ui-tb__tools {
  display: flex;
  flex: none;
  align-items: center;
  gap: 4px;
}
.ui-tb__search {
  display: flex;
  align-items: center;
  gap: 6px;
  width: clamp(96px, 30cqw, 170px);
  height: 30px;
  margin-right: 4px;
  padding: 0 10px;
  border-radius: 9px;
  background: #f5f5f5;
  color: var(--ui-tb-muted);
  transition:
    box-shadow 160ms ease,
    background-color 160ms ease;
}
.ui-tb__search:focus-within {
  background: #fff;
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--ui-tb-muted) 45%, transparent);
}
.ui-tb__search input {
  flex: 1;
  min-width: 0;
  border: 0;
  outline: none;
  background: transparent;
  font: inherit;
  font-size: 13px;
  color: var(--ui-tb-ink);
}
.ui-tb__search input::-webkit-search-cancel-button {
  display: none;
}
.ui-tb__menu-wrap {
  position: relative;
}
.ui-tb__menu {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  z-index: 8;
  display: grid;
  gap: 2px;
  min-width: 180px;
  max-width: 260px;
  padding: 6px 4px 4px;
  border-radius: 12px;
  background: #fff;
  box-shadow:
    0 0 0 1px #e5e5e5,
    0 12px 30px -8px rgba(0, 0, 0, 0.2);
  max-height: 300px;
  overflow-y: auto;
  animation: ui-tb-drop 180ms var(--ui-tb-ease);
}
.ui-tb__menu-title {
  margin: 0 0 2px;
  padding: 0 10px;
  font-size: 11.5px;
  color: var(--ui-tb-muted);
}
.ui-tb__menu-none {
  margin: 0;
  padding: 6px 10px 8px;
  font-size: 13px;
  color: var(--ui-tb-muted);
}
.ui-tb__none {
  margin: 0;
  padding: 32px 18px 40px;
  text-align: center;
  font-size: 13px;
  color: var(--ui-tb-muted);
}
.ui-tb__menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 13px !important;
  text-align: left;
}
.ui-tb__menu-item svg {
  margin-left: auto;
  color: var(--ui-tb-accent);
}
.ui-tb__menu-item:hover {
  background: #f5f5f5;
}
.ui-tb .ui-tb__menu-item:focus-visible {
  outline-offset: -2px;
}
.ui-tb__menu-clear {
  color: var(--ui-tb-muted) !important;
}
.ui-tb__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-tb__swatch--dot {
  border-radius: 50%;
}
.ui-tb__prio-on {
  fill: #525252;
}
.ui-tb__prio-off {
  fill: #d4d4d4;
}
.ui-tb__ring-track {
  stroke: #e0e0e0;
}
.ui-tb__columns {
  display: grid;
  grid-auto-columns: minmax(224px, 1fr);
  grid-auto-flow: column;
  gap: 10px;
  padding: 0 12px 12px;
  overflow-x: auto;
  scrollbar-width: thin;
}
.ui-tb__column {
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 300px;
  padding: 4px 6px 6px;
  border-radius: 16px;
  background: var(--ui-tb-tray);
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease;
}
.ui-tb__column[data-over] {
  background: #eaf4fc;
  box-shadow: inset 0 0 0 1px #cde9ff;
}
.ui-tb__col-head {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 38px;
  padding: 0 4px 0 8px;
}
.ui-tb__col-title {
  font-size: 13.5px;
  font-weight: 500;
}
.ui-tb__col-count {
  flex: none;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-tb-muted);
}
.ui-tb__add {
  margin-left: auto;
}
.ui-tb__status {
  display: grid;
  place-items: center;
  flex: none;
  width: 15px;
  height: 15px;
}
.ui-tb__status svg {
  width: 15px;
  height: 15px;
}
.ui-tb__more {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  height: 32px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font: inherit;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-tb-muted);
  cursor: pointer;
}
.ui-tb__more:hover {
  background: rgba(0, 0, 0, 0.04);
  color: inherit;
}
.ui-tb__more span {
  font-weight: 400;
  opacity: 0.7;
}
:where(.dark, [data-theme="dark"]) .ui-tb__more:hover {
  background: rgba(255, 255, 255, 0.06);
}
.ui-tb__cards {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-content: start;
  gap: 6px;
  flex: 1;
}
.ui-tb__slot {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 6px;
}
.ui-tb__card {
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-tb-card);
  box-shadow:
    0 0 0 1px #e8e8e8,
    0 1px 2px rgba(0, 0, 0, 0.04);
  cursor: grab;
  animation: ui-tb-in 320ms var(--ui-tb-ease) both;
  transition:
    box-shadow 160ms ease,
    opacity 160ms ease,
    transform 200ms var(--ui-tb-ease);
}
.ui-tb__card:hover {
  box-shadow:
    0 0 0 1px #dcdcdc,
    0 6px 16px -8px rgba(0, 0, 0, 0.14);
}
.ui-tb__card:active {
  cursor: grabbing;
}
.ui-tb__card[data-dragging] {
  opacity: 0.35;
  transform: scale(0.98);
}
.ui-tb__card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 18px;
}
.ui-tb__key {
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-tb-muted);
}
.ui-tb__avatar {
  flex: none;
  border-radius: 50%;
  object-fit: cover;
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.06);
}
.ui-tb__avatar--initials {
  display: grid;
  place-items: center;
  background: #eef7ff;
  font-size: 9px;
  font-weight: 600;
  color: var(--ui-tb-accent);
}
.ui-tb__card-title {
  display: flex;
  gap: 8px;
  margin: 4px 0 0;
  font-size: 13.5px;
  font-weight: 450;
  line-height: 19px;
}
.ui-tb__card-title .ui-tb__status {
  margin-top: 2px;
}
.ui-tb__title-text {
  min-width: 0;
  overflow: hidden;
  overflow-wrap: anywhere;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  line-clamp: 3;
}
.ui-tb__title-text[data-untitled] {
  color: var(--ui-tb-muted);
}
.ui-tb__props {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 9px;
}
.ui-tb__prop {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  max-width: 100%;
  height: 22px;
  padding: 0 7px;
  border-radius: 7px;
  box-shadow: inset 0 0 0 1px #ebebeb;
  font-size: 11.5px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  color: var(--ui-tb-text);
}
.ui-tb__prop svg {
  flex: none;
  color: var(--ui-tb-muted);
}
.ui-tb__prop[data-tone="soon"] {
  color: #b25e00;
}
.ui-tb__prop[data-tone="soon"] svg {
  color: #e8b000;
}
.ui-tb__prop[data-tone="late"] {
  color: #c21f78;
  background: #fff5f9;
  box-shadow: inset 0 0 0 1px #fce1f0;
}
.ui-tb__prop[data-tone="late"] svg {
  color: #ee3e9e;
}
.ui-tb__created {
  margin: 9px 0 0;
  font-size: 11.5px;
  color: var(--ui-tb-muted);
}
.ui-tb[data-compact] .ui-tb__props,
.ui-tb[data-compact] .ui-tb__created {
  display: none;
}
.ui-tb__drop {
  display: block;
  height: 3px;
  margin: -1px 4px;
  border-radius: 2px;
  background: var(--ui-tb-accent);
  animation: ui-tb-grow 160ms var(--ui-tb-ease);
}
.ui-tb__empty {
  display: grid;
  place-items: center;
  height: 80px;
  margin: 0;
  border: 1px dashed #d9d9d9;
  border-radius: 12px;
  font-size: 12.5px;
  color: var(--ui-tb-muted);
}
.ui-tb__new input {
  width: 100%;
  height: 40px;
  padding: 0 12px;
  border: 0;
  border-radius: 12px;
  outline: none;
  background: #fff;
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--ui-tb-muted) 45%, transparent);
  font: inherit;
  font-size: 13.5px;
}
.ui-tb__scrim {
  position: absolute;
  inset: 0;
  z-index: 9;
  background: rgba(23, 23, 23, 0.08);
  opacity: 0;
  pointer-events: none;
  transition: opacity 240ms ease;
}
.ui-tb__scrim[data-open] {
  opacity: 1;
  pointer-events: auto;
}
.ui-tb__panel {
  position: absolute;
  top: 8px;
  right: 8px;
  bottom: 8px;
  z-index: 10;
  display: flex;
  flex-direction: column;
  width: min(360px, calc(100% - 16px));
  padding: 14px 16px 14px;
  overflow-y: auto;
  border-radius: 16px;
  background: #fff;
  box-shadow:
    0 0 0 1px #e5e5e5,
    0 20px 50px -12px rgba(0, 0, 0, 0.25);
  transform: translateX(calc(100% + 24px));
  transition: transform 380ms var(--ui-tb-ease);
}
.ui-tb__panel[data-open] {
  transform: none;
}
.ui-tb .ui-tb__panel:focus-visible {
  outline: none;
}
.ui-tb__panel-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.ui-tb__title-input {
  margin: 8px -6px 0;
  padding: 4px 6px;
  border: 0;
  border-radius: 8px;
  outline: none;
  resize: none;
  field-sizing: content;
  min-height: 54px;
  font: inherit;
  font-size: 17px;
  font-weight: 600;
  line-height: 23px;
  color: var(--ui-tb-ink);
}
.ui-tb__title-input:focus {
  background: #f7f7f7;
}
.ui-tb__fields {
  display: grid;
  gap: 6px;
  margin: 14px 0 0;
}
.ui-tb__fields dt {
  margin-top: 8px;
  font-size: 12px;
  color: var(--ui-tb-muted);
}
.ui-tb__fields dd {
  margin: 0;
  min-width: 0;
}
.ui-tb__choices {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}
.ui-tb__choice {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 28px;
  padding: 0 9px;
  border: 0;
  border-radius: 8px;
  background: #fff;
  box-shadow: inset 0 0 0 1px #e8e8e8;
  font-size: 12.5px !important;
  color: var(--ui-tb-text) !important;
  transition:
    background-color 140ms ease,
    box-shadow 140ms ease;
}
.ui-tb__choice:hover {
  background: #f7f7f7;
}
.ui-tb__choice:is([aria-pressed="true"], [aria-checked="true"]) {
  background: #eef7ff;
  box-shadow: inset 0 0 0 1px #cde9ff;
  color: var(--ui-tb-ink) !important;
}
.ui-tb__panel-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: auto;
  padding-top: 16px;
  font-size: 12px;
  color: var(--ui-tb-muted);
}
.ui-tb__delete {
  height: 28px;
  padding: 0 10px;
  border: 0;
  border-radius: 8px;
  background: transparent;
  font-size: 12.5px !important;
  color: #f04438 !important;
}
.ui-tb__delete:hover {
  background: #fff1f1;
}
@media (pointer: coarse) {
  .ui-tb__icon {
    width: 36px;
    height: 36px;
  }
  .ui-tb__col-head {
    height: 44px;
  }
  .ui-tb__search {
    height: 36px;
  }
  .ui-tb__search input,
  .ui-tb__new input {
    font-size: 16px;
  }
  .ui-tb__menu-item {
    height: 40px;
  }
  .ui-tb__choice,
  .ui-tb__delete {
    height: 36px;
  }
  .ui-tb__more {
    height: 40px;
  }
}
@keyframes ui-tb-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-tb-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-tb-grow {
  from {
    transform: scaleX(0.6);
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-tb__card,
  .ui-tb__menu,
  .ui-tb__drop {
    animation: none;
  }
  .ui-tb__panel,
  .ui-tb__scrim,
  .ui-tb__card {
    transition: none;
  }
}
.ui-tb input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-tb textarea:focus-visible,
.ui-tb [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-tb {
  --ui-tb-focus: rgba(77, 141, 255, 0.8);
  --ui-tb-tray: #161618;
  --ui-tb-card: #232326;
  --ui-tb-line: rgba(255, 255, 255, 0.08);
  --ui-tb-ink: #ededed;
  --ui-tb-text: #c4c4c4;
  --ui-tb-muted: #8f8f8f;
  background: #232326;
  border-color: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-tb__crumb svg {
  color: #6b6b70;
}
:where(.dark, [data-theme="dark"]) .ui-tb__icon:hover {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-tb__icon[aria-pressed="true"],
:where(.dark, [data-theme="dark"]) .ui-tb__icon[data-active] {
  background: rgba(79, 176, 254, 0.16);
  color: #4fb0fe !important;
}
:where(.dark, [data-theme="dark"]) .ui-tb__search {
  background: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-tb__search:focus-within {
  background: #2a2a2d;
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--ui-tb-muted) 45%, transparent);
}
:where(.dark, [data-theme="dark"]) .ui-tb__menu {
  background: #2a2a2d;
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.1),
    0 12px 30px -8px rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-tb__menu-item:hover {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-tb__menu-item svg {
  color: #4fb0fe;
}
:where(.dark, [data-theme="dark"]) .ui-tb__column[data-over] {
  background: rgba(79, 176, 254, 0.12);
  box-shadow: inset 0 0 0 1px rgba(79, 176, 254, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-tb__card {
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.08),
    0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-tb__card:hover {
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.14),
    0 6px 16px -8px rgba(0, 0, 0, 0.5);
}
:where(.dark, [data-theme="dark"]) .ui-tb__avatar {
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-tb__avatar--initials {
  background: rgba(79, 176, 254, 0.16);
  color: #4fb0fe;
}
:where(.dark, [data-theme="dark"]) .ui-tb__prop {
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.1);
}
:where(.dark, [data-theme="dark"]) .ui-tb__prop[data-tone="soon"] {
  color: #e6c24d;
}
:where(.dark, [data-theme="dark"]) .ui-tb__prop[data-tone="late"] {
  color: #f06db5;
  background: rgba(240, 109, 181, 0.14);
  box-shadow: inset 0 0 0 1px rgba(240, 109, 181, 0.28);
}
:where(.dark, [data-theme="dark"]) .ui-tb__prio-on {
  fill: #c4c4c4;
}
:where(.dark, [data-theme="dark"]) .ui-tb__prio-off {
  fill: #4a4a4f;
}
:where(.dark, [data-theme="dark"]) .ui-tb__ring-track {
  stroke: rgba(255, 255, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-tb__empty {
  border-color: rgba(255, 255, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-tb__new input {
  background: #2a2a2d;
  color: var(--ui-tb-ink);
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--ui-tb-muted) 45%, transparent);
}
:where(.dark, [data-theme="dark"]) .ui-tb__scrim {
  background: rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-tb__panel {
  background: #232326;
  box-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.1),
    0 20px 50px -12px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-tb__title-input {
  background: transparent;
}
:where(.dark, [data-theme="dark"]) .ui-tb__title-input:focus {
  background: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-tb__choice {
  background: #2a2a2d;
  box-shadow: inset 0 0 0 1px rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-tb__choice:hover {
  background: #313135;
}
:where(.dark, [data-theme="dark"])
  .ui-tb__choice:is([aria-pressed="true"], [aria-checked="true"]) {
  background: rgba(79, 176, 254, 0.16);
  box-shadow: inset 0 0 0 1px rgba(79, 176, 254, 0.45);
}
:where(.dark, [data-theme="dark"]) .ui-tb__delete {
  color: #ff6b5f !important;
}
:where(.dark, [data-theme="dark"]) .ui-tb__delete:hover {
  background: rgba(255, 107, 95, 0.14);
}

.board-demo {
  align-self: stretch;
  width: 100%;
  min-width: 0;
  padding: 20px 16px;
}
.board-demo[data-fit="stage"] {
  justify-items: center;
  padding: 32px 0;
  display: grid;
}
.card__preview .board-demo {
  padding: 0;
  position: absolute;
  inset: 0;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(#000 72%, #0000);
  mask-image: linear-gradient(#000 72%, #0000);
}
.board-demo[data-fit="card"] .board-demo__frame {
  transform-origin: 0 0;
  position: absolute;
  top: 44px;
  left: 24px;
}
.board-demo__frame {
  min-width: 0;
}
`;export{n as default};
