const n=`.ui-tw {
  --ui-tw-card: #ffffff;
  --ui-tw-line: #ececec;
  --ui-tw-ink: #171717;
  --ui-tw-text: #404040;
  --ui-tw-muted: #8f8f8f;
  --ui-tw-faint: #b5b5b5;
  --ui-tw-star: #a3a3a8;
  --ui-tw-star-off: #e2e2e5;
  --ui-tw-initials: #f0f0f1;
  --ui-tw-shadow: 0 0 0 1px var(--ui-tw-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-tw-lift:
    0 0 0 1px var(--ui-tw-line), 0 2px 4px rgba(0, 0, 0, 0.03),
    0 12px 28px -10px rgba(0, 0, 0, 0.14);
  --ui-tw-focus: rgba(0, 96, 226, 0.7);
  --ui-tw-gap: 16px;
  --ui-tw-fade: 96px;
  --ui-tw-dim: 0.62;
  --ui-tw-ease: cubic-bezier(0.22, 1, 0.36, 1);
  container-type: inline-size;
  display: grid;
  grid-template-columns: repeat(var(--ui-tw-cols, 3), minmax(0, 1fr));
  /* One row exactly as tall as the wall, so a column's height never follows its (repeated) content */
  grid-template-rows: minmax(0, 1fr);
  gap: var(--ui-tw-gap);
  width: 100%;
  min-width: 0;
  height: var(--ui-tw-height, 600px);
  /* Room at the sides for the lifted card's shadow; the wall clips everything else */
  padding-inline: 12px;
  box-sizing: border-box;
  overflow: hidden;
  -webkit-mask-image: linear-gradient(
    180deg,
    transparent,
    #000 var(--ui-tw-fade),
    #000 calc(100% - var(--ui-tw-fade)),
    transparent
  );
  mask-image: linear-gradient(
    180deg,
    transparent,
    #000 var(--ui-tw-fade),
    #000 calc(100% - var(--ui-tw-fade)),
    transparent
  );
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  -webkit-font-smoothing: antialiased;
}

.ui-tw[data-empty] {
  display: grid;
  place-items: center;
  height: auto;
  min-height: 160px;
  -webkit-mask-image: none;
  mask-image: none;
}
.ui-tw__empty {
  margin: 0;
  font-size: 14px;
  color: var(--ui-tw-muted);
}

.ui-tw__col {
  position: relative;
  min-width: 0;
  min-height: 0;
  height: 100%;
  cursor: grab;
  user-select: none;
  -webkit-user-select: none;
  -webkit-touch-callout: none;
}
.ui-tw__col[data-dragging] {
  cursor: grabbing;
}
.ui-tw__track {
  will-change: transform;
}
.ui-tw__set {
  position: relative;
  display: flex;
  flex-direction: column;
  margin: 0;
  padding: 0;
  list-style: none;
}
/* Every card carries its gap below, so one set's height is exactly the wrap distance */
.ui-tw__item {
  margin-bottom: var(--ui-tw-gap);
}

.ui-tw__card {
  display: flex;
  flex-direction: column;
  gap: 14px;
  margin: 0;
  padding: 18px 20px 18px;
  border-radius: 16px;
  background: var(--ui-tw-card);
  box-shadow: var(--ui-tw-shadow);
  color: var(--ui-tw-text);
  transition:
    transform 320ms var(--ui-tw-ease),
    box-shadow 320ms var(--ui-tw-ease),
    opacity 320ms var(--ui-tw-ease);
}
.ui-tw__card:focus {
  outline: none;
}
.ui-tw__card:focus-visible {
  outline: 2px solid var(--ui-tw-focus);
  outline-offset: 2px;
}

.ui-tw__stars {
  display: flex;
  gap: 2px;
  margin-bottom: -4px;
}
.ui-tw__stars svg {
  width: 13px;
  height: 13px;
  fill: var(--ui-tw-star-off);
}
.ui-tw__stars svg[data-on] {
  fill: var(--ui-tw-star);
}

.ui-tw__quote {
  margin: 0;
}
.ui-tw__quote p {
  margin: 0;
  font-size: 14px;
  line-height: 1.6;
  letter-spacing: -0.006em;
  text-wrap: pretty;
  overflow-wrap: break-word;
  /* Line breaks in a quote are kept; very long quotes stop at ten lines so a card never outgrows the wall */
  white-space: pre-line;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 10;
  line-clamp: 10;
  overflow: hidden;
}

.ui-tw__who {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-tw__avatar {
  flex: none;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  object-fit: cover;
  background: var(--ui-tw-initials);
  /* A hairline ring keeps light photos from melting into the card */
  box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.05);
  pointer-events: none;
}
.ui-tw__avatar--initials {
  display: grid;
  place-items: center;
  font-size: 12.5px;
  font-weight: 600;
  letter-spacing: 0.01em;
  color: var(--ui-tw-muted);
}
.ui-tw__id {
  display: grid;
  gap: 1px;
  min-width: 0;
}
.ui-tw__name {
  display: flex;
  /* Top-aligned, so the check stays on the first line when a long name wraps */
  align-items: flex-start;
  gap: 5px;
  min-width: 0;
  font-size: 13.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-tw-ink);
}
/* The name identifies the person: it wraps to a second line (an email-like name breaks anywhere) and only then is cut */
.ui-tw__name-text {
  display: -webkit-box;
  min-width: 0;
  overflow: hidden;
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
}
.ui-tw__verified {
  flex: none;
  margin-top: 2px;
  width: 14px;
  height: 14px;
  fill: var(--ui-tw-faint);
}
/* Role and company wrap once at most, then end in an ellipsis */
.ui-tw__meta {
  min-width: 0;
  overflow: hidden;
  overflow-wrap: anywhere;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  font-size: 12.5px;
  line-height: 17px;
  color: var(--ui-tw-muted);
}

/* Hover: the card under the pointer lifts a little, the rest of the wall steps back */
@media (hover: hover) {
  .ui-tw__col:not([data-dragging]) .ui-tw__card:hover {
    transform: translateY(-3px);
    box-shadow: var(--ui-tw-lift);
  }
  .ui-tw:has(.ui-tw__col:not([data-dragging]) .ui-tw__card:hover)
    .ui-tw__card:not(:hover) {
    opacity: var(--ui-tw-dim);
  }
}
/* Keyboard focus gets the same lift */
.ui-tw__card:focus-visible {
  transform: translateY(-3px);
  box-shadow: var(--ui-tw-lift);
}

/* Narrow walls (one column on phones): roomier, more readable quotes */
@container (max-width: 479px) {
  .ui-tw__card {
    padding: 18px 18px 18px;
  }
  .ui-tw__quote p {
    font-size: 15px;
    line-height: 1.58;
  }
}
@container (max-width: 739px) {
  .ui-tw__col {
    --ui-tw-gap: 14px;
  }
}

/* Reduced motion: a static masonry that shows every quote – no fixed height, no fade */
.ui-tw[data-static] {
  height: auto;
  grid-template-rows: auto;
  overflow: visible;
  -webkit-mask-image: none;
  mask-image: none;
}
.ui-tw[data-static] .ui-tw__col {
  height: auto;
  cursor: auto;
  user-select: auto;
  -webkit-user-select: auto;
}

@media (prefers-reduced-motion: reduce) {
  .ui-tw__card {
    transition: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-tw {
  --ui-tw-card: #19191b;
  --ui-tw-line: #2a2a2e;
  --ui-tw-ink: #ededed;
  --ui-tw-text: #c8c8cc;
  --ui-tw-muted: #8b8b92;
  --ui-tw-faint: #6b6b72;
  --ui-tw-star: #7a7a82;
  --ui-tw-star-off: #2f2f34;
  --ui-tw-initials: #232327;
  --ui-tw-shadow: 0 0 0 1px var(--ui-tw-line);
  --ui-tw-lift: 0 0 0 1px #34343a, 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-tw-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-tw__avatar {
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.06);
}

.testimonial-wall-demo {
  -webkit-font-smoothing: antialiased;
  justify-items: center;
  gap: 24px;
  width: 100%;
  min-width: 0;
  max-width: 1000px;
  margin-inline: auto;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    Segoe UI,
    Roboto,
    sans-serif;
  display: grid;
}
.testimonial-wall-demo :is(.ui-tw, .ui-twc) {
  --ui-tw-height: 580px;
  --ui-twc-height: 580px;
}
.testimonial-wall-demo__head {
  text-align: center;
  justify-items: center;
  gap: 6px;
  padding-inline: 16px;
  animation: 0.6s cubic-bezier(0.22, 1, 0.36, 1) 0.12s both
    testimonial-wall-demo-in;
  display: grid;
}
.testimonial-wall-demo__eyebrow {
  color: #8f8f8f;
  margin: 0;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 16px;
}
.testimonial-wall-demo__title {
  letter-spacing: -0.025em;
  color: #171717;
  text-wrap: balance;
  margin: 0;
  font-size: 26px;
  font-weight: 600;
  line-height: 1.15;
}
@keyframes testimonial-wall-demo-in {
  0% {
    opacity: 0;
    filter: blur(2px);
    transform: translateY(4px);
  }
}
@media (prefers-reduced-motion: reduce) {
  .testimonial-wall-demo__head {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .testimonial-wall-demo__eyebrow {
  color: #8b8b92;
}
:where(.dark, [data-theme="dark"]) .testimonial-wall-demo__title {
  color: #ededed;
}
.card__preview .testimonial-wall-demo {
  box-sizing: border-box;
  transform-origin: 0 0;
  flex-direction: column;
  width: 263.158%;
  max-width: none;
  height: 263.158%;
  padding: 95px 30px 0;
  display: flex;
  position: absolute;
  top: 0;
  left: 0;
  transform: scale(0.38);
}
.card__preview .testimonial-wall-demo__head {
  display: none;
}
.card__preview .testimonial-wall-demo :is(.ui-tw, .ui-twc) {
  --ui-tw-fade: 110px;
  --ui-twc-fade: 120px;
  flex: 1;
  height: auto;
  min-height: 0;
}
.stage:has(.testimonial-wall-demo) {
  height: 760px;
  padding: 48px 32px 32px;
}
@media (width<=760px) {
  .stage:has(.testimonial-wall-demo) {
    height: 720px;
    min-height: 0;
    padding: 56px 12px 16px;
  }
  .testimonial-wall-demo {
    gap: 18px;
  }
  .testimonial-wall-demo :is(.ui-tw, .ui-twc) {
    --ui-tw-height: 540px;
    --ui-twc-height: 540px;
  }
  .testimonial-wall-demo__head {
    padding-inline: 48px;
  }
  .testimonial-wall-demo__title {
    font-size: 22px;
  }
}
.testimonial-wall-demo--clean .testimonial-wall-demo__eyebrow {
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: #00000073;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
}
.testimonial-wall-demo--clean .testimonial-wall-demo__title {
  letter-spacing: -0.24px;
  color: #000;
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
}
:where(.dark, [data-theme="dark"])
  .testimonial-wall-demo--clean
  .testimonial-wall-demo__eyebrow {
  color: #ffffff73;
}
:where(.dark, [data-theme="dark"])
  .testimonial-wall-demo--clean
  .testimonial-wall-demo__title {
  color: #fff;
}
@media (width<=760px) {
  .testimonial-wall-demo--clean .testimonial-wall-demo__title {
    font-size: 22px;
    line-height: 28px;
  }
}
`;export{n as default};
