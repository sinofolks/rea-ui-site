const n=`.ui-trv {
  --ui-trv-blur: 8px;
  --ui-trv-rise: 0.35em;
  --ui-trv-ease: cubic-bezier(0.2, 0.7, 0.2, 1);
}
.ui-trv__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-trv__w {
  display: inline-block;
  max-width: 100%;
  white-space: nowrap;
}
/* A word longer than the line breaks inside instead of running past it */
.ui-trv__p,
.ui-trv__w {
  overflow-wrap: anywhere;
}
.ui-trv__w:has(> .ui-trv__p) {
  white-space: normal;
}
.ui-trv__p {
  display: inline-block;
  opacity: 0;
  filter: blur(var(--ui-trv-blur));
  transform: translateY(var(--ui-trv-rise));
  will-change: opacity, filter, transform;
}
.ui-trv[data-shown] .ui-trv__p {
  animation: ui-trv-in var(--ui-trv-duration) var(--ui-trv-ease) both;
  animation-delay: calc(
    var(--ui-trv-delay) + var(--ui-trv-i) * var(--ui-trv-stagger)
  );
}
@keyframes ui-trv-in {
  from {
    opacity: 0;
    filter: blur(var(--ui-trv-blur));
    transform: translateY(var(--ui-trv-rise));
  }
  to {
    opacity: 1;
    filter: blur(0);
    transform: none;
  }
}

/* Reduced motion: the text is simply there */
@media (prefers-reduced-motion: reduce) {
  .ui-trv .ui-trv__p,
  .ui-trv[data-shown] .ui-trv__p {
    opacity: 1;
    filter: none;
    transform: none;
    animation: none;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html>.
   The text takes its color from the parent, so only the blur softens a touch on dark backgrounds */
:where(.dark, [data-theme="dark"]) .ui-trv {
  --ui-trv-blur: 6px;
}

.text-reveal-demo {
  text-align: center;
  justify-items: center;
  gap: 28px;
  width: 100%;
  font-family: Inter, system-ui, sans-serif;
  display: grid;
}
.text-reveal-demo__copy {
  gap: 14px;
  max-width: 460px;
  display: grid;
}
.text-reveal-demo__title {
  letter-spacing: -0.03em;
  color: #171717;
  text-wrap: balance;
  margin: 0;
  font-size: clamp(30px, 5vw, 44px);
  font-weight: 600;
  line-height: 1.1;
}
.text-reveal-demo__body {
  color: #8f8f8f;
  text-wrap: pretty;
  margin: 0;
  font-size: 16px;
  line-height: 1.55;
}
.text-reveal-demo__replay {
  color: #171717;
  cursor: pointer;
  background: #fff;
  border: 0;
  border-radius: 9px;
  height: 30px;
  padding: 0 12px;
  font:
    500 12.5px/1 Inter,
    system-ui,
    sans-serif;
  box-shadow: 0 0 0 1px #e5e5e5;
}
.text-reveal-demo__replay:hover {
  background: #fafafa;
}
.card__preview .text-reveal-demo {
  place-content: center;
  padding: 0 28px;
  position: absolute;
  inset: 0;
}
.card__preview .text-reveal-demo__copy {
  gap: 8px;
  max-width: 280px;
}
.card__preview .text-reveal-demo__title {
  font-size: 24px;
}
.card__preview .text-reveal-demo__body {
  font-size: 12.5px;
}
.card__preview .text-reveal-demo__replay {
  display: none;
}
:where(.dark, [data-theme="dark"]) .text-reveal-demo__title {
  color: #ededed;
}
:where(.dark, [data-theme="dark"]) .text-reveal-demo__replay {
  color: #ededed;
  background: #232326;
  box-shadow: 0 0 0 1px #ffffff14;
}
:where(.dark, [data-theme="dark"]) .text-reveal-demo__replay:hover {
  background: #2a2a2e;
}
`;export{n as default};
