const n=`.ui-thinkc {
  --ui-tkc-card: #ffffff;
  --ui-tkc-ink: rgba(0, 0, 0, 0.88);
  --ui-tkc-strong: #000000;
  --ui-tkc-text: rgba(0, 0, 0, 0.65);
  --ui-tkc-muted: rgba(0, 0, 0, 0.65);
  --ui-tkc-faint: rgba(0, 0, 0, 0.65);
  --ui-tkc-icon: rgba(0, 0, 0, 0.65);
  --ui-tkc-line: rgba(0, 0, 0, 0.06);
  --ui-tkc-rail: rgba(0, 0, 0, 0.08);
  --ui-tkc-fill: rgba(0, 0, 0, 0.06);
  --ui-tkc-wash: rgba(0, 0, 0, 0.03);
  --ui-tkc-accent: rgba(0, 96, 226, 0.765);
  --ui-tkc-shine: rgba(255, 255, 255, 0.82);
  --ui-tkc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tkc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tkc-ring: 0 0 0 0.5px rgba(0, 0, 0, 0.1);
  --ui-tkc-focus: rgba(0, 96, 226, 0.7);
  --ui-tkc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 440px;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-tkc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-thinkc *,
.ui-thinkc *::before,
.ui-thinkc *::after {
  box-sizing: border-box;
}
:where(.ui-thinkc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-thinkc) svg {
  display: block;
  flex: none;
}
.ui-thinkc button:focus-visible,
.ui-thinkc a:focus-visible {
  outline: 2px solid var(--ui-tkc-focus);
  outline-offset: 2px;
}
.ui-thinkc__head {
  display: flex;
  width: fit-content;
  align-items: center;
  gap: 10px;
  max-width: 100%;
  height: 36px;
  padding: 0 8px;
  border-radius: 8px;
  text-align: left;
}
.ui-thinkc__mark {
  display: grid;
  grid-template-columns: repeat(3, 3px);
  grid-auto-rows: 3px;
  gap: 1.5px;
  place-content: center;
  width: 16px;
  height: 16px;
}
.ui-thinkc__mark i {
  border-radius: 0.75px;
  background: var(--ui-tkc-accent);
  animation: ui-thinkc-pixel 1.2s ease-in-out infinite both;
}
.ui-thinkc[data-done] .ui-thinkc__mark i {
  animation: ui-thinkc-settle 420ms var(--ui-tkc-ease) both;
}
.ui-thinkc__title {
  display: inline-flex;
  min-width: 0;
  gap: 8px;
  font-weight: 500;
  white-space: nowrap;
  color: var(--ui-tkc-ink);
  transition: color 160ms ease;
  animation: ui-thinkc-in 420ms var(--ui-tkc-ease) both;
}
.ui-thinkc__head:hover .ui-thinkc__title {
  color: var(--ui-tkc-muted);
}
.ui-thinkc__title .ui-thinkc__shimmer {
  color: var(--ui-tkc-muted);
}
.ui-thinkc__time {
  font-weight: 400;
  font-variant-numeric: tabular-nums;
  color: var(--ui-tkc-faint);
}
.ui-thinkc__chevron {
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  margin-left: -4px;
  color: var(--ui-tkc-icon);
  opacity: 0;
  transition: opacity 160ms ease;
}
.ui-thinkc__head:is(:hover, :focus-visible) .ui-thinkc__chevron {
  opacity: 0.6;
}
.ui-thinkc__chevron svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
  transform: rotate(-90deg);
  transition: transform 260ms var(--ui-tkc-ease);
}
.ui-thinkc__head[aria-expanded="true"] .ui-thinkc__chevron svg {
  transform: none;
}
.ui-thinkc__body {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 360ms var(--ui-tkc-ease),
    opacity 260ms ease;
}
.ui-thinkc__body[data-open="false"] {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-thinkc__clip {
  min-height: 0;
  overflow: visible;
}
.ui-thinkc__body[data-open="false"] .ui-thinkc__clip {
  overflow: hidden;
}
.ui-thinkc__list {
  margin: 0;
  padding: 8px 8px 0;
  list-style: none;
}
.ui-thinkc__item {
  position: relative;
  display: grid;
  grid-template-columns: 16px minmax(0, 1fr);
  gap: 10px;
  padding-bottom: 12px;
  animation: ui-thinkc-in 520ms var(--ui-tkc-ease) both;
}
.ui-thinkc__item:not(:last-child)::before {
  content: "";
  position: absolute;
  left: 7.5px;
  top: 22px;
  bottom: 2px;
  width: 1px;
  background: var(--ui-tkc-rail);
  transform-origin: top;
  animation: ui-thinkc-line 520ms var(--ui-tkc-ease) both;
}
.ui-thinkc__node {
  display: grid;
  place-items: center;
  width: 16px;
  height: 20px;
}
.ui-thinkc__globe {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: var(--ui-tkc-icon);
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-thinkc__dot {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background: var(--ui-tkc-faint);
  transition:
    background-color 300ms ease,
    border-radius 300ms ease;
}
.ui-thinkc__item[data-active] .ui-thinkc__dot {
  width: 6px;
  height: 6px;
  border-radius: 1.5px;
  background: var(--ui-tkc-accent);
  animation: ui-thinkc-pulse 1s ease-in-out infinite;
}
.ui-thinkc__check {
  width: 16px;
  height: 16px;
  animation: ui-thinkc-pop 460ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-thinkc__check circle {
  fill: var(--ui-tkc-accent);
}
.ui-thinkc__check path {
  fill: none;
  stroke: #fff;
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 9;
  stroke-dashoffset: 9;
  animation: ui-thinkc-draw 360ms var(--ui-tkc-ease) 180ms forwards;
}
.ui-thinkc__content {
  min-width: 0;
}
.ui-thinkc__label {
  position: relative;
  display: inline-block;
  max-width: 100%;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
  color: var(--ui-tkc-text);
  transition: color 300ms ease;
}
.ui-thinkc__item[data-active] .ui-thinkc__label {
  color: var(--ui-tkc-muted);
}
.ui-thinkc__item[data-kind="done"] .ui-thinkc__label {
  font-weight: 500;
  color: var(--ui-tkc-ink);
}
.ui-thinkc__sources {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
  padding: 1px 0 2px;
}
.ui-thinkc__source {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 100%;
  height: 26px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  background: var(--ui-tkc-card);
  box-shadow: var(--ui-tkc-shadow);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tkc-ink);
  text-decoration: none;
  animation: ui-thinkc-chip 420ms var(--ui-tkc-ease) both;
}
a.ui-thinkc__source,
.ui-thinkc__more {
  position: relative;
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
a.ui-thinkc__source:hover {
  background: var(--ui-tkc-wash);
}
.ui-thinkc .ui-thinkc__more {
  padding: 0 8px;
  background: none;
  box-shadow: inset 0 0 0 0.5px var(--ui-tkc-line);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-tkc-text);
}
.ui-thinkc .ui-thinkc__more:hover {
  background: var(--ui-tkc-wash);
  color: var(--ui-tkc-ink);
}
.ui-thinkc .ui-thinkc__more[aria-expanded="true"] {
  background: var(--ui-tkc-fill);
  color: var(--ui-tkc-ink);
}
.ui-thinkc__tip {
  position: absolute;
  left: 50%;
  bottom: calc(100% + 6px);
  z-index: 2;
  padding: 4px 8px;
  border-radius: 6px;
  background: var(--ui-tkc-card);
  box-shadow: var(--ui-tkc-shadow-pop);
  color: var(--ui-tkc-text);
  font-size: 12px;
  line-height: 16px;
  width: max-content;
  max-width: min(320px, 80vw);
  overflow-wrap: anywhere;
  pointer-events: none;
  opacity: 0;
  transform: translate(-50%, 4px);
  transition:
    opacity 140ms ease,
    transform 200ms var(--ui-tkc-ease);
}
.ui-thinkc__source:hover .ui-thinkc__tip,
.ui-thinkc__source:focus-visible .ui-thinkc__tip {
  opacity: 1;
  transform: translate(-50%, 0);
  transition-delay: 250ms;
}
.ui-thinkc__source[data-count] {
  padding: 0 8px;
  background: none;
  box-shadow: inset 0 0 0 0.5px var(--ui-tkc-line);
  color: var(--ui-tkc-text);
}
.ui-thinkc__source-label {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-thinkc__favicon img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.ui-thinkc__favicon {
  display: grid;
  place-items: center;
  flex: none;
  width: 14px;
  height: 14px;
  border-radius: 4px;
  overflow: hidden;
  box-shadow: var(--ui-tkc-ring);
}
.ui-thinkc__favicon svg {
  width: 100%;
  height: 100%;
}
.ui-thinkc__shimmer {
  position: relative;
}
.ui-thinkc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: inherit;
  overflow-wrap: inherit;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-tkc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-thinkc-sweep 1.6s linear infinite;
  pointer-events: none;
}
@keyframes ui-thinkc-in {
  from {
    opacity: 0;
    transform: translateY(6px);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-thinkc-line {
  from {
    transform: scaleY(0);
  }
  to {
    transform: scaleY(1);
  }
}
@keyframes ui-thinkc-chip {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.92);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-thinkc-pulse {
  50% {
    transform: scale(0.7);
    opacity: 0.45;
  }
}
@keyframes ui-thinkc-pixel {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.2;
  }
}
@keyframes ui-thinkc-settle {
  from {
    opacity: 0.2;
    transform: scale(0.6);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-thinkc-pop {
  0% {
    transform: scale(0.5);
  }
  60% {
    transform: scale(1.12);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-thinkc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-thinkc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@container (max-width: 360px) {
  .ui-thinkc__head {
    padding: 0 8px;
  }
  .ui-thinkc__list {
    padding: 8px 8px 0;
  }
}
@media (pointer: coarse) {
  .ui-thinkc__head {
    height: 52px;
  }
  .ui-thinkc__source {
    height: 32px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-thinkc *,
  .ui-thinkc *::before,
  .ui-thinkc *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
  }
  .ui-thinkc__shimmer::after {
    display: none;
  }
  .ui-thinkc__check path {
    stroke-dashoffset: 0;
  }
}
:where(.dark, [data-theme="dark"]) .ui-thinkc {
  --ui-tkc-card: #1c1c1e;
  --ui-tkc-ink: rgba(255, 255, 255, 0.9);
  --ui-tkc-strong: #ffffff;
  --ui-tkc-text: rgba(255, 255, 255, 0.62);
  --ui-tkc-muted: rgba(255, 255, 255, 0.46);
  --ui-tkc-faint: rgba(255, 255, 255, 0.3);
  --ui-tkc-icon: rgba(255, 255, 255, 0.5);
  --ui-tkc-line: rgba(255, 255, 255, 0.08);
  --ui-tkc-rail: rgba(255, 255, 255, 0.1);
  --ui-tkc-fill: rgba(255, 255, 255, 0.08);
  --ui-tkc-wash: rgba(255, 255, 255, 0.04);
  --ui-tkc-accent: #4d8dff;
  --ui-tkc-shine: #ffffff;
  --ui-tkc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tkc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-tkc-ring: 0 0 0 0.5px rgba(255, 255, 255, 0.14);
  --ui-tkc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-thinkc__tip {
  background: #232326;
}
`;export{n as default};
