const n=`.ui-tc {
  --ui-tc-radius: 20px;
  --ui-tc-shadow:
    0 1px 2px rgba(0, 0, 0, 0.06), 0 8px 24px -12px rgba(0, 0, 0, 0.18);
  --ui-tc-shadow-active:
    0 2px 4px rgba(0, 0, 0, 0.05), 0 24px 48px -16px rgba(0, 0, 0, 0.3);
  --ui-tc-glare-color: rgba(255, 255, 255, 0.32);
  --ui-tc-spring: cubic-bezier(0.34, 1.36, 0.64, 1);
  display: inline-block;
  perspective: var(--ui-tc-perspective);
}
.ui-tc-card {
  --rx: 0deg;
  --ry: 0deg;
  --gx: 50%;
  --gy: 50%;
  --ui-tc-lift: 0px;
  --ui-tc-s: 1;
  position: relative;
  overflow: hidden;
  border-radius: var(--ui-tc-radius);
  box-shadow: var(--ui-tc-shadow);
  transform: translateY(var(--ui-tc-lift)) rotateX(var(--rx)) rotateY(var(--ry))
    scale(var(--ui-tc-s));
  transition:
    transform 700ms var(--ui-tc-spring),
    box-shadow 500ms ease;
  will-change: transform;
}
.ui-tc-card[data-active] {
  --ui-tc-s: var(--ui-tc-scale);
  --ui-tc-lift: -2px;
  box-shadow: var(--ui-tc-shadow-active);
  transition:
    transform 140ms ease-out,
    box-shadow 300ms ease;
}
.ui-tc:has(:focus-visible) .ui-tc-card {
  --ui-tc-lift: -4px;
  box-shadow: var(--ui-tc-shadow-active);
}
.ui-tc-glare {
  position: absolute;
  inset: 0;
  z-index: 1;
  border-radius: inherit;
  pointer-events: none;
  background: radial-gradient(
    circle at var(--gx) var(--gy),
    var(--ui-tc-glare-color),
    transparent 55%
  );
  mix-blend-mode: soft-light;
  opacity: 0;
  transition: opacity 400ms ease;
}
.ui-tc-card[data-active] .ui-tc-glare {
  opacity: 1;
}
@media (hover: none), (pointer: coarse) {
  .ui-tc-card[data-active] {
    --ui-tc-s: 1;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-tc-card,
  .ui-tc-card[data-active],
  .ui-tc:has(:focus-visible) .ui-tc-card {
    transform: none;
    transition: box-shadow 300ms ease;
  }
  .ui-tc-glare {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-tc {
  --ui-tc-shadow:
    0 1px 2px rgba(0, 0, 0, 0.4), 0 8px 24px -12px rgba(0, 0, 0, 0.6);
  --ui-tc-shadow-active:
    0 2px 4px rgba(0, 0, 0, 0.4), 0 28px 56px -16px rgba(0, 0, 0, 0.75);
  --ui-tc-glare-color: rgba(255, 255, 255, 0.24);
}

.tilt-card-demo {
  -webkit-font-smoothing: antialiased;
  flex-direction: column;
  align-items: center;
  gap: 28px;
  width: 100%;
  font-family:
    Inter,
    ui-sans-serif,
    system-ui,
    -apple-system,
    sans-serif;
  display: flex;
}
.tilt-card-demo .ui-tc {
  max-width: 100%;
}
.tilt-card-demo__card {
  aspect-ratio: 1.586;
  box-sizing: border-box;
  color: #fff;
  -webkit-user-select: none;
  user-select: none;
  background:
    radial-gradient(120% 90% at 100% 0, #ffffff38, #0000 55%),
    radial-gradient(90% 80% at 0 100%, #7c4dff8c, #0000 60%),
    linear-gradient(135deg, #2f6bff 0%, #4f5bff 45%, #7c4dff 100%);
  flex-direction: column;
  width: 340px;
  max-width: 100%;
  padding: 22px 24px;
  display: flex;
  position: relative;
}
.tilt-card-demo__card:after {
  content: "";
  border-radius: inherit;
  pointer-events: none;
  position: absolute;
  inset: 0;
  box-shadow: inset 0 0 0 1px #ffffff2e;
}
.tilt-card-demo__top {
  justify-content: space-between;
  align-items: center;
  display: flex;
}
.tilt-card-demo__brand {
  letter-spacing: -0.01em;
  font-size: 15px;
  font-weight: 500;
}
.tilt-card-demo__brand b {
  opacity: 0.75;
  font-weight: 600;
}
.tilt-card-demo__wave {
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8px;
  stroke-linecap: round;
  opacity: 0.8;
  width: 20px;
  height: 20px;
}
.tilt-card-demo__chip {
  background: linear-gradient(135deg, #f3e2b3, #d9b86c 55%, #f1dca4);
  border-radius: 6px;
  width: 40px;
  height: 30px;
  margin-top: auto;
  position: relative;
  box-shadow: inset 0 0 0 1px #785a1e40;
}
.tilt-card-demo__chip:before,
.tilt-card-demo__chip:after {
  content: "";
  border-block: 1px solid #785a1e4d;
  position: absolute;
  inset: 9px 0;
}
.tilt-card-demo__chip:after {
  border: 0;
  border-inline: 1px solid #785a1e4d;
  inset: 0 13px;
}
.tilt-card-demo__number {
  letter-spacing: 0.06em;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  margin-top: 14px;
  font-size: 17px;
  font-weight: 500;
}
.tilt-card-demo__bottom {
  gap: 28px;
  margin-top: 12px;
  display: flex;
}
.tilt-card-demo__bottom > div {
  flex-direction: column;
  gap: 2px;
  display: flex;
}
.tilt-card-demo__label {
  letter-spacing: 0.08em;
  text-transform: uppercase;
  opacity: 0.65;
  font-size: 10px;
  font-weight: 500;
}
.tilt-card-demo__value {
  font-size: 13px;
  font-weight: 500;
}
.tilt-card-demo__caption {
  color: #8f8f8f;
  margin: 0;
  font-size: 13px;
  line-height: 1.4;
}
.card__preview .tilt-card-demo {
  zoom: 0.62;
  justify-content: center;
  gap: 18px;
  position: absolute;
  inset: 0;
}
`;export{n as default};
