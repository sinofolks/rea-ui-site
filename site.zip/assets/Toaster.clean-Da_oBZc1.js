const n=`.ui-tsc {
  --ui-tsc-card: #ffffff;
  --ui-tsc-strong: #000000;
  --ui-tsc-ink: rgba(0, 0, 0, 0.88);
  --ui-tsc-text: rgba(0, 0, 0, 0.65);
  --ui-tsc-icon: rgba(0, 0, 0, 0.65);
  --ui-tsc-faint: rgba(0, 0, 0, 0.27);
  --ui-tsc-hairline: rgba(0, 0, 0, 0.1);
  --ui-tsc-success: #0f783c;
  --ui-tsc-danger: #bf383d;
  --ui-tsc-accent: #0060e2;
  --ui-tsc-focus: rgba(0, 96, 226, 0.7);
  --ui-tsc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tsc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 1px -1px rgba(0, 0, 0, 0.12),
    0 1px 3px 0 rgba(0, 0, 0, 0.07);
  --ui-tsc-shadow-float:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05), 0 10px 24px -10px rgba(0, 0, 0, 0.14);
  --ui-tsc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-tsc-width: 356px;
  --ui-tsc-offset: 24px;
  position: fixed;
  z-index: 9999;
  box-sizing: border-box;
  container-type: inline-size;
  width: var(--ui-tsc-width);
  max-width: calc(100% - 2 * var(--ui-tsc-offset));
  margin: 0;
  padding: 0;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-tsc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
  outline: none;
}
.ui-tsc[data-inline] {
  position: absolute;
  z-index: 20;
  --ui-tsc-offset: 20px;
}
.ui-tsc[data-empty] {
  pointer-events: none;
}
.ui-tsc *,
.ui-tsc *::before,
.ui-tsc *::after {
  box-sizing: border-box;
}
:where(.ui-tsc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-tsc) svg {
  display: block;
  flex: none;
}
.ui-tsc button:focus-visible {
  outline: 2px solid var(--ui-tsc-focus);
  outline-offset: 2px;
}
.ui-tsc[data-y="bottom"] {
  bottom: var(--ui-tsc-offset);
}
.ui-tsc[data-y="top"] {
  top: var(--ui-tsc-offset);
}
.ui-tsc[data-x="right"] {
  right: var(--ui-tsc-offset);
}
.ui-tsc[data-x="left"] {
  left: var(--ui-tsc-offset);
}
.ui-tsc[data-x="center"] {
  left: 50%;
  transform: translateX(-50%);
}
.ui-tsc:not([data-inline])[data-y="bottom"] {
  bottom: max(var(--ui-tsc-offset), env(safe-area-inset-bottom));
}
.ui-tsc__list {
  position: relative;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-tsc__toast {
  position: absolute;
  left: 0;
  right: 0;
  outline: none;
  touch-action: none;
  -webkit-user-select: none;
  user-select: none;
  transition:
    transform 440ms var(--ui-tsc-ease),
    opacity 320ms ease,
    height 380ms var(--ui-tsc-ease);
}
.ui-tsc[data-y="bottom"] .ui-tsc__toast {
  bottom: 0;
  transform-origin: 50% 0;
}
.ui-tsc[data-y="top"] .ui-tsc__toast {
  top: 0;
  transform-origin: 50% 100%;
}
.ui-tsc__toast[data-removing] {
  pointer-events: none;
  transition:
    transform 380ms var(--ui-tsc-ease),
    opacity 260ms ease,
    height 380ms var(--ui-tsc-ease);
}
.ui-tsc__swipe {
  position: relative;
  height: 100%;
  transition:
    transform 460ms cubic-bezier(0.34, 1.3, 0.64, 1),
    opacity 260ms ease;
}
.ui-tsc__toast[data-swiping] {
  cursor: grabbing;
}
.ui-tsc__card {
  position: relative;
  height: 100%;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-tsc-card);
  box-shadow: var(--ui-tsc-shadow-float);
}
.ui-tsc__toast:focus-visible .ui-tsc__card {
  outline: 2px solid var(--ui-tsc-focus);
  outline-offset: 2px;
}
.ui-tsc__content {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 12px 14px 12px 12px;
  transition: opacity 260ms ease;
}
.ui-tsc__content[data-action] {
  padding-right: 12px;
}
.ui-tsc__toast[data-behind] .ui-tsc__content,
.ui-tsc__toast[data-behind] .ui-tsc__timer {
  opacity: 0;
}
.ui-tsc__text {
  position: relative;
  flex: 1;
  min-width: 0;
}
.ui-tsc__title {
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-tsc-strong);
  overflow-wrap: anywhere;
}
.ui-tsc__desc {
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-tsc-text);
  overflow-wrap: anywhere;
}
.ui-tsc__copy[data-changed] {
  animation: ui-tsc-text-in 300ms var(--ui-tsc-ease) both;
}
.ui-tsc__ghost {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  pointer-events: none;
  animation: ui-tsc-text-out 220ms ease both;
}
.ui-tsc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 20px;
  color: var(--ui-tsc-icon);
  transition: color 300ms ease;
}
.ui-tsc__icon[data-type="success"] {
  color: var(--ui-tsc-success);
}
.ui-tsc__icon[data-type="error"] {
  color: var(--ui-tsc-danger);
}
.ui-tsc__icon[data-type="info"] {
  color: var(--ui-tsc-accent);
}
.ui-tsc__icon[data-type="custom"] {
  overflow: hidden;
}
.ui-tsc__icon[data-type="custom"] > * {
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-tsc__status {
  width: 16px;
  height: 16px;
  overflow: visible;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-tsc__icon[data-type="success"] .ui-tsc__status,
.ui-tsc__icon[data-type="error"] .ui-tsc__status {
  animation: ui-tsc-pop 460ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-tsc__spin {
  transform-box: fill-box;
  transform-origin: center;
  animation: ui-tsc-spin 760ms linear infinite;
  animation-play-state: paused;
}
.ui-tsc__icon[data-type="loading"] .ui-tsc__spin {
  animation-play-state: running;
}
.ui-tsc__ring {
  stroke-dasharray: 1 0;
  stroke-opacity: 0.24;
  transition:
    stroke-dasharray 560ms var(--ui-tsc-ease),
    stroke-opacity 360ms ease;
}
.ui-tsc__icon[data-type="loading"] .ui-tsc__ring {
  stroke-dasharray: 0.28 0.72;
  stroke-opacity: 1;
}
.ui-tsc__mark {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  opacity: 0;
}
.ui-tsc__info {
  opacity: 0;
  transition: opacity 240ms ease;
}
.ui-tsc__icon[data-type="success"] .ui-tsc__check,
.ui-tsc__icon[data-type="error"] .ui-tsc__x1,
.ui-tsc__icon[data-type="error"] .ui-tsc__x2 {
  opacity: 1;
  stroke-dashoffset: 0;
  animation: ui-tsc-draw 340ms var(--ui-tsc-ease) 160ms both;
}
.ui-tsc__icon[data-type="error"] .ui-tsc__x2 {
  animation-delay: 260ms;
}
.ui-tsc__icon[data-type="info"] .ui-tsc__info {
  opacity: 1;
}
.ui-tsc__action {
  flex: none;
  align-self: center;
  height: 28px;
  margin: -4px 0;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    box-shadow 140ms ease,
    transform 160ms var(--ui-tsc-ease);
}
:where(.ui-tsc) .ui-tsc__action {
  background: var(--ui-tsc-card);
  box-shadow: var(--ui-tsc-shadow);
  color: var(--ui-tsc-strong);
}
.ui-tsc__action {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
}
.ui-tsc__action-label {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-tsc__action:hover {
  box-shadow: var(--ui-tsc-shadow-hover);
}
.ui-tsc__action:active {
  transform: scale(0.97);
}
.ui-tsc__close {
  position: absolute;
  top: -7px;
  left: -7px;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  opacity: 0;
  transform: scale(0.8);
  transition:
    opacity 160ms ease,
    transform 200ms var(--ui-tsc-ease),
    color 160ms ease,
    box-shadow 160ms ease;
}
:where(.ui-tsc) .ui-tsc__close {
  background: var(--ui-tsc-card);
  box-shadow: var(--ui-tsc-shadow);
  color: var(--ui-tsc-icon);
}
.ui-tsc__close::before {
  content: "";
  position: absolute;
  inset: -6px;
}
.ui-tsc__close:hover {
  color: var(--ui-tsc-ink);
  box-shadow: var(--ui-tsc-shadow-hover);
}
.ui-tsc__toast:not([data-behind]):hover .ui-tsc__close,
.ui-tsc__toast:not([data-behind]):focus-within .ui-tsc__close {
  opacity: 1;
  transform: none;
}
.ui-tsc__glyph {
  width: 10px;
  height: 10px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.2;
  stroke-linecap: round;
}
.ui-tsc__timer {
  position: absolute;
  left: 12px;
  right: 12px;
  bottom: 0;
  height: 1px;
  background: var(--ui-tsc-hairline);
  transform-origin: left;
  animation-name: ui-tsc-timer;
  animation-timing-function: linear;
  animation-fill-mode: both;
  transition: opacity 260ms ease;
}
.ui-tsc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-tsc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-tsc-draw {
  from {
    stroke-dashoffset: 1;
  }
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-tsc-pop {
  0% {
    transform: scale(0.82);
  }
  55% {
    transform: scale(1.08);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-tsc-timer {
  from {
    transform: scaleX(1);
  }
  to {
    transform: scaleX(0);
  }
}
@keyframes ui-tsc-text-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-tsc-text-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translateY(-4px);
    filter: blur(3px);
  }
}
@container (max-width: 300px) {
  .ui-tsc__content {
    padding: 10px 12px 10px 10px;
  }
}
@media (max-width: 600px) {
  .ui-tsc,
  .ui-tsc[data-x] {
    left: 12px;
    right: 12px;
    width: auto;
    max-width: none;
    transform: none;
  }
  .ui-tsc[data-y="bottom"] {
    bottom: 12px;
  }
  .ui-tsc:not([data-inline])[data-y="bottom"] {
    bottom: max(12px, env(safe-area-inset-bottom));
  }
  .ui-tsc[data-y="top"] {
    top: 12px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-tsc__toast:not([data-behind]) .ui-tsc__close {
    opacity: 1;
    transform: none;
  }
  .ui-tsc__close {
    width: 24px;
    height: 24px;
    top: -8px;
    left: -8px;
  }
  .ui-tsc__close::before {
    inset: -8px;
  }
  .ui-tsc__action {
    height: 36px;
    margin: -8px -2px -8px 0;
    padding: 0 14px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-tsc *:not(.ui-tsc__spin):not(.ui-tsc__timer),
  .ui-tsc *::before,
  .ui-tsc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-tsc {
  --ui-tsc-card: #1c1c1e;
  --ui-tsc-strong: #ffffff;
  --ui-tsc-ink: rgba(255, 255, 255, 0.9);
  --ui-tsc-text: rgba(255, 255, 255, 0.62);
  --ui-tsc-icon: rgba(255, 255, 255, 0.46);
  --ui-tsc-faint: rgba(255, 255, 255, 0.3);
  --ui-tsc-hairline: rgba(255, 255, 255, 0.14);
  --ui-tsc-success: #3ec27a;
  --ui-tsc-danger: #ff6369;
  --ui-tsc-accent: #4d8dff;
  --ui-tsc-focus: rgba(77, 141, 255, 0.8);
  --ui-tsc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tsc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tsc-shadow-float:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4),
    0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-tsc .ui-tsc__action {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-tsc .ui-tsc__close {
  background: #2a2a2d;
}
`;export{n as default};
