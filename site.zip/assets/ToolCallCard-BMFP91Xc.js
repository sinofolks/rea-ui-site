const n=`.ui-tcl,
.ui-tcl-group {
  --ui-tcl-ink: #171717;
  --ui-tcl-text: #6b6b6b;
  --ui-tcl-muted: #626873;
  --ui-tcl-bg: #ffffff;
  --ui-tcl-line: #e7e7e7;
  --ui-tcl-hover: #fafafa;
  --ui-tcl-tile: #f5f5f5;
  --ui-tcl-code: #fafafa;
  --ui-tcl-ring: #ffffff;
  --ui-tcl-red: #c4352c;
  --ui-tcl-red-bg: rgba(200, 55, 45, 0.06);
  --ui-tcl-red-line: rgba(200, 55, 45, 0.16);
  --ui-tcl-key: #171717;
  --ui-tcl-str: #0e7869;
  --ui-tcl-num: #a25308;
  --ui-tcl-lit: #6e56cf;
  --ui-tcl-shine: rgba(255, 255, 255, 0.82);
  --ui-tcl-focus: rgba(0, 96, 226, 0.7);
  --ui-tcl-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-tcl-mono: ui-monospace, "SF Mono", Menlo, monospace;
  box-sizing: border-box;
  min-width: 0;
  color: var(--ui-tcl-text);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.4;
  letter-spacing: -0.006em;
  -webkit-font-smoothing: antialiased;
}
.ui-tcl *,
.ui-tcl-group * {
  box-sizing: border-box;
}

.ui-tcl {
  position: relative;
  border-radius: 12px;
  background: var(--ui-tcl-bg);
  box-shadow:
    inset 0 0 0 1px var(--ui-tcl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-tcl-sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}

/* Header: icon, name + summary, status, chevron – everything truncates before it overflows */
.ui-tcl__head {
  all: unset;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  min-height: 44px;
  padding: 8px 10px 8px 9px;
  border-radius: 12px;
  cursor: pointer;
  transition: background-color 160ms ease;
}
.ui-tcl[data-open] .ui-tcl__head {
  border-radius: 12px 12px 0 0;
}
.ui-tcl__head:focus-visible,
.ui-tcl-group__head:focus-visible,
.ui-tcl__copy:focus-visible,
.ui-tcl__more:focus-visible,
.ui-tcl__retry:focus-visible {
  outline: 2px solid var(--ui-tcl-focus);
  outline-offset: 2px;
}
@media (hover: hover) {
  .ui-tcl__head:hover {
    background: var(--ui-tcl-hover);
  }
  .ui-tcl-group__head:hover {
    background: var(--ui-tcl-hover);
    color: var(--ui-tcl-ink);
  }
  .ui-tcl__copy:hover {
    background: var(--ui-tcl-hover);
    color: var(--ui-tcl-ink);
  }
  .ui-tcl__more:hover {
    color: var(--ui-tcl-ink);
  }
  .ui-tcl__retry:hover {
    background: var(--ui-tcl-hover);
  }
}

.ui-tcl__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 26px;
  height: 26px;
  border-radius: 7px;
  background: var(--ui-tcl-tile);
  box-shadow: inset 0 0 0 1px var(--ui-tcl-line);
  color: var(--ui-tcl-ink);
}
.ui-tcl__icon > svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.ui-tcl__main {
  display: flex;
  align-items: baseline;
  gap: 8px;
  flex: 1;
  min-width: 0;
}
.ui-tcl__name {
  flex: 0 1 auto;
  max-width: 55%;
  overflow: hidden;
  color: var(--ui-tcl-ink);
  font-family: var(--ui-tcl-mono);
  font-size: 12.5px;
  font-weight: 500;
  letter-spacing: 0;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-tcl__summary {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-tcl-text);
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ui-tcl__status {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: none;
  color: var(--ui-tcl-muted);
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  animation: ui-tcl-in 360ms var(--ui-tcl-ease) both;
}
.ui-tcl[data-status="error"] .ui-tcl__status {
  color: var(--ui-tcl-red);
}
.ui-tcl__status > svg {
  width: 14px;
  height: 14px;
  flex: none;
  fill: none;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-tcl__spinner circle {
  stroke: currentColor;
  stroke-width: 1.6;
  opacity: 0.22;
}
.ui-tcl__spinner path {
  stroke: var(--ui-tcl-ink);
  stroke-width: 1.6;
}
.ui-tcl__spinner {
  animation: ui-tcl-spin 800ms linear infinite;
}
.ui-tcl__ok {
  stroke: var(--ui-tcl-ink);
  stroke-width: 1.8;
}
.ui-tcl__ok path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-tcl-draw 360ms var(--ui-tcl-ease) 80ms forwards;
}
.ui-tcl__err {
  stroke: var(--ui-tcl-red);
  stroke-width: 1.5;
}

.ui-tcl__chevron {
  flex: none;
  width: 14px;
  height: 14px;
  fill: none;
  stroke: var(--ui-tcl-muted);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition: transform 360ms var(--ui-tcl-ease);
}
.ui-tcl[data-open] > .ui-tcl__head .ui-tcl__chevron,
.ui-tcl-group[data-open] > .ui-tcl-group__head .ui-tcl__chevron {
  transform: rotate(180deg);
}

/* Body: grows from 0fr to 1fr, so the height animates without measuring */
.ui-tcl__body {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 380ms var(--ui-tcl-ease),
    opacity 240ms ease;
}
.ui-tcl[data-open] > .ui-tcl__body,
.ui-tcl-group[data-open] > .ui-tcl__body {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-tcl__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-tcl__sections {
  display: grid;
  gap: 12px;
  padding: 12px;
  border-top: 1px solid var(--ui-tcl-line);
}

.ui-tcl__section {
  display: grid;
  gap: 6px;
  min-width: 0;
}
.ui-tcl__section-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 24px;
}
.ui-tcl__label {
  color: var(--ui-tcl-muted);
  font-size: 12px;
  font-weight: 500;
}
.ui-tcl__pending {
  margin: 0;
  color: var(--ui-tcl-muted);
  font-size: 12.5px;
}

.ui-tcl__copy {
  all: unset;
  position: relative;
  display: grid;
  place-items: center;
  width: 24px;
  height: 24px;
  border-radius: 6px;
  color: var(--ui-tcl-muted);
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-tcl__copy svg {
  position: absolute;
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
  transition:
    opacity 200ms ease,
    transform 320ms var(--ui-tcl-ease),
    filter 200ms ease;
}
.ui-tcl__copy-done {
  opacity: 0;
  transform: scale(0.6);
  filter: blur(2px);
  stroke-width: 1.7;
}
.ui-tcl__copy[data-copied] {
  color: var(--ui-tcl-ink);
}
.ui-tcl__copy[data-copied] .ui-tcl__copy-icon {
  opacity: 0;
  transform: scale(0.6);
  filter: blur(2px);
}
.ui-tcl__copy[data-copied] .ui-tcl__copy-done {
  opacity: 1;
  transform: none;
  filter: none;
}

/* Code: wraps instead of scrolling sideways; capped blocks fade out at the bottom */
.ui-tcl__code {
  position: relative;
  margin: 0;
  padding: 10px 12px;
  overflow: hidden;
  border-radius: 8px;
  background: var(--ui-tcl-code);
  box-shadow: inset 0 0 0 1px var(--ui-tcl-line);
  color: var(--ui-tcl-muted);
  font-family: var(--ui-tcl-mono);
  font-size: 12px;
  line-height: 1.6;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  tab-size: 2;
  transition: max-height 420ms var(--ui-tcl-ease);
}
.ui-tcl__code code {
  display: block;
  font: inherit;
}
.ui-tcl__code::after {
  content: "";
  position: absolute;
  left: 1px;
  right: 1px;
  bottom: 1px;
  height: 56px;
  border-radius: 0 0 7px 7px;
  background: linear-gradient(to bottom, transparent, var(--ui-tcl-code));
  opacity: 0;
  transition: opacity 240ms ease;
  pointer-events: none;
}
.ui-tcl__code[data-capped]::after {
  opacity: 1;
}
.ui-tcl__code[data-scroll] {
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-tcl__t-key {
  color: var(--ui-tcl-key);
}
.ui-tcl__t-str {
  color: var(--ui-tcl-str);
}
.ui-tcl__t-num {
  color: var(--ui-tcl-num);
}
.ui-tcl__t-lit {
  color: var(--ui-tcl-lit);
}

.ui-tcl__more {
  all: unset;
  justify-self: start;
  padding: 2px 4px;
  margin-left: -4px;
  border-radius: 5px;
  color: var(--ui-tcl-text);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  transition: color 160ms ease;
}

/* Error: the message and an optional retry */
.ui-tcl__error {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 9px 10px 9px 11px;
  border-radius: 8px;
  background: var(--ui-tcl-red-bg);
  box-shadow: inset 0 0 0 1px var(--ui-tcl-red-line);
}
.ui-tcl__error > .ui-tcl__err {
  flex: none;
  width: 14px;
  height: 14px;
  margin-top: 2px;
  fill: none;
  stroke-linecap: round;
}
.ui-tcl__error-text {
  flex: 1;
  min-width: 0;
  max-height: 200px;
  margin: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  white-space: pre-line;
  color: var(--ui-tcl-red);
  font-size: 13px;
  line-height: 1.45;
  overflow-wrap: anywhere;
}
.ui-tcl__retry {
  all: unset;
  display: inline-flex;
  align-items: center;
  gap: 5px;
  flex: none;
  height: 26px;
  margin: -3px 0;
  padding: 0 10px 0 8px;
  border-radius: 7px;
  background: var(--ui-tcl-bg);
  box-shadow:
    inset 0 0 0 1px var(--ui-tcl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  color: var(--ui-tcl-ink);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  transition: background-color 160ms ease;
}
.ui-tcl__retry svg {
  width: 13px;
  height: 13px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-tcl__retry:active svg {
  transform: rotate(-60deg);
  transition: transform 200ms var(--ui-tcl-ease);
}

/* Group: one quiet line with the tool icons stacked, the cards below */
.ui-tcl-group {
  display: grid;
}
.ui-tcl-group__head {
  all: unset;
  box-sizing: border-box;
  display: flex;
  align-items: center;
  gap: 9px;
  justify-self: start;
  max-width: 100%;
  min-height: 36px;
  padding: 4px 10px 4px 5px;
  border-radius: 10px;
  color: var(--ui-tcl-text);
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-tcl-group__stack {
  display: flex;
  flex: none;
}
.ui-tcl-group__stack .ui-tcl__icon {
  width: 24px;
  height: 24px;
  border-radius: 7px;
  box-shadow:
    inset 0 0 0 1px var(--ui-tcl-line),
    0 0 0 2px var(--ui-tcl-ring);
  animation: ui-tcl-pop 420ms var(--ui-tcl-ease) both;
}
.ui-tcl-group__stack .ui-tcl__icon + .ui-tcl__icon {
  margin-left: -5px;
}
.ui-tcl-group__stack .ui-tcl__icon > svg {
  width: 13px;
  height: 13px;
}
.ui-tcl-group__title {
  display: flex;
  align-items: baseline;
  gap: 5px;
  min-width: 0;
  white-space: nowrap;
  animation: ui-tcl-in 360ms var(--ui-tcl-ease) both;
}
.ui-tcl-group__label {
  position: relative;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  color: inherit;
  font-weight: 500;
}
.ui-tcl-group__failed {
  flex: none;
  color: var(--ui-tcl-red);
}
.ui-tcl-group__time {
  flex: none;
  color: var(--ui-tcl-muted);
  font-variant-numeric: tabular-nums;
}
.ui-tcl-group__list {
  display: grid;
  gap: 8px;
  padding-top: 8px;
}

/* A soft light sweeping over "Using tools…" */
.ui-tcl__shine::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-tcl-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-tcl-sweep 1.8s linear infinite;
  pointer-events: none;
}

@keyframes ui-tcl-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-tcl-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-tcl-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-tcl-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-tcl-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-tcl *,
  .ui-tcl-group *,
  .ui-tcl *::after,
  .ui-tcl-group *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
  }
  .ui-tcl__shine::after {
    display: none;
  }
  .ui-tcl__ok path {
    stroke-dashoffset: 0;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-tcl,
:where(.dark, [data-theme="dark"]) .ui-tcl-group {
  --ui-tcl-ink: #ededed;
  --ui-tcl-text: #a1a1a1;
  --ui-tcl-muted: #7c7c7c;
  --ui-tcl-bg: #161618;
  --ui-tcl-line: rgba(255, 255, 255, 0.1);
  --ui-tcl-hover: rgba(255, 255, 255, 0.035);
  --ui-tcl-tile: #1d1d20;
  --ui-tcl-code: #1d1d20;
  --ui-tcl-ring: #161618;
  --ui-tcl-red: #ff7b72;
  --ui-tcl-red-bg: rgba(255, 110, 100, 0.08);
  --ui-tcl-red-line: rgba(255, 110, 100, 0.2);
  --ui-tcl-key: #ededed;
  --ui-tcl-str: #5fd4b8;
  --ui-tcl-num: #f2a65a;
  --ui-tcl-lit: #b5a4ff;
  --ui-tcl-shine: rgba(255, 255, 255, 0.95);
  --ui-tcl-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-tcl {
  box-shadow: inset 0 0 0 1px var(--ui-tcl-line);
}
`;export{n as default};
