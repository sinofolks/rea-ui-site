const n=`.ui-um {
  --ui-um-tray: #f0f0f0;
  --ui-um-card: #ffffff;
  --ui-um-line: #ececec;
  --ui-um-ink: #171717;
  --ui-um-text: #404040;
  --ui-um-muted: #626873;
  --ui-um-faint: #6b6b6b;
  --ui-um-well: #f4f4f5;
  --ui-um-hover: #f4f4f5;
  --ui-um-track: #efeff1;
  --ui-um-fill: #4a4a4f;
  --ui-um-spark: #dcdce0;
  --ui-um-accent: #2f6bff;
  --ui-um-warn: #f59e0b;
  --ui-um-warn-text: #ac4f07;
  --ui-um-c1: #2f6bff;
  --ui-um-c2: #74a0ff;
  --ui-um-c3: #b4cbff;
  --ui-um-c4: #a8a8ae;
  --ui-um-c5: #d4d4d8;
  --ui-um-focus: rgba(0, 96, 226, 0.7);
  --ui-um-tip-shadow:
    0 8px 24px -6px rgba(0, 0, 0, 0.16), 0 2px 6px rgba(0, 0, 0, 0.06);
  --ui-um-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 460px;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-um-tray);
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 1.45;
  color: var(--ui-um-text);
  -webkit-font-smoothing: antialiased;
}
.ui-um *,
.ui-um *::before,
.ui-um *::after {
  box-sizing: border-box;
}
:where(.ui-um) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-um) :is(h3, p, ul) {
  margin: 0;
  padding: 0;
}
:where(.ui-um) ul {
  list-style: none;
}
.ui-um :is(button, [tabindex="0"]):focus-visible {
  outline: 2px solid var(--ui-um-focus);
  outline-offset: 2px;
}
.ui-um b {
  font-weight: 500;
  color: var(--ui-um-ink);
}
.ui-um__muted {
  color: var(--ui-um-muted);
}
.ui-um__card {
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-um-card);
  box-shadow:
    0 0 0 1px var(--ui-um-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition: height 360ms var(--ui-um-ease);
}
.ui-um__inner {
  display: flow-root;
  padding: 14px 16px 18px;
}
.ui-um__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}
.ui-um__heading {
  flex: 1 1 auto;
  min-width: min(120px, 40%);
  padding-top: 2px;
}
.ui-um__title {
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-um-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-um__sub {
  font-size: 12.5px;
  color: var(--ui-um-muted);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-um__sep {
  margin: 0 6px;
  color: var(--ui-um-faint);
}
.ui-um__switch {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, auto);
  grid-auto-flow: column;
  flex: 0 1 auto;
  min-width: 0;
  padding: 2px;
  border-radius: 10px;
  background: var(--ui-um-well);
  box-shadow: inset 0 0 0 1px var(--ui-um-line);
}
.ui-um__pill {
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 8px;
  background: var(--ui-um-card);
  box-shadow:
    0 0 0 1px var(--ui-um-line),
    0 1px 2px rgba(0, 0, 0, 0.06);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 320ms var(--ui-um-ease),
    width 320ms var(--ui-um-ease),
    height 320ms var(--ui-um-ease),
    opacity 200ms ease;
}
.ui-um__option {
  position: relative;
  z-index: 1;
  min-width: 0;
  height: 26px;
  padding: 0 9px;
  overflow: hidden;
  border-radius: 8px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-um-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: color 200ms ease;
}
.ui-um .ui-um__option:focus-visible {
  outline-offset: -2px;
}
.ui-um__option:hover,
.ui-um__option[aria-checked="true"] {
  color: var(--ui-um-ink);
}
.ui-um__figure {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  margin-top: 18px;
}
.ui-um__amount {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  column-gap: 6px;
  min-width: 0;
}
.ui-um__big {
  font-size: 28px;
  font-weight: 600;
  line-height: 34px;
  letter-spacing: -0.02em;
  color: var(--ui-um-ink);
  font-variant-numeric: tabular-nums;
}
.ui-um__of {
  font-size: 13px;
  color: var(--ui-um-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-um__pct {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-um-text);
  font-variant-numeric: tabular-nums;
  transition: color 260ms ease;
}
.ui-um__pct[data-state="warn"] {
  color: var(--ui-um-warn-text);
}
.ui-um__pct[data-state="limit"] {
  color: var(--ui-um-ink);
}
.ui-um__dot {
  display: inline-block;
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-um-warn);
  animation: ui-um-pop 420ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-um[data-state="limit"] .ui-um__pct .ui-um__dot,
.ui-um[data-state="limit"] .ui-um__status .ui-um__dot,
.ui-um__limit[data-state="limit"] .ui-um__dot {
  box-shadow: 0 0 0 3px color-mix(in srgb, var(--ui-um-warn) 22%, transparent);
}
.ui-um__bar {
  position: relative;
  margin-top: 10px;
  padding: 4px 0;
  border-radius: 6px;
  cursor: default;
}
.ui-um__track {
  display: flex;
  height: 10px;
  overflow: hidden;
  border-radius: 5px;
  background: var(--ui-um-track);
}
.ui-um__seg {
  position: relative;
  flex: none;
  height: 100%;
  overflow: hidden;
  transition: opacity 200ms ease;
}
.ui-um__seg::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 2px;
  background: var(--ui-um-card);
}
.ui-um__bar[data-active] .ui-um__seg:not([data-active]) {
  opacity: 0.28;
}
.ui-um__tip {
  position: absolute;
  bottom: calc(100% + 6px);
  z-index: 2;
  display: grid;
  gap: 1px;
  padding: 7px 10px 8px;
  border: 1px solid var(--ui-um-line);
  border-radius: 10px;
  background: var(--ui-um-card);
  box-shadow: var(--ui-um-tip-shadow);
  max-width: 100%;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transform: translate(var(--ui-um-tip-x), 4px) scale(0.97);
  transition:
    left 260ms var(--ui-um-ease),
    transform 260ms var(--ui-um-ease),
    opacity 160ms ease;
}
.ui-um__tip[data-open] {
  opacity: 1;
  transform: translate(var(--ui-um-tip-x), 0);
}
.ui-um__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-um__tip-label {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 12px;
  color: var(--ui-um-muted);
}
.ui-um__tip-value {
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-um-ink);
  font-variant-numeric: tabular-nums;
}
.ui-um__tip-value .ui-um__muted {
  font-weight: 400;
}
.ui-um__legend {
  display: grid;
  margin-top: 10px;
}
.ui-um__row {
  display: grid;
  grid-template-rows: 1fr;
  animation: ui-um-grow 380ms var(--ui-um-ease) both;
  transition:
    grid-template-rows 320ms var(--ui-um-ease) 80ms,
    opacity 200ms ease;
}
.ui-um__row[data-leaving] {
  grid-template-rows: 0fr;
  opacity: 0;
  pointer-events: none;
}
.ui-um__item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 0;
  height: 30px;
  margin: 0 -8px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 8px;
  transition:
    background-color 160ms ease,
    opacity 200ms ease;
}
.ui-um__row[data-leaving] .ui-um__item {
  background: none;
}
.ui-um__item[data-active] {
  background: var(--ui-um-hover);
}
.ui-um__legend[data-active] .ui-um__item:not([data-active]) {
  opacity: 0.45;
}
.ui-um__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2.5px;
}
.ui-um__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-um-text);
}
.ui-um__value {
  color: var(--ui-um-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-um__share {
  width: 40px;
  text-align: right;
  color: var(--ui-um-muted);
  font-variant-numeric: tabular-nums;
}
.ui-um__daily {
  margin-top: 12px;
}
.ui-um__daily-head {
  display: flex;
  justify-content: space-between;
  gap: 12px;
  font-size: 12px;
  color: var(--ui-um-muted);
  white-space: nowrap;
}
.ui-um__daily-read {
  font-variant-numeric: tabular-nums;
  animation: ui-um-in 220ms var(--ui-um-ease) both;
}
.ui-um__spark {
  display: flex;
  align-items: stretch;
  gap: 2px;
  height: 34px;
  margin-top: 8px;
  border-radius: 4px;
  cursor: default;
}
.ui-um__spark[data-many] {
  gap: 1px;
}
.ui-um__spark[data-many="dense"] {
  gap: 0;
}
.ui-um__spark[data-few] {
  gap: 5px;
}
.ui-um__day {
  display: flex;
  flex: 1 1 0;
  align-items: flex-end;
  min-width: 0;
}
.ui-um__day > span {
  width: 100%;
  border-radius: 2px;
  background: var(--ui-um-spark);
  transform-origin: bottom;
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-um__spark[data-regrow] .ui-um__day > span {
  animation: ui-um-rise 520ms var(--ui-um-ease) both;
  animation-delay: calc(var(--i) * 18ms);
}
.ui-um__day[data-future] > span {
  height: 2px;
  background: var(--ui-um-track);
}
.ui-um__spark[data-hover] .ui-um__day:not([data-active]) > span {
  opacity: 0.6;
}
.ui-um__day[data-active] > span {
  background: var(--ui-um-accent);
}
.ui-um__limits {
  display: grid;
  grid-template-columns: repeat(var(--n, 3), minmax(0, 1fr));
  gap: 12px 18px;
  margin-top: 16px;
  padding-top: 14px;
  border-top: 1px solid var(--ui-um-line);
}
.ui-um__limit {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-content: start;
  min-width: 0;
}
.ui-um__limit-label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-um-muted);
  white-space: nowrap;
}
.ui-um__limit-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-um__limit-value {
  color: var(--ui-um-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.ui-um__limit-value .ui-um__muted {
  font-weight: 400;
}
.ui-um__thin {
  position: relative;
  display: block;
  height: 4px;
  margin-top: 7px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-um-track);
}
.ui-um__thin > span {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  border-radius: inherit;
  background: var(--ui-um-fill);
}
.ui-um__thin[data-unlimited] {
  background: repeating-linear-gradient(
    -45deg,
    var(--ui-um-track) 0 3px,
    transparent 3px 6px
  );
}
.ui-um__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 6px 12px;
  min-height: 44px;
  padding: 6px 2px 2px 12px;
  font-size: 12.5px;
  color: var(--ui-um-muted);
}
.ui-um__status {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-um-in 260ms var(--ui-um-ease) both;
}
.ui-um__status > :last-child {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-um__action {
  display: inline-flex;
  flex: none;
  justify-content: center;
  max-width: 100%;
  height: 32px;
  margin-left: auto;
  overflow: hidden;
  border-radius: 14px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-um-ink);
  background: var(--ui-um-card);
  box-shadow:
    0 0 0 1px var(--ui-um-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition:
    background-color 280ms ease,
    color 280ms ease,
    box-shadow 280ms ease,
    width 320ms var(--ui-um-ease),
    transform 140ms ease;
}
.ui-um__action:hover {
  background: var(--ui-um-hover);
}
.ui-um__action:active {
  transform: scale(0.97);
}
.ui-um__action[data-strong] {
  background: var(--ui-um-ink);
  color: var(--ui-um-card);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.12),
    0 6px 14px -6px rgba(0, 0, 0, 0.35);
  animation: ui-um-nudge 520ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-um__action[data-strong]:hover {
  background: var(--ui-um-ink);
  opacity: 0.88;
}
.ui-um__action-inner {
  display: inline-flex;
  align-items: center;
  flex: none;
  height: 100%;
  padding: 0 14px;
  white-space: nowrap;
}
.ui-um__action-text {
  animation: ui-um-in 260ms var(--ui-um-ease) both;
}
.ui-um__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-um-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-um-grow {
  from {
    grid-template-rows: 0fr;
    opacity: 0;
  }
  to {
    grid-template-rows: 1fr;
    opacity: 1;
  }
}
@keyframes ui-um-rise {
  from {
    transform: scaleY(0);
  }
  to {
    transform: none;
  }
}
@keyframes ui-um-pop {
  0% {
    transform: scale(0.3);
  }
  60% {
    transform: scale(1.25);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-um-nudge {
  0% {
    transform: scale(0.94);
  }
  60% {
    transform: scale(1.04);
  }
  100% {
    transform: scale(1);
  }
}
@container (max-width: 400px) {
  .ui-um__inner {
    padding: 12px 14px 16px;
  }
  .ui-um__head {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
  .ui-um__switch {
    grid-auto-columns: minmax(0, auto);
  }
  .ui-um__option {
    padding: 0 6px;
  }
  .ui-um__big {
    font-size: 26px;
  }
  .ui-um__limits {
    grid-template-columns: minmax(0, 1fr);
    gap: 12px;
  }
  .ui-um__limit {
    grid-template-columns: minmax(0, 1fr) fit-content(60%);
    column-gap: 12px;
  }
  .ui-um__limit-value {
    font-size: 12.5px;
    text-align: end;
  }
  .ui-um__thin {
    grid-column: 1 / -1;
    margin-top: 6px;
  }
}
@container (max-width: 300px) {
  .ui-um__of {
    font-size: 12px;
  }
  .ui-um__share {
    width: 34px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-um__option {
    height: 34px;
  }
  .ui-um__item {
    height: 36px;
  }
  .ui-um__action {
    height: 38px;
    border-radius: 13px;
  }
  .ui-um__foot {
    min-height: 50px;
  }
  .ui-um__bar {
    padding: 10px 0;
    margin-top: 4px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-um *,
  .ui-um *::before,
  .ui-um *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-um {
  --ui-um-tray: #111113;
  --ui-um-card: #19191b;
  --ui-um-line: #2a2a2e;
  --ui-um-ink: #ededed;
  --ui-um-text: #c8c8cc;
  --ui-um-muted: #8b8b92;
  --ui-um-faint: #5c5c63;
  --ui-um-well: #111113;
  --ui-um-hover: #232326;
  --ui-um-track: #2a2a2e;
  --ui-um-fill: #b4b4ba;
  --ui-um-spark: #3a3a40;
  --ui-um-accent: #6d8bff;
  --ui-um-warn: #f5a524;
  --ui-um-warn-text: #f5b350;
  --ui-um-c1: #6d8bff;
  --ui-um-c2: #4c66c9;
  --ui-um-c3: #34468a;
  --ui-um-c4: #6b6b72;
  --ui-um-c5: #45454b;
  --ui-um-focus: rgba(77, 141, 255, 0.8);
  --ui-um-tip-shadow:
    0 8px 24px -6px rgba(0, 0, 0, 0.5), 0 2px 6px rgba(0, 0, 0, 0.35);
}
:where(.dark, [data-theme="dark"]) .ui-um__pill {
  background: #2a2a2e;
  box-shadow: 0 0 0 1px rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-um__tip {
  background: #2a2a2d;
  border-color: rgba(255, 255, 255, 0.1);
}
`;export{n as default};
