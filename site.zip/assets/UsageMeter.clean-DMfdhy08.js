const n=`.ui-umc {
  --ui-umc-card: #ffffff;
  --ui-umc-strong: #000000;
  --ui-umc-ink: rgba(0, 0, 0, 0.88);
  --ui-umc-text: rgba(0, 0, 0, 0.65);
  --ui-umc-muted: rgba(0, 0, 0, 0.65);
  --ui-umc-faint: rgba(0, 0, 0, 0.65);
  --ui-umc-line: rgba(0, 0, 0, 0.06);
  --ui-umc-wash: rgba(0, 0, 0, 0.03);
  --ui-umc-fill: rgba(0, 0, 0, 0.06);
  --ui-umc-track: rgba(0, 0, 0, 0.06);
  --ui-umc-spark: rgba(0, 0, 0, 0.12);
  --ui-umc-accent: rgba(0, 96, 226, 0.765);
  --ui-umc-warn: #e8a20c;
  --ui-umc-warn-text: #916100;
  --ui-umc-warn-bg: rgba(232, 162, 12, 0.12);
  --ui-umc-full: #e5484d;
  --ui-umc-full-text: #bf353a;
  --ui-umc-full-bg: rgba(229, 72, 77, 0.08);
  --ui-umc-c1: rgba(0, 96, 226, 0.765);
  --ui-umc-c2: rgba(0, 96, 226, 0.5);
  --ui-umc-c3: rgba(0, 96, 226, 0.3);
  --ui-umc-c4: rgba(0, 96, 226, 0.16);
  --ui-umc-c5: rgba(0, 0, 0, 0.14);
  --ui-umc-dark: rgba(0, 0, 0, 0.88);
  --ui-umc-on-dark: #fcfcfc;
  --ui-umc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-umc-tip-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 2px 0 rgba(0, 0, 0, 0.05),
    0 8px 20px -8px rgba(0, 0, 0, 0.14);
  --ui-umc-focus: rgba(0, 96, 226, 0.7);
  --ui-umc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 460px;
  border-radius: 10px;
  background: var(--ui-umc-card);
  box-shadow: var(--ui-umc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-umc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-umc *,
.ui-umc *::before,
.ui-umc *::after {
  box-sizing: border-box;
}
:where(.ui-umc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-umc) :is(h3, p, ul) {
  margin: 0;
  padding: 0;
}
:where(.ui-umc) ul {
  list-style: none;
}
.ui-umc :is(button, [tabindex="0"]):focus-visible {
  outline: 2px solid var(--ui-umc-focus);
  outline-offset: 2px;
}
.ui-umc b {
  font-weight: 500;
  color: var(--ui-umc-ink);
}
.ui-umc__muted {
  color: var(--ui-umc-muted);
}
.ui-umc__card {
  overflow: hidden;
  border-radius: 10px 10px 0 0;
  transition: height 360ms var(--ui-umc-ease);
}
.ui-umc__inner {
  display: flow-root;
  padding: 16px 16px 16px;
}
.ui-umc__head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}
.ui-umc__heading {
  flex: 1 1 auto;
  min-width: min(120px, 40%);
}
.ui-umc__title {
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-umc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-umc__sub {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-umc__sep {
  margin: 0 6px;
  color: var(--ui-umc-faint);
}
.ui-umc__switch {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, auto);
  grid-auto-flow: column;
  gap: 8px;
  flex: 0 1 auto;
  min-width: 0;
}
.ui-umc__pill {
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 6px;
  background: var(--ui-umc-fill);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 320ms var(--ui-umc-ease),
    width 320ms var(--ui-umc-ease),
    height 320ms var(--ui-umc-ease),
    opacity 200ms ease;
}
.ui-umc__option {
  position: relative;
  z-index: 1;
  min-width: 0;
  height: 28px;
  padding: 4px 10px;
  overflow: hidden;
  border-radius: 6px;
  box-shadow: inset 0 0 0 0.5px var(--ui-umc-line);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-umc-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition:
    color 200ms ease,
    background-color 120ms ease;
}
.ui-umc__option[aria-checked="true"] {
  color: var(--ui-umc-ink);
}
@media (hover: hover) {
  .ui-umc__option[aria-checked="false"]:hover {
    background: var(--ui-umc-wash);
    color: var(--ui-umc-ink);
  }
}
.ui-umc__figure {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-top: 14px;
}
.ui-umc__amount {
  display: flex;
  flex-wrap: wrap;
  align-items: baseline;
  column-gap: 8px;
  min-width: 0;
}
.ui-umc__big {
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.24px;
  color: var(--ui-umc-strong);
  font-variant-numeric: tabular-nums;
}
.ui-umc__of {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-umc__pct {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-umc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-umc-text);
  font-variant-numeric: tabular-nums;
  transition:
    color 260ms ease,
    background-color 260ms ease;
}
.ui-umc__pct[data-state="warn"] {
  background: var(--ui-umc-warn-bg);
  color: var(--ui-umc-warn-text);
}
.ui-umc__pct[data-state="limit"] {
  background: var(--ui-umc-full-bg);
  color: var(--ui-umc-full-text);
}
.ui-umc__dot {
  display: inline-block;
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-umc-warn);
  animation: ui-umc-pop 420ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-umc[data-state="limit"] :is(.ui-umc__pct, .ui-umc__status) .ui-umc__dot,
.ui-umc__limit[data-state="limit"] .ui-umc__dot {
  background: var(--ui-umc-full);
}
.ui-umc__bar {
  position: relative;
  margin-top: 10px;
  padding: 4px 0;
  border-radius: 4px;
  cursor: default;
}
.ui-umc__track {
  display: flex;
  height: 8px;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-umc-track);
}
.ui-umc__seg {
  position: relative;
  flex: none;
  height: 100%;
  overflow: hidden;
  transition: opacity 200ms ease;
}
.ui-umc__seg::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 2px;
  background: var(--ui-umc-card);
}
.ui-umc__bar[data-active] .ui-umc__seg:not([data-active]) {
  opacity: 0.3;
}
.ui-umc__tip {
  position: absolute;
  bottom: calc(100% + 6px);
  z-index: 2;
  display: grid;
  gap: 2px;
  padding: 6px 10px 7px;
  border-radius: 8px;
  background: var(--ui-umc-card);
  box-shadow: var(--ui-umc-tip-shadow);
  max-width: 100%;
  white-space: nowrap;
  pointer-events: none;
  opacity: 0;
  transform: translate(var(--ui-umc-tip-x), 4px) scale(0.97);
  transition:
    left 260ms var(--ui-umc-ease),
    transform 260ms var(--ui-umc-ease),
    opacity 160ms ease;
}
.ui-umc__tip[data-open] {
  opacity: 1;
  transform: translate(var(--ui-umc-tip-x), 0);
}
.ui-umc__tip-label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
}
.ui-umc__tip-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-umc__tip-value {
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-umc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-umc__tip-value .ui-umc__muted {
  font-weight: 400;
}
.ui-umc__legend {
  display: grid;
  margin-top: 10px;
}
.ui-umc__row {
  display: grid;
  grid-template-rows: 1fr;
  animation: ui-umc-grow 380ms var(--ui-umc-ease) both;
  transition:
    grid-template-rows 320ms var(--ui-umc-ease) 80ms,
    opacity 200ms ease;
}
.ui-umc__row[data-leaving] {
  grid-template-rows: 0fr;
  opacity: 0;
  pointer-events: none;
}
.ui-umc__item {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 0;
  height: 32px;
  margin: 0 -8px;
  padding: 0 8px;
  overflow: hidden;
  border-radius: 6px;
  transition:
    background-color 120ms ease-out,
    opacity 200ms ease;
}
.ui-umc__row[data-leaving] .ui-umc__item {
  background: none;
}
.ui-umc__item[data-active] {
  background: var(--ui-umc-wash);
}
.ui-umc__legend[data-active] .ui-umc__item:not([data-active]) {
  opacity: 0.45;
}
.ui-umc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-umc__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-umc-ink);
}
.ui-umc__value {
  color: var(--ui-umc-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-umc__share {
  width: 40px;
  font-size: 12px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-umc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-umc__daily {
  margin-top: 14px;
}
.ui-umc__daily-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
  white-space: nowrap;
}
.ui-umc__daily-head > :first-child {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
}
.ui-umc__daily-read {
  font-variant-numeric: tabular-nums;
  animation: ui-umc-in 220ms var(--ui-umc-ease) both;
}
.ui-umc__spark {
  display: flex;
  align-items: stretch;
  gap: 2px;
  height: 32px;
  margin-top: 8px;
  border-radius: 4px;
  cursor: default;
}
.ui-umc__spark[data-few] {
  gap: 5px;
}
.ui-umc__spark[data-many] {
  gap: 1px;
}
.ui-umc__spark[data-many="dense"] {
  gap: 0;
}
.ui-umc__day {
  display: flex;
  flex: 1 1 0;
  align-items: flex-end;
  min-width: 0;
}
.ui-umc__day > span {
  width: 100%;
  border-radius: 2px;
  background: var(--ui-umc-spark);
  transform-origin: bottom;
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-umc__spark[data-regrow] .ui-umc__day > span {
  animation: ui-umc-rise 520ms var(--ui-umc-ease) both;
  animation-delay: calc(var(--i) * 18ms);
}
.ui-umc__day[data-future] > span {
  height: 2px;
  background: var(--ui-umc-track);
}
.ui-umc__spark[data-hover] .ui-umc__day:not([data-active]) > span {
  opacity: 0.6;
}
.ui-umc__day[data-active] > span {
  background: var(--ui-umc-accent);
}
.ui-umc__limits {
  display: grid;
  grid-template-columns: repeat(var(--n, 3), minmax(0, 1fr));
  gap: 12px 18px;
  margin-top: 16px;
  padding-top: 14px;
  border-top: 0.5px solid var(--ui-umc-line);
}
.ui-umc__limit {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-content: start;
  min-width: 0;
}
.ui-umc__limit-label {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
  white-space: nowrap;
}
.ui-umc__limit-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-umc__limit-value {
  color: var(--ui-umc-ink);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}
.ui-umc__limit-value .ui-umc__muted {
  font-weight: 400;
}
.ui-umc__thin {
  position: relative;
  display: block;
  height: 4px;
  margin-top: 6px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-umc-track);
}
.ui-umc__thin > span {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  border-radius: inherit;
  background: var(--ui-umc-accent);
  transition: background-color 260ms ease;
}
.ui-umc__limit[data-state="warn"] .ui-umc__thin > span {
  background: var(--ui-umc-warn);
}
.ui-umc__limit[data-state="limit"] .ui-umc__thin > span {
  background: var(--ui-umc-full);
}
.ui-umc__thin[data-unlimited] {
  background: repeating-linear-gradient(
    -45deg,
    var(--ui-umc-track) 0 3px,
    transparent 3px 6px
  );
}
.ui-umc__foot {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 8px 12px;
  min-height: 44px;
  padding: 6px 8px 6px 16px;
  border-top: 0.5px solid var(--ui-umc-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-umc-muted);
}
.ui-umc__status {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-umc-in 260ms var(--ui-umc-ease) both;
}
.ui-umc__status > :last-child {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-umc__action {
  display: inline-flex;
  flex: none;
  justify-content: center;
  max-width: 100%;
  height: 28px;
  margin-left: auto;
  overflow: hidden;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-umc-strong);
  background: var(--ui-umc-card);
  box-shadow: var(--ui-umc-shadow);
  transition:
    background-color 280ms ease,
    color 280ms ease,
    box-shadow 280ms ease,
    width 320ms var(--ui-umc-ease),
    transform 140ms ease;
}
.ui-umc__action:hover {
  background: #fafafa;
}
.ui-umc__action:active {
  transform: scale(0.97);
}
.ui-umc__action[data-strong] {
  background: var(--ui-umc-dark);
  color: var(--ui-umc-on-dark);
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.12);
  animation: ui-umc-nudge 520ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-umc__action[data-strong]:hover {
  background: var(--ui-umc-dark);
  opacity: 0.88;
}
.ui-umc__action-inner {
  display: inline-flex;
  align-items: center;
  flex: none;
  height: 100%;
  padding: 0 10px;
  white-space: nowrap;
}
.ui-umc__action-text {
  animation: ui-umc-in 260ms var(--ui-umc-ease) both;
}
.ui-umc__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-umc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-umc-grow {
  from {
    grid-template-rows: 0fr;
    opacity: 0;
  }
  to {
    grid-template-rows: 1fr;
    opacity: 1;
  }
}
@keyframes ui-umc-rise {
  from {
    transform: scaleY(0);
  }
  to {
    transform: none;
  }
}
@keyframes ui-umc-pop {
  0% {
    transform: scale(0.3);
  }
  60% {
    transform: scale(1.25);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-umc-nudge {
  0% {
    transform: scale(0.94);
  }
  60% {
    transform: scale(1.04);
  }
  100% {
    transform: scale(1);
  }
}
@container (max-width: 400px) {
  .ui-umc__inner {
    padding: 14px 14px 14px;
  }
  .ui-umc__foot {
    padding: 6px 8px 6px 14px;
  }
  .ui-umc__head {
    flex-direction: column;
    align-items: stretch;
    gap: 12px;
  }
  .ui-umc__switch {
    grid-auto-columns: minmax(0, auto);
    gap: 4px;
  }
  .ui-umc__option {
    padding: 4px 8px;
  }
  .ui-umc__limits {
    grid-template-columns: minmax(0, 1fr);
    gap: 12px;
  }
  .ui-umc__limit {
    grid-template-columns: minmax(0, 1fr) fit-content(60%);
    column-gap: 12px;
  }
  .ui-umc__limit-value {
    font-size: 12px;
    line-height: 16px;
    text-align: end;
  }
  .ui-umc__thin {
    grid-column: 1 / -1;
    margin-top: 6px;
  }
}
@container (max-width: 300px) {
  .ui-umc__option {
    padding: 4px 6px;
  }
  .ui-umc__share {
    width: 34px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-umc__option {
    height: 34px;
    padding: 7px 10px;
  }
  .ui-umc__item {
    height: 36px;
  }
  .ui-umc__action {
    height: 36px;
  }
  .ui-umc__foot {
    min-height: 52px;
  }
  .ui-umc__bar {
    padding: 10px 0;
    margin-top: 4px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-umc *,
  .ui-umc *::before,
  .ui-umc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-umc {
  --ui-umc-card: #1c1c1e;
  --ui-umc-strong: #ffffff;
  --ui-umc-ink: rgba(255, 255, 255, 0.9);
  --ui-umc-text: rgba(255, 255, 255, 0.62);
  --ui-umc-muted: rgba(255, 255, 255, 0.46);
  --ui-umc-faint: rgba(255, 255, 255, 0.3);
  --ui-umc-line: rgba(255, 255, 255, 0.08);
  --ui-umc-wash: rgba(255, 255, 255, 0.04);
  --ui-umc-fill: rgba(255, 255, 255, 0.08);
  --ui-umc-track: rgba(255, 255, 255, 0.08);
  --ui-umc-spark: rgba(255, 255, 255, 0.16);
  --ui-umc-accent: #4d8dff;
  --ui-umc-warn: #f0b43a;
  --ui-umc-warn-text: #f0b43a;
  --ui-umc-warn-bg: rgba(232, 162, 12, 0.16);
  --ui-umc-full: #ff6b70;
  --ui-umc-full-text: #ff8a8e;
  --ui-umc-full-bg: rgba(229, 72, 77, 0.14);
  --ui-umc-c1: #4d8dff;
  --ui-umc-c2: rgba(77, 141, 255, 0.62);
  --ui-umc-c3: rgba(77, 141, 255, 0.4);
  --ui-umc-c4: rgba(77, 141, 255, 0.22);
  --ui-umc-c5: rgba(255, 255, 255, 0.16);
  --ui-umc-dark: rgba(255, 255, 255, 0.9);
  --ui-umc-on-dark: #111113;
  --ui-umc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-umc-tip-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 8px 20px -8px rgba(0, 0, 0, 0.6);
  --ui-umc-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-umc__action:hover {
  background: #232326;
}
:where(.dark, [data-theme="dark"]) .ui-umc__tip {
  background: #2a2a2d;
}
`;export{n as default};
