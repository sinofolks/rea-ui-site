const n=`.ui-vo {
  --ui-vo-ink: #171717;
  --ui-vo-muted: #8f8f8f;
  --ui-vo-accent: #2f6bff;
  --ui-vo-focus: rgba(23, 23, 23, 0.22);
  display: inline-grid;
  justify-items: center;
  gap: 2px;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  color: var(--ui-vo-ink);
  -webkit-font-smoothing: antialiased;
  -webkit-tap-highlight-color: transparent;
}
button.ui-vo {
  border-radius: 24px;
  cursor: pointer;
}
button.ui-vo:focus-visible {
  outline: 2px solid var(--ui-vo-focus);
  outline-offset: 4px;
}
.ui-vo__canvas {
  display: block;
  width: var(--ui-vo-size);
  height: var(--ui-vo-size);
  color: var(--ui-vo-ink);
  transition: transform 500ms cubic-bezier(0.32, 0.72, 0.24, 1);
}
button.ui-vo:active .ui-vo__canvas {
  transform: scale(0.97);
}
.ui-vo__label {
  max-width: max(var(--ui-vo-size), 120px);
  height: 20px;
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-vo-muted);
  white-space: nowrap;
}
.ui-vo__label > span {
  max-width: 100%;
}
.ui-vo__label > span {
  display: inline-flex;
  align-items: baseline;
  gap: 1px;
  animation: ui-vo-in 360ms cubic-bezier(0.32, 0.72, 0.24, 1) both;
}
.ui-vo[data-state="listening"] .ui-vo__label,
.ui-vo[data-state="speaking"] .ui-vo__label {
  color: var(--ui-vo-ink);
}
.ui-vo__dots {
  display: inline-flex;
  gap: 2px;
  margin-left: 2px;
}
.ui-vo__dots i {
  width: 2.5px;
  height: 2.5px;
  border-radius: 50%;
  background: currentColor;
  animation: ui-vo-blink 1.2s ease-in-out infinite;
}
.ui-vo__dots i:nth-child(2) {
  animation-delay: 0.16s;
}
.ui-vo__dots i:nth-child(3) {
  animation-delay: 0.32s;
}
@keyframes ui-vo-in {
  from {
    opacity: 0;
    transform: translateY(5px);
    filter: blur(3px);
  }
}
@keyframes ui-vo-blink {
  0%,
  100% {
    opacity: 0.25;
  }
  40% {
    opacity: 1;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-vo *,
  .ui-vo *::before,
  .ui-vo *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-vo {
  --ui-vo-ink: #ededed;
  --ui-vo-muted: #8b8b92;
  --ui-vo-accent: #6f9bff;
  --ui-vo-focus: rgba(255, 255, 255, 0.3);
}

.vo-demo {
  justify-items: center;
  gap: 22px;
  width: 100%;
  display: grid;
}
.card__preview .vo-demo {
  align-content: center;
  position: absolute;
  inset: 34px 0 0;
}
.card__preview .vo-demo__states {
  display: none;
}
.card__preview .vo-demo .ui-vo {
  zoom: 0.72;
}
.stage:has(.vo-demo) {
  height: 480px;
}
@media (width<=760px) {
  .vo-demo__states button {
    height: 28px;
    padding: 0 8px;
    font-size: 12px;
  }
  .stage:has(.vo-demo) {
    height: 520px;
    padding: 120px 16px 24px;
  }
}
`;export{n as default};
