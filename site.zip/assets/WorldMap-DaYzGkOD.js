const n=`.ui-wm {
  --ui-wm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 540 / 242;
}
.ui-wm-map,
.ui-wm-art {
  position: absolute;
  inset: 0;
  display: block;
  width: 100%;
  height: 100%;
}
.ui-wm-band {
  animation: ui-wm-travel 14s linear infinite;
}
.ui-wm-band--1 {
  animation-delay: -0.42s;
}
.ui-wm-band--2 {
  animation-delay: -0.84s;
}
@keyframes ui-wm-travel {
  from {
    stroke-dashoffset: 0;
  }
  to {
    stroke-dashoffset: -1000;
  }
}
.ui-wm-layer {
  transform-box: view-box;
}
.ui-wm-layer[data-phase="enter"] {
  animation: ui-wm-in 520ms var(--ui-wm-ease) both;
}
.ui-wm-layer[data-phase="exit"] {
  animation: ui-wm-out 320ms cubic-bezier(0.4, 0, 1, 1) both;
}
@keyframes ui-wm-in {
  from {
    opacity: 0;
    transform: scale(0.94);
  }
}
@keyframes ui-wm-out {
  to {
    opacity: 0;
  }
}
.ui-wm-switch {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 1;
  padding: 12px;
  transform: scale(var(--ui-wm-s, 1));
  transform-origin: 0 0;
  font-family: inherit;
  -webkit-font-smoothing: antialiased;
}
.ui-wm-trigger {
  display: flex;
  align-items: center;
  gap: 4px;
  height: 28px;
  margin: 0;
  padding: 0 8px 0 12px;
  border: 1px solid #e5e5e5;
  border-radius: 999px;
  background: #ffffff;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  color: #171717;
  font: inherit;
  font-size: 13px;
  font-weight: 500;
  line-height: 1;
  white-space: nowrap;
  cursor: pointer;
  transition: transform 160ms var(--ui-wm-ease);
}
.ui-wm-trigger:active {
  transform: scale(0.96);
}
.ui-wm-trigger:focus-visible {
  outline: 2px solid #a8b5ff;
  outline-offset: 2px;
}
.ui-wm-chevron {
  width: 14px;
  height: 14px;
  transition: transform 220ms var(--ui-wm-ease);
}
.ui-wm-trigger[aria-expanded="true"] .ui-wm-chevron {
  transform: rotate(180deg);
}
.ui-wm-menu {
  --morph: 420ms cubic-bezier(0.32, 0.72, 0, 1);
  position: absolute;
  top: calc(12px + 28px + 6px);
  left: 12px;
  width: 172px;
  filter: drop-shadow(0 6px 12px rgba(0, 0, 0, 0.08))
    drop-shadow(0 1px 2.5px rgba(0, 0, 0, 0.05));
  transition: visibility 0s linear 0s;
}
.ui-wm-menu[data-open="false"] {
  visibility: hidden;
  pointer-events: none;
  transition: visibility 0s linear 300ms;
}
.ui-wm-panel {
  position: relative;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  padding: 5px;
  background: #ffffff;
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  outline: none;
  clip-path: inset(0 0 0 0 round 16px);
  transition: clip-path var(--morph);
}
.ui-wm-menu[data-open="false"] .ui-wm-panel {
  clip-path: inset(
    0 calc(100% - var(--from-w)) calc(100% - var(--from-h)) 0 round
      calc(var(--from-h) / 2)
  );
  transition: clip-path 300ms cubic-bezier(0.4, 0, 0.2, 1);
}
.ui-wm-panel > * {
  transition:
    opacity 220ms ease-out 110ms,
    transform 380ms var(--ui-wm-ease) 60ms;
}
.ui-wm-menu[data-open="false"] .ui-wm-panel > * {
  opacity: 0;
  transition: opacity 120ms ease-in;
}
.ui-wm-menu[data-open="false"] .ui-wm-option {
  transform: translateY(-4px);
}
.ui-wm-fill {
  position: absolute;
  top: 0;
  left: 5px;
  right: 5px;
  border-radius: 10px;
  background: #f5f5f5;
  pointer-events: none;
  transition:
    transform 190ms cubic-bezier(0.25, 1, 0.3, 1),
    height 190ms cubic-bezier(0.25, 1, 0.3, 1),
    opacity 160ms ease-out;
}
.ui-wm-fill[data-glide="false"] {
  transition: opacity 160ms ease-out;
}
.ui-wm-option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 7px 8px 7px 10px;
  border-radius: 10px;
  color: #171717;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  cursor: pointer;
}
.ui-wm-option-name {
  flex: 1;
  min-width: 0;
  white-space: nowrap;
}
.ui-wm-check {
  flex: none;
  width: 15px;
  height: 15px;
  opacity: 0;
  transform: scale(0.6);
  transition:
    opacity 160ms ease-out,
    transform 260ms cubic-bezier(0.34, 1.5, 0.64, 1);
}
.ui-wm-check svg {
  display: block;
  width: 100%;
  height: 100%;
}
.ui-wm-option[aria-selected="true"] .ui-wm-check {
  opacity: 1;
  transform: none;
}
@media (prefers-reduced-motion: reduce) {
  .ui-wm-band,
  .ui-wm-layer {
    animation: none !important;
  }
  .ui-wm-layer[data-phase="exit"] {
    display: none;
  }
  .ui-wm-panel,
  .ui-wm-panel > *,
  .ui-wm-fill,
  .ui-wm-check,
  .ui-wm-chevron {
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-wm-land {
  fill: #2a2a2d;
  stroke: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-wm-focus {
  fill: #46464c;
  stroke: rgba(255, 255, 255, 0.12);
}
:where(.dark, [data-theme="dark"]) .ui-wm-drop {
  flood-color: #000000;
  flood-opacity: 0.45;
}
:where(.dark, [data-theme="dark"]) .ui-wm-trigger {
  border-color: rgba(255, 255, 255, 0.08);
  background: #232326;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
  color: #ededed;
}
:where(.dark, [data-theme="dark"]) .ui-wm-chevron-ink {
  stroke: #8f8f8f;
}
:where(.dark, [data-theme="dark"]) .ui-wm-menu {
  filter: drop-shadow(0 6px 12px rgba(0, 0, 0, 0.4))
    drop-shadow(0 1px 2.5px rgba(0, 0, 0, 0.35));
}
:where(.dark, [data-theme="dark"]) .ui-wm-panel {
  background: #232326;
  border-color: rgba(255, 255, 255, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-wm-fill {
  background: #2a2a2d;
}
:where(.dark, [data-theme="dark"]) .ui-wm-option {
  color: #ededed;
}

.world-map-demo {
  width: 100%;
}
.stage .world-map-demo {
  width: min(100%, 560px);
}
.card__preview .world-map-demo {
  place-items: center;
  width: auto;
  display: grid;
  position: absolute;
  inset: 0;
}
.card__preview .world-map-demo .ui-wm {
  width: 94%;
}
.card__preview .world-map-demo .ui-wm-switch {
  top: 16px;
}
`;export{n as default};
