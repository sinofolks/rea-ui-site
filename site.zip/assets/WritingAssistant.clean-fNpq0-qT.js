const n=`.ui-wac {
  --ui-wac-card: #ffffff;
  --ui-wac-strong: #000000;
  --ui-wac-ink: rgba(0, 0, 0, 0.88);
  --ui-wac-text: rgba(0, 0, 0, 0.65);
  --ui-wac-muted: rgba(0, 0, 0, 0.65);
  --ui-wac-faint: rgba(0, 0, 0, 0.65);
  --ui-wac-icon: rgba(0, 0, 0, 0.65);
  --ui-wac-line: rgba(0, 0, 0, 0.06);
  --ui-wac-fill: rgba(0, 0, 0, 0.06);
  --ui-wac-wash: rgba(0, 0, 0, 0.03);
  --ui-wac-solid: rgba(0, 0, 0, 0.88);
  --ui-wac-on-solid: #fcfcfc;
  --ui-wac-accent: #0060e2;
  --ui-wac-accent-wash: rgba(0, 96, 226, 0.08);
  --ui-wac-accent-ring: rgba(0, 96, 226, 0.22);
  --ui-wac-shine: rgba(255, 255, 255, 0.82);
  --ui-wac-pink: #ec4899;
  --ui-wac-violet: #8b5cf6;
  --ui-wac-blue: #2f6bff;
  --ui-wac-glow: 0.13;
  --ui-wac-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-wac-focus: rgba(0, 96, 226, 0.7);
  --ui-wac-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: flex;
  flex-direction: column;
  width: 100%;
  max-width: 380px;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-wac-card);
  box-shadow: var(--ui-wac-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-wac-ink);
  -webkit-font-smoothing: antialiased;
  -webkit-tap-highlight-color: transparent;
}
.ui-wac *,
.ui-wac *::before,
.ui-wac *::after {
  box-sizing: border-box;
}
:where(.ui-wac) button {
  appearance: none;
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
:where(.ui-wac) svg {
  display: block;
  flex: none;
}
.ui-wac button:focus-visible {
  outline: 2px solid var(--ui-wac-focus);
  outline-offset: 2px;
}
.ui-wac__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 12px 12px 16px;
  border-bottom: 0.5px solid var(--ui-wac-line);
}
.ui-wac__id {
  min-width: 0;
}
.ui-wac__name {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-wac-strong);
}
.ui-wac__mark {
  width: 16px;
  height: 16px;
}
.ui-wac__name-text {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-wac__tagline {
  margin: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-wac-text);
}
.ui-wac__new {
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-wac-icon);
  opacity: 0;
  transform: scale(0.8);
  pointer-events: none;
  transition:
    opacity 220ms ease,
    transform 320ms var(--ui-wac-ease),
    background-color 160ms ease,
    color 160ms ease;
}
.ui-wac[data-chat] .ui-wac__new {
  opacity: 1;
  transform: none;
  pointer-events: auto;
}
.ui-wac__new:hover {
  background: var(--ui-wac-wash);
  color: var(--ui-wac-ink);
}
.ui-wac__new svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
}
.ui-wac__body {
  position: relative;
  display: flex;
  flex-direction: column;
  height: 340px;
  overflow: hidden;
}
.ui-wac__content {
  position: relative;
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  overflow: hidden;
}
.ui-wac__glow {
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: 1;
  transition: opacity 600ms ease;
}
.ui-wac[data-chat] .ui-wac__glow {
  opacity: 0.4;
}
.ui-wac__blob {
  position: absolute;
  border-radius: 50%;
  filter: blur(36px);
  opacity: var(--ui-wac-glow);
  animation: ui-wac-drift-a 6s ease-in-out infinite alternate;
}
.ui-wac__blob--pink {
  left: -18%;
  top: 54%;
  width: 58%;
  height: 40%;
  background: var(--ui-wac-pink);
}
.ui-wac__blob--violet {
  right: -16%;
  top: 46%;
  width: 54%;
  height: 42%;
  background: var(--ui-wac-violet);
  animation-name: ui-wac-drift-b;
  animation-duration: 7s;
}
.ui-wac__blob--blue {
  left: 22%;
  bottom: -22%;
  width: 62%;
  height: 40%;
  background: var(--ui-wac-blue);
  animation-name: ui-wac-drift-c;
  animation-duration: 5.5s;
}
.ui-wac__welcome {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 12px;
  padding: 16px;
  animation: ui-wac-in 380ms var(--ui-wac-ease) both;
}
.ui-wac__greeting {
  margin: 0;
  overflow-wrap: anywhere;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-wac-strong);
}
.ui-wac__chips {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}
.ui-wac__chip {
  padding: 4px 10px;
  border-radius: 6px;
  background: color-mix(in srgb, var(--ui-wac-card) 70%, transparent);
  box-shadow: inset 0 0 0 0.5px var(--ui-wac-line);
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--ui-wac-text);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms var(--ui-wac-ease);
}
.ui-wac__chip:hover {
  background:
    linear-gradient(var(--ui-wac-wash), var(--ui-wac-wash)),
    color-mix(in srgb, var(--ui-wac-card) 70%, transparent);
  color: var(--ui-wac-ink);
}
.ui-wac__chip:active {
  transform: scale(0.97);
}
.ui-wac__messages {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
  padding: 16px 16px 14px;
  overflow-y: auto;
  scrollbar-width: none;
  -webkit-mask-image: linear-gradient(
    transparent,
    #000 16px,
    #000 calc(100% - 12px),
    transparent
  );
  mask-image: linear-gradient(
    transparent,
    #000 16px,
    #000 calc(100% - 12px),
    transparent
  );
}
.ui-wac__messages::-webkit-scrollbar {
  display: none;
}
.ui-wac__msg {
  max-width: 86%;
  margin: 0;
  font-size: 13px;
  line-height: 20px;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  color: var(--ui-wac-ink);
  animation: ui-wac-in 320ms var(--ui-wac-ease) both;
}
.ui-wac__msg--user {
  align-self: flex-end;
  padding: 6px 10px;
  border-radius: 10px;
  background: var(--ui-wac-fill);
}
.ui-wac__msg--assistant {
  align-self: flex-start;
  max-width: 94%;
}
.ui-wac__typing {
  color: var(--ui-wac-muted);
}
.ui-wac__shimmer {
  position: relative;
  display: inline-block;
}
.ui-wac__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-wac-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-wac-sweep 1.3s linear infinite;
  pointer-events: none;
}
.ui-wac__row {
  position: relative;
  flex: none;
  display: flex;
  align-items: flex-end;
  gap: 4px;
  margin: 0;
  padding: 6px 10px 10px 16px;
}
.ui-wac__field {
  flex: 1;
  min-width: 0;
  display: flex;
  margin-right: 4px;
}
.ui-wac__field textarea {
  display: block;
  flex: 1;
  min-width: 0;
  height: 28px;
  margin: 0;
  padding: 4px 0;
  border: 0;
  background: none;
  outline: none;
  resize: none;
  font: inherit;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-wac-strong);
  caret-color: var(--ui-wac-accent);
  overflow-y: auto;
  scrollbar-width: none;
  -webkit-mask-image: linear-gradient(transparent, #000 4px);
  mask-image: linear-gradient(transparent, #000 4px);
}
.ui-wac__field textarea::-webkit-scrollbar {
  display: none;
}
.ui-wac__field textarea::placeholder {
  color: var(--ui-wac-faint);
  opacity: 1;
}
.ui-wac__field[data-listening] textarea {
  color: var(--ui-wac-text);
}
.ui-wac__send {
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: var(--ui-wac-solid) !important;
  color: var(--ui-wac-on-solid);
  transition:
    transform 160ms var(--ui-wac-ease),
    opacity 160ms ease;
  animation: ui-wac-pop 280ms var(--ui-wac-ease) both;
}
.ui-wac__send:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-wac__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-wac__send svg {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-wac__mic {
  position: relative;
  display: grid;
  place-items: center;
  flex: none;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-wac-icon);
  transition:
    background-color 200ms ease,
    color 160ms ease,
    transform 160ms var(--ui-wac-ease);
}
.ui-wac__mic:not(:disabled):hover {
  background: var(--ui-wac-wash);
  color: var(--ui-wac-ink);
}
.ui-wac__mic:not(:disabled):active {
  transform: scale(0.94);
}
.ui-wac__mic:disabled {
  opacity: 0.5;
  cursor: default;
}
.ui-wac__mic svg {
  position: relative;
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-wac__mic[data-listening],
.ui-wac__mic[data-listening]:hover {
  background: var(--ui-wac-accent-wash);
  color: var(--ui-wac-accent);
}
.ui-wac__pulse {
  position: absolute;
  inset: 0;
  border-radius: 6px;
  opacity: 0;
}
.ui-wac__mic[data-listening] .ui-wac__pulse {
  opacity: 1;
  animation: ui-wac-ring 1.6s ease-out infinite;
}
.ui-wac__wave {
  position: relative;
  display: flex;
  align-items: center;
  gap: 2px;
  height: 12px;
}
.ui-wac__wave i {
  width: 2px;
  height: 100%;
  border-radius: 1px;
  background: currentColor;
  transform: scaleY(0.35);
  animation: ui-wac-wave 1.1s ease-in-out infinite;
}
.ui-wac__wave i:nth-child(2) {
  animation-delay: -0.35s;
}
.ui-wac__wave i:nth-child(3) {
  animation-delay: -0.7s;
}
@keyframes ui-wac-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
}
@keyframes ui-wac-pop {
  from {
    opacity: 0;
    transform: scale(0.6);
  }
}
@keyframes ui-wac-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@keyframes ui-wac-ring {
  0% {
    box-shadow: 0 0 0 0 var(--ui-wac-accent-ring);
  }
  100% {
    box-shadow: 0 0 0 7px transparent;
  }
}
@keyframes ui-wac-wave {
  0%,
  100% {
    transform: scaleY(0.35);
  }
  50% {
    transform: scaleY(1);
  }
}
@keyframes ui-wac-drift-a {
  0% {
    transform: translate(0, 0) scale(1);
  }
  50% {
    transform: translate(55%, -22%) scale(1.25);
  }
  100% {
    transform: translate(20%, 14%) scale(0.85);
  }
}
@keyframes ui-wac-drift-b {
  0% {
    transform: translate(0, 0) scale(1);
  }
  50% {
    transform: translate(-55%, 24%) scale(0.85);
  }
  100% {
    transform: translate(-22%, -16%) scale(1.25);
  }
}
@keyframes ui-wac-drift-c {
  0% {
    transform: translate(0, 0) scale(1);
  }
  50% {
    transform: translate(-45%, -26%) scale(1.2);
  }
  100% {
    transform: translate(30%, -10%) scale(0.88);
  }
}
@container (max-width: 330px) {
  .ui-wac__head {
    padding-left: 12px;
  }
  .ui-wac__welcome,
  .ui-wac__messages {
    padding-left: 12px;
    padding-right: 12px;
  }
  .ui-wac__row {
    padding-left: 12px;
  }
}
@media (pointer: coarse) {
  .ui-wac__new,
  .ui-wac__mic,
  .ui-wac__send {
    width: 34px;
    height: 34px;
  }
  .ui-wac__chip {
    padding: 7px 12px;
  }
  .ui-wac__field textarea {
    padding: 7px 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-wac__blob,
  .ui-wac__welcome,
  .ui-wac__msg,
  .ui-wac__send,
  .ui-wac__mic[data-listening] .ui-wac__pulse,
  .ui-wac__wave i,
  .ui-wac__shimmer::after {
    animation: none;
  }
  .ui-wac__wave i {
    transform: scaleY(0.7);
  }
}
.ui-wac input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-wac textarea:focus-visible,
.ui-wac [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-wac {
  --ui-wac-card: #1c1c1e;
  --ui-wac-strong: #ffffff;
  --ui-wac-ink: rgba(255, 255, 255, 0.9);
  --ui-wac-text: rgba(255, 255, 255, 0.62);
  --ui-wac-muted: rgba(255, 255, 255, 0.46);
  --ui-wac-faint: rgba(255, 255, 255, 0.3);
  --ui-wac-icon: rgba(255, 255, 255, 0.5);
  --ui-wac-line: rgba(255, 255, 255, 0.08);
  --ui-wac-fill: rgba(255, 255, 255, 0.08);
  --ui-wac-wash: rgba(255, 255, 255, 0.04);
  --ui-wac-solid: rgba(255, 255, 255, 0.92);
  --ui-wac-on-solid: #161618;
  --ui-wac-accent: #4d8dff;
  --ui-wac-accent-wash: rgba(77, 141, 255, 0.14);
  --ui-wac-accent-ring: rgba(77, 141, 255, 0.3);
  --ui-wac-shine: #ffffff;
  --ui-wac-pink: #f472b6;
  --ui-wac-violet: #a78bfa;
  --ui-wac-blue: #4d82ff;
  --ui-wac-glow: 0.14;
  --ui-wac-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-wac-focus: rgba(77, 141, 255, 0.8);
}
`;export{n as default};
