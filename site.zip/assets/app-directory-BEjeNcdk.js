const e=`"use client";

import "./AppDirectory.css";
// Copyable component. Keep its sibling CSS file in the same folder.
// Generated from the maintained TSX sources; regenerate with npm run generate:standalone.
import * as React from "react";
import type { ReactElement } from "react";
import * as React_jsx_runtime_CTsRTJUX from "react/jsx-runtime";
/** Explicit migration boundary for values whose original types were erased.
 * Keep this alias private. Replace usages with concrete types as internals are refactored.
 * Public component contracts never expose this type. See docs/type-migration.md.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type RecoveredValue = any;
const t_react_BkAXpnfr: RecoveredValue = (): RecoveredValue => React;
const t_jsx_runtime_CTsRTJUX: RecoveredValue = (): RecoveredValue =>
  React_jsx_runtime_CTsRTJUX;
var n_demo_Ctokv7Xz: RecoveredValue = t_react_BkAXpnfr(),
  r_demo_Ctokv7Xz: RecoveredValue = t_jsx_runtime_CTsRTJUX(),
  i_demo_Ctokv7Xz: RecoveredValue = (e?: RecoveredValue): RecoveredValue =>
    new Intl.NumberFormat().format(e),
  a_demo_Ctokv7Xz: RecoveredValue = (e?: RecoveredValue): RecoveredValue =>
    ((Array.from(e.trim()) as RecoveredValue[])[0] ?? \`?\`).toLocaleUpperCase(),
  ComponentO: RecoveredValue = ({ app }: RecoveredValue): RecoveredValue =>
    app.logo != null && app.logo !== !1 ? (
      <r_demo_Ctokv7Xz.Fragment>{app.logo}</r_demo_Ctokv7Xz.Fragment>
    ) : (
      <span className={\`ui-ad__tile-initial\`}>{a_demo_Ctokv7Xz(app.name)}</span>
    );
function ComponentS({
  title = \`Integrations\`,
  subtitle = \`Connect the tools your team already works in.\`,
  apps = b,
  categories = v,
  onToggle,
  className,
}: RecoveredValue): RecoveredValue {
  let [g, _]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(
      (): RecoveredValue =>
        new Set(
          apps
            .filter((e?: RecoveredValue): RecoveredValue => e.connected)
            .map((e?: RecoveredValue): RecoveredValue => e.id),
        ),
    ),
    [y, C]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(new Set()),
    [w, T]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(\`essentials\`),
    [E, D]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(\`\`),
    [O, k]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(\`all\`),
    [A, j]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(!1),
    M: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null),
    N: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null),
    P: RecoveredValue = (0, n_demo_Ctokv7Xz.useId)(),
    F: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null),
    I: RecoveredValue = x(F);
  (0, n_demo_Ctokv7Xz.useEffect)((): RecoveredValue => {
    if (!A) return;
    let e: RecoveredValue = (e?: RecoveredValue): RecoveredValue =>
        !M.current?.contains(e.target) && j(!1),
      t: RecoveredValue = (e?: RecoveredValue): RecoveredValue => {
        e.key === \`Escape\` && (j(!1), N.current?.focus());
      },
      n: RecoveredValue = L();
    return (
      (
        n.find(
          (e?: RecoveredValue): RecoveredValue =>
            e.getAttribute(\`aria-checked\`) === \`true\`,
        ) ?? n[0]
      )?.focus(),
      window.addEventListener(\`pointerdown\`, e),
      window.addEventListener(\`keydown\`, t),
      (): RecoveredValue => {
        (window.removeEventListener(\`pointerdown\`, e),
          window.removeEventListener(\`keydown\`, t));
      }
    );
  }, [A]);
  let L: RecoveredValue = (): RecoveredValue =>
      Array.from(
        M.current?.querySelectorAll(\`[role="menuitemradio"]\`) ?? [],
      ) as RecoveredValue[],
    R: RecoveredValue = (e?: RecoveredValue): RecoveredValue => {
      let t: RecoveredValue = L(),
        n: RecoveredValue = t.indexOf(document.activeElement as HTMLElement),
        r: RecoveredValue = t.length - 1,
        i: RecoveredValue =
          e.key === \`ArrowDown\`
            ? n < r
              ? n + 1
              : 0
            : e.key === \`ArrowUp\`
              ? n > 0
                ? n - 1
                : r
              : e.key === \`Home\`
                ? 0
                : e.key === \`End\`
                  ? r
                  : -1;
      i >= 0 ? (e.preventDefault(), t[i]?.focus()) : e.key === \`Tab\` && j(!1);
    },
    z: RecoveredValue = (e?: RecoveredValue, t?: RecoveredValue): RecoveredValue =>
      t === \`all\` ? !0 : t === \`essentials\` ? !!e.essential : e.categories.includes(t),
    B: RecoveredValue = E.trim().toLowerCase(),
    V: RecoveredValue = (0, n_demo_Ctokv7Xz.useMemo)(
      (): RecoveredValue =>
        apps.filter(
          (e?: RecoveredValue): RecoveredValue =>
            !(
              (B &&
                !\`\${e.name} \${e.vendor} \${e.description}\`.toLowerCase().includes(B)) ||
              (!B && !z(e, w)) ||
              (O === \`connected\` && !g.has(e.id)) ||
              (O === \`available\` && g.has(e.id))
            ),
        ),
      [apps, B, w, O, g],
    ),
    H: RecoveredValue = (e?: RecoveredValue): RecoveredValue => {
      if (!y.has(e.id)) {
        if (g.has(e.id)) {
          let t: RecoveredValue = new Set(g);
          (t.delete(e.id), _(t), onToggle?.(e, !1));
          return;
        }
        (C((t?: RecoveredValue): RecoveredValue => new Set(t).add(e.id)),
          window.setTimeout((): RecoveredValue => {
            (C((t?: RecoveredValue): RecoveredValue => {
              let n: RecoveredValue = new Set(t);
              return (n.delete(e.id), n);
            }),
              _((t?: RecoveredValue): RecoveredValue => new Set(t).add(e.id)),
              onToggle?.(e, !0));
          }, 900));
      }
    },
    U: RecoveredValue = B
      ? \`Results for “\${E.trim()}”\`
      : (categories.find((e?: RecoveredValue): RecoveredValue => e.id === w)?.label ??
        \`Apps\`),
    W: RecoveredValue = apps.filter((e?: RecoveredValue): RecoveredValue => !e.essential),
    G: RecoveredValue = !B && w === \`essentials\` && O === \`all\` && W.length > 0,
    K: RecoveredValue = (
      {
        all: \`All apps\`,
        connected: \`Connected\`,
        available: \`Not connected\`,
      } as Record<string, RecoveredValue>
    )[O];
  return (
    <r_demo_Ctokv7Xz.Fragment>
      <section
        className={[\`ui-ad\`, className].filter(Boolean).join(\` \`)}
        aria-label={title}
      >
        <header className={\`ui-ad__bar\`}>
          <span className={\`ui-ad__bar-title\`}>{\`Apps\`}</span>
          <span className={\`ui-ad__bar-meta\`}>
            {i_demo_Ctokv7Xz(g.size)}
            {\` connected\`}
          </span>
        </header>
        <div className={\`ui-ad__card\`}>
          <div className={\`ui-ad__intro\`}>
            <h2 className={\`ui-ad__title\`}>{title}</h2>
            <p className={\`ui-ad__subtitle\`}>
              {subtitle}
              {\` \`}
              <a
                href={\`#\`}
                className={\`ui-ad__link\`}
                onClick={(e?: RecoveredValue): RecoveredValue => e.preventDefault()}
              >
                {\`Learn more \`}
                <ComponentF />
              </a>
            </p>
          </div>
          <div className={\`ui-ad__tools\`}>
            <label className={\`ui-ad__search\`} htmlFor={P}>
              <ComponentU />
              <input
                id={P}
                type={\`search\`}
                placeholder={\`Search apps\`}
                value={E}
                onChange={(e?: RecoveredValue): RecoveredValue => D(e.target.value)}
                autoComplete={\`off\`}
              />
            </label>
            <div className={\`ui-ad__filter\`} ref={M as RecoveredValue}>
              <button
                ref={N as RecoveredValue}
                type={\`button\`}
                className={\`ui-ad__btn\`}
                aria-haspopup={\`menu\`}
                aria-expanded={A}
                data-active={O !== \`all\` || void 0}
                onClick={(): RecoveredValue =>
                  j((e?: RecoveredValue): RecoveredValue => !e)
                }
                onKeyDown={(e?: RecoveredValue): RecoveredValue => {
                  (e.key === \`ArrowDown\` || e.key === \`ArrowUp\`) &&
                    (e.preventDefault(), j(!0));
                }}
              >
                <ComponentD />
                {O === \`all\` ? \`Filter\` : K}
              </button>
              {A && (
                <div
                  className={\`ui-ad__menu\`}
                  role={\`menu\`}
                  aria-label={\`Show\`}
                  onKeyDown={R}
                >
                  {[\`all\`, \`connected\`, \`available\`].map(
                    (e?: RecoveredValue): RecoveredValue => (
                      <button
                        type={\`button\`}
                        role={\`menuitemradio\`}
                        aria-checked={O === e}
                        tabIndex={-1}
                        className={\`ui-ad__menu-item\`}
                        onClick={(): RecoveredValue => {
                          (k(e), j(!1), N.current?.focus());
                        }}
                        key={e}
                      >
                        {
                          (
                            {
                              all: \`All apps\`,
                              connected: \`Connected\`,
                              available: \`Not connected\`,
                            } as Record<string, RecoveredValue>
                          )[e]
                        }
                        {O === e && <ComponentP />}
                      </button>
                    ),
                  )}
                </div>
              )}
            </div>
          </div>
          <div className={\`ui-ad__layout\`}>
            <nav className={\`ui-ad__nav\`} aria-label={\`Categories\`}>
              {categories.map((e?: RecoveredValue): RecoveredValue => {
                let t: RecoveredValue = apps.filter(
                    (t?: RecoveredValue): RecoveredValue => z(t, e.id),
                  ).length,
                  n: RecoveredValue = !B && w === e.id;
                return (
                  <button
                    type={\`button\`}
                    className={\`ui-ad__nav-item\`}
                    aria-current={n || void 0}
                    onClick={(): RecoveredValue => {
                      (T(e.id), D(\`\`));
                    }}
                    key={e.id}
                  >
                    <span className={\`ui-ad__nav-icon\`}>{e.icon}</span>
                    <span className={\`ui-ad__nav-label\`} title={e.label}>
                      {e.label}
                    </span>
                    <span className={\`ui-ad__nav-count\`}>{i_demo_Ctokv7Xz(t)}</span>
                  </button>
                );
              })}
            </nav>
            <div className={\`ui-ad__morph\`} ref={I as RecoveredValue}>
              <div className={\`ui-ad__main\`} ref={F as RecoveredValue}>
                <h3 className={\`ui-ad__heading\`} aria-live={\`polite\`}>
                  <span className={\`ui-ad__heading-text\`} title={U}>
                    {U}
                  </span>
                  <span>{i_demo_Ctokv7Xz(V.length)}</span>
                </h3>
                {V.length === 0 ? (
                  <div className={\`ui-ad__empty\`}>
                    <p>
                      {B || O !== \`all\`
                        ? \`No apps match.\`
                        : apps.length
                          ? \`No apps in this category yet.\`
                          : \`No apps yet.\`}
                    </p>
                    {(B || O !== \`all\`) && (
                      <button
                        type={\`button\`}
                        className={\`ui-ad__btn\`}
                        onClick={(): RecoveredValue => {
                          (D(\`\`), k(\`all\`));
                        }}
                      >{\`Clear search\`}</button>
                    )}
                  </div>
                ) : (
                  <ul className={\`ui-ad__grid\`}>
                    {V.map((e?: RecoveredValue, t?: RecoveredValue): RecoveredValue => {
                      let n: RecoveredValue = g.has(e.id),
                        i: RecoveredValue = y.has(e.id);
                      return (
                        <li
                          className={\`ui-ad__app\`}
                          data-connected={n || void 0}
                          style={
                            {
                              animationDelay: \`\${Math.min(t, 12) * 30}ms\`,
                            } as RecoveredValue
                          }
                          key={e.id}
                        >
                          <div className={\`ui-ad__app-head\`}>
                            <span
                              className={\`ui-ad__tile\`}
                              data-filled={e.tile ? !0 : void 0}
                              style={
                                (e.tile
                                  ? {
                                      background: e.tile,
                                    }
                                  : void 0) as RecoveredValue
                              }
                            >
                              <ComponentO app={e} />
                            </span>
                            <span className={\`ui-ad__app-name\`}>
                              <span className={\`ui-ad__name\`}>
                                <span className={\`ui-ad__name-text\`} title={e.name}>
                                  {e.name}
                                </span>
                                <ComponentH />
                              </span>
                              {e.vendor && (
                                <span className={\`ui-ad__vendor\`} title={e.vendor}>
                                  {\`By \`}
                                  {e.vendor}
                                </span>
                              )}
                            </span>
                          </div>
                          <p className={\`ui-ad__desc\`} title={e.description || void 0}>
                            {e.description}
                          </p>
                          <ComponentC
                            name={e.name}
                            state={i ? \`busy\` : n ? \`on\` : \`off\`}
                            onClick={(): RecoveredValue => H(e)}
                          />
                        </li>
                      );
                    })}
                    {G && (
                      <li className={\`ui-ad__app ui-ad__discover\`}>
                        <div className={\`ui-ad__discover-head\`}>
                          <span>
                            <span className={\`ui-ad__name\`}>{\`Discover more\`}</span>
                            <span className={\`ui-ad__vendor\`}>
                              {\`+\`}
                              {i_demo_Ctokv7Xz(W.length)}
                              {\` \`}
                              {W.length === 1 ? \`app\` : \`apps\`}
                            </span>
                          </span>
                          <span className={\`ui-ad__stack\`} aria-hidden={\`true\`}>
                            {W.slice(0, 3).map(
                              (e?: RecoveredValue): RecoveredValue => (
                                <span
                                  className={\`ui-ad__tile\`}
                                  data-filled={e.tile ? !0 : void 0}
                                  style={
                                    (e.tile
                                      ? {
                                          background: e.tile,
                                        }
                                      : void 0) as RecoveredValue
                                  }
                                  children={<ComponentO app={e} />}
                                  key={e.id}
                                />
                              ),
                            )}
                          </span>
                        </div>
                        <button
                          type={\`button\`}
                          className={\`ui-ad__btn\`}
                          onClick={(): RecoveredValue => T(\`all\`)}
                        >{\`View all\`}</button>
                      </li>
                    )}
                  </ul>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </r_demo_Ctokv7Xz.Fragment>
  );
}
function ComponentC({ name, state, onClick }: RecoveredValue): RecoveredValue {
  let a: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null),
    o: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null);
  (0, n_demo_Ctokv7Xz.useLayoutEffect)((): RecoveredValue => {
    let e: RecoveredValue = a.current,
      t: RecoveredValue = o.current;
    if (!e || !t) return;
    let n: RecoveredValue =
        parseFloat(getComputedStyle(e).paddingLeft) +
        parseFloat(getComputedStyle(e).paddingRight),
      r: RecoveredValue = (): RecoveredValue => {
        e.style.width = \`\${t.offsetWidth + n}px\`;
      };
    r();
    let i: RecoveredValue = new ResizeObserver(r);
    i.observe(t);
    let s: RecoveredValue = requestAnimationFrame(
      (): RecoveredValue => e.setAttribute(\`data-smooth\`, \`\`),
    );
    return (): RecoveredValue => {
      (i.disconnect(), cancelAnimationFrame(s));
    };
  }, []);
  let [s, c]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(!1);
  return (
    (0, n_demo_Ctokv7Xz.useEffect)((): RecoveredValue => {
      if (!s) return;
      let e: RecoveredValue = setTimeout((): RecoveredValue => c(!1), 3e3);
      return (): RecoveredValue => clearTimeout(e);
    }, [s]),
    (
      <button
        ref={a as RecoveredValue}
        type={\`button\`}
        className={\`ui-ad__connect\`}
        data-state={state}
        data-armed={s || void 0}
        aria-label={
          s
            ? \`Tap again to disconnect \${name}\`
            : \`\${state === \`on\` ? \`Disconnect\` : \`Connect\`} \${name}\`
        }
        onClick={(): RecoveredValue => {
          if (state === \`on\` && !s && window.matchMedia(\`(hover: none)\`).matches)
            return c(!0);
          (c(!1), onClick());
        }}
        onBlur={(): RecoveredValue => c(!1)}
      >
        <span ref={o as RecoveredValue} className={\`ui-ad__connect-label\`}>
          {state === \`busy\` ? (
            <r_demo_Ctokv7Xz.Fragment>
              <ComponentG />
              {\` Connecting…\`}
            </r_demo_Ctokv7Xz.Fragment>
          ) : state === \`on\` ? (
            <r_demo_Ctokv7Xz.Fragment>
              <ComponentM />
              {\` \`}
              <span className={\`ui-ad__on-label\`}>{\`Connected\`}</span>
              <span className={\`ui-ad__off-label\`}>{\`Disconnect\`}</span>
            </r_demo_Ctokv7Xz.Fragment>
          ) : (
            \`Connect\`
          )}
        </span>
      </button>
    )
  );
}
var l: RecoveredValue = (e?: RecoveredValue, t: RecoveredValue = 16): RecoveredValue => (
    <svg
      viewBox={\`0 0 16 16\`}
      width={t}
      height={t}
      fill={\`none\`}
      stroke={\`currentColor\`}
      strokeWidth={\`1.3\`}
      strokeLinecap={\`round\`}
      strokeLinejoin={\`round\`}
      aria-hidden={\`true\`}
    >
      <path d={e} />
    </svg>
  ),
  ComponentU: RecoveredValue = (): RecoveredValue =>
    l(\`M7 12.5a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11ZM11 11l3.5 3.5\`),
  ComponentD: RecoveredValue = (): RecoveredValue => l(\`M2.5 4.5h11M4.5 8h7M6.5 11.5h3\`),
  ComponentF: RecoveredValue = (): RecoveredValue => l(\`M5 11 11 5M6 5h5v5\`, 12),
  ComponentP: RecoveredValue = (): RecoveredValue => l(\`m3.5 8.5 3 3 6-7\`, 14),
  ComponentM: RecoveredValue = (): RecoveredValue =>
    l(
      \`M6.5 9.5l3-3M7.3 4.7l.9-.9a2.5 2.5 0 0 1 3.5 3.5l-.9.9M8.7 11.3l-.9.9a2.5 2.5 0 0 1-3.5-3.5l.9-.9\`,
      14,
    ),
  ComponentH: RecoveredValue = (): RecoveredValue => (
    <svg
      className={\`ui-ad__verified\`}
      viewBox={\`0 0 16 16\`}
      width={\`15\`}
      height={\`15\`}
      role={\`img\`}
      aria-label={\`Verified\`}
    >
      <path
        d={\`M8.00 0.80 L9.55 2.20 L11.60 1.76 L12.24 3.76 L14.24 4.40 L13.80 6.45 L15.20 8.00 L13.80 9.55 L14.24 11.60 L12.24 12.24 L11.60 14.24 L9.55 13.80 L8.00 15.20 L6.45 13.80 L4.40 14.24 L3.76 12.24 L1.76 11.60 L2.20 9.55 L0.80 8.00 L2.20 6.45 L1.76 4.40 L3.76 3.76 L4.40 1.76 L6.45 2.20Z\`}
        fill={\`currentColor\`}
        stroke={\`currentColor\`}
        strokeWidth={\`1.2\`}
        strokeLinejoin={\`round\`}
      />
      <path
        d={\`m5.3 8.1 1.8 1.8 3.6-3.7\`}
        fill={\`none\`}
        stroke={\`var(--ui-ad-on-accent, #fff)\`}
        strokeWidth={\`1.5\`}
        strokeLinecap={\`round\`}
        strokeLinejoin={\`round\`}
      />
    </svg>
  ),
  ComponentG: RecoveredValue = (): RecoveredValue => (
    <span className={\`ui-ad__spinner\`} aria-hidden={\`true\`} />
  ),
  __demo_Ctokv7Xz: RecoveredValue = {
    essentials: l(\`m8 1.8 1.9 3.9 4.3.6-3.1 3 .7 4.3L8 11.6l-3.8 2 .7-4.3-3.1-3 4.3-.6Z\`),
    all: l(\`M2.5 2.5h4v4h-4zM9.5 2.5h4v4h-4zM2.5 9.5h4v4h-4zM9.5 9.5h4v4h-4z\`),
    analytics: l(\`M2.5 2.5h11v11h-11zM5.5 10.5v-2M8 10.5v-5M10.5 10.5V7\`),
    automation: l(\`M9 1.5 3.5 9H8l-1 5.5L12.5 7H8Z\`),
    billing: l(
      \`M8 14.5a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13ZM10 5.8C9.6 5.2 8.9 5 8 5c-1.1 0-2 .6-2 1.5S6.9 7.8 8 8s2 .6 2 1.5S9.1 11 8 11c-.9 0-1.7-.3-2.1-1M8 3.8V5M8 11v1.2\`,
    ),
    communication: l(\`M2.5 3.5h11v7.5H7l-3 2.5V11H2.5Z\`),
    crm: l(
      \`M6 7.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM1.5 13.5c.6-2.3 2.3-3.5 4.5-3.5s3.9 1.2 4.5 3.5M10.5 2.7a2.5 2.5 0 0 1 0 4.6M12.5 10.3c1 .6 1.7 1.6 2 3.2\`,
    ),
    design: l(\`M10.5 2.5 13.5 5.5 6 13H3v-3ZM9 4l3 3\`),
    development: l(\`M5.5 4.5 2 8l3.5 3.5M10.5 4.5 14 8l-3.5 3.5\`),
    docs: l(\`M4 1.5h5.5l3 3v10H4zM9.5 1.5v3h3M6 8h4.5M6 10.5h4.5\`),
    product: l(\`M2.5 2.5h3v11h-3zM6.5 2.5h3v7h-3zM10.5 2.5h3v4h-3z\`),
    scheduling: l(\`M2.5 3.5h11v10h-11zM2.5 6.5h11M5.5 1.5v3M10.5 1.5v3\`),
    storage: l(
      \`M2.5 4c0-1.1 2.5-2 5.5-2s5.5.9 5.5 2-2.5 2-5.5 2-5.5-.9-5.5-2ZM2.5 4v8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2V4M2.5 8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2\`,
    ),
  },
  v: RecoveredValue = [
    {
      id: \`essentials\`,
      label: \`Essentials\`,
      icon: __demo_Ctokv7Xz.essentials,
    },
    {
      id: \`all\`,
      label: \`All apps\`,
      icon: __demo_Ctokv7Xz.all,
    },
    {
      id: \`analytics\`,
      label: \`Analytics\`,
      icon: __demo_Ctokv7Xz.analytics,
    },
    {
      id: \`automation\`,
      label: \`Automation\`,
      icon: __demo_Ctokv7Xz.automation,
    },
    {
      id: \`billing\`,
      label: \`Billing\`,
      icon: __demo_Ctokv7Xz.billing,
    },
    {
      id: \`communication\`,
      label: \`Communication\`,
      icon: __demo_Ctokv7Xz.communication,
    },
    {
      id: \`crm\`,
      label: \`CRM\`,
      icon: __demo_Ctokv7Xz.crm,
    },
    {
      id: \`design\`,
      label: \`Design\`,
      icon: __demo_Ctokv7Xz.design,
    },
    {
      id: \`development\`,
      label: \`Development\`,
      icon: __demo_Ctokv7Xz.development,
    },
    {
      id: \`docs\`,
      label: \`Docs\`,
      icon: __demo_Ctokv7Xz.docs,
    },
    {
      id: \`product\`,
      label: \`Product\`,
      icon: __demo_Ctokv7Xz.product,
    },
    {
      id: \`scheduling\`,
      label: \`Scheduling\`,
      icon: __demo_Ctokv7Xz.scheduling,
    },
    {
      id: \`storage\`,
      label: \`Storage\`,
      icon: __demo_Ctokv7Xz.storage,
    },
  ],
  y_demo_Ctokv7Xz: RecoveredValue = (
    e?: RecoveredValue,
    t?: RecoveredValue,
  ): RecoveredValue => (
    <svg viewBox={\`0 0 24 24\`} fill={t} aria-hidden={\`true\`}>
      <path d={e} />
    </svg>
  ),
  b: RecoveredValue = [
    {
      id: \`slack\`,
      connected: !0,
      name: \`Slack\`,
      vendor: \`Slack\`,
      description: \`Get alerts in your channels and act on them without leaving the conversation.\`,
      categories: [\`communication\`],
      logo: ((_Component?: RecoveredValue): RecoveredValue => <_Component />)(
        (): RecoveredValue => (
          <svg viewBox={\`0 0 24 24\`} aria-hidden={\`true\`}>
            <path
              fill={\`#E01E5A\`}
              d={\`M5.04 15.17a2.53 2.53 0 0 1-2.52 2.52A2.53 2.53 0 0 1 0 15.17a2.53 2.53 0 0 1 2.52-2.53h2.52zm1.27 0a2.53 2.53 0 0 1 2.53-2.53 2.53 2.53 0 0 1 2.52 2.53v6.31A2.53 2.53 0 0 1 8.84 24a2.53 2.53 0 0 1-2.53-2.52z\`}
            />
            <path
              fill={\`#36C5F0\`}
              d={\`M8.84 5.04a2.53 2.53 0 0 1-2.53-2.52A2.53 2.53 0 0 1 8.84 0a2.53 2.53 0 0 1 2.52 2.52v2.52zm0 1.27a2.53 2.53 0 0 1 2.52 2.53 2.53 2.53 0 0 1-2.52 2.52H2.52A2.53 2.53 0 0 1 0 8.84a2.53 2.53 0 0 1 2.52-2.53z\`}
            />
            <path
              fill={\`#2EB67D\`}
              d={\`M18.96 8.84a2.53 2.53 0 0 1 2.52-2.53A2.53 2.53 0 0 1 24 8.84a2.53 2.53 0 0 1-2.52 2.52h-2.52zm-1.27 0a2.53 2.53 0 0 1-2.53 2.52 2.53 2.53 0 0 1-2.52-2.52V2.52A2.53 2.53 0 0 1 15.16 0a2.53 2.53 0 0 1 2.53 2.52z\`}
            />
            <path
              fill={\`#ECB22E\`}
              d={\`M15.16 18.96a2.53 2.53 0 0 1 2.53 2.52A2.53 2.53 0 0 1 15.16 24a2.53 2.53 0 0 1-2.52-2.52v-2.52zm0-1.27a2.53 2.53 0 0 1-2.52-2.53 2.53 2.53 0 0 1 2.52-2.52h6.32A2.53 2.53 0 0 1 24 15.16a2.53 2.53 0 0 1-2.52 2.53z\`}
            />
          </svg>
        ),
      ),
      essential: !0,
    },
    {
      id: \`notion\`,
      name: \`Notion\`,
      vendor: \`Notion\`,
      description: \`Turn records into pages and keep project docs in sync both ways.\`,
      categories: [\`docs\`],
      logo: y_demo_Ctokv7Xz(
        \`M4.459 4.208c.746.606 1.026.56 2.428.466l13.215-.793c.28 0 .047-.28-.046-.326L17.86 1.968c-.42-.326-.981-.7-2.055-.607L3.01 2.295c-.466.046-.56.28-.374.466zm.793 3.08v13.904c0 .747.373 1.027 1.214.98l14.523-.84c.841-.046.935-.56.935-1.167V6.354c0-.606-.233-.933-.748-.887l-15.177.887c-.56.047-.747.327-.747.933zm14.337.745c.093.42 0 .84-.42.888l-.7.14v10.264c-.608.327-1.168.514-1.635.514-.748 0-.935-.234-1.495-.933l-4.577-7.186v6.952L12.21 19s0 .84-1.168.84l-3.222.186c-.093-.186 0-.653.327-.746l.84-.233V9.854L7.822 9.76c-.094-.42.14-1.026.793-1.073l3.456-.233 4.764 7.279v-6.44l-1.215-.139c-.093-.514.28-.887.747-.933zM1.936 1.035l13.31-.98c1.634-.14 2.055-.047 3.082.7l4.249 2.986c.7.513.934.653.934 1.213v16.378c0 1.026-.373 1.634-1.68 1.726l-15.458.934c-.98.047-1.448-.093-1.962-.747l-3.129-4.06c-.56-.747-.793-1.306-.793-1.96V2.667c0-.839.374-1.54 1.447-1.632z\`,
        \`currentColor\`,
      ),
      essential: !0,
    },
    {
      id: \`linear\`,
      name: \`Linear\`,
      vendor: \`Linear\`,
      description: \`Create issues from customer feedback and track them to release.\`,
      categories: [\`product\`],
      logo: y_demo_Ctokv7Xz(
        \`M2.886 4.18A11.982 11.982 0 0 1 11.99 0C18.624 0 24 5.376 24 12.009c0 3.64-1.62 6.903-4.18 9.105L2.887 4.18ZM1.817 5.626l16.556 16.556c-.524.33-1.075.62-1.65.866L.951 7.277c.247-.575.537-1.126.866-1.65ZM.322 9.163l14.515 14.515c-.71.172-1.443.282-2.195.322L0 11.358a12 12 0 0 1 .322-2.195Zm-.17 4.862 9.823 9.824a12.02 12.02 0 0 1-9.824-9.824Z\`,
        \`#ffffff\`,
      ),
      tile: \`#5E6AD2\`,
      essential: !0,
    },
    {
      id: \`figma\`,
      name: \`Figma\`,
      vendor: \`Figma\`,
      description: \`Preview designs inline and link frames to the work they belong to.\`,
      categories: [\`design\`],
      logo: ((_Component2?: RecoveredValue): RecoveredValue => <_Component2 />)(
        (): RecoveredValue => (
          <svg viewBox={\`0 0 38 57\`} aria-hidden={\`true\`}>
            <path
              d={\`M19 28.5a9.5 9.5 0 1 1 19 0 9.5 9.5 0 0 1-19 0Z\`}
              fill={\`#1ABCFE\`}
            />
            <path
              d={\`M0 47.5A9.5 9.5 0 0 1 9.5 38H19v9.5a9.5 9.5 0 1 1-19 0Z\`}
              fill={\`#0ACF83\`}
            />
            <path d={\`M19 0v19h9.5a9.5 9.5 0 1 0 0-19H19Z\`} fill={\`#FF7262\`} />
            <path
              d={\`M0 9.5A9.5 9.5 0 0 0 9.5 19H19V0H9.5A9.5 9.5 0 0 0 0 9.5Z\`}
              fill={\`#F24E1E\`}
            />
            <path
              d={\`M0 28.5A9.5 9.5 0 0 0 9.5 38H19V19H9.5A9.5 9.5 0 0 0 0 28.5Z\`}
              fill={\`#A259FF\`}
            />
          </svg>
        ),
      ),
      essential: !0,
    },
    {
      id: \`github\`,
      name: \`GitHub\`,
      vendor: \`GitHub\`,
      description: \`Link pull requests and see deploy status next to every task.\`,
      categories: [\`development\`],
      logo: y_demo_Ctokv7Xz(
        \`M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12\`,
        \`#ffffff\`,
      ),
      tile: \`#171717\`,
      essential: !0,
    },
    {
      id: \`stripe\`,
      name: \`Stripe\`,
      vendor: \`Stripe\`,
      description: \`Sync customers, invoices and subscriptions in real time.\`,
      categories: [\`billing\`],
      logo: y_demo_Ctokv7Xz(
        \`M13.976 9.15c-2.172-.806-3.356-1.426-3.356-2.409 0-.831.683-1.305 1.901-1.305 2.227 0 4.515.858 6.09 1.631l.89-5.494C18.252.975 15.697 0 12.165 0 9.667 0 7.589.654 6.104 1.872 4.56 3.147 3.757 4.992 3.757 7.218c0 4.039 2.467 5.76 6.476 7.219 2.585.92 3.445 1.574 3.445 2.583 0 .98-.84 1.545-2.354 1.545-1.875 0-4.965-.921-6.99-2.109l-.9 5.555C5.175 22.99 8.385 24 11.714 24c2.641 0 4.843-.624 6.328-1.813 1.664-1.305 2.525-3.236 2.525-5.732 0-4.128-2.524-5.851-6.594-7.305h.003z\`,
        \`#ffffff\`,
      ),
      tile: \`#635BFF\`,
      essential: !0,
    },
    {
      id: \`zapier\`,
      name: \`Zapier\`,
      vendor: \`Zapier\`,
      description: \`Connect 6,000 apps with no-code workflows and triggers.\`,
      categories: [\`automation\`],
      logo: y_demo_Ctokv7Xz(
        \`M4.157 0A4.151 4.151 0 0 0 0 4.161v15.678A4.151 4.151 0 0 0 4.157 24h15.682A4.152 4.152 0 0 0 24 19.839V4.161A4.152 4.152 0 0 0 19.839 0H4.157Zm10.61 8.761h.03a.577.577 0 0 1 .23.038.585.585 0 0 1 .201.124.63.63 0 0 1 .162.431.612.612 0 0 1-.162.435.58.58 0 0 1-.201.128.58.58 0 0 1-.23.042.529.529 0 0 1-.235-.042.585.585 0 0 1-.332-.328.559.559 0 0 1-.038-.235.613.613 0 0 1 .17-.431.59.59 0 0 1 .405-.162Zm2.853 1.572c.03.004.061.004.095.004.325-.011.646.064.937.219.238.144.431.355.552.609.128.279.189.582.185.888v.193a2 2 0 0 1 0 .219h-2.498c.003.227.075.45.204.642a.78.78 0 0 0 .646.265.714.714 0 0 0 .484-.136.642.642 0 0 0 .23-.318l.915.257a1.398 1.398 0 0 1-.28.537c-.14.159-.321.284-.521.355a2.234 2.234 0 0 1-.836.136 1.923 1.923 0 0 1-1.001-.245 1.618 1.618 0 0 1-.665-.703 2.221 2.221 0 0 1-.227-1.036 1.95 1.95 0 0 1 .48-1.398 1.9 1.9 0 0 1 1.3-.488Zm-9.607.023c.162.004.325.026.48.079.207.065.4.174.563.314.26.302.393.692.366 1.088v2.276H8.53l-.109-.711h-.065c-.064.163-.155.31-.272.439a1.122 1.122 0 0 1-.374.264 1.023 1.023 0 0 1-.453.083 1.334 1.334 0 0 1-.866-.264.965.965 0 0 1-.329-.801.993.993 0 0 1 .076-.431 1.02 1.02 0 0 1 .242-.363 1.478 1.478 0 0 1 1.043-.303h.952v-.181a.696.696 0 0 0-.136-.454.553.553 0 0 0-.438-.154.695.695 0 0 0-.378.086.48.48 0 0 0-.193.254l-.99-.144a1.26 1.26 0 0 1 .257-.563c.14-.174.321-.302.533-.378.261-.091.54-.136.82-.129.053-.003.106-.007.163-.007Zm4.384.007c.174 0 .347.038.506.114.182.083.34.211.458.374.257.423.377.911.351 1.406a2.53 2.53 0 0 1-.355 1.448 1.148 1.148 0 0 1-1.009.517c-.204 0-.401-.045-.582-.136a1.052 1.052 0 0 1-.48-.457 1.298 1.298 0 0 1-.114-.234h-.045l.004 1.784h-1.059v-4.713h.904l.117.805h.057c.068-.208.177-.401.328-.56a1.129 1.129 0 0 1 .843-.344h.076v-.004Zm7.559.084h.903l.113.805h.053a1.37 1.37 0 0 1 .235-.484.813.813 0 0 1 .313-.242.82.82 0 0 1 .39-.076h.234v1.051h-.401a.662.662 0 0 0-.313.008.623.623 0 0 0-.272.155.663.663 0 0 0-.174.26.683.683 0 0 0-.027.314v1.875h-1.054v-3.666Zm-17.515.003h3.262v.896L3.73 13.104l.034.113h1.973l.042.9H2.4v-.9l1.931-1.754-.045-.117H2.441v-.896Zm11.815 0h1.055v3.659h-1.055V10.45Zm3.443.684.019.016a.69.69 0 0 0-.351.045.756.756 0 0 0-.287.204c-.11.155-.174.336-.189.522h1.545c-.034-.526-.257-.787-.74-.787h.003Zm-5.718.163c-.026 0-.057 0-.083.004a.78.78 0 0 0-.31.053.746.746 0 0 0-.257.189 1.016 1.016 0 0 0-.204.695v.064c-.015.257.057.507.204.711a.634.634 0 0 0 .253.196.638.638 0 0 0 .314.061.644.644 0 0 0 .578-.265c.14-.223.204-.48.189-.74a1.216 1.216 0 0 0-.181-.711.677.677 0 0 0-.503-.257Zm-4.509 1.266a.464.464 0 0 0-.268.102.373.373 0 0 0-.114.276c0 .053.008.106.027.155a.375.375 0 0 0 .087.132.576.576 0 0 0 .397.11v.004a.863.863 0 0 0 .563-.182.573.573 0 0 0 .211-.457v-.14h-.903Z\`,
        \`#ffffff\`,
      ),
      tile: \`#FF4F00\`,
      essential: !0,
    },
    {
      id: \`hubspot\`,
      name: \`HubSpot\`,
      vendor: \`HubSpot\`,
      description: \`Keep contacts, companies and deals matched across both tools.\`,
      categories: [\`crm\`],
      logo: y_demo_Ctokv7Xz(
        \`M18.164 7.93V5.084a2.198 2.198 0 001.267-1.978v-.067A2.2 2.2 0 0017.238.845h-.067a2.2 2.2 0 00-2.193 2.193v.067a2.196 2.196 0 001.252 1.973l.013.006v2.852a6.22 6.22 0 00-2.969 1.31l.012-.01-7.828-6.095A2.497 2.497 0 104.3 4.656l-.012.006 7.697 5.991a6.176 6.176 0 00-1.038 3.446c0 1.343.425 2.588 1.147 3.607l-.013-.02-2.342 2.343a1.968 1.968 0 00-.58-.095h-.002a2.033 2.033 0 102.033 2.033 1.978 1.978 0 00-.1-.595l.005.014 2.317-2.317a6.247 6.247 0 104.782-11.134l-.036-.005zm-.964 9.378a3.206 3.206 0 113.215-3.207v.002a3.206 3.206 0 01-3.207 3.207z\`,
        \`#FF7A59\`,
      ),
      essential: !0,
    },
    {
      id: \`zoom\`,
      name: \`Zoom\`,
      vendor: \`Zoom\`,
      description: \`Start meetings from any record and save the recording link.\`,
      categories: [\`communication\`, \`scheduling\`],
      logo: y_demo_Ctokv7Xz(
        \`M5.033 14.649H.743a.74.74 0 0 1-.686-.458.74.74 0 0 1 .16-.808L3.19 10.41H1.06A1.06 1.06 0 0 1 0 9.35h3.957c.301 0 .57.18.686.458a.74.74 0 0 1-.161.808L1.51 13.59h2.464c.585 0 1.06.475 1.06 1.06zM24 11.338c0-1.14-.927-2.066-2.066-2.066-.61 0-1.158.265-1.537.686a2.061 2.061 0 0 0-1.536-.686c-1.14 0-2.066.926-2.066 2.066v3.311a1.06 1.06 0 0 0 1.06-1.06v-2.251a1.004 1.004 0 0 1 2.013 0v2.251c0 .586.474 1.06 1.06 1.06v-3.311a1.004 1.004 0 0 1 2.012 0v2.251c0 .586.475 1.06 1.06 1.06zM16.265 12a2.728 2.728 0 1 1-5.457 0 2.728 2.728 0 0 1 5.457 0zm-1.06 0a1.669 1.669 0 1 0-3.338 0 1.669 1.669 0 0 0 3.338 0zm-4.82 0a2.728 2.728 0 1 1-5.458 0 2.728 2.728 0 0 1 5.457 0zm-1.06 0a1.669 1.669 0 1 0-3.338 0 1.669 1.669 0 0 0 3.338 0z\`,
        \`#ffffff\`,
      ),
      tile: \`#0B5CFF\`,
    },
    {
      id: \`discord\`,
      name: \`Discord\`,
      vendor: \`Discord\`,
      description: \`Post updates to community channels when something ships.\`,
      categories: [\`communication\`],
      logo: y_demo_Ctokv7Xz(
        \`M20.317 4.3698a19.7913 19.7913 0 00-4.8851-1.5152.0741.0741 0 00-.0785.0371c-.211.3753-.4447.8648-.6083 1.2495-1.8447-.2762-3.68-.2762-5.4868 0-.1636-.3933-.4058-.8742-.6177-1.2495a.077.077 0 00-.0785-.037 19.7363 19.7363 0 00-4.8852 1.515.0699.0699 0 00-.0321.0277C.5334 9.0458-.319 13.5799.0992 18.0578a.0824.0824 0 00.0312.0561c2.0528 1.5076 4.0413 2.4228 5.9929 3.0294a.0777.0777 0 00.0842-.0276c.4616-.6304.8731-1.2952 1.226-1.9942a.076.076 0 00-.0416-.1057c-.6528-.2476-1.2743-.5495-1.8722-.8923a.077.077 0 01-.0076-.1277c.1258-.0943.2517-.1923.3718-.2914a.0743.0743 0 01.0776-.0105c3.9278 1.7933 8.18 1.7933 12.0614 0a.0739.0739 0 01.0785.0095c.1202.099.246.1981.3728.2924a.077.077 0 01-.0066.1276 12.2986 12.2986 0 01-1.873.8914.0766.0766 0 00-.0407.1067c.3604.698.7719 1.3628 1.225 1.9932a.076.076 0 00.0842.0286c1.961-.6067 3.9495-1.5219 6.0023-3.0294a.077.077 0 00.0313-.0552c.5004-5.177-.8382-9.6739-3.5485-13.6604a.061.061 0 00-.0312-.0286zM8.02 15.3312c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9555-2.4189 2.157-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.9555 2.4189-2.1569 2.4189zm7.9748 0c-1.1825 0-2.1569-1.0857-2.1569-2.419 0-1.3332.9554-2.4189 2.1569-2.4189 1.2108 0 2.1757 1.0952 2.1568 2.419 0 1.3332-.946 2.4189-2.1568 2.4189Z\`,
        \`#ffffff\`,
      ),
      tile: \`#5865F2\`,
    },
    {
      id: \`calendly\`,
      name: \`Calendly\`,
      vendor: \`Calendly\`,
      description: \`Log booked meetings and the answers people gave when booking.\`,
      categories: [\`scheduling\`],
      logo: y_demo_Ctokv7Xz(
        \`M19.655 14.262c.281 0 .557.023.828.064 0 .005-.005.01-.005.014-.105.267-.234.534-.381.786l-1.219 2.106c-1.112 1.936-3.177 3.127-5.411 3.127h-2.432c-2.23 0-4.294-1.191-5.412-3.127l-1.218-2.106a6.251 6.251 0 0 1 0-6.252l1.218-2.106C6.736 4.832 8.8 3.641 11.035 3.641h2.432c2.23 0 4.294 1.191 5.411 3.127l1.219 2.106c.147.252.271.519.381.786 0 .004.005.009.005.014-.267.041-.543.064-.828.064-1.816 0-2.501-.607-3.291-1.306-.764-.676-1.711-1.517-3.44-1.517h-1.029c-1.251 0-2.387.455-3.2 1.278-.796.805-1.233 1.904-1.233 3.099v1.411c0 1.196.437 2.295 1.233 3.099.813.823 1.949 1.278 3.2 1.278h1.034c1.729 0 2.676-.841 3.439-1.517.791-.703 1.471-1.306 3.287-1.301Zm.005-3.237c.399 0 .794-.036 1.179-.11-.002-.004-.002-.01-.002-.014-.073-.414-.193-.823-.349-1.218.731-.12 1.407-.396 1.986-.819 0-.004-.005-.013-.005-.018-.331-1.085-.832-2.101-1.489-3.03-.649-.915-1.435-1.719-2.331-2.395-1.867-1.398-4.088-2.138-6.428-2.138-1.448 0-2.855.28-4.175.841-1.273.543-2.423 1.315-3.407 2.299S2.878 6.552 2.341 7.83c-.557 1.324-.842 2.726-.842 4.175 0 1.448.281 2.855.842 4.174.542 1.274 1.314 2.423 2.298 3.407s2.129 1.761 3.407 2.299c1.324.556 2.727.841 4.175.841 2.34 0 4.561-.74 6.428-2.137a10.815 10.815 0 0 0 2.331-2.396c.652-.929 1.158-1.949 1.489-3.03 0-.004.005-.014.005-.018-.579-.423-1.255-.699-1.986-.819.161-.395.276-.804.349-1.218.005-.009.005-.014.005-.023.869.166 1.692.506 2.404 1.035.685.505.552 1.075.446 1.416C22.184 20.437 17.619 24 12.221 24c-6.625 0-12-5.375-12-12s5.37-12 12-12c5.398 0 9.963 3.563 11.471 8.464.106.341.239.915-.446 1.421-.717.529-1.535.873-2.404 1.034.128.716.128 1.45 0 2.166-.387-.074-.782-.11-1.182-.11-4.184 0-3.968 2.823-6.736 2.823h-1.029c-1.899 0-3.15-1.357-3.15-3.095v-1.411c0-1.738 1.251-3.094 3.15-3.094h1.034c2.768 0 2.552 2.823 6.731 2.827Z\`,
        \`#ffffff\`,
      ),
      tile: \`#006BFF\`,
    },
    {
      id: \`google-calendar\`,
      name: \`Google Calendar\`,
      vendor: \`Google\`,
      description: \`See upcoming meetings with every contact in one timeline.\`,
      categories: [\`scheduling\`],
      logo: y_demo_Ctokv7Xz(
        \`M18.316 5.684H24v12.632h-5.684V5.684zM5.684 24h12.632v-5.684H5.684V24zM18.316 5.684V0H1.895A1.894 1.894 0 0 0 0 1.895v16.421h5.684V5.684h12.632zm-7.207 6.25v-.065c.272-.144.5-.349.687-.617s.279-.595.279-.982c0-.379-.099-.72-.3-1.025a2.05 2.05 0 0 0-.832-.714 2.703 2.703 0 0 0-1.197-.257c-.6 0-1.094.156-1.481.467-.386.311-.65.671-.793 1.078l1.085.452c.086-.249.224-.461.413-.633.189-.172.445-.257.767-.257.33 0 .602.088.816.264a.86.86 0 0 1 .322.703c0 .33-.12.589-.36.778-.24.19-.535.284-.886.284h-.567v1.085h.633c.407 0 .748.109 1.02.327.272.218.407.499.407.843 0 .336-.129.614-.387.832s-.565.327-.924.327c-.351 0-.651-.103-.897-.311-.248-.208-.422-.502-.521-.881l-1.096.452c.178.616.505 1.082.977 1.401.472.319.984.478 1.538.477a2.84 2.84 0 0 0 1.293-.291c.382-.193.684-.458.902-.794.218-.336.327-.72.327-1.149 0-.429-.115-.797-.344-1.105a2.067 2.067 0 0 0-.881-.689zm2.093-1.931l.602.913L15 10.045v5.744h1.187V8.446h-.827l-2.158 1.557zM22.105 0h-3.289v5.184H24V1.895A1.894 1.894 0 0 0 22.105 0zm-3.289 23.5l4.684-4.684h-4.684V23.5zM0 22.105C0 23.152.848 24 1.895 24h3.289v-5.184H0v3.289z\`,
        \`#4285F4\`,
      ),
    },
    {
      id: \`make\`,
      name: \`Make\`,
      vendor: \`Make\`,
      description: \`Build visual multi-step automations with branches and filters.\`,
      categories: [\`automation\`],
      logo: y_demo_Ctokv7Xz(
        \`M13.38 3.498c-.27 0-.511.19-.566.465L9.85 18.986a.578.578 0 0 0 .453.678l4.095.826a.58.58 0 0 0 .682-.455l2.963-15.021a.578.578 0 0 0-.453-.678l-4.096-.826a.589.589 0 0 0-.113-.012zm-5.876.098a.576.576 0 0 0-.516.318L.062 17.697a.575.575 0 0 0 .256.774l3.733 1.877a.578.578 0 0 0 .775-.258l6.926-13.781a.577.577 0 0 0-.256-.776L7.762 3.658a.571.571 0 0 0-.258-.062zm11.74.115a.576.576 0 0 0-.576.576v15.426c0 .318.258.578.576.578h4.178a.58.58 0 0 0 .578-.578V4.287a.578.578 0 0 0-.578-.576Z\`,
        \`#ffffff\`,
      ),
      tile: \`#6D00CC\`,
    },
    {
      id: \`mixpanel\`,
      name: \`Mixpanel\`,
      vendor: \`Mixpanel\`,
      description: \`Send product events and build reports from real usage.\`,
      categories: [\`analytics\`],
      logo: y_demo_Ctokv7Xz(
        \`M6.967 9.996h3.053c-.763-.477-1.048-1.145-1.431-2.384L7.443 3.366C6.919 1.458 6.49.551 4.39.551H.004v1.145h.621c1.286 0 1.431.477 1.814 1.908L3.44 7.326c.524 1.814 1.337 2.67 3.53 2.67h-.003Zm7.06 0h3.053c2.194 0 2.956-.86 3.484-2.67l1.001-3.722c.382-1.431.57-1.908 1.814-1.908H24V.551h-4.34c-2.146 0-2.576.86-3.053 2.815l-1.145 4.246c-.384 1.286-.673 1.907-1.435 2.384Zm-4.007 4.008h4.007V9.996H10.02v4.008ZM0 23.449h4.39c2.1 0 2.529-.907 3.053-2.815l1.146-4.246c.383-1.239.668-1.907 1.431-2.384H6.967c-2.194 0-3.007.86-3.531 2.67l-1.001 3.722c-.383 1.431-.524 1.907-1.814 1.907H0v1.146Zm19.65 0h4.343v-1.146h-.622c-1.239 0-1.431-.476-1.814-1.907l-1.001-3.722c-.524-1.814-1.286-2.67-3.483-2.67h-3.046c.762.477 1.041 1.098 1.424 2.384l1.145 4.246c.477 1.955.907 2.815 3.054 2.815Z\`,
        \`#ffffff\`,
      ),
      tile: \`#7856FF\`,
    },
    {
      id: \`google-analytics\`,
      name: \`Google Analytics\`,
      vendor: \`Google\`,
      description: \`Attribute signups to the campaigns and pages that brought them.\`,
      categories: [\`analytics\`],
      logo: y_demo_Ctokv7Xz(
        \`M22.84 2.9982v17.9987c.0086 1.6473-1.3197 2.9897-2.967 2.9984a2.9808 2.9808 0 01-.3677-.0208c-1.528-.226-2.6477-1.5558-2.6105-3.1V3.1204c-.0369-1.5458 1.0856-2.8762 2.6157-3.1 1.6361-.1915 3.1178.9796 3.3093 2.6158.014.1201.0208.241.0202.3619zM4.1326 18.0548c-1.6417 0-2.9726 1.331-2.9726 2.9726C1.16 22.6691 2.4909 24 4.1326 24s2.9726-1.3309 2.9726-2.9726-1.331-2.9726-2.9726-2.9726zm7.8728-9.0098c-.0171 0-.0342 0-.0513.0003-1.6495.0904-2.9293 1.474-2.891 3.1256v7.9846c0 2.167.9535 3.4825 2.3505 3.763 1.6118.3266 3.1832-.7152 3.5098-2.327.04-.1974.06-.3983.0593-.5998v-8.9585c.003-1.6474-1.33-2.9852-2.9773-2.9882z\`,
        \`#E37400\`,
      ),
    },
    {
      id: \`paddle\`,
      name: \`Paddle\`,
      vendor: \`Paddle\`,
      description: \`Handle checkout, tax and subscriptions as merchant of record.\`,
      categories: [\`billing\`],
      logo: y_demo_Ctokv7Xz(
        \`M2.363 7.904v.849a3.95 3.95 0 0 1 3.65 2.425c.198.476.3.987.299 1.502h.791c0-1.04.416-2.037 1.157-2.772a3.962 3.962 0 0 1 2.792-1.149V7.91a3.959 3.959 0 0 1-3.65-2.425 3.893 3.893 0 0 1-.299-1.502h-.791c0 1.04-.416 2.037-1.157 2.772a3.96 3.96 0 0 1-2.792 1.149M13.105 2.51H6.312V0h6.793c4.772 0 8.532 3.735 8.532 8.314 0 4.58-3.76 8.314-8.532 8.314H9.156V24H6.312v-9.882h6.793c3.319 0 5.688-2.352 5.688-5.804 0-3.451-2.37-5.804-5.688-5.804\`,
        \`#ffffff\`,
      ),
      tile: \`#FDDD35\`,
    },
    {
      id: \`dropbox\`,
      name: \`Dropbox\`,
      vendor: \`Dropbox\`,
      description: \`Attach files from Dropbox and keep shared folders linked.\`,
      categories: [\`storage\`],
      logo: y_demo_Ctokv7Xz(
        \`M6 1.807L0 5.629l6 3.822 6.001-3.822L6 1.807zM18 1.807l-6 3.822 6 3.822 6-3.822-6-3.822zM0 13.274l6 3.822 6.001-3.822L6 9.452l-6 3.822zM18 9.452l-6 3.822 6 3.822 6-3.822-6-3.822zM6 18.371l6.001 3.822 6-3.822-6-3.822L6 18.371z\`,
        \`#0061FF\`,
      ),
    },
    {
      id: \`google-drive\`,
      name: \`Google Drive\`,
      vendor: \`Google\`,
      description: \`Pick files from Drive and preview them without downloading.\`,
      categories: [\`storage\`, \`docs\`],
      logo: y_demo_Ctokv7Xz(
        \`M12.01 1.485c-2.082 0-3.754.02-3.743.047.01.02 1.708 3.001 3.774 6.62l3.76 6.574h3.76c2.081 0 3.753-.02 3.742-.047-.005-.02-1.708-3.001-3.775-6.62l-3.76-6.574zm-4.76 1.73a789.828 789.861 0 0 0-3.63 6.319L0 15.868l1.89 3.298 1.885 3.297 3.62-6.335 3.618-6.33-1.88-3.287C8.1 4.704 7.255 3.22 7.25 3.214zm2.259 12.653-.203.348c-.114.198-.96 1.672-1.88 3.287a423.93 423.948 0 0 1-1.698 2.97c-.01.026 3.24.042 7.222.042h7.244l1.796-3.157c.992-1.734 1.85-3.23 1.906-3.323l.104-.167h-7.249z\`,
        \`#1FA463\`,
      ),
    },
    {
      id: \`typeform\`,
      name: \`Typeform\`,
      vendor: \`Typeform\`,
      description: \`Create records from form answers the moment they come in.\`,
      categories: [\`product\`],
      logo: y_demo_Ctokv7Xz(
        \`M15.502 13.035c-.5 0-.756-.411-.756-.917 0-.505.252-.894.756-.894.513 0 .756.407.756.894-.004.515-.261.917-.756.917Zm-4.888-1.81c.292 0 .414.17.414.317 0 .357-.365.514-1.126.536 0-.442.253-.854.712-.854Zm-3.241 1.81c-.473 0-.67-.384-.67-.917 0-.527.202-.894.67-.894.477 0 .702.38.702.894 0 .537-.234.917-.702.917Zm-3.997-2.334h-.738l1.224 2.808c-.234.519-.36.648-.522.648-.171 0-.333-.138-.45-.259l-.324.43c.22.232.522.366.832.366.387 0 .685-.224.856-.626l1.413-3.371h-.725l-.738 2.012-.828-2.008Zm19.553.523c.36 0 .432.246.432.823v1.516H24v-1.914c0-.689-.473-.988-.91-.988-.386 0-.742.241-.94.688a.901.901 0 0 0-.891-.688c-.365 0-.73.232-.927.666v-.626h-.64v2.857h.64v-1.22c0-.617.324-1.114.765-1.114.36 0 .427.246.427.823v1.516h.64l-.005-1.225c0-.617.329-1.114.77-1.114Zm-5.1-.523h-.324v2.857h.639v-1.095c0-.693.306-1.163.76-1.163.118 0 .217.005.325.05l.099-.676c-.081-.009-.153-.018-.225-.018-.45 0-.774.309-.964.707V10.7h-.31Zm-2.327-.045c-.846 0-1.418.644-1.418 1.458 0 .845.58 1.475 1.418 1.475.85 0 1.431-.648 1.431-1.475-.004-.818-.594-1.458-1.431-1.458Zm-4.852 2.38c-.333 0-.581-.17-.685-.515.847-.036 1.675-.242 1.675-.988 0-.43-.423-.872-1.03-.872-.82 0-1.374.666-1.374 1.457 0 .828.545 1.476 1.36 1.476.567 0 .927-.228 1.21-.559l-.31-.42c-.329.335-.531.42-.846.42Zm-3.151-2.38c-.324 0-.648.188-.774.483v-.438h-.64v3.98h.64v-1.422c.135.205.445.34.72.34.85 0 1.3-.631 1.3-1.48-.004-.841-.445-1.463-1.246-1.463Zm-4.483-1.1H0v.622h1.18v3.38h.67v-3.38h1.166v-.622Zm9.502 1.145h-.383v.572h.383v2.285h.639v-2.285h.621v-.572h-.621v-.447c0-.286.117-.385.382-.385.1 0 .19.027.311.068l.144-.537c-.117-.067-.351-.094-.504-.094-.612 0-.972.367-.972 1.002v.393Z\`,
        \`#ffffff\`,
      ),
      tile: \`#262627\`,
    },
    {
      id: \`jira\`,
      name: \`Jira\`,
      vendor: \`Atlassian\`,
      description: \`Sync issues, statuses and assignees with your Jira projects.\`,
      categories: [\`product\`, \`development\`],
      logo: y_demo_Ctokv7Xz(
        \`M11.571 11.513H0a5.218 5.218 0 0 0 5.232 5.215h2.13v2.057A5.215 5.215 0 0 0 12.575 24V12.518a1.005 1.005 0 0 0-1.005-1.005zm5.723-5.756H5.736a5.215 5.215 0 0 0 5.215 5.214h2.129v2.058a5.218 5.218 0 0 0 5.215 5.214V6.758a1.001 1.001 0 0 0-1.001-1.001zM23.013 0H11.455a5.215 5.215 0 0 0 5.215 5.215h2.129v2.057A5.215 5.215 0 0 0 24 12.483V1.005A1.001 1.001 0 0 0 23.013 0Z\`,
        \`#0052CC\`,
      ),
    },
    {
      id: \`intercom\`,
      name: \`Intercom\`,
      vendor: \`Intercom\`,
      description: \`See conversations next to the customer and reply from one place.\`,
      categories: [\`communication\`, \`crm\`],
      logo: y_demo_Ctokv7Xz(
        \`M21 0H3C1.343 0 0 1.343 0 3v18c0 1.658 1.343 3 3 3h18c1.658 0 3-1.342 3-3V3c0-1.657-1.342-3-3-3zm-5.801 4.399c0-.44.36-.8.802-.8.44 0 .8.36.8.8v10.688c0 .442-.36.801-.8.801-.443 0-.802-.359-.802-.801V4.399zM11.2 3.994c0-.44.357-.799.8-.799s.8.359.8.799v11.602c0 .44-.357.8-.8.8s-.8-.36-.8-.8V3.994zm-4 .405c0-.44.359-.8.799-.8.443 0 .802.36.802.8v10.688c0 .442-.36.801-.802.801-.44 0-.799-.359-.799-.801V4.399zM3.199 6c0-.442.36-.8.802-.8.44 0 .799.358.799.8v7.195c0 .441-.359.8-.799.8-.443 0-.802-.36-.802-.8V6zM20.52 18.202c-.123.105-3.086 2.593-8.52 2.593-5.433 0-8.397-2.486-8.521-2.593-.335-.288-.375-.792-.086-1.128.285-.334.79-.375 1.125-.09.047.041 2.693 2.211 7.481 2.211 4.848 0 7.456-2.186 7.479-2.207.334-.289.839-.25 1.128.086.289.336.25.84-.086 1.128zm.281-5.007c0 .441-.36.8-.801.8-.441 0-.801-.36-.801-.8V6c0-.442.361-.8.801-.8.441 0 .801.357.801.8v7.195z\`,
        \`#ffffff\`,
      ),
      tile: \`#1F8DED\`,
    },
    {
      id: \`airtable\`,
      name: \`Airtable\`,
      vendor: \`Airtable\`,
      description: \`Mirror bases as tables and keep fields in sync automatically.\`,
      categories: [\`storage\`],
      logo: y_demo_Ctokv7Xz(
        \`M11.992 1.966c-.434 0-.87.086-1.28.257L1.779 5.917c-.503.208-.49.908.012 1.116l8.982 3.558a3.266 3.266 0 0 0 2.454 0l8.982-3.558c.503-.196.503-.908.012-1.116l-8.957-3.694a3.255 3.255 0 0 0-1.272-.257zM23.4 8.056a.589.589 0 0 0-.222.045l-10.012 3.877a.612.612 0 0 0-.38.564v8.896a.6.6 0 0 0 .821.552L23.62 18.1a.583.583 0 0 0 .38-.551V8.653a.6.6 0 0 0-.6-.596zM.676 8.095a.644.644 0 0 0-.48.19C.086 8.396 0 8.53 0 8.69v8.355c0 .442.515.737.908.54l6.27-3.006.307-.147 2.969-1.436c.466-.22.43-.908-.061-1.092L.883 8.138a.57.57 0 0 0-.207-.044z\`,
        \`#18BFFF\`,
      ),
    },
  ];
function x(e?: RecoveredValue): RecoveredValue {
  let t: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null);
  return (
    (0, n_demo_Ctokv7Xz.useLayoutEffect)((): RecoveredValue => {
      let n: RecoveredValue = t.current,
        r: RecoveredValue = e.current;
      if (!n || !r) return;
      let i: RecoveredValue = (): RecoveredValue => {
        n.style.height = \`\${r.offsetHeight}px\`;
      };
      i();
      let a: RecoveredValue = new ResizeObserver(i);
      a.observe(r);
      let o: RecoveredValue = requestAnimationFrame(
        (): RecoveredValue => n.setAttribute(\`data-smooth\`, \`\`),
      );
      return (): RecoveredValue => {
        (a.disconnect(), cancelAnimationFrame(o));
      };
    }, [e]),
    t
  );
}
var C_demo_Ctokv7Xz: RecoveredValue = 1040;
function Runtime(): RecoveredValue {
  let e: RecoveredValue = (0, n_demo_Ctokv7Xz.useRef)(null),
    [t, i]: RecoveredValue = (0, n_demo_Ctokv7Xz.useState)(null);
  return (
    (0, n_demo_Ctokv7Xz.useLayoutEffect)((): RecoveredValue => {
      let t: RecoveredValue = e.current,
        n: RecoveredValue = t?.closest(\`.card__preview\`),
        r: RecoveredValue = n ?? t?.closest(\`.stage\`);
      if (!t || !r) return;
      let a: RecoveredValue = (): RecoveredValue => {
        let e: RecoveredValue = r.clientWidth;
        if (n)
          return i({
            scale: (e - 48) / C_demo_Ctokv7Xz,
            card: !0,
          });
        if (e < 760) return i(null);
        i({
          scale: Math.min(0.82, (e - 140) / C_demo_Ctokv7Xz),
          card: !1,
        });
      };
      a();
      let o: RecoveredValue = new ResizeObserver(a);
      return (o.observe(r), (): RecoveredValue => o.disconnect());
    }, []),
    (
      <div
        ref={e as RecoveredValue}
        className={\`apps-demo\`}
        data-fit={t ? (t.card ? \`card\` : \`stage\`) : void 0}
      >
        <div
          className={\`apps-demo__frame\`}
          style={
            (t
              ? t.card
                ? {
                    width: C_demo_Ctokv7Xz,
                    transform: \`scale(\${t.scale})\`,
                  }
                : {
                    width: C_demo_Ctokv7Xz,
                    zoom: t.scale,
                  }
              : void 0) as RecoveredValue
          }
        >
          <ComponentS />
        </div>
      </div>
    )
  );
}
function Preview(): ReactElement {
  return (
    <>
      <Runtime />
    </>
  );
}
export { Preview };
export default Preview;
`;export{e as default};
