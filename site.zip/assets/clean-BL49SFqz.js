import{j as r}from"./workbench-model-BwgilGut.js";import{C as c}from"./CollaborationStreamView-68U7Btqq.js";const e=`
.ui-crsc {
  --ui-crsc-card: #ffffff;
  --ui-crsc-strong: #000000;
  --ui-crsc-ink: rgba(0, 0, 0, 0.88);
  --ui-crsc-text: rgba(0, 0, 0, 0.65);
  --ui-crsc-muted: rgba(0, 0, 0, 0.65);
  --ui-crsc-faint: rgba(0, 0, 0, 0.65);
  --ui-crsc-pixel: rgba(0, 0, 0, 0.32);
  --ui-crsc-fill: rgba(0, 0, 0, 0.05);
  --ui-crsc-well: rgba(0, 0, 0, 0.035);
  --ui-crsc-you: rgba(0, 0, 0, 0.022);
  --ui-crsc-you-line: rgba(0, 0, 0, 0.05);
  --ui-crsc-line: rgba(0, 0, 0, 0.08);
  --ui-crsc-scrim: rgba(250, 250, 250, 0.72);
  --ui-crsc-accent: rgba(0, 96, 226, 0.765);
  --ui-crsc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-crsc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 2px 6px -2px rgba(0, 0, 0, 0.12);
  --ui-crsc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-crsc-shine: rgba(255, 255, 255, 0.82);
  --ui-crsc-solid: rgba(0, 0, 0, 0.88);
  --ui-crsc-on-solid: #fcfcfc;
  --ui-crsc-wait-bg: #ff9c0029;
  --ui-crsc-wait-fg: #b74400;
  --ui-crsc-focus: rgba(0, 96, 226, 0.7);
  --ui-crsc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-crsc-ink);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-crsc *,
.ui-crsc *::before,
.ui-crsc *::after {
  box-sizing: border-box;
}
:where(.ui-crsc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-crsc button:focus-visible {
  outline: 2px solid var(--ui-crsc-focus);
  outline-offset: 2px;
}
.ui-crsc p {
  margin: 0;
}
.ui-crsc svg {
  display: block;
  flex: none;
}
.ui-crsc__live {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-muted);
}
.ui-crsc__pulse {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-crsc-accent);
  animation: ui-crsc-pulse 1400ms ease-in-out infinite;
}
.ui-crsc__top {
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 0;
  padding-bottom: 4px;
}
.ui-crsc__tabs {
  display: flex;
  flex: 1;
  gap: 2px;
  min-width: 0;
  margin-left: -8px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-crsc__tabs::-webkit-scrollbar {
  display: none;
}
.ui-crsc__tabs[data-more="end"] {
  -webkit-mask: linear-gradient(to right, #000 calc(100% - 32px), transparent);
  mask: linear-gradient(to right, #000 calc(100% - 32px), transparent);
}
.ui-crsc__tabs[data-more="start"] {
  -webkit-mask: linear-gradient(to right, transparent, #000 32px);
  mask: linear-gradient(to right, transparent, #000 32px);
}
.ui-crsc__tabs[data-more="both"] {
  -webkit-mask: linear-gradient(
    to right,
    transparent,
    #000 32px,
    #000 calc(100% - 32px),
    transparent
  );
  mask: linear-gradient(
    to right,
    transparent,
    #000 32px,
    #000 calc(100% - 32px),
    transparent
  );
}
.ui-crsc__tab-name {
  max-width: 160px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-crsc__tab {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 7px;
  height: 28px;
  padding: 0 8px;
  border-radius: 7px;
  font-size: 12.5px;
  line-height: 16px;
  color: var(--ui-crsc-muted);
  white-space: nowrap;
  transition:
    color 160ms ease,
    background-color 160ms ease;
}
.ui-crsc__tab:hover {
  color: var(--ui-crsc-text);
}
.ui-crsc__tab[aria-pressed="true"] {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc .ui-crsc__tab:focus-visible {
  outline-offset: -2px;
}
.ui-crsc__mark {
  display: grid;
  flex: none;
  grid-template-columns: repeat(3, 3px);
  grid-auto-rows: 3px;
  gap: 1.5px;
  place-content: center;
  width: 16px;
  height: 16px;
}
.ui-crsc__mark i {
  border-radius: 0.75px;
  background: var(--ui-crsc-c, var(--ui-crsc-pixel));
  opacity: 0;
  transition: opacity 240ms ease;
}
.ui-crsc__mark i[data-on] {
  opacity: 1;
}
.ui-crsc__mark[data-you] i {
  background: var(--ui-crsc-ink);
}
.ui-crsc__mark[data-busy] i {
  animation: ui-crsc-pixel 1.2s ease-in-out infinite both;
}
.ui-crsc__mark[data-busy] i:not([data-on]) {
  opacity: 0.16;
}
.ui-crsc__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
}
.ui-crsc__logo > svg {
  width: 14px;
  height: 14px;
}
.ui-crsc__logo[data-busy] {
  animation: ui-crsc-pulse 1200ms ease-in-out infinite;
}
.ui-crsc__panel {
  position: relative;
}
.ui-crsc__scroll {
  margin: 0 -8px;
  padding: 0 8px;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  -webkit-mask: linear-gradient(
    transparent,
    #000 24px,
    #000 calc(100% - 24px),
    transparent
  );
  mask: linear-gradient(
    transparent,
    #000 24px,
    #000 calc(100% - 24px),
    transparent
  );
}
.ui-crsc__stream {
  display: grid;
  padding: 18px 0 20px;
}
.ui-crsc[data-picking] :is(.ui-crsc__msg, .ui-crsc__system):not([data-kept]) {
  opacity: 0.3;
}
.ui-crsc__msg {
  display: grid;
  grid-template-columns: 16px minmax(0, 1fr);
  column-gap: 10px;
  align-items: start;
  margin: 0 -8px;
  padding: 4px 8px;
  border-radius: 14px;
  outline: none;
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-crsc__msg[data-you] {
  grid-template-columns: minmax(0, 1fr);
}
.ui-crsc__msg[data-you] > .ui-crsc__side {
  display: none;
}
.ui-crsc__msg[data-you] .ui-crsc__body {
  justify-self: end;
  background: var(--ui-crsc-you);
  box-shadow: inset 0 0 0 1px var(--ui-crsc-you-line);
}
.ui-crsc__msg[data-you] .ui-crsc__quote {
  background: var(--ui-crsc-card);
}
.ui-crsc__msg[data-you]:hover .ui-crsc__body,
.ui-crsc__msg[data-you][data-selected] .ui-crsc__body {
  box-shadow: inset 0 0 0 1px var(--ui-crsc-you-line);
  filter: brightness(0.985);
}
.ui-crsc__msg[data-same] {
  margin-top: -2px;
}
.ui-crsc .ui-crsc__msg:focus-visible {
  outline: none;
}
.ui-crsc__msg:focus-visible .ui-crsc__body {
  outline: 2px solid var(--ui-crsc-focus);
  outline-offset: 2px;
}
.ui-crsc .ui-crsc__system:focus-visible {
  outline: 2px solid var(--ui-crsc-focus);
  outline-offset: -2px;
}
.ui-crsc .ui-crsc__quote:focus-visible {
  outline-offset: -2px;
}
.ui-crsc__window-body:focus-visible {
  outline: 2px solid var(--ui-crsc-focus);
  outline-offset: -2px;
}
.ui-crsc__side {
  display: grid;
  height: 38px;
  place-items: center;
}
.ui-crsc__body {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 7px;
  justify-self: start;
  min-width: 0;
  max-width: min(100%, 560px);
  padding: 10px 12px 11px;
  border-radius: 12px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-shadow);
  transition: box-shadow 200ms ease;
}
.ui-crsc__msg:hover .ui-crsc__body,
.ui-crsc__msg[data-selected] .ui-crsc__body {
  box-shadow: var(--ui-crsc-shadow-hover);
}
.ui-crsc__msg[data-flash] .ui-crsc__body {
  animation: ui-crsc-flash 1400ms ease both;
}
.ui-crsc__quote {
  display: grid;
  gap: 1px;
  min-width: 0;
  margin: 0;
  padding: 5px 10px 6px 8px;
  border-radius: 8px;
  background: var(--ui-crsc-well);
  text-align: left;
  transition: background-color 140ms ease;
}
.ui-crsc__quote:not([data-only]):hover {
  background: var(--ui-crsc-fill);
}
.ui-crsc__quote[data-only] {
  justify-self: start;
  padding: 4px 10px 4px 8px;
}
.ui-crsc__quote-to {
  margin-right: -1px;
  font-weight: 400;
  color: var(--ui-crsc-muted);
}
.ui-crsc__quote-who {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-crsc__quote-who + .ui-crsc__quote-to {
  margin-right: -1px;
  font-weight: 400;
  color: var(--ui-crsc-muted);
}
.ui-crsc__quote-who {
  margin-left: 8px;
}
.ui-crsc__quote-who {
  min-width: 0;
}
.ui-crsc__quote-more,
.ui-crsc__for-more {
  flex: none;
  margin-left: 8px;
  color: var(--ui-crsc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-crsc__quote-name {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-crsc-text);
  white-space: nowrap;
}
.ui-crsc__quote-name .ui-crsc__mark {
  transform: scale(0.8);
  margin: 0 -1px 0 -3.5px;
}
.ui-crsc__quote-text {
  overflow: hidden;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-crsc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crsc__head {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.ui-crsc__from {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-crsc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  transition: color 160ms ease;
}
.ui-crsc__tag {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-crsc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crsc-text);
}
.ui-crsc__needs {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  background: var(--ui-crsc-wait-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crsc-wait-fg);
}
.ui-crsc__at {
  flex: none;
  margin-left: auto;
  padding-left: 12px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-crsc__text {
  display: -webkit-box;
  overflow: hidden;
  overflow-wrap: anywhere;
  color: var(--ui-crsc-text);
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
  transition: color 160ms ease;
}
.ui-crsc__msg:hover .ui-crsc__text,
.ui-crsc__msg[data-selected] .ui-crsc__text {
  color: var(--ui-crsc-ink);
}
.ui-crsc__msg[data-selected] .ui-crsc__text {
  -webkit-line-clamp: unset;
}
.ui-crsc__files {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  padding-top: 1px;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-crsc-text);
}
.ui-crsc__file {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  max-width: 100%;
  height: 24px;
  padding: 0 8px 0 7px;
  border-radius: 7px;
  background: var(--ui-crsc-well);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-crsc__file:hover {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc__file:active {
  transform: scale(0.98);
}
.ui-crsc__file > svg {
  flex: none;
  color: var(--ui-crsc-muted);
}
.ui-crsc__preview {
  position: absolute;
  inset: 0;
  z-index: 10;
  display: grid;
  place-items: center;
  padding: 24px 16px;
  background: var(--ui-crsc-scrim);
  animation: ui-crsc-fade 180ms ease both;
}
.ui-crsc__window {
  display: grid;
  grid-template-rows: auto minmax(0, 1fr);
  width: min(100%, 560px);
  max-height: min(100%, 440px);
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-pop);
  animation: ui-crsc-pop 260ms var(--ui-crsc-ease) both;
}
.ui-crsc__window-head {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 12px 12px 14px;
  box-shadow: 0 0.5px 0 var(--ui-crsc-line);
}
.ui-crsc__window-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-crsc-well);
  color: var(--ui-crsc-muted);
}
.ui-crsc__window-icon svg {
  width: 14px;
  height: 14px;
}
.ui-crsc__window-title {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-crsc__window-name {
  display: -webkit-box;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-crsc-ink);
  overflow-wrap: anywhere;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-crsc__window-meta {
  display: flex;
  align-items: center;
  gap: 5px;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-muted);
  white-space: pre;
}
.ui-crsc__window-meta .ui-crsc__mark {
  transform: scale(0.8);
  margin: 0 -1px 0 -2px;
}
.ui-crsc__preview-close {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-crsc-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-crsc__preview-close:hover {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc__preview-close svg {
  width: 16px;
  height: 16px;
}
.ui-crsc__window-body {
  min-height: 0;
  overflow: auto;
  padding: 12px 14px 14px;
  outline: none;
  overscroll-behavior: contain;
}
.ui-crsc__window-empty {
  margin: 0;
  padding: 20px 0;
  color: var(--ui-crsc-muted);
  text-align: center;
}
.ui-crsc__doc {
  margin: 0;
  font: inherit;
  color: var(--ui-crsc-text);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}
.ui-crsc__doc p {
  margin: 0;
}
.ui-crsc__doc-h {
  margin-bottom: 4px !important;
  font-size: 14px;
  font-weight: 600;
  color: var(--ui-crsc-ink);
}
.ui-crsc__doc[data-code] {
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 12px;
  line-height: 19px;
}
.ui-crsc__sheet {
  min-width: 100%;
  border-collapse: collapse;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
}
.ui-crsc__sheet th {
  padding: 0 10px 6px 0;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-crsc-muted);
  text-align: left;
  white-space: nowrap;
}
.ui-crsc__sheet td {
  padding: 7px 10px 7px 0;
  white-space: nowrap;
  color: var(--ui-crsc-text);
  box-shadow: inset 0 0.5px 0 var(--ui-crsc-line);
}
.ui-crsc__sheet td:first-child {
  font-weight: 500;
  color: var(--ui-crsc-ink);
}
.ui-crsc__tree {
  display: grid;
  gap: 2px;
  margin: 0;
  padding: 0;
  list-style: none;
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 12px;
}
.ui-crsc__tree li {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 26px;
  color: var(--ui-crsc-text);
}
.ui-crsc__tree svg {
  flex: none;
  color: var(--ui-crsc-muted);
}
.ui-crsc__file-name {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crsc__co {
  display: inline-flex;
  align-items: baseline;
  gap: 4px;
  white-space: nowrap;
}
.ui-crsc__co-logo {
  display: inline-grid;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-shadow);
  align-self: center;
  transform: translateY(1px);
}
.ui-crsc__co-logo > svg {
  width: 10px;
  height: 10px;
}
.ui-crsc__msg[data-selected] {
  position: relative;
  z-index: 4;
}
.ui-crsc__more {
  position: absolute;
  top: calc(100% - 2px);
  left: 34px;
  z-index: 5;
  width: min(calc(100% - 42px), 560px);
  pointer-events: none;
}
.ui-crsc__more[data-open] {
  pointer-events: auto;
}
.ui-crsc__card {
  display: grid;
  gap: 10px;
  padding: 10px 12px 12px;
  border-radius: 12px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-pop);
  cursor: default;
  scroll-margin-bottom: 28px;
  opacity: 0;
  transform: translateY(-4px) scale(0.98);
  transform-origin: 24px top;
  transition:
    opacity 180ms ease,
    transform 260ms var(--ui-crsc-ease);
}
.ui-crsc__more[data-open] .ui-crsc__card {
  opacity: 1;
  transform: none;
}
.ui-crsc__facts {
  display: flex;
  flex-wrap: wrap;
  gap: 6px 20px;
  margin: 0;
}
.ui-crsc__facts > div {
  display: grid;
  gap: 0;
}
.ui-crsc__facts dt {
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-crsc-muted);
}
.ui-crsc__facts dd {
  margin: 0;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crsc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-crsc__items {
  display: grid;
  gap: 2px;
  margin: 0;
  padding: 8px 0 0;
  list-style: none;
  border-top: 0.5px solid rgba(0, 0, 0, 0.06);
}
.ui-crsc__facts:only-child,
.ui-crsc__items:first-child {
  border-top: 0;
  padding-top: 0;
}
.ui-crsc__item {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 26px;
}
.ui-crsc__tile {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 5px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-shadow);
}
.ui-crsc__tile > svg {
  width: 12px;
  height: 12px;
}
.ui-crsc__tile-dot {
  width: 6px;
  height: 6px;
  border-radius: 2px;
  background: var(--ui-crsc-faint);
}
.ui-crsc__item-label {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12.5px;
  color: var(--ui-crsc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crsc__item-detail {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-crsc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crsc__shimmer {
  position: relative;
  justify-self: start;
  color: var(--ui-crsc-muted);
}
.ui-crsc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-crsc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-crsc-sweep 1.6s linear infinite;
  pointer-events: none;
}
.ui-crsc__system {
  display: flex;
  align-items: center;
  min-width: 0;
  height: 30px;
  margin: 0 -8px;
  padding: 0 8px 0 34px;
  border-radius: 8px;
  outline: none;
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-crsc__system-text {
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-faint);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-crsc__system-name {
  color: var(--ui-crsc-muted);
}
.ui-crsc__reply {
  flex: none;
  align-self: center;
  height: 18px;
  padding: 0 6px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-crsc-text);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-crsc__reply:hover {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc__composer {
  position: relative;
  padding-top: 6px;
}
.ui-crsc__write {
  position: relative;
  display: grid;
  gap: 8px;
  padding: 12px 10px 10px;
  border-radius: 16px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-shadow);
  cursor: text;
  transition: box-shadow 200ms ease;
}
.ui-crsc__field {
  display: block;
  width: 100%;
  min-height: 40px;
  max-height: 120px;
  margin: 0;
  padding: 0 4px;
  border: 0;
  background: transparent;
  font: inherit;
  color: var(--ui-crsc-strong);
  resize: none;
  outline: none;
  field-sizing: content;
  caret-color: var(--ui-crsc-accent);
}
.ui-crsc__field::placeholder {
  color: var(--ui-crsc-faint);
}
.ui-crsc__tools {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-crsc__at-btn {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 999px;
  font-size: 14px;
  font-weight: 500;
  color: var(--ui-crsc-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-crsc__at-btn:hover {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc__for {
  display: flex;
  flex: 1;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-muted);
  white-space: nowrap;
}
.ui-crsc__for-who {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: var(--ui-crsc-text);
}
.ui-crsc__for-who .ui-crsc__mark {
  transform: scale(0.8);
  margin: 0 -2px;
}
.ui-crsc__send {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-left: auto;
  border-radius: 999px;
  background: var(--ui-crsc-solid);
  color: var(--ui-crsc-on-solid);
  transition:
    background-color 200ms ease,
    transform 160ms var(--ui-crsc-ease);
}
.ui-crsc__send svg {
  width: 16px;
  height: 16px;
}
.ui-crsc__send:disabled {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-faint);
  cursor: default;
}
.ui-crsc__send:not(:disabled):active {
  transform: scale(0.94);
}
.ui-crsc__quote--draft {
  margin: 0;
}
.ui-crsc__unreply {
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  margin-left: auto;
  border-radius: 5px;
  font-size: 14px;
  line-height: 1;
  color: var(--ui-crsc-muted);
}
.ui-crsc__unreply:hover {
  background: var(--ui-crsc-fill);
  color: var(--ui-crsc-ink);
}
.ui-crsc__menu {
  position: absolute;
  bottom: calc(100% - 2px);
  left: 8px;
  z-index: 6;
  display: grid;
  gap: 1px;
  min-width: 220px;
  margin: 0;
  padding: 4px;
  list-style: none;
  border-radius: 10px;
  background: var(--ui-crsc-card);
  box-shadow: var(--ui-crsc-pop);
  animation: ui-crsc-fade 160ms ease both;
}
.ui-crsc__option {
  display: flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12.5px;
  color: var(--ui-crsc-ink);
  cursor: pointer;
}
.ui-crsc__option[aria-selected="true"] {
  background: var(--ui-crsc-fill);
}
.ui-crsc__option-model {
  margin-left: auto;
  font-size: 11.5px;
  color: var(--ui-crsc-faint);
}
.ui-crsc :is(.ui-crsc__msg, .ui-crsc__system)[data-fresh] {
  animation: ui-crsc-in 420ms var(--ui-crsc-ease) both;
}
.ui-crsc__empty {
  padding: 20px 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-crsc-muted);
}
.ui-crsc__new {
  position: absolute;
  bottom: 8px;
  left: 50%;
  z-index: 3;
  height: 26px;
  padding: 0 10px;
  border-radius: 13px;
  background: var(--ui-crsc-card);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 6px 16px -6px rgba(0, 0, 0, 0.2);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-crsc-ink);
  transform: translateX(-50%);
  animation: ui-crsc-fade 260ms ease both;
}
@container (max-width: 480px) {
  .ui-crsc__at {
    padding-left: 8px;
  }
  .ui-crsc__body {
    max-width: 100%;
  }
}
@media (pointer: coarse) {
  .ui-crsc__tab {
    height: 34px;
  }
  .ui-crsc__file {
    height: 30px;
    padding-inline: 10px 11px;
  }
  .ui-crsc__reply {
    position: relative;
  }
  .ui-crsc__reply::after {
    content: "";
    position: absolute;
    inset: -8px -4px;
  }
  .ui-crsc :is(.ui-crsc__at-btn, .ui-crsc__send, .ui-crsc__preview-close) {
    width: 34px;
    height: 34px;
  }
  .ui-crsc__option {
    height: 40px;
  }
}
@keyframes ui-crsc-in {
  from {
    opacity: 0;
    transform: translateY(6px);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-crsc-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-crsc-pop {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.98);
  }
}
@keyframes ui-crsc-flash {
  0%,
  100% {
    box-shadow: var(--ui-crsc-shadow);
  }
  20%,
  60% {
    box-shadow: 0 0 0 2px var(--ui-crsc-focus);
  }
}
@keyframes ui-crsc-pixel {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.2;
  }
}
@keyframes ui-crsc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-crsc-pulse {
  50% {
    opacity: 0.35;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-crsc *,
  .ui-crsc *::before,
  .ui-crsc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-crsc {
  --ui-crsc-card: #1c1c1f;
  --ui-crsc-strong: #ffffff;
  --ui-crsc-ink: rgba(255, 255, 255, 0.9);
  --ui-crsc-text: rgba(255, 255, 255, 0.62);
  --ui-crsc-muted: rgba(255, 255, 255, 0.45);
  --ui-crsc-faint: rgba(255, 255, 255, 0.28);
  --ui-crsc-pixel: rgba(255, 255, 255, 0.35);
  --ui-crsc-fill: rgba(255, 255, 255, 0.07);
  --ui-crsc-well: rgba(255, 255, 255, 0.05);
  --ui-crsc-you: rgba(255, 255, 255, 0.05);
  --ui-crsc-you-line: rgba(255, 255, 255, 0.09);
  --ui-crsc-line: rgba(255, 255, 255, 0.09);
  --ui-crsc-scrim: rgba(18, 18, 20, 0.7);
  --ui-crsc-accent: #5b9aff;
  --ui-crsc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-crsc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 2px 6px -2px rgba(0, 0, 0, 0.5);
  --ui-crsc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-crsc-shine: rgba(255, 255, 255, 0.95);
  --ui-crsc-solid: rgba(255, 255, 255, 0.92);
  --ui-crsc-on-solid: #141416;
  --ui-crsc-wait-bg: #fb6a0025;
  --ui-crsc-wait-fg: #ffa057;
  --ui-crsc-focus: rgba(77, 141, 255, 0.8);
}
`;function t(i){return r.jsx(c,{...i,variant:"clean",styles:e})}export{t as C};
