import{j as t}from"./workbench-model-BwgilGut.js";import{T as i}from"./ToolAccessMapView-5nHwjEqc.js";const e=`
.ui-tamc {
  --ui-tamc-card: #ffffff;
  --ui-tamc-strong: #000000;
  --ui-tamc-ink: rgba(0, 0, 0, 0.88);
  --ui-tamc-text: rgba(0, 0, 0, 0.65);
  --ui-tamc-muted: rgba(0, 0, 0, 0.65);
  --ui-tamc-faint: rgba(0, 0, 0, 0.65);
  --ui-tamc-line: rgba(0, 0, 0, 0.06);
  --ui-tamc-fill: rgba(0, 0, 0, 0.05);
  --ui-tamc-well: rgba(0, 0, 0, 0.025);
  --ui-tamc-rail: rgba(0, 0, 0, 0.13);
  --ui-tamc-used: #82bcff;
  --ui-tamc-glint: #2a7fff;
  --ui-tamc-off: #d9d9dc;
  --ui-tamc-brand-bg: #008ff519;
  --ui-tamc-brand-fg: #006ac6;
  --ui-tamc-ok-bg: #00a43319;
  --ui-tamc-ok-fg: #007a2d;
  --ui-tamc-warn-bg: #ff9c0029;
  --ui-tamc-warn-fg: #b74400;
  --ui-tamc-danger-bg: #f52b0018;
  --ui-tamc-danger-fg: #cd2200;
  --ui-tamc-focus: rgba(0, 96, 226, 0.7);
  --ui-tamc-solid: rgba(0, 0, 0, 0.88);
  --ui-tamc-on-solid: #fcfcfc;
  --ui-tamc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tamc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 2px 6px -2px rgba(0, 0, 0, 0.12);
  --ui-tamc-shadow-off:
    0 0 0 0.5px rgba(0, 0, 0, 0.1), 0 1px 1px -1px rgba(0, 0, 0, 0),
    0 1px 2px 0 rgba(0, 0, 0, 0);
  --ui-tamc-dim: 0.45;
  --ui-tamc-mono:
    ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
  --ui-tamc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-tamc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-tamc *,
.ui-tamc *::before,
.ui-tamc *::after {
  box-sizing: border-box;
}
:where(.ui-tamc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-tamc button:focus-visible {
  outline: 2px solid var(--ui-tamc-focus);
  outline-offset: 2px;
}
.ui-tamc textarea:focus-visible {
  outline: none;
}
.ui-tamc :is(.ui-tamc__agent-tab, .ui-tamc__call):focus-visible {
  outline-offset: -2px;
}
.ui-tamc p {
  margin: 0;
}
.ui-tamc svg {
  display: block;
  flex: none;
}
.ui-tamc__head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 0 2px 10px;
}
.ui-tamc__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-tamc-muted);
}
.ui-tamc__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-tamc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__sum {
  display: flex;
  flex: none;
  justify-content: flex-end;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tamc-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-tamc__sum-tools {
  min-width: 68px;
  text-align: right;
}
.ui-tamc__sum-calls {
  min-width: 66px;
  padding-left: 4px;
  text-align: right;
  white-space: pre;
}
.ui-tamc__live {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 18px;
  margin-left: auto;
  padding: 0 6px 0 4px;
  border-radius: 4px;
  background: var(--ui-tamc-brand-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-tamc-brand-fg);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  opacity: 0;
  transform: scale(0.96);
  transition:
    opacity 200ms ease,
    transform 200ms var(--ui-tamc-ease);
}
.ui-tamc__live[data-on] {
  opacity: 1;
  transform: none;
}
.ui-tamc__agents {
  display: flex;
  gap: 6px;
  min-width: 0;
  padding: 1px 1px 4px;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-tamc__agents[data-more] {
  -webkit-mask: linear-gradient(90deg, #000 calc(100% - 32px), transparent);
  mask: linear-gradient(90deg, #000 calc(100% - 32px), transparent);
}
.ui-tamc__agents::-webkit-scrollbar {
  display: none;
}
.ui-tamc__agent-tab {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 5px;
  border-radius: 7px;
  background: var(--ui-tamc-fill);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-tamc-text);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-tamc__agent-tab:hover {
  color: var(--ui-tamc-ink);
}
.ui-tamc__agent-tab[aria-selected="true"] {
  background: var(--ui-tamc-card);
  color: var(--ui-tamc-ink);
  box-shadow: var(--ui-tamc-shadow);
}
.ui-tamc__tab-avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 5px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  font-size: 9px;
  font-weight: 600;
  color: var(--ui-tamc-text);
}
.ui-tamc__tab-avatar[data-logo] > svg {
  width: 11px;
  height: 11px;
}
.ui-tamc__tab-name {
  max-width: 160px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__empty {
  margin: 0;
  padding: 28px 16px;
  text-align: center;
  color: var(--ui-tamc-muted);
}
.ui-tamc__stage {
  position: relative;
  height: var(--ui-tamc-map-h);
  transition: height 260ms var(--ui-tamc-ease);
}
.ui-tamc__map {
  position: absolute;
  inset: 0;
  transition: opacity 200ms ease;
}
.ui-tamc__map[aria-hidden] {
  opacity: 0;
}
.ui-tamc__lines {
  position: absolute;
  top: 0;
  left: 0;
  overflow: visible;
  pointer-events: none;
}
.ui-tamc__base {
  fill: none;
  stroke: var(--ui-tamc-off);
  stroke-width: 1.5;
  stroke-dasharray: 0.012 0.024;
  animation: ui-tamc-fade 300ms both;
}
.ui-tamc__line {
  fill: none;
  stroke: var(--ui-tamc-used);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-dasharray: 1;
  transition: stroke 200ms ease;
  animation: ui-tamc-grow 460ms calc(var(--ui-tamc-k) * 45ms)
    var(--ui-tamc-ease) both;
}
.ui-tamc__glint {
  fill: none;
  stroke: var(--ui-tamc-glint);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-dasharray: var(--ui-tamc-l) 2;
  animation: ui-tamc-glint 1300ms 460ms linear infinite both;
}
.ui-tamc__joint {
  fill: var(--ui-tamc-card);
  stroke: var(--ui-tamc-off);
  stroke-width: 1.5;
  transition: stroke 300ms ease;
  animation: ui-tamc-fade 200ms both;
}
.ui-tamc__joint[data-on] {
  stroke: var(--ui-tamc-used);
}
.ui-tamc__card {
  position: absolute;
  z-index: 1;
  width: 200px;
  padding: 10px 10px 9px;
  border-radius: 10px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  overflow: hidden;
  transform: translateY(-50%);
  animation: ui-tamc-in 300ms var(--ui-tamc-ease) both;
}
.ui-tamc__card-body {
  display: grid;
  gap: 6px;
  animation: ui-tamc-swap 340ms var(--ui-tamc-ease) both;
}
.ui-tamc__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-tamc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-tamc-text);
}
.ui-tamc__avatar[data-logo] > svg {
  width: 13px;
  height: 13px;
}
.ui-tamc__who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-tamc__name {
  overflow: hidden;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-tamc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__model {
  overflow: hidden;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-tamc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__status {
  display: inline-flex;
  flex: none;
  align-self: start;
  align-items: center;
  gap: 4px;
  height: 18px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-tamc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-tamc-text);
  white-space: nowrap;
}
.ui-tamc__status:has(svg) {
  padding-left: 4px;
}
.ui-tamc__status[data-status="running"] {
  background: var(--ui-tamc-brand-bg);
  color: var(--ui-tamc-brand-fg);
}
.ui-tamc__status[data-status="waiting"] {
  background: var(--ui-tamc-warn-bg);
  color: var(--ui-tamc-warn-fg);
}
.ui-tamc__status[data-status="done"] {
  background: var(--ui-tamc-ok-bg);
  color: var(--ui-tamc-ok-fg);
}
.ui-tamc__status[data-status="failed"] {
  background: var(--ui-tamc-danger-bg);
  color: var(--ui-tamc-danger-fg);
}
.ui-tamc__task {
  display: -webkit-box;
  overflow: hidden;
  overflow-wrap: anywhere;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tamc-text);
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-tamc__tool {
  position: absolute;
  z-index: 1;
  display: grid;
  align-content: center;
  gap: 2px;
  width: 130px;
  height: 46px;
  padding: 0 10px 0 8px;
  border-radius: 9px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  transition:
    box-shadow 320ms ease,
    background-color 320ms ease;
  animation: ui-tamc-move 440ms calc(140ms + var(--ui-tamc-k) * 45ms)
    var(--ui-tamc-ease) both;
}
.ui-tamc__tool:not([data-state="blocked"]):hover {
  box-shadow: var(--ui-tamc-shadow-hover);
}
.ui-tamc__tool > * {
  transition: opacity 320ms ease;
}
.ui-tamc__tool[data-state="blocked"] {
  background: transparent;
  box-shadow: var(--ui-tamc-shadow-off);
  cursor: default;
}
.ui-tamc__tool[data-state="blocked"] > * {
  opacity: var(--ui-tamc-dim);
}
.ui-tamc__tool[data-state="blocked"] .ui-tamc__tile {
  filter: grayscale(1);
}
.ui-tamc__tool[data-state="blocked"]:active {
  transform: none;
}
.ui-tamc__tool:active {
  transform: scale(0.98);
}
.ui-tamc__tool-top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-tamc__tile {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  font-size: 9px;
  font-weight: 600;
  color: var(--ui-tamc-text);
  transition: filter 320ms ease;
}
.ui-tamc__tile > svg {
  width: 10px;
  height: 10px;
}
.ui-tamc__tool-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-tamc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__count {
  flex: none;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-tamc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-tamc__tool-meta {
  display: flex;
  align-items: center;
  height: 16px;
  padding-left: 22px;
  overflow: hidden;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-tamc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-tamc__badge {
  display: inline-flex;
  align-items: center;
  height: 16px;
  padding: 0 5px;
  border-radius: 4px;
  font-size: 10.5px;
  font-weight: 500;
  line-height: 16px;
}
.ui-tamc__badge[data-kind="running"] {
  background: var(--ui-tamc-brand-bg);
  color: var(--ui-tamc-brand-fg);
}
.ui-tamc__badge[data-kind="failed"] {
  background: var(--ui-tamc-danger-bg);
  color: var(--ui-tamc-danger-fg);
}
.ui-tamc__none {
  position: absolute;
  right: 0;
  bottom: 14px;
  left: 0;
  text-align: center;
  font-size: 12px;
  color: var(--ui-tamc-muted);
}
.ui-tamc[data-narrow]
  :is(.ui-tamc__sum-tools, .ui-tamc__sum-dot, .ui-tamc__live-word) {
  display: none;
}
.ui-tamc[data-narrow] .ui-tamc__sum-calls {
  min-width: 56px;
  padding-left: 0;
}
.ui-tamc[data-narrow] .ui-tamc__live {
  gap: 3px;
  margin-right: 8px;
}
.ui-tamc[data-narrow] .ui-tamc__stage {
  height: auto;
  min-height: var(--ui-tamc-map-h);
}
.ui-tamc[data-narrow] .ui-tamc__map {
  position: relative;
  display: grid;
  gap: 10px;
  padding: 8px 0 2px;
}
.ui-tamc[data-narrow] .ui-tamc__card {
  position: relative;
  width: auto;
  transform: none;
}
.ui-tamc[data-narrow] .ui-tamc__tools {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(118px, 1fr));
  gap: 8px;
}
.ui-tamc[data-narrow] .ui-tamc__tool {
  position: relative;
  width: auto;
  --ui-tamc-from: 0 6px !important;
}
.ui-tamc[data-narrow] .ui-tamc__none {
  position: static;
}
.ui-tamc[data-narrow] .ui-tamc__map[aria-hidden] {
  position: absolute;
}
.ui-tamc__panel {
  position: absolute;
  inset: 8px 0 0;
  z-index: 2;
  display: flex;
  flex-direction: column;
  padding: 4px 12px 12px;
  border-radius: 12px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  overflow: hidden;
}
.ui-tamc__panel > * {
  animation: ui-tamc-fade 220ms 120ms both;
}
.ui-tamc__panel-head {
  display: flex;
  flex: none;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 36px;
}
.ui-tamc__back {
  display: grid;
  flex: none;
  place-items: center;
  width: 24px;
  height: 24px;
  margin-left: -2px;
  border-radius: 6px;
  color: var(--ui-tamc-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-tamc__back:hover {
  background: var(--ui-tamc-fill);
  color: var(--ui-tamc-ink);
}
.ui-tamc__panel-name {
  flex: none;
  font-weight: 500;
  color: var(--ui-tamc-strong);
  white-space: nowrap;
}
.ui-tamc__panel-desc {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-tamc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__panel-sum {
  flex: none;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tamc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-tamc__panel-body {
  display: grid;
  flex: 1;
  grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
  gap: 12px;
  min-height: 0;
}
.ui-tamc__calls {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  align-content: start;
  gap: 2px;
  min-height: 0;
  margin: 0;
  padding: 2px;
  overflow-y: auto;
  overscroll-behavior: contain;
  list-style: none;
  scrollbar-width: thin;
}
.ui-tamc__call {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  height: 30px;
  padding: 0 8px 0 6px;
  border-radius: 7px;
  transition: background-color 150ms ease;
}
.ui-tamc__call:hover {
  background: var(--ui-tamc-well);
}
.ui-tamc__call[aria-pressed="true"] {
  background: var(--ui-tamc-fill);
}
.ui-tamc__call-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 14px;
  color: var(--ui-tamc-muted);
}
.ui-tamc__call-icon[data-status="failed"] {
  color: var(--ui-tamc-danger-fg);
}
.ui-tamc__call-text {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-family: var(--ui-tamc-mono);
  font-size: 11.5px;
  line-height: 16px;
  color: var(--ui-tamc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-tamc__chip {
  flex: none;
  height: 16px;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-tamc-fill);
  font-size: 10.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-tamc-text);
}
.ui-tamc__call-time {
  flex: none;
  min-width: 34px;
  font-size: 11px;
  color: var(--ui-tamc-muted);
  text-align: right;
  font-variant-numeric: tabular-nums;
}
.ui-tamc__detail {
  display: flex;
  flex-direction: column;
  gap: 6px;
  min-height: 0;
  padding-top: 2px;
  animation: ui-tamc-fade 180ms both;
}
.ui-tamc__label {
  display: flex;
  flex: none;
  align-items: center;
  gap: 6px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-tamc-muted);
}
.ui-tamc__label-meta {
  margin-left: auto;
  font-size: 11px;
  letter-spacing: 0;
  text-transform: none;
  color: var(--ui-tamc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-tamc__code {
  flex: 0 1 auto;
  min-height: 34px;
  margin: 0;
  padding: 8px 10px;
  overflow: auto;
  border: 0;
  border-radius: 7px;
  background: var(--ui-tamc-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-tamc-line);
  font-family: var(--ui-tamc-mono);
  font-size: 11.5px;
  line-height: 17px;
  color: var(--ui-tamc-ink);
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  scrollbar-width: thin;
}
.ui-tamc__code[data-error] {
  color: var(--ui-tamc-danger-fg);
}
.ui-tamc__edit {
  width: 100%;
  min-height: 108px;
  resize: none;
  background: var(--ui-tamc-card);
  box-shadow: inset 0 0 0 0.5px var(--ui-tamc-rail);
  outline: none;
}
.ui-tamc__edit[aria-invalid="true"] {
  box-shadow: inset 0 0 0 0.5px var(--ui-tamc-danger-fg);
}
.ui-tamc__waiting {
  font-family: inherit;
  font-size: 12px;
  background:
    linear-gradient(
        90deg,
        var(--ui-tamc-muted) 0 40%,
        var(--ui-tamc-faint) 50%,
        var(--ui-tamc-muted) 60% 100%
      )
      0 0 / 250% 100%,
    var(--ui-tamc-well);
  -webkit-background-clip: text, border-box;
  background-clip: text, border-box;
  color: transparent;
  animation: ui-tamc-shine 1000ms linear infinite;
}
.ui-tamc__actions {
  display: flex;
  flex: none;
  align-items: center;
  justify-content: flex-end;
  gap: 6px;
  margin-top: auto;
  padding-top: 4px;
}
.ui-tamc__invalid {
  margin-right: auto;
  font-size: 12px;
  color: var(--ui-tamc-danger-fg);
}
.ui-tamc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-tamc-card);
  box-shadow: var(--ui-tamc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-tamc-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-tamc__btn:hover {
  background: var(--ui-tamc-well);
}
.ui-tamc__btn--primary {
  padding-left: 9px;
  background: var(--ui-tamc-solid);
  box-shadow: none;
  color: var(--ui-tamc-on-solid);
}
.ui-tamc__btn--primary:hover {
  background: var(--ui-tamc-solid);
  opacity: 0.88;
}
.ui-tamc__btn:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-tamc__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-tamc[data-narrow] .ui-tamc__panel-desc {
  display: none;
}
.ui-tamc[data-narrow] .ui-tamc__panel-body {
  grid-template-columns: minmax(0, 1fr);
  grid-template-rows: auto minmax(0, 1fr);
}
.ui-tamc[data-narrow] .ui-tamc__calls {
  max-height: 98px;
}
.ui-tamc__spin {
  animation: ui-tamc-spin 900ms linear infinite;
}
@media (pointer: coarse) {
  .ui-tamc__agent-tab {
    height: 32px;
  }
  .ui-tamc__call {
    height: 36px;
  }
  .ui-tamc__back {
    width: 32px;
    height: 32px;
  }
}
@keyframes ui-tamc-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-tamc-glint {
  from {
    stroke-dashoffset: -1;
  }
  to {
    stroke-dashoffset: 0.3;
  }
}
@keyframes ui-tamc-grow {
  from {
    stroke-dashoffset: -1;
  }
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-tamc-move {
  from {
    opacity: 0;
    translate: var(--ui-tamc-from);
  }
}
@keyframes ui-tamc-swap {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
}
@keyframes ui-tamc-in {
  from {
    opacity: 0;
    scale: 0.96;
  }
}
@keyframes ui-tamc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-tamc-shine {
  from {
    background-position:
      100% 0,
      0 0;
  }
  to {
    background-position:
      0 0,
      0 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-tamc *,
  .ui-tamc *::before,
  .ui-tamc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-tamc__waiting {
    background: var(--ui-tamc-well);
    color: var(--ui-tamc-muted);
  }
  .ui-tamc__glint {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-tamc {
  --ui-tamc-card: #1c1c1f;
  --ui-tamc-strong: #ffffff;
  --ui-tamc-ink: rgba(255, 255, 255, 0.9);
  --ui-tamc-text: rgba(255, 255, 255, 0.62);
  --ui-tamc-muted: rgba(255, 255, 255, 0.45);
  --ui-tamc-faint: rgba(255, 255, 255, 0.28);
  --ui-tamc-line: rgba(255, 255, 255, 0.08);
  --ui-tamc-fill: rgba(255, 255, 255, 0.07);
  --ui-tamc-well: rgba(255, 255, 255, 0.035);
  --ui-tamc-rail: rgba(255, 255, 255, 0.16);
  --ui-tamc-used: #3f78bf;
  --ui-tamc-glint: #b9d8ff;
  --ui-tamc-off: #3a3a3f;
  --ui-tamc-brand-bg: #0077ff3a;
  --ui-tamc-brand-fg: #70b8ff;
  --ui-tamc-ok-bg: #00f04a1f;
  --ui-tamc-ok-fg: #3dd68c;
  --ui-tamc-warn-bg: #fb6a0025;
  --ui-tamc-warn-fg: #ffa057;
  --ui-tamc-danger-bg: #ff35232b;
  --ui-tamc-danger-fg: #ff977d;
  --ui-tamc-focus: rgba(77, 141, 255, 0.8);
  --ui-tamc-solid: rgba(255, 255, 255, 0.92);
  --ui-tamc-on-solid: #141416;
  --ui-tamc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tamc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 2px 6px -2px rgba(0, 0, 0, 0.5);
  --ui-tamc-shadow-off:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0);
}
`;function n(a){return t.jsx(i,{...a,styles:e,clean:!0})}export{n as T};
