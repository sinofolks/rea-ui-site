import{j as i}from"./workbench-model-BwgilGut.js";import{C as e,F as s,S as p,I as a,R as r,T as o}from"./stepper-form-tsDnNktI.js";const c=`.ui-stpc {
  --ui-stpc-card: #ffffff;
  --ui-stpc-ink: rgba(0, 0, 0, 0.88);
  --ui-stpc-strong: #000000;
  --ui-stpc-text: rgba(0, 0, 0, 0.65);
  --ui-stpc-muted: rgba(0, 0, 0, 0.65);
  --ui-stpc-faint: rgba(0, 0, 0, 0.65);
  --ui-stpc-icon: rgba(0, 0, 0, 0.65);
  --ui-stpc-line: rgba(0, 0, 0, 0.06);
  --ui-stpc-fill: rgba(0, 0, 0, 0.06);
  --ui-stpc-fill-strong: rgba(0, 0, 0, 0.1);
  --ui-stpc-wash: rgba(0, 0, 0, 0.03);
  --ui-stpc-wash-soft: rgba(0, 0, 0, 0.015);
  --ui-stpc-accent: #0060e2;
  --ui-stpc-accent-soft: rgba(0, 96, 226, 0.08);
  --ui-stpc-accent-fill: rgba(0, 96, 226, 0.05);
  --ui-stpc-accent-line: rgba(0, 96, 226, 0.35);
  --ui-stpc-ok: #0f783c;
  --ui-stpc-ok-soft: rgba(26, 154, 82, 0.1);
  --ui-stpc-danger: #bf383d;
  --ui-stpc-danger-soft: rgba(229, 72, 77, 0.55);
  --ui-stpc-chip: rgba(0, 0, 0, 0.88);
  --ui-stpc-chip-hover: rgba(0, 0, 0, 0.8);
  --ui-stpc-on-chip: #fcfcfc;
  --ui-stpc-white-hover: #fafafa;
  --ui-stpc-focus: rgba(0, 96, 226, 0.7);
  --ui-stpc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-stpc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.12), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-stpc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 520px;
  border-radius: 10px;
  background: var(--ui-stpc-card);
  box-shadow: var(--ui-stpc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-stpc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-stpc *,
.ui-stpc *::before,
.ui-stpc *::after {
  box-sizing: border-box;
}
:where(.ui-stpc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-stpc) svg {
  display: block;
  flex: none;
}
:where(.ui-stpc) :is(h2, p, dl, dd, ul, ol) {
  margin: 0;
}
.ui-stpc button:focus-visible {
  outline: 2px solid var(--ui-stpc-focus);
  outline-offset: 2px;
}
.ui-stpc__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.65;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-stpc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-stpc__draw {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2.2;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-stpc__draw path {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-stpc-draw 360ms var(--ui-stpc-ease) 80ms forwards;
}
.ui-stpc__head {
  padding: 16px 20px 0;
}
.ui-stpc__steps {
  position: relative;
}
.ui-stpc__list {
  display: grid;
  grid-template-columns: repeat(var(--ui-stpc-n), minmax(0, 1fr));
  gap: 8px;
  padding: 0;
  list-style: none;
}
.ui-stpc__step {
  position: relative;
  display: grid;
  min-width: 0;
}
.ui-stpc__step-btn {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  align-items: center;
  column-gap: 6px;
  row-gap: 6px;
  min-width: 0;
  margin: -4px;
  padding: 4px 4px 2px;
  border-radius: 6px;
  text-align: left;
  cursor: default;
  transition: background-color 100ms ease;
}
button.ui-stpc__step-btn {
  cursor: pointer;
}
button.ui-stpc__step-btn:hover {
  background: var(--ui-stpc-wash);
}
.ui-stpc__bar {
  position: relative;
  grid-column: 1 / -1;
  height: 2px;
  overflow: hidden;
  border-radius: 1px;
  background: var(--ui-stpc-line);
}
.ui-stpc__bar::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: var(--ui-stpc-accent);
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform 360ms var(--ui-stpc-ease);
}
.ui-stpc__step:not([data-state="upcoming"]) .ui-stpc__bar::after {
  transform: none;
}
.ui-stpc__mark {
  display: inline-flex;
  flex: none;
  align-items: center;
  justify-content: flex-start;
  min-width: 12px;
  height: 16px;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-stpc-faint);
  transition: color 200ms ease;
}
.ui-stpc__mark > span {
  animation: ui-stpc-in 260ms var(--ui-stpc-ease) both;
}
.ui-stpc__mark .ui-stpc__draw {
  width: 12px;
  height: 12px;
  stroke-width: 2.4;
}
.ui-stpc__step[data-state="current"] .ui-stpc__mark {
  color: var(--ui-stpc-accent);
}
.ui-stpc__step[data-state="done"] .ui-stpc__mark {
  color: var(--ui-stpc-accent);
}
.ui-stpc__step-label {
  overflow: hidden;
  min-width: 0;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-stpc-muted);
  transition: color 200ms ease;
}
.ui-stpc__step[data-state="done"] .ui-stpc__step-label {
  color: var(--ui-stpc-text);
}
.ui-stpc__step[data-state="current"] .ui-stpc__step-label {
  color: var(--ui-stpc-strong);
}
button.ui-stpc__step-btn:hover .ui-stpc__step-label {
  color: var(--ui-stpc-ink);
}
.ui-stpc__compact {
  display: none;
}
.ui-stpc__compact-text {
  display: flex;
  min-width: 0;
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  font-variant-numeric: tabular-nums;
  color: var(--ui-stpc-muted);
  white-space: nowrap;
  animation: ui-stpc-in 280ms var(--ui-stpc-ease) both;
}
.ui-stpc__compact-dot {
  margin: 0 6px;
  color: var(--ui-stpc-faint);
}
.ui-stpc__compact-title {
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--ui-stpc-strong);
}
.ui-stpc__card {
  display: grid;
  min-width: 0;
}
.ui-stpc__viewport {
  position: relative;
  overflow: hidden;
  transition: height 360ms var(--ui-stpc-ease);
}
.ui-stpc__pane {
  padding: 20px 20px 20px;
  animation: ui-stpc-enter 360ms var(--ui-stpc-ease) both;
}
.ui-stpc__pane[data-dir="-1"] {
  animation-name: ui-stpc-enter-back;
}
.ui-stpc__pane[data-first] {
  animation: none;
}
.ui-stpc__pane[data-pane="leaving"] {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  pointer-events: none;
  animation: ui-stpc-leave 280ms var(--ui-stpc-ease) both;
}
.ui-stpc__pane[data-pane="leaving"][data-dir="-1"] {
  animation-name: ui-stpc-leave-back;
}
.ui-stpc__heading {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-stpc-strong);
  outline: none;
  overflow-wrap: anywhere;
}
.ui-stpc__desc {
  color: var(--ui-stpc-text);
  text-wrap: pretty;
  white-space: pre-line;
  overflow-wrap: anywhere;
}
.ui-stpc__body {
  display: grid;
  gap: 16px;
  margin-top: 16px;
}
.ui-stpc__field {
  display: grid;
  min-width: 0;
}
.ui-stpc__label {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 8px;
  margin: 0 0 6px 2px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-stpc-text);
}
.ui-stpc__label-text {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-stpc__optional {
  flex: none;
  font-weight: 400;
  color: var(--ui-stpc-muted);
}
.ui-stpc__control {
  min-width: 0;
}
.ui-stpc__input,
.ui-stpc__tags {
  display: flex;
  align-items: center;
  min-width: 0;
  height: 32px;
  border-radius: 8px;
  background: var(--ui-stpc-card);
  box-shadow: var(--ui-stpc-shadow);
  transition: box-shadow 120ms ease;
  cursor: text;
}
.ui-stpc__input:hover,
.ui-stpc__tags:hover {
  box-shadow: var(--ui-stpc-shadow-hover);
}
.ui-stpc__input:focus-within,
.ui-stpc__tags:focus-within {
  outline: none;
  box-shadow: var(--ui-stpc-shadow-hover);
}
.ui-stpc__input[data-invalid],
.ui-stpc__tags[data-invalid] {
  box-shadow:
    0 0 0 0.5px var(--ui-stpc-danger),
    0 1px 2px 0 rgba(229, 72, 77, 0.08);
}
.ui-stpc__input[data-invalid]:focus-within,
.ui-stpc__tags[data-invalid]:focus-within {
  box-shadow:
    0 0 0 1px var(--ui-stpc-danger),
    0 1px 2px 0 rgba(229, 72, 77, 0.08);
}
.ui-stpc__input input,
.ui-stpc__tags-input {
  flex: 1;
  min-width: 0;
  height: 32px;
  margin: 0;
  padding: 0 10px;
  border: 0;
  outline: none;
  background: none;
  font: inherit;
  color: var(--ui-stpc-ink);
}
.ui-stpc__input input::placeholder,
.ui-stpc__tags-input::placeholder {
  color: var(--ui-stpc-faint);
}
.ui-stpc__prefix {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 60%;
  overflow: hidden;
  padding-left: 10px;
  color: var(--ui-stpc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  user-select: none;
}
.ui-stpc__prefix + input {
  padding-left: 0;
}
.ui-stpc__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  transition:
    grid-template-rows 260ms var(--ui-stpc-ease),
    opacity 200ms ease;
}
.ui-stpc__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
}
.ui-stpc__fold > div {
  min-height: 0;
  overflow: hidden;
}
.ui-stpc__msg,
.ui-stpc__hint {
  padding: 6px 0 0 2px;
  font-size: 12px;
  line-height: 16px;
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-stpc__msg {
  color: var(--ui-stpc-danger);
  animation: ui-stpc-in 240ms var(--ui-stpc-ease) both;
}
.ui-stpc__hint {
  color: var(--ui-stpc-muted);
}
.ui-stpc__tags {
  gap: 4px;
  padding: 0 4px;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
  overscroll-behavior-x: contain;
}
.ui-stpc__tags::-webkit-scrollbar {
  display: none;
}
.ui-stpc__chips {
  display: contents;
  padding: 0;
  list-style: none;
}
.ui-stpc__chip {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  max-width: 220px;
  height: 24px;
  padding: 0 3px 0 8px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-stpc-fill);
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-stpc-ink);
  white-space: nowrap;
  animation: ui-stpc-chip 260ms var(--ui-stpc-ease) both;
}
.ui-stpc__chip[data-leaving] {
  pointer-events: none;
}
.ui-stpc__chip-text {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-stpc__chip-x {
  display: grid;
  place-items: center;
  flex: none;
  width: 18px;
  height: 18px;
  border-radius: 4px;
  color: var(--ui-stpc-icon);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-stpc__chip-x .ui-stpc__glyph {
  width: 12px;
  height: 12px;
  stroke-width: 1.9;
}
.ui-stpc__chip-x:hover {
  background: var(--ui-stpc-fill);
  color: var(--ui-stpc-ink);
}
.ui-stpc__chip[data-leaving] .ui-stpc__chip-x {
  background: none;
}
.ui-stpc__tags-input {
  flex: 1 0 140px;
  height: 24px;
  padding: 0 6px;
}
.ui-stpc__tags-input:first-child {
  padding-left: 6px;
}
.ui-stpc__choices {
  position: relative;
  display: grid;
  grid-auto-columns: minmax(0, 1fr);
  grid-auto-flow: column;
  gap: 8px;
}
.ui-stpc__ring {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 2;
  border-radius: 8px;
  box-shadow: 0 0 0 0.5px var(--ui-stpc-accent-line);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 260ms var(--ui-stpc-ease),
    width 260ms var(--ui-stpc-ease),
    height 260ms var(--ui-stpc-ease),
    opacity 160ms ease;
}
.ui-stpc__choice {
  position: relative;
  display: grid;
  align-content: start;
  gap: 2px;
  min-width: 0;
  padding: 10px 12px 12px;
  border-radius: 8px;
  background: var(--ui-stpc-card);
  box-shadow: var(--ui-stpc-shadow);
  text-align: left;
  transition: background-color 100ms ease;
}
.ui-stpc__choice:hover {
  background: var(--ui-stpc-wash-soft);
}
.ui-stpc__choice[aria-checked="true"] {
  background: var(--ui-stpc-accent-fill);
}
.ui-stpc__choice:focus-visible {
  outline-offset: 2px;
}
.ui-stpc__choice-top {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 2px 6px;
  min-width: 0;
}
.ui-stpc__choice-title {
  min-width: min(100%, 72px);
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-stpc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-stpc__badge {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-stpc-accent-soft);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-stpc-accent);
}
.ui-stpc__radio {
  position: relative;
  flex: none;
  width: 14px;
  height: 14px;
  margin-left: auto;
  border-radius: 50%;
  box-shadow: inset 0 0 0 1px var(--ui-stpc-fill-strong);
  transition: box-shadow 200ms ease;
}
.ui-stpc__radio::after {
  content: "";
  position: absolute;
  inset: 3.5px;
  border-radius: 50%;
  background: var(--ui-stpc-accent);
  transform: scale(0);
  transition: transform 280ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-stpc__choice[aria-checked="true"] .ui-stpc__radio {
  box-shadow: inset 0 0 0 1px var(--ui-stpc-accent);
}
.ui-stpc__choice[aria-checked="true"] .ui-stpc__radio::after {
  transform: scale(1);
}
.ui-stpc__choice-aside {
  font-variant-numeric: tabular-nums;
  color: var(--ui-stpc-ink);
}
.ui-stpc__choice-desc {
  margin-top: 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stpc-text);
  text-wrap: pretty;
  overflow-wrap: anywhere;
}
.ui-stpc__review {
  display: grid;
  border-radius: 8px;
  box-shadow: var(--ui-stpc-shadow);
}
.ui-stpc__review-row {
  display: grid;
  grid-template-columns: 96px minmax(0, 1fr) auto;
  align-items: baseline;
  gap: 12px;
  padding: 10px 8px 10px 12px;
}
.ui-stpc__review-row + .ui-stpc__review-row {
  border-top: 0.5px solid var(--ui-stpc-line);
}
.ui-stpc__review dt {
  min-width: 0;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-stpc-muted);
  overflow-wrap: anywhere;
}
.ui-stpc__review dd {
  min-width: 0;
  color: var(--ui-stpc-ink);
  overflow-wrap: anywhere;
}
.ui-stpc__edit {
  height: 24px;
  margin: -2px 0;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-stpc-text);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-stpc__edit:hover {
  background: var(--ui-stpc-wash);
  color: var(--ui-stpc-ink);
}
.ui-stpc__success {
  display: grid;
  justify-items: center;
  padding: 16px 0 8px;
  text-align: center;
}
.ui-stpc__success-check {
  display: grid;
  place-items: center;
  width: 36px;
  height: 36px;
  margin-bottom: 12px;
  border-radius: 50%;
  background: var(--ui-stpc-ok-soft);
  color: var(--ui-stpc-ok);
  animation: ui-stpc-pop 520ms cubic-bezier(0.34, 1.56, 0.64, 1) 120ms both;
}
.ui-stpc__success-check .ui-stpc__draw {
  width: 18px;
  height: 18px;
  stroke-width: 2;
}
.ui-stpc__success-check .ui-stpc__draw path {
  animation-delay: 320ms;
}
.ui-stpc__success .ui-stpc__heading {
  animation: ui-stpc-in 340ms var(--ui-stpc-ease) 220ms both;
}
.ui-stpc__success .ui-stpc__desc {
  max-width: 40ch;
  text-wrap: balance;
  animation: ui-stpc-in 340ms var(--ui-stpc-ease) 290ms both;
}
.ui-stpc__success-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 8px;
  margin-top: 16px;
  animation: ui-stpc-in 340ms var(--ui-stpc-ease) 360ms both;
}
.ui-stpc__foot-fold {
  position: sticky;
  bottom: 0;
  z-index: 3;
  display: grid;
  grid-template-rows: 1fr;
  border-radius: 0 0 10px 10px;
  background: var(--ui-stpc-card);
  transition:
    grid-template-rows 340ms var(--ui-stpc-ease),
    opacity 200ms ease;
}
.ui-stpc__foot-fold[data-hidden] {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-stpc__foot {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 0;
  overflow: hidden;
  padding: 0 12px;
  border-top: 0.5px solid var(--ui-stpc-line);
}
.ui-stpc__foot::before {
  content: "";
  flex: none;
  width: 0;
  height: 48px;
  margin-right: -12px;
}
.ui-stpc__btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  height: 28px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  transition:
    background-color 100ms ease,
    opacity 200ms ease,
    transform 120ms ease,
    width 300ms var(--ui-stpc-ease),
    visibility 200ms;
}
.ui-stpc__btn-ghost,
.ui-stpc__btn-secondary {
  gap: 6px;
  padding: 0 10px 0 8px;
  background: var(--ui-stpc-card);
  box-shadow: var(--ui-stpc-shadow);
  color: var(--ui-stpc-strong);
}
.ui-stpc__btn-secondary {
  padding: 0 10px;
}
.ui-stpc__btn-ghost .ui-stpc__glyph {
  color: var(--ui-stpc-icon);
}
.ui-stpc__btn-ghost:hover,
.ui-stpc__btn-secondary:hover {
  background: var(--ui-stpc-white-hover);
}
.ui-stpc__btn-ghost[data-hidden] {
  opacity: 0;
  visibility: hidden;
}
.ui-stpc__btn-primary {
  margin-left: auto;
  overflow: hidden;
  background: var(--ui-stpc-chip);
  color: var(--ui-stpc-on-chip);
}
.ui-stpc__btn-primary:hover {
  background: var(--ui-stpc-chip-hover);
}
.ui-stpc__btn:active {
  transform: scale(0.97);
}
.ui-stpc__btn-primary[aria-disabled="true"] {
  opacity: 0.35;
}
.ui-stpc__btn-primary[data-busy] {
  opacity: 0.7;
  cursor: progress;
}
.ui-stpc__btn-inner {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  max-width: calc(100cqw - 112px);
  padding: 0 10px;
}
.ui-stpc__btn-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  animation: ui-stpc-in 240ms var(--ui-stpc-ease) both;
}
.ui-stpc__spinner {
  width: 12px;
  height: 12px;
  border-radius: 50%;
  border: 1.5px solid currentColor;
  border-right-color: transparent;
  animation: ui-stpc-spin 700ms linear infinite;
}
.ui-stpc__submit-error {
  flex: 1 1 auto;
  min-width: 0;
  overflow-wrap: anywhere;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-stpc-danger);
  animation: ui-stpc-in 240ms var(--ui-stpc-ease) both;
}
@keyframes ui-stpc-in {
  from {
    opacity: 0;
    transform: translateY(3px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-stpc-enter {
  from {
    opacity: 0;
    transform: translateX(24px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stpc-enter-back {
  from {
    opacity: 0;
    transform: translateX(-24px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stpc-leave {
  to {
    opacity: 0;
    transform: translateX(-24px);
  }
}
@keyframes ui-stpc-leave-back {
  to {
    opacity: 0;
    transform: translateX(24px);
  }
}
@keyframes ui-stpc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-stpc-pop {
  0% {
    opacity: 0;
    transform: scale(0.4);
  }
  60% {
    opacity: 1;
    transform: scale(1.08);
  }
  100% {
    opacity: 1;
    transform: scale(1);
  }
}
@keyframes ui-stpc-chip {
  from {
    opacity: 0;
    transform: scale(0.85);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-stpc-spin {
  to {
    transform: rotate(360deg);
  }
}
@container (max-width: 420px) {
  .ui-stpc__head {
    padding: 14px 16px 0;
  }
  .ui-stpc__compact {
    display: flex;
    margin-bottom: 8px;
  }
  .ui-stpc__list {
    gap: min(8px, calc((100cqw - 32px) / (var(--ui-stpc-n) * 4)));
  }
  .ui-stpc__step-btn {
    row-gap: 0;
    padding-bottom: 4px;
  }
  .ui-stpc__mark,
  .ui-stpc__step-label {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
  .ui-stpc__pane {
    padding: 16px 16px 16px;
  }
  .ui-stpc__foot {
    padding: 0 12px;
  }
  .ui-stpc__choices {
    grid-template-columns: minmax(0, 1fr);
    grid-auto-flow: row;
  }
  .ui-stpc__choice {
    grid-template-columns: minmax(0, 1fr) auto;
    column-gap: 10px;
    padding: 10px 12px;
  }
  .ui-stpc__choice-top {
    grid-column: 1;
  }
  .ui-stpc__choice-aside {
    grid-column: 2;
    grid-row: 1;
    align-self: center;
  }
  .ui-stpc__choice-desc {
    grid-column: 1 / -1;
    margin-top: 0;
  }
  .ui-stpc__radio {
    order: -1;
    margin-left: 0;
    margin-right: 2px;
  }
  .ui-stpc__review-row {
    grid-template-columns: minmax(0, 1fr) auto;
    row-gap: 0;
  }
  .ui-stpc__review dt {
    grid-column: 1;
  }
  .ui-stpc__review dd {
    grid-column: 1;
    grid-row: 2;
  }
  .ui-stpc__edit {
    grid-column: 2;
    grid-row: 1 / span 2;
    align-self: center;
    margin: 0;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-stpc__input input,
  .ui-stpc__tags-input,
  .ui-stpc__prefix {
    font-size: 16px;
  }
  .ui-stpc__input,
  .ui-stpc__tags,
  .ui-stpc__input input {
    height: 40px;
  }
  .ui-stpc__chip {
    height: 30px;
  }
  .ui-stpc__chip-x {
    width: 26px;
    height: 26px;
  }
  .ui-stpc__tags-input {
    height: 30px;
  }
  .ui-stpc__btn {
    height: 36px;
  }
  .ui-stpc__foot::before {
    height: 56px;
  }
  .ui-stpc__edit {
    height: 34px;
    padding: 0 12px;
  }
  .ui-stpc__step-btn {
    padding-top: 10px;
    padding-bottom: 8px;
    margin: -10px -4px -8px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-stpc *,
  .ui-stpc *::before,
  .ui-stpc *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-stpc {
  --ui-stpc-card: #1c1c1e;
  --ui-stpc-ink: rgba(255, 255, 255, 0.9);
  --ui-stpc-strong: #ffffff;
  --ui-stpc-text: rgba(255, 255, 255, 0.62);
  --ui-stpc-muted: rgba(255, 255, 255, 0.46);
  --ui-stpc-faint: rgba(255, 255, 255, 0.3);
  --ui-stpc-icon: rgba(255, 255, 255, 0.5);
  --ui-stpc-line: rgba(255, 255, 255, 0.08);
  --ui-stpc-fill: rgba(255, 255, 255, 0.08);
  --ui-stpc-fill-strong: rgba(255, 255, 255, 0.16);
  --ui-stpc-wash: rgba(255, 255, 255, 0.04);
  --ui-stpc-wash-soft: rgba(255, 255, 255, 0.025);
  --ui-stpc-accent: #4d8dff;
  --ui-stpc-accent-soft: rgba(77, 141, 255, 0.14);
  --ui-stpc-accent-fill: rgba(77, 141, 255, 0.09);
  --ui-stpc-accent-line: rgba(77, 141, 255, 0.5);
  --ui-stpc-ok: #3ec27a;
  --ui-stpc-ok-soft: rgba(62, 194, 122, 0.14);
  --ui-stpc-danger: #ff6369;
  --ui-stpc-chip: rgba(255, 255, 255, 0.9);
  --ui-stpc-chip-hover: rgba(255, 255, 255, 0.8);
  --ui-stpc-on-chip: #111113;
  --ui-stpc-white-hover: #232326;
  --ui-stpc-focus: rgba(77, 141, 255, 0.8);
  --ui-stpc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-stpc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;function d(t){return i.jsx(p,{...t,variant:"clean",styles:c})}function l(t){return i.jsx(s,{...t,variant:"clean"})}function _(t){return i.jsx(a,{...t,variant:"clean"})}function h(t){return i.jsx(o,{...t,variant:"clean"})}function g(t){return i.jsx(e,{...t,variant:"clean"})}function x(t){return i.jsx(r,{...t,variant:"clean"})}export{g as S,l as a,d as b,_ as c,x as d,h as e};
