import{j as e}from"./workbench-model-BwgilGut.js";import{B as s}from"./billing-schedule-7-4YMwMQ.js";const a=`.ui-bsc {
  --ui-bsc-card: #ffffff;
  --ui-bsc-ink: rgba(0, 0, 0, 0.88);
  --ui-bsc-strong: #000000;
  --ui-bsc-text: rgba(0, 0, 0, 0.65);
  --ui-bsc-muted: rgba(0, 0, 0, 0.65);
  --ui-bsc-faint: rgba(0, 0, 0, 0.65);
  --ui-bsc-icon: rgba(0, 0, 0, 0.65);
  --ui-bsc-line: rgba(0, 0, 0, 0.06);
  --ui-bsc-wash: rgba(0, 0, 0, 0.03);
  --ui-bsc-fill: rgba(0, 0, 0, 0.06);
  --ui-bsc-accent: #0060e2;
  --ui-bsc-pick: rgba(0, 96, 226, 0.05);
  --ui-bsc-pick-edge: rgba(0, 96, 226, 0.35);
  --ui-bsc-focus: rgba(0, 96, 226, 0.7);
  --ui-bsc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bsc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.12), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bsc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bsc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 560px;
  border-radius: 10px;
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-bsc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-bsc *,
.ui-bsc *::before,
.ui-bsc *::after {
  box-sizing: border-box;
}
:where(.ui-bsc) button,
:where(.ui-bsc) select,
:where(.ui-bsc) input {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
}
:where(.ui-bsc) button {
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-bsc button:focus-visible,
.ui-bsc select:focus-visible {
  outline: 2px solid var(--ui-bsc-focus);
  outline-offset: 2px;
}
.ui-bsc svg {
  display: block;
  width: 16px;
  height: 16px;
  flex: none;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.65;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-bsc__head {
  display: grid;
  gap: 2px;
  padding: 14px 14px 12px;
}
.ui-bsc__title {
  margin: 0;
  overflow-wrap: anywhere;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-bsc-strong);
}
.ui-bsc__summary {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  color: var(--ui-bsc-text);
  white-space: nowrap;
}
.ui-bsc__phase {
  min-width: 0;
  max-width: 100%;
  margin-left: -4px;
  padding: 0 4px;
  border-radius: 5px;
  font-weight: 500;
  color: var(--ui-bsc-ink);
  outline: none;
  text-overflow: ellipsis;
  field-sizing: content;
  transition:
    background-color 120ms ease,
    box-shadow 120ms ease;
}
.ui-bsc__phase:hover {
  background: var(--ui-bsc-wash);
}
.ui-bsc__phase:focus {
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow-hover);
}
.ui-bsc__dot {
  color: var(--ui-bsc-faint);
}
.ui-bsc__summary svg {
  width: 14px;
  height: 14px;
  color: var(--ui-bsc-faint);
}
.ui-bsc__end {
  animation: ui-bsc-fade 260ms ease both;
}
.ui-bsc__fields {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 0 14px 14px;
}
.ui-bsc__field {
  display: grid;
  gap: 6px;
  min-width: 0;
}
.ui-bsc__label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bsc-text);
}
.ui-bsc__input,
.ui-bsc__select {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  width: 100%;
  height: 32px;
  padding: 0 8px 0 10px;
  border-radius: 8px;
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow);
  color: var(--ui-bsc-ink);
  text-align: left;
  transition: box-shadow 140ms ease;
}
.ui-bsc__select:hover,
.ui-bsc__input:hover {
  box-shadow: var(--ui-bsc-shadow-hover);
}
.ui-bsc__input input {
  flex: 1;
  min-width: 0;
  height: 100%;
  outline: none;
  font-variant-numeric: tabular-nums;
}
.ui-bsc__input input::-webkit-calendar-picker-indicator {
  position: absolute;
  inset: 0;
  width: auto;
  height: auto;
  opacity: 0;
  cursor: pointer;
}
.ui-bsc__input svg {
  color: var(--ui-bsc-icon);
  pointer-events: none;
}
.ui-bsc__input:focus-within {
  outline: none;
  box-shadow: var(--ui-bsc-shadow-hover);
}
.ui-bsc__select svg {
  color: var(--ui-bsc-icon);
  transition: transform 220ms var(--ui-bsc-ease);
}
.ui-bsc__select[aria-expanded="true"] svg {
  transform: rotate(180deg);
}
.ui-bsc__select--accent {
  background: var(--ui-bsc-pick);
  box-shadow: inset 0 0 0 0.5px var(--ui-bsc-pick-edge);
}
.ui-bsc__dd {
  position: relative;
}
.ui-bsc__menu {
  position: absolute;
  top: calc(100% + 6px);
  left: 0;
  right: 0;
  z-index: 5;
  display: grid;
  gap: 1px;
  min-width: 220px;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow-pop);
  animation: ui-bsc-menu 200ms var(--ui-bsc-ease) both;
  transform-origin: top;
}
.ui-bsc__menu {
  max-width: min(360px, calc(100vw - 32px));
  max-height: min(320px, 60vh);
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-bsc__menu button {
  overflow-wrap: anywhere;
}
.ui-bsc__menu-empty {
  margin: 0;
  padding: 6px 8px;
  color: var(--ui-bsc-muted);
}
.ui-bsc__menu[data-up] {
  top: auto;
  bottom: calc(100% + 6px);
  right: auto;
  transform-origin: bottom left;
}
.ui-bsc__menu button {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-height: 28px;
  padding: 4px 8px;
  border-radius: 6px;
  text-align: left;
  color: var(--ui-bsc-ink);
  transition: background-color 90ms ease-out;
}
.ui-bsc__menu button:hover {
  background: var(--ui-bsc-fill);
}
.ui-bsc__menu button svg {
  color: var(--ui-bsc-accent);
}
.ui-bsc__menu small {
  display: block;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bsc-muted);
}
.ui-bsc__table {
  border-top: 0.5px solid var(--ui-bsc-line);
}
.ui-bsc__row {
  display: grid;
  grid-template-columns: minmax(0, 1.15fr) minmax(0, 0.85fr) 216px;
  align-items: center;
  gap: 12px;
  min-height: 48px;
  padding: 6px 10px 6px 14px;
  border-bottom: 0.5px solid var(--ui-bsc-line);
  transition: background-color 120ms ease;
  animation: ui-bsc-row 320ms var(--ui-bsc-ease) both;
}
.ui-bsc__rows-outer .ui-bsc__row:hover {
  background: var(--ui-bsc-wash);
}
.ui-bsc__row--head {
  min-height: 32px;
  padding-top: 8px;
  padding-bottom: 8px;
  font-size: 10px;
  line-height: 16px;
  font-weight: 500;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-bsc-muted);
  animation: none;
}
.ui-bsc__right {
  text-align: right;
  padding-right: 36px;
}
.ui-bsc__rows-outer {
  overflow: hidden;
}
.ui-bsc__rows-outer[data-smooth] {
  transition: height 320ms var(--ui-bsc-ease);
}
.ui-bsc__empty {
  margin: 0;
  padding: 14px;
  border-bottom: 0.5px solid var(--ui-bsc-line);
  color: var(--ui-bsc-muted);
}
.ui-bsc__name {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-bsc-ink);
}
.ui-bsc__name-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-bsc__tag {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  flex: none;
  border-radius: 5px;
  background: var(--ui-bsc-fill);
  color: var(--ui-bsc-icon);
}
.ui-bsc__tag svg {
  width: 14px;
  height: 14px;
}
.ui-bsc__muted {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bsc-muted);
  white-space: nowrap;
}
.ui-bsc__repeat {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  color: var(--ui-bsc-icon);
}
.ui-bsc__repeat select {
  color: var(--ui-bsc-text);
}
.ui-bsc__repeat select,
.ui-bsc__timing {
  height: 24px;
  padding: 0 6px;
  border-radius: 6px;
  appearance: none;
  cursor: pointer;
  transition:
    background-color 120ms ease,
    color 120ms ease;
}
.ui-bsc__repeat select:hover,
.ui-bsc__timing:hover {
  background: var(--ui-bsc-fill);
  color: var(--ui-bsc-ink);
}
.ui-bsc__timing {
  height: 20px;
  margin: 0 30px 0 0;
  padding: 0 4px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bsc-muted);
  text-align: right;
}
.ui-bsc__price {
  display: grid;
  justify-items: end;
  min-width: 0;
}
.ui-bsc__price-main {
  display: flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
}
.ui-bsc__num {
  display: inline-flex;
  align-items: center;
  font-weight: 500;
  color: var(--ui-bsc-ink);
  font-variant-numeric: tabular-nums;
}
.ui-bsc__num input {
  height: 24px;
  padding: 0 1px;
  border-radius: 5px;
  outline: none;
  font-weight: 500;
  text-align: right;
  font-variant-numeric: tabular-nums;
  field-sizing: content;
  min-width: 2ch;
  transition:
    background-color 120ms ease,
    box-shadow 120ms ease;
}
.ui-bsc__num input:hover {
  background: var(--ui-bsc-fill);
}
.ui-bsc__num input:focus {
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow-hover);
}
.ui-bsc__remove {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-left: 2px;
  border-radius: 6px;
  color: var(--ui-bsc-icon);
  opacity: 0;
  transition:
    opacity 120ms ease,
    background-color 120ms ease,
    color 120ms ease;
}
.ui-bsc__row:hover .ui-bsc__remove,
.ui-bsc__remove:focus-visible {
  opacity: 1;
}
.ui-bsc__remove:hover {
  background: var(--ui-bsc-wash);
  color: var(--ui-bsc-ink);
}
.ui-bsc__actions {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px 12px;
}
.ui-bsc__spacer {
  flex: 1;
}
.ui-bsc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px 0 8px;
  border-radius: 6px;
  background: var(--ui-bsc-card);
  box-shadow: var(--ui-bsc-shadow);
  font-weight: 500;
  color: var(--ui-bsc-strong);
  white-space: nowrap;
  transition:
    box-shadow 140ms ease,
    opacity 200ms ease,
    transform 140ms ease;
}
.ui-bsc__btn:hover:not(:disabled) {
  box-shadow: var(--ui-bsc-shadow-hover);
}
.ui-bsc__btn:active:not(:disabled) {
  transform: scale(0.97);
}
.ui-bsc__btn:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-bsc__btn svg {
  color: var(--ui-bsc-icon);
}
.ui-bsc__select-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-bsc__totals {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px 16px;
  flex-wrap: wrap;
  padding: 10px 14px;
  border-top: 0.5px solid var(--ui-bsc-line);
}
.ui-bsc__total {
  display: inline-flex;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
  white-space: nowrap;
}
.ui-bsc__total-label {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bsc-muted);
}
.ui-bsc__total {
  flex-wrap: wrap;
  white-space: normal;
}
.ui-bsc__total-label {
  white-space: nowrap;
}
.ui-bsc__total b {
  white-space: nowrap;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-bsc-strong);
  font-variant-numeric: tabular-nums;
}
.ui-bsc__total em {
  align-self: center;
  padding: 2px 6px;
  border-radius: 5px;
  background: var(--ui-bsc-pick);
  font-size: 11px;
  line-height: 16px;
  font-style: normal;
  font-weight: 500;
  color: var(--ui-bsc-accent);
  animation: ui-bsc-fade 220ms ease both;
}
@keyframes ui-bsc-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-bsc-row {
  from {
    opacity: 0;
    transform: translateY(-4px);
  }
}
@keyframes ui-bsc-menu {
  from {
    opacity: 0;
    transform: scale(0.97) translateY(-4px);
  }
}
@container (max-width: 500px) {
  .ui-bsc__fields {
    grid-template-columns: 1fr;
  }
  .ui-bsc__summary {
    flex-wrap: wrap;
    row-gap: 0;
  }
  .ui-bsc__row {
    grid-template-columns: minmax(0, 1fr);
    gap: 2px;
    padding: 10px 8px 10px 14px;
  }
  .ui-bsc__row > :nth-child(2) {
    display: none;
  }
  .ui-bsc__row--head {
    display: none;
  }
  .ui-bsc__price {
    justify-items: stretch;
  }
  .ui-bsc__price-main {
    justify-content: flex-start;
  }
  .ui-bsc__num {
    margin-left: -2px;
  }
  .ui-bsc__timing {
    justify-self: start;
    margin: 0 0 0 -4px;
  }
  .ui-bsc__remove {
    opacity: 1;
    margin-left: auto;
  }
  .ui-bsc__actions {
    flex-wrap: wrap;
  }
  .ui-bsc__spacer {
    display: none;
  }
  .ui-bsc__totals {
    flex-direction: column;
    align-items: stretch;
  }
  .ui-bsc__total {
    justify-content: space-between;
  }
  .ui-bsc__total--phase .ui-bsc__total-label {
    margin-right: auto;
    order: -1;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-bsc__input,
  .ui-bsc__select {
    height: 40px;
  }
  .ui-bsc__btn {
    height: 36px;
    padding: 0 12px 0 10px;
  }
  .ui-bsc__menu button {
    min-height: 40px;
  }
  .ui-bsc__remove {
    width: 36px;
    height: 36px;
    opacity: 1;
  }
  .ui-bsc__repeat select {
    height: 32px;
  }
  .ui-bsc__num input {
    height: 32px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bsc__rows-outer[data-smooth] {
    transition: none;
  }
  .ui-bsc__row,
  .ui-bsc__menu,
  .ui-bsc__end,
  .ui-bsc__total em {
    animation: none;
  }
}
.ui-bsc input:not([type="checkbox"]):not([type="radio"]):focus-visible,
.ui-bsc textarea:focus-visible,
.ui-bsc [contenteditable]:focus-visible {
  outline: none;
}
:where(.dark, [data-theme="dark"]) .ui-bsc {
  --ui-bsc-card: #1c1c1e;
  --ui-bsc-ink: rgba(255, 255, 255, 0.9);
  --ui-bsc-strong: #ffffff;
  --ui-bsc-text: rgba(255, 255, 255, 0.62);
  --ui-bsc-muted: rgba(255, 255, 255, 0.46);
  --ui-bsc-faint: rgba(255, 255, 255, 0.3);
  --ui-bsc-icon: rgba(255, 255, 255, 0.5);
  --ui-bsc-line: rgba(255, 255, 255, 0.08);
  --ui-bsc-wash: rgba(255, 255, 255, 0.04);
  --ui-bsc-fill: rgba(255, 255, 255, 0.08);
  --ui-bsc-accent: #4d8dff;
  --ui-bsc-pick: rgba(77, 141, 255, 0.14);
  --ui-bsc-pick-edge: rgba(77, 141, 255, 0.5);
  --ui-bsc-focus: rgba(77, 141, 255, 0.8);
  --ui-bsc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-bsc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.18), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-bsc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 12px 28px -10px rgba(0, 0, 0, 0.6),
    0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-bsc__input input {
  color-scheme: dark;
}
:where(.dark, [data-theme="dark"]) .ui-bsc select option {
  background: #1c1c1e;
  color: rgba(255, 255, 255, 0.9);
}
`;function r(i){return e.jsx(s,{...i,clean:!0,styles:a})}export{r as B};
