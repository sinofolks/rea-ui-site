const n=`"use client";

import "./DelegateBoard.clean.css";
// Copyable component. Keep its sibling CSS file in the same folder.
// Generated from the maintained TSX sources; regenerate with npm run generate:standalone.
import {
  type ReactElement,
  type ReactNode,
  useEffect,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type PointerEvent,
  type RefCallback,
  memo,
} from "react";
interface DelegateAgent {
  id?: string;
  name?: string;
  model?: string;
  avatar?: ReactNode;
  current?: number;
  rate?: number;
  [field: string]: unknown;
}
interface DelegateTask {
  id?: string;
  title?: string;
  estimate?: number;
  tools?: ReactNode[];
  agentId?: string | null;
  [field: string]: unknown;
}
type DelegateMode = "auto" | "manual";
interface DelegateBoardProps {
  agents: DelegateAgent[];
  tasks: DelegateTask[];
  onAssign?: (taskId: string, agentId: string | null) => void;
  now?: number;
  mode?: DelegateMode;
  defaultMode?: DelegateMode;
  onModeChange?: (mode: DelegateMode) => void;
  suggestion?: {
    taskId: string;
    agentId: string;
  } | null;
  formatCost?: (amount: number) => string;
  title?: string;
  className?: string;
}
type EntityId = string | undefined;
interface DragState {
  id: EntityId;
  x: number;
  y: number;
  dx: number;
  dy: number;
  width: number;
  from: "pile" | "queue";
}
interface PointerStart {
  id: EntityId;
  x: number;
  y: number;
  element: HTMLButtonElement;
  from: "pile" | "queue";
}
interface TaskHandlers {
  down: (
    event: PointerEvent<HTMLButtonElement>,
    id: EntityId,
    from: "pile" | "queue",
  ) => void;
  move: (event: PointerEvent<HTMLButtonElement>) => void;
  up: (event: PointerEvent<HTMLButtonElement>) => void;
  cancel: () => void;
  key: (event: KeyboardEvent<HTMLButtonElement>, id: EntityId) => void;
}
type DelegateController = ReturnType<typeof useDelegateBoard>;
interface TaskCardProps {
  task: DelegateTask;
  prefix: string;
  dragging: boolean;
  picked: boolean;
  describedBy: string;
  track: RefCallback<HTMLLIElement>;
  handlers: TaskHandlers;
}
interface ViewProps extends DelegateBoardProps {
  variant: "default" | "clean";
}
interface AgentQueueProps {
  agent: DelegateAgent;
  index: number;
  prefix: string;
  board: DelegateController;
  formatCost: (amount: number) => string;
}
function DelegateBoard(props: DelegateBoardProps) {
  return <DelegateBoardView {...props} variant="clean" />;
}
function defaultFormatCost(amount: number) {
  if (amount > 0 && amount < 0.01) return "<$0.01";
  return \`$\${amount < 10 ? amount.toFixed(2) : amount < 100 ? amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : Math.round(amount).toLocaleString("en-US")}\`;
}
function formatHours(minutes: number) {
  const rounded = Math.round(minutes),
    hours = Math.floor(rounded / 60);
  return hours < 24
    ? \`\${hours}h \${String(rounded % 60).padStart(2, "0")}m\`
    : \`\${Math.floor(hours / 24)}d \${hours % 24}h\`;
}
function formatClock(timestamp: number) {
  const date = new Date(timestamp);
  return \`\${String(date.getHours()).padStart(2, "0")}:\${String(date.getMinutes()).padStart(2, "0")}\`;
}
function formatFinishTime(timestamp: number, now: number) {
  const date = new Date(timestamp),
    startOfDay = (date: Date) =>
      new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime(),
    days = Math.round((startOfDay(date) - startOfDay(new Date(now))) / 86400000);
  return days <= 0
    ? formatClock(timestamp)
    : days < 7
      ? \`\${date.toLocaleDateString("en-US", { weekday: "short" })} \${formatClock(timestamp)}\`
      : date.toLocaleDateString("en-US", { month: "short", day: "numeric" });
}
function useDelegateBoard(
  {
    agents,
    tasks,
    onAssign,
    now,
    mode,
    defaultMode = "manual",
    onModeChange,
    suggestion,
  }: DelegateBoardProps,
  prefix: string,
) {
  const id = useId(),
    rootRef = useRef<HTMLDivElement>(null);
  const [assignments, setAssignments] = useState<
    Record<string, string | null | undefined>
  >({});
  const [drag, setDrag] = useState<DragState | null>(null),
    [dropTarget, setDropTarget] = useState<string | null>(null),
    [pickedId, setPickedId] = useState<EntityId | null>(null),
    [pickedAgentIndex, setPickedAgentIndex] = useState(0),
    [announcement, setAnnouncement] = useState(""),
    [failedAvatars, setFailedAvatars] = useState<Record<string, boolean>>({}),
    [clock, setClock] = useState(() => Date.now());
  useEffect(() => {
    if (now !== undefined) return;
    const timer = window.setInterval(() => setClock(Date.now()), 30000);
    return () => window.clearInterval(timer);
  }, [now]);
  const currentTime = now ?? clock,
    [localMode, setLocalMode] = useState(defaultMode),
    currentMode = mode ?? localMode;
  function changeMode(next: DelegateMode) {
    setLocalMode(next);
    onModeChange?.(next);
  }
  const assignmentOrder = useRef<EntityId[]>([]);
  const assignedTasks = tasks.map((task) =>
    String(task.id) in assignments
      ? { ...task, agentId: assignments[String(task.id)] }
      : task,
  );
  const order = new Map(assignmentOrder.current.map((id, index) => [id, index]));
  const orderedTasks = [...assignedTasks].sort(
    (left, right) => (order.get(left.id) ?? -1) - (order.get(right.id) ?? -1),
  );
  const unassignedTasks = orderedTasks.filter((task) => !task.agentId);
  const queueFor = (agentId: EntityId) =>
    orderedTasks.filter((task) => task.agentId === agentId);
  const findAgent = (id: EntityId) => agents.find((agent) => agent.id === id);
  function finishTime(agent: DelegateAgent, additional?: (typeof assignedTasks)[number]) {
    const queue = queueFor(agent.id).filter((task) => task.id !== additional?.id);
    if (!queue.length && !additional) return null;
    const current = queue.length
      ? (finiteNumber(agent.current) ?? taskMinutes(queue[0]))
      : 0;
    const waiting = queue.slice(1).reduce((sum, task) => sum + taskMinutes(task), 0);
    return (
      currentTime +
      (current + waiting + (additional ? taskMinutes(additional) : 0)) * minute
    );
  }
  function queueMinutes(agent: DelegateAgent) {
    const queue = queueFor(agent.id);
    return queue.length
      ? (finiteNumber(agent.current) ?? taskMinutes(queue[0])) +
          queue.slice(1).reduce((sum, task) => sum + taskMinutes(task), 0)
      : 0;
  }
  function estimateCost(agent: DelegateAgent, minutes: number) {
    const rate = finiteNumber(agent.rate);
    return rate == null ? null : rate * minutes;
  }
  const totalCost = agents.reduce<number | null>((total, agent) => {
    const cost = estimateCost(agent, queueMinutes(agent));
    return cost == null ? total : (total ?? 0) + cost;
  }, null);
  function assignTask(taskId: EntityId, agentId: EntityId | null) {
    const task = assignedTasks.find((task) => task.id === taskId);
    if (!task || (task.agentId ?? null) === agentId) return;
    assignmentOrder.current = [
      ...assignmentOrder.current.filter((id) => id !== taskId),
      taskId,
    ];
    const name = agentId ? findAgent(agentId)?.name : null;
    setAnnouncement(
      name ? \`\${task.title} → \${name}\` : \`\${task.title} is unassigned again\`,
    );
    if (onAssign) onAssign(taskId!, agentId!);
    else
      setAssignments((previous) => ({
        ...previous,
        [String(taskId)]: agentId,
      }));
  }
  const firstUnassigned = unassignedTasks[0]?.id;
  useEffect(() => {
    if (currentMode !== "auto" || !firstUnassigned || drag) return;
    const timer = window.setTimeout(
      () => {
        const available = [...agents].sort(
          (left, right) =>
            (finishTime(left) ?? currentTime) - (finishTime(right) ?? currentTime),
        )[0];
        if (available) assignTask(firstUnassigned, available.id);
      },
      prefersReducedMotion() ? 0 : 900,
    );
    return () => window.clearTimeout(timer);
  }, [currentMode, firstUnassigned, drag]);
  const taskRefs = useRef(new Map<EntityId, HTMLLIElement>()),
    refCallbacks = useRef(new Map<EntityId, RefCallback<HTMLLIElement>>());
  function trackTask(id: EntityId) {
    let callback = refCallbacks.current.get(id);
    if (!callback) {
      callback = (element) => {
        if (element) taskRefs.current.set(id, element);
        else taskRefs.current.delete(id);
      };
      refCallbacks.current.set(id, callback);
    }
    return callback;
  }
  const previousRects = useRef(new Map<EntityId, DOMRect>()),
    dropOrigin = useRef<{
      id: EntityId;
      rect: DOMRect;
    } | null>(null);
  const layout = JSON.stringify(
      orderedTasks.map((task) => [task.id, task.agentId ?? null]),
    ),
    previousLayout = useRef(layout);
  // Capture old DOM bounds before React moves a task into another queue.
  if (rootRef.current && layout !== previousLayout.current)
    previousRects.current = new Map(
      [...taskRefs.current].map(([id, element]) => [id, element.getBoundingClientRect()]),
    );
  useLayoutEffect(() => {
    if (previousLayout.current === layout) return;
    previousLayout.current = layout;
    const origin = dropOrigin.current;
    dropOrigin.current = null;
    if (prefersReducedMotion()) return;
    const scale = elementScale(rootRef.current);
    for (const [id, element] of taskRefs.current) {
      const previous =
        origin && origin.id === id ? origin.rect : previousRects.current.get(id);
      if (!previous) continue;
      const current = element.getBoundingClientRect(),
        left = (previous.left - current.left) / scale,
        top = (previous.top - current.top) / scale;
      if (Math.abs(left) < 1 && Math.abs(top) < 1) continue;
      const resized =
        Math.abs(previous.width - current.width) > 8 ||
        Math.abs(previous.height - current.height) > 4;
      element.animate(
        [
          {
            transform: \`translate(\${left}px, \${top}px)\`,
            opacity: resized ? 0.4 : 1,
            zIndex: 3,
          },
          { transform: "none", opacity: 1, zIndex: 3 },
        ],
        { duration: 480, easing: moveEasing },
      );
    }
  }, [layout]);
  const pointerStart = useRef<PointerStart | null>(null);
  function targetAt(x: number, y: number) {
    const element = document.elementFromPoint(x, y),
      agent = element?.closest<HTMLElement>("[data-agent]");
    if (agent && rootRef.current?.contains(agent)) return agent.dataset.agent ?? null;
    const pile = element?.closest("[data-pile]");
    return pile && rootRef.current?.contains(pile) ? "pile" : null;
  }
  function pointerDown(
    event: PointerEvent<HTMLButtonElement>,
    id: EntityId,
    from: "pile" | "queue",
  ) {
    if (event.button !== 0) return;
    pointerStart.current = {
      id,
      x: event.clientX,
      y: event.clientY,
      element: event.currentTarget,
      from,
    };
    event.currentTarget.setPointerCapture(event.pointerId);
  }
  function pointerMove(event: PointerEvent<HTMLButtonElement>) {
    const start = pointerStart.current;
    if (!start) return;
    if (drag) setDrag({ ...drag, x: event.clientX, y: event.clientY });
    else {
      if (Math.hypot(event.clientX - start.x, event.clientY - start.y) < 4) return;
      const bounds = start.element.getBoundingClientRect();
      setDrag({
        id: start.id,
        x: event.clientX,
        y: event.clientY,
        dx: start.x - bounds.left,
        dy: start.y - bounds.top,
        width: Math.max(bounds.width, 200),
        from: start.from,
      });
      setPickedId(null);
    }
    setDropTarget(targetAt(event.clientX, event.clientY));
  }
  function pointerUp(event: PointerEvent<HTMLButtonElement>) {
    const start = pointerStart.current;
    pointerStart.current = null;
    if (!start || !drag) return;
    const target = targetAt(event.clientX, event.clientY),
      ghost = rootRef.current?.querySelector(\`.\${prefix}__ghost\`);
    if (ghost && target)
      dropOrigin.current = { id: drag.id, rect: ghost.getBoundingClientRect() };
    setDrag(null);
    setDropTarget(null);
    if (target === "pile") assignTask(drag.id, null);
    else if (target) assignTask(drag.id, target);
  }
  function handleTaskKeyDown(event: KeyboardEvent<HTMLButtonElement>, taskId: EntityId) {
    if (!agents.length) return;
    const number = Number(event.key);
    if (number >= 1 && number <= agents.length) {
      event.preventDefault();
      assignTask(taskId, agents[number - 1].id);
      setPickedId(null);
      return;
    }
    if (pickedId === taskId) {
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        setPickedAgentIndex(
          (index) =>
            (index + (event.key === "ArrowDown" ? 1 : -1) + agents.length) %
            agents.length,
        );
      } else if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        assignTask(taskId, agents[pickedAgentIndex].id);
        setPickedId(null);
      } else if (event.key === "Escape") {
        event.preventDefault();
        setPickedId(null);
      }
    } else if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      setPickedId(taskId);
      setPickedAgentIndex(0);
      setAnnouncement(
        \`Picked up \${assignedTasks.find((task) => task.id === taskId)?.title}. Choose an agent with the arrow keys, Enter to hand it over.\`,
      );
    }
  }
  const targetAgentId = drag
    ? dropTarget
    : pickedId
      ? agents[pickedAgentIndex]?.id
      : (suggestion?.agentId ?? null);
  const activeTask = assignedTasks.find(
    (task) => task.id === (drag?.id ?? pickedId ?? suggestion?.taskId),
  );
  const currentHandlers = useRef<TaskHandlers>({
    down: pointerDown,
    move: pointerMove,
    up: pointerUp,
    cancel: () => {},
    key: handleTaskKeyDown,
  });
  currentHandlers.current = {
    down: pointerDown,
    move: pointerMove,
    up: pointerUp,
    cancel: () => {
      pointerStart.current = null;
      setDrag(null);
      setDropTarget(null);
    },
    key: handleTaskKeyDown,
  };
  const handlers = useMemo<TaskHandlers>(
    () => ({
      down: (...args) => currentHandlers.current.down(...args),
      move: (event) => currentHandlers.current.move(event),
      up: (event) => currentHandlers.current.up(event),
      cancel: () => currentHandlers.current.cancel(),
      key: (...args) => currentHandlers.current.key(...args),
    }),
    [],
  );
  return {
    id,
    rootRef,
    drag,
    dropTarget,
    pickedId,
    announcement,
    failedAvatars,
    setFailedAvatars,
    currentTime,
    currentMode,
    changeMode,
    unassignedTasks,
    queueFor,
    finishTime,
    estimateCost,
    totalCost,
    trackTask,
    targetAgentId,
    activeTask,
    handlers,
    pointerDown,
    pointerMove,
    pointerUp,
    handleTaskKeyDown,
  };
}
function TaskTools({ task, prefix }: { task: DelegateTask; prefix: string }) {
  return task.tools?.length ? (
    <span className={\`\${prefix}__tools\`} aria-hidden="true">
      {task.tools.slice(0, 3).map((tool, index) => (
        <span className={\`\${prefix}__tool\`} key={index}>
          {tool}
        </span>
      ))}
    </span>
  ) : null;
}
function AgentQueue({ agent, index, prefix, board, formatCost }: AgentQueueProps) {
  const queue = board.queueFor(agent.id),
    finish = board.finishTime(agent),
    targeted = board.targetAgentId === agent.id;
  const preview =
    targeted && board.activeTask && board.activeTask.agentId !== agent.id
      ? board.finishTime(agent, board.activeTask)
      : null;
  const addedCost =
    preview && board.activeTask
      ? board.estimateCost(agent, taskMinutes(board.activeTask))
      : null;
  const avatarFailed = board.failedAvatars[String(agent.id)],
    rate = finiteNumber(agent.rate);
  return (
    <li
      className={\`\${prefix}__agent\`}
      data-agent={agent.id}
      data-target={targeted ? "" : undefined}
    >
      <span
        className={\`\${prefix}__avatar\`}
        data-logo={agent.avatar && !avatarFailed ? "" : undefined}
        onErrorCapture={() =>
          board.setFailedAvatars((previous) =>
            previous[String(agent.id)]
              ? previous
              : { ...previous, [String(agent.id)]: true },
          )
        }
      >
        {agent.avatar && !avatarFailed ? agent.avatar : initials(agent.name)}
      </span>
      <span className={\`\${prefix}__who\`}>
        <span className={\`\${prefix}__name-line\`}>
          <span className={\`\${prefix}__name\`} dir="auto" title={agent.name}>
            {agent.name}
          </span>
          <span className={\`\${prefix}__key\`} aria-hidden="true">
            {index + 1}
          </span>
        </span>
        <span className={\`\${prefix}__model\`}>
          <span className={\`\${prefix}__model-text\`} dir="auto" title={agent.model}>
            {agent.model}
          </span>
          {rate != null && (
            <span className={\`\${prefix}__rate\`}>{formatCost(rate)}/min</span>
          )}
        </span>
      </span>
      <span className={\`\${prefix}__load\`}>
        {addedCost != null && (
          <span className={\`\${prefix}__price\`} key="price">
            +{formatCost(addedCost)}
          </span>
        )}
        {preview ? (
          <span className={\`\${prefix}__tag\`} data-kind="preview" key="preview">
            +{formatShortMinutes(board.activeTask ? taskMinutes(board.activeTask) : 0)}{" "}
            until {formatFinishTime(preview, board.currentTime)}
          </span>
        ) : finish ? (
          <span className={\`\${prefix}__tag\`} data-kind="busy" key={finish}>
            Busy until {formatFinishTime(finish, board.currentTime)}
          </span>
        ) : (
          <span className={\`\${prefix}__tag\`} data-kind="free" key="free">
            Free
          </span>
        )}
      </span>
      <ul className={\`\${prefix}__queue\`} aria-label={\`\${agent.name}'s queue\`}>
        {queue.slice(0, 3).map((task, index) => (
          <li
            key={task.id}
            ref={board.trackTask(task.id)}
            className={\`\${prefix}__chip-slot\`}
          >
            <button
              type="button"
              className={\`\${prefix}__chip\`}
              data-chip-id={task.id}
              data-running={index === 0 ? "" : undefined}
              data-dragging={board.drag?.id === task.id ? "" : undefined}
              title={\`\${task.title} · ~\${formatMinutes(taskMinutes(task))}\`}
              onPointerDown={(event) => board.pointerDown(event, task.id, "queue")}
              onPointerMove={board.pointerMove}
              onPointerUp={board.pointerUp}
              onKeyDown={(event) => board.handleTaskKeyDown(event, task.id)}
            >
              {index === 0 ? (
                <SpinnerIcon prefix={prefix} />
              ) : (
                <TaskTools task={task} prefix={prefix} />
              )}
              <span className={\`\${prefix}__chip-title\`} dir="auto">
                {task.title}
              </span>
            </button>
          </li>
        ))}
        {queue.length > 3 && (
          <li className={\`\${prefix}__more\`}>
            <button
              type="button"
              className={\`\${prefix}__chip \${prefix}__chip--more\`}
              aria-describedby={\`\${board.id}-\${agent.id}-more\`}
            >
              +{numberFormatter.format(queue.length - 3)}
            </button>
            <span
              className={\`\${prefix}__tip\`}
              id={\`\${board.id}-\${agent.id}-more\`}
              role="tooltip"
            >
              <ul className={\`\${prefix}__tip-list\`}>
                {queue.slice(3, 11).map((task) => (
                  <li key={task.id}>
                    <TaskTools task={task} prefix={prefix} />
                    <span className={\`\${prefix}__tip-title\`} dir="auto">
                      {task.title}
                    </span>
                    <span className={\`\${prefix}__tip-min\`}>
                      ~{formatMinutes(taskMinutes(task))}
                    </span>
                  </li>
                ))}
                {queue.length > 11 && (
                  <li className={\`\${prefix}__tip-min\`}>
                    +{numberFormatter.format(queue.length - 11)} more
                  </li>
                )}
              </ul>
            </span>
          </li>
        )}
      </ul>
    </li>
  );
}
function DragGhost({ prefix, board }: { prefix: string; board: DelegateController }) {
  const { drag, activeTask, rootRef } = board;
  if (!drag || !activeTask) return null;
  const scale = elementScale(rootRef.current),
    bounds = rootRef.current?.getBoundingClientRect();
  const left = ((drag.x - drag.dx - (bounds?.left ?? 0)) / scale).toFixed(1),
    top = ((drag.y - drag.dy - (bounds?.top ?? 0)) / scale).toFixed(1);
  return (
    <div
      className={\`\${prefix}__ghost\`}
      style={{ left: \`\${left}px\`, top: \`\${top}px\`, width: drag.width / scale }}
      aria-hidden="true"
    >
      <span className={\`\${prefix}__grip\`}>
        <GripIcon />
      </span>
      <span className={\`\${prefix}__task-main\`}>
        <span className={\`\${prefix}__task-title\`} dir="auto">
          {activeTask.title}
        </span>
        <span className={\`\${prefix}__task-meta\`}>
          <TaskTools task={activeTask} prefix={prefix} />~
          {formatMinutes(taskMinutes(activeTask))}
        </span>
      </span>
    </div>
  );
}
function DelegateBoardView({ variant, ...props }: ViewProps) {
  const clean = variant === "clean",
    prefix = clean ? "ui-dbc" : "ui-db",
    board = useDelegateBoard(props, prefix);
  const {
    title = "Delegate",
    className,
    suggestion,
    agents,
    formatCost = defaultFormatCost,
  } = props;
  const header = (
    <header className={\`\${prefix}__bar\`}>
      <span className={\`\${prefix}__spark\`}>
        <AssistantIcon />
      </span>
      <span className={\`\${prefix}__title\`} dir="auto" title={title}>
        {title}
      </span>
      <span className={\`\${prefix}__hint\`}>
        {board.currentMode === "auto"
          ? "New tasks go to whoever is free first"
          : "Drag a task onto an agent"}
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={board.currentMode === "auto"}
        className={\`\${prefix}__auto\`}
        onClick={() => board.changeMode(board.currentMode === "auto" ? "manual" : "auto")}
      >
        <span className={\`\${prefix}__auto-label\`}>Auto</span>
        <span className={\`\${prefix}__switch\`} aria-hidden="true">
          <span />
        </span>
      </button>
    </header>
  );
  return (
    <div
      ref={board.rootRef}
      className={[prefix, className].filter(Boolean).join(" ")}
      data-dragging={board.drag ? "" : undefined}
    >
      {!clean && header}
      <div className={\`\${prefix}__card\`}>
        {clean && header}
        <div className={\`\${prefix}__body\`}>
          <section
            className={\`\${prefix}__pile\`}
            data-pile=""
            data-over={
              board.dropTarget === "pile" && board.drag?.from === "queue" ? "" : undefined
            }
            aria-labelledby={\`\${board.id}-pile\`}
          >
            <h4 className={\`\${prefix}__head\`} id={\`\${board.id}-pile\`}>
              Unassigned{" "}
              <span className={\`\${prefix}__count\`}>
                {numberFormatter.format(board.unassignedTasks.length)}
              </span>
            </h4>
            <ul
              className={\`\${prefix}__tasks\`}
              data-long={board.unassignedTasks.length > 12 ? "" : undefined}
            >
              {board.unassignedTasks.map((task) => (
                <TaskCard_TaskCard
                  key={task.id}
                  task={task}
                  prefix={prefix}
                  dragging={board.drag?.id === task.id}
                  picked={board.pickedId === task.id || suggestion?.taskId === task.id}
                  describedBy={\`\${board.id}-how\`}
                  track={board.trackTask(task.id)}
                  handlers={board.handlers}
                />
              ))}
              {board.unassignedTasks.length === 0 && (
                <li className={\`\${prefix}__empty\`}>Everything is handed out</li>
              )}
            </ul>
          </section>
          <section className={\`\${prefix}__agents\`} aria-labelledby={\`\${board.id}-agents\`}>
            <h4 className={\`\${prefix}__head\`} id={\`\${board.id}-agents\`}>
              Agents
              {board.totalCost != null && board.totalCost > 0 && (
                <span
                  className={\`\${prefix}__spend\`}
                  key={Math.round(board.totalCost * 100)}
                >
                  {formatCost(board.totalCost)} in queues
                </span>
              )}
            </h4>
            <ul className={\`\${prefix}__roster\`}>
              {agents.map((agent, index) => (
                <AgentQueue
                  key={agent.id}
                  agent={agent}
                  index={index}
                  prefix={prefix}
                  board={board}
                  formatCost={formatCost}
                />
              ))}
            </ul>
          </section>
        </div>
      </div>
      <DragGhost prefix={prefix} board={board} />
      <span className={\`\${prefix}__sr\`} id={\`\${board.id}-how\`}>
        Drag onto an agent, or press Enter, choose with the arrow keys and press Enter
        again. Number keys hand it over at once.
      </span>
      <span className={\`\${prefix}__sr\`} aria-live="polite">
        {board.announcement}
      </span>
    </div>
  );
}
const minute = 60000;
const numberFormatter = new Intl.NumberFormat("en-US");
const finiteNumber = (value: unknown) =>
  typeof value === "number" && Number.isFinite(value) ? value : undefined;
const taskMinutes = (task: DelegateTask) => Math.max(0, finiteNumber(task.estimate) ?? 0);
const formatMinutes = (minutes: number) =>
  minutes < 60 ? \`\${Math.round(minutes)} min\` : formatHours(minutes);
const formatShortMinutes = (minutes: number) =>
  minutes < 60 ? \`\${Math.round(minutes)}m\` : formatHours(minutes);
const prefersReducedMotion = () =>
  typeof window !== "undefined" &&
  window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const moveEasing = "cubic-bezier(0.32, 0.72, 0.24, 1)";
const initials = (name: string = "") =>
  name
    .trim()
    .split(/\\s+/)
    .map((word) => word.match(/[\\p{L}\\p{N}]/u)?.[0] ?? "")
    .join("")
    .slice(0, 2)
    .toUpperCase();
const elementScale = (element: HTMLElement | null) =>
  element && element.offsetWidth
    ? element.getBoundingClientRect().width / element.offsetWidth
    : 1;
const AssistantIcon = () => (
  <svg width={\`14\`} height={\`14\`} viewBox={\`0 0 14 14\`} aria-hidden={\`true\`}>
    <path
      d={\`M7 1.2c.4 2.9 1.9 4.4 4.8 4.8-2.9.4-4.4 1.9-4.8 4.8C6.6 7.9 5.1 6.4 2.2 6 5.1 5.6 6.6 4.1 7 1.2Z\`}
      fill={\`currentColor\`}
    />
    <circle cx={\`11.6\`} cy={\`11.4\`} r={\`1.1\`} fill={\`currentColor\`} opacity={\`0.55\`} />
  </svg>
);
const GripIcon = () => (
  <svg width={\`12\`} height={\`12\`} viewBox={\`0 0 12 12\`} aria-hidden={\`true\`}>
    {[3, 6, 9].map((row) =>
      [4.3, 7.7].map((column) => (
        <circle
          cx={column}
          cy={row}
          r={\`0.95\`}
          fill={\`currentColor\`}
          key={\`\${column}-\${row}\`}
        />
      )),
    )}
  </svg>
);
const SpinnerIcon = ({ prefix }: { prefix: string }) => (
  <svg
    width={\`12\`}
    height={\`12\`}
    viewBox={\`0 0 12 12\`}
    aria-hidden={\`true\`}
    className={\`\${prefix}__spin\`}
  >
    <circle
      cx={\`6\`}
      cy={\`6\`}
      r={\`4.6\`}
      fill={\`none\`}
      stroke={\`currentColor\`}
      strokeOpacity={\`0.25\`}
      strokeWidth={\`1.6\`}
    />
    <path
      d={\`M6 1.4a4.6 4.6 0 0 1 4.6 4.6\`}
      fill={\`none\`}
      stroke={\`currentColor\`}
      strokeWidth={\`1.6\`}
      strokeLinecap={\`round\`}
    />
  </svg>
);
const TaskCard_TaskCard = memo(function TaskCard({
  task,
  prefix,
  dragging,
  picked,
  describedBy,
  track,
  handlers,
}: TaskCardProps) {
  return (
    <li ref={track} className={\`\${prefix}__task-slot\`}>
      <button
        type="button"
        className={\`\${prefix}__task\`}
        data-task-id={task.id}
        data-dragging={dragging ? "" : undefined}
        data-picked={picked ? "" : undefined}
        aria-describedby={describedBy}
        onPointerDown={(event) => handlers.down(event, task.id, "pile")}
        onPointerMove={handlers.move}
        onPointerUp={handlers.up}
        onPointerCancel={handlers.cancel}
        onKeyDown={(event) => handlers.key(event, task.id)}
      >
        <span className={\`\${prefix}__grip\`}>
          <GripIcon />
        </span>
        <span className={\`\${prefix}__task-main\`}>
          <span className={\`\${prefix}__task-title\`} dir="auto" title={task.title}>
            {task.title}
          </span>
          <span className={\`\${prefix}__task-meta\`}>
            <TaskTools task={task} prefix={prefix} />~{formatMinutes(taskMinutes(task))}
          </span>
        </span>
      </button>
    </li>
  );
});
export { DelegateBoard };
export type { DelegateAgent };
export type { DelegateTask };
export type { DelegateMode };
export type { DelegateBoardProps };
`;export{n as default};
