import{j as r}from"./workbench-model-BwgilGut.js";import{S as n}from"./ScheduledRunsView-eGCx-Hna.js";const e=`.ui-srn {
  --ui-srn-card: #ffffff;
  --ui-srn-strong: #000000;
  --ui-srn-ink: rgba(0, 0, 0, 0.88);
  --ui-srn-text: rgba(0, 0, 0, 0.65);
  --ui-srn-muted: rgba(0, 0, 0, 0.65);
  --ui-srn-faint: rgba(0, 0, 0, 0.65);
  --ui-srn-line: rgba(0, 0, 0, 0.06);
  --ui-srn-lane: #f4f4f5;
  --ui-srn-well: rgba(0, 0, 0, 0.025);
  --ui-srn-edge: #e9e9ec;
  --ui-srn-accent: #0060e2;
  --ui-srn-focus: rgba(0, 96, 226, 0.7);
  --ui-srn-accent-bg: rgba(0, 96, 226, 0.08);
  --ui-srn-drop: rgba(0, 96, 226, 0.4);
  --ui-srn-hatch: rgba(0, 0, 0, 0.05);
  --ui-srn-meter: #c8c8ce;
  --ui-srn-track: rgba(0, 0, 0, 0.045);
  --ui-srn-now: #e5484d;
  --ui-srn-track-2: rgba(0, 0, 0, 0.05);
  --ui-srn-amber: #ac4f07;
  --ui-srn-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-srn-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-srn / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-srn-text);
  -webkit-font-smoothing: antialiased;
}
.ui-srn *,
.ui-srn *::before,
.ui-srn *::after {
  box-sizing: border-box;
}
.ui-srn ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-srn) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-srn button:focus-visible {
  outline: 2px solid var(--ui-srn-focus);
  outline-offset: 2px;
}
.ui-srn__bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 12px;
}
.ui-srn__heading {
  display: flex;
  align-items: baseline;
  gap: 8px;
  min-width: 0;
}
.ui-srn__title {
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-srn-strong);
  white-space: nowrap;
}
.ui-srn__note {
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-srn-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-srn__bar {
  flex-wrap: wrap;
}
.ui-srn__tools {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-left: auto;
}
.ui-srn__crew {
  display: flex;
  align-items: center;
  padding-left: 9px;
}
.ui-srn__agent {
  position: relative;
  display: inline-flex;
  align-items: center;
  height: 26px;
  margin-left: -9px;
  padding: 0 5px;
  border-radius: 7px;
  background: var(--ui-srn-card) !important;
  box-shadow: var(--ui-srn-shadow);
  transition:
    margin-left 380ms var(--ui-srn-ease),
    transform 160ms ease,
    opacity 200ms ease;
}
.ui-srn__crew[data-open] .ui-srn__agent {
  margin-left: 4px;
}
.ui-srn__crew[data-open] .ui-srn__agent:not([data-on]) {
  opacity: 0.6;
}
.ui-srn__agent:hover {
  transform: translateY(-1px);
}
.ui-srn__agent-logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-srn-ink);
}
.ui-srn__agent-logo > svg {
  width: 14px;
  height: 14px;
}
.ui-srn__agent-name {
  max-width: 0;
  overflow: hidden;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-srn-ink);
  white-space: nowrap;
  opacity: 0;
  transition:
    max-width 380ms var(--ui-srn-ease),
    margin 380ms var(--ui-srn-ease),
    opacity 240ms ease;
}
.ui-srn__agent[data-on] .ui-srn__agent-name {
  max-width: 120px;
  margin: 0 3px 0 6px;
  opacity: 1;
}
.ui-srn__total {
  font-size: 12px;
  color: var(--ui-srn-muted);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-srn__modes {
  display: flex;
  padding: 2px;
  border-radius: 8px;
  background: var(--ui-srn-track-2);
}
.ui-srn__modes > button {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 24px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 12.5px !important;
  font-weight: 500;
  color: var(--ui-srn-text) !important;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-srn__modes > button > svg {
  width: 12px;
  height: 12px;
}
.ui-srn__modes > button:focus-visible {
  outline-offset: -2px;
}
.ui-srn__modes > button[aria-checked="true"] {
  background: var(--ui-srn-card) !important;
  color: var(--ui-srn-strong) !important;
  box-shadow: var(--ui-srn-shadow);
}
.ui-srn__body {
  display: grid;
  grid-template-columns: 220px minmax(0, 1fr);
  gap: 12px;
  align-items: stretch;
}
.ui-srn__stack {
  position: relative;
  min-height: 240px;
  padding: 4px;
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-srn-lane);
}
.ui-srn__stack-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 30px;
  padding: 0 6px 0 8px;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-srn-muted);
}
.ui-srn__count {
  display: grid;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 6px;
  background: rgba(16, 16, 24, 0.06);
  font-size: 11px;
  color: var(--ui-srn-text);
  font-variant-numeric: tabular-nums;
}
.ui-srn__cards {
  display: grid;
}
.ui-srn__body > .ui-srn__stack {
  display: flex;
  flex-direction: column;
  height: 0;
  min-height: max(100%, 240px);
}
.ui-srn__stack > .ui-srn__cards {
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
}
.ui-srn__tile:focus-visible {
  outline: 2px solid var(--ui-srn-focus);
  outline-offset: 2px;
}
.ui-srn__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-srn__slot {
  height: 68px;
  transition: height 420ms var(--ui-srn-ease) 140ms;
}
.ui-srn__slot[data-gone] {
  height: 0;
  pointer-events: none;
}
.ui-srn__slot[data-gone] > .ui-srn__card {
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  transition:
    opacity 160ms ease,
    visibility 0s linear 160ms;
}
.ui-srn__card[data-flying] {
  visibility: hidden;
}
.ui-srn__card[data-movable] {
  cursor: grab;
  touch-action: none;
  user-select: none;
}
.ui-srn__card[data-held] {
  opacity: 0.35;
}
.ui-srn__tile {
  display: grid;
  align-content: center;
  gap: 3px;
  height: 64px;
  padding: 0 8px 0 6px;
  overflow: hidden;
  border-radius: 7px;
  background: var(--ui-srn-card);
  box-shadow: var(--ui-srn-shadow);
}
.ui-srn__tile-top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-srn__tile-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 11.5px;
  font-weight: 500;
  line-height: 15px;
  color: var(--ui-srn-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-srn__tile-part {
  flex: none;
  font-size: 10px;
  line-height: 15px;
  color: var(--ui-srn-muted);
  font-variant-numeric: tabular-nums;
}
.ui-srn__tile-meta {
  overflow: hidden;
  padding-left: 24px;
  font-size: 10.5px;
  line-height: 14px;
  color: var(--ui-srn-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-srn__tile-meta[data-nope] {
  color: var(--ui-srn-amber);
}
.ui-srn__card {
  height: 64px;
}
.ui-srn__tile-stats {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 16px;
  padding-left: 24px;
  font-size: 10.5px;
  line-height: 16px;
  color: var(--ui-srn-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-srn__stat {
  display: inline-flex;
  align-items: center;
  gap: 3px;
}
.ui-srn__stat > svg {
  flex: none;
  width: 12px;
  height: 12px;
}
.ui-srn__tag {
  margin-left: auto;
  padding: 0 5px;
  border-radius: 4px;
  background: var(--ui-srn-track-2);
  font-size: 10px;
  line-height: 15px;
  color: var(--ui-srn-text);
}
.ui-srn__tile[data-open] {
  box-shadow:
    0 0 0 1.5px var(--ui-srn-drop),
    var(--ui-srn-shadow);
}
.ui-srn__info {
  position: absolute;
  z-index: 7;
  display: grid;
  pointer-events: none;
  gap: 8px;
  padding: 12px;
  border-radius: 10px;
  background: var(--ui-srn-card);
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 14px 32px -10px rgba(16, 16, 24, 0.24),
    0 2px 6px rgba(16, 16, 24, 0.05);
  transform-origin: top left;
  animation: ui-srn-pop 180ms var(--ui-srn-ease) both;
}
.ui-srn__info-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-srn__info-title {
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-srn-strong);
  overflow-wrap: anywhere;
}
.ui-srn__info-text {
  margin: 0;
  font-size: 12px;
  line-height: 17px;
  color: var(--ui-srn-text);
}
.ui-srn__info-rows {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr);
  gap: 4px 12px;
  margin: 0;
  padding-top: 8px;
  border-top: 0.5px solid var(--ui-srn-line);
  font-size: 12px;
  line-height: 16px;
}
.ui-srn__info-rows dt {
  color: var(--ui-srn-muted);
}
.ui-srn__info-rows dd {
  margin: 0;
  color: var(--ui-srn-ink);
  font-variant-numeric: tabular-nums;
}
.ui-srn__info-hint {
  margin: 0;
  font-size: 11px;
  line-height: 15px;
  color: var(--ui-srn-faint);
}
@keyframes ui-srn-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
.ui-srn__tile {
  cursor: pointer;
  transition: opacity 240ms ease;
}
.ui-srn__tile[data-dim] {
  background: var(--ui-srn-well);
}
.ui-srn__tile .ui-srn__mark,
.ui-srn__info .ui-srn__mark {
  width: 18px;
  height: 18px;
  border-radius: 5px;
}
.ui-srn__tile .ui-srn__mark > svg,
.ui-srn__info .ui-srn__mark > svg {
  width: 12px;
  height: 12px;
}
.ui-srn__empty {
  position: absolute;
  inset: 34px 4px 4px;
  display: grid;
  place-items: center;
  margin: 0;
  font-size: 12px;
  color: var(--ui-srn-faint);
  opacity: 0;
  transition: opacity 300ms ease 300ms;
  pointer-events: none;
}
.ui-srn__empty[data-show] {
  opacity: 1;
}
.ui-srn__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  overflow: hidden;
  border-radius: 4px;
  background: var(--ui-srn-card);
  box-shadow: var(--ui-srn-shadow);
  font-size: 9px;
  font-weight: 500;
  color: var(--ui-srn-ink);
}
.ui-srn__mark > svg {
  width: 10px;
  height: 10px;
}
.ui-srn__flier {
  position: absolute;
  z-index: 5;
  pointer-events: none;
}
.ui-srn__scroll {
  min-width: 0;
  overflow-x: auto;
  user-select: none;
}
.ui-srn__week {
  display: grid;
  gap: 4px;
  min-width: calc(38px + var(--ui-srn-days) * 128px);
}
.ui-srn__row {
  display: grid;
  grid-template-columns: 34px repeat(var(--ui-srn-days), minmax(0, 1fr));
  gap: 4px;
}
.ui-srn__row--head {
  height: 30px;
  align-items: center;
}
.ui-srn__day {
  display: flex;
  align-items: baseline;
  gap: 4px;
  height: 26px;
  padding: 5px 8px 0;
  border-radius: 8px;
  background: var(--ui-srn-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-srn-line);
  font-size: 10px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-srn-muted);
}
.ui-srn__day b {
  font-size: 12px;
  font-weight: 500;
  letter-spacing: 0;
  color: var(--ui-srn-text);
  font-variant-numeric: tabular-nums;
}
.ui-srn__time {
  padding-top: 6px;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-srn-faint);
  font-variant-numeric: tabular-nums;
}
.ui-srn__cell {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  height: 156px;
  padding: 4px 4px 20px;
  border-radius: 10px;
  background: var(--ui-srn-well);
  box-shadow: inset 0 0 0 0.5px var(--ui-srn-line);
}
.ui-srn__cell[data-past] {
  background: transparent;
}
.ui-srn__cell[data-past] .ui-srn__tile-title {
  color: var(--ui-srn-muted);
}
.ui-srn__cell {
  transition:
    background-color 160ms ease,
    box-shadow 160ms ease,
    opacity 160ms ease;
}
.ui-srn__cell[data-blocked] {
  background: repeating-linear-gradient(
    135deg,
    var(--ui-srn-well) 0 6px,
    var(--ui-srn-hatch) 6px 7px
  );
}
.ui-srn__cell[data-blocked] > :not(.ui-srn__why) {
  opacity: 1;
}
.ui-srn__cell[data-over] {
  background: var(--ui-srn-accent-bg);
  box-shadow: inset 0 0 0 1px var(--ui-srn-drop);
}
.ui-srn__chips {
  position: relative;
  z-index: 1;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 3px;
}
.ui-srn__chip[data-landing] {
  visibility: hidden;
}
.ui-srn__chip[data-movable] {
  cursor: grab;
  touch-action: none;
  user-select: none;
}
.ui-srn__chip[data-held] {
  opacity: 0.35;
}
.ui-srn[data-dragging],
.ui-srn[data-dragging] * {
  cursor: grabbing !important;
}
.ui-srn__ghost {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 6;
  margin: 0;
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.08),
    0 12px 24px -8px rgba(16, 16, 24, 0.28);
  pointer-events: none;
  animation: none;
}
.ui-srn__chip[data-fresh] {
  animation: ui-srn-drop 460ms var(--ui-srn-ease) both;
}
.ui-srn__more {
  height: 64px;
  padding-left: 6px;
  font-size: 11px;
  line-height: 64px;
  color: var(--ui-srn-muted);
}
.ui-srn__now {
  position: absolute;
  top: -2px;
  right: 0;
  left: 0;
  z-index: 2;
  height: 1.5px;
  margin-top: -0.75px;
  background: var(--ui-srn-now);
  pointer-events: none;
}
.ui-srn__now::before {
  content: "";
  position: absolute;
  top: 50%;
  left: -4px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--ui-srn-now);
  transform: translateY(-50%);
}
.ui-srn__use {
  position: absolute;
  right: 8px;
  bottom: 9px;
  left: 8px;
  height: 4px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-srn-track);
}
.ui-srn__use > i {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ui-srn-meter);
  transition: width 520ms var(--ui-srn-ease);
}
.ui-srn__cell[data-past] .ui-srn__use > i {
  opacity: 0.5;
}
.ui-srn__why {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 3;
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--ui-srn-card);
  box-shadow: var(--ui-srn-shadow);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-srn-text);
  white-space: nowrap;
  transform: translate(-50%, -50%);
  pointer-events: none;
  animation: ui-srn-pop 140ms ease both;
}
@keyframes ui-srn-drop {
  from {
    opacity: 0;
    transform: translateY(-6px) scale(0.96);
  }
}
@container ui-srn (max-width: 640px) {
  .ui-srn__body > .ui-srn__stack {
    height: auto;
    min-height: 0;
  }
  .ui-srn__stack > .ui-srn__cards {
    max-height: 320px;
  }
  .ui-srn__body {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-srn__cards {
    grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
    column-gap: 4px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-srn *,
  .ui-srn *::before,
  .ui-srn *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-srn {
  --ui-srn-card: #1c1c1f;
  --ui-srn-strong: #ffffff;
  --ui-srn-ink: rgba(255, 255, 255, 0.9);
  --ui-srn-text: rgba(255, 255, 255, 0.62);
  --ui-srn-muted: rgba(255, 255, 255, 0.45);
  --ui-srn-faint: rgba(255, 255, 255, 0.28);
  --ui-srn-line: rgba(255, 255, 255, 0.08);
  --ui-srn-lane: #161618;
  --ui-srn-well: rgba(255, 255, 255, 0.03);
  --ui-srn-edge: #2c2c31;
  --ui-srn-accent: #5b9aff;
  --ui-srn-focus: rgba(77, 141, 255, 0.8);
  --ui-srn-accent-bg: rgba(91, 154, 255, 0.1);
  --ui-srn-drop: rgba(91, 154, 255, 0.5);
  --ui-srn-hatch: rgba(255, 255, 255, 0.06);
  --ui-srn-meter: #55555c;
  --ui-srn-track: rgba(255, 255, 255, 0.06);
  --ui-srn-now: #ff6369;
  --ui-srn-track-2: rgba(255, 255, 255, 0.07);
  --ui-srn-amber: #fbbf24;
  --ui-srn-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-srn__count {
  background: rgba(255, 255, 255, 0.08);
}
`;function s(i){return r.jsx(n,{...i,styles:e,clean:!0})}export{s as S};
