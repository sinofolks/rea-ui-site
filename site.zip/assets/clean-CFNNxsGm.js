import{r as i,j as t}from"./workbench-model-BwgilGut.js";function sa({label:c,hint:L,error:d,optional:Y=!1,counter:q=!1,minRows:l=3,maxRows:v=10,expandable:m=!1,expandedRows:_=16,expanded:B,onExpandedChange:w,onSubmitShortcut:k,className:A,inputClassName:G,id:J,value:u,defaultValue:H,onChange:y,onKeyDown:j,disabled:M,readOnly:S,maxLength:p,ref:g,"aria-describedby":Q,...e}){const E=i.useId(),T=J??`${E}-input`,O=`${E}-message`,W=`${E}-count`,h=i.useRef(null),[V,F]=i.useState(String(H??"")),x=u!=null?String(u):V,[Z,D]=i.useState(!1),o=m&&(B??Z),[K,$]=i.useState(!1),N=i.useRef(0);i.useEffect(()=>()=>window.clearTimeout(N.current),[]);const C=!!d||e["aria-invalid"]===!0||e["aria-invalid"]==="true",z=b(d)?d:b(L)?L:null,I=q&&typeof p=="number",P=c==null&&!e["aria-label"]&&!e["aria-labelledby"]&&typeof e.placeholder=="string"?e.placeholder:void 0,f=()=>{const a=h.current;if(!a)return;const r=getComputedStyle(a),n=parseFloat(r.lineHeight)||20,s=parseFloat(r.paddingTop)+parseFloat(r.paddingBottom),aa=(o?Math.max(_,l):l)*n+s,U=(o?Math.max(_,v):Math.max(v,l))*n+s,ta=a.style.height;a.style.height="auto";const X=a.scrollHeight,ea=Math.min(Math.max(X,aa),U);a.style.height=ta,a.offsetHeight,a.style.height=`${ea}px`,a.style.overflowY=X>U+1?"auto":"hidden"};i.useLayoutEffect(f,[x,o,l,v,_]),i.useEffect(()=>{const a=h.current;if(!a||typeof ResizeObserver>"u")return;let r=a.clientWidth;const n=new ResizeObserver(()=>{a.clientWidth!==r&&(r=a.clientWidth,f())}),s=window.matchMedia("(pointer: coarse)");return s.addEventListener("change",f),n.observe(a),()=>{n.disconnect(),s.removeEventListener("change",f)}}),i.useEffect(()=>{var n;const a=(n=h.current)==null?void 0:n.form;if(!a||u!==void 0)return;const r=()=>window.setTimeout(()=>{var s;return F(((s=h.current)==null?void 0:s.value)??"")});return a.addEventListener("reset",r),()=>a.removeEventListener("reset",r)},[u]);const R=()=>{const a=!o;$(!0),window.clearTimeout(N.current),N.current=window.setTimeout(()=>$(!1),320),B===void 0&&D(a),w==null||w(a)};return t.jsxs("div",{className:["ui-tac",A].filter(Boolean).join(" "),"data-invalid":C||void 0,"data-disabled":M||void 0,"data-readonly":S||void 0,"data-expandable":m||void 0,children:[t.jsx("style",{href:"ui-text-area-clean",precedence:"default",children:oa}),c!=null&&t.jsxs("div",{className:"ui-tac__head",children:[t.jsx("label",{className:"ui-tac__label",htmlFor:T,children:c}),Y&&t.jsx("span",{className:"ui-tac__optional",children:"Optional"})]}),t.jsxs("div",{className:"ui-tac__box",children:[t.jsx("textarea",{...e,ref:a=>{h.current=a,typeof g=="function"?g(a):g&&(g.current=a)},id:T,className:["ui-tac__input",G].filter(Boolean).join(" "),rows:l,value:u,defaultValue:H,disabled:M,readOnly:S,maxLength:p,dir:e.dir??"auto","aria-label":e["aria-label"]??P,"aria-invalid":C||void 0,"aria-describedby":[Q,z?O:null,I?W:null].filter(Boolean).join(" ")||void 0,"aria-keyshortcuts":k?"Meta+Enter Control+Enter":e["aria-keyshortcuts"],"data-gliding":K||void 0,onChange:a=>{u===void 0&&F(a.target.value),y==null||y(a)},onKeyDown:a=>{k&&a.key==="Enter"&&(a.metaKey||a.ctrlKey)&&!a.nativeEvent.isComposing&&(a.preventDefault(),k(a.currentTarget.value)),j==null||j(a)}}),m&&!M&&t.jsx("button",{type:"button",className:"ui-tac__expand","aria-label":o?"Less room":"More room","aria-pressed":o,"aria-controls":T,onClick:R,children:t.jsx("span",{className:"ui-tac__swap",children:o?t.jsx(ra,{}):t.jsx(ia,{})},o?"less":"more")})]}),(z||I)&&t.jsxs("div",{className:"ui-tac__foot",children:[t.jsx("p",{className:"ui-tac__message",id:O,dir:"auto","aria-live":b(d)?"polite":void 0,children:z},b(d)?"error":"hint"),I&&t.jsxs("span",{className:"ui-tac__count",id:W,"data-full":x.length===p||void 0,"data-over":x.length>p||void 0,children:[x.length.toLocaleString(),"/",p.toLocaleString()]})]})]})}const b=c=>c!=null&&typeof c!="boolean"&&c!=="";function ia(){return t.jsx("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t.jsx("path",{d:"M16.5 3h4.5v4.5M21 3l-6 6M7.5 21H3v-4.5M3 21l6-6"})})}function ra(){return t.jsx("svg",{viewBox:"0 0 24 24",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:t.jsx("path",{d:"M14.5 5v4.5H19M14.5 9.5 20 4M9.5 19v-4.5H5M9.5 14.5 4 20"})})}const oa=`
/* Colors and motion as variables – override them on .ui-tac (see Theming in the docs) */
.ui-tac {
  --ui-tac-title: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tac-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-tac-muted: var(--aui-muted, rgba(0, 0, 0, 0.65));
  --ui-tac-subtle: var(--aui-muted, rgba(0, 0, 0, 0.65));
  --ui-tac-faint: var(--aui-placeholder, rgba(0, 0, 0, 0.65));
  --ui-tac-icon: var(--aui-muted, rgba(0, 0, 0, 0.65));
  --ui-tac-surface: var(--aui-surface, #ffffff);
  --ui-tac-wash: rgba(0, 0, 0, 0.04);
  --ui-tac-readonly: rgba(0, 0, 0, 0.02);
  --ui-tac-shadow: 0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.08)), 0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-tac-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.13)), 0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tac-shadow-focus: 0 0 0 1px var(--aui-border-strong, rgba(0, 0, 0, 0.28)), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-tac-danger: var(--aui-danger, #c13338);
  --ui-tac-danger-edge: rgba(229, 72, 77, 0.55);
  --ui-tac-danger-edge-focus: rgba(229, 72, 77, 0.8);
  --ui-tac-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-tac-ease: cubic-bezier(0.22, 1, 0.36, 1);

  --fs: 13px;
  --lh: 20px;

  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  font-family: var(--aui-font, "Inter", "InterVariable", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif);
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-tac-ink);
  -webkit-font-smoothing: antialiased;
}
/* Touch screens: 16px text, so iOS doesn't zoom in on focus */
@media (pointer: coarse) {
  .ui-tac { --fs: 16px; --lh: 24px; }
}

.ui-tac__head { display: flex; align-items: baseline; gap: 6px; min-width: 0; }
.ui-tac__label { min-width: 0; font-weight: 500; color: var(--ui-tac-title); overflow-wrap: anywhere; cursor: default; }
.ui-tac__optional { flex: none; font-size: 12px; line-height: 16px; color: var(--ui-tac-subtle); }

/* The box: white, a hairline shadow as its edge; hover and focus only make that edge firmer */
.ui-tac__box {
  position: relative;
  display: flex;
  min-width: 0;
  border-radius: var(--aui-radius, 8px);
  background: var(--ui-tac-surface);
  box-shadow: var(--ui-tac-shadow);
  cursor: text;
  transition: box-shadow 140ms ease, background-color 140ms ease;
}
.ui-tac__box:hover { box-shadow: var(--ui-tac-shadow-hover); }
.ui-tac__box:focus-within { box-shadow: var(--ui-tac-shadow-focus); }
.ui-tac[data-invalid] .ui-tac__box { box-shadow: 0 0 0 1px var(--ui-tac-danger-edge), 0 1px 2px 0 rgba(0, 0, 0, 0.05); animation: ui-tac-nudge 320ms var(--ui-tac-ease); }
.ui-tac[data-invalid] .ui-tac__box:focus-within { box-shadow: 0 0 0 1px var(--ui-tac-danger-edge-focus), 0 1px 2px 0 rgba(0, 0, 0, 0.05); }
.ui-tac[data-readonly] .ui-tac__box { background: var(--ui-tac-readonly); box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.08); cursor: default; }
.ui-tac[data-disabled] .ui-tac__box { background: var(--ui-tac-readonly); box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.06); cursor: not-allowed; }
.ui-tac[data-disabled] { opacity: 0.55; }

.ui-tac__input {
  display: block;
  flex: 1;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  margin: 0;
  padding: 7px 10px;
  border: 0;
  border-radius: inherit;
  outline: 0;
  background: transparent;
  font: inherit;
  font-size: var(--fs);
  line-height: var(--lh);
  color: var(--ui-tac-ink);
  overflow-wrap: anywhere;
  resize: none;
  overflow-y: hidden;
  scrollbar-width: thin;
  -webkit-appearance: none;
  appearance: none;
}
/* The corner button keeps clear of the text */
.ui-tac[data-expandable] .ui-tac__input { padding-inline-end: 36px; }
.ui-tac__input::placeholder { color: var(--ui-tac-faint); opacity: 1; }
.ui-tac__input:disabled { cursor: not-allowed; }
.ui-tac__input[data-gliding] { transition: height 300ms var(--ui-tac-ease); }

/* More room: a small ghost button in the top corner */
.ui-tac__expand {
  position: absolute;
  top: 4px;
  inset-inline-end: 4px;
  display: grid;
  place-items: center;
  width: 26px;
  height: 26px;
  margin: 0;
  padding: 0;
  border: 0;
  border-radius: 5px;
  background: transparent;
  color: var(--ui-tac-icon);
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: background-color 140ms ease, color 140ms ease;
}
.ui-tac__expand:hover { background: var(--ui-tac-wash); color: var(--ui-tac-ink); }
.ui-tac__expand:focus-visible { outline: 2px solid var(--ui-tac-focus); outline-offset: -2px; }
.ui-tac__expand svg { display: block; }
.ui-tac__swap { display: grid; animation: ui-tac-swap 280ms var(--ui-tac-ease); }
@media (pointer: coarse) {
  .ui-tac__expand { width: 32px; height: 32px; }
  .ui-tac__expand::before { content: ""; position: absolute; inset: -4px; }
  .ui-tac[data-expandable] .ui-tac__input { padding-inline-end: 42px; }
}

/* Under the field: the hint, or the error in its place, and the count */
.ui-tac__foot { display: flex; align-items: flex-start; gap: 12px; min-width: 0; }
.ui-tac__message {
  flex: 1;
  min-width: 0;
  margin: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-tac-subtle);
  overflow-wrap: anywhere;
  animation: ui-tac-message 260ms var(--ui-tac-ease);
}
.ui-tac[data-invalid] .ui-tac__message { color: var(--ui-tac-danger); }
.ui-tac__count { flex: none; margin-left: auto; font-size: 12px; line-height: 16px; font-variant-numeric: tabular-nums; color: var(--ui-tac-faint); transition: color 140ms ease; }
.ui-tac__count[data-full] { color: var(--ui-tac-muted); }
.ui-tac__count[data-over] { color: var(--ui-tac-danger); }

@keyframes ui-tac-nudge {
  30% { transform: translateX(-3px); }
  65% { transform: translateX(2px); }
}
@keyframes ui-tac-message {
  from { opacity: 0; transform: translateY(-3px); filter: blur(2px); }
}
@keyframes ui-tac-swap {
  from { opacity: 0; transform: scale(0.6); filter: blur(2px); }
}

@media (prefers-reduced-motion: reduce) {
  .ui-tac *, .ui-tac[data-invalid] .ui-tac__box { animation-duration: 1ms !important; }
  .ui-tac__box, .ui-tac__input[data-gliding] { transition-duration: 1ms; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-tac {
  --ui-tac-title: var(--aui-ink, rgba(255, 255, 255, 0.92));
  --ui-tac-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-tac-muted: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-tac-subtle: var(--aui-muted, rgba(255, 255, 255, 0.46));
  --ui-tac-faint: var(--aui-placeholder, rgba(255, 255, 255, 0.3));
  --ui-tac-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-tac-surface: var(--aui-surface, #1c1c1e);
  --ui-tac-wash: rgba(255, 255, 255, 0.07);
  --ui-tac-readonly: rgba(255, 255, 255, 0.03);
  --ui-tac-shadow: 0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.14)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tac-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.2)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tac-shadow-focus: 0 0 0 1px var(--aui-border-strong, rgba(255, 255, 255, 0.3)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-tac-danger: var(--aui-danger, #ff6369);
  --ui-tac-danger-edge: rgba(255, 99, 105, 0.5);
  --ui-tac-danger-edge-focus: rgba(255, 99, 105, 0.75);
  --ui-tac-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
:where(.dark, [data-theme="dark"]) .ui-tac[data-readonly] .ui-tac__box,
:where(.dark, [data-theme="dark"]) .ui-tac[data-disabled] .ui-tac__box { box-shadow: 0 0 0 0.5px rgba(255, 255, 255, 0.12); }
`;export{sa as T};
