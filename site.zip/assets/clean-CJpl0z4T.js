import{j as i}from"./workbench-model-BwgilGut.js";import{P as e}from"./ParallelAttemptsView-DFmBinw2.js";const p=`
.ui-pac {
  --ui-pac-panel: #ffffff;
  --ui-pac-card: #ffffff;
  --ui-pac-strong: #000000;
  --ui-pac-ink: rgba(0, 0, 0, 0.88);
  --ui-pac-text: rgba(0, 0, 0, 0.65);
  --ui-pac-muted: rgba(0, 0, 0, 0.65);
  --ui-pac-faint: rgba(0, 0, 0, 0.65);
  --ui-pac-line: rgba(0, 0, 0, 0.06);
  --ui-pac-fill: rgba(0, 0, 0, 0.06);
  --ui-pac-track: rgba(0, 0, 0, 0.035);
  --ui-pac-accent: #0060e2;
  --ui-pac-focus: rgba(0, 96, 226, 0.7);
  --ui-pac-running-bg: rgba(0, 96, 226, 0.12);
  --ui-pac-running-edge: rgba(0, 96, 226, 0.34);
  --ui-pac-running-ink: #0058cf;
  --ui-pac-done-bg: rgba(0, 164, 51, 0.14);
  --ui-pac-done-edge: rgba(0, 140, 50, 0.32);
  --ui-pac-done-ink: #007a2d;
  --ui-pac-failed-bg: #f52b0020;
  --ui-pac-failed-edge: rgba(215, 36, 0, 0.36);
  --ui-pac-failed-ink: #cd2200;
  --ui-pac-best-bg: rgba(0, 164, 51, 0.24);
  --ui-pac-best-edge: rgba(0, 140, 50, 0.48);
  --ui-pac-shine: rgba(255, 255, 255, 0.85);
  --ui-pac-wash: rgba(0, 164, 51, 0.035);
  --ui-pac-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-pac-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-pac / inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-pac-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-pac *,
.ui-pac *::before,
.ui-pac *::after {
  box-sizing: border-box;
}
:where(.ui-pac) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-pac button:focus-visible {
  outline: 2px solid var(--ui-pac-focus);
  outline-offset: 2px;
}
.ui-pac svg {
  display: block;
  flex: none;
}
.ui-pac__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  margin-bottom: 16px;
}
.ui-pac__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-pac-accent);
}
.ui-pac__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-pac-strong);
}
.ui-pac__task {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-pac-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-pac__sum {
  display: flex;
  align-items: center;
  gap: 14px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-pac-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-pac__sum b {
  font-weight: 500;
  color: var(--ui-pac-ink);
}
.ui-pac__panel {
  display: grid;
  gap: 8px;
}
.ui-pac__row {
  position: relative;
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr) minmax(120px, 36%) minmax(
      96px,
      auto
    );
  align-items: center;
  column-gap: 14px;
  padding: 12px 16px 12px 12px;
  border-radius: 10px;
  background: var(--ui-pac-panel);
  box-shadow: var(--ui-pac-shadow);
  transition:
    opacity 320ms ease,
    background-color 500ms ease,
    box-shadow 300ms ease;
  animation: ui-pac-in 420ms var(--ui-pac-ease)
    calc(min(var(--i, 0), 12) * 70ms) backwards;
}
.ui-pac__row > .ui-pac__lane {
  margin-left: 6px;
}
.ui-pac__icon {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--ui-pac-card);
  box-shadow: var(--ui-pac-shadow);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-pac-text);
}
.ui-pac__icon > svg {
  width: 14px;
  height: 14px;
}
.ui-pac__row[data-picked] {
  background:
    linear-gradient(var(--ui-pac-wash), var(--ui-pac-wash)), var(--ui-pac-panel);
  box-shadow:
    var(--ui-pac-shadow),
    0 0 0 0.5px var(--ui-pac-done-edge);
}
.ui-pac__row[data-quiet] {
  opacity: 0.5;
}
.ui-pac__row[data-quiet]:hover,
.ui-pac__row[data-quiet]:focus-within {
  opacity: 1;
}
.ui-pac__who {
  display: grid;
  min-width: 0;
}
.ui-pac__name {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-pac-ink);
  white-space: nowrap;
}
.ui-pac__model {
  flex: 0 10 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 400;
  color: var(--ui-pac-muted);
}
.ui-pac__name-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-pac__approach {
  flex: 0 100 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 400;
  color: var(--ui-pac-muted);
  text-overflow: ellipsis;
}
.ui-pac__approach::before {
  content: "·";
  margin-right: 6px;
  color: var(--ui-pac-faint);
}
.ui-pac__line {
  overflow: hidden;
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-pac-text);
  white-space: nowrap;
  text-overflow: ellipsis;
  animation: ui-pac-fade 320ms ease both;
}
.ui-pac__row[data-status="running"] .ui-pac__line {
  color: var(--k-ink);
}
.ui-pac__row[data-status="failed"] .ui-pac__line {
  color: var(--ui-pac-failed-ink);
}
.ui-pac__lane {
  position: relative;
  height: 8px;
  border-radius: 4px;
  background: var(--ui-pac-track);
}
.ui-pac__fill {
  position: absolute;
  inset: 0 auto 0 0;
  width: calc(var(--p) * 100%);
  border-radius: 4px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 0.5px var(--k-edge);
  overflow: hidden;
  transition:
    width 600ms var(--ui-pac-ease),
    background-color 400ms ease,
    box-shadow 400ms ease;
}
.ui-pac__row[data-status="running"] .ui-pac__fill::before {
  content: "";
  position: absolute;
  inset: 0 auto 0 0;
  width: 60px;
  background: linear-gradient(
    90deg,
    transparent,
    var(--ui-pac-shine),
    transparent
  );
  opacity: 0.8;
  animation: ui-pac-sweep 1500ms linear infinite;
}
.ui-pac__row[data-status="running"] .ui-pac__fill::after {
  content: "";
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  width: 24px;
  background: linear-gradient(90deg, transparent, var(--k-edge));
  animation: ui-pac-glow 1100ms ease-in-out infinite alternate;
}
.ui-pac__row[data-best] .ui-pac__fill {
  background: var(--ui-pac-best-bg);
  box-shadow: inset 0 0 0 0.5px var(--ui-pac-best-edge);
}
.ui-pac__end {
  display: grid;
  justify-items: end;
  min-width: 0;
  text-align: right;
}
.ui-pac__score {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-pac-ink);
  font-variant-numeric: tabular-nums;
  animation: ui-pac-fade 320ms ease both;
}
.ui-pac__pct {
  font-weight: 400;
  color: var(--ui-pac-muted);
}
.ui-pac__failed {
  color: var(--ui-pac-failed-ink);
}
.ui-pac__best {
  height: 18px;
  padding: 0 6px;
  border-radius: 4px;
  background: var(--ui-pac-done-bg);
  font-size: 11px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-pac-done-ink);
  animation: ui-pac-pop 420ms var(--ui-pac-ease) both;
}
.ui-pac__meta-slot {
  position: relative;
  display: grid;
  justify-items: end;
  height: 18px;
}
.ui-pac__meta {
  font-size: 12px;
  line-height: 18px;
  color: var(--ui-pac-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
  transition: opacity 160ms ease;
}
.ui-pac__use {
  position: absolute;
  top: -3px;
  right: -6px;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  height: 24px;
  padding: 0 6px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-pac-text);
  white-space: nowrap;
  opacity: 0;
  transition:
    opacity 160ms ease,
    background-color 160ms ease,
    color 160ms ease;
}
.ui-pac__row:hover .ui-pac__meta[data-hide],
.ui-pac__row:focus-within .ui-pac__meta[data-hide],
.ui-pac__row[data-picked] .ui-pac__meta[data-hide] {
  opacity: 0;
}
.ui-pac__row:hover .ui-pac__use,
.ui-pac__use:focus-visible,
.ui-pac__use[data-on] {
  opacity: 1;
}
.ui-pac__use:hover {
  background: var(--ui-pac-fill);
  color: var(--ui-pac-ink);
}
.ui-pac__use[data-on] {
  color: var(--ui-pac-done-ink);
  cursor: default;
}
.ui-pac__use[data-on]:hover {
  background: none;
}
.ui-pac [data-status="running"] {
  --k-bg: var(--ui-pac-running-bg);
  --k-edge: var(--ui-pac-running-edge);
  --k-ink: var(--ui-pac-running-ink);
}
.ui-pac [data-status="done"] {
  --k-bg: var(--ui-pac-done-bg);
  --k-edge: var(--ui-pac-done-edge);
  --k-ink: var(--ui-pac-done-ink);
}
.ui-pac [data-status="failed"] {
  --k-bg: var(--ui-pac-failed-bg);
  --k-edge: var(--ui-pac-failed-edge);
  --k-ink: var(--ui-pac-failed-ink);
}
.ui-pac__row[data-best] {
  --k-bg: var(--ui-pac-best-bg);
  --k-edge: var(--ui-pac-best-edge);
}
@container ui-pac (max-width: 560px) {
  .ui-pac__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-pac__row {
    grid-template-columns: 28px minmax(0, 1fr) minmax(84px, auto);
    grid-template-areas: "icon who end" "lane lane lane";
    row-gap: 12px;
    column-gap: 12px;
    padding: 12px 14px 14px 12px;
  }
  .ui-pac__icon {
    grid-area: icon;
  }
  .ui-pac__who {
    grid-area: who;
  }
  .ui-pac__end {
    grid-area: end;
  }
  .ui-pac__row > .ui-pac__lane {
    grid-area: lane;
    margin-left: 0;
  }
  .ui-pac__approach {
    display: none;
  }
  .ui-pac__line {
    display: -webkit-box;
    min-height: 36px;
    white-space: normal;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
  }
}
@keyframes ui-pac-in {
  from {
    opacity: 0;
    transform: translateY(4px);
  }
}
@keyframes ui-pac-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-pac-pop {
  0% {
    opacity: 0;
    transform: scale(0.8);
  }
  60% {
    opacity: 1;
    transform: scale(1.06);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-pac-sweep {
  from {
    transform: translateX(-60px);
  }
  to {
    transform: translateX(900px);
  }
}
@keyframes ui-pac-glow {
  from {
    opacity: 0.45;
  }
  to {
    opacity: 1;
  }
}
@media (hover: none) {
  .ui-pac__use {
    opacity: 1;
  }
  .ui-pac__meta[data-hide] {
    opacity: 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-pac *,
  .ui-pac *::before,
  .ui-pac *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-pac {
  --ui-pac-panel: #1c1c1f;
  --ui-pac-card: #232326;
  --ui-pac-strong: #ffffff;
  --ui-pac-ink: rgba(255, 255, 255, 0.9);
  --ui-pac-text: rgba(255, 255, 255, 0.62);
  --ui-pac-muted: rgba(255, 255, 255, 0.45);
  --ui-pac-faint: rgba(255, 255, 255, 0.28);
  --ui-pac-line: rgba(255, 255, 255, 0.08);
  --ui-pac-fill: rgba(255, 255, 255, 0.08);
  --ui-pac-track: rgba(255, 255, 255, 0.05);
  --ui-pac-accent: #5b9aff;
  --ui-pac-focus: rgba(77, 141, 255, 0.8);
  --ui-pac-running-bg: rgba(60, 130, 255, 0.24);
  --ui-pac-running-edge: rgba(112, 170, 255, 0.5);
  --ui-pac-running-ink: #8ab8ff;
  --ui-pac-done-bg: rgba(40, 200, 110, 0.2);
  --ui-pac-done-edge: rgba(60, 220, 130, 0.4);
  --ui-pac-done-ink: #3dd68c;
  --ui-pac-failed-bg: rgba(255, 70, 50, 0.22);
  --ui-pac-failed-edge: rgba(255, 110, 90, 0.48);
  --ui-pac-failed-ink: #ff977d;
  --ui-pac-best-bg: rgba(40, 200, 110, 0.32);
  --ui-pac-best-edge: rgba(60, 220, 130, 0.6);
  --ui-pac-shine: rgba(255, 255, 255, 0.3);
  --ui-pac-wash: rgba(40, 200, 110, 0.06);
  --ui-pac-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;function n(a){return i.jsx(e,{...a,styles:p,clean:!0})}export{n as P};
