import{j as a}from"./workbench-model-BwgilGut.js";import{D as t}from"./DelegateBoardView-pszavNym.js";const e=`
.ui-dbc {
  --ui-dbc-card: #ffffff;
  --ui-dbc-strong: #000000;
  --ui-dbc-ink: rgba(0, 0, 0, 0.88);
  --ui-dbc-text: rgba(0, 0, 0, 0.65);
  --ui-dbc-muted: rgba(0, 0, 0, 0.65);
  --ui-dbc-faint: rgba(0, 0, 0, 0.65);
  --ui-dbc-line: rgba(0, 0, 0, 0.06);
  --ui-dbc-wash: rgba(0, 0, 0, 0.03);
  --ui-dbc-lane: rgba(0, 0, 0, 0.035);
  --ui-dbc-switch-off: rgba(0, 0, 0, 0.12);
  --ui-dbc-fill: rgba(0, 0, 0, 0.06);
  --ui-dbc-accent: #0060e2;
  --ui-dbc-brand-bg: #008ff519;
  --ui-dbc-brand-fg: #006ac6;
  --ui-dbc-warn-bg: #ff9c0029;
  --ui-dbc-warn-fg: #cc4e00;
  --ui-dbc-ok-bg: #00a43319;
  --ui-dbc-ok-fg: #00713f;
  --ui-dbc-focus: rgba(0, 96, 226, 0.7);
  --ui-dbc-target-bg: rgba(0, 120, 245, 0.045);
  --ui-dbc-target-edge: rgba(0, 96, 226, 0.3);
  --ui-dbc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-dbc-lift:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 16px 32px -12px rgba(0, 0, 0, 0.25),
    0 2px 6px rgba(0, 0, 0, 0.06);
  --ui-dbc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 720px;
  container-type: inline-size;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-dbc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-dbc[data-dragging] {
  cursor: grabbing;
  user-select: none;
  -webkit-user-select: none;
}
.ui-dbc *,
.ui-dbc *::before,
.ui-dbc *::after {
  box-sizing: border-box;
}
:where(.ui-dbc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-dbc button:focus-visible {
  outline: 2px solid var(--ui-dbc-focus);
  outline-offset: 2px;
}
.ui-dbc ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-dbc h4 {
  margin: 0;
}
.ui-dbc svg {
  display: block;
  flex: none;
}
.ui-dbc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-dbc__card {
  border-radius: 10px;
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
}
.ui-dbc__bar {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  padding: 12px 12px 12px 16px;
  border-bottom: 0.5px solid var(--ui-dbc-line);
}
.ui-dbc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-dbc-accent);
}
.ui-dbc__title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-dbc-strong);
  white-space: nowrap;
}
.ui-dbc__hint {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dbc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dbc__auto {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 8px;
  height: 28px;
  padding: 0 2px 0 6px;
  border-radius: 6px;
}
.ui-dbc__auto-label {
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-dbc-strong);
  transition: opacity 200ms ease;
}
.ui-dbc__auto[aria-checked="false"] .ui-dbc__auto-label {
  color: var(--ui-dbc-muted);
}
.ui-dbc__switch {
  position: relative;
  width: 28px;
  height: 16px;
  border-radius: 999px;
  background: var(--ui-dbc-switch-off);
  transition: background-color 220ms ease;
}
.ui-dbc__switch > span {
  position: absolute;
  top: 2px;
  left: 2px;
  width: 12px;
  height: 12px;
  border-radius: 50%;
  background: #fff;
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.18),
    0 0 0 0.5px rgba(0, 0, 0, 0.04);
  transition: transform 240ms var(--ui-dbc-ease);
}
.ui-dbc__auto[aria-checked="true"] .ui-dbc__switch {
  background: var(--ui-dbc-accent);
}
.ui-dbc__auto[aria-checked="true"] .ui-dbc__switch > span {
  transform: translateX(12px);
}
.ui-dbc__body {
  display: grid;
  grid-template-columns: 236px minmax(0, 1fr);
}
.ui-dbc__head {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 4px 8px !important;
  font-size: 12px;
  font-weight: 400;
  line-height: 16px;
  color: var(--ui-dbc-muted);
}
.ui-dbc__count {
  display: grid;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-dbc-text);
  font-variant-numeric: tabular-nums;
}
.ui-dbc__pile {
  margin: 12px 0 12px 12px;
  padding: 10px 6px 6px;
  border-radius: 10px;
  background: var(--ui-dbc-lane);
  transition:
    background-color 200ms ease,
    box-shadow 200ms ease;
}
.ui-dbc__pile .ui-dbc__head {
  margin-left: 6px !important;
}
.ui-dbc__pile[data-over] {
  box-shadow: inset 0 0 0 1px var(--ui-dbc-line);
}
.ui-dbc__tasks {
  display: grid;
  gap: 4px;
}
.ui-dbc__tasks[data-long] {
  max-height: 560px;
  margin: -2px;
  padding: 2px;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.ui-dbc__task,
.ui-dbc__ghost {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  width: 100%;
  padding: 8px 10px 8px 6px;
  border-radius: 8px;
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
  cursor: grab;
  touch-action: none;
  transition:
    opacity 160ms ease,
    box-shadow 160ms ease;
}
.ui-dbc__task:hover {
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 2px 6px -2px rgba(0, 0, 0, 0.12);
}
.ui-dbc__task[data-dragging],
.ui-dbc__chip[data-dragging] {
  opacity: 0.35;
}
.ui-dbc__task[data-picked] {
  background: var(--ui-dbc-target-bg);
  box-shadow:
    inset 0 0 0 0.5px var(--ui-dbc-target-edge),
    var(--ui-dbc-shadow);
}
.ui-dbc__grip {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 20px;
  color: var(--ui-dbc-faint);
}
.ui-dbc__task-main {
  display: grid;
  gap: 2px;
  min-width: 0;
}
.ui-dbc__task-title {
  overflow: hidden;
  text-align: start;
  font-weight: 500;
  color: var(--ui-dbc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dbc__task-meta {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dbc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-dbc__tools {
  display: flex;
  gap: 4px;
}
.ui-dbc__tool,
.ui-dbc__tool > svg,
.ui-dbc__tool > img {
  display: grid;
  width: 12px;
  height: 12px;
}
.ui-dbc__tool {
  flex: none;
  overflow: hidden;
}
.ui-dbc__tool > img {
  object-fit: contain;
}
.ui-dbc__empty {
  display: grid;
  place-items: center;
  min-height: 52px;
  padding: 8px 10px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dbc-muted);
  text-align: center;
}
.ui-dbc__ghost {
  position: absolute;
  z-index: 1000;
  box-shadow: var(--ui-dbc-lift);
  cursor: grabbing;
  pointer-events: none;
  transform: rotate(1.5deg) scale(1.02);
}
.ui-dbc__agents {
  padding: 14px 12px 12px;
}
.ui-dbc__roster {
  display: grid;
  gap: 4px;
}
.ui-dbc__agent {
  display: grid;
  grid-template-columns: 28px minmax(0, 1fr) auto;
  grid-template-areas: "avatar who load" "avatar queue queue";
  column-gap: 10px;
  row-gap: 6px;
  padding: 8px 8px 8px 8px;
  border-radius: 8px;
  transition:
    background-color 180ms ease,
    box-shadow 180ms ease;
}
.ui-dbc[data-dragging] .ui-dbc__agent {
  box-shadow: inset 0 0 0 0.5px var(--ui-dbc-line);
}
.ui-dbc__agent[data-target] {
  background: var(--ui-dbc-target-bg);
}
.ui-dbc__avatar {
  grid-area: avatar;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 7px;
  background: var(--ui-dbc-fill);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-dbc-text);
}
.ui-dbc__avatar[data-logo] {
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
}
.ui-dbc__avatar > svg,
.ui-dbc__avatar > img {
  width: 15px;
  height: 15px;
}
.ui-dbc__avatar {
  flex: none;
  overflow: hidden;
}
.ui-dbc__avatar > img {
  object-fit: contain;
}
.ui-dbc__who {
  grid-area: who;
  display: grid;
  min-width: 0;
}
.ui-dbc__name-line {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-dbc__name {
  overflow: hidden;
  text-align: start;
  font-weight: 500;
  color: var(--ui-dbc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dbc__key {
  display: none;
  place-items: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 4px;
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-dbc-muted);
}
.ui-dbc:focus-within .ui-dbc__key {
  display: grid;
}
.ui-dbc__model {
  display: flex;
  min-width: 0;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dbc-muted);
  white-space: nowrap;
}
.ui-dbc__model-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-dbc__load {
  grid-area: load;
  align-self: start;
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-dbc__spend {
  margin-left: auto;
  font-variant-numeric: tabular-nums;
  animation: ui-dbc-in 260ms var(--ui-dbc-ease) both;
}
.ui-dbc__rate {
  flex: none;
  margin-left: 6px;
  color: var(--ui-dbc-faint);
  font-variant-numeric: tabular-nums;
}
.ui-dbc__price {
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-dbc-brand-fg);
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-dbc-in 260ms var(--ui-dbc-ease) both;
}
.ui-dbc__tag {
  display: inline-flex;
  align-items: center;
  height: 20px;
  padding: 0 7px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-dbc-in 260ms var(--ui-dbc-ease) both;
}
.ui-dbc__tag[data-kind="free"] {
  background: var(--ui-dbc-ok-bg);
  color: var(--ui-dbc-ok-fg);
}
.ui-dbc__tag[data-kind="busy"] {
  background: var(--ui-dbc-fill);
  color: var(--ui-dbc-text);
}
.ui-dbc__tag[data-kind="preview"] {
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
  color: var(--ui-dbc-brand-fg);
}
.ui-dbc__queue {
  grid-area: queue;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  min-width: 0;
}
.ui-dbc__queue:empty {
  display: none;
}
.ui-dbc__chip-slot {
  min-width: 0;
  max-width: 100%;
}
.ui-dbc__chip {
  display: flex;
  align-items: center;
  gap: 5px;
  max-width: 100%;
  height: 24px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  background: var(--ui-dbc-card);
  box-shadow: var(--ui-dbc-shadow);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-dbc-text);
  cursor: grab;
  touch-action: none;
}
.ui-dbc__chip[data-running] {
  background: var(--ui-dbc-brand-bg);
  box-shadow: none;
  color: var(--ui-dbc-brand-fg);
  font-weight: 500;
}
.ui-dbc__chip-title {
  text-align: start;
  min-width: 0;
  max-width: 150px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-dbc__more {
  position: relative;
}
.ui-dbc__chip--more {
  padding: 0 8px;
  font-weight: 500;
  color: var(--ui-dbc-text);
  cursor: default;
}
.ui-dbc__tip {
  position: absolute;
  bottom: calc(100% + 6px);
  left: 50%;
  z-index: 10;
  display: grid;
  width: max-content;
  max-width: min(320px, 90cqw);
  padding: 8px 10px;
  border-radius: 8px;
  background: rgba(24, 24, 27, 0.92);
  -webkit-backdrop-filter: blur(8px);
  backdrop-filter: blur(8px);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.35);
  font-size: 12px;
  line-height: 16px;
  color: rgba(255, 255, 255, 0.86);
  text-align: left;
  opacity: 0;
  visibility: hidden;
  transform: translate(-50%, 3px);
  transition:
    opacity 160ms ease,
    transform 160ms ease,
    visibility 0s linear 160ms;
  pointer-events: none;
}
.ui-dbc__more:hover .ui-dbc__tip,
.ui-dbc__more:focus-within .ui-dbc__tip {
  opacity: 1;
  visibility: visible;
  transform: translate(-50%, 0);
  transition:
    opacity 160ms ease,
    transform 160ms ease,
    visibility 0s;
}
.ui-dbc__tip-list {
  display: grid;
  gap: 2px;
}
.ui-dbc__tip-list li {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-dbc__tip-title {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: start;
}
.ui-dbc__tip-min {
  flex: none;
}
.ui-dbc__tip {
  --ui-dbc-strong: #fff;
  --ui-db-ink: #fff;
}
.ui-dbc__tip-min {
  color: rgba(255, 255, 255, 0.5);
}
.ui-dbc__spin {
  animation: ui-dbc-spin 900ms linear infinite;
}
@keyframes ui-dbc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-dbc-in {
  from {
    opacity: 0;
    transform: translateY(2px);
  }
}
@container (max-width: 560px) {
  .ui-dbc__body {
    grid-template-columns: minmax(0, 1fr);
  }
  .ui-dbc__queue {
    position: relative;
  }
  .ui-dbc__more {
    position: static;
  }
  .ui-dbc__tip {
    left: 0;
    max-width: 100%;
    transform: translate(0, 3px);
  }
  .ui-dbc__more:hover .ui-dbc__tip,
  .ui-dbc__more:focus-within .ui-dbc__tip {
    transform: none;
  }
  .ui-dbc__pile {
    margin: 12px 12px 0;
  }
  .ui-dbc__hint {
    display: none;
  }
}
@media (pointer: coarse) {
  .ui-dbc__auto {
    height: 34px;
  }
  .ui-dbc__chip {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-dbc *,
  .ui-dbc *::before,
  .ui-dbc *::after {
    animation: none !important;
    transition: none !important;
  }
  .ui-dbc__ghost {
    transform: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-dbc {
  --ui-dbc-card: #1c1c1f;
  --ui-dbc-strong: #ffffff;
  --ui-dbc-ink: rgba(255, 255, 255, 0.9);
  --ui-dbc-text: rgba(255, 255, 255, 0.62);
  --ui-dbc-muted: rgba(255, 255, 255, 0.45);
  --ui-dbc-faint: rgba(255, 255, 255, 0.28);
  --ui-dbc-line: rgba(255, 255, 255, 0.08);
  --ui-dbc-wash: rgba(255, 255, 255, 0.04);
  --ui-dbc-lane: rgba(255, 255, 255, 0.035);
  --ui-dbc-switch-off: rgba(255, 255, 255, 0.16);
  --ui-dbc-fill: rgba(255, 255, 255, 0.08);
  --ui-dbc-accent: #5b9aff;
  --ui-dbc-brand-bg: #0077ff3a;
  --ui-dbc-brand-fg: #70b8ff;
  --ui-dbc-warn-bg: #fb6a0025;
  --ui-dbc-warn-fg: #ffa057;
  --ui-dbc-ok-bg: #22ff991e;
  --ui-dbc-ok-fg: #46fea5d4;
  --ui-dbc-focus: rgba(77, 141, 255, 0.8);
  --ui-dbc-target-bg: rgba(91, 154, 255, 0.08);
  --ui-dbc-target-edge: rgba(112, 184, 255, 0.35);
  --ui-dbc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-dbc-lift:
    0 0 0 0.5px rgba(255, 255, 255, 0.14), 0 16px 32px -12px rgba(0, 0, 0, 0.7);
}
:where(.dark, [data-theme="dark"]) .ui-dbc__tip {
  background: rgba(250, 250, 250, 0.94);
  box-shadow: 0 8px 24px -8px rgba(0, 0, 0, 0.6);
  color: rgba(0, 0, 0, 0.82);
}
:where(.dark, [data-theme="dark"]) .ui-dbc__tip {
  --ui-dbc-strong: rgba(0, 0, 0, 0.88);
  --ui-db-ink: rgba(0, 0, 0, 0.88);
}
:where(.dark, [data-theme="dark"]) .ui-dbc__tip-min {
  color: rgba(0, 0, 0, 0.5);
}
`;function o(i){return a.jsx(t,{...i,variant:"clean",styles:e})}export{o as D};
