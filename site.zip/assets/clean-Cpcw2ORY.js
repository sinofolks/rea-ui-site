import{j as t}from"./workbench-model-BwgilGut.js";import{I as e}from"./IntegrationPickerView-BXezvPpm.js";function o(r){return t.jsx(e,{...r,clean:!0})}export{o as I};
