import{j as o}from"./workbench-model-BwgilGut.js";import{A as p}from"./ApprovalView-Dai2dPnt.js";function e(r){return o.jsx(p,{...r,clean:!0})}export{e as A};
