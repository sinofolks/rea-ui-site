import{j as o}from"./workbench-model-BwgilGut.js";import{T as t}from"./clean-db0TW5TD.js";import{w as r}from"./preview-CHHlf7B_.js";const m=r(t);function a(){return o.jsx(m,{})}export{a as default};
