import{j as c}from"./workbench-model-BwgilGut.js";import{B as e}from"./BreakdownView-CEYs2sRO.js";const t=`
.ui-bcc {
  --ui-bcc-card: #ffffff;
  --ui-bcc-ink: rgba(0, 0, 0, 0.88);
  --ui-bcc-strong: #000000;
  --ui-bcc-text: rgba(0, 0, 0, 0.65);
  --ui-bcc-muted: rgba(0, 0, 0, 0.65);
  --ui-bcc-faint: rgba(0, 0, 0, 0.27);
  --ui-bcc-icon: rgba(0, 0, 0, 0.65);
  --ui-bcc-line: rgba(0, 0, 0, 0.06);
  --ui-bcc-grid: rgba(0, 0, 0, 0.06);
  --ui-bcc-zero: rgba(0, 0, 0, 0.12);
  --ui-bcc-fill: rgba(0, 0, 0, 0.06);
  --ui-bcc-wash: rgba(0, 0, 0, 0.03);
  --ui-bcc-rest: rgba(0, 0, 0, 0.035);
  --ui-bcc-accent: #0060e2;
  --ui-bcc-focus: rgba(0, 96, 226, 0.7);
  --ui-bcc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bcc-shadow-hover:
    0 0 0 0.5px rgba(0, 0, 0, 0.12), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bcc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-bcc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 560px;
  border-radius: 10px;
  background: var(--ui-bcc-card);
  box-shadow: var(--ui-bcc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-bcc-ink);
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
}
.ui-bcc *,
.ui-bcc *::before,
.ui-bcc *::after {
  box-sizing: border-box;
}
:where(.ui-bcc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-bcc) svg {
  display: block;
  flex: none;
}
.ui-bcc button:focus-visible {
  outline: 2px solid var(--ui-bcc-focus);
  outline-offset: 2px;
}
.ui-bcc__head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 2px 12px;
  padding: 14px 16px 0;
}
.ui-bcc__title {
  flex: 1 1 0;
  min-width: min(120px, 100%);
  overflow: hidden;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-bcc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bcc__total {
  flex: none;
  max-width: 100%;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bcc-muted);
}
.ui-bcc__total strong {
  white-space: nowrap;
  font-size: 15px;
  line-height: 24px;
  font-weight: 500;
  color: var(--ui-bcc-ink);
}
.ui-bcc__controls {
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: 8px;
  padding: 12px 16px 0;
}
.ui-bcc__select {
  position: relative;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  min-width: 0;
}
.ui-bcc__select-label {
  padding-left: 2px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bcc-muted);
}
.ui-bcc__select-btn {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 6px;
  height: 28px;
  padding: 0 6px 0 10px;
  border-radius: 6px;
  background: var(--ui-bcc-card);
  box-shadow: var(--ui-bcc-shadow);
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-bcc-strong);
  text-align: left;
  transition: box-shadow 160ms ease;
}
.ui-bcc__select-btn:hover {
  box-shadow: var(--ui-bcc-shadow-hover);
}
.ui-bcc__select-btn span {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-bcc__select-btn svg {
  color: var(--ui-bcc-icon);
  transition: transform 220ms var(--ui-bcc-ease);
}
.ui-bcc__select-btn[aria-expanded="true"] svg {
  transform: rotate(180deg);
}
.ui-bcc__menu {
  position: absolute;
  top: calc(100% + 4px);
  left: 0;
  right: 0;
  z-index: 6;
  display: grid;
  gap: 0;
  min-width: 140px;
  padding: 4px;
  border-radius: 10px;
  background: var(--ui-bcc-card);
  box-shadow: var(--ui-bcc-shadow-pop);
  transform-origin: top center;
  animation: ui-bcc-drop 180ms var(--ui-bcc-ease);
}
.ui-bcc__option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 28px;
  padding: 0 6px 0 8px;
  border-radius: 6px;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-bcc-ink);
  text-align: left;
  white-space: nowrap;
}
.ui-bcc__option span {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-bcc__option:hover,
.ui-bcc__option:focus-visible {
  background: var(--ui-bcc-fill);
  outline: none;
}
.ui-bcc__option svg {
  color: var(--ui-bcc-accent);
}
.ui-bcc__chart {
  padding: 20px 16px 10px;
}
.ui-bcc__plot {
  position: relative;
  height: 196px;
  margin-right: 28px;
}
.ui-bcc__grid {
  position: absolute;
  left: 0;
  right: 0;
  height: 0;
  border-top: 0.5px solid var(--ui-bcc-grid);
}
.ui-bcc__grid[data-zero] {
  border-color: var(--ui-bcc-zero);
}
.ui-bcc__tick {
  position: absolute;
  right: -28px;
  top: -8px;
  width: 24px;
  font-size: 11px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-bcc-muted);
}
.ui-bcc__bars {
  position: absolute;
  inset: 0;
  display: grid;
  gap: 4px;
}
.ui-bcc__col {
  position: relative;
  display: flex;
  align-items: flex-end;
  justify-content: center;
  height: 100%;
  border-radius: 6px;
  transition: opacity 200ms ease;
}
.ui-bcc__col:focus-visible {
  outline-offset: 2px;
}
.ui-bcc__col[data-dim] {
  opacity: 0.35;
}
.ui-bcc__rest {
  position: absolute;
  top: 0;
  left: 50%;
  width: min(12px, 100%);
  transform: translateX(-50%);
  border-radius: 3px 3px 0 0;
  background: var(--ui-bcc-rest);
  opacity: 0;
  transition:
    opacity 180ms ease,
    bottom 520ms var(--ui-bcc-ease);
}
.ui-bcc__col[data-active] .ui-bcc__rest {
  opacity: 1;
}
.ui-bcc__bar {
  position: relative;
  display: flex;
  flex-direction: column-reverse;
  gap: 1px;
  width: min(12px, 100%);
  min-height: 0;
  overflow: hidden;
  border-radius: 3px 3px 0 0;
  transition: height 520ms var(--ui-bcc-ease);
}
.ui-bcc__seg {
  flex-basis: 0;
  min-height: 2px;
  transition:
    flex-grow 520ms var(--ui-bcc-ease),
    background-color 300ms ease;
}
.ui-bcc__tooltip {
  position: absolute;
  z-index: 4;
  min-width: 152px;
  padding: 6px 10px 8px;
  border-radius: 10px;
  background: var(--ui-bcc-card);
  box-shadow: var(--ui-bcc-shadow-pop);
  top: 0;
  pointer-events: none;
  max-width: min(260px, 100%);
  transition: left 200ms var(--ui-bcc-ease);
  animation: ui-bcc-pop 160ms var(--ui-bcc-ease);
}
.ui-bcc__tip-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  margin: 0;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-bcc-strong);
}
.ui-bcc__tip-head strong {
  flex: none;
  font-weight: 500;
}
.ui-bcc__tip-label {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  white-space: nowrap;
}
.ui-bcc__tip-label > span,
.ui-bcc__tip-seg,
.ui-bcc__pill > span,
.ui-bcc__row-label > span,
.ui-bcc__th-seg > span:last-child,
.ui-bcc__chip > span:last-child {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-bcc__tooltip ul {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
  margin: 4px 0 0;
  padding: 4px 0 0;
  border-top: 0.5px solid var(--ui-bcc-line);
  list-style: none;
}
.ui-bcc__tooltip li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-bcc-text);
}
.ui-bcc__tip-seg {
  flex: 1;
  white-space: nowrap;
}
.ui-bcc__tip-num {
  flex: none;
  color: var(--ui-bcc-ink);
}
.ui-bcc__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-bcc__xaxis {
  display: grid;
  gap: 4px;
  margin: 8px 28px 0 0;
}
.ui-bcc__xlabel {
  position: relative;
  display: grid;
  place-items: center;
  height: 24px;
  min-width: 0;
  overflow: visible;
  color: var(--ui-bcc-icon);
}
.ui-bcc__pill {
  position: absolute;
  top: 50%;
  left: 50%;
  z-index: 2;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 24px;
  padding: 0 8px 0 6px;
  border-radius: 6px;
  background: var(--ui-bcc-card);
  box-shadow: var(--ui-bcc-shadow);
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  max-width: min(220px, 80cqw);
  white-space: nowrap;
  color: var(--ui-bcc-ink);
  transform: translate(-50%, -50%);
  animation: ui-bcc-pill 200ms var(--ui-bcc-ease);
}
.ui-bcc__xtext {
  overflow: hidden;
  max-width: 100%;
  font-size: 11px;
  line-height: 16px;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-bcc-muted);
}
.ui-bcc__table-wrap {
  overflow-x: auto;
  border-top: 0.5px solid var(--ui-bcc-line);
  scrollbar-width: thin;
}
.ui-bcc__table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
  line-height: 20px;
}
.ui-bcc__table th,
.ui-bcc__table td {
  height: 36px;
  padding: 0 10px;
  border-top: 0.5px solid var(--ui-bcc-line);
  background: var(--ui-bcc-card);
  text-align: left;
  white-space: nowrap;
}
.ui-bcc__table th:first-child,
.ui-bcc__table td:first-child {
  padding-left: 16px;
}
.ui-bcc__table th:last-child,
.ui-bcc__table td:last-child {
  padding-right: 16px;
}
.ui-bcc__table thead th {
  height: 32px;
  border-top: 0;
  font-size: 10px;
  line-height: 16px;
  font-weight: 500;
  letter-spacing: 0.5px;
  text-transform: uppercase;
  color: var(--ui-bcc-muted);
}
.ui-bcc__table [data-num] {
  text-align: right;
}
.ui-bcc__table tbody th {
  position: sticky;
  left: 0;
  z-index: 1;
  font-weight: 400;
  color: var(--ui-bcc-ink);
}
.ui-bcc__table tbody tr[data-active] th,
.ui-bcc__table tbody tr[data-active] td {
  background: linear-gradient(var(--ui-bcc-wash), var(--ui-bcc-wash))
    var(--ui-bcc-card);
}
.ui-bcc__table td {
  color: var(--ui-bcc-text);
}
.ui-bcc__table td[data-total] {
  color: var(--ui-bcc-ink);
}
.ui-bcc__table [data-hidden] {
  opacity: 0.35;
}
.ui-bcc__row-label,
.ui-bcc__th-seg {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  max-width: 220px;
}
.ui-bcc__th-seg {
  max-width: 160px;
}
.ui-bcc__row-label svg {
  color: var(--ui-bcc-icon);
}
.ui-bcc__th-seg {
  gap: 6px;
}
.ui-bcc__foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  min-height: 44px;
  padding: 8px;
  border-top: 0.5px solid var(--ui-bcc-line);
}
.ui-bcc__legend {
  display: flex;
  flex-wrap: nowrap;
  gap: 2px;
  min-width: 0;
  overflow-x: auto;
  scrollbar-width: none;
}
.ui-bcc__legend::-webkit-scrollbar {
  display: none;
}
.ui-bcc__chip {
  flex: none;
  max-width: 220px;
}
.ui-bcc .ui-bcc__chip:focus-visible {
  outline-offset: -2px;
}
.ui-bcc__chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 12px;
  line-height: 16px;
  font-weight: 500;
  color: var(--ui-bcc-text);
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    opacity 160ms ease;
}
.ui-bcc__chip:hover {
  background: var(--ui-bcc-wash);
  color: var(--ui-bcc-ink);
}
.ui-bcc__chip[aria-pressed="false"] {
  opacity: 0.45;
  text-decoration: line-through;
  text-decoration-color: var(--ui-bcc-faint);
}
.ui-bcc__hint {
  padding-left: 8px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-bcc-muted);
}
.ui-bcc__reset {
  flex: none;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-bcc-ink);
  transition: background-color 140ms ease;
  animation: ui-bcc-pop 160ms var(--ui-bcc-ease);
}
.ui-bcc__reset:hover {
  background: var(--ui-bcc-wash);
}
@keyframes ui-bcc-drop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-bcc-pop {
  from {
    opacity: 0;
  }
}
@keyframes ui-bcc-pill {
  from {
    opacity: 0;
    transform: translate(-50%, -50%) scale(0.92);
  }
}
.ui-bcc__morph {
  overflow: hidden;
}
.ui-bcc__morph[data-smooth] {
  transition: height 380ms var(--ui-bcc-ease);
}
@container (max-width: 420px) {
  .ui-bcc__head {
    padding: 12px 12px 0;
  }
  .ui-bcc__controls {
    gap: 6px;
    padding: 10px 12px 0;
  }
  .ui-bcc__select-btn {
    padding: 0 4px 0 8px;
  }
  .ui-bcc__chart {
    padding: 18px 12px 8px;
  }
  .ui-bcc__plot {
    height: 168px;
  }
  .ui-bcc__bar,
  .ui-bcc__rest {
    width: min(10px, 100%);
  }
  .ui-bcc__table th:first-child,
  .ui-bcc__table td:first-child {
    padding-left: 12px;
  }
  .ui-bcc__table th:last-child,
  .ui-bcc__table td:last-child {
    padding-right: 12px;
  }
  .ui-bcc__foot {
    padding: 6px;
  }
  .ui-bcc__legend {
    gap: 0;
  }
  .ui-bcc__chip {
    gap: 5px;
    padding: 0 6px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-bcc__select-btn {
    height: 36px;
  }
  .ui-bcc__option {
    height: 40px;
  }
  .ui-bcc__chip,
  .ui-bcc__reset {
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-bcc__bar,
  .ui-bcc__seg,
  .ui-bcc__tooltip,
  .ui-bcc__col,
  .ui-bcc__rest,
  .ui-bcc__morph[data-smooth] {
    transition: none;
  }
  .ui-bcc__menu,
  .ui-bcc__tooltip,
  .ui-bcc__pill,
  .ui-bcc__reset {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-bcc {
  --ui-bcc-card: #1c1c1e;
  --ui-bcc-ink: rgba(255, 255, 255, 0.9);
  --ui-bcc-strong: #ffffff;
  --ui-bcc-text: rgba(255, 255, 255, 0.62);
  --ui-bcc-muted: rgba(255, 255, 255, 0.46);
  --ui-bcc-faint: rgba(255, 255, 255, 0.3);
  --ui-bcc-icon: rgba(255, 255, 255, 0.5);
  --ui-bcc-line: rgba(255, 255, 255, 0.08);
  --ui-bcc-grid: rgba(255, 255, 255, 0.08);
  --ui-bcc-zero: rgba(255, 255, 255, 0.16);
  --ui-bcc-fill: rgba(255, 255, 255, 0.08);
  --ui-bcc-wash: rgba(255, 255, 255, 0.04);
  --ui-bcc-rest: rgba(255, 255, 255, 0.05);
  --ui-bcc-accent: #4d8dff;
  --ui-bcc-focus: rgba(77, 141, 255, 0.8);
  --ui-bcc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-bcc-shadow-hover:
    0 0 0 0.5px rgba(255, 255, 255, 0.16), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-bcc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-bcc__menu,
:where(.dark, [data-theme="dark"]) .ui-bcc__tooltip,
:where(.dark, [data-theme="dark"]) .ui-bcc__pill {
  background: #252527;
}
:where(.dark, [data-theme="dark"]) .ui-bcc__select-btn {
  background: #232325;
}
`;function r(i){return c.jsx(e,{...i,styles:t,clean:!0})}export{r as B};
