import{j as p}from"./workbench-model-BwgilGut.js";import{K as e}from"./KpiChartView-C8MQd6X9.js";const t=`
.ui-kpic {
  --ui-kpic-card: #ffffff;
  --ui-kpic-pop: #ffffff;
  --ui-kpic-ink: rgba(0, 0, 0, 0.88);
  --ui-kpic-strong: #000000;
  --ui-kpic-text: rgba(0, 0, 0, 0.65);
  --ui-kpic-muted: rgba(0, 0, 0, 0.65);
  --ui-kpic-line: rgba(0, 0, 0, 0.06);
  --ui-kpic-grid: rgba(0, 0, 0, 0.06);
  --ui-kpic-guide: rgba(0, 0, 0, 0.12);
  --ui-kpic-up: #0f783c;
  --ui-kpic-up-bg: rgba(26, 154, 82, 0.08);
  --ui-kpic-down: #bf383d;
  --ui-kpic-down-bg: rgba(229, 72, 77, 0.08);
  --ui-kpic-focus: rgba(0, 96, 226, 0.7);
  --ui-kpic-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-kpic-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-kpic-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 460px;
  border-radius: 10px;
  background: var(--ui-kpic-card);
  box-shadow: var(--ui-kpic-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 20px;
  font-weight: 400;
  color: var(--ui-kpic-ink);
  -webkit-font-smoothing: antialiased;
  font-variant-numeric: tabular-nums;
}
.ui-kpic *,
.ui-kpic *::before,
.ui-kpic *::after {
  box-sizing: border-box;
}
.ui-kpic__body {
  padding: 14px 16px 12px;
}
.ui-kpic__title {
  margin: 0;
  overflow: hidden;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-kpic-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-kpic__value {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  margin: 6px 0 0;
  font-size: 24px;
  font-weight: 500;
  line-height: 32px;
  letter-spacing: -0.02em;
  color: var(--ui-kpic-strong);
}
.ui-kpic__delta {
  flex: none;
  white-space: nowrap;
  display: inline-flex;
  align-items: center;
  height: 20px;
  padding: 0 6px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  letter-spacing: 0;
}
.ui-kpic__amount {
  min-width: 0;
  overflow-wrap: anywhere;
}
.ui-kpic__delta[data-trend="up"] {
  background: var(--ui-kpic-up-bg);
  color: var(--ui-kpic-up);
}
.ui-kpic__delta[data-trend="down"] {
  background: var(--ui-kpic-down-bg);
  color: var(--ui-kpic-down);
}
.ui-kpic__chart {
  display: grid;
  grid-template-columns: auto 1fr;
  grid-template-rows: 124px 16px;
  column-gap: 10px;
  row-gap: 8px;
  margin-top: 20px;
}
.ui-kpic__yaxis {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin: -8px 0;
  font-size: 11px;
  line-height: 16px;
  text-align: right;
  color: var(--ui-kpic-muted);
}
.ui-kpic__plot {
  position: relative;
  touch-action: pan-y;
  border-radius: 4px;
  outline: none;
  cursor: crosshair;
}
.ui-kpic__plot:focus-visible {
  outline: 2px solid var(--ui-kpic-focus);
  outline-offset: 2px;
}
.ui-kpic__grid {
  position: absolute;
  left: 0;
  right: 0;
  height: 0;
  border-top: 0.5px solid var(--ui-kpic-grid);
}
.ui-kpic__lines {
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: visible;
  animation: ui-kpic-draw 1100ms var(--ui-kpic-ease) both;
}
.ui-kpic__lines path {
  fill: none;
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-kpic__marker {
  position: absolute;
  inset: 0;
  pointer-events: none;
  opacity: 0;
  transition: opacity 140ms ease;
}
.ui-kpic__marker[data-open] {
  opacity: 1;
}
.ui-kpic__guide,
.ui-kpic__dot {
  position: absolute;
  transition:
    left 90ms ease-out,
    top 90ms ease-out;
}
.ui-kpic__guide {
  top: -4px;
  bottom: 0;
  width: 0;
  border-left: 1px solid var(--ui-kpic-guide);
  margin-left: -0.5px;
}
.ui-kpic__dot {
  width: 8px;
  height: 8px;
  margin: -4px 0 0 -4px;
  border-radius: 50%;
  box-shadow: 0 0 0 2px var(--ui-kpic-card);
}
.ui-kpic__point {
  position: absolute;
  width: 6px;
  height: 6px;
  margin: -3px 0 0 -3px;
  border-radius: 50%;
  box-shadow: 0 0 0 2px var(--ui-kpic-card);
  pointer-events: none;
  animation: ui-kpic-pop 400ms var(--ui-kpic-ease) both;
}
.ui-kpic__plot[data-empty] {
  cursor: default;
}
.ui-kpic__plot[data-empty] > :not(.ui-kpic__grid, .ui-kpic__empty) {
  display: none;
}
.ui-kpic__empty {
  position: absolute;
  top: 50%;
  left: 50%;
  max-width: 100%;
  margin: 0;
  padding: 0 10px;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  background: var(--ui-kpic-card);
  transform: translate(-50%, -50%);
  font-size: 12px;
  line-height: 16px;
  text-align: center;
  color: var(--ui-kpic-muted);
}
.ui-kpic__tooltip {
  position: absolute;
  top: -8px;
  z-index: 2;
  min-width: 160px;
  max-width: calc(100cqw - 16px);
  padding: 6px 10px 8px;
  border-radius: 10px;
  background: var(--ui-kpic-pop);
  box-shadow: var(--ui-kpic-shadow-pop);
  pointer-events: none;
  opacity: 0;
  transform: translateX(calc(var(--ui-kpic-shift) + var(--ui-kpic-nudge, 0px)))
    scale(0.98);
  transition:
    left 90ms ease-out,
    opacity 140ms ease,
    transform 180ms var(--ui-kpic-ease);
}
.ui-kpic__tooltip[data-side="right"] {
  --ui-kpic-shift: 14px;
  transform-origin: left top;
}
.ui-kpic__tooltip[data-side="left"] {
  --ui-kpic-shift: calc(-100% - 14px);
  transform-origin: right top;
}
.ui-kpic__tooltip[data-open] {
  opacity: 1;
  transform: translateX(calc(var(--ui-kpic-shift) + var(--ui-kpic-nudge, 0px)));
}
.ui-kpic__date {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin: 0;
  font-size: 13px;
  line-height: 20px;
  font-weight: 500;
  color: var(--ui-kpic-strong);
}
.ui-kpic__tooltip ul {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 0;
  margin: 4px 0 0;
  padding: 4px 0 0;
  border-top: 0.5px solid var(--ui-kpic-line);
  list-style: none;
}
.ui-kpic__tooltip li {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  line-height: 20px;
  color: var(--ui-kpic-text);
}
.ui-kpic__swatch {
  flex: none;
  width: 8px;
  height: 8px;
  border-radius: 2px;
}
.ui-kpic__label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-kpic__num {
  flex: none;
  padding-left: 16px;
  color: var(--ui-kpic-ink);
}
.ui-kpic__xaxis {
  position: relative;
  grid-column: 2;
  font-size: 11px;
  line-height: 16px;
  color: var(--ui-kpic-muted);
}
.ui-kpic__xaxis span {
  position: absolute;
  top: 0;
  max-width: 34%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  transform: translateX(-50%);
}
.ui-kpic__xaxis span[data-edge="start"] {
  transform: none;
}
.ui-kpic__xaxis span[data-edge="end"] {
  transform: translateX(-100%);
}
.ui-kpic__footer {
  overflow-wrap: anywhere;
  margin: 0;
  padding: 10px 16px;
  border-top: 0.5px solid var(--ui-kpic-line);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-kpic-muted);
}
@keyframes ui-kpic-draw {
  from {
    clip-path: inset(-10% 100% -10% 0);
  }
  to {
    clip-path: inset(-10% -2% -10% 0);
  }
}
@keyframes ui-kpic-pop {
  from {
    opacity: 0;
    transform: scale(0.4);
  }
}
@container (max-width: 360px) {
  .ui-kpic__body {
    padding: 12px 12px 10px;
  }
  .ui-kpic__chart {
    grid-template-rows: 112px 16px;
    column-gap: 8px;
  }
  .ui-kpic__footer {
    padding: 10px 12px;
  }
  .ui-kpic__tooltip {
    min-width: 144px;
  }
  .ui-kpic__num {
    padding-left: 12px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-kpic__lines,
  .ui-kpic__point {
    animation: none;
  }
  .ui-kpic__marker,
  .ui-kpic__guide,
  .ui-kpic__dot,
  .ui-kpic__tooltip {
    transition: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-kpic {
  --ui-kpic-card: #1c1c1e;
  --ui-kpic-pop: #252527;
  --ui-kpic-ink: rgba(255, 255, 255, 0.9);
  --ui-kpic-strong: #ffffff;
  --ui-kpic-text: rgba(255, 255, 255, 0.62);
  --ui-kpic-muted: rgba(255, 255, 255, 0.46);
  --ui-kpic-line: rgba(255, 255, 255, 0.08);
  --ui-kpic-grid: rgba(255, 255, 255, 0.08);
  --ui-kpic-guide: rgba(255, 255, 255, 0.2);
  --ui-kpic-up: #3ec27a;
  --ui-kpic-up-bg: rgba(62, 194, 122, 0.14);
  --ui-kpic-down: #ff6b70;
  --ui-kpic-down-bg: rgba(229, 72, 77, 0.14);
  --ui-kpic-focus: rgba(77, 141, 255, 0.8);
  --ui-kpic-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-kpic-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
}
`;function r(i){return p.jsx(e,{...i,styles:t,clean:!0})}export{r as K};
