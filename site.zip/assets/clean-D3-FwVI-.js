import{j as o}from"./workbench-model-BwgilGut.js";import{T as t}from"./clean-B3MOLIAD.js";import{w as r}from"./preview-CHHlf7B_.js";const n=r(t);function a(){return o.jsx(n,{})}export{a as default};
