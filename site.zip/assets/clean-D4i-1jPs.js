import{j as o}from"./workbench-model-BwgilGut.js";import{R as t}from"./clean-DLtcxi4_.js";import{w as r}from"./preview-CHHlf7B_.js";const m=r(t);function e(){return o.jsx(m,{})}export{e as default};
