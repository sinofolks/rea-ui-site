import{j as i}from"./workbench-model-BwgilGut.js";import{u as Q,n as W,s as X,f as Z,P as z,a as ii,E as D,b as ei,c as ai}from"./ElapsedTime-BwwqT7Bi.js";function ri({styles:d,createStepId:B,...h}){const{title:s,estimate:_,className:R,onRetry:m,onRun:c,onCancel:g,status:S="draft"}=h,{planSteps:P,isDraft:r,stepsRef:o,editing:n,setEditing:E,newTitle:f,setNewTitle:v,removingIds:I,draggingId:b,announcement:A,rootRef:F,addInputRef:T,rowRefs:w,enteringIds:y,activeSince:K,durations:L,planStartedAt:Y,instructionsId:k,focusRow:$,removeStep:U,beginRename:V,finishRename:x,addStep:H,handleRowKeyDown:q,startDrag:G,moveDrag:J,finishDrag:j,total:u,phase:l,statusText:N}=Q(h,B);return i.jsxs("div",{ref:F,className:["ui-plc",R].filter(Boolean).join(" "),"data-status":S,"data-dragging":b?"":void 0,children:[i.jsx("style",{href:"ui-agent-plan-clean",precedence:"default",children:d}),i.jsxs("div",{className:"ui-plc__card",children:[i.jsxs("div",{className:"ui-plc__head",children:[i.jsxs("div",{className:"ui-plc__meta",children:[i.jsxs("span",{className:"ui-plc__state",children:[i.jsx("span",{className:"ui-plc__state-icon","aria-hidden":"true",children:i.jsxs("svg",{viewBox:"0 0 16 16",children:[i.jsx("path",{d:"M6.5 4.5h7M6.5 8h7M6.5 11.5h7"}),i.jsx("circle",{cx:"3.25",cy:"4.5",r:".6"}),i.jsx("circle",{cx:"3.25",cy:"8",r:".6"}),i.jsx("circle",{cx:"3.25",cy:"11.5",r:".6"})]})}),i.jsxs("span",{className:"ui-plc__state-label",children:["Plan · ",W.format(u)," ",u===1?"step":"steps"]})]}),r&&_?i.jsxs("span",{className:"ui-plc__estimate",title:_,children:[i.jsxs("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:[i.jsx("circle",{cx:"8",cy:"8",r:"6"}),i.jsx("path",{d:"M8 5v3.2l2 1.3"})]}),i.jsxs("span",{children:[i.jsx("span",{className:"ui-plc__sr",children:"Estimated time "}),_]})]}):null]}),s&&i.jsx("h3",{className:"ui-plc__title",dir:"auto",children:s})]}),i.jsx("p",{id:k,className:"ui-plc__sr",children:"Press Enter to rename, Alt plus arrow keys to move, Delete to remove."}),i.jsx("ol",{className:"ui-plc__list","aria-label":s?`Plan: ${s}`:"Plan",children:P.map((e,p)=>{const t=X(e),C=r&&(n==null?void 0:n.id)===e.id,M=Z(e.duration)??L.current.get(e.id),O=K.current.get(e.id);return i.jsxs("li",{ref:a=>(a&&w.current.set(e.id,a),()=>{w.current.delete(e.id)}),className:"ui-plc__step","data-step":r?void 0:t,"data-dragging":b===e.id?"":void 0,"data-removing":I.includes(e.id)?"":void 0,"data-enter":y.current.has(e.id)?"":void 0,onAnimationEnd:a=>{a.target===a.currentTarget&&y.current.delete(e.id)},tabIndex:r&&!C?0:void 0,"aria-describedby":r?k:void 0,"aria-current":t==="active"&&!r?"step":void 0,onKeyDown:a=>q(a,e.id),children:[r&&i.jsx("span",{className:"ui-plc__grip","aria-hidden":"true",title:"Drag to reorder",onPointerDown:a=>G(a,e.id),onPointerMove:J,onPointerUp:j,onPointerCancel:j,children:i.jsxs("svg",{viewBox:"0 0 16 16",children:[i.jsx("circle",{cx:"6",cy:"4",r:"1.1"}),i.jsx("circle",{cx:"10",cy:"4",r:"1.1"}),i.jsx("circle",{cx:"6",cy:"8",r:"1.1"}),i.jsx("circle",{cx:"10",cy:"8",r:"1.1"}),i.jsx("circle",{cx:"6",cy:"12",r:"1.1"}),i.jsx("circle",{cx:"10",cy:"12",r:"1.1"})]})}),i.jsx("span",{className:"ui-plc__marker","aria-hidden":"true",children:r||t==="pending"?i.jsx("span",{className:"ui-plc__num",children:p+1}):t==="active"?i.jsx(z,{prefix:"ui-plc"}):t==="done"?i.jsx("svg",{viewBox:"0 0 16 16",className:"ui-plc__mark",children:i.jsx("path",{d:"M4.2 8.4 6.8 11l5-5.6",pathLength:1,className:"ui-plc__draw"})}):t==="failed"?i.jsx("svg",{viewBox:"0 0 16 16",className:"ui-plc__mark",children:i.jsx("path",{d:"M8 4.2v4.4M8 11.6h.01"})}):i.jsx("svg",{viewBox:"0 0 16 16",className:"ui-plc__mark",children:i.jsx("path",{d:"M5 8h6"})})}),i.jsxs("div",{className:"ui-plc__main",children:[C?i.jsx("input",{className:"ui-plc__edit",dir:"auto",value:n==null?void 0:n.value,"aria-label":`Rename step ${p+1}`,autoFocus:!0,onFocus:a=>a.currentTarget.select(),onChange:a=>E({id:e.id,value:a.target.value}),onBlur:()=>x(!0),onKeyDown:a=>{a.key==="Enter"?(a.preventDefault(),x(!0,!0)):a.key==="Escape"&&(a.preventDefault(),a.stopPropagation(),x(!1,!0))}}):i.jsx("span",{className:"ui-plc__name",dir:"auto",onDoubleClick:()=>V(e.id),children:e.title}),(e.detail||e.tool)&&i.jsxs("span",{className:"ui-plc__sub",children:[e.detail&&i.jsx("span",{className:"ui-plc__detail",dir:"auto",children:e.detail}),e.tool&&i.jsx("code",{className:"ui-plc__tool",title:e.tool,children:e.tool})]}),!r&&i.jsxs("span",{className:"ui-plc__sr",children:[", ",ii[t]]}),!r&&t==="failed"&&i.jsxs("span",{className:"ui-plc__fail",children:[i.jsx("span",{className:"ui-plc__error",dir:"auto",children:e.error??"This step failed"}),m&&i.jsxs("button",{type:"button",className:"ui-plc__retry",onClick:()=>m(e.id),children:[i.jsxs("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:[i.jsx("path",{d:"M13 8a5 5 0 1 1-1.6-3.7"}),i.jsx("path",{d:"M13 3v2.6h-2.6"})]}),"Retry from here"]})]})]}),i.jsx("span",{className:"ui-plc__aside",children:r?i.jsx("button",{type:"button",className:"ui-plc__remove","aria-label":`Remove step ${p+1}: ${e.title}`,onClick:()=>U(e.id),children:i.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:i.jsx("path",{d:"M4.5 4.5l7 7M11.5 4.5l-7 7"})})}):t==="active"?i.jsx("span",{className:"ui-plc__time","aria-hidden":"true",children:i.jsx(D,{since:O})}):t==="done"&&M!==void 0?i.jsxs("span",{className:"ui-plc__time ui-plc__time--done",children:[i.jsx("span",{className:"ui-plc__sr",children:"took "}),ei(M)]}):t==="skipped"?i.jsx("span",{className:"ui-plc__time","aria-hidden":"true",children:"Skipped"}):null}),p<u-1&&i.jsx("span",{className:"ui-plc__rail","aria-hidden":"true"})]},e.id)})}),i.jsx("div",{className:"ui-plc__tail",inert:!r,children:i.jsx("div",{className:"ui-plc__tail-inner",children:i.jsxs("label",{className:"ui-plc__add",children:[i.jsx("span",{className:"ui-plc__add-icon","aria-hidden":"true",children:i.jsx("svg",{viewBox:"0 0 16 16",children:i.jsx("path",{d:"M8 4.5v7M4.5 8h7"})})}),i.jsx("input",{ref:T,value:f,placeholder:"Add step","aria-label":"Add a step at the end",enterKeyHint:"done",onChange:e=>v(e.target.value),onKeyDown:e=>{if(e.key==="Enter")e.preventDefault(),H();else if(e.key==="Escape")v("");else if(e.key==="ArrowUp"&&!f){const p=o.current[o.current.length-1];p&&(e.preventDefault(),$(p.id))}}})]})})}),i.jsx("div",{className:"ui-plc__foot","data-phase":l,children:l==="draft"?i.jsxs(i.Fragment,{children:[i.jsx("span",{className:"ui-plc__hint","aria-hidden":"true",children:"Drag to reorder · double-click to rename"}),i.jsxs("span",{className:"ui-plc__actions",children:[g&&i.jsx("button",{type:"button",className:"ui-plc__btn ui-plc__btn--secondary",onClick:g,children:"Cancel"}),i.jsxs("button",{type:"button",className:"ui-plc__btn ui-plc__btn--primary ui-plc__run",disabled:!u,onClick:()=>c==null?void 0:c(o.current),children:["Run plan",i.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:i.jsx("path",{d:"M5.5 3.8v8.4L12 8z"})})]})]})]}):i.jsxs(i.Fragment,{children:[i.jsxs("span",{className:"ui-plc__status",children:[i.jsx("span",{className:"ui-plc__status-icon","aria-hidden":"true",children:l==="running"?i.jsx(z,{prefix:"ui-plc"}):l==="done"?i.jsxs("svg",{viewBox:"0 0 16 16",className:"ui-plc__badge",children:[i.jsx("circle",{cx:"8",cy:"8",r:"7"}),i.jsx("path",{d:"M5.2 8.2 7.1 10l3.7-4",pathLength:1,className:"ui-plc__draw"})]}):i.jsxs("svg",{viewBox:"0 0 16 16",className:"ui-plc__badge",children:[i.jsx("circle",{cx:"8",cy:"8",r:"7"}),i.jsx("path",{d:"M8 4.8v3.8M8 11.2h.01"})]})}),i.jsx("span",{className:l==="running"?"ui-plc__status-label ui-plc__shimmer":"ui-plc__status-label","data-text":N,children:N})]}),l==="running"?i.jsx("span",{className:"ui-plc__elapsed","aria-hidden":"true",children:i.jsx(D,{since:Y.current??void 0,whole:!0})}):l==="done"&&c?i.jsx("span",{className:"ui-plc__actions",children:i.jsxs("button",{type:"button",className:"ui-plc__btn ui-plc__btn--secondary ui-plc__again",onClick:()=>c(o.current),children:[i.jsxs("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:[i.jsx("path",{d:"M13 8a5 5 0 1 1-1.6-3.7"}),i.jsx("path",{d:"M13 3v2.6h-2.6"})]}),"Run again"]})}):null]})},l)]}),i.jsx("p",{className:"ui-plc__sr",role:"status","aria-live":"polite",children:A})]})}const ti=`
.ui-plc {
  --ui-plc-card: #ffffff;
  --ui-plc-ink: rgba(0, 0, 0, 0.88);
  --ui-plc-strong: #000000;
  --ui-plc-text: rgba(0, 0, 0, 0.65);
  --ui-plc-muted: rgba(0, 0, 0, 0.65);
  --ui-plc-faint: rgba(0, 0, 0, 0.65);
  --ui-plc-icon: rgba(0, 0, 0, 0.65);
  --ui-plc-line: rgba(0, 0, 0, 0.06);
  --ui-plc-ring: rgba(0, 0, 0, 0.1);
  --ui-plc-rail: rgba(0, 0, 0, 0.08);
  --ui-plc-fill: rgba(0, 0, 0, 0.06);
  --ui-plc-wash: rgba(0, 0, 0, 0.03);
  --ui-plc-chip: rgba(0, 0, 0, 0.045);
  --ui-plc-accent: #0060e2;
  --ui-plc-on-accent: #ffffff;
  --ui-plc-red: #bf383d;
  --ui-plc-red-bg: #bf383d;
  --ui-plc-primary: rgba(0, 0, 0, 0.88);
  --ui-plc-primary-hover: rgba(0, 0, 0, 0.78);
  --ui-plc-on-primary: #fcfcfc;
  --ui-plc-raise-hover: #fafafa;
  --ui-plc-shine: rgba(255, 255, 255, 0.82);
  --ui-plc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-plc-shadow-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.16),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-plc-focus: rgba(0, 96, 226, 0.7);
  --ui-plc-edit-glow: rgba(0, 96, 226, 0.1);
  --ui-plc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-plc-inset: 30px;
  container-type: inline-size;
  position: relative;
  box-sizing: border-box;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  width: 100%;
  max-width: 440px;
  color: var(--ui-plc-ink);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-plc__card {
  position: relative;
  border-radius: 10px;
  background: var(--ui-plc-card);
  box-shadow: var(--ui-plc-shadow);
}
.ui-plc:not([data-status="draft"]) {
  --ui-plc-inset: 10px;
}
.ui-plc[data-dragging] {
  cursor: grabbing;
  user-select: none;
  -webkit-user-select: none;
}
.ui-plc *,
.ui-plc *::before,
.ui-plc *::after {
  box-sizing: border-box;
}
.ui-plc svg {
  display: block;
  width: 100%;
  height: 100%;
  overflow: visible;
}
:where(.ui-plc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  letter-spacing: inherit;
  color: inherit;
  cursor: pointer;
}
.ui-plc__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  margin: -1px;
  padding: 0;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
  border: 0;
}
.ui-plc__head {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  padding: 16px 16px 10px;
}
.ui-plc__meta {
  display: flex;
  align-items: center;
  gap: 10px;
  min-height: 16px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-plc-muted);
}
.ui-plc__state {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  flex: none;
}
.ui-plc__state-label {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-plc__state-icon {
  flex: none;
  width: 16px;
  height: 16px;
  color: var(--ui-plc-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-plc__state-icon circle[r=".6"] {
  fill: currentColor;
}
.ui-plc__estimate {
  display: inline-flex;
  align-items: center;
  min-width: 0;
  gap: 6px;
  margin-left: auto;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-plc__estimate > span {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-plc__estimate svg {
  flex: none;
  width: 16px;
  height: 16px;
  color: var(--ui-plc-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-plc__title {
  margin: 0;
  color: var(--ui-plc-strong);
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  text-wrap: balance;
  overflow-wrap: anywhere;
  text-align: start;
}
.ui-plc__list {
  position: relative;
  margin: 0;
  padding: 0 6px 6px;
  list-style: none;
}
.ui-plc__step {
  position: relative;
  display: grid;
  grid-template-columns: 20px minmax(0, 1fr) auto;
  column-gap: 10px;
  align-items: start;
  padding: 8px 10px 8px var(--ui-plc-inset);
  border-radius: 6px;
  outline: none;
  transition:
    transform 420ms var(--ui-plc-ease),
    padding 420ms var(--ui-plc-ease),
    height 260ms var(--ui-plc-ease),
    opacity 180ms ease,
    background-color 140ms ease,
    box-shadow 200ms ease;
}
.ui-plc[data-status="draft"] .ui-plc__step:hover {
  background: var(--ui-plc-wash);
}
.ui-plc__step:focus-visible {
  outline: 2px solid var(--ui-plc-focus);
  outline-offset: -2px;
}
.ui-plc__step[data-dragging] {
  z-index: 2;
  background: var(--ui-plc-card) !important;
  box-shadow: var(--ui-plc-shadow-pop);
  transition:
    background-color 140ms ease,
    box-shadow 200ms ease;
}
.ui-plc__step[data-removing] {
  height: 0 !important;
  padding-top: 0;
  padding-bottom: 0;
  overflow: hidden;
  opacity: 0;
  pointer-events: none;
}
.ui-plc__step[data-enter] {
  animation: ui-plc-enter 380ms var(--ui-plc-ease) both;
}
.ui-plc__grip {
  position: absolute;
  top: 8px;
  left: 6px;
  display: grid;
  place-items: center;
  width: 18px;
  height: 20px;
  border-radius: 5px;
  color: var(--ui-plc-faint);
  fill: currentColor;
  cursor: grab;
  touch-action: none;
  opacity: 0;
  transition:
    opacity 140ms ease,
    color 140ms ease,
    background-color 140ms ease;
}
.ui-plc__grip svg {
  width: 16px;
  height: 16px;
}
.ui-plc__step:hover .ui-plc__grip,
.ui-plc__step:focus-visible .ui-plc__grip,
.ui-plc__step[data-dragging] .ui-plc__grip {
  opacity: 1;
}
.ui-plc__grip:hover,
.ui-plc__step[data-dragging] .ui-plc__grip {
  color: var(--ui-plc-icon);
  background: var(--ui-plc-fill);
}
.ui-plc__step[data-dragging] .ui-plc__grip {
  cursor: grabbing;
}
.ui-plc__marker {
  position: relative;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--ui-plc-card);
  box-shadow:
    inset 0 0 0 0.5px var(--ui-plc-ring),
    0 1px 1px -1px rgba(0, 0, 0, 0.1);
  color: var(--ui-plc-muted);
  font-size: 11px;
  font-weight: 500;
  line-height: 1;
  font-variant-numeric: tabular-nums;
  transition:
    background-color 320ms ease,
    color 320ms ease,
    box-shadow 320ms ease;
}
.ui-plc__marker > * {
  grid-area: 1 / 1;
  animation: ui-plc-pop 360ms var(--ui-plc-ease) both;
}
.ui-plc__num {
  animation: none !important;
}
.ui-plc__marker .ui-plc__spinner {
  width: 14px;
  height: 14px;
}
.ui-plc__mark {
  width: 12px !important;
  height: 12px !important;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.6;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-plc__step[data-step="active"] .ui-plc__marker {
  box-shadow: none;
  color: var(--ui-plc-accent);
}
.ui-plc__step[data-step="done"] .ui-plc__marker {
  background: var(--ui-plc-accent);
  box-shadow: none;
  color: var(--ui-plc-on-accent);
}
.ui-plc__step[data-step="failed"] .ui-plc__marker {
  background: var(--ui-plc-red-bg);
  box-shadow: none;
  color: var(--ui-plc-red);
}
.ui-plc__step[data-step="skipped"] .ui-plc__marker {
  box-shadow: none;
  outline: 1px dashed var(--ui-plc-faint);
  outline-offset: -1px;
}
.ui-plc__draw {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  animation: ui-plc-draw 420ms var(--ui-plc-ease) 80ms forwards;
}
.ui-plc__spinner line {
  stroke: currentColor;
  stroke-width: 1.4;
  stroke-linecap: round;
  opacity: 0.18;
  animation: ui-plc-ray 800ms linear infinite;
}
.ui-plc__main {
  display: grid;
  gap: 2px;
  min-width: 0;
}
.ui-plc__name {
  color: var(--ui-plc-ink);
  font-weight: 500;
  overflow-wrap: anywhere;
  text-align: start;
  transition: color 300ms ease;
}
.ui-plc[data-status="draft"] .ui-plc__name {
  cursor: text;
}
.ui-plc__step[data-step="pending"] .ui-plc__name {
  color: var(--ui-plc-text);
}
.ui-plc__step[data-step="skipped"] .ui-plc__name {
  color: var(--ui-plc-muted);
  text-decoration: line-through;
  text-decoration-color: var(--ui-plc-faint);
}
.ui-plc__sub {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 8px;
  min-width: 0;
  color: var(--ui-plc-muted);
  font-size: 12px;
  line-height: 16px;
}
.ui-plc__detail {
  min-width: 0;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
}
.ui-plc__tool {
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-plc-chip);
  color: var(--ui-plc-text);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11px;
  line-height: 16px;
  letter-spacing: 0;
  white-space: nowrap;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-plc__edit {
  width: calc(100% + 14px);
  height: 28px;
  margin: -4px -7px;
  padding: 0 6px;
  border: 0;
  border-radius: 6px;
  background: var(--ui-plc-card);
  box-shadow: 0 0 0 0.5px var(--ui-plc-faint);
  color: var(--ui-plc-ink);
  font: inherit;
  font-weight: 500;
  letter-spacing: inherit;
  outline: none;
}
.ui-plc__fail {
  display: grid;
  justify-items: start;
  gap: 8px;
  margin-top: 4px;
  animation: ui-plc-fade 360ms var(--ui-plc-ease) both;
}
.ui-plc__error {
  color: var(--ui-plc-red);
  font-size: 12px;
  line-height: 16px;
  overflow-wrap: anywhere;
  white-space: pre-line;
  text-align: start;
}
.ui-plc__retry,
.ui-plc__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  white-space: nowrap;
  transition:
    background-color 140ms ease,
    opacity 140ms ease,
    transform 160ms var(--ui-plc-ease);
}
.ui-plc__retry,
.ui-plc__btn--secondary {
  background: var(--ui-plc-card);
  box-shadow: var(--ui-plc-shadow);
  color: var(--ui-plc-strong);
}
.ui-plc__retry,
.ui-plc__again {
  padding: 0 10px 0 8px;
}
.ui-plc__retry svg,
.ui-plc__btn--secondary svg {
  width: 16px;
  height: 16px;
  color: var(--ui-plc-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-plc__retry:hover,
.ui-plc__btn--secondary:hover {
  background: var(--ui-plc-raise-hover);
}
.ui-plc__retry:active,
.ui-plc__btn:active {
  transform: scale(0.97);
}
.ui-plc__aside {
  display: flex;
  align-items: center;
  min-height: 20px;
  color: var(--ui-plc-muted);
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-plc__time {
  animation: ui-plc-fade 300ms ease both;
}
.ui-plc__step[data-step="active"] .ui-plc__time {
  color: var(--ui-plc-ink);
}
.ui-plc__remove {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  margin: -4px -6px -4px 0;
  border-radius: 6px;
  color: var(--ui-plc-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
  opacity: 0;
  transition:
    opacity 140ms ease,
    color 140ms ease,
    background-color 140ms ease;
}
.ui-plc__remove svg {
  width: 16px;
  height: 16px;
}
.ui-plc__step:hover .ui-plc__remove,
.ui-plc__step:focus-visible .ui-plc__remove,
.ui-plc__remove:focus-visible {
  opacity: 1;
}
.ui-plc__remove:hover {
  color: var(--ui-plc-ink);
  background: var(--ui-plc-wash);
}
.ui-plc__remove:focus-visible,
.ui-plc__retry:focus-visible,
.ui-plc__btn:focus-visible {
  outline: 2px solid var(--ui-plc-focus);
  outline-offset: 2px;
}
.ui-plc__rail {
  position: absolute;
  top: 31px;
  bottom: -5px;
  left: calc(var(--ui-plc-inset) + 9.5px);
  width: 1px;
  overflow: hidden;
  background: var(--ui-plc-rail);
  opacity: 0;
  pointer-events: none;
  transition: opacity 300ms ease;
}
.ui-plc:not([data-status="draft"]) .ui-plc__rail {
  opacity: 1;
  transition-delay: 240ms;
}
.ui-plc__rail::after {
  content: "";
  position: absolute;
  inset: 0;
  background: var(--ui-plc-accent);
  transform: scaleY(0);
  transform-origin: top;
  transition: transform 560ms var(--ui-plc-ease);
}
.ui-plc__step[data-step="done"] .ui-plc__rail::after,
.ui-plc__step[data-step="skipped"] .ui-plc__rail::after {
  transform: scaleY(1);
}
.ui-plc__tail {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 420ms var(--ui-plc-ease),
    opacity 260ms ease;
}
.ui-plc:not([data-status="draft"]) .ui-plc__tail {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-plc__tail-inner {
  min-height: 0;
  overflow: hidden;
}
.ui-plc__add {
  display: grid;
  grid-template-columns: 20px minmax(0, 1fr);
  column-gap: 10px;
  align-items: center;
  margin: -4px 6px 8px;
  padding: 6px 10px 6px var(--ui-plc-inset);
  border-radius: 6px;
  cursor: text;
  transition: background-color 140ms ease;
}
.ui-plc__add:hover,
.ui-plc__add:focus-within {
  background: var(--ui-plc-wash);
}
.ui-plc__add-icon {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  color: var(--ui-plc-icon);
  fill: none;
  stroke: currentColor;
  stroke-width: 1.1;
  stroke-linecap: round;
}
.ui-plc__add-icon svg {
  width: 16px;
  height: 16px;
}
.ui-plc__add input {
  width: 100%;
  min-width: 0;
  height: 20px;
  padding: 0;
  border: 0;
  background: none;
  color: var(--ui-plc-ink);
  font: inherit;
  letter-spacing: inherit;
  outline: none;
}
.ui-plc__add input::placeholder {
  color: var(--ui-plc-faint);
  opacity: 1;
}
.ui-plc__foot {
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 48px;
  padding: 0 10px 0 16px;
  border-top: 0.5px solid var(--ui-plc-line);
  color: var(--ui-plc-muted);
  font-size: 12px;
  line-height: 16px;
}
.ui-plc__foot > * {
  animation: ui-plc-fade 320ms var(--ui-plc-ease) both;
}
.ui-plc__hint {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-plc__actions {
  display: flex;
  flex: none;
  gap: 8px;
  margin-left: auto;
}
.ui-plc__btn--primary {
  padding: 0 8px 0 10px;
  background: var(--ui-plc-primary);
  color: var(--ui-plc-on-primary);
}
.ui-plc__btn--primary:hover {
  background: var(--ui-plc-primary-hover);
}
.ui-plc__btn--primary:disabled {
  opacity: 0.4;
  cursor: default;
  transform: none;
}
.ui-plc__btn--primary svg {
  width: 16px;
  height: 16px;
  fill: currentColor;
}
.ui-plc__status {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  color: var(--ui-plc-ink);
  font-size: 13px;
  line-height: 20px;
}
.ui-plc__status-icon {
  flex: none;
  width: 16px;
  height: 16px;
  color: var(--ui-plc-accent);
}
.ui-plc__status-icon .ui-plc__spinner {
  width: 14px;
  height: 14px;
  margin: 1px;
}
.ui-plc__badge circle {
  fill: currentColor;
}
.ui-plc__badge path {
  fill: none;
  stroke: var(--ui-plc-on-accent);
  stroke-width: 1.4;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-plc__foot[data-phase="failed"] .ui-plc__status-icon {
  color: var(--ui-plc-red-bg);
}
.ui-plc__foot[data-phase="failed"] .ui-plc__badge path {
  stroke: var(--ui-plc-red);
  stroke-width: 1.6;
}
.ui-plc__foot[data-phase="failed"] .ui-plc__status {
  color: var(--ui-plc-red);
}
.ui-plc__status-label {
  position: relative;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
}
.ui-plc__foot[data-phase="done"] .ui-plc__status-label {
  font-weight: 500;
}
.ui-plc__shimmer {
  color: var(--ui-plc-muted);
}
.ui-plc__shimmer::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(
      90deg,
      transparent 38%,
      var(--ui-plc-shine) 50%,
      transparent 62%
    )
    100% 0 / 300% 100% no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  animation: ui-plc-sweep 1.6s linear infinite;
  pointer-events: none;
}
.ui-plc__elapsed {
  margin-left: auto;
  padding-right: 6px;
  color: var(--ui-plc-faint);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
@media (hover: none) {
  .ui-plc__grip,
  .ui-plc__remove {
    opacity: 1;
  }
}
@media (pointer: coarse) {
  .ui-plc__foot {
    min-height: 56px;
  }
  .ui-plc__btn,
  .ui-plc__retry {
    height: 36px;
  }
  .ui-plc__remove {
    width: 36px;
    height: 36px;
    margin: -8px -10px -8px 0;
  }
  .ui-plc__grip::after {
    content: "";
    position: absolute;
    inset: -8px -6px;
  }
}
@container (max-width: 400px) {
  .ui-plc__hint {
    display: none;
  }
}
@container (max-width: 340px) {
  .ui-plc__head {
    padding: 14px 14px 10px;
  }
  .ui-plc__list {
    padding-inline: 4px;
  }
  .ui-plc__step,
  .ui-plc__add {
    column-gap: 8px;
    padding-right: 8px;
  }
  .ui-plc__add {
    margin-inline: 4px;
  }
  .ui-plc__foot {
    padding-left: 14px;
  }
}
@keyframes ui-plc-fade {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-plc-enter {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-plc-pop {
  from {
    opacity: 0;
    transform: scale(0.5);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-plc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-plc-ray {
  0% {
    opacity: 1;
  }
  100% {
    opacity: 0.18;
  }
}
@keyframes ui-plc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-plc *,
  .ui-plc *::before,
  .ui-plc *::after {
    animation-duration: 1ms !important;
    animation-delay: 0ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
    transition-delay: 0ms !important;
  }
  .ui-plc__spinner line {
    opacity: 0.6;
  }
  .ui-plc__draw {
    stroke-dashoffset: 0;
  }
  .ui-plc__shimmer::after {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-plc {
  --ui-plc-card: #1c1c1e;
  --ui-plc-ink: rgba(255, 255, 255, 0.9);
  --ui-plc-strong: #ffffff;
  --ui-plc-text: rgba(255, 255, 255, 0.62);
  --ui-plc-muted: rgba(255, 255, 255, 0.46);
  --ui-plc-faint: rgba(255, 255, 255, 0.3);
  --ui-plc-icon: rgba(255, 255, 255, 0.5);
  --ui-plc-line: rgba(255, 255, 255, 0.08);
  --ui-plc-ring: rgba(255, 255, 255, 0.14);
  --ui-plc-rail: rgba(255, 255, 255, 0.1);
  --ui-plc-fill: rgba(255, 255, 255, 0.08);
  --ui-plc-wash: rgba(255, 255, 255, 0.04);
  --ui-plc-chip: rgba(255, 255, 255, 0.07);
  --ui-plc-accent: #4d8dff;
  --ui-plc-red: #ff6b70;
  --ui-plc-red-bg: rgba(229, 72, 77, 0.14);
  --ui-plc-primary: rgba(255, 255, 255, 0.9);
  --ui-plc-primary-hover: rgba(255, 255, 255, 0.8);
  --ui-plc-on-primary: #1c1c1e;
  --ui-plc-raise-hover: #232326;
  --ui-plc-shine: #ffffff;
  --ui-plc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-plc-shadow-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-plc-focus: rgba(77, 141, 255, 0.8);
  --ui-plc-edit-glow: rgba(77, 141, 255, 0.14);
}
:where(.dark, [data-theme="dark"]) .ui-plc__marker {
  box-shadow: inset 0 0 0 0.5px var(--ui-plc-ring);
}
`,li=ai();function ci(d){return i.jsx(ri,{...d,styles:ti,createStepId:li})}export{ci as A};
