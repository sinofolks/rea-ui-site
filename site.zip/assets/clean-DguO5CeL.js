import{j as t}from"./workbench-model-BwgilGut.js";import{A as i}from"./AgentTreeView-DmzH7fSg.js";const e=`.ui-agtc {
  --ui-agtc-card: #ffffff;
  --ui-agtc-strong: #000000;
  --ui-agtc-ink: rgba(0, 0, 0, 0.88);
  --ui-agtc-text: rgba(0, 0, 0, 0.65);
  --ui-agtc-muted: rgba(0, 0, 0, 0.65);
  --ui-agtc-faint: rgba(0, 0, 0, 0.27);
  --ui-agtc-line: rgba(0, 0, 0, 0.06);
  --ui-agtc-fill: rgba(0, 0, 0, 0.06);
  --ui-agtc-accent: #0060e2;
  --ui-agtc-link: #82bcff;
  --ui-agtc-link-muted: rgba(0, 0, 0, 0.12);
  --ui-agtc-brand-bg: #008ff519;
  --ui-agtc-brand-fg: #006ac6;
  --ui-agtc-ok-bg: #00a43319;
  --ui-agtc-ok-fg: #007a2d;
  --ui-agtc-warn-bg: #ff9c0029;
  --ui-agtc-warn-fg: #b74400;
  --ui-agtc-danger-bg: #f52b0018;
  --ui-agtc-danger-fg: #cd2200;
  --ui-agtc-focus: rgba(0, 96, 226, 0.7);
  --ui-agtc-solid: rgba(0, 0, 0, 0.88);
  --ui-agtc-on-solid: #fcfcfc;
  --ui-agtc-pop:
    0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 12px 28px -10px rgba(0, 0, 0, 0.18),
    0 1px 2px rgba(0, 0, 0, 0.05);
  --ui-agtc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-agtc-card-w: 216px;
  --ui-agtc-indent: 32px;
  --ui-agtc-shine: rgba(0, 0, 0, 0.22);
  --ui-agtc-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-agtc-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-agtc *,
.ui-agtc *::before,
.ui-agtc *::after {
  box-sizing: border-box;
}
:where(.ui-agtc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-agtc button:focus-visible {
  outline: 2px solid var(--ui-agtc-focus);
  outline-offset: 2px;
}
.ui-agtc p {
  margin: 0;
}
.ui-agtc svg {
  display: block;
  flex: none;
}
.ui-agtc__bar {
  position: relative;
  z-index: 3;
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 8px;
  min-width: 0;
  margin-bottom: 16px;
}
.ui-agtc__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-agtc-accent);
}
.ui-agtc__title {
  flex: 1 1 0;
  min-width: min(160px, 100%);
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-agtc-strong);
}
.ui-agtc__sum {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  align-items: center;
  gap: 4px 10px;
  margin-left: auto;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agtc__sum-run {
  color: var(--ui-agtc-brand-fg);
}
.ui-agtc__sum-wait {
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__sum-fail {
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__sum-cost {
  min-width: 44px;
  color: var(--ui-agtc-ink);
  font-weight: 500;
  text-align: right;
}
.ui-agtc__sum-btn {
  display: inline-flex;
  flex: none;
  white-space: nowrap;
  align-items: center;
  gap: 2px;
  height: 22px;
  margin: -3px 0;
  padding: 0 4px 0 7px;
  border-radius: 5px;
  font-size: 12px;
  font-weight: 500;
  transition: background-color 160ms ease;
}
.ui-agtc__sum-btn[data-kind="waiting"] {
  background: var(--ui-agtc-warn-bg);
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__sum-btn[data-kind="failed"] {
  background: var(--ui-agtc-danger-bg);
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__sum-btn:hover {
  filter: saturate(1.3) brightness(0.97);
}
.ui-agtc__sum-btn > svg {
  transition: transform 220ms var(--ui-agtc-ease);
}
.ui-agtc__sum-btn[aria-expanded="true"] > svg {
  transform: rotate(180deg);
}
.ui-agtc__pop {
  max-height: min(440px, 70vh);
  overflow-y: auto;
  overscroll-behavior: contain;
  position: absolute;
  top: calc(100% + 8px);
  right: 0;
  z-index: 5;
  display: grid;
  gap: 4px;
  width: 300px;
  max-width: 100%;
  padding: 6px;
  border-radius: 10px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-pop);
  animation: ui-agtc-pop 200ms var(--ui-agtc-ease) both;
}
.ui-agtc__pop-item {
  min-width: 0;
  display: grid;
  gap: 4px;
  padding: 8px 8px 8px;
  border-radius: 7px;
}
.ui-agtc__pop-item + .ui-agtc__pop-item {
  border-top: 0.5px solid var(--ui-agtc-line);
  border-radius: 0 0 7px 7px;
}
.ui-agtc__pop-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agtc__pop-head .ui-agtc__status {
  width: 20px;
  padding: 0;
  justify-content: center;
}
.ui-agtc__pop-name {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-weight: 500;
  color: var(--ui-agtc-strong);
}
.ui-agtc__pop-task {
  flex: 1 1 0;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-agtc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__pop-text {
  overflow-wrap: anywhere;
  padding-left: 28px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-text);
}
.ui-agtc__pop-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 4px;
}
.ui-agtc__btn {
  display: inline-flex;
  align-items: center;
  height: 28px;
  padding: 0 10px;
  border-radius: 6px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-agtc-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-agtc__btn:hover {
  background: var(--ui-agtc-fill);
}
.ui-agtc__btn--primary {
  background: var(--ui-agtc-solid);
  box-shadow: none;
  color: var(--ui-agtc-on-solid);
}
.ui-agtc__btn--primary:hover {
  background: var(--ui-agtc-solid);
  opacity: 0.88;
}
.ui-agtc__tree {
  position: relative;
  display: grid;
  justify-items: center;
}
.ui-agtc__links {
  position: absolute;
  top: 0;
  left: 0;
  overflow: visible;
  pointer-events: none;
}
.ui-agtc__link {
  fill: none;
  stroke: var(--ui-agtc-link);
  stroke-width: 1.5;
  stroke-linecap: round;
  transition: stroke 240ms ease;
}
.ui-agtc__links [data-muted] .ui-agtc__link {
  stroke: var(--ui-agtc-link-muted);
}
.ui-agtc__links [data-fresh] .ui-agtc__link {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 1;
  animation: ui-agtc-draw 420ms var(--ui-agtc-ease) both;
}
.ui-agtc__dots {
  z-index: 2;
}
.ui-agtc__dot {
  fill: var(--ui-agtc-card);
  stroke: var(--ui-agtc-link);
  stroke-width: 1.5;
  transition: stroke 240ms ease;
}
.ui-agtc__dot[data-muted] {
  stroke: var(--ui-agtc-link-muted);
}
.ui-agtc__root {
  position: relative;
  z-index: 1;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside] {
  display: grid;
  grid-template-columns: minmax(0, 1fr) var(--ui-agtc-card-w) minmax(0, 1fr);
  align-items: start;
  width: 100%;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside] > :first-child {
  grid-column: 2;
}
.ui-agtc[data-wide] .ui-agtc__root[data-beside]:has(+ .ui-agtc__level) {
  margin-right: 0;
  padding-right: var(--ui-agtc-indent);
}
.ui-agtc__beside {
  width: var(--ui-agtc-card-w);
}
.ui-agtc[data-wide] .ui-agtc__beside {
  grid-column: 3;
  justify-self: start;
  margin-left: 56px;
}
.ui-agtc:not([data-wide]) .ui-agtc__beside {
  width: auto;
  margin: 12px 0 0 var(--ui-agtc-step);
}
.ui-agtc__links [data-dashed] .ui-agtc__link {
  stroke-dasharray: 3 4;
  stroke-dashoffset: 0;
  animation: none;
}
.ui-agtc__level {
  position: relative;
  z-index: 1;
  display: flex;
  align-items: flex-start;
  justify-content: center;
  gap: 8px;
  width: 100%;
  margin-top: 40px;
}
.ui-agtc__level > .ui-agtc__hang {
  flex: none;
  width: calc(
    var(--ui-agtc-card-w) + var(--ui-agtc-indent) * var(--ui-agtc-col, 1)
  );
}
.ui-agtc[data-wide] .ui-agtc__root:has(+ .ui-agtc__level) {
  margin-right: var(--ui-agtc-indent);
}
.ui-agtc__hang {
  display: grid;
  align-content: start;
  gap: 12px;
}
.ui-agtc__below {
  display: grid;
  gap: 12px;
  padding-left: var(--ui-agtc-indent);
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  justify-items: stretch;
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  container-type: inline-size;
}
.ui-agtc__node {
  width: var(--ui-agtc-card-w);
}
.ui-agtc:not([data-wide]) .ui-agtc__tree {
  --ui-agtc-step: min(
    var(--ui-agtc-indent),
    max(12px, (100cqw - 180px) / max(1, var(--ui-agtc-depth, 1)))
  );
}
.ui-agtc:not([data-wide]) .ui-agtc__node {
  width: calc(100cqw - var(--ui-agtc-depth, 0) * var(--ui-agtc-step));
}
.ui-agtc:not([data-wide]) .ui-agtc__below {
  padding-left: var(--ui-agtc-step);
}
.ui-agtc:not([data-wide]) .ui-agtc__level {
  display: grid;
  gap: 12px;
  margin-top: 12px;
  padding-left: var(--ui-agtc-step);
}
.ui-agtc:not([data-wide]) .ui-agtc__level {
  justify-content: stretch;
}
.ui-agtc:not([data-wide]) .ui-agtc__level > .ui-agtc__hang {
  width: auto;
}
.ui-agtc__node {
  position: relative;
  display: grid;
  gap: 6px;
  padding: 10px 10px 8px;
  border-radius: 8px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  animation: ui-agtc-rise 360ms var(--ui-agtc-ease) both;
  transition:
    box-shadow 200ms ease,
    opacity 240ms ease;
}
.ui-agtc__node[data-leaving] {
  animation: ui-agtc-leave 280ms var(--ui-agtc-ease) forwards;
  pointer-events: none;
}
.ui-agtc__links [data-leaving] .ui-agtc__link {
  stroke-dasharray: 1 1;
  stroke-dashoffset: 0;
  animation: ui-agtc-retract 280ms var(--ui-agtc-ease) forwards;
}
.ui-agtc__dot[data-leaving] {
  animation: ui-agtc-fade 280ms ease forwards;
}
.ui-agtc__node[data-clickable] {
  cursor: pointer;
}
.ui-agtc__lead {
  min-width: 0;
  margin-bottom: 24px;
}
.ui-agtc__extra {
  min-width: 0;
  margin-top: -6px;
}
.ui-agtc__extra-in {
  padding-top: 6px;
}
.ui-agtc[data-picking] .ui-agtc__node:not([data-kept]) {
  opacity: 0.4;
}
.ui-agtc__node:focus-visible {
  outline: 2px solid var(--ui-agtc-focus);
  outline-offset: 2px;
}
.ui-agtc__node[data-clickable]:hover {
  box-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.1),
    0 2px 6px -2px rgba(0, 0, 0, 0.12);
}
.ui-agtc__node[data-status="queued"],
.ui-agtc__node[data-status="stopped"] {
  opacity: 0.6;
}
.ui-agtc__top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agtc__avatar {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
  font-size: 10px;
  font-weight: 500;
  color: var(--ui-agtc-text);
}
.ui-agtc__avatar[data-logo] > svg {
  width: 13px;
  height: 13px;
}
.ui-agtc__who {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-agtc__name {
  overflow: hidden;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__tools {
  display: inline-flex;
  margin-right: 6px;
  vertical-align: top;
}
.ui-agtc__tool {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-agtc-card);
  box-shadow: var(--ui-agtc-shadow);
}
.ui-agtc__tool + .ui-agtc__tool {
  margin-left: -4px;
}
.ui-agtc__tool > svg {
  width: 10px;
  height: 10px;
}
.ui-agtc__tool--more {
  width: auto;
  min-width: 16px;
  padding: 0 3px;
  font-size: 9px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
}
.ui-agtc__model {
  overflow: hidden;
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-agtc-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agtc__status {
  display: inline-flex;
  flex: none;
  align-self: start;
  align-items: center;
  gap: 4px;
  height: 18px;
  padding: 0 6px 0 4px;
  border-radius: 4px;
  background: var(--ui-agtc-fill);
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-text);
  white-space: nowrap;
}
.ui-agtc__status[data-status="running"] {
  background: var(--ui-agtc-brand-bg);
  color: var(--ui-agtc-brand-fg);
}
.ui-agtc__spin {
  animation: ui-agtc-spin 900ms linear infinite;
}
.ui-agtc__status[data-status="waiting"] {
  background: var(--ui-agtc-warn-bg);
  color: var(--ui-agtc-warn-fg);
}
.ui-agtc__status[data-status="done"] {
  background: var(--ui-agtc-ok-bg);
  color: var(--ui-agtc-ok-fg);
}
.ui-agtc__status[data-status="failed"] {
  background: var(--ui-agtc-danger-bg);
  color: var(--ui-agtc-danger-fg);
}
.ui-agtc__task {
  text-align: start;
  overflow-wrap: anywhere;
  display: -webkit-box;
  overflow: hidden;
  margin: -2px -2px -3px !important;
  padding: 2px 2px 3px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agtc-text);
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}
.ui-agtc__meta {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 20px;
}
.ui-agtc__cost {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 11px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-agtc-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
}
.ui-agtc__amount[data-live] {
  background: linear-gradient(
      90deg,
      currentColor 0%,
      currentColor 38%,
      var(--ui-agtc-shine) 50%,
      currentColor 62%,
      currentColor 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  -webkit-text-fill-color: transparent;
  animation: ui-agtc-shine 1100ms linear infinite;
}
.ui-agtc__time {
  font-weight: 400;
  color: var(--ui-agtc-muted);
}
.ui-agtc__fold {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 2px;
  height: 20px;
  padding: 0 4px 0 6px;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-agtc-muted);
  font-variant-numeric: tabular-nums;
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-agtc__fold:hover {
  background: var(--ui-agtc-fill);
  color: var(--ui-agtc-ink);
}
.ui-agtc__fold > svg {
  transition: transform 220ms var(--ui-agtc-ease);
}
.ui-agtc__fold[aria-expanded="false"] > svg {
  transform: rotate(-90deg);
}
@keyframes ui-agtc-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-agtc-draw {
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-agtc-retract {
  to {
    stroke-dashoffset: 1;
  }
}
@keyframes ui-agtc-leave {
  to {
    opacity: 0;
    transform: translateY(4px) scale(0.97);
  }
}
@keyframes ui-agtc-fade {
  to {
    opacity: 0;
  }
}
@keyframes ui-agtc-rise {
  from {
    opacity: 0;
    transform: translateY(6px) scale(0.98);
  }
}
@keyframes ui-agtc-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-agtc-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@media (pointer: coarse) {
  .ui-agtc__fold {
    height: 32px;
    padding: 0 8px 0 10px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-agtc *,
  .ui-agtc *::before,
  .ui-agtc *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-agtc {
  --ui-agtc-shine: rgba(255, 255, 255, 0.35);
  --ui-agtc-card: #1c1c1f;
  --ui-agtc-strong: #ffffff;
  --ui-agtc-ink: rgba(255, 255, 255, 0.9);
  --ui-agtc-text: rgba(255, 255, 255, 0.62);
  --ui-agtc-muted: rgba(255, 255, 255, 0.45);
  --ui-agtc-faint: rgba(255, 255, 255, 0.28);
  --ui-agtc-line: rgba(255, 255, 255, 0.08);
  --ui-agtc-fill: rgba(255, 255, 255, 0.08);
  --ui-agtc-accent: #5b9aff;
  --ui-agtc-link: #4f8fdb;
  --ui-agtc-link-muted: rgba(255, 255, 255, 0.14);
  --ui-agtc-brand-bg: #0077ff3a;
  --ui-agtc-brand-fg: #70b8ff;
  --ui-agtc-ok-bg: #00f04a1f;
  --ui-agtc-ok-fg: #3dd68c;
  --ui-agtc-warn-bg: #fb6a0025;
  --ui-agtc-warn-fg: #ffa057;
  --ui-agtc-danger-bg: #ff35232b;
  --ui-agtc-danger-fg: #ff977d;
  --ui-agtc-focus: rgba(77, 141, 255, 0.8);
  --ui-agtc-solid: rgba(255, 255, 255, 0.92);
  --ui-agtc-on-solid: #141416;
  --ui-agtc-pop:
    0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 28px -10px rgba(0, 0, 0, 0.6);
  --ui-agtc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`;function o(a){return t.jsx(i,{...a,styles:e,clean:!0})}export{o as A};
