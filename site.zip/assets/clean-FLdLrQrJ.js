import{j as i}from"./workbench-model-BwgilGut.js";import{u as B}from"./use-setup-guide-BvnvwkZD.js";const $=()=>i.jsx("svg",{className:"ui-sgdc__chevron",viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.3",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:i.jsx("path",{d:"m4.5 6.25 3.5 3.5 3.5-3.5"})}),S=()=>i.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:i.jsx("path",{d:"M9.5 2.5v4h4M9.5 6.5l4.5-4.5M6.5 13.5v-4h-4M6.5 9.5 2 14"})}),W=()=>i.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:i.jsx("path",{d:"M10 2h4v4M14 2 9.5 6.5M6 14H2v-4M2 14l4.5-4.5"})}),G=()=>i.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.2",strokeLinecap:"round","aria-hidden":"true",children:i.jsx("path",{d:"m4 4 8 8M12 4l-8 8"})}),E=()=>i.jsxs("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:[i.jsx("circle",{cx:"8",cy:"8",r:"7",fill:"currentColor"}),i.jsx("path",{d:"m5.2 8.2 1.9 1.9 3.7-3.9",fill:"none",stroke:"var(--ui-sgdc-on-accent)",strokeWidth:"1.4",strokeLinecap:"round",strokeLinejoin:"round"})]}),F=()=>i.jsx("svg",{viewBox:"0 0 16 16",fill:"none",stroke:"currentColor",strokeWidth:"1.1","aria-hidden":"true",children:i.jsx("circle",{cx:"8",cy:"8",r:"6.5",strokeDasharray:"2 2"})}),X=`
.ui-sgdc {
  --ui-sgdc-card: #ffffff;
  --ui-sgdc-strong: #000000;
  --ui-sgdc-ink: rgba(0, 0, 0, 0.88);
  --ui-sgdc-text: rgba(0, 0, 0, 0.65);
  --ui-sgdc-muted: rgba(0, 0, 0, 0.65);
  --ui-sgdc-faint: rgba(0, 0, 0, 0.65);
  --ui-sgdc-icon: rgba(0, 0, 0, 0.65);
  --ui-sgdc-line: rgba(0, 0, 0, 0.06);
  --ui-sgdc-fill: rgba(0, 0, 0, 0.06);
  --ui-sgdc-ring: rgba(0, 0, 0, 0.2);
  --ui-sgdc-wash: rgba(0, 0, 0, 0.03);
  --ui-sgdc-open: rgba(0, 0, 0, 0.025);
  --ui-sgdc-accent: #0060e2;
  --ui-sgdc-on-accent: #ffffff;
  --ui-sgdc-focus: rgba(0, 96, 226, 0.7);
  --ui-sgdc-shadow:
    0 0 0 0.5px rgba(0, 0, 0, 0.06), 0 1px 1px -1px rgba(0, 0, 0, 0.1),
    0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-sgdc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  container-type: inline-size;
  width: 100%;
  max-width: 320px;
  border-radius: 10px;
  background: var(--ui-sgdc-card);
  box-shadow: var(--ui-sgdc-shadow);
  font-family:
    "Inter",
    "InterVariable",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-sgdc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-sgdc *,
.ui-sgdc *::before,
.ui-sgdc *::after {
  box-sizing: border-box;
}
:where(.ui-sgdc) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-sgdc) svg {
  display: block;
  flex: none;
}
.ui-sgdc button:focus-visible {
  outline: 2px solid var(--ui-sgdc-focus);
  outline-offset: 2px;
}
.ui-sgdc__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 12px 10px 0 16px;
}
.ui-sgdc__title {
  overflow: hidden;
  min-width: 0;
  margin: 0;
  font-size: 15px;
  font-weight: 500;
  line-height: 24px;
  color: var(--ui-sgdc-strong);
  text-align: start;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-sgdc__actions {
  display: flex;
  flex: none;
  align-items: center;
  gap: 2px;
}
.ui-sgdc__edit {
  height: 28px;
  padding: 0 8px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-sgdc-text);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-sgdc__edit:hover {
  background: var(--ui-sgdc-wash);
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  color: var(--ui-sgdc-icon);
  transition:
    background-color 100ms ease,
    color 100ms ease;
}
.ui-sgdc__icon-btn:hover {
  background: var(--ui-sgdc-wash);
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__icon-btn svg {
  width: 16px;
  height: 16px;
}
.ui-sgdc__progress {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 16px 12px;
}
.ui-sgdc__track {
  display: block;
  flex: 1;
  height: 4px;
  overflow: hidden;
  border-radius: 2px;
  background: var(--ui-sgdc-fill);
}
.ui-sgdc__fill {
  display: block;
  height: 100%;
  border-radius: inherit;
  background: var(--ui-sgdc-accent);
  transform-origin: left center;
  transition: transform 700ms var(--ui-sgdc-ease);
}
.ui-sgdc__count {
  flex: none;
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__body {
  display: grid;
  grid-template-rows: 1fr;
  transition:
    grid-template-rows 420ms var(--ui-sgdc-ease),
    opacity 260ms ease;
}
.ui-sgdc__body[data-hidden] {
  grid-template-rows: 0fr;
  opacity: 0;
}
.ui-sgdc__groups {
  display: grid;
  gap: 2px;
  min-height: 0;
  overflow: hidden;
  padding: 0 4px;
  border-top: 0.5px solid var(--ui-sgdc-line);
}
.ui-sgdc__groups::before,
.ui-sgdc__groups::after {
  content: "";
  display: block;
  height: 2px;
}
.ui-sgdc__group {
  border-radius: 8px;
  transition: background-color 200ms ease;
}
.ui-sgdc__group[data-open] {
  background: var(--ui-sgdc-open);
}
.ui-sgdc__group-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  padding: 8px 8px 8px 12px;
  border-radius: 8px;
  text-align: left;
  transition: background-color 100ms ease;
}
.ui-sgdc__group-head:hover {
  background: var(--ui-sgdc-wash);
}
.ui-sgdc__group[data-open] .ui-sgdc__group-head:hover {
  background: none;
}
.ui-sgdc__group-title {
  position: relative;
  min-width: 0;
  font-size: 13px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-sgdc-strong);
  text-align: start;
  overflow-wrap: anywhere;
  transition: color 300ms ease;
}
.ui-sgdc__group-title[data-done] {
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__group-title::after {
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  top: 52%;
  height: 1px;
  background: currentColor;
  transform: scaleX(0);
  transform-origin: left center;
  transition: transform 420ms var(--ui-sgdc-ease);
}
.ui-sgdc__group-title[data-done]::after {
  transform: scaleX(1);
}
.ui-sgdc__chevron {
  width: 16px;
  height: 16px;
  margin-top: 2px;
  color: var(--ui-sgdc-icon);
  transition: transform 320ms var(--ui-sgdc-ease);
}
.ui-sgdc__group[data-open] .ui-sgdc__chevron {
  transform: rotate(180deg);
}
.ui-sgdc__panel {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 380ms var(--ui-sgdc-ease);
}
.ui-sgdc__group[data-open] .ui-sgdc__panel {
  grid-template-rows: 1fr;
}
.ui-sgdc__tasks {
  min-height: 0;
  overflow: hidden;
  margin: 0;
  padding: 0 4px;
  list-style: none;
}
.ui-sgdc__tasks li:last-child {
  padding-bottom: 6px;
}
.ui-sgdc__task {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  width: 100%;
  padding: 6px 8px;
  border-radius: 6px;
  text-align: left;
  opacity: 0;
  transform: translateY(-4px);
  transition:
    opacity 260ms ease,
    transform 320ms var(--ui-sgdc-ease),
    color 260ms ease,
    background-color 100ms ease;
}
.ui-sgdc__group[data-open] .ui-sgdc__task {
  opacity: 1;
  transform: none;
  transition-delay: 80ms, 80ms, 0ms, 0ms;
}
.ui-sgdc__task:not(:disabled):hover {
  background: var(--ui-sgdc-wash);
}
.ui-sgdc__task[data-state="current"] {
  color: var(--ui-sgdc-ink);
}
.ui-sgdc__task[data-state="locked"] {
  color: var(--ui-sgdc-muted);
  cursor: default;
}
.ui-sgdc__task[data-state="done"] {
  color: var(--ui-sgdc-muted);
}
.ui-sgdc__mark {
  display: grid;
  place-items: center;
  flex: none;
  width: 16px;
  height: 16px;
  margin-top: 2px;
  border-radius: 50%;
  transition: box-shadow 160ms ease;
}
.ui-sgdc__task[data-state="current"] .ui-sgdc__mark {
  box-shadow: inset 0 0 0 1px var(--ui-sgdc-ring);
}
.ui-sgdc__task[data-state="current"]:hover .ui-sgdc__mark {
  box-shadow: inset 0 0 0 1px var(--ui-sgdc-accent);
}
.ui-sgdc__task[data-state="locked"] .ui-sgdc__mark {
  color: var(--ui-sgdc-faint);
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__mark {
  color: var(--ui-sgdc-accent);
}
.ui-sgdc__mark svg {
  width: 16px;
  height: 16px;
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__mark svg {
  animation: ui-sgdc-pop 420ms var(--ui-sgdc-ease);
}
.ui-sgdc__task-label {
  min-width: 0;
  font-size: 13px;
  line-height: 20px;
  text-align: start;
  white-space: pre-line;
  overflow-wrap: anywhere;
  text-decoration-line: line-through;
  text-decoration-color: transparent;
  text-decoration-thickness: 1px;
  transition: text-decoration-color 260ms ease;
}
.ui-sgdc__task[data-state="done"] .ui-sgdc__task-label {
  text-decoration-color: currentColor;
}
@keyframes ui-sgdc-pop {
  from {
    transform: scale(0.5);
    opacity: 0;
  }
}
@container (max-width: 300px) {
  .ui-sgdc__head {
    padding-left: 12px;
  }
  .ui-sgdc__progress {
    padding-inline: 12px;
  }
  .ui-sgdc__group-head {
    padding-left: 10px;
  }
}
@media (pointer: coarse) {
  .ui-sgdc__icon-btn {
    width: 36px;
    height: 36px;
  }
  .ui-sgdc__edit {
    height: 36px;
  }
  .ui-sgdc__group-head {
    padding-block: 12px;
  }
  .ui-sgdc__task {
    padding-block: 9px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-sgdc__fill,
  .ui-sgdc__body,
  .ui-sgdc__panel,
  .ui-sgdc__task,
  .ui-sgdc__chevron,
  .ui-sgdc__group,
  .ui-sgdc__group-title::after {
    transition: none;
  }
  .ui-sgdc__mark svg {
    animation: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-sgdc {
  --ui-sgdc-card: #1c1c1e;
  --ui-sgdc-strong: #ffffff;
  --ui-sgdc-ink: rgba(255, 255, 255, 0.9);
  --ui-sgdc-text: rgba(255, 255, 255, 0.62);
  --ui-sgdc-muted: rgba(255, 255, 255, 0.46);
  --ui-sgdc-faint: rgba(255, 255, 255, 0.3);
  --ui-sgdc-icon: rgba(255, 255, 255, 0.5);
  --ui-sgdc-line: rgba(255, 255, 255, 0.08);
  --ui-sgdc-fill: rgba(255, 255, 255, 0.08);
  --ui-sgdc-ring: rgba(255, 255, 255, 0.26);
  --ui-sgdc-wash: rgba(255, 255, 255, 0.04);
  --ui-sgdc-open: rgba(255, 255, 255, 0.03);
  --ui-sgdc-accent: #4d8dff;
  --ui-sgdc-on-accent: #ffffff;
  --ui-sgdc-focus: rgba(77, 141, 255, 0.8);
  --ui-sgdc-shadow:
    0 0 0 0.5px rgba(255, 255, 255, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
}
`,h=new Intl.NumberFormat("en");function R({title:a="Setup guide",groups:m,onEdit:c,onClose:g,onChange:f,className:b}){const{guideGroups:k,completedIds:o,openGroupId:v,setOpenGroupId:w,minimized:r,setMinimized:j,taskCount:y,completedCount:N,progress:u,toggleTask:C}=B({groups:m,onChange:f});return i.jsxs(i.Fragment,{children:[i.jsx("style",{href:"ui-setup-guide-clean",precedence:"default",children:X}),i.jsxs("section",{className:["ui-sgdc",b].filter(Boolean).join(" "),"aria-label":a,children:[i.jsxs("header",{className:"ui-sgdc__head",children:[i.jsx("h3",{className:"ui-sgdc__title",title:a,dir:"auto",children:a}),i.jsxs("div",{className:"ui-sgdc__actions",children:[c&&i.jsx("button",{type:"button",className:"ui-sgdc__edit",onClick:c,children:"Edit"}),i.jsx("button",{type:"button",className:"ui-sgdc__icon-btn","aria-label":r?"Expand setup guide":"Minimize setup guide","aria-expanded":!r,onClick:()=>j(s=>!s),children:r?i.jsx(W,{}):i.jsx(S,{})}),g&&i.jsx("button",{type:"button",className:"ui-sgdc__icon-btn","aria-label":"Close setup guide",onClick:g,children:i.jsx(G,{})})]})]}),i.jsxs("div",{className:"ui-sgdc__progress",children:[i.jsx("span",{className:"ui-sgdc__track",role:"progressbar","aria-label":`${a} progress`,"aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":Math.round(u*100),children:i.jsx("span",{className:"ui-sgdc__fill",style:{transform:`scaleX(${u})`}})}),i.jsxs("span",{className:"ui-sgdc__count","aria-hidden":"true",children:[h.format(N),"/",h.format(y)]})]}),i.jsx("div",{className:"ui-sgdc__body","data-hidden":r||void 0,children:i.jsx("div",{className:"ui-sgdc__groups",children:k.map((s,I)=>{var _;const t=v===s.id,z=s.tasks.every(e=>o.has(e.id)),M=(_=s.tasks.find(e=>!o.has(e.id)))==null?void 0:_.id,l=s.tasks.findIndex(e=>e.id===M),p=`ui-sgdc-${s.id}`;return i.jsxs("div",{className:"ui-sgdc__group","data-open":t||void 0,children:[i.jsxs("button",{type:"button",className:"ui-sgdc__group-head","aria-expanded":t,"aria-controls":p,onClick:()=>w(t?null:s.id),children:[i.jsx("span",{className:"ui-sgdc__group-title","data-done":z||void 0,dir:"auto",children:s.title}),i.jsx($,{})]}),i.jsx("div",{className:"ui-sgdc__panel",id:p,inert:!t,children:i.jsx("ul",{className:"ui-sgdc__tasks",children:s.tasks.map((e,x)=>{const d=o.has(e.id),n=!d&&l!==-1&&x>l,L=d?"done":n?"locked":"current";return i.jsx("li",{children:i.jsxs("button",{type:"button",className:"ui-sgdc__task","data-state":L,disabled:n,"aria-pressed":d,onClick:()=>C(s,e.id),children:[i.jsx("span",{className:"ui-sgdc__mark","aria-hidden":"true",children:d?i.jsx(E,{}):n?i.jsx(F,{}):null}),i.jsx("span",{className:"ui-sgdc__task-label",dir:"auto",children:e.label})]})},`${x}-${e.id}`)})})})]},`${I}-${s.id}`)})})})]})]})}export{R as S};
