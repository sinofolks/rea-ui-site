import{j as a}from"./workbench-model-BwgilGut.js";import{t as W}from"./react-BkAXpnfr-Clok0bvh.js";import{t as A}from"./jsx-runtime-CTsRTJUX-CoXrQeBV.js";var n=W(),D=A();function G({variant:i="primary",size:e="md",loading:o=!1,icon:u,iconRight:s,children:c,className:C,disabled:N,onClick:l,onPointerEnter:p,type:S="button",ref:b,...m}){let d=typeof c=="string"?c:void 0,x=c!=null&&c!==!1&&c!=="",h=!x&&!!(u||s),E=H.includes(i)?i:"primary",T=R.includes(e)?e:"md",y=(0,n.useRef)(null),w=(0,n.useRef)(0),[B,I]=(0,n.useState)(!1);(0,n.useEffect)(()=>I(!0),[]);let _=d??"label",k=o&&u?"spinner":M(u),j=M(s),f=`${_}|${k}|${j}`,z=(0,n.useRef)(f);return(0,n.useLayoutEffect)(()=>{let t=y.current;if(!t)return;let r=t.getBoundingClientRect().width,g=w.current,L=z.current!==f;w.current=r,z.current=f,!(!L||!g||Math.abs(g-r)<.5)&&(window.matchMedia("(prefers-reduced-motion: reduce)").matches||t.animate([{width:`${g}px`},{width:`${r}px`}],{duration:480,easing:"cubic-bezier(0.25, 1, 0.5, 1)"}))}),a.jsxs(D.Fragment,{children:[a.jsx("style",{href:"ui-button-clean",precedence:"default",children:F}),a.jsxs("button",{type:S,className:["ui-buttonc",C].filter(Boolean).join(" "),"data-variant":E,"data-size":T,"data-loading":o||void 0,"data-icon-only":h||void 0,"data-icon-left":!h&&!!u||void 0,"data-icon-right":!h&&!!s||void 0,"data-ready":B||void 0,ref:(t=>{y.current=t,typeof b=="function"?b(t):b&&(b.current=t)}),disabled:N,"aria-busy":o||void 0,"aria-disabled":o||void 0,onClick:t=>{if(o){t.preventDefault();return}l==null||l(t)},onPointerEnter:t=>{let r=t.currentTarget.querySelector(".ui-buttonc__label");r&&d&&!m.title&&(r.title=r.scrollWidth>r.clientWidth+1?d:""),p==null||p(t)},...m,children:[u&&a.jsx("span",{className:"ui-buttonc__icon","aria-hidden":"true",onErrorCapture:$,children:o?a.jsx(V,{}):u},`icon-${k}`),x&&a.jsx("span",{className:"ui-buttonc__label","data-text":d,dir:"auto",children:c},`label-${_}`),s&&a.jsx("span",{className:"ui-buttonc__icon","aria-hidden":"true",onErrorCapture:$,children:s},`icon-right-${j}`)]})]})}var H=["primary","secondary","ghost","destructive"],R=["sm","md","lg"],$=i=>{i.target instanceof HTMLImageElement&&(i.target.style.visibility="hidden")},V=()=>a.jsxs("svg",{className:"ui-buttonc__spinner",viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",children:[a.jsx("circle",{cx:"12",cy:"12",r:"8.5",opacity:.2}),a.jsx("path",{d:"M12 3.5a8.5 8.5 0 0 1 8.5 8.5"})]}),v=new WeakMap,q=1;function M(i){if(!(0,n.isValidElement)(i)||typeof i.type=="string")return 0;let e=i.type;return v.has(e)||v.set(e,q++),v.get(e)}var F=`
/* Colors and motion as variables – override them on .ui-buttonc (see Theming in the docs) */
.ui-buttonc {
  --ui-btnc-title: var(--aui-ink, #000);
  --ui-btnc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-btnc-muted: var(--aui-muted, rgba(0, 0, 0, 0.61));
  --ui-btnc-icon: var(--aui-muted, rgba(0, 0, 0, 0.447));
  --ui-btnc-solid: var(--aui-primary, rgba(0, 0, 0, 0.88));
  --ui-btnc-solid-hover: rgba(0, 0, 0, 0.8);
  --ui-btnc-on-solid: var(--aui-on-primary, #fcfcfc);
  --ui-btnc-surface: var(--aui-surface, #ffffff);
  --ui-btnc-shadow: 0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.06)), 0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-btnc-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.1)), 0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 3px 0 rgba(0, 0, 0, 0.07);
  --ui-btnc-wash: rgba(0, 0, 0, 0.03);
  --ui-btnc-danger: var(--aui-danger, #c4320a);
  --ui-btnc-danger-bg: rgba(240, 68, 56, 0.08);
  --ui-btnc-danger-bg-hover: rgba(240, 68, 56, 0.12);
  --ui-btnc-shine: rgba(255, 255, 255, 0.82);
  --ui-btnc-shine-on-solid: #ffffff;
  --ui-btnc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-btnc-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-btnc-load: 650ms;

  --h: 28px;
  --px: 10px;
  --gap: 6px;
  --fs: 13px;
  --lh: 20px;
  --icon: 16px;
  --radius: var(--aui-radius, 6px);

  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--gap);
  box-sizing: border-box;
  height: var(--h);
  padding: 0 var(--px);
  margin: 0;
  border: 0;
  border-radius: var(--radius);
  font-family: var(--aui-font, "Inter", "InterVariable", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif);
  font-size: var(--fs);
  font-weight: 500;
  line-height: var(--lh);
  letter-spacing: 0;
  max-width: 100%;
  min-width: 0;
  white-space: nowrap;
  text-decoration: none;
  cursor: pointer;
  user-select: none;
  -webkit-tap-highlight-color: transparent;
  -webkit-font-smoothing: antialiased;
  transition:
    background-color 140ms ease,
    color 140ms ease,
    box-shadow 140ms ease,
    transform 160ms var(--ui-btnc-ease),
    opacity 140ms ease;
}

/* Sizes: 24 · 28 · 32 high (taller on touch screens, see below) */
.ui-buttonc[data-size="sm"] {
  --h: 24px;
  --px: 8px;
  --gap: 4px;
  --fs: 12px;
  --lh: 16px;
  --icon: 14px;
  --radius: var(--aui-radius, 6px);
}
.ui-buttonc[data-size="lg"] {
  --h: 32px;
  --px: 12px;
  --gap: 6px;
  --fs: 13px;
  --icon: 16px;
  --radius: var(--aui-radius, 6px);
}
/* Touch screens: every size grows to a comfortable tap height – 32 · 34 · 36 – the look stays the same */
@media (pointer: coarse) {
  .ui-buttonc[data-size="sm"] { --h: 32px; }
  .ui-buttonc[data-size="md"] { --h: 34px; }
  .ui-buttonc[data-size="lg"] { --h: 36px; }
}
/* An icon sits closer to the edge than the text, so both look evenly spaced */
.ui-buttonc[data-icon-left] {
  padding-left: calc(var(--px) - 2px);
}
.ui-buttonc[data-icon-right] {
  padding-right: calc(var(--px) - 2px);
}
.ui-buttonc[data-icon-only] {
  width: var(--h);
  padding: 0;
}

/* primary: a dark chip */
.ui-buttonc[data-variant="primary"] {
  background: var(--ui-btnc-solid);
  color: var(--ui-btnc-on-solid);
}
.ui-buttonc[data-variant="primary"]:hover:not(:disabled) {
  background: var(--ui-btnc-solid-hover);
}

/* secondary: white with the card's hairline shadow */
.ui-buttonc[data-variant="secondary"] {
  background: var(--ui-btnc-surface);
  color: var(--ui-btnc-title);
  box-shadow: var(--ui-btnc-shadow);
}
.ui-buttonc[data-variant="secondary"] .ui-buttonc__icon {
  color: var(--ui-btnc-icon);
}
.ui-buttonc[data-variant="secondary"]:hover:not(:disabled) {
  box-shadow: var(--ui-btnc-shadow-hover);
}

/* ghost: a muted label, a soft wash appears on hover */
.ui-buttonc[data-variant="ghost"] {
  background: transparent;
  color: var(--ui-btnc-muted);
}
.ui-buttonc[data-variant="ghost"] .ui-buttonc__icon {
  color: var(--ui-btnc-icon);
}
.ui-buttonc[data-variant="ghost"]:hover:not(:disabled) {
  background: var(--ui-btnc-wash);
  color: var(--ui-btnc-ink);
}
.ui-buttonc[data-variant="ghost"]:hover:not(:disabled) .ui-buttonc__icon {
  color: var(--ui-btnc-ink);
}

/* destructive: red label on a minimal red fill, no stroke */
.ui-buttonc[data-variant="destructive"] {
  background: var(--ui-btnc-danger-bg);
  color: var(--ui-btnc-danger);
}
.ui-buttonc[data-variant="destructive"]:hover:not(:disabled) {
  background: var(--ui-btnc-danger-bg-hover);
}

.ui-buttonc .ui-buttonc__icon {
  transition: color 140ms ease;
}
.ui-buttonc:active:not(:disabled):not([data-loading]) {
  transform: scale(0.97);
}
.ui-buttonc:focus-visible {
  outline: 2px solid var(--ui-btnc-focus);
  outline-offset: 2px;
}
.ui-buttonc:disabled {
  opacity: 0.4;
  cursor: default;
}
.ui-buttonc[data-loading] {
  cursor: default;
}

.ui-buttonc__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: var(--icon);
  height: var(--icon);
}
.ui-buttonc__icon {
  overflow: hidden;
}
.ui-buttonc__icon > svg,
.ui-buttonc__icon > img {
  display: block;
  width: 100%;
  height: 100%;
}
.ui-buttonc__icon > img {
  object-fit: contain;
}

/* Morph: the button clips while its width glides; changed parts blur in */
.ui-buttonc {
  overflow: clip;
}
.ui-buttonc[data-ready] .ui-buttonc__label {
  animation: ui-buttonc-label-in 480ms cubic-bezier(0.25, 1, 0.5, 1) both;
}
.ui-buttonc[data-ready] .ui-buttonc__icon {
  animation: ui-buttonc-icon-in 520ms cubic-bezier(0.25, 1, 0.5, 1) both;
}

/* Loading: a light band sweeps across a copy of the dimmed label */
/* A label too long for its parent ends in "…" – the full text shows on hover */
.ui-buttonc__label {
  position: relative;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-buttonc__label::after {
  content: attr(data-text);
  content: attr(data-text) / "";
  position: absolute;
  inset: 0;
  white-space: nowrap;
  color: transparent;
  background: linear-gradient(90deg, transparent 38%, var(--ui-btnc-shine) 50%, transparent 62%) 100% 0 / 300% 100%
    no-repeat;
  -webkit-background-clip: text;
  background-clip: text;
  opacity: 0;
  pointer-events: none;
}
.ui-buttonc[data-variant="primary"] .ui-buttonc__label::after {
  --ui-btnc-shine: var(--ui-btnc-shine-on-solid);
}
.ui-buttonc[data-loading] .ui-buttonc__label {
  color: color-mix(in srgb, currentColor 50%, transparent);
}
.ui-buttonc[data-loading] .ui-buttonc__label::after {
  opacity: 1;
  animation: ui-buttonc-sweep calc(var(--ui-btnc-load) * 1.6) linear infinite;
}
.ui-buttonc__spinner {
  animation: ui-buttonc-spin 900ms linear infinite;
}

@keyframes ui-buttonc-label-in {
  from {
    opacity: 0;
    filter: blur(3px);
    transform: translateY(25%);
  }
}
@keyframes ui-buttonc-icon-in {
  from {
    opacity: 0;
    filter: blur(2px);
    transform: scale(0.7);
  }
}

@keyframes ui-buttonc-spin {
  to {
    transform: rotate(1turn);
  }
}

@keyframes ui-buttonc-sweep {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0% 0;
  }
}

@media (prefers-reduced-motion: reduce) {
  .ui-buttonc[data-ready] .ui-buttonc__label,
  .ui-buttonc[data-ready] .ui-buttonc__icon {
    animation: none;
  }
  .ui-buttonc {
    transition-duration: 1ms;
  }
  .ui-buttonc[data-loading] .ui-buttonc__label::after {
    animation: none;
    opacity: 0;
  }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-buttonc {
  /* primary inverts: a light chip with dark text */
  --ui-btnc-solid: var(--aui-primary, rgba(255, 255, 255, 0.9));
  --ui-btnc-solid-hover: rgba(255, 255, 255, 0.82);
  --ui-btnc-on-solid: var(--aui-on-primary, #161618);
  --ui-btnc-shine-on-solid: #ffffff;

  --ui-btnc-title: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-btnc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-btnc-muted: var(--aui-muted, rgba(255, 255, 255, 0.62));
  --ui-btnc-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-btnc-surface: var(--aui-surface, #1c1c1e);
  --ui-btnc-shadow: 0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.1)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-btnc-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.16)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-btnc-wash: rgba(255, 255, 255, 0.06);
  --ui-btnc-danger: var(--aui-danger, #ff8a7a);
  --ui-btnc-danger-bg: rgba(255, 107, 95, 0.14);
  --ui-btnc-danger-bg-hover: rgba(255, 107, 95, 0.2);
  --ui-btnc-shine: #ffffff;
  --ui-btnc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}

/* Hover of the primary button follows its fill – also a brand color from --aui-primary. Browsers without
   color-mix() (Safari before 16.2) keep the fixed hover above */
@supports (color: color-mix(in srgb, red 50%, transparent)) {
  .ui-buttonc {
    --ui-btnc-solid-hover: color-mix(in srgb, var(--ui-btnc-solid) 91%, transparent);
  }
}
`;export{G as i};
