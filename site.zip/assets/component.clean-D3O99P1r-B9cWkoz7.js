import{j as a}from"./workbench-model-BwgilGut.js";import{t as ne}from"./react-BkAXpnfr-Clok0bvh.js";var o=ne();function fe({options:r,value:z,defaultValue:X=null,onChange:N,placeholder:C="Choose…",label:g,hint:K,error:v,optional:Z=!1,size:T="md",disabled:_=!1,name:I,required:ee,id:ie,className:ae,"aria-label":D,ref:k}){let m=(0,o.useId)(),L=ie??`${m}-trigger`,R=`${m}-list`,E=`${m}-label`,A=`${m}-message`,B=e=>`${m}-option-${e}`,[re,te]=(0,o.useState)(X),h=z===void 0?re:z,n=r.find(e=>e.value===h)??null,[s,U]=(0,o.useState)(!1),[c,d]=(0,o.useState)(-1),[l,W]=(0,o.useState)(null),[$,Y]=(0,o.useState)(null),y=(0,o.useRef)(null),b=(0,o.useRef)(null),f=(0,o.useRef)({text:"",at:0}),q=!!v,M=j(v)?v:j(K)?K:null,se=ue.includes(T)?T:"md",P=e=>e>=0&&e<r.length&&!r[e].disabled,F=()=>r.findIndex(e=>!e.disabled),le=()=>{for(let e=r.length-1;e>=0;e--)if(!r[e].disabled)return e;return-1},O=(e,i)=>{for(let t=e+i;t>=0&&t<r.length;t+=i)if(!r[t].disabled)return t;return e},V=e=>{if(_||!r.length)return;let i=r.findIndex(t=>t.value===h);d(P(i)?i:F()),U(!0)},w=(e=!0)=>{var i;U(!1),Y(null),W(null),e&&((i=y.current)==null||i.focus({preventScroll:!0}))},H=e=>{if(!P(e))return;let i=r[e];z===void 0&&te(i.value),i.value!==h&&(N==null||N(i.value,i)),w()},G=()=>{var Q;let e=y.current;if(!e)return;let i=e.getBoundingClientRect(),t=window.innerHeight-i.bottom-4-8,x=i.top-4-8,p=Math.min(((Q=b.current)==null?void 0:Q.scrollHeight)??280,288),u=t<Math.min(p,160)&&x>t,J=Math.max(i.width,180),oe=Math.min(Math.max(8,i.left),window.innerWidth-J-8);W({top:u?i.top-4:i.bottom+4,left:oe,width:J,maxHeight:Math.max(120,Math.min(288,u?x:t)),up:u})};(0,o.useLayoutEffect)(()=>{if(!s)return;let e=b.current;e&&"showPopover"in e&&!e.matches(":popover-open")&&e.showPopover(),G();let i=()=>G();return window.addEventListener("resize",i),window.addEventListener("scroll",i,!0),()=>{window.removeEventListener("resize",i),window.removeEventListener("scroll",i,!0),e&&"hidePopover"in e&&e.matches(":popover-open")&&e.hidePopover()}},[s]),(0,o.useEffect)(()=>{if(!s)return;let e=i=>{var x,p;let t=i.target;(x=y.current)!=null&&x.contains(t)||(p=b.current)!=null&&p.contains(t)||w(!1)};return document.addEventListener("pointerdown",e,!0),()=>document.removeEventListener("pointerdown",e,!0)},[s]),(0,o.useLayoutEffect)(()=>{var i;if(!s||c<0)return;let e=(i=b.current)==null?void 0:i.querySelector(`[data-index="${c}"]`);e&&(Y({top:e.offsetTop,height:e.offsetHeight}),e.scrollIntoView({block:"nearest"}))},[c,s,l]);let S=e=>{let i=Date.now();f.current.text=i-f.current.at>700?e:f.current.text+e,f.current.at=i;let t=f.current.text.toLowerCase(),x=s?c:r.findIndex(u=>u.value===h),p=[...r.keys()].map(u=>(u+x+ +(t.length===1)+r.length)%r.length).find(u=>P(u)&&r[u].label.toLowerCase().startsWith(t));p!==void 0&&(s?d(p):H(p))};return a.jsxs("div",{className:["ui-selc",ae].filter(Boolean).join(" "),"data-size":se,"data-open":s||void 0,"data-invalid":q||void 0,"data-disabled":_||void 0,children:[a.jsx("style",{href:"ui-select-clean",precedence:"default",children:pe}),g!=null&&a.jsxs("div",{className:"ui-selc__head",children:[a.jsx("label",{className:"ui-selc__label",id:E,htmlFor:L,children:g}),Z&&a.jsx("span",{className:"ui-selc__optional",children:"Optional"})]}),a.jsxs("button",{ref:(e=>{y.current=e,typeof k=="function"?k(e):k&&(k.current=e)}),id:L,type:"button",className:"ui-selc__trigger",role:"combobox","aria-haspopup":"listbox","aria-expanded":s,"aria-controls":R,"aria-activedescendant":s&&c>=0?B(c):void 0,"aria-label":D,"aria-labelledby":D||g==null?void 0:`${E} ${L}`,"aria-describedby":M?A:void 0,"aria-invalid":q||void 0,"aria-required":ee||void 0,disabled:_,onClick:()=>s?w():V(),onKeyDown:e=>{if(!_){if(!s){e.key==="ArrowDown"||e.key==="ArrowUp"||e.key==="Enter"||e.key===" "?(e.preventDefault(),V()):e.key.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&S(e.key);return}switch(e.key){case"ArrowDown":e.preventDefault(),d(i=>O(i,1));break;case"ArrowUp":e.preventDefault(),d(i=>O(i,-1));break;case"Home":case"PageUp":e.preventDefault(),d(F());break;case"End":case"PageDown":e.preventDefault(),d(le());break;case"Enter":case" ":e.preventDefault(),e.key===" "&&Date.now()-f.current.at<700?S(" "):H(c);break;case"Escape":e.preventDefault(),w();break;case"Tab":w(!1);break;default:e.key.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&S(e.key)}}},children:[(n==null?void 0:n.icon)&&a.jsx("span",{className:"ui-selc__icon","aria-hidden":"true",children:n.icon}),a.jsx("span",{className:"ui-selc__value","data-empty":n?void 0:"",title:n==null?void 0:n.label,children:n?n.label:C}),a.jsx("span",{className:"ui-selc__chevron","aria-hidden":"true",children:a.jsx(ce,{})})]}),I&&a.jsx("input",{type:"hidden",name:I,value:h??""}),s&&a.jsxs("div",{ref:b,id:R,className:"ui-selc__list",role:"listbox","aria-labelledby":g==null?void 0:E,"aria-label":g==null?D??C:void 0,popover:"manual","data-up":(l==null?void 0:l.up)||void 0,style:l?{top:l.up?void 0:l.top,bottom:l.up?window.innerHeight-l.top:void 0,left:l.left,width:l.width,maxHeight:l.maxHeight}:void 0,onPointerLeave:()=>d(-1),children:[$&&a.jsx("span",{className:"ui-selc__glow","aria-hidden":"true",style:{transform:`translateY(${$.top}px)`,height:$.height}}),r.map((e,i)=>a.jsxs("div",{id:B(i),className:"ui-selc__option",role:"option","data-index":i,"aria-selected":e.value===h,"aria-disabled":e.disabled||void 0,"data-active":i===c||void 0,onPointerMove:()=>e.disabled||i===c||d(i),onPointerDown:t=>t.preventDefault(),onClick:()=>H(i),children:[e.icon&&a.jsx("span",{className:"ui-selc__icon","aria-hidden":"true",children:e.icon}),a.jsxs("span",{className:"ui-selc__text",children:[a.jsx("span",{className:"ui-selc__option-label",children:e.label}),e.description&&a.jsx("span",{className:"ui-selc__option-hint",children:e.description})]}),a.jsx("span",{className:"ui-selc__check","aria-hidden":"true",children:e.value===h&&a.jsx(de,{})})]},e.value))]}),M&&a.jsx("p",{className:"ui-selc__message",id:A,"aria-live":j(v)?"polite":void 0,children:M},j(v)?"error":"hint")]})}var ue=["sm","md","lg"],j=r=>r!=null&&typeof r!="boolean"&&r!=="";function ce(){return a.jsx("svg",{viewBox:"0 0 24 24",width:"14",height:"14",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:a.jsx("path",{d:"m7 10 5 5 5-5"})})}function de(){return a.jsx("svg",{viewBox:"0 0 24 24",width:"14",height:"14",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:a.jsx("path",{className:"ui-selc__tick",d:"M5 12.5 9.5 17 19 7",pathLength:1})})}var pe=`
/* Colors and motion as variables – override them on .ui-selc (see Theming in the docs) */
.ui-selc {
  --ui-selc-title: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-selc-ink: var(--aui-ink, rgba(0, 0, 0, 0.88));
  --ui-selc-subtle: var(--aui-muted, rgba(0, 0, 0, 0.45));
  --ui-selc-faint: var(--aui-placeholder, rgba(0, 0, 0, 0.3));
  --ui-selc-icon: var(--aui-muted, rgba(0, 0, 0, 0.447));
  --ui-selc-surface: var(--aui-surface, #ffffff);
  --ui-selc-menu: var(--aui-surface, #ffffff);
  --ui-selc-glow: rgba(0, 0, 0, 0.045);
  --ui-selc-readonly: rgba(0, 0, 0, 0.02);
  --ui-selc-shadow: 0 0 0 0.5px var(--aui-border, rgba(0, 0, 0, 0.08)), 0 1px 1px -1px rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --ui-selc-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(0, 0, 0, 0.13)), 0 1px 1px -1px rgba(0, 0, 0, 0.12), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-selc-shadow-open: 0 0 0 1px var(--aui-border-strong, rgba(0, 0, 0, 0.28)), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --ui-selc-shadow-menu: 0 0 0 0.5px rgba(0, 0, 0, 0.08), 0 8px 24px -6px rgba(0, 0, 0, 0.14), 0 2px 6px -2px rgba(0, 0, 0, 0.06);
  --ui-selc-danger: var(--aui-danger, #c4320a);
  --ui-selc-danger-edge: rgba(240, 68, 56, 0.55);
  --ui-selc-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-selc-ease: cubic-bezier(0.22, 1, 0.36, 1);

  --h: 32px;
  --px: 10px;
  --fs: 13px;
  --radius: var(--aui-radius, 7px);

  display: flex;
  flex-direction: column;
  gap: 6px;
  min-width: 0;
  font-family: var(--aui-font, "Inter", "InterVariable", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif);
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-selc-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-selc[data-size="sm"] { --h: 28px; --px: 8px; --radius: calc(var(--aui-radius, 7px) - 1px); }
.ui-selc[data-size="lg"] { --h: 36px; --px: 12px; --fs: 14px; --radius: calc(var(--aui-radius, 7px) + 1px); }
/* Touch screens: a comfortable tap height and 16px text */
@media (pointer: coarse) {
  .ui-selc { --fs: 16px; }
  .ui-selc[data-size="sm"] { --h: 34px; }
  .ui-selc[data-size="md"] { --h: 38px; }
  .ui-selc[data-size="lg"] { --h: 40px; }
}

.ui-selc__head { display: flex; align-items: baseline; gap: 6px; min-width: 0; }
.ui-selc__label { min-width: 0; font-weight: 500; color: var(--ui-selc-title); overflow-wrap: anywhere; cursor: default; }
.ui-selc__optional { flex: none; font-size: 12px; line-height: 16px; color: var(--ui-selc-subtle); }

/* The field: the Text Field's look – white, a hairline edge that firms up on hover and while open */
.ui-selc__trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  box-sizing: border-box;
  width: 100%;
  height: var(--h);
  min-width: 0;
  margin: 0;
  padding: 0 calc(var(--px) - 2px) 0 var(--px);
  border: 0;
  border-radius: var(--radius);
  background: var(--ui-selc-surface);
  box-shadow: var(--ui-selc-shadow);
  font: inherit;
  font-size: var(--fs);
  color: var(--ui-selc-ink);
  text-align: start;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: box-shadow 140ms ease, background-color 140ms ease;
}
.ui-selc__trigger:hover { box-shadow: var(--ui-selc-shadow-hover); }
.ui-selc[data-open] .ui-selc__trigger { box-shadow: var(--ui-selc-shadow-open); }
.ui-selc__trigger:focus-visible { outline: 2px solid var(--ui-selc-focus); outline-offset: 2px; }
.ui-selc[data-invalid] .ui-selc__trigger { box-shadow: 0 0 0 1px var(--ui-selc-danger-edge), 0 1px 2px 0 rgba(0, 0, 0, 0.05); }
.ui-selc__trigger:disabled { background: var(--ui-selc-readonly); box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.06); cursor: not-allowed; }
.ui-selc[data-disabled] { opacity: 0.55; }

.ui-selc__value { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.ui-selc__value[data-empty] { color: var(--ui-selc-faint); }
.ui-selc__icon { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-selc-icon); }
.ui-selc__icon > svg, .ui-selc__icon > img { display: block; width: 16px; height: 16px; }
.ui-selc__chevron { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-selc-icon); transition: transform 240ms var(--ui-selc-ease); }
.ui-selc[data-open] .ui-selc__chevron { transform: rotate(180deg); }

/* The list: a white card in the top layer, at the field's edge */
.ui-selc__list {
  position: fixed;
  inset: auto;
  z-index: 1000;
  box-sizing: border-box;
  margin: 0;
  padding: 4px;
  border: 0;
  border-radius: 10px;
  background: var(--ui-selc-menu);
  box-shadow: var(--ui-selc-shadow-menu);
  color: var(--ui-selc-ink);
  font: inherit;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  transform-origin: top center;
  animation: ui-selc-in 200ms var(--ui-selc-ease) both;
}
.ui-selc__list[data-up] { transform-origin: bottom center; }
.ui-selc__list::backdrop { display: none; }

/* One soft highlight that glides between the rows */
.ui-selc__glow {
  position: absolute;
  top: 0;
  left: 4px;
  right: 4px;
  border-radius: 6px;
  background: var(--ui-selc-glow);
  pointer-events: none;
  transition: transform 180ms var(--ui-selc-ease), height 180ms var(--ui-selc-ease);
}

.ui-selc__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 32px;
  padding: 6px 8px;
  box-sizing: border-box;
  border-radius: 6px;
  font-size: 13px;
  line-height: 20px;
  cursor: pointer;
  user-select: none;
}
.ui-selc__option[aria-disabled] { color: var(--ui-selc-faint); cursor: default; }
.ui-selc__option[aria-disabled] .ui-selc__icon { opacity: 0.5; }
.ui-selc__text { display: grid; flex: 1; min-width: 0; }
.ui-selc__option-label { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.ui-selc__option[aria-selected="true"] .ui-selc__option-label { font-weight: 500; }
.ui-selc__option-hint { overflow: hidden; font-size: 12px; line-height: 16px; white-space: nowrap; text-overflow: ellipsis; color: var(--ui-selc-subtle); }
.ui-selc__check { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-selc-ink); }
.ui-selc__tick { stroke-dasharray: 1; animation: ui-selc-draw 280ms 40ms var(--ui-selc-ease) both; }
@media (pointer: coarse) {
  .ui-selc__option { min-height: 40px; font-size: 15px; }
}

.ui-selc__message { margin: 0; font-size: 12px; line-height: 16px; color: var(--ui-selc-subtle); overflow-wrap: anywhere; animation: ui-selc-message 260ms var(--ui-selc-ease); }
.ui-selc[data-invalid] .ui-selc__message { color: var(--ui-selc-danger); }

@keyframes ui-selc-in {
  from { opacity: 0; transform: translateY(-4px) scale(0.98); }
}
.ui-selc__list[data-up] { animation-name: ui-selc-in-up; }
@keyframes ui-selc-in-up {
  from { opacity: 0; transform: translateY(4px) scale(0.98); }
}
@keyframes ui-selc-draw {
  from { stroke-dashoffset: 1; }
  to { stroke-dashoffset: 0; }
}
@keyframes ui-selc-message {
  from { opacity: 0; transform: translateY(-3px); filter: blur(2px); }
}

@media (prefers-reduced-motion: reduce) {
  .ui-selc *, .ui-selc__list { animation-duration: 1ms !important; }
  .ui-selc__glow, .ui-selc__chevron, .ui-selc__trigger { transition-duration: 1ms; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-selc {
  --ui-selc-title: var(--aui-ink, rgba(255, 255, 255, 0.92));
  --ui-selc-ink: var(--aui-ink, rgba(255, 255, 255, 0.9));
  --ui-selc-subtle: var(--aui-muted, rgba(255, 255, 255, 0.46));
  --ui-selc-faint: var(--aui-placeholder, rgba(255, 255, 255, 0.3));
  --ui-selc-icon: var(--aui-muted, rgba(255, 255, 255, 0.5));
  --ui-selc-surface: var(--aui-surface, #1c1c1e);
  --ui-selc-menu: var(--aui-surface, #1f1f22);
  --ui-selc-glow: rgba(255, 255, 255, 0.07);
  --ui-selc-readonly: rgba(255, 255, 255, 0.03);
  --ui-selc-shadow: 0 0 0 0.5px var(--aui-border, rgba(255, 255, 255, 0.14)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-selc-shadow-hover: 0 0 0 0.5px var(--aui-border-strong, rgba(255, 255, 255, 0.2)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-selc-shadow-open: 0 0 0 1px var(--aui-border-strong, rgba(255, 255, 255, 0.3)), 0 1px 2px 0 rgba(0, 0, 0, 0.4);
  --ui-selc-shadow-menu: 0 0 0 0.5px rgba(255, 255, 255, 0.12), 0 12px 32px -8px rgba(0, 0, 0, 0.6);
  --ui-selc-danger: var(--aui-danger, #ff8a7a);
  --ui-selc-danger-edge: rgba(255, 107, 95, 0.5);
  --ui-selc-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
`;export{fe as i};
