import{r as s,j as a}from"./workbench-model-BwgilGut.js";import{t as me}from"./react-BkAXpnfr-Clok0bvh.js";import{t as ve}from"./jsx-runtime-CTsRTJUX-CoXrQeBV.js";const _e=7,pe=110;function Ae({items:h,index:_,defaultIndex:V,onIndexChange:H,onSelect:w,itemWidth:j=280,itemHeight:ne=280,angle:U=50,reflection:G=!0,caption:K=!0,renderCaption:O,controls:L=!0,ticks:D=!0,sound:J=!1,"aria-label":ce="Cover flow",className:oe}){const l=h.length,v=Math.max(l-1,0),k=(e=>Math.min(Math.max(e,0),v))(_??V??Math.floor(v/2)),[$,se]=s.useState(k),[ue,X]=s.useState(1),[q,Z]=s.useState(1),B=s.useRef(null),f=s.useRef([]),o=s.useRef({pos:k,target:k,vel:0,raf:0,last:0,active:k}),g=s.useRef({angle:U,scale:q,itemWidth:j,onIndexChange:H,sound:J,count:l});g.current={angle:U,scale:q,itemWidth:j,onIndexChange:H,sound:J,count:l};const N=s.useRef(!1);s.useEffect(()=>{const e=window.matchMedia("(prefers-reduced-motion: reduce)");N.current=e.matches;const t=()=>N.current=e.matches;return e.addEventListener("change",t),()=>e.removeEventListener("change",t)},[]);const z=s.useRef(null),W=()=>{const e=z.current;if(!e||e.state!=="running")return;const t=e.currentTime,i=e.createOscillator(),n=e.createGain();i.type="triangle",i.frequency.setValueAtTime(2200,t),i.frequency.exponentialRampToValueAtTime(900,t+.03),n.gain.setValueAtTime(1e-4,t),n.gain.exponentialRampToValueAtTime(.05,t+.004),n.gain.exponentialRampToValueAtTime(1e-4,t+.045),i.connect(n).connect(e.destination),i.start(t),i.stop(t+.05)},y=()=>{var t;if(!g.current.sound)return;const e=window.AudioContext??window.webkitAudioContext;!z.current&&e&&(z.current=new e),((t=z.current)==null?void 0:t.state)==="suspended"&&z.current.resume()};s.useEffect(()=>()=>{var e;return void((e=z.current)==null?void 0:e.close())},[]);const x=s.useCallback(()=>{var ee,A;const{pos:e}=o.current,{angle:t,scale:i,itemWidth:n}=g.current,c=n*.78*i,d=n*.27*i,b=n*.7*i;f.current.forEach((C,S)=>{if(!C)return;const I=S-e,R=Math.abs(I);if(R>_e+1){C.style.visibility="hidden";return}const F=Math.min(R,1),ae=Math.sign(I),le=ae*(F*c+Math.max(R-1,0)*d);C.style.visibility="";const ge=1-F*.08-Math.min(Math.max(R-1,0),4)*.015;C.style.transform=`translate3d(${le}px, 0, ${-F*b}px) rotateY(${-ae*F*t}deg) scale(${ge.toFixed(4)})`,C.style.zIndex=String(1e3-Math.round(R*10)),C.style.setProperty("--ui-cf-t",F.toFixed(3)),C.style.setProperty("--ui-cf-d",Math.min(Math.max(I,-1.5),1.5).toFixed(3)),C.dataset.side=I<0?"left":"right"});const M=Math.round(Math.min(Math.max(e,0),g.current.count-1));M!==o.current.active&&(X(M>o.current.active?1:-1),o.current.active=M,se(M),(A=(ee=g.current).onIndexChange)==null||A.call(ee,M),W())},[]),p=s.useCallback(()=>{const e=o.current;if(e.raf)return;e.last=performance.now();const t=i=>{const n=Math.min(i-e.last,32)/1e3;e.last=i;const c=190,d=2*Math.sqrt(c)*.92;if(e.vel+=(c*(e.target-e.pos)-d*e.vel)*n,e.pos+=e.vel*n,Math.abs(e.target-e.pos)<6e-4&&Math.abs(e.vel)<.002){e.pos=e.target,e.vel=0,e.raf=0,x();return}x(),e.raf=requestAnimationFrame(t)};e.raf=requestAnimationFrame(t)},[x]),m=s.useCallback(e=>{const t=o.current;t.target=Math.min(Math.max(Math.round(e),0),g.current.count-1),N.current?(t.pos=t.target,t.vel=0,x()):p()},[x,p]);s.useEffect(()=>()=>cancelAnimationFrame(o.current.raf),[]),s.useEffect(()=>{_!==void 0&&_!==Math.round(o.current.target)&&m(_)},[_,m]),s.useEffect(()=>{o.current.target>v?m(v):x()},[v,m,x]),s.useLayoutEffect(()=>{const e=B.current;if(!e)return;const t=()=>Z(Math.min(1,Math.max(.5,e.clientWidth/(j*3.2))));t();const i=new ResizeObserver(t);return i.observe(e),()=>i.disconnect()},[j]),s.useLayoutEffect(x);const P=s.useRef(0);s.useEffect(()=>{const e=B.current;if(!e)return;const t=i=>{const n=i.shiftKey&&!i.deltaX?i.deltaY:i.deltaX;if(Math.abs(n)<=Math.abs(i.deltaY)&&!i.shiftKey)return;i.preventDefault(),y();const c=o.current,d=pe*g.current.scale*1.4;c.target=Math.min(Math.max(c.target+n/d,-.35),g.current.count-1+.35),p(),window.clearTimeout(P.current),P.current=window.setTimeout(()=>m(c.target+Math.sign(n)*.3),110)};return e.addEventListener("wheel",t,{passive:!1}),()=>{e.removeEventListener("wheel",t),window.clearTimeout(P.current)}},[p,m]);const Y=s.useRef(null),fe=e=>{if(e.button!==0)return;y();const t=e.target.closest("[data-cf-index]");Y.current={id:e.pointerId,x:e.clientX,from:o.current.pos,moved:!1,hit:t?Number(t.dataset.cfIndex):null,samples:[{x:e.clientX,t:performance.now()}]}},te=e=>{const t=Y.current;if(!t||t.id!==e.pointerId)return;const i=e.clientX-t.x;if(!t.moved){if(Math.abs(i)<6)return;t.moved=!0,e.currentTarget.setPointerCapture(e.pointerId),e.currentTarget.dataset.dragging=""}const n=o.current;cancelAnimationFrame(n.raf),n.raf=0;let c=t.from-i/(pe*g.current.scale);const d=g.current.count-1;c<0&&(c=c*.3),c>d&&(c=d+(c-d)*.3),n.pos=n.target=c,n.vel=0,t.samples.push({x:e.clientX,t:performance.now()}),t.samples.length>6&&t.samples.shift(),x()},re=e=>{const t=Y.current;if(!t||t.id!==e.pointerId)return;if(Y.current=null,delete e.currentTarget.dataset.dragging,!t.moved){if(t.hit===null)return;t.hit===Math.round(o.current.target)?w==null||w(h[t.hit],t.hit):m(t.hit);return}const i=t.samples[0],n=t.samples[t.samples.length-1],c=Math.max(n.t-i.t,1),d=-((n.x-i.x)/c)*1e3/(pe*g.current.scale),b=o.current;b.vel=N.current?0:d;let M=Math.round(b.pos+d*.18);Math.abs(d)>.8&&M===Math.round(t.from)&&(M+=Math.sign(d)),m(M)},T=e=>{const t=Math.round(o.current.target),i={ArrowLeft:t-1,ArrowRight:t+1,Home:0,End:v};e.key in i?(e.preventDefault(),y(),m(i[e.key])):(e.key==="Enter"||e.key===" ")&&w&&e.target===e.currentTarget&&(e.preventDefault(),w(h[t],t))},E=h[$],de=Math.round(j*q),ie=Math.round(ne*q),r=(e,t=!1)=>a.jsx("div",{className:"ui-cf__media",children:e.cover??(e.image?a.jsx("img",{src:e.image,alt:t?"":e.alt??e.title??"",draggable:!1,loading:"lazy",decoding:"async",onError:i=>i.currentTarget.style.visibility="hidden"}):null)});return a.jsxs("div",{className:["ui-cf",oe].filter(Boolean).join(" "),style:{"--ui-cf-w":`${de}px`,"--ui-cf-h":`${ie}px`},"data-reflection":G||void 0,children:[a.jsx("style",{href:"ui-cover-flow",precedence:"default",children:xe}),a.jsx("div",{ref:B,className:"ui-cf__viewport",role:"region","aria-roledescription":"carousel","aria-label":ce,tabIndex:0,onKeyDown:T,onPointerDown:fe,onPointerMove:te,onPointerUp:re,onPointerCancel:re,"data-selectable":w?"":void 0,children:a.jsx("div",{className:"ui-cf__stage",style:{perspective:`${Math.round(1e3*q)}px`},children:h.map((e,t)=>a.jsxs("div",{ref:i=>{f.current[t]=i},className:"ui-cf__item","data-cf-index":t,"data-active":t===$||void 0,role:"group","aria-roledescription":"slide","aria-label":`${t+1} of ${l}${e.title?`: ${e.title}`:""}`,"aria-hidden":t!==$||void 0,children:[a.jsx("div",{className:"ui-cf__ground","aria-hidden":"true"}),a.jsx("div",{className:"ui-cf__card",children:r(e)}),G&&a.jsx("div",{className:"ui-cf__reflection","aria-hidden":"true",inert:!0,children:a.jsx("div",{className:"ui-cf__card",children:r(e,!0)})})]},e.id))})}),(K||L||D)&&a.jsxs("div",{className:"ui-cf__footer",children:[a.jsxs("div",{className:"ui-cf__row",children:[L&&a.jsx("button",{type:"button",className:"ui-cf__nav","aria-label":"Previous",disabled:$===0,onClick:()=>m(Math.round(o.current.target)-1),children:a.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("path",{d:"M10 3.5 5.5 8l4.5 4.5"})})}),K&&a.jsx("div",{className:"ui-cf__caption","aria-live":"polite",children:a.jsx("div",{className:"ui-cf__caption-in","data-dir":ue>0?"next":"prev",children:E&&(O?O(E,$):a.jsxs(a.Fragment,{children:[E.title&&a.jsx("div",{className:"ui-cf__title",children:E.title}),E.subtitle&&a.jsx("div",{className:"ui-cf__subtitle",children:E.subtitle})]}))},E==null?void 0:E.id)}),L&&a.jsx("button",{type:"button",className:"ui-cf__nav","aria-label":"Next",disabled:$===v,onClick:()=>m(Math.round(o.current.target)+1),children:a.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("path",{d:"M6 3.5 10.5 8 6 12.5"})})})]}),D&&l>15&&a.jsxs("div",{className:"ui-cf__counter","aria-hidden":"true",children:[$+1," / ",l]}),D&&l>1&&l<=15&&a.jsx("div",{className:"ui-cf__ticks",children:h.map((e,t)=>a.jsx("button",{type:"button",tabIndex:-1,className:"ui-cf__tick","aria-label":`Show ${e.title??`cover ${t+1}`}`,"aria-current":t===$||void 0,onClick:()=>m(t)},e.id))})]})]})}const xe=`
.ui-cf {
  --ui-cf-ink: #171717;
  --ui-cf-muted: #8a8a8a;
  --ui-cf-card: #f1f1f1;
  --ui-cf-edge: rgba(0, 0, 0, 0.08);
  --ui-cf-dim: rgba(255, 255, 255, 0.24);
  --ui-cf-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), 0 10px 20px -12px rgba(0, 0, 0, 0.18);
  --ui-cf-reflect: 0.22;
  --ui-cf-ground: rgba(0, 0, 0, 0.16);
  --ui-cf-tick: rgba(0, 0, 0, 0.16);
  --ui-cf-nav: #ffffff;
  --ui-cf-nav-line: #e7e7e7;
  --ui-cf-focus: rgba(23, 23, 23, 0.25);
  --ui-cf-ease: cubic-bezier(0.22, 1, 0.36, 1);
  display: grid;
  gap: 4px;
  width: 100%;
  min-width: 0;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  -webkit-font-smoothing: antialiased;
}

/* Soft fade on both sides, so the stacks run out instead of being cut off */
.ui-cf__viewport {
  position: relative;
  overflow: hidden;
  padding: calc(var(--ui-cf-h) * 0.08) 0 0;
  height: calc(var(--ui-cf-h) * 1.08);
  border-radius: 12px;
  outline: none;
  cursor: grab;
  touch-action: pan-y;
  user-select: none;
  -webkit-user-select: none;
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 9%, #000 91%, transparent);
  mask-image: linear-gradient(90deg, transparent, #000 9%, #000 91%, transparent);
}
.ui-cf[data-reflection] .ui-cf__viewport { height: calc(var(--ui-cf-h) * 1.4); }
.ui-cf__viewport[data-dragging] { cursor: grabbing; }
.ui-cf__viewport:focus-visible .ui-cf__item[data-active] .ui-cf__card {
  box-shadow: var(--ui-cf-shadow), 0 0 0 3px var(--ui-cf-focus);
}

.ui-cf__stage {
  position: relative;
  height: var(--ui-cf-h);
  transform-style: preserve-3d;
}
.ui-cf__item {
  position: absolute;
  top: 0;
  left: 50%;
  width: var(--ui-cf-w);
  height: var(--ui-cf-h);
  margin-left: calc(var(--ui-cf-w) / -2);
  transform-style: preserve-3d;
  will-change: transform;
}
.ui-cf__viewport[data-selectable] .ui-cf__item[data-active] { cursor: pointer; }
.ui-cf__card {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cf-card);
  box-shadow: var(--ui-cf-shadow);
}
.ui-cf__media {
  position: absolute;
  inset: 0 -8%;
  transform: translateX(calc(var(--ui-cf-d, 0) * -5%));
}
.ui-cf__media > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
}
/* A soft shadow on the floor that fades as a cover turns away */
.ui-cf__ground {
  position: absolute;
  left: 10%;
  right: 10%;
  bottom: -3px;
  height: 8px;
  border-radius: 50%;
  background: var(--ui-cf-ground);
  filter: blur(5px);
  opacity: calc(1 - var(--ui-cf-t, 0) * 0.7);
  pointer-events: none;
}
/* Hairline edge, a dim that grows as a cover turns away, and a sheen on the side facing the light */
.ui-cf__card::before,
.ui-cf__card::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
}
.ui-cf__card::before {
  z-index: 2;
  box-shadow: inset 0 0 0 1px var(--ui-cf-edge);
  background: linear-gradient(90deg, rgba(255, 255, 255, 0.22), transparent 45%);
  opacity: calc(var(--ui-cf-t, 0) * 0.9);
}
.ui-cf__item[data-side="right"] .ui-cf__card::before {
  background: linear-gradient(270deg, rgba(255, 255, 255, 0.22), transparent 45%);
}
.ui-cf__card::after {
  z-index: 1;
  background: var(--ui-cf-dim);
  opacity: var(--ui-cf-t, 0);
}

/* The floor: a flipped copy that fades out – a mask, so it works on any background */
.ui-cf__reflection {
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  height: 32%;
  margin-top: 2px;
  overflow: hidden;
  pointer-events: none;
  -webkit-mask-image: linear-gradient(to bottom, rgba(0, 0, 0, var(--ui-cf-reflect)), transparent 85%);
  mask-image: linear-gradient(to bottom, rgba(0, 0, 0, var(--ui-cf-reflect)), transparent 85%);
}
.ui-cf__reflection > .ui-cf__card {
  height: var(--ui-cf-h);
  transform: scaleY(-1);
  transform-origin: 50% calc(var(--ui-cf-h) / 2);
  box-shadow: none;
}
.ui-cf__reflection > .ui-cf__card {
  position: absolute;
  bottom: auto;
  top: 0;
}

/* Caption with previous / next on either side, position ticks below */
.ui-cf__footer {
  position: relative;
  z-index: 1;
  display: grid;
  justify-items: center;
  gap: 14px;
  margin-top: calc(var(--ui-cf-h) * -0.04);
}
.ui-cf:not([data-reflection]) .ui-cf__footer { margin-top: 12px; }
.ui-cf__row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  min-height: 44px;
}
.ui-cf__counter { color: var(--ui-cf-muted); font-size: 12px; line-height: 14px; font-variant-numeric: tabular-nums; }
.ui-cf__ticks {
  display: flex;
  align-items: center;
  gap: 2px;
}
.ui-cf__tick {
  display: grid;
  place-items: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 0;
  background: none;
  cursor: pointer;
}
.ui-cf__tick::before {
  content: "";
  width: 5px;
  height: 5px;
  border-radius: 999px;
  background: var(--ui-cf-tick);
  transition: width 320ms var(--ui-cf-ease), background-color 200ms ease;
}
.ui-cf__tick[aria-current]::before {
  width: 14px;
  background: var(--ui-cf-ink);
}
.ui-cf__tick:hover::before { background: var(--ui-cf-muted); }
.ui-cf__tick[aria-current]:hover::before { background: var(--ui-cf-ink); }
.ui-cf__caption {
  display: grid;
  min-width: min(220px, 50vw);
  text-align: center;
}
.ui-cf__caption-in { animation: ui-cf-in 420ms var(--ui-cf-ease) both; }
.ui-cf__caption-in[data-dir="prev"] { animation-name: ui-cf-in-prev; }
.ui-cf__title {
  color: var(--ui-cf-ink);
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  line-height: 1.35;
}
.ui-cf__subtitle {
  color: var(--ui-cf-muted);
  font-size: 13px;
  line-height: 1.4;
}
.ui-cf__nav {
  display: grid;
  place-items: center;
  flex: none;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: var(--ui-cf-nav);
  box-shadow: inset 0 0 0 1px var(--ui-cf-nav-line), 0 1px 2px rgba(0, 0, 0, 0.05);
  color: var(--ui-cf-ink);
  cursor: pointer;
  transition: transform 160ms var(--ui-cf-ease), opacity 160ms ease;
}
.ui-cf__nav:active { transform: scale(0.92); }
.ui-cf__nav:disabled { opacity: 0.35; cursor: default; transform: none; }
.ui-cf__nav:focus-visible { outline: 2px solid var(--ui-cf-focus); outline-offset: 2px; }
.ui-cf__nav svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
@media (pointer: coarse) {
  .ui-cf__nav { width: 40px; height: 40px; }
}

/* The caption rises in from the direction of travel */
@keyframes ui-cf-in {
  from { opacity: 0; transform: translate(14px, 4px); filter: blur(3px); }
  to { opacity: 1; transform: none; filter: none; }
}
@keyframes ui-cf-in-prev {
  from { opacity: 0; transform: translate(-14px, 4px); filter: blur(3px); }
  to { opacity: 1; transform: none; filter: none; }
}

@media (prefers-reduced-motion: reduce) {
  .ui-cf__caption-in { animation: none; }
  .ui-cf__media { transform: none; }
  .ui-cf__tick::before { transition: none; }
  .ui-cf__nav { transition: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-cf {
  --ui-cf-ink: #ededed;
  --ui-cf-muted: #8f8f8f;
  --ui-cf-card: #1d1d20;
  --ui-cf-edge: rgba(255, 255, 255, 0.1);
  --ui-cf-dim: rgba(0, 0, 0, 0.5);
  --ui-cf-shadow: 0 1px 2px rgba(0, 0, 0, 0.3), 0 12px 24px -14px rgba(0, 0, 0, 0.6);
  --ui-cf-reflect: 0.3;
  --ui-cf-ground: rgba(0, 0, 0, 0.45);
  --ui-cf-tick: rgba(255, 255, 255, 0.2);
  --ui-cf-nav: #1d1d20;
  --ui-cf-nav-line: rgba(255, 255, 255, 0.1);
  --ui-cf-focus: rgba(255, 255, 255, 0.35);
}
`;var u=me(),be=ve(),he=110;function we({items:h,index:_,defaultIndex:V,onIndexChange:H,onSelect:w,itemWidth:j=280,itemHeight:ne=280,angle:U=50,reflection:G=!0,caption:K=!0,renderCaption:O,controls:L=!0,ticks:D=!0,sound:J=!1,"aria-label":ce="Cover flow",className:oe}){let l=h.length,v=Math.max(l-1,0),Q=(r=>Math.min(Math.max(r,0),v))(_??V??Math.floor(v/2)),[k,$]=(0,u.useState)(Q),[se,ue]=(0,u.useState)(1),[X,q]=(0,u.useState)(1),Z=(0,u.useRef)(null),B=(0,u.useRef)([]),f=(0,u.useRef)({pos:Q,target:Q,vel:0,raf:0,last:0,active:Q}),o=(0,u.useRef)({angle:U,scale:X,itemWidth:j,onIndexChange:H,sound:J,count:l});o.current={angle:U,scale:X,itemWidth:j,onIndexChange:H,sound:J,count:l};let g=(0,u.useRef)(!1);(0,u.useEffect)(()=>{let r=window.matchMedia("(prefers-reduced-motion: reduce)");g.current=r.matches;let e=()=>g.current=r.matches;return r.addEventListener("change",e),()=>r.removeEventListener("change",e)},[]);let N=(0,u.useRef)(null),z=()=>{let r=N.current;if(!r||r.state!=="running")return;let e=r.currentTime,t=r.createOscillator(),i=r.createGain();t.type="triangle",t.frequency.setValueAtTime(2200,e),t.frequency.exponentialRampToValueAtTime(900,e+.03),i.gain.setValueAtTime(1e-4,e),i.gain.exponentialRampToValueAtTime(.05,e+.004),i.gain.exponentialRampToValueAtTime(1e-4,e+.045),t.connect(i).connect(r.destination),t.start(e),t.stop(e+.05)},W=()=>{var e;if(!o.current.sound)return;let r=window.AudioContext??window.webkitAudioContext;!N.current&&r&&(N.current=new r),((e=N.current)==null?void 0:e.state)==="suspended"&&N.current.resume()};(0,u.useEffect)(()=>()=>{var r;return void((r=N.current)==null?void 0:r.close())},[]);let y=(0,u.useCallback)(()=>{var M,ee;let{pos:r}=f.current,{angle:e,scale:t,itemWidth:i}=o.current,n=i*.78*t,c=i*.27*t,d=i*.7*t;B.current.forEach((A,C)=>{if(!A)return;let S=C-r,I=Math.abs(S);if(I>8){A.style.visibility="hidden";return}let R=Math.min(I,1),F=Math.sign(S),ae=F*(R*n+Math.max(I-1,0)*c);A.style.visibility="";let le=1-R*.08-Math.min(Math.max(I-1,0),4)*.015;A.style.transform=`translate3d(${ae}px, 0, ${-R*d}px) rotateY(${-F*R*e}deg) scale(${le.toFixed(4)})`,A.style.zIndex=String(1e3-Math.round(I*10)),A.style.setProperty("--ui-cf-t",R.toFixed(3)),A.style.setProperty("--ui-cf-d",Math.min(Math.max(S,-1.5),1.5).toFixed(3)),A.dataset.side=S<0?"left":"right"});let b=Math.round(Math.min(Math.max(r,0),o.current.count-1));b!==f.current.active&&(ue(b>f.current.active?1:-1),f.current.active=b,$(b),(ee=(M=o.current).onIndexChange)==null||ee.call(M,b),z())},[]),x=(0,u.useCallback)(()=>{let r=f.current;if(r.raf)return;r.last=performance.now();let e=t=>{let i=Math.min(t-r.last,32)/1e3;r.last=t;let n=2*Math.sqrt(190)*.92;if(r.vel+=(190*(r.target-r.pos)-n*r.vel)*i,r.pos+=r.vel*i,Math.abs(r.target-r.pos)<6e-4&&Math.abs(r.vel)<.002){r.pos=r.target,r.vel=0,r.raf=0,y();return}y(),r.raf=requestAnimationFrame(e)};r.raf=requestAnimationFrame(e)},[y]),p=(0,u.useCallback)(r=>{let e=f.current;e.target=Math.min(Math.max(Math.round(r),0),o.current.count-1),g.current?(e.pos=e.target,e.vel=0,y()):x()},[y,x]);(0,u.useEffect)(()=>()=>cancelAnimationFrame(f.current.raf),[]),(0,u.useEffect)(()=>{_!==void 0&&_!==Math.round(f.current.target)&&p(_)},[_,p]),(0,u.useEffect)(()=>{f.current.target>v?p(v):y()},[v,p,y]),(0,u.useLayoutEffect)(()=>{let r=Z.current;if(!r)return;let e=()=>q(Math.min(1,Math.max(.5,r.clientWidth/(j*3.2))));e();let t=new ResizeObserver(e);return t.observe(r),()=>t.disconnect()},[j]),(0,u.useLayoutEffect)(y);let m=(0,u.useRef)(0);(0,u.useEffect)(()=>{let r=Z.current;if(!r)return;let e=t=>{let i=t.shiftKey&&!t.deltaX?t.deltaY:t.deltaX;if(Math.abs(i)<=Math.abs(t.deltaY)&&!t.shiftKey)return;t.preventDefault(),W();let n=f.current,c=he*o.current.scale*1.4;n.target=Math.min(Math.max(n.target+i/c,-.35),o.current.count-1+.35),x(),window.clearTimeout(m.current),m.current=window.setTimeout(()=>p(n.target+Math.sign(i)*.3),110)};return r.addEventListener("wheel",e,{passive:!1}),()=>{r.removeEventListener("wheel",e),window.clearTimeout(m.current)}},[x,p]);let P=(0,u.useRef)(null),Y=r=>{if(r.button!==0)return;W();let e=r.target.closest("[data-cf-index]");P.current={id:r.pointerId,x:r.clientX,from:f.current.pos,moved:!1,hit:e?Number(e.dataset.cfIndex):null,samples:[{x:r.clientX,t:performance.now()}]}},fe=r=>{let e=P.current;if(!e||e.id!==r.pointerId)return;let t=r.clientX-e.x;if(!e.moved){if(Math.abs(t)<6)return;e.moved=!0,r.currentTarget.setPointerCapture(r.pointerId),r.currentTarget.dataset.dragging=""}let i=f.current;cancelAnimationFrame(i.raf),i.raf=0;let n=e.from-t/(he*o.current.scale),c=o.current.count-1;n<0&&(n*=.3),n>c&&(n=c+(n-c)*.3),i.pos=i.target=n,i.vel=0,e.samples.push({x:r.clientX,t:performance.now()}),e.samples.length>6&&e.samples.shift(),y()},te=r=>{let e=P.current;if(!e||e.id!==r.pointerId)return;if(P.current=null,delete r.currentTarget.dataset.dragging,!e.moved){if(e.hit===null)return;e.hit===Math.round(f.current.target)?w==null||w(h[e.hit],e.hit):p(e.hit);return}let t=e.samples[0],i=e.samples[e.samples.length-1],n=Math.max(i.t-t.t,1),c=-((i.x-t.x)/n)*1e3/(he*o.current.scale),d=f.current;d.vel=g.current?0:c;let b=Math.round(d.pos+c*.18);Math.abs(c)>.8&&b===Math.round(e.from)&&(b+=Math.sign(c)),p(b)},re=r=>{let e=Math.round(f.current.target),t={ArrowLeft:e-1,ArrowRight:e+1,Home:0,End:v};r.key in t?(r.preventDefault(),W(),p(t[r.key])):(r.key==="Enter"||r.key===" ")&&w&&r.target===r.currentTarget&&(r.preventDefault(),w(h[e],e))},T=h[k],E=Math.round(j*X),de=Math.round(ne*X),ie=(r,e=!1)=>a.jsx("div",{className:"ui-cf__media",children:r.cover??(r.image?a.jsx("img",{src:r.image,alt:e?"":r.alt??r.title??"",draggable:!1,loading:"lazy",decoding:"async",onError:t=>t.currentTarget.style.visibility="hidden"}):null)});return a.jsxs("div",{className:["ui-cf",oe].filter(Boolean).join(" "),style:{"--ui-cf-w":`${E}px`,"--ui-cf-h":`${de}px`},"data-reflection":G||void 0,children:[a.jsx("style",{href:"ui-cover-flow",precedence:"default",children:ke}),a.jsx("div",{ref:Z,className:"ui-cf__viewport",role:"region","aria-roledescription":"carousel","aria-label":ce,tabIndex:0,onKeyDown:re,onPointerDown:Y,onPointerMove:fe,onPointerUp:te,onPointerCancel:te,"data-selectable":w?"":void 0,children:a.jsx("div",{className:"ui-cf__stage",style:{perspective:`${Math.round(1e3*X)}px`},children:h.map((r,e)=>a.jsxs("div",{ref:(t=>{B.current[e]=t}),className:"ui-cf__item","data-cf-index":e,"data-active":e===k||void 0,role:"group","aria-roledescription":"slide","aria-label":`${e+1} of ${l}${r.title?`: ${r.title}`:""}`,"aria-hidden":e!==k||void 0,children:[a.jsx("div",{className:"ui-cf__ground","aria-hidden":"true"}),a.jsx("div",{className:"ui-cf__card",children:ie(r)}),G&&a.jsx("div",{className:"ui-cf__reflection","aria-hidden":"true",inert:!0,children:a.jsx("div",{className:"ui-cf__card",children:ie(r,!0)})})]},r.id))})}),(K||L||D)&&a.jsxs("div",{className:"ui-cf__footer",children:[a.jsxs("div",{className:"ui-cf__row",children:[L&&a.jsx("button",{type:"button",className:"ui-cf__nav","aria-label":"Previous",disabled:k===0,onClick:()=>p(Math.round(f.current.target)-1),children:a.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("path",{d:"M10 3.5 5.5 8l4.5 4.5"})})}),K&&a.jsx("div",{className:"ui-cf__caption","aria-live":"polite",children:a.jsx("div",{className:"ui-cf__caption-in","data-dir":se>0?"next":"prev",children:T&&(O?O(T,k):a.jsxs(be.Fragment,{children:[T.title&&a.jsx("div",{className:"ui-cf__title",children:T.title}),T.subtitle&&a.jsx("div",{className:"ui-cf__subtitle",children:T.subtitle})]}))},T==null?void 0:T.id)}),L&&a.jsx("button",{type:"button",className:"ui-cf__nav","aria-label":"Next",disabled:k===v,onClick:()=>p(Math.round(f.current.target)+1),children:a.jsx("svg",{viewBox:"0 0 16 16","aria-hidden":"true",children:a.jsx("path",{d:"M6 3.5 10.5 8 6 12.5"})})})]}),D&&l>15&&a.jsxs("div",{className:"ui-cf__counter","aria-hidden":"true",children:[k+1," / ",l]}),D&&l>1&&l<=15&&a.jsx("div",{className:"ui-cf__ticks",children:h.map((r,e)=>a.jsx("button",{type:"button",tabIndex:-1,className:"ui-cf__tick","aria-label":`Show ${r.title??`cover ${e+1}`}`,"aria-current":e===k||void 0,onClick:()=>p(e)},r.id))})]})]})}var ke=`
.ui-cf {
  --ui-cf-ink: #171717;
  --ui-cf-muted: #8a8a8a;
  --ui-cf-card: #f1f1f1;
  --ui-cf-edge: rgba(0, 0, 0, 0.08);
  --ui-cf-dim: rgba(255, 255, 255, 0.24);
  --ui-cf-shadow: 0 1px 2px rgba(0, 0, 0, 0.05), 0 10px 20px -12px rgba(0, 0, 0, 0.18);
  --ui-cf-reflect: 0.22;
  --ui-cf-ground: rgba(0, 0, 0, 0.16);
  --ui-cf-tick: rgba(0, 0, 0, 0.16);
  --ui-cf-nav: #ffffff;
  --ui-cf-nav-line: #e7e7e7;
  --ui-cf-focus: rgba(23, 23, 23, 0.25);
  --ui-cf-ease: cubic-bezier(0.22, 1, 0.36, 1);
  display: grid;
  gap: 4px;
  width: 100%;
  min-width: 0;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  -webkit-font-smoothing: antialiased;
}

/* Soft fade on both sides, so the stacks run out instead of being cut off */
.ui-cf__viewport {
  position: relative;
  overflow: hidden;
  padding: calc(var(--ui-cf-h) * 0.08) 0 0;
  height: calc(var(--ui-cf-h) * 1.08);
  border-radius: 12px;
  outline: none;
  cursor: grab;
  touch-action: pan-y;
  user-select: none;
  -webkit-user-select: none;
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 9%, #000 91%, transparent);
  mask-image: linear-gradient(90deg, transparent, #000 9%, #000 91%, transparent);
}
.ui-cf[data-reflection] .ui-cf__viewport { height: calc(var(--ui-cf-h) * 1.4); }
.ui-cf__viewport[data-dragging] { cursor: grabbing; }
.ui-cf__viewport:focus-visible .ui-cf__item[data-active] .ui-cf__card {
  box-shadow: var(--ui-cf-shadow), 0 0 0 3px var(--ui-cf-focus);
}

.ui-cf__stage {
  position: relative;
  height: var(--ui-cf-h);
  transform-style: preserve-3d;
}
.ui-cf__item {
  position: absolute;
  top: 0;
  left: 50%;
  width: var(--ui-cf-w);
  height: var(--ui-cf-h);
  margin-left: calc(var(--ui-cf-w) / -2);
  transform-style: preserve-3d;
  will-change: transform;
}
.ui-cf__viewport[data-selectable] .ui-cf__item[data-active] { cursor: pointer; }
.ui-cf__card {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-cf-card);
  box-shadow: var(--ui-cf-shadow);
}
.ui-cf__media {
  position: absolute;
  inset: 0 -8%;
  transform: translateX(calc(var(--ui-cf-d, 0) * -5%));
}
.ui-cf__media > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  pointer-events: none;
}
/* A soft shadow on the floor that fades as a cover turns away */
.ui-cf__ground {
  position: absolute;
  left: 10%;
  right: 10%;
  bottom: -3px;
  height: 8px;
  border-radius: 50%;
  background: var(--ui-cf-ground);
  filter: blur(5px);
  opacity: calc(1 - var(--ui-cf-t, 0) * 0.7);
  pointer-events: none;
}
/* Hairline edge, a dim that grows as a cover turns away, and a sheen on the side facing the light */
.ui-cf__card::before,
.ui-cf__card::after {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
}
.ui-cf__card::before {
  z-index: 2;
  box-shadow: inset 0 0 0 1px var(--ui-cf-edge);
  background: linear-gradient(90deg, rgba(255, 255, 255, 0.22), transparent 45%);
  opacity: calc(var(--ui-cf-t, 0) * 0.9);
}
.ui-cf__item[data-side="right"] .ui-cf__card::before {
  background: linear-gradient(270deg, rgba(255, 255, 255, 0.22), transparent 45%);
}
.ui-cf__card::after {
  z-index: 1;
  background: var(--ui-cf-dim);
  opacity: var(--ui-cf-t, 0);
}

/* The floor: a flipped copy that fades out – a mask, so it works on any background */
.ui-cf__reflection {
  position: absolute;
  top: 100%;
  left: 0;
  width: 100%;
  height: 32%;
  margin-top: 2px;
  overflow: hidden;
  pointer-events: none;
  -webkit-mask-image: linear-gradient(to bottom, rgba(0, 0, 0, var(--ui-cf-reflect)), transparent 85%);
  mask-image: linear-gradient(to bottom, rgba(0, 0, 0, var(--ui-cf-reflect)), transparent 85%);
}
.ui-cf__reflection > .ui-cf__card {
  height: var(--ui-cf-h);
  transform: scaleY(-1);
  transform-origin: 50% calc(var(--ui-cf-h) / 2);
  box-shadow: none;
}
.ui-cf__reflection > .ui-cf__card {
  position: absolute;
  bottom: auto;
  top: 0;
}

/* Caption with previous / next on either side, position ticks below */
.ui-cf__footer {
  position: relative;
  z-index: 1;
  display: grid;
  justify-items: center;
  gap: 14px;
  margin-top: calc(var(--ui-cf-h) * -0.04);
}
.ui-cf:not([data-reflection]) .ui-cf__footer { margin-top: 12px; }
.ui-cf__row {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 20px;
  min-height: 44px;
}
.ui-cf__counter { color: var(--ui-cf-muted); font-size: 12px; line-height: 14px; font-variant-numeric: tabular-nums; }
.ui-cf__ticks {
  display: flex;
  align-items: center;
  gap: 2px;
}
.ui-cf__tick {
  display: grid;
  place-items: center;
  width: 14px;
  height: 14px;
  padding: 0;
  border: 0;
  background: none;
  cursor: pointer;
}
.ui-cf__tick::before {
  content: "";
  width: 5px;
  height: 5px;
  border-radius: 999px;
  background: var(--ui-cf-tick);
  transition: width 320ms var(--ui-cf-ease), background-color 200ms ease;
}
.ui-cf__tick[aria-current]::before {
  width: 14px;
  background: var(--ui-cf-ink);
}
.ui-cf__tick:hover::before { background: var(--ui-cf-muted); }
.ui-cf__tick[aria-current]:hover::before { background: var(--ui-cf-ink); }
.ui-cf__caption {
  display: grid;
  min-width: min(220px, 50vw);
  text-align: center;
}
.ui-cf__caption-in { animation: ui-cf-in 420ms var(--ui-cf-ease) both; }
.ui-cf__caption-in[data-dir="prev"] { animation-name: ui-cf-in-prev; }
.ui-cf__title {
  color: var(--ui-cf-ink);
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.01em;
  line-height: 1.35;
}
.ui-cf__subtitle {
  color: var(--ui-cf-muted);
  font-size: 13px;
  line-height: 1.4;
}
.ui-cf__nav {
  display: grid;
  place-items: center;
  flex: none;
  width: 32px;
  height: 32px;
  padding: 0;
  border: 0;
  border-radius: 999px;
  background: var(--ui-cf-nav);
  box-shadow: inset 0 0 0 1px var(--ui-cf-nav-line), 0 1px 2px rgba(0, 0, 0, 0.05);
  color: var(--ui-cf-ink);
  cursor: pointer;
  transition: transform 160ms var(--ui-cf-ease), opacity 160ms ease;
}
.ui-cf__nav:active { transform: scale(0.92); }
.ui-cf__nav:disabled { opacity: 0.35; cursor: default; transform: none; }
.ui-cf__nav:focus-visible { outline: 2px solid var(--ui-cf-focus); outline-offset: 2px; }
.ui-cf__nav svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.7;
  stroke-linecap: round;
  stroke-linejoin: round;
}
@media (pointer: coarse) {
  .ui-cf__nav { width: 40px; height: 40px; }
}

/* The caption rises in from the direction of travel */
@keyframes ui-cf-in {
  from { opacity: 0; transform: translate(14px, 4px); filter: blur(3px); }
  to { opacity: 1; transform: none; filter: none; }
}
@keyframes ui-cf-in-prev {
  from { opacity: 0; transform: translate(-14px, 4px); filter: blur(3px); }
  to { opacity: 1; transform: none; filter: none; }
}

@media (prefers-reduced-motion: reduce) {
  .ui-cf__caption-in { animation: none; }
  .ui-cf__media { transform: none; }
  .ui-cf__tick::before { transition: none; }
  .ui-cf__nav { transition: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-cf {
  --ui-cf-ink: #ededed;
  --ui-cf-muted: #8f8f8f;
  --ui-cf-card: #1d1d20;
  --ui-cf-edge: rgba(255, 255, 255, 0.1);
  --ui-cf-dim: rgba(0, 0, 0, 0.5);
  --ui-cf-shadow: 0 1px 2px rgba(0, 0, 0, 0.3), 0 12px 24px -14px rgba(0, 0, 0, 0.6);
  --ui-cf-reflect: 0.3;
  --ui-cf-ground: rgba(0, 0, 0, 0.45);
  --ui-cf-tick: rgba(255, 255, 255, 0.2);
  --ui-cf-nav: #1d1d20;
  --ui-cf-nav-line: rgba(255, 255, 255, 0.1);
  --ui-cf-focus: rgba(255, 255, 255, 0.35);
}
`,ye=[["Stone","#f4f4f5","#d4d4d8"],["Mint","#f0fbf7","#b6e4d3"],["Sky","#eff6ff","#bcd6fb"],["Sage","#f0f7f2","#bfdcc8"],["Blush","#fdf2f8","#f5b5d6"],["Sand","#fdfaf3","#ead9b8"],["Lilac","#f5f3ff","#cdc3f5"],["Ice","#f0faff","#b8e0f0"],["Peach","#fff7ed","#f6c9a4"],["Mist","#f8fafc","#cbd5e1"]].map(([h,_,V])=>({id:h,title:h,subtitle:`${_} → ${V}`.toUpperCase(),cover:a.jsx("div",{className:"cf-demo__gradient",style:{background:`linear-gradient(160deg, ${_}, ${V})`}})}));function Me(){return a.jsx("div",{className:"cf-demo",children:a.jsx(we,{items:ye,defaultIndex:4,itemWidth:240,itemHeight:320,"aria-label":"Gradient collection"})})}const je=`.cf-demo{grid-template-columns:minmax(0,1fr);width:100%;max-width:980px;margin:0 auto;display:grid}.cf-demo__gradient{width:100%;height:100%}.card__preview .cf-demo{place-content:center;max-width:none;padding-top:26px;position:absolute;inset:0}.card__preview .cf-demo .ui-cf{zoom:.62;pointer-events:none}.card__preview .cf-demo .ui-cf__footer{display:none}.stage:has(.cf-demo){height:580px;padding-left:0;padding-right:0}@media (width<=760px){.stage:has(.cf-demo){height:520px}}
`;function Re(){return a.jsxs(a.Fragment,{children:[a.jsx("style",{children:je}),a.jsx(Me,{})]})}export{Ae as CoverFlow,Re as Preview,Re as default};
