import{j as o}from"./workbench-model-BwgilGut.js";import{E as t}from"./index-AVIOlmcx.js";import{w as r}from"./preview-CHHlf7B_.js";const m=r(t);function i(){return o.jsx(m,{})}export{i as default};
