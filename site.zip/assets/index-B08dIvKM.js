import{j as s}from"./workbench-model-BwgilGut.js";import{c as o,T as e}from"./toast-store-OVaeSbB0.js";const t=o(),u=t.api,a=`
.ui-ts {
  --ui-ts-card: #ffffff;
  --ui-ts-line: #ececec;
  --ui-ts-ink: #171717;
  --ui-ts-text: #404040;
  --ui-ts-muted: #626873;
  --ui-ts-faint: #b5b5b5;
  --ui-ts-button: #f0f0f0;
  --ui-ts-button-hover: #e6e6e7;
  --ui-ts-hairline: rgba(23, 23, 23, 0.14);
  --ui-ts-success: #237843;
  --ui-ts-danger: #bf383d;
  --ui-ts-shadow:
    0 0 0 1px var(--ui-ts-line), 0 1px 2px rgba(0, 0, 0, 0.04),
    0 8px 24px -6px rgba(0, 0, 0, 0.1);
  --ui-ts-focus: rgba(0, 96, 226, 0.7);
  --ui-ts-ease: cubic-bezier(0.22, 1, 0.36, 1);
  --ui-ts-width: 356px;
  --ui-ts-offset: 24px;
  position: fixed;
  z-index: 9999;
  box-sizing: border-box;
  width: var(--ui-ts-width);
  max-width: calc(100% - 2 * var(--ui-ts-offset));
  margin: 0;
  padding: 0;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13.5px;
  line-height: 1.45;
  color: var(--ui-ts-text);
  -webkit-font-smoothing: antialiased;
  outline: none;
}
.ui-ts[data-inline] {
  position: absolute;
  z-index: 20;
  --ui-ts-offset: 20px;
}
.ui-ts[data-empty] {
  pointer-events: none;
}
.ui-ts *,
.ui-ts *::before,
.ui-ts *::after {
  box-sizing: border-box;
}
:where(.ui-ts) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-ts) svg {
  display: block;
  flex: none;
}
.ui-ts button:focus-visible {
  outline: 2px solid var(--ui-ts-focus);
  outline-offset: 2px;
}
.ui-ts[data-y="bottom"] {
  bottom: var(--ui-ts-offset);
}
.ui-ts[data-y="top"] {
  top: var(--ui-ts-offset);
}
.ui-ts[data-x="right"] {
  right: var(--ui-ts-offset);
}
.ui-ts[data-x="left"] {
  left: var(--ui-ts-offset);
}
.ui-ts[data-x="center"] {
  left: 50%;
  transform: translateX(-50%);
}
.ui-ts:not([data-inline])[data-y="bottom"] {
  bottom: max(var(--ui-ts-offset), env(safe-area-inset-bottom));
}
.ui-ts__list {
  position: relative;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ts__toast {
  position: absolute;
  left: 0;
  right: 0;
  outline: none;
  touch-action: none;
  -webkit-user-select: none;
  user-select: none;
  transition:
    transform 440ms var(--ui-ts-ease),
    opacity 320ms ease,
    height 380ms var(--ui-ts-ease);
}
.ui-ts[data-y="bottom"] .ui-ts__toast {
  bottom: 0;
  transform-origin: 50% 0;
}
.ui-ts[data-y="top"] .ui-ts__toast {
  top: 0;
  transform-origin: 50% 100%;
}
.ui-ts__toast[data-removing] {
  pointer-events: none;
  transition:
    transform 380ms var(--ui-ts-ease),
    opacity 260ms ease,
    height 380ms var(--ui-ts-ease);
}
.ui-ts__swipe {
  position: relative;
  height: 100%;
  transition:
    transform 460ms cubic-bezier(0.34, 1.3, 0.64, 1),
    opacity 260ms ease;
}
.ui-ts__toast[data-swiping] {
  cursor: grabbing;
}
.ui-ts__card {
  position: relative;
  height: 100%;
  overflow: hidden;
  border-radius: 14px;
  background: var(--ui-ts-card);
  box-shadow: var(--ui-ts-shadow);
}
.ui-ts__toast:focus-visible .ui-ts__card {
  outline: 2px solid var(--ui-ts-focus);
  outline-offset: 2px;
}
.ui-ts__content {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 14px;
  transition: opacity 260ms ease;
}
.ui-ts__content[data-action] {
  padding-right: 10px;
}
.ui-ts__toast[data-behind] .ui-ts__content,
.ui-ts__toast[data-behind] .ui-ts__timer {
  opacity: 0;
}
.ui-ts__text {
  position: relative;
  flex: 1;
  min-width: 0;
}
.ui-ts__title {
  color: var(--ui-ts-ink);
  font-weight: 500;
  line-height: 20px;
  overflow-wrap: anywhere;
}
.ui-ts__desc {
  margin-top: 1px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ts-muted);
  overflow-wrap: anywhere;
}
.ui-ts__copy[data-changed] {
  animation: ui-ts-text-in 300ms var(--ui-ts-ease) both;
}
.ui-ts__ghost {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  pointer-events: none;
  animation: ui-ts-text-out 220ms ease both;
}
.ui-ts__icon {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  color: var(--ui-ts-muted);
  transition: color 300ms ease;
}
.ui-ts__icon[data-type="success"] {
  color: var(--ui-ts-success);
}
.ui-ts__icon[data-type="error"] {
  color: var(--ui-ts-danger);
}
.ui-ts__icon[data-type="info"] {
  color: var(--ui-ts-ink);
}
.ui-ts__icon[data-type="custom"] {
  overflow: hidden;
}
.ui-ts__icon[data-type="custom"] > * {
  width: 18px;
  height: 18px;
  object-fit: contain;
}
.ui-ts__status {
  width: 18px;
  height: 18px;
  overflow: visible;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-ts__icon[data-type="success"] .ui-ts__status,
.ui-ts__icon[data-type="error"] .ui-ts__status {
  animation: ui-ts-pop 460ms cubic-bezier(0.34, 1.56, 0.64, 1) both;
}
.ui-ts__spin {
  transform-box: fill-box;
  transform-origin: center;
  animation: ui-ts-spin 760ms linear infinite;
  animation-play-state: paused;
}
.ui-ts__icon[data-type="loading"] .ui-ts__spin {
  animation-play-state: running;
}
.ui-ts__ring {
  stroke-dasharray: 1 0;
  stroke-opacity: 0.28;
  transition:
    stroke-dasharray 560ms var(--ui-ts-ease),
    stroke-opacity 360ms ease;
}
.ui-ts__icon[data-type="loading"] .ui-ts__ring {
  stroke-dasharray: 0.28 0.72;
  stroke-opacity: 1;
}
.ui-ts__mark {
  stroke-dasharray: 1;
  stroke-dashoffset: 1;
  opacity: 0;
}
.ui-ts__info {
  opacity: 0;
  transition: opacity 240ms ease;
}
.ui-ts__icon[data-type="success"] .ui-ts__check,
.ui-ts__icon[data-type="error"] .ui-ts__x1,
.ui-ts__icon[data-type="error"] .ui-ts__x2 {
  opacity: 1;
  stroke-dashoffset: 0;
  animation: ui-ts-draw 340ms var(--ui-ts-ease) 160ms both;
}
.ui-ts__icon[data-type="error"] .ui-ts__x2 {
  animation-delay: 260ms;
}
.ui-ts__icon[data-type="info"] .ui-ts__info {
  opacity: 1;
}
.ui-ts__action {
  flex: none;
  align-self: center;
  height: 28px;
  margin: -4px 0;
  padding: 0 10px;
  border-radius: 8px;
  background: var(--ui-ts-button);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-ts-ink);
  white-space: nowrap;
  transition: background-color 160ms ease;
}
.ui-ts__action {
  flex: 0 1 auto;
  min-width: 0;
  max-width: 50%;
}
.ui-ts__action-label {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.ui-ts__action:hover {
  background: var(--ui-ts-button-hover);
}
.ui-ts__close {
  position: absolute;
  top: -7px;
  left: -7px;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 50%;
  background: var(--ui-ts-card);
  box-shadow:
    0 0 0 1px var(--ui-ts-line),
    0 1px 3px rgba(0, 0, 0, 0.08);
  color: var(--ui-ts-muted);
  opacity: 0;
  transform: scale(0.8);
  transition:
    opacity 160ms ease,
    transform 200ms var(--ui-ts-ease),
    color 160ms ease;
}
.ui-ts__close::before {
  content: "";
  position: absolute;
  inset: -6px;
}
.ui-ts__close:hover {
  color: var(--ui-ts-ink);
}
.ui-ts__toast:not([data-behind]):hover .ui-ts__close,
.ui-ts__toast:not([data-behind]):focus-within .ui-ts__close {
  opacity: 1;
  transform: none;
}
.ui-ts__glyph {
  width: 12px;
  height: 12px;
  fill: none;
  stroke: currentColor;
  stroke-width: 2;
  stroke-linecap: round;
}
.ui-ts__timer {
  position: absolute;
  left: 14px;
  right: 14px;
  bottom: 0;
  height: 1px;
  background: var(--ui-ts-hairline);
  transform-origin: left;
  animation-name: ui-ts-timer;
  animation-timing-function: linear;
  animation-fill-mode: both;
  transition: opacity 260ms ease;
}
.ui-ts__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
@keyframes ui-ts-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-ts-draw {
  from {
    stroke-dashoffset: 1;
  }
  to {
    stroke-dashoffset: 0;
  }
}
@keyframes ui-ts-pop {
  0% {
    transform: scale(0.82);
  }
  55% {
    transform: scale(1.08);
  }
  100% {
    transform: scale(1);
  }
}
@keyframes ui-ts-timer {
  from {
    transform: scaleX(1);
  }
  to {
    transform: scaleX(0);
  }
}
@keyframes ui-ts-text-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(3px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-ts-text-out {
  from {
    opacity: 1;
  }
  to {
    opacity: 0;
    transform: translateY(-4px);
    filter: blur(3px);
  }
}
@media (max-width: 600px) {
  .ui-ts,
  .ui-ts[data-x] {
    left: 12px;
    right: 12px;
    width: auto;
    max-width: none;
    transform: none;
  }
  .ui-ts[data-y="bottom"] {
    bottom: 12px;
  }
  .ui-ts:not([data-inline])[data-y="bottom"] {
    bottom: max(12px, env(safe-area-inset-bottom));
  }
  .ui-ts[data-y="top"] {
    top: 12px;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-ts__toast:not([data-behind]) .ui-ts__close {
    opacity: 1;
    transform: none;
  }
  .ui-ts__close {
    width: 24px;
    height: 24px;
    top: -8px;
    left: -8px;
  }
  .ui-ts__close::before {
    inset: -8px;
  }
  .ui-ts__action {
    height: 36px;
    margin: -8px -2px -8px 0;
    padding: 0 14px;
    border-radius: 10px;
    font-size: 13px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ts *:not(.ui-ts__spin):not(.ui-ts__timer),
  .ui-ts *::before,
  .ui-ts *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ts {
  --ui-ts-card: #19191b;
  --ui-ts-line: #2a2a2e;
  --ui-ts-ink: #ededed;
  --ui-ts-text: #c8c8cc;
  --ui-ts-muted: #8b8b92;
  --ui-ts-faint: #5c5c63;
  --ui-ts-button: #26262a;
  --ui-ts-button-hover: #2e2e33;
  --ui-ts-hairline: rgba(255, 255, 255, 0.16);
  --ui-ts-success: #4cc38a;
  --ui-ts-danger: #ff6369;
  --ui-ts-shadow:
    0 0 0 1px var(--ui-ts-line), 0 1px 2px rgba(0, 0, 0, 0.3),
    0 10px 28px -6px rgba(0, 0, 0, 0.5);
  --ui-ts-focus: rgba(77, 141, 255, 0.8);
}
`;function p(i){return s.jsx(e,{...i,store:t,clean:!1,styles:a})}export{p as T,u as t};
