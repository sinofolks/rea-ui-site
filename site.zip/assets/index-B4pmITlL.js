import{j as i}from"./workbench-model-BwgilGut.js";import{A as e}from"./agent-handoff-DKdsXHxi.js";const t=`.ui-ah {
  --ui-ah-card: #ffffff;
  --ui-ah-strong: #171717;
  --ui-ah-ink: #171717;
  --ui-ah-text: #6b6b6b;
  --ui-ah-muted: #626873;
  --ui-ah-faint: #6b6b6b;
  --ui-ah-line: #ececec;
  --ui-ah-edge: #ececec;
  --ui-ah-well: #f5f5f5;
  --ui-ah-lane: #f0f0f0;
  --ui-ah-blue: #2a5ee5;
  --ui-ah-board-line: #ececec;
  --ui-ah-board-ink: #171717;
  --ui-ah-board-text: #6b6b6b;
  --ui-ah-board-green: #147a3f;
  --ui-ah-board-amber: #8f6100;
  --ui-ah-board-red: #e5484d;
  --ui-ah-shine: #d4d4d4;
  --ui-ah-kpi-shine: #a3a3a3;
  --ui-ah-link: #a9c2ff;
  --ui-ah-link-muted: #d6d6d6;
  --ui-ah-accent: #2a5ee5;
  --ui-ah-focus: rgba(0, 96, 226, 0.7);
  --ui-ah-accent-bg: #edf2ff;
  --ui-ah-glow: rgba(47, 107, 255, 0.45);
  --ui-ah-drop: #a9c2ff;
  --ui-ah-green: #1a7f45;
  --ui-ah-green-bg: #e6f6ec;
  --ui-ah-amber: #b45309;
  --ui-ah-amber-bg: #fdf3e1;
  --ui-ah-red: #be3f0b;
  --ui-ah-red-line: #f0a56d;
  --ui-ah-red-bg: #fdeee3;
  --ui-ah-tip: #171717;
  --ui-ah-lift: 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-ah-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-ah-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  min-width: 0;
  container: ui-ah / inline-size;
  padding: 8px 0 0;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  color: var(--ui-ah-text);
  letter-spacing: -0.006em;
  -webkit-font-smoothing: antialiased;
}
.ui-ah *,
.ui-ah *::before,
.ui-ah *::after {
  box-sizing: border-box;
}
.ui-ah :is(ol, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
:where(.ui-ah) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  letter-spacing: inherit;
  cursor: pointer;
}
.ui-ah button:focus-visible,
.ui-ah__agent:focus-visible {
  outline: 2px solid var(--ui-ah-focus);
  outline-offset: 2px;
}
.ui-ah__lines {
  position: absolute;
  inset: 0;
  z-index: 1;
  width: 100%;
  height: 100%;
  overflow: visible;
  pointer-events: none;
}
.ui-ah__top-layer {
  z-index: 3;
}
.ui-ah__line {
  fill: none;
  stroke: var(--ui-ah-link-muted);
  stroke-width: 1.5;
  stroke-linecap: round;
  transition: stroke 300ms ease;
}
.ui-ah__lines [data-passed] .ui-ah__line {
  stroke: var(--ui-ah-link);
}
.ui-ah__dot {
  fill: var(--ui-ah-card);
  stroke: var(--ui-ah-link-muted);
  stroke-width: 1.5;
  transition: stroke 300ms ease;
}
.ui-ah__dot[data-passed] {
  stroke: var(--ui-ah-link);
}
.ui-ah__flow {
  position: relative;
  z-index: 2;
  display: grid;
  grid-template-columns: repeat(calc(var(--n) * 2), minmax(0, 1fr));
  row-gap: 72px;
}
.ui-ah__agent {
  grid-column: var(--c) / span 2;
  justify-self: center;
  width: calc(100% - 16px);
  max-width: 300px;
  border-radius: 16px;
  background: var(--ui-ah-card);
  box-shadow:
    0 0 0 1px var(--ui-ah-edge),
    var(--ui-ah-lift);
}
.ui-ah__agent {
  grid-row: 1;
  display: grid;
  gap: 10px;
  padding: 14px 14px 12px;
  transition:
    box-shadow 200ms ease,
    transform 200ms var(--ui-ah-ease);
}
.ui-ah__agent[data-over],
.ui-ah[data-holding] .ui-ah__agent:not([data-blocked]):hover {
  box-shadow:
    0 0 0 1px var(--ui-ah-drop),
    0 12px 24px -12px rgba(0, 96, 226, 0.14);
  transform: translateY(-2px);
}
.ui-ah[data-holding] .ui-ah__agent {
  cursor: copy;
}
.ui-ah[data-carrying],
.ui-ah[data-carrying] * {
  cursor: grabbing !important;
  user-select: none;
}
.ui-ah__card-main[data-carried] {
  opacity: 0.4;
}
.ui-ah__ghost {
  position: absolute;
  z-index: 10;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px 10px 10px;
  border-radius: 12px;
  background: var(--ui-ah-card);
  box-shadow:
    0 0 0 1px var(--ui-ah-board-line),
    0 16px 32px -12px rgba(16, 16, 24, 0.3);
  pointer-events: none;
  transform: rotate(-2deg);
  animation: ui-ah-lift 160ms var(--ui-ah-ease) both;
}
.ui-ah__agent {
  transition:
    box-shadow 200ms ease,
    transform 200ms var(--ui-ah-ease),
    opacity 200ms ease;
}
.ui-ah__agent[data-blocked] {
  opacity: 0.45;
  cursor: not-allowed !important;
}
.ui-ah__top {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}
.ui-ah__face {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--ui-ah-card);
  box-shadow: var(--ui-ah-shadow);
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-ah-ink);
}
.ui-ah__face > img,
.ui-ah__col-face > img,
.ui-ah__logo > img,
.ui-ah__card-mark > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: inherit;
}
.ui-ah__face > svg {
  width: 14px;
  height: 14px;
}
.ui-ah__who {
  display: grid;
  flex: 1;
  min-width: 3em;
}
.ui-ah__agent {
  container: ui-ah-agent / inline-size;
}
@container ui-ah-agent (max-width: 200px) {
  .ui-ah__status-word {
    display: none;
  }
  .ui-ah__status {
    width: 20px;
    padding: 0;
    justify-content: center;
  }
  .ui-ah__status[data-status="idle"] {
    display: none;
  }
}
.ui-ah__name {
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 600;
  line-height: 18px;
  color: var(--ui-ah-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__desc {
  display: -webkit-box;
  height: 40px;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ah-text);
}
.ui-ah__model {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-ah-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__status {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 4px;
  height: 20px;
  padding: 0 6px;
  border-radius: 6px;
  background: var(--ui-ah-well);
  font-size: 11.5px;
  font-weight: 500;
  color: var(--ui-ah-muted);
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-ah__status > svg {
  width: 10px;
  height: 10px;
}
.ui-ah__status[data-status="working"] {
  background: var(--ui-ah-accent-bg);
  color: var(--ui-ah-accent);
}
.ui-ah__now {
  display: grid;
  align-items: center;
  min-width: 0;
  height: 34px;
  padding: 0 10px;
  overflow: hidden;
  border-radius: 10px;
  background: var(--ui-ah-lane);
  font-size: 13px;
}
.ui-ah__now > .ui-ah__swap > .ui-ah__swap-layer {
  display: flex;
  align-items: center;
  gap: 6px;
}
.ui-ah__swap {
  display: inline-grid;
  grid-template-columns: minmax(0, 1fr);
  align-items: center;
  min-width: 0;
  overflow: hidden;
}
.ui-ah__swap-layer {
  grid-area: 1 / 1;
  min-width: 0;
}
.ui-ah__swap-layer[data-leaving] {
  animation: ui-ah-swap-out 380ms var(--ui-ah-ease) both;
  pointer-events: none;
}
.ui-ah__swap-layer[data-coming] {
  animation: ui-ah-swap-in 380ms var(--ui-ah-ease) both;
}
.ui-ah__now-task {
  flex: none;
  max-width: 55%;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-ah-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__now-note {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__now-more {
  flex: none;
}
.ui-ah__now-idle {
  color: var(--ui-ah-faint);
}
.ui-ah__agent {
  position: relative;
  cursor: pointer;
}
.ui-ah:has(.ui-ah__agent[data-peek]) .ui-ah__flow {
  z-index: 4;
}
.ui-ah__agent[data-peek] {
  z-index: 1;
}
.ui-ah__peek {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  right: 0;
  z-index: 2;
  display: grid;
  gap: 2px;
  padding: 12px;
  border-radius: 18px;
  background: var(--ui-ah-card);
  box-shadow:
    0 0 0 1px var(--ui-ah-edge),
    0 18px 40px -14px rgba(16, 16, 24, 0.28),
    0 4px 10px -4px rgba(16, 16, 24, 0.08);
  cursor: default;
  transform-origin: 50% 0;
  animation: ui-ah-peek 240ms var(--ui-ah-ease) both;
}
.ui-ah__peek-head {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  padding: 0 0 0 2px;
}
.ui-ah__peek-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-ah-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__peek-x {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  margin: -2px -2px -2px 0;
  border-radius: 7px;
  color: var(--ui-ah-faint);
  transition:
    background-color 150ms ease,
    color 150ms ease;
}
.ui-ah__peek-x:hover {
  background: var(--ui-ah-lane);
  color: var(--ui-ah-ink);
}
.ui-ah__peek-x > svg {
  width: 12px;
  height: 12px;
}
.ui-ah__peek-state {
  padding-left: 26px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ah-muted);
}
.ui-ah__peek-body {
  display: grid;
  gap: 6px;
  margin-top: 8px;
  padding: 10px;
  border-radius: 12px;
  background: var(--ui-ah-lane);
}
.ui-ah__peek-desc {
  margin: 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-ah-text);
}
.ui-ah__peek-label {
  margin-top: 4px;
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-ah-faint);
}
.ui-ah__tools {
  display: grid;
  gap: 2px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-ah__tool {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 28px;
  font-size: 13px;
  color: var(--ui-ah-ink);
  animation: ui-ah-in 260ms var(--ui-ah-ease) both;
}
.ui-ah__tool:nth-child(2) {
  animation-delay: 40ms;
}
.ui-ah__tool:nth-child(3) {
  animation-delay: 80ms;
}
.ui-ah__tool:nth-child(n + 4) {
  animation-delay: 120ms;
}
.ui-ah__tool-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__tool-detail {
  flex: none;
  max-width: 45%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ah-muted);
}
.ui-ah__cost {
  flex: none;
  font-size: 11.5px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-ah-muted);
}
.ui-ah__cost[data-live] {
  background: linear-gradient(
      90deg,
      var(--ui-ah-ink) 0%,
      var(--ui-ah-ink) 38%,
      var(--ui-ah-kpi-shine) 50%,
      var(--ui-ah-ink) 62%,
      var(--ui-ah-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-ah-shine 1500ms linear infinite;
}
.ui-ah__shine {
  background: linear-gradient(
      90deg,
      var(--ui-ah-muted) 0%,
      var(--ui-ah-muted) 38%,
      var(--ui-ah-shine) 50%,
      var(--ui-ah-muted) 62%,
      var(--ui-ah-muted) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-ah-shine 1500ms linear infinite;
}
.ui-ah__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-ah-card);
  box-shadow: var(--ui-ah-shadow);
  color: var(--ui-ah-faint);
}
.ui-ah__logo > svg {
  width: 10px;
  height: 10px;
}
.ui-ah__spin {
  animation: ui-ah-spin 900ms linear infinite;
}
.ui-ah__light {
  filter: drop-shadow(0 0 1.5px var(--ui-ah-glow));
}
.ui-ah__streak {
  --d: 48px;
  fill: none;
  stroke: var(--ui-ah-accent);
  stroke-width: 2;
  stroke-dasharray: 3.4px calc(var(--len) + var(--d) * 2);
  stroke-dashoffset: calc(var(--d) - var(--shift));
  opacity: 0;
  animation: ui-ah-streak 1000ms cubic-bezier(0.45, 0, 0.55, 1) both;
}
.ui-ah__streak[data-on] {
  animation-delay: 850ms;
}
.ui-ah__col {
  grid-column: var(--c) / span 2;
  grid-row: 2;
  justify-self: center;
  width: calc(100% - 16px);
  max-width: 360px;
  height: 228px;
  padding: 4px;
  overflow: hidden;
  border-radius: 16px;
  background: var(--ui-ah-lane);
  -webkit-mask-image: linear-gradient(
    180deg,
    #000 calc(100% - 64px),
    transparent
  );
  mask-image: linear-gradient(180deg, #000 calc(100% - 64px), transparent);
}
.ui-ah__col-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  height: 30px;
  padding: 0 6px 0 8px;
}
.ui-ah__col-who {
  display: flex;
  align-items: center;
  gap: 5px;
  min-width: 0;
  overflow: hidden;
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-ah-muted);
  white-space: nowrap;
}
.ui-ah__col-face {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  border-radius: 4px;
  background: var(--ui-ah-card);
  box-shadow: var(--ui-ah-shadow);
  font-size: 9px;
  color: var(--ui-ah-ink);
}
.ui-ah__col-name {
  min-width: 1.6em;
  max-width: 45%;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ah__col-face > svg {
  width: 10px;
  height: 10px;
}
.ui-ah__col-arrow {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  margin: 0 2px;
  color: var(--ui-ah-faint);
}
.ui-ah__col-arrow > svg {
  width: 12px;
  height: 12px;
}
.ui-ah__lane-n {
  display: grid;
  flex: none;
  place-items: center;
  min-width: 20px;
  height: 18px;
  padding: 0 5px;
  border-radius: 7px;
  background: rgba(16, 16, 24, 0.06);
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-ah-text);
  font-variant-numeric: tabular-nums;
}
.ui-ah__cards {
  display: grid;
  gap: 4px;
}
.ui-ah__lane-empty {
  padding: 18px 0 20px;
  font-size: 13px;
  text-align: center;
  color: var(--ui-ah-faint);
}
.ui-ah__none {
  margin: 0;
  padding: 24px 0;
  font-size: 12.5px;
  text-align: center;
  color: var(--ui-ah-faint);
}
.ui-ah__card {
  border-radius: 12px;
  background: var(--ui-ah-card);
  box-shadow:
    0 0 0 1px var(--ui-ah-board-line),
    0 1px 2px rgba(16, 16, 24, 0.04);
  animation: ui-ah-drop 420ms var(--ui-ah-ease) both;
  transition: box-shadow 200ms ease;
}
.ui-ah__card:hover,
.ui-ah__card[data-open] {
  box-shadow:
    0 0 0 1px #dcdce1,
    0 4px 14px -6px rgba(16, 16, 24, 0.12);
}
.ui-ah__card-main {
  display: grid;
  gap: 3px;
  width: 100%;
  padding: 9px 12px 9px 10px;
  border-radius: 12px;
  text-align: left;
  cursor: pointer;
}
.ui-ah__card-main[data-movable] {
  cursor: grab;
}
.ui-ah__card-main[data-movable]:active {
  cursor: grabbing;
}
.ui-ah__card-main[aria-pressed="true"] {
  box-shadow: 0 0 0 1.5px var(--ui-ah-link);
}
.ui-ah__card-top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-ah__card-mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 14px;
  height: 18px;
  color: var(--ui-ah-blue);
}
.ui-ah__card-mark > svg {
  width: 12px;
  height: 12px;
}
.ui-ah__card-title {
  min-width: 0;
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  color: var(--ui-ah-board-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__card-desc {
  padding-left: 22px;
  overflow: hidden;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-ah-board-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__card-foot {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 0;
  margin-top: 3px;
  padding-left: 22px;
}
.ui-ah__card-state {
  font-size: 13px;
  color: var(--ui-ah-board-text);
}
.ui-ah__card-state > .ui-ah__swap-layer {
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.ui-ah__card-word {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-ah__state-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 11px;
  height: 11px;
  color: var(--ui-ah-blue);
}
.ui-ah__state-icon > svg {
  width: 11px;
  height: 11px;
}
.ui-ah__state-icon[data-status="done"] {
  color: var(--ui-ah-board-green);
}
.ui-ah__state-icon[data-status="warning"] {
  color: var(--ui-ah-board-amber);
}
.ui-ah__fold {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 360ms var(--ui-ah-ease);
}
.ui-ah__fold[data-open] {
  grid-template-rows: 1fr;
}
.ui-ah__clip {
  min-height: 0;
  overflow: hidden;
}
.ui-ah__items {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  margin: 0 10px 10px !important;
  padding-top: 8px !important;
  border-top: 1px solid var(--ui-ah-board-line);
}
.ui-ah__item-wrap {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 4px;
  min-width: 0;
}
.ui-ah__item {
  display: flex;
  align-items: center;
  gap: 6px;
  width: 100%;
  height: 26px;
  padding: 0 8px;
  border-radius: 7px;
  background: var(--ui-ah-well);
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-ah-ink);
  text-align: left;
  white-space: nowrap;
  cursor: default;
}
.ui-ah__kind {
  display: grid;
  flex: none;
  place-items: center;
  width: 12px;
  height: 12px;
  color: var(--ui-ah-muted);
}
.ui-ah__kind > svg {
  width: 12px;
  height: 12px;
}
.ui-ah__label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-ah__item[data-lost] {
  background: var(--ui-ah-red-bg);
  box-shadow: inset 0 0 0 1px var(--ui-ah-red-line);
  color: var(--ui-ah-text);
  cursor: pointer;
}
.ui-ah__item[data-lost] .ui-ah__kind {
  color: var(--ui-ah-red);
}
.ui-ah__item[data-lost] .ui-ah__label {
  text-decoration: line-through;
  text-decoration-color: var(--ui-ah-red);
}
.ui-ah__why {
  display: grid;
  gap: 8px;
  padding: 9px 10px;
  border-radius: 10px;
  background: var(--ui-ah-tip);
  font-size: 13px;
  line-height: 18px;
  color: #ffffff;
  animation: ui-ah-fade 160ms ease both;
}
.ui-ah__restore {
  justify-self: start;
  height: 24px;
  padding: 0 9px;
  border-radius: 7px;
  background: rgba(255, 255, 255, 0.14);
  font-size: 13px;
  font-weight: 600;
  color: #ffffff;
}
.ui-ah__restore:hover {
  background: rgba(255, 255, 255, 0.22);
}
@container ui-ah (max-width: 760px) {
  .ui-ah__status-word {
    display: none;
  }
  .ui-ah__status {
    width: 20px;
    padding: 0;
    justify-content: center;
  }
  .ui-ah__status[data-status="idle"] {
    display: none;
  }
  .ui-ah__status > svg {
    margin: 0;
  }
}
@container ui-ah (max-width: 620px) {
  .ui-ah__flow {
    grid-template-columns: minmax(0, 1fr);
    row-gap: 12px;
  }
  .ui-ah__agent,
  .ui-ah__col {
    grid-column: 1;
    grid-row: auto;
    width: 100%;
    max-width: none;
  }
  .ui-ah__flow > * {
    order: var(--c);
  }
  .ui-ah__lines {
    display: none;
  }
  .ui-ah__col {
    width: calc(100% - 32px);
    height: 220px;
  }
}
@keyframes ui-ah-streak {
  0% {
    stroke-dashoffset: calc(var(--d) - var(--shift));
    opacity: 0;
  }
  12% {
    opacity: var(--o);
  }
  85% {
    opacity: var(--o);
  }
  100% {
    stroke-dashoffset: calc(var(--len) * -1 - var(--shift));
    opacity: 0;
  }
}
@keyframes ui-ah-drop {
  from {
    opacity: 0;
    transform: translateY(-6px) scale(0.97);
  }
}
@keyframes ui-ah-strike {
  to {
    background-size: 100% 1px;
    opacity: 0.6;
  }
}
@keyframes ui-ah-in {
  from {
    opacity: 0;
    transform: translateY(3px);
  }
}
@keyframes ui-ah-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-ah-lift {
  from {
    transform: none;
    box-shadow: 0 0 0 1px var(--ui-ah-board-line);
  }
}
@keyframes ui-ah-peek {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.97);
  }
}
@keyframes ui-ah-swap-in {
  from {
    opacity: 0;
    transform: translateY(70%);
    filter: blur(2px);
  }
}
@keyframes ui-ah-swap-out {
  to {
    opacity: 0;
    transform: translateY(-70%);
    filter: blur(2px);
  }
}
@keyframes ui-ah-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-ah-spin {
  to {
    transform: rotate(360deg);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-ah *,
  .ui-ah *::before,
  .ui-ah *::after {
    animation-duration: 1ms !important;
  }
  .ui-ah__streak {
    display: none;
  }
}
:where(.dark, [data-theme="dark"]) .ui-ah {
  --ui-ah-card: #232326;
  --ui-ah-strong: #f5f5f5;
  --ui-ah-ink: #f0f0f0;
  --ui-ah-text: #a1a1a1;
  --ui-ah-muted: #8a8a8a;
  --ui-ah-faint: #5c5c5c;
  --ui-ah-line: #2e2e31;
  --ui-ah-edge: #2e2e31;
  --ui-ah-well: #2c2c30;
  --ui-ah-lane: #1a1a1c;
  --ui-ah-blue: #6d93ff;
  --ui-ah-board-line: #2e2e31;
  --ui-ah-board-ink: #f0f0f0;
  --ui-ah-board-text: #a1a1a1;
  --ui-ah-board-green: #55d68c;
  --ui-ah-board-amber: #f2b33d;
  --ui-ah-board-red: #ff6369;
  --ui-ah-shine: #f5f5f5;
  --ui-ah-kpi-shine: #8a8a8a;
  --ui-ah-link: #6d93ff;
  --ui-ah-link-muted: #3a3a3e;
  --ui-ah-accent: #6d93ff;
  --ui-ah-focus: rgba(77, 141, 255, 0.8);
  --ui-ah-accent-bg: #1d2b4d;
  --ui-ah-glow: rgba(109, 147, 255, 0.5);
  --ui-ah-drop: #3c5fb3;
  --ui-ah-green: #55d68c;
  --ui-ah-green-bg: #15321f;
  --ui-ah-amber: #fbbf24;
  --ui-ah-amber-bg: #3a2a10;
  --ui-ah-red: #ffa057;
  --ui-ah-red-line: #b06a35;
  --ui-ah-red-bg: #432614;
  --ui-ah-tip: #fafafa;
  --ui-ah-lift: 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-ah-shadow: 0 0 0 1px #2e2e31, 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-ah__why {
  color: #111113;
}
:where(.dark, [data-theme="dark"]) .ui-ah__restore {
  background: rgba(0, 0, 0, 0.08);
  color: #111113;
}
`;function n(a){return i.jsx(e,{...a,clean:!1,styles:t})}export{n as A};
