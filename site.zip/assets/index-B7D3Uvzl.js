import{j as i}from"./workbench-model-BwgilGut.js";import{D as e}from"./date-range-picker-jNW1DZq-.js";const a=`.ui-drp {
  --ui-drp-tray: #f0f0f0;
  --ui-drp-card: #ffffff;
  --ui-drp-line: #ececec;
  --ui-drp-ink: #171717;
  --ui-drp-text: #404040;
  --ui-drp-muted: #626873;
  --ui-drp-faint: #6b6b6b;
  --ui-drp-hover: #f2f2f3;
  --ui-drp-active: #ebebed;
  --ui-drp-band: rgba(47, 107, 255, 0.1);
  --ui-drp-band-preview: rgba(47, 107, 255, 0.06);
  --ui-drp-accent: #2f6bff;
  --ui-drp-on-accent: #ffffff;
  --ui-drp-compare: #ececee;
  --ui-drp-compare-edge: #b9b9be;
  --ui-drp-focus: rgba(0, 96, 226, 0.7);
  --ui-drp-shadow:
    0 0 0 1px rgba(0, 0, 0, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.18),
    0 4px 12px -4px rgba(0, 0, 0, 0.06);
  --ui-drp-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 13px;
  line-height: 1.4;
  color: var(--ui-drp-text);
  -webkit-font-smoothing: antialiased;
}
.ui-drp *,
.ui-drp *::before,
.ui-drp *::after {
  box-sizing: border-box;
}
:where(.ui-drp) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  cursor: pointer;
}
:where(.ui-drp) svg {
  display: block;
  flex: none;
}
.ui-drp button:focus-visible {
  outline: 2px solid var(--ui-drp-focus);
  outline-offset: 2px;
}
.ui-drp__glyph {
  width: 16px;
  height: 16px;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}
.ui-drp__trigger {
  display: inline-flex;
  align-items: center;
  overflow: hidden;
  max-width: 100%;
  min-height: 38px;
  padding: 5px 9px 5px 11px;
  border-radius: 11px;
  background: var(--ui-drp-card);
  box-shadow:
    0 0 0 1px var(--ui-drp-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  text-align: left;
  transition:
    box-shadow 160ms ease,
    width 320ms var(--ui-drp-ease);
}
.ui-drp__trigger-inner {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 10px;
  max-width: calc(100vw - 56px);
}
.ui-drp__trigger:hover {
  box-shadow:
    0 0 0 1px var(--ui-drp-faint),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-drp__trigger > .ui-drp__glyph {
  color: var(--ui-drp-muted);
}
.ui-drp__trigger-text {
  display: grid;
  min-width: 0;
  animation: ui-drp-in 280ms var(--ui-drp-ease) both;
}
.ui-drp__trigger-range {
  overflow: hidden;
  color: var(--ui-drp-ink);
  font-weight: 500;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-drp__trigger-compare {
  overflow: hidden;
  font-size: 12px;
  color: var(--ui-drp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-drp__chevron {
  color: var(--ui-drp-muted);
  transition: transform 260ms var(--ui-drp-ease);
}
.ui-drp[data-open] .ui-drp__chevron {
  transform: rotate(180deg);
}
.ui-drp__panel {
  position: absolute;
  z-index: 30;
  top: calc(100% + 8px);
  left: 0;
  container-type: inline-size;
  width: var(--ui-drp-panel-width, min(652px, calc(100vw - 32px)));
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-drp-tray);
  box-shadow: var(--ui-drp-shadow);
  overflow: hidden;
  transform-origin: top left;
  transition: height 320ms var(--ui-drp-ease);
  animation: ui-drp-open 260ms var(--ui-drp-ease) both;
}
.ui-drp__pill {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 0;
  border-radius: 8px;
  background: var(--ui-drp-active);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 320ms var(--ui-drp-ease),
    width 320ms var(--ui-drp-ease),
    height 320ms var(--ui-drp-ease),
    opacity 200ms ease;
}
.ui-drp__body {
  display: grid;
  grid-template-columns: 136px 1fr;
  border-radius: 16px;
  background: var(--ui-drp-card);
  box-shadow: 0 0 0 1px var(--ui-drp-line);
}
.ui-drp__presets {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 1px;
  padding: 6px;
  border-right: 1px solid var(--ui-drp-line);
}
.ui-drp__preset {
  display: flex;
  align-items: center;
  height: 30px;
  padding: 0 10px;
  border-radius: 8px;
  text-align: left;
  white-space: nowrap;
  color: var(--ui-drp-text);
  position: relative;
  z-index: 1;
  transition:
    background-color 140ms ease,
    color 200ms ease;
}
.ui-drp__preset {
  max-width: 100%;
  min-width: 0;
}
.ui-drp__preset-label {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
button.ui-drp__preset:hover:not([aria-selected="true"]) {
  background: var(--ui-drp-hover);
  color: var(--ui-drp-ink);
}
.ui-drp__preset[aria-selected="true"],
.ui-drp__preset-custom[data-active] {
  color: var(--ui-drp-ink);
}
.ui-drp__preset-custom {
  margin-top: auto;
  color: var(--ui-drp-muted);
  cursor: default;
}
.ui-drp__cal {
  position: relative;
  padding: 12px 14px 10px;
  overflow: hidden;
}
.ui-drp__nav {
  position: absolute;
  top: 8px;
  left: 10px;
  right: 10px;
  z-index: 1;
  display: flex;
  justify-content: space-between;
  pointer-events: none;
}
.ui-drp__nav > * {
  pointer-events: auto;
}
.ui-drp__icon-btn {
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  color: var(--ui-drp-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease;
}
.ui-drp__icon-btn:hover {
  background: var(--ui-drp-hover);
  color: var(--ui-drp-ink);
}
.ui-drp__months {
  display: grid;
  grid-template-columns: repeat(2, auto);
  justify-content: center;
  gap: 24px;
  animation: ui-drp-slide 320ms var(--ui-drp-ease) both;
}
.ui-drp__months[data-dir="-1"] {
  animation-name: ui-drp-slide-back;
}
.ui-drp__month-name {
  height: 22px;
  margin-bottom: 6px;
  font-weight: 600;
  text-align: center;
  color: var(--ui-drp-ink);
}
.ui-drp__grid {
  display: grid;
  gap: 2px;
}
.ui-drp__weekdays,
.ui-drp__week {
  display: grid;
  grid-template-columns: repeat(7, 32px);
}
.ui-drp__weekday {
  height: 26px;
  font-size: 11px;
  font-weight: 500;
  line-height: 26px;
  text-align: center;
  color: var(--ui-drp-muted);
}
.ui-drp__day {
  position: relative;
  display: grid;
  height: 32px;
}
.ui-drp__day::before {
  content: "";
  position: absolute;
  inset: 2px 0;
  transition:
    background-color 220ms ease,
    border-radius 220ms var(--ui-drp-ease),
    left 220ms var(--ui-drp-ease),
    right 220ms var(--ui-drp-ease);
}
.ui-drp__day[data-range]::before {
  background: var(--ui-drp-band);
}
.ui-drp__day[data-preview]::before {
  background: var(--ui-drp-band-preview);
}
.ui-drp__day[data-compare]::before {
  background: var(--ui-drp-compare);
}
.ui-drp__day[data-start]::before,
.ui-drp__day[data-compare-start]::before,
.ui-drp__day[data-row-start]::before {
  left: 2px;
  border-top-left-radius: 9px;
  border-bottom-left-radius: 9px;
}
.ui-drp__day[data-end]::before,
.ui-drp__day[data-compare-end]::before,
.ui-drp__day[data-row-end]::before {
  right: 2px;
  border-top-right-radius: 9px;
  border-bottom-right-radius: 9px;
}
.ui-drp__day button {
  position: relative;
  border-radius: 9px;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-drp-ink);
  transition:
    background-color 200ms ease,
    color 200ms ease,
    box-shadow 200ms ease,
    transform 160ms var(--ui-drp-ease);
}
.ui-drp__day button:hover:not(:disabled) {
  background: var(--ui-drp-hover);
}
.ui-drp__day[data-range] button:hover:not(:disabled) {
  background: transparent;
  box-shadow: inset 0 0 0 1px var(--ui-drp-accent);
}
.ui-drp__day button:active:not(:disabled) {
  transform: scale(0.94);
}
.ui-drp__day button:disabled {
  color: var(--ui-drp-faint);
  cursor: default;
}
.ui-drp .ui-drp__day button:focus-visible {
  outline-offset: -2px;
}
.ui-drp__day button[aria-current="date"]::after {
  content: "";
  position: absolute;
  left: 50%;
  bottom: 4px;
  width: 3px;
  height: 3px;
  margin-left: -1.5px;
  border-radius: 50%;
  background: currentColor;
  opacity: 0.55;
}
.ui-drp__day[data-start] button,
.ui-drp__day[data-end] button {
  background: var(--ui-drp-accent) !important;
  color: var(--ui-drp-on-accent);
  font-weight: 600;
  box-shadow: none !important;
  animation: ui-drp-pick 380ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.ui-drp__day[data-preview][data-end] button {
  animation: none;
}
.ui-drp__day[data-compare-start] button,
.ui-drp__day[data-compare-end] button {
  box-shadow: inset 0 0 0 1px var(--ui-drp-compare-edge);
}
.ui-drp__day-empty::before {
  display: none;
}
.ui-drp__foot {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 14px;
  padding: 10px 10px 6px 10px;
}
.ui-drp__summary {
  display: grid;
  gap: 6px;
  min-width: 0;
}
.ui-drp__summary-range {
  display: flex;
  align-items: baseline;
  gap: 8px;
  color: var(--ui-drp-ink);
  font-weight: 500;
}
.ui-drp__summary-range > span:first-child {
  animation: ui-drp-in 280ms var(--ui-drp-ease) both;
}
.ui-drp__count {
  font-size: 12px;
  font-weight: 400;
  font-variant-numeric: tabular-nums;
  color: var(--ui-drp-muted);
  animation: ui-drp-in 280ms var(--ui-drp-ease) both;
}
.ui-drp__compare {
  display: flex;
  align-items: center;
  gap: 8px;
}
.ui-drp__compare-label {
  font-size: 12px;
  color: var(--ui-drp-muted);
}
.ui-drp__segments {
  position: relative;
  display: inline-flex;
  padding: 2px;
  border-radius: 9px;
  background: var(--ui-drp-card);
  box-shadow: 0 0 0 1px var(--ui-drp-line);
}
.ui-drp__segment {
  position: relative;
  z-index: 1;
  height: 24px;
  padding: 0 8px;
  border-radius: 7px;
  font-size: 12px;
  white-space: nowrap;
  color: var(--ui-drp-muted);
  transition: color 200ms ease;
}
.ui-drp__segment:hover {
  color: var(--ui-drp-ink);
}
.ui-drp__segment[aria-checked="true"] {
  color: var(--ui-drp-ink);
}
.ui-drp__segments .ui-drp__pill {
  border-radius: 7px;
}
.ui-drp__fold {
  display: grid;
  grid-template-rows: 0fr;
  opacity: 0;
  margin-top: -6px;
  transition:
    grid-template-rows 300ms var(--ui-drp-ease),
    opacity 200ms ease,
    margin-top 300ms var(--ui-drp-ease);
}
.ui-drp__fold[data-open] {
  grid-template-rows: 1fr;
  opacity: 1;
  margin-top: 0;
}
.ui-drp__fold > div {
  min-height: 0;
  overflow: hidden;
}
.ui-drp__compare-range {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: var(--ui-drp-muted);
  animation: ui-drp-in 220ms var(--ui-drp-ease) both;
}
.ui-drp__compare-range::before {
  content: "";
  width: 14px;
  height: 8px;
  border-radius: 3px;
  background: var(--ui-drp-compare);
  box-shadow: inset 0 0 0 1px var(--ui-drp-compare-edge);
}
.ui-drp__buttons {
  display: flex;
  flex: none;
  gap: 6px;
}
.ui-drp__btn {
  height: 32px;
  padding: 0 13px;
  border-radius: 9px;
  font-weight: 500;
  color: var(--ui-drp-text);
  transition:
    background-color 140ms ease,
    opacity 140ms ease,
    transform 140ms ease;
}
.ui-drp__btn:not(.ui-drp__btn-primary):hover {
  background: var(--ui-drp-active);
}
.ui-drp__btn-primary {
  background: var(--ui-drp-ink);
  color: var(--ui-drp-card);
}
.ui-drp__btn-primary:hover {
  opacity: 0.88;
}
.ui-drp__btn-primary:active {
  transform: scale(0.97);
}
.ui-drp__btn-primary:disabled {
  opacity: 0.35;
  cursor: default;
}
@keyframes ui-drp-open {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drp-slide {
  from {
    opacity: 0;
    transform: translateX(14px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drp-slide-back {
  from {
    opacity: 0;
    transform: translateX(-14px);
  }
  to {
    opacity: 1;
    transform: none;
  }
}
@keyframes ui-drp-in {
  from {
    opacity: 0;
    transform: translateY(4px);
    filter: blur(2px);
  }
  to {
    opacity: 1;
    transform: none;
    filter: none;
  }
}
@keyframes ui-drp-pick {
  0% {
    transform: scale(0.82);
  }
  60% {
    transform: scale(1.06);
  }
  100% {
    transform: scale(1);
  }
}
@container (max-width: 600px) {
  .ui-drp__body {
    grid-template-columns: 1fr;
  }
  .ui-drp__presets {
    flex-direction: row;
    gap: 6px;
    padding: 10px;
    overflow-x: auto;
    border-right: 0;
    border-bottom: 1px solid var(--ui-drp-line);
    scrollbar-width: none;
  }
  .ui-drp__presets::-webkit-scrollbar {
    display: none;
  }
  .ui-drp__preset {
    flex: none;
    height: 32px;
    padding: 0 12px;
    border-radius: 999px;
    box-shadow: inset 0 0 0 1px var(--ui-drp-line);
  }
  .ui-drp__presets .ui-drp__pill {
    border-radius: 999px;
  }
  .ui-drp__preset-custom {
    display: none;
  }
  .ui-drp__months {
    grid-template-columns: 1fr;
    justify-items: center;
  }
  .ui-drp__month:not([data-second]) {
    display: none;
  }
  .ui-drp__foot {
    flex-direction: column;
    align-items: stretch;
  }
  .ui-drp__buttons {
    justify-content: flex-end;
  }
  .ui-drp__compare {
    flex-wrap: wrap;
  }
}
@container (max-width: 340px) {
  .ui-drp__weekdays,
  .ui-drp__week {
    grid-template-columns: repeat(7, 1fr);
  }
  .ui-drp__cal {
    padding: 14px 8px 10px;
  }
  .ui-drp__months {
    justify-items: stretch;
  }
}
@media (hover: none) and (pointer: coarse) {
  .ui-drp__day {
    height: 38px;
  }
  .ui-drp__weekdays,
  .ui-drp__week {
    grid-template-columns: repeat(7, minmax(0, 38px));
  }
  .ui-drp__icon-btn {
    width: 38px;
    height: 38px;
  }
  .ui-drp__btn {
    height: 38px;
  }
  .ui-drp__segment {
    height: 30px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-drp *,
  .ui-drp *::before,
  .ui-drp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-drp {
  --ui-drp-tray: #111113;
  --ui-drp-card: #19191b;
  --ui-drp-line: #2a2a2e;
  --ui-drp-ink: #ededed;
  --ui-drp-text: #c8c8cc;
  --ui-drp-muted: #8b8b92;
  --ui-drp-faint: #4a4a50;
  --ui-drp-hover: #232326;
  --ui-drp-active: #2a2a2e;
  --ui-drp-band: rgba(109, 139, 255, 0.18);
  --ui-drp-band-preview: rgba(109, 139, 255, 0.1);
  --ui-drp-accent: #6d8bff;
  --ui-drp-on-accent: #0d0d10;
  --ui-drp-compare: #26262a;
  --ui-drp-compare-edge: #4a4a50;
  --ui-drp-focus: rgba(77, 141, 255, 0.8);
  --ui-drp-shadow:
    0 0 0 1px rgba(255, 255, 255, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.6);
}
`;function p(r){return i.jsx(e,{...r,clean:!1,styles:a})}export{p as D};
