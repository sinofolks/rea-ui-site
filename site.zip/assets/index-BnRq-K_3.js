import{j as t}from"./workbench-model-BwgilGut.js";import{A as n}from"./AgentInboxView-B9zP_wCo.js";function s(o){return t.jsx(n,{...o})}export{s as A};
