import{r as l,j as a}from"./workbench-model-BwgilGut.js";function ge({options:t,value:N,defaultValue:ee=null,onChange:I,placeholder:K="Choose…",label:v,hint:T,error:m,optional:ie=!1,size:A="md",disabled:k=!1,name:R,required:ae,id:te,className:se,"aria-label":D,ref:y}){const b=l.useId(),E=te??`${b}-trigger`,B=`${b}-list`,L=`${b}-label`,O=`${b}-message`,U=e=>`${b}-option-${e}`,[re,ne]=l.useState(ee),h=N!==void 0?N:re,o=t.find(e=>e.value===h)??null,[r,W]=l.useState(!1),[u,c]=l.useState(-1),[n,Y]=l.useState(null),[S,q]=l.useState(null),j=l.useRef(null),w=l.useRef(null),x=l.useRef({text:"",at:0}),F=!!m,$=z(m)?m:z(T)?T:null,le=ce.includes(A)?A:"md",M=e=>e>=0&&e<t.length&&!t[e].disabled,V=()=>t.findIndex(e=>!e.disabled),oe=()=>{for(let e=t.length-1;e>=0;e--)if(!t[e].disabled)return e;return-1},G=(e,i)=>{for(let s=e+i;s>=0&&s<t.length;s+=i)if(!t[s].disabled)return s;return e},Z=e=>{if(k||!t.length)return;const i=t.findIndex(s=>s.value===h);c(M(i)?i:V()),W(!0)},_=(e=!0)=>{var i;W(!1),q(null),Y(null),e&&((i=j.current)==null||i.focus({preventScroll:!0}))},H=e=>{if(!M(e))return;const i=t[e];N===void 0&&ne(i.value),i.value!==h&&(I==null||I(i.value,i)),_()},J=()=>{var X;const e=j.current;if(!e)return;const i=e.getBoundingClientRect(),s=4,d=8,f=window.innerHeight-i.bottom-s-d,g=i.top-s-d,p=Math.min(((X=w.current)==null?void 0:X.scrollHeight)??280,288),C=f<Math.min(p,160)&&g>f,Q=Math.max(i.width,180),de=Math.min(Math.max(d,i.left),window.innerWidth-Q-d);Y({top:C?i.top-s:i.bottom+s,left:de,width:Q,maxHeight:Math.max(120,Math.min(288,C?g:f)),up:C})};l.useLayoutEffect(()=>{if(!r)return;const e=w.current;e&&"showPopover"in e&&!e.matches(":popover-open")&&e.showPopover(),J();const i=()=>J();return window.addEventListener("resize",i),window.addEventListener("scroll",i,!0),()=>{window.removeEventListener("resize",i),window.removeEventListener("scroll",i,!0),e&&"hidePopover"in e&&e.matches(":popover-open")&&e.hidePopover()}},[r]),l.useEffect(()=>{if(!r)return;const e=i=>{var d,f;const s=i.target;(d=j.current)!=null&&d.contains(s)||(f=w.current)!=null&&f.contains(s)||_(!1)};return document.addEventListener("pointerdown",e,!0),()=>document.removeEventListener("pointerdown",e,!0)},[r]),l.useLayoutEffect(()=>{var i;if(!r||u<0)return;const e=(i=w.current)==null?void 0:i.querySelector(`[data-index="${u}"]`);e&&(q({top:e.offsetTop,height:e.offsetHeight}),e.scrollIntoView({block:"nearest"}))},[u,r,n]);const P=e=>{const i=Date.now();x.current.text=i-x.current.at>700?e:x.current.text+e,x.current.at=i;const s=x.current.text.toLowerCase(),d=r?u:t.findIndex(p=>p.value===h),g=[...t.keys()].map(p=>(p+d+(s.length===1?1:0)+t.length)%t.length).find(p=>M(p)&&t[p].label.toLowerCase().startsWith(s));g!==void 0&&(r?c(g):H(g))},ue=e=>{if(!k){if(!r){e.key==="ArrowDown"||e.key==="ArrowUp"||e.key==="Enter"||e.key===" "?(e.preventDefault(),Z()):e.key.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&P(e.key);return}switch(e.key){case"ArrowDown":e.preventDefault(),c(i=>G(i,1));break;case"ArrowUp":e.preventDefault(),c(i=>G(i,-1));break;case"Home":case"PageUp":e.preventDefault(),c(V());break;case"End":case"PageDown":e.preventDefault(),c(oe());break;case"Enter":case" ":e.preventDefault(),e.key===" "&&Date.now()-x.current.at<700?P(" "):H(u);break;case"Escape":e.preventDefault(),_();break;case"Tab":_(!1);break;default:e.key.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&P(e.key)}}};return a.jsxs("div",{className:["ui-sel",se].filter(Boolean).join(" "),"data-size":le,"data-open":r||void 0,"data-invalid":F||void 0,"data-disabled":k||void 0,children:[a.jsx("style",{href:"ui-select",precedence:"default",children:fe}),v!=null&&a.jsxs("div",{className:"ui-sel__head",children:[a.jsx("label",{className:"ui-sel__label",id:L,htmlFor:E,children:v}),ie&&a.jsx("span",{className:"ui-sel__optional",children:"Optional"})]}),a.jsxs("button",{ref:e=>{j.current=e,typeof y=="function"?y(e):y&&(y.current=e)},id:E,type:"button",className:"ui-sel__trigger",role:"combobox","aria-haspopup":"listbox","aria-expanded":r,"aria-controls":B,"aria-activedescendant":r&&u>=0?U(u):void 0,"aria-label":D,"aria-labelledby":D?void 0:v!=null?`${L} ${E}`:void 0,"aria-describedby":$?O:void 0,"aria-invalid":F||void 0,"aria-required":ae||void 0,disabled:k,onClick:()=>r?_():Z(),onKeyDown:ue,children:[(o==null?void 0:o.icon)&&a.jsx("span",{className:"ui-sel__icon","aria-hidden":"true",children:o.icon}),a.jsx("span",{className:"ui-sel__value","data-empty":o?void 0:"",title:o==null?void 0:o.label,children:o?o.label:K}),a.jsx("span",{className:"ui-sel__chevron","aria-hidden":"true",children:a.jsx(pe,{})})]}),R&&a.jsx("input",{type:"hidden",name:R,value:h??""}),r&&a.jsxs("div",{ref:w,id:B,className:"ui-sel__list",role:"listbox","aria-labelledby":v!=null?L:void 0,"aria-label":v==null?D??K:void 0,popover:"manual","data-up":(n==null?void 0:n.up)||void 0,style:n?{top:n.up?void 0:n.top,bottom:n.up?window.innerHeight-n.top:void 0,left:n.left,width:n.width,maxHeight:n.maxHeight}:void 0,onPointerLeave:()=>c(-1),children:[S&&a.jsx("span",{className:"ui-sel__glow","aria-hidden":"true",style:{transform:`translateY(${S.top}px)`,height:S.height}}),t.map((e,i)=>a.jsxs("div",{id:U(i),className:"ui-sel__option",role:"option","data-index":i,"aria-selected":e.value===h,"aria-disabled":e.disabled||void 0,"data-active":i===u||void 0,onPointerMove:()=>e.disabled||i===u||c(i),onPointerDown:s=>s.preventDefault(),onClick:()=>H(i),children:[e.icon&&a.jsx("span",{className:"ui-sel__icon","aria-hidden":"true",children:e.icon}),a.jsxs("span",{className:"ui-sel__text",children:[a.jsx("span",{className:"ui-sel__option-label",children:e.label}),e.description&&a.jsx("span",{className:"ui-sel__option-hint",children:e.description})]}),a.jsx("span",{className:"ui-sel__check","aria-hidden":"true",children:e.value===h&&a.jsx(he,{})})]},e.value))]}),$&&a.jsx("p",{className:"ui-sel__message",id:O,"aria-live":z(m)?"polite":void 0,children:$},z(m)?"error":"hint")]})}const ce=["sm","md","lg"],z=t=>t!=null&&typeof t!="boolean"&&t!=="";function pe(){return a.jsx("svg",{viewBox:"0 0 24 24",width:"14",height:"14",fill:"none",stroke:"currentColor",strokeWidth:"1.8",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:a.jsx("path",{d:"m7 10 5 5 5-5"})})}function he(){return a.jsx("svg",{viewBox:"0 0 24 24",width:"14",height:"14",fill:"none",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:a.jsx("path",{className:"ui-sel__tick",d:"M5 12.5 9.5 17 19 7",pathLength:1})})}const fe=`
/* Colors and motion as variables – override them on .ui-sel (see Theming in the docs) */
.ui-sel {
  --ui-sel-title: var(--aui-ink, #171717);
  --ui-sel-ink: var(--aui-ink, #171717);
  --ui-sel-subtle: var(--aui-muted, #626873);
  --ui-sel-faint: var(--aui-placeholder, #6b6b6b);
  --ui-sel-icon: var(--aui-muted, #626873);
  --ui-sel-surface: var(--aui-surface, #ffffff);
  --ui-sel-menu: var(--aui-surface, #ffffff);
  --ui-sel-line: var(--aui-border, #e6e6e8);
  --ui-sel-edge: var(--aui-border-strong, #d4d4d8);
  --ui-sel-edge-open: var(--aui-border-strong, #b4b4bb);
  --ui-sel-glow: #f4f4f5;
  --ui-sel-readonly: #fafafa;
  --ui-sel-shadow-menu: 0 0 0 1px rgba(0, 0, 0, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.18), 0 4px 12px -4px rgba(0, 0, 0, 0.06);
  --ui-sel-danger: var(--aui-danger, #c43238);
  --ui-sel-danger-edge: #f0a3a6;
  --ui-sel-danger-wash: rgba(229, 72, 77, 0.04);
  --ui-sel-focus: var(--aui-focus, rgba(0, 96, 226, 0.7));
  --ui-sel-ease: cubic-bezier(0.22, 1, 0.36, 1);

  --h: 36px;
  --px: 12px;
  --fs: 13.5px;
  --radius: var(--aui-radius, 10px);

  display: flex;
  flex-direction: column;
  gap: 7px;
  min-width: 0;
  font-family: var(--aui-font, "Inter", "InterVariable", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif);
  font-size: 13.5px;
  line-height: 20px;
  color: var(--ui-sel-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-sel[data-size="sm"] { --h: 32px; --px: 10px; --fs: 13px; --radius: calc(var(--aui-radius, 10px) - 1px); }
.ui-sel[data-size="lg"] { --h: 40px; --px: 14px; --fs: 14px; --radius: calc(var(--aui-radius, 10px) + 2px); }
/* Touch screens: a comfortable tap height and 16px text */
@media (pointer: coarse) {
  .ui-sel { --fs: 16px; }
  .ui-sel[data-size="sm"] { --h: 36px; }
  .ui-sel[data-size="md"] { --h: 40px; }
  .ui-sel[data-size="lg"] { --h: 44px; }
}

.ui-sel__head { display: flex; align-items: baseline; gap: 6px; min-width: 0; padding: 0 2px; }
.ui-sel__label { min-width: 0; font-size: 13px; font-weight: 500; color: var(--ui-sel-title); overflow-wrap: anywhere; cursor: default; }
.ui-sel__optional { flex: none; font-size: 12px; line-height: 16px; color: var(--ui-sel-subtle); }

/* The field: the Text Field's look – white with a 1px gray edge that darkens on hover and while open */
.ui-sel__trigger {
  display: flex;
  align-items: center;
  gap: 8px;
  box-sizing: border-box;
  width: 100%;
  height: var(--h);
  min-width: 0;
  margin: 0;
  padding: 0 calc(var(--px) - 2px) 0 var(--px);
  border: 0;
  border-radius: var(--radius);
  background: var(--ui-sel-surface);
  box-shadow: 0 0 0 1px var(--ui-sel-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  font: inherit;
  font-size: var(--fs);
  color: var(--ui-sel-ink);
  text-align: start;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
  transition: box-shadow 140ms ease, background-color 140ms ease;
}
.ui-sel__trigger:hover { box-shadow: 0 0 0 1px var(--ui-sel-edge), 0 1px 2px rgba(0, 0, 0, 0.04); }
.ui-sel[data-open] .ui-sel__trigger { box-shadow: 0 0 0 1px var(--ui-sel-edge-open), 0 1px 2px rgba(0, 0, 0, 0.04); }
.ui-sel__trigger:focus-visible { outline: 2px solid var(--ui-sel-focus); outline-offset: 2px; }
.ui-sel[data-invalid] .ui-sel__trigger { background: var(--ui-sel-danger-wash); box-shadow: 0 0 0 1px var(--ui-sel-danger-edge), 0 1px 2px rgba(0, 0, 0, 0.04); }
.ui-sel__trigger:disabled { background: var(--ui-sel-readonly); box-shadow: 0 0 0 1px var(--ui-sel-line); cursor: not-allowed; }
.ui-sel[data-disabled] { opacity: 0.55; }

.ui-sel__value { flex: 1; min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.ui-sel__value[data-empty] { color: var(--ui-sel-faint); }
.ui-sel__icon { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-sel-icon); }
.ui-sel__icon > svg, .ui-sel__icon > img { display: block; width: 16px; height: 16px; }
.ui-sel__chevron { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-sel-icon); transition: transform 240ms var(--ui-sel-ease); }
.ui-sel[data-open] .ui-sel__chevron { transform: rotate(180deg); }

/* The list: a white card in the top layer, at the field's edge */
.ui-sel__list {
  position: fixed;
  inset: auto;
  z-index: 1000;
  box-sizing: border-box;
  margin: 0;
  padding: 5px;
  border: 0;
  border-radius: 14px;
  background: var(--ui-sel-menu);
  box-shadow: var(--ui-sel-shadow-menu);
  color: var(--ui-sel-ink);
  font: inherit;
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: thin;
  transform-origin: top center;
  animation: ui-sel-in 200ms var(--ui-sel-ease) both;
}
.ui-sel__list[data-up] { transform-origin: bottom center; }
.ui-sel__list::backdrop { display: none; }

/* One soft highlight that glides between the rows */
.ui-sel__glow {
  position: absolute;
  top: 0;
  left: 5px;
  right: 5px;
  border-radius: 9px;
  background: var(--ui-sel-glow);
  pointer-events: none;
  transition: transform 180ms var(--ui-sel-ease), height 180ms var(--ui-sel-ease);
}

.ui-sel__option {
  position: relative;
  display: flex;
  align-items: center;
  gap: 8px;
  min-height: 34px;
  padding: 7px 10px;
  box-sizing: border-box;
  border-radius: 9px;
  font-size: 13.5px;
  line-height: 20px;
  cursor: pointer;
  user-select: none;
}
.ui-sel__option[aria-disabled] { color: var(--ui-sel-faint); cursor: default; }
.ui-sel__option[aria-disabled] .ui-sel__icon { opacity: 0.5; }
.ui-sel__text { display: grid; flex: 1; min-width: 0; }
.ui-sel__option-label { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.ui-sel__option[aria-selected="true"] .ui-sel__option-label { font-weight: 500; }
.ui-sel__option-hint { overflow: hidden; font-size: 12px; line-height: 16px; white-space: nowrap; text-overflow: ellipsis; color: var(--ui-sel-subtle); }
.ui-sel__check { display: grid; flex: none; place-items: center; width: 16px; height: 16px; color: var(--ui-sel-ink); }
.ui-sel__tick { stroke-dasharray: 1; animation: ui-sel-draw 280ms 40ms var(--ui-sel-ease) both; }
@media (pointer: coarse) {
  .ui-sel__option { min-height: 40px; font-size: 15px; }
}

.ui-sel__message { margin: 0; padding: 0 2px; font-size: 12.5px; line-height: 17px; color: var(--ui-sel-subtle); overflow-wrap: anywhere; animation: ui-sel-message 260ms var(--ui-sel-ease); }
.ui-sel[data-invalid] .ui-sel__message { color: var(--ui-sel-danger); }

@keyframes ui-sel-in {
  from { opacity: 0; transform: translateY(-4px) scale(0.98); }
}
.ui-sel__list[data-up] { animation-name: ui-sel-in-up; }
@keyframes ui-sel-in-up {
  from { opacity: 0; transform: translateY(4px) scale(0.98); }
}
@keyframes ui-sel-draw {
  from { stroke-dashoffset: 1; }
  to { stroke-dashoffset: 0; }
}
@keyframes ui-sel-message {
  from { opacity: 0; transform: translateY(-3px); filter: blur(2px); }
}

@media (prefers-reduced-motion: reduce) {
  .ui-sel *, .ui-sel__list { animation-duration: 1ms !important; }
  .ui-sel__glow, .ui-sel__chevron, .ui-sel__trigger { transition-duration: 1ms; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-sel {
  --ui-sel-title: var(--aui-ink, #ededed);
  --ui-sel-ink: var(--aui-ink, #ededed);
  --ui-sel-subtle: var(--aui-muted, #8b8b92);
  --ui-sel-faint: var(--aui-placeholder, #5c5c63);
  --ui-sel-icon: var(--aui-muted, #8b8b92);
  --ui-sel-surface: var(--aui-surface, #19191b);
  --ui-sel-menu: var(--aui-surface, #19191b);
  --ui-sel-line: var(--aui-border, #2a2a2e);
  --ui-sel-edge: var(--aui-border-strong, #3a3a40);
  --ui-sel-edge-open: var(--aui-border-strong, #4e4e55);
  --ui-sel-glow: #26262a;
  --ui-sel-readonly: #151517;
  --ui-sel-shadow-menu: 0 0 0 1px rgba(255, 255, 255, 0.06), 0 18px 40px -12px rgba(0, 0, 0, 0.6);
  --ui-sel-danger: var(--aui-danger, #ff6369);
  --ui-sel-danger-edge: rgba(255, 99, 105, 0.45);
  --ui-sel-danger-wash: rgba(229, 72, 77, 0.06);
  --ui-sel-focus: var(--aui-focus, rgba(77, 141, 255, 0.8));
}
`;export{ge as S};
