import{j as e}from"./workbench-model-BwgilGut.js";import{C as p}from"./context-map-BEsK8AzS.js";const a=`.ui-cmp {
  --ui-cmp-tray: #f0f0f0;
  --ui-cmp-panel: #ffffff;
  --ui-cmp-card: #ffffff;
  --ui-cmp-strong: #171717;
  --ui-cmp-ink: #171717;
  --ui-cmp-text: #6b6b6b;
  --ui-cmp-muted: #626873;
  --ui-cmp-faint: #6b6b6b;
  --ui-cmp-line: #ececec;
  --ui-cmp-accent: #2a5ee5;
  --ui-cmp-focus: rgba(0, 96, 226, 0.7);
  --ui-cmp-shine: #b8b8b8;
  --ui-cmp-hover: rgba(0, 0, 0, 0.05);
  --ui-cmp-high: #a45200;
  --ui-cmp-high-bg: #ffefd6;
  --ui-cmp-full: #c2331f;
  --ui-cmp-full-bg: #fde3df;
  --ui-cmp-system-bg: #f3f3f3;
  --ui-cmp-system-edge: #e1e1e1;
  --ui-cmp-system-ink: #5c5c5c;
  --ui-cmp-tools-bg: #e2f2f9;
  --ui-cmp-tools-edge: #a6d6ea;
  --ui-cmp-tools-ink: #006a94;
  --ui-cmp-memory-bg: #ececfc;
  --ui-cmp-memory-edge: #bdbdf0;
  --ui-cmp-memory-ink: #4a4ac2;
  --ui-cmp-file-bg: #e6effd;
  --ui-cmp-file-edge: #a9c4f5;
  --ui-cmp-file-ink: #2456d6;
  --ui-cmp-chat-bg: #f3eafa;
  --ui-cmp-chat-edge: #d3b6ec;
  --ui-cmp-chat-ink: #7b3fb0;
  --ui-cmp-result-bg: #ffefd6;
  --ui-cmp-result-edge: #f7c27a;
  --ui-cmp-result-ink: #ab5000;
  --ui-cmp-summary-bg: #dcf3e4;
  --ui-cmp-summary-edge: #9fd9b4;
  --ui-cmp-summary-ink: #187941;
  --ui-cmp-free-edge: #d6d6d6;
  --ui-cmp-free-hatch: rgba(0, 0, 0, 0.035);
  --ui-cmp-shadow: 0 0 0 1px #ececec, 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-cmp-button: var(--ui-cmp-shadow);
  --ui-cmp-button-hover: 0 0 0 1px #e2e2e2, 0 1px 3px rgba(0, 0, 0, 0.07);
  --ui-cmp-pop: 0 0 0 1px #ececec, 0 16px 36px -12px rgba(0, 0, 0, 0.22);
  --ui-cmp-height: 280px;
  --ui-cmp-gap: 3px;
  --ui-cmp-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-cmp-tray);
  min-width: 0;
  container: ui-cmp / inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  color: var(--ui-cmp-text);
  text-align: left;
  letter-spacing: -0.006em;
  -webkit-font-smoothing: antialiased;
}
.ui-cmp *,
.ui-cmp *::before,
.ui-cmp *::after {
  box-sizing: border-box;
}
.ui-cmp__bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 8px;
  min-width: 0;
  padding: 10px 12px 12px;
}
.ui-cmp__mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-cmp-accent);
}
.ui-cmp__title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-cmp-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmp__who {
  display: inline-flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}
.ui-cmp__logo {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 7px;
  background: var(--ui-cmp-card);
  box-shadow: var(--ui-cmp-shadow);
}
.ui-cmp__logo > svg {
  width: 12px;
  height: 12px;
}
.ui-cmp__model {
  min-width: 0;
  overflow: hidden;
  color: var(--ui-cmp-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmp__pick {
  position: relative;
  display: inline-flex;
  min-width: 0;
}
.ui-cmp__agent {
  min-width: 0;
  height: 32px;
  margin: -5px 0;
  padding: 0 8px 0 11px;
  border: 0;
  border-radius: 999px;
  letter-spacing: inherit;
  background: var(--ui-cmp-card);
  box-shadow: var(--ui-cmp-button);
  font: inherit;
  color: inherit;
  cursor: pointer;
  transition: box-shadow 160ms ease;
}
.ui-cmp__agent:hover,
.ui-cmp__agent[aria-expanded="true"] {
  box-shadow: var(--ui-cmp-button-hover);
}
.ui-cmp__agent .ui-cmp__logo {
  width: 14px;
  height: 14px;
  border-radius: 0;
  background: none;
  box-shadow: none;
}
.ui-cmp__agent .ui-cmp__logo > svg {
  width: 15px;
  height: 15px;
}
.ui-cmp__agent:focus-visible,
.ui-cmp__option:focus-visible {
  outline: 2px solid var(--ui-cmp-focus);
  outline-offset: 2px;
}
.ui-cmp__option:focus-visible {
  outline-offset: -2px;
}
.ui-cmp__chev {
  flex: none;
  width: 13px;
  height: 13px;
  margin-left: -2px;
  color: var(--ui-cmp-muted);
  transition: transform 180ms var(--ui-cmp-ease);
}
.ui-cmp__agent[aria-expanded="true"] .ui-cmp__chev {
  transform: rotate(180deg);
}
.ui-cmp__menu {
  position: absolute;
  top: calc(100% + 8px);
  left: 0;
  z-index: 6;
  display: grid;
  gap: 2px;
  width: 268px;
  padding: 5px;
  border-radius: 16px;
  background: var(--ui-cmp-card);
  box-shadow: var(--ui-cmp-shadow);
  animation: ui-cmp-tip 160ms var(--ui-cmp-ease) both;
}
.ui-cmp__option {
  display: flex;
  align-items: center;
  gap: 10px;
  width: 100%;
  padding: 7px 10px 7px 7px;
  border: 0;
  border-radius: 11px;
  letter-spacing: inherit;
  background: none;
  font: inherit;
  text-align: left;
  color: inherit;
  cursor: pointer;
}
.ui-cmp__option:hover {
  background: var(--ui-cmp-hover);
}
.ui-cmp__option[aria-checked="true"] {
  background: var(--ui-cmp-hover);
}
.ui-cmp__option-text {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-cmp__option-name {
  overflow: hidden;
  font-size: 14px;
  font-weight: 600;
  line-height: 19px;
  color: var(--ui-cmp-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmp__option-model {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 17px;
  color: var(--ui-cmp-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-cmp__option .ui-cmp__logo {
  width: 28px;
  height: 28px;
  border-radius: 8px;
}
.ui-cmp__option .ui-cmp__logo > svg {
  width: 14px;
  height: 14px;
}
.ui-cmp__limit {
  flex: none;
  height: 20px;
  padding: 0 7px;
  border-radius: 999px;
  background: var(--ui-cmp-hover);
  font-size: 12px;
  font-weight: 500;
  line-height: 20px;
  color: var(--ui-cmp-text);
  font-variant-numeric: tabular-nums;
}
.ui-cmp__status {
  display: inline-flex;
  flex: none;
  align-items: center;
  max-width: 100%;
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  gap: 5px;
  height: 24px;
  padding: 0 10px 0 8px;
  border-radius: 999px;
  background: var(--ui-cmp-summary-bg);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-cmp-summary-ink);
  animation: ui-cmp-fade 240ms ease both;
}
.ui-cmp__sum {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-cmp-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.ui-cmp__sum b {
  font-weight: 600;
  color: var(--ui-cmp-ink);
}
.ui-cmp__used {
  background: linear-gradient(
      90deg,
      var(--ui-cmp-ink) 0%,
      var(--ui-cmp-ink) 38%,
      var(--ui-cmp-shine) 50%,
      var(--ui-cmp-ink) 62%,
      var(--ui-cmp-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent !important;
  animation: ui-cmp-shine 1100ms linear infinite;
}
.ui-cmp__pct {
  min-width: 44px;
  height: 24px;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--ui-cmp-card);
  box-shadow: var(--ui-cmp-shadow);
  font-size: 12.5px;
  font-weight: 600;
  line-height: 24px;
  color: var(--ui-cmp-text);
  text-align: center;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-cmp__pct[data-level="high"] {
  background: var(--ui-cmp-high-bg);
  color: var(--ui-cmp-high);
}
.ui-cmp__pct[data-level="full"] {
  background: var(--ui-cmp-full-bg);
  color: var(--ui-cmp-full);
}
.ui-cmp__status-text {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cmp__compare {
  display: inline-flex;
  flex: none;
  gap: 1px;
  padding: 2px;
  border-radius: 999px;
  background: var(--ui-cmp-hover);
}
.ui-cmp__compare {
  margin: -2px 0;
  animation: ui-cmp-fade 280ms ease both;
}
.ui-cmp__roll {
  display: inline-grid;
  vertical-align: top;
  overflow: hidden;
}
.ui-cmp__roll > * {
  grid-area: 1 / 1;
}
.ui-cmp__roll-in[data-rolling] {
  animation: ui-cmp-roll-in 340ms var(--ui-cmp-ease) both;
}
.ui-cmp__roll-out {
  animation: ui-cmp-roll-out 300ms var(--ui-cmp-ease) both;
  pointer-events: none;
}
.ui-cmp__fates-row {
  display: grid;
}
.ui-cmp__fates-row > .ui-cmp__roll {
  display: grid;
}
@keyframes ui-cmp-roll-in {
  from {
    opacity: 0;
    transform: translateY(80%);
  }
}
@keyframes ui-cmp-roll-out {
  to {
    opacity: 0;
    transform: translateY(-80%);
  }
}
.ui-cmp__compare button {
  height: 24px;
  padding: 0 9px;
  border: 0;
  border-radius: 999px;
  background: none;
  font: inherit;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-cmp-muted);
  cursor: pointer;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-cmp__compare button:hover {
  color: var(--ui-cmp-ink);
}
.ui-cmp__compare button[aria-pressed="true"] {
  background: var(--ui-cmp-card);
  color: var(--ui-cmp-ink);
  box-shadow: var(--ui-cmp-shadow);
}
.ui-cmp__compare button:focus-visible {
  outline: 2px solid var(--ui-cmp-focus);
  outline-offset: -2px;
}
.ui-cmp__area {
  position: relative;
  height: var(--ui-cmp-height);
  padding: 0;
  border-radius: 16px;
  background: var(--ui-cmp-panel);
  box-shadow: var(--ui-cmp-shadow);
}
.ui-cmp__tile {
  position: absolute;
  left: 0;
  top: 0;
  width: max(0px, calc(var(--w) - var(--ui-cmp-gap)));
  height: max(0px, calc(var(--h) - var(--ui-cmp-gap)));
  border-radius: min(9px, calc(var(--w) / 4), calc(var(--h) / 4));
  background: var(--k-bg);
  box-shadow: inset 0 0 0 1px var(--k-edge);
  overflow: hidden;
  transform: translate(
    calc(var(--x) + var(--ui-cmp-gap) / 2),
    calc(var(--y) + var(--ui-cmp-gap) / 2)
  );
  transition:
    opacity 200ms ease,
    background-color 300ms ease;
  cursor: default;
}
.ui-cmp__tile[data-kind="free"] {
  background: repeating-linear-gradient(
    135deg,
    transparent 0 6px,
    var(--ui-cmp-free-hatch) 6px 7px
  );
  box-shadow: none;
  outline: 1.5px dashed var(--ui-cmp-free-edge);
  outline-offset: -2px;
}
.ui-cmp__tile[data-dim] {
  opacity: 0.55;
}
.ui-cmp__label {
  position: absolute;
  top: 8px;
  right: 0;
  left: 10px;
  display: grid;
  min-width: 0;
  pointer-events: none;
}
.ui-cmp__name,
.ui-cmp__tokens {
  overflow: hidden;
  white-space: nowrap;
  -webkit-mask-image: linear-gradient(
    90deg,
    #000 calc(100% - 22px),
    transparent calc(100% - 4px)
  );
  mask-image: linear-gradient(
    90deg,
    #000 calc(100% - 22px),
    transparent calc(100% - 4px)
  );
  opacity: 0;
  transition: opacity 220ms ease;
}
.ui-cmp__name {
  font-size: 13px;
  font-weight: 600;
  line-height: 17px;
  color: var(--k-ink);
}
.ui-cmp__tokens {
  font-size: 12.5px;
  line-height: 17px;
  color: var(--k-ink);
  font-variant-numeric: tabular-nums;
}
.ui-cmp__name[data-show] {
  opacity: 1;
}
.ui-cmp__tokens[data-show] {
  opacity: 0.7;
}
.ui-cmp__kind {
  opacity: 0;
  transition: opacity 220ms ease;
}
.ui-cmp__kind[data-show] {
  opacity: 1;
}
.ui-cmp__tile[data-kind="free"] :is(.ui-cmp__name, .ui-cmp__tokens) {
  color: var(--ui-cmp-muted);
}
.ui-cmp [data-kind="system"] {
  --k-bg: var(--ui-cmp-system-bg);
  --k-edge: var(--ui-cmp-system-edge);
  --k-ink: var(--ui-cmp-system-ink);
}
.ui-cmp [data-kind="tools"] {
  --k-bg: var(--ui-cmp-tools-bg);
  --k-edge: var(--ui-cmp-tools-edge);
  --k-ink: var(--ui-cmp-tools-ink);
}
.ui-cmp [data-kind="memory"] {
  --k-bg: var(--ui-cmp-memory-bg);
  --k-edge: var(--ui-cmp-memory-edge);
  --k-ink: var(--ui-cmp-memory-ink);
}
.ui-cmp [data-kind="file"] {
  --k-bg: var(--ui-cmp-file-bg);
  --k-edge: var(--ui-cmp-file-edge);
  --k-ink: var(--ui-cmp-file-ink);
}
.ui-cmp [data-kind="chat"] {
  --k-bg: var(--ui-cmp-chat-bg);
  --k-edge: var(--ui-cmp-chat-edge);
  --k-ink: var(--ui-cmp-chat-ink);
}
.ui-cmp [data-kind="result"] {
  --k-bg: var(--ui-cmp-result-bg);
  --k-edge: var(--ui-cmp-result-edge);
  --k-ink: var(--ui-cmp-result-ink);
}
.ui-cmp [data-kind="summary"] {
  --k-bg: var(--ui-cmp-summary-bg);
  --k-edge: var(--ui-cmp-summary-edge);
  --k-ink: var(--ui-cmp-summary-ink);
}
.ui-cmp__tip {
  position: absolute;
  top: 0;
  left: 0;
  z-index: 5;
  display: grid;
  gap: 2px;
  width: max-content;
  max-width: 320px;
  padding: 10px 14px 11px;
  border-radius: 14px;
  background: var(--ui-cmp-card);
  box-shadow: var(--ui-cmp-pop);
  pointer-events: none;
  animation: ui-cmp-tip 160ms var(--ui-cmp-ease) both;
}
.ui-cmp__tip-head {
  display: flex;
  align-items: center;
  gap: 7px;
  min-width: 0;
}
.ui-cmp__swatch {
  flex: none;
  width: 10px;
  height: 10px;
  border-radius: 3px;
  background: var(--k-bg);
  box-shadow: inset 0 0 0 1px var(--k-edge);
}
.ui-cmp__tip-name {
  display: -webkit-box;
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-cmp-ink);
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
}
.ui-cmp__tip-head {
  align-items: flex-start;
}
.ui-cmp__tip-head > .ui-cmp__swatch {
  margin-top: 5px;
}
.ui-cmp__tip-meta {
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-cmp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cmp__tip-items {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, max-content));
  gap: 7px 18px;
  margin: 8px 0 0;
  padding: 9px 0 0;
  border-top: 1px solid var(--ui-cmp-line);
  list-style: none;
}
.ui-cmp__tip-items li {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-size: 13px;
  line-height: 20px;
  color: var(--ui-cmp-text);
  white-space: nowrap;
}
.ui-cmp__tip-item {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-cmp__tip-more {
  color: var(--ui-cmp-muted);
}
.ui-cmp :is(.ui-cmp__logo, .ui-cmp__icon) > img {
  width: 14px;
  height: 14px;
  object-fit: contain;
}
.ui-cmp__tip-items .ui-cmp__logo,
.ui-cmp__tip-head .ui-cmp__logo {
  width: 20px;
  height: 20px;
  border-radius: 6px;
  color: var(--ui-cmp-ink);
}
.ui-cmp__tip-items .ui-cmp__logo > svg,
.ui-cmp__tip-head .ui-cmp__logo > svg {
  width: 11px;
  height: 11px;
}
.ui-cmp__icon {
  display: inline-flex;
  vertical-align: -2px;
  margin-right: 5px;
}
.ui-cmp__icon > svg {
  width: 13px;
  height: 13px;
  border-radius: 3px;
}
.ui-cmp__tip-detail {
  display: -webkit-box;
  overflow: hidden;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-cmp-text);
  overflow-wrap: anywhere;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 4;
}
.ui-cmp__tip-fate {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-top: 4px;
  font-size: 12px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-cmp-text);
}
.ui-cmp__tip-fate > svg {
  flex: none;
  width: 12px;
  height: 12px;
}
.ui-cmp__tip-fate:is([data-fate="summarized"], [data-fate="summary"]) {
  color: var(--ui-cmp-summary-ink);
}
.ui-cmp__tip-fate[data-fate="dropped"] {
  color: var(--ui-cmp-muted);
}
.ui-cmp__tile[data-fate="summarized"] {
  box-shadow: none;
  outline: 1.5px dashed color-mix(in srgb, var(--k-ink) 55%, transparent);
  outline-offset: -1.5px;
}
.ui-cmp__tile[data-fate="dropped"] {
  opacity: 0.42;
  filter: grayscale(1);
}
.ui-cmp__tile[data-fate="dropped"] .ui-cmp__name {
  text-decoration: line-through;
}
.ui-cmp__tile[data-fate="summary"] {
  box-shadow: inset 0 0 0 1px var(--ui-cmp-summary-edge);
}
.ui-cmp__badge {
  position: absolute;
  top: 6px;
  right: 6px;
  z-index: 1;
  display: grid;
  place-items: center;
  width: 18px;
  height: 18px;
  border-radius: 5px;
  background: var(--ui-cmp-hover);
  color: var(--ui-cmp-muted);
  pointer-events: none;
  animation: ui-cmp-fade 240ms ease both;
}
.ui-cmp__badge > svg {
  width: 11px;
  height: 11px;
}
.ui-cmp__tile[data-pinned] {
  box-shadow: inset 0 0 0 1.5px var(--k-ink);
}
.ui-cmp__tile[data-fate="summarized"][data-pinned] {
  outline-style: solid;
}
.ui-cmp__tile {
  cursor: pointer;
}
.ui-cmp__tile[data-kind="free"] {
  cursor: default;
}
.ui-cmp__fates {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 4px 16px;
  min-height: 18px;
  margin: 10px 0 0;
  padding: 0 10px 8px;
  font-size: 13px;
  line-height: 18px;
  color: var(--ui-cmp-muted);
  font-variant-numeric: tabular-nums;
}
.ui-cmp__fates b {
  font-weight: 500;
  color: var(--ui-cmp-ink);
}
.ui-cmp__fates--none {
  color: var(--ui-cmp-faint);
}
.ui-cmp__fate {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap;
}
.ui-cmp__fate::before {
  content: "";
  flex: none;
  width: 9px;
  height: 9px;
  border-radius: 2.5px;
  background: var(--ui-cmp-system-bg);
  box-shadow: inset 0 0 0 1.5px var(--ui-cmp-system-edge);
}
.ui-cmp__fate[data-fate="summarized"]::before {
  background: none;
  box-shadow: none;
  outline: 1px dashed var(--ui-cmp-muted);
  outline-offset: -1px;
}
.ui-cmp__fate[data-fate="dropped"]::before {
  opacity: 0.45;
}
@container ui-cmp (max-width: 480px) {
  .ui-cmp__compare {
    order: 2;
    margin-left: auto;
  }
  .ui-cmp__sum {
    min-height: 28px;
  }
  .ui-cmp__fates {
    min-height: 40px;
    align-content: flex-start;
  }
  .ui-cmp__pct {
    order: 3;
  }
  .ui-cmp__sum {
    flex-basis: 100%;
    justify-content: space-between;
    margin-left: 0;
  }
  .ui-cmp__area {
    --ui-cmp-height: 240px;
  }
}
@keyframes ui-cmp-in {
  from {
    opacity: 0;
  }
}
@keyframes ui-cmp-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-cmp-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
.ui-cmp__spin {
  flex: none;
  width: 12px;
  height: 12px;
  animation: ui-cmp-spin 800ms steps(8) infinite;
}
@keyframes ui-cmp-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-cmp-tip {
  from {
    opacity: 0;
    transform: translateY(4px) scale(0.96);
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cmp *,
  .ui-cmp *::before,
  .ui-cmp *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-cmp {
  --ui-cmp-focus: rgba(77, 141, 255, 0.8);
  --ui-cmp-tray: #1a1a1c;
  --ui-cmp-panel: #232326;
  --ui-cmp-card: #2a2a2e;
  --ui-cmp-strong: #f5f5f5;
  --ui-cmp-ink: #f0f0f0;
  --ui-cmp-text: #a1a1a1;
  --ui-cmp-muted: #8a8a8a;
  --ui-cmp-faint: #5c5c5c;
  --ui-cmp-line: #2e2e31;
  --ui-cmp-accent: #6d93ff;
  --ui-cmp-shine: #8a8a8a;
  --ui-cmp-hover: rgba(255, 255, 255, 0.07);
  --ui-cmp-high: #ffb357;
  --ui-cmp-high-bg: #3a2a12;
  --ui-cmp-full: #ff8a76;
  --ui-cmp-full-bg: #3d1a16;
  --ui-cmp-system-bg: #2b2b2f;
  --ui-cmp-system-edge: #3a3a40;
  --ui-cmp-system-ink: #bdbdbd;
  --ui-cmp-tools-bg: #12303b;
  --ui-cmp-tools-edge: #2a6a84;
  --ui-cmp-tools-ink: #6fd0f2;
  --ui-cmp-memory-bg: #24244a;
  --ui-cmp-memory-edge: #4a4aa0;
  --ui-cmp-memory-ink: #b3b3ff;
  --ui-cmp-file-bg: #1d2b4d;
  --ui-cmp-file-edge: #3c5fb3;
  --ui-cmp-file-ink: #8aaeff;
  --ui-cmp-chat-bg: #2f2140;
  --ui-cmp-chat-edge: #6a4a94;
  --ui-cmp-chat-ink: #d4a8ff;
  --ui-cmp-result-bg: #3a2a12;
  --ui-cmp-result-edge: #8a5a1c;
  --ui-cmp-result-ink: #ffc078;
  --ui-cmp-summary-bg: #15321f;
  --ui-cmp-summary-edge: #2f7a4b;
  --ui-cmp-summary-ink: #55d68c;
  --ui-cmp-free-edge: #3a3a40;
  --ui-cmp-free-hatch: rgba(255, 255, 255, 0.04);
  --ui-cmp-shadow: 0 0 0 1px #2e2e31, 0 1px 2px rgba(0, 0, 0, 0.4);
  --ui-cmp-button: var(--ui-cmp-shadow);
  --ui-cmp-button-hover: 0 0 0 1px #3a3a40, 0 1px 3px rgba(0, 0, 0, 0.45);
  --ui-cmp-pop: 0 0 0 1px #34343a, 0 16px 36px -12px rgba(0, 0, 0, 0.7);
}
`;function r(i){return e.jsx(p,{...i,clean:!1,styles:a})}export{r as C};
