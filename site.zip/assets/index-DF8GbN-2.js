import{j as o}from"./workbench-model-BwgilGut.js";import{A as p}from"./ApprovalView-Dai2dPnt.js";function s(r){return o.jsx(p,{...r})}export{s as A};
