import{j as i}from"./workbench-model-BwgilGut.js";import{A as e}from"./agent-monitor-DsMLKk3t.js";const t=`.ui-agm {
  --ui-agm-tray: #f0f0f0;
  --ui-agm-card: #ffffff;
  --ui-agm-strong: #171717;
  --ui-agm-ink: #171717;
  --ui-agm-text: #6b6b6b;
  --ui-agm-muted: #626873;
  --ui-agm-faint: #6b6b6b;
  --ui-agm-line: #ececec;
  --ui-agm-edge: #ececec;
  --ui-agm-lane: #f5f5f5;
  --ui-agm-fill: #e4e4e5;
  --ui-agm-accent: #2a5ee5;
  --ui-agm-accent-bg: rgba(47, 107, 255, 0.08);
  --ui-agm-green: #177a44;
  --ui-agm-green-bg: rgba(34, 160, 90, 0.1);
  --ui-agm-red: #c43339;
  --ui-agm-red-bg: rgba(229, 72, 77, 0.08);
  --ui-agm-amber: #9c5b08;
  --ui-agm-amber-bg: rgba(232, 162, 12, 0.14);
  --ui-agm-shine: rgba(23, 23, 23, 0.25);
  --ui-agm-focus: rgba(0, 96, 226, 0.7);
  --ui-agm-seg: #e6e6e7;
  --ui-agm-live: 47, 107, 255;
  --ui-agm-hot: #a3a3a8;
  --ui-agm-shadow: 0 0 0 1px var(--ui-agm-line), 0 1px 2px rgba(0, 0, 0, 0.04);
  --ui-agm-ease: cubic-bezier(0.32, 0.72, 0.24, 1);
  position: relative;
  display: inline-block;
  max-width: 100%;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-agm-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-agm *,
.ui-agm *::before,
.ui-agm *::after {
  box-sizing: border-box;
}
:where(.ui-agm) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-agm :is(button, .ui-agm__panel, .ui-agm__steps):focus-visible {
  outline: 2px solid var(--ui-agm-focus);
  outline-offset: 2px;
}
.ui-agm :is(ol, ul) {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-agm svg {
  display: block;
  flex: none;
}
.ui-agm__panel {
  position: relative;
  display: grid;
  width: 372px;
  max-width: 100%;
  padding: 4px;
  border-radius: 20px;
  background: var(--ui-agm-tray);
  transform-origin: 24px 24px;
  animation: ui-agm-open 340ms var(--ui-agm-ease) both;
}
.ui-agm__card {
  display: grid;
  gap: 12px;
  min-width: 0;
  padding: 14px 14px 12px;
  border-radius: 16px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
}
.ui-agm__top {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agm__face {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  margin-right: 2px;
  border-radius: 9px;
  background: var(--ui-agm-card);
  box-shadow: inset 0 0 0 1px var(--ui-agm-line);
  font-size: 12px;
  font-weight: 600;
  color: var(--ui-agm-ink);
}
.ui-agm__face > svg {
  width: 16px;
  height: 16px;
}
.ui-agm__face > img {
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: inherit;
}
.ui-agm__who {
  display: grid;
  flex: 1;
  min-width: 3em;
}
.ui-agm__name {
  overflow: hidden;
  font-weight: 600;
  line-height: 18px;
  color: var(--ui-agm-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__role {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 17px;
  color: var(--ui-agm-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__cost {
  flex: none;
  font-size: 12.5px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-text);
  animation: ui-agm-morph-in 380ms var(--ui-agm-ease) both;
}
.ui-agm__cost[data-live] {
  background: linear-gradient(
      90deg,
      var(--ui-agm-ink) 0%,
      var(--ui-agm-ink) 38%,
      var(--ui-agm-shine) 50%,
      var(--ui-agm-ink) 62%,
      var(--ui-agm-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-agm-shine 1500ms linear infinite;
}
.ui-agm__state {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 6px;
  height: 26px;
  padding: 0 10px 0 9px;
  overflow: hidden;
  border-radius: 999px;
  background: var(--ui-agm-lane);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-agm-text);
  white-space: nowrap;
  transition:
    background-color 300ms ease,
    color 300ms ease;
}
.ui-agm__dot {
  position: relative;
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: currentColor;
  opacity: 0.6;
}
.ui-agm__dot::after {
  content: "";
  position: absolute;
  inset: -3px;
  border-radius: 50%;
  background: currentColor;
  opacity: 0;
}
.ui-agm__state:is([data-status="running"], [data-status="waiting"])
  .ui-agm__dot {
  opacity: 1;
}
.ui-agm__state:is([data-status="running"], [data-status="waiting"])
  .ui-agm__dot::after {
  animation: ui-agm-pulse 1600ms ease-out infinite;
}
.ui-agm__state .ui-agm__roll {
  flex: none;
  height: 26px;
}
.ui-agm__state[data-status="running"] {
  background: var(--ui-agm-accent-bg);
  color: var(--ui-agm-accent);
}
.ui-agm__state[data-status="waiting"] {
  background: var(--ui-agm-amber-bg);
  color: var(--ui-agm-amber);
}
.ui-agm__state[data-status="finished"] {
  background: var(--ui-agm-green-bg);
  color: var(--ui-agm-green);
}
.ui-agm__state[data-status="failed"] {
  background: var(--ui-agm-red-bg);
  color: var(--ui-agm-red);
}
.ui-agm__fold {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-right: -4px;
  border-radius: 9px;
  color: var(--ui-agm-muted);
  box-shadow: inset 0 0 0 1px var(--ui-agm-line);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-agm__fold:hover {
  background: var(--ui-agm-lane);
  color: var(--ui-agm-ink);
}
.ui-agm__well {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
  height: 44px;
  padding: 0 12px 0 8px;
  border-radius: 12px;
  background: var(--ui-agm-lane);
  font-size: 13px;
  transition: background-color 300ms ease;
}
.ui-agm__well[data-status="waiting"] {
  background: var(--ui-agm-amber-bg);
}
.ui-agm__well:not([data-status="running"]):not(:has(.ui-agm__tile)) {
  padding-left: 12px;
}
.ui-agm__roll {
  display: inline-grid;
  flex: 1;
  grid-template-columns: minmax(0, 1fr);
  align-items: center;
  min-width: 0;
  height: 44px;
  overflow: hidden;
}
.ui-agm__roll-layer {
  grid-area: 1 / 1;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-agm__roll-layer[data-leaving] {
  animation: ui-agm-out 380ms var(--ui-agm-ease) both;
  pointer-events: none;
}
.ui-agm__roll-layer[data-coming] {
  animation: ui-agm-in 380ms var(--ui-agm-ease) both;
}
.ui-agm__tile {
  display: grid;
  flex: none;
  place-items: center;
  width: 28px;
  height: 28px;
  border-radius: 8px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
  color: var(--ui-agm-text);
}
.ui-agm__tile > svg {
  width: 15px;
  height: 15px;
}
.ui-agm__task {
  min-width: 0;
  overflow: hidden;
  font-weight: 500;
  color: var(--ui-agm-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__well[data-status="waiting"] .ui-agm__task {
  flex: none;
}
.ui-agm__task--quiet {
  font-weight: 400;
  color: var(--ui-agm-muted);
}
.ui-agm__flag {
  flex: none;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--ui-agm-red);
}
.ui-agm__shine {
  background: linear-gradient(
      90deg,
      var(--ui-agm-ink) 0%,
      var(--ui-agm-ink) 38%,
      var(--ui-agm-shine) 50%,
      var(--ui-agm-ink) 62%,
      var(--ui-agm-ink) 100%
    )
    0 0 / 300% 100%;
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
  animation: ui-agm-shine 1500ms linear infinite;
}
.ui-agm__code {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  padding: 0 7px;
  border-radius: 7px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  line-height: 22px;
  letter-spacing: 0;
  color: var(--ui-agm-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__diff {
  display: inline-flex;
  flex: none;
  gap: 6px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.ui-agm__add {
  color: var(--ui-agm-green);
}
.ui-agm__del {
  color: var(--ui-agm-red);
}
.ui-agm__note {
  flex: none;
  color: var(--ui-agm-muted);
}
.ui-agm__clock {
  flex: none;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-muted);
  animation: ui-agm-morph-in 380ms var(--ui-agm-ease) both;
}
.ui-agm__strip-wrap {
  margin: 2px 0;
}
.ui-agm__strip {
  display: flex;
  gap: 3px;
  height: 8px;
}
.ui-agm__seg {
  position: relative;
  min-width: 4px;
  border-radius: 4px;
  background: var(--ui-agm-seg);
  transition:
    flex-grow 300ms linear,
    background-color 400ms ease,
    opacity 200ms ease;
  animation: ui-agm-grow 420ms var(--ui-agm-ease) backwards;
}
.ui-agm__strip .ui-agm__seg::after {
  content: "";
  position: absolute;
  inset: -6px -1px;
}
.ui-agm__seg[data-state="running"] {
  background: rgba(var(--ui-agm-live), 0.3);
}
.ui-agm__seg[data-state="running"]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: inherit;
  background: linear-gradient(
      90deg,
      transparent 0%,
      rgba(255, 255, 255, 0.75) 50%,
      transparent 100%
    )
    0 0 / 50% 100% no-repeat;
  animation: ui-agm-sheen 1600ms ease-in-out infinite;
}
.ui-agm__seg[data-state="failed"] {
  background:
    repeating-linear-gradient(
      -45deg,
      var(--ui-agm-red-bg) 0 2px,
      transparent 2px 4px
    ),
    var(--ui-agm-seg);
}
.ui-agm__seg[data-state="waiting"] {
  flex: 0 0 14px;
  background: var(--ui-agm-amber);
  opacity: 0.6;
  animation:
    ui-agm-grow 420ms var(--ui-agm-ease) backwards,
    ui-agm-breathe 1600ms ease-in-out infinite;
}
.ui-agm:not([data-status="running"])
  .ui-agm__seg[data-state="running"]::before {
  animation: none;
  opacity: 0;
}
.ui-agm[data-status="finished"] .ui-agm__seg:not([data-state="failed"]) {
  background: var(--ui-agm-green-bg);
}
.ui-agm[data-status="paused"] .ui-agm__seg[data-state="running"] {
  opacity: 0.45;
}
.ui-agm[data-pointing] .ui-agm__strip .ui-agm__seg:not([data-hot]),
.ui-agm[data-pointing] .ui-agm__step:not([data-hot]) {
  opacity: 0.35;
}
.ui-agm__strip .ui-agm__seg[data-hot]:not([data-state="running"]) {
  background: var(--ui-agm-hot);
}
.ui-agm__steps::-webkit-scrollbar {
  display: none;
}
.ui-agm__steps[data-fade-top] {
  --ui-agm-fade-top: transparent;
}
.ui-agm__steps[data-fade-bottom] {
  --ui-agm-fade-bottom: transparent;
}
.ui-agm__steps {
  position: relative;
  display: grid;
  align-content: start;
  height: calc(var(--ui-agm-shown, 0) * 30px);
  overflow-y: auto;
  overscroll-behavior: contain;
  scrollbar-width: none;
  margin: -2px -6px 0;
  --ui-agm-fade-top: #000;
  --ui-agm-fade-bottom: #000;
  -webkit-mask-image: linear-gradient(
    to bottom,
    var(--ui-agm-fade-top),
    #000 14px,
    #000 calc(100% - 14px),
    var(--ui-agm-fade-bottom)
  );
  mask-image: linear-gradient(
    to bottom,
    var(--ui-agm-fade-top),
    #000 14px,
    #000 calc(100% - 14px),
    var(--ui-agm-fade-bottom)
  );
  transition: height 420ms var(--ui-agm-ease);
}
.ui-agm__step {
  position: relative;
  display: flex;
  align-items: center;
  gap: 10px;
  height: 30px;
  padding: 0 8px;
  border-radius: 9px;
  font-size: 13px;
  cursor: pointer;
  transition:
    opacity 200ms ease,
    background-color 200ms ease;
  animation: ui-agm-drop 460ms var(--ui-agm-ease) backwards;
}
.ui-agm__step[data-hot] {
  background: var(--ui-agm-lane);
}
.ui-agm__strip .ui-agm__seg {
  cursor: pointer;
}
.ui-agm__step-hit {
  position: absolute;
  inset: 0;
  border-radius: inherit;
}
.ui-agm .ui-agm__step-hit:focus-visible {
  outline-offset: -2px;
}
.ui-agm__step > :not(.ui-agm__step-hit) {
  position: relative;
  pointer-events: none;
}
.ui-agm__step-icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 20px;
  height: 20px;
  border-radius: 6px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
  color: var(--ui-agm-muted);
}
.ui-agm__step-icon > svg {
  width: 12px;
  height: 12px;
}
.ui-agm__step-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  color: var(--ui-agm-text);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__step-time {
  flex: none;
  font-size: 12.5px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-faint);
}
.ui-agm__step[data-state="failed"] .ui-agm__step-time {
  color: var(--ui-agm-red);
}
.ui-agm__info {
  position: absolute;
  z-index: 2;
  right: 12px;
  left: 12px;
  display: grid;
  gap: 10px;
  padding: 12px;
  border-radius: 14px;
  background: var(--ui-agm-card);
  box-shadow:
    0 0 0 1px var(--ui-agm-line),
    0 12px 24px -8px rgba(0, 0, 0, 0.16),
    0 4px 8px -4px rgba(0, 0, 0, 0.06);
  transform-origin: 50% 0;
  animation: ui-agm-pop 260ms var(--ui-agm-ease) both;
}
.ui-agm__info-head {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}
.ui-agm__info-title {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-agm__info-label {
  overflow: hidden;
  font-weight: 600;
  line-height: 18px;
  color: var(--ui-agm-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__info-sub {
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-agm-muted);
}
.ui-agm__info-close {
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  margin: -2px -2px 0 0;
  border-radius: 8px;
  color: var(--ui-agm-faint);
  transition:
    background-color 160ms ease,
    color 160ms ease;
}
.ui-agm__info-close:hover {
  background: var(--ui-agm-lane);
  color: var(--ui-agm-ink);
}
.ui-agm__info-facts {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 4px;
  margin: 0;
}
.ui-agm__info-facts > div {
  display: grid;
  gap: 1px;
  padding: 6px 8px;
  border-radius: 9px;
  background: var(--ui-agm-lane);
}
.ui-agm__info-facts dt {
  font-size: 11px;
  line-height: 14px;
  color: var(--ui-agm-muted);
}
.ui-agm__info-facts dd {
  margin: 0;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 17px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-ink);
}
.ui-agm__info-facts dd[data-state="failed"] {
  color: var(--ui-agm-red);
}
.ui-agm__info-facts dd[data-state="running"] {
  color: var(--ui-agm-accent);
}
.ui-agm__info-detail {
  margin: 0;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-agm-text);
}
.ui-agm__info-output {
  display: block;
  overflow: hidden;
  padding: 6px 9px;
  border-radius: 8px;
  background: var(--ui-agm-lane);
  font-family: ui-monospace, "SF Mono", Menlo, monospace;
  font-size: 11.5px;
  line-height: 16px;
  letter-spacing: 0;
  color: var(--ui-agm-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__foot {
  display: flex;
  align-items: center;
  gap: 6px;
  min-height: 46px;
  padding: 8px 6px 4px 4px;
}
.ui-agm__where {
  flex: 1;
  padding-right: 4px;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-muted);
  text-align: right;
}
.ui-agm__morph {
  display: inline-grid;
  flex: none;
  align-items: center;
  transition: width 380ms var(--ui-agm-ease);
}
.ui-agm__morph-layer {
  grid-area: 1 / 1;
  justify-self: start;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  white-space: nowrap;
}
.ui-agm__morph-layer[data-leaving] {
  animation: ui-agm-morph-out 240ms ease both;
  pointer-events: none;
}
.ui-agm__morph-layer[data-coming] {
  animation: ui-agm-morph-in 380ms var(--ui-agm-ease) both;
}
.ui-agm__icon-end {
  overflow: hidden;
}
.ui-agm__icon-end .ui-agm__morph-layer,
.ui-agm__controls .ui-agm__morph-layer {
  transform-origin: 0 50%;
}
.ui-agm__icon-meta.ui-agm__shine {
  color: transparent;
}
.ui-agm__seg-label .ui-agm__morph-layer {
  gap: 5px;
}
.ui-agm__seg-label .ui-agm__morph-layer > svg {
  color: var(--ui-agm-muted);
}
.ui-agm__group {
  display: inline-flex;
  gap: 6px;
}
.ui-agm__seg-btn,
.ui-agm__btn {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  height: 32px;
  padding: 0 12px 0 10px;
  border-radius: 10px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-agm-ink);
  white-space: nowrap;
  transition:
    background-color 160ms ease,
    color 160ms ease,
    transform 160ms ease,
    opacity 160ms ease;
}
.ui-agm__seg-btn > svg {
  color: var(--ui-agm-muted);
}
.ui-agm__seg-btn:hover,
.ui-agm__btn:hover {
  background: var(--ui-agm-lane);
}
.ui-agm__seg-btn:active,
.ui-agm__btn:active {
  transform: scale(0.96);
}
.ui-agm__btn {
  padding: 0 12px;
}
.ui-agm__btn--go {
  padding: 0 10px 0 12px;
  background: var(--ui-agm-ink);
  box-shadow: none;
  color: var(--ui-agm-card);
}
.ui-agm__btn--go:hover {
  background: var(--ui-agm-ink);
  opacity: 0.86;
}
.ui-agm__btn--go > svg {
  color: inherit;
}
.ui-agm__btn--quiet {
  height: 30px;
  padding: 0 8px;
  background: none;
  box-shadow: none;
  color: var(--ui-agm-text);
}
.ui-agm__btn--quiet:hover {
  background: var(--ui-agm-fill);
  color: var(--ui-agm-ink);
}
.ui-agm__btn kbd {
  display: inline-grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 4px;
  border-radius: 5px;
  background: var(--ui-agm-card);
  box-shadow: 0 0 0 1px var(--ui-agm-line);
  font: inherit;
  font-size: 10.5px;
  font-weight: 400;
  color: var(--ui-agm-muted);
}
.ui-agm__btn--go kbd {
  background: rgba(255, 255, 255, 0.16);
  box-shadow: none;
  color: rgba(255, 255, 255, 0.8);
}
.ui-agm__icon {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: 12px;
  height: 48px;
  padding: 4px 14px 4px 4px;
  border-radius: 16px;
  background: var(--ui-agm-tray);
  text-align: left;
  transform-origin: 24px 50%;
  animation: ui-agm-open 300ms var(--ui-agm-ease) both;
}
.ui-agm__icon-who {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 40px;
  padding: 0 12px 0 5px;
  border-radius: 12px;
  background: var(--ui-agm-card);
  box-shadow: var(--ui-agm-shadow);
}
.ui-agm__icon-who .ui-agm__face {
  width: 30px;
  height: 30px;
  box-shadow: none;
  background: var(--ui-agm-lane);
}
.ui-agm__icon-name {
  max-width: 140px;
  overflow: hidden;
  font-size: 13px;
  font-weight: 600;
  color: var(--ui-agm-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__tools {
  display: flex;
  align-items: center;
}
.ui-agm__tool {
  position: relative;
  display: grid;
  flex: none;
  place-items: center;
  width: 26px;
  height: 26px;
  border-radius: 8px;
  background: var(--ui-agm-card);
  box-shadow:
    inset 0 0 0 1px var(--ui-agm-line),
    0 0 0 2px var(--ui-agm-tray);
  color: var(--ui-agm-muted);
  animation: ui-agm-join 480ms var(--ui-agm-ease) backwards;
  transition:
    transform 220ms var(--ui-agm-ease),
    box-shadow 220ms ease;
}
.ui-agm__tool + .ui-agm__tool {
  margin-left: -6px;
}
.ui-agm__tool > svg {
  width: 13px;
  height: 13px;
  opacity: 0.4;
  filter: grayscale(1);
  pointer-events: none;
  transition:
    opacity 300ms ease,
    filter 300ms ease;
}
.ui-agm__tool[data-live] {
  z-index: 1;
}
.ui-agm__tool[data-live] > svg,
.ui-agm[data-status="finished"] .ui-agm__tool > svg {
  opacity: 1;
  filter: none;
}
.ui-agm__tool[data-live="ask"] {
  background:
    linear-gradient(var(--ui-agm-amber-bg), var(--ui-agm-amber-bg)),
    var(--ui-agm-card);
}
.ui-agm__tool:hover {
  z-index: 3;
  transform: translateY(-4px);
  box-shadow:
    inset 0 0 0 1px var(--ui-agm-line),
    0 0 0 2px var(--ui-agm-tray),
    0 6px 12px -2px rgba(0, 0, 0, 0.14);
}
.ui-agm__tool:hover > svg {
  opacity: 1;
  filter: none;
}
.ui-agm__tip {
  position: absolute;
  bottom: calc(100% + 10px);
  left: 50%;
  display: grid;
  gap: 1px;
  width: max-content;
  max-width: 220px;
  padding: 8px 11px;
  border-radius: 11px;
  background: var(--ui-agm-card);
  box-shadow:
    0 0 0 1px var(--ui-agm-line),
    0 12px 24px -8px rgba(0, 0, 0, 0.16),
    0 4px 8px -4px rgba(0, 0, 0, 0.06);
  font-weight: 400;
  text-align: left;
  white-space: normal;
  opacity: 0;
  transform: translate(-50%, 4px) scale(0.97);
  transform-origin: 50% 100%;
  pointer-events: none;
  transition:
    opacity 160ms ease,
    transform 220ms var(--ui-agm-ease);
}
.ui-agm__tool:hover .ui-agm__tip {
  opacity: 1;
  transform: translate(-50%, 0);
}
.ui-agm__tip-title {
  overflow: hidden;
  font-size: 13px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-agm-strong);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-agm__tip-sub {
  font-size: 12px;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-muted);
}
.ui-agm__tools-more {
  flex: none;
  margin-right: 4px;
  font-size: 11px;
  font-weight: 500;
  color: var(--ui-agm-muted);
}
.ui-agm__icon-meta {
  flex: none;
  min-width: 36px;
  font-size: 13px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-ink);
  white-space: nowrap;
}
.ui-agm__icon-meta:is(
  [data-status="idle"],
  [data-status="paused"],
  [data-status="cancelled"]
) {
  color: var(--ui-agm-muted);
}
.ui-agm__done-tag {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 5px;
  height: 26px;
  padding: 0 10px 0 8px;
  border-radius: 999px;
  background: var(--ui-agm-green-bg);
  font-size: 12.5px;
  font-weight: 500;
  font-variant-numeric: tabular-nums;
  color: var(--ui-agm-green);
  white-space: nowrap;
}
.ui-agm__done-tag > svg {
  stroke-width: 1.8;
}
.ui-agm__done-tag[data-tone="ask"] {
  background: var(--ui-agm-amber-bg);
  color: var(--ui-agm-amber);
}
.ui-agm__done-tag[data-tone="ask"] > svg {
  stroke-width: 1.5;
}
.ui-agm__done-tag[data-tone="fail"] {
  background: var(--ui-agm-red-bg);
  color: var(--ui-agm-red);
}
@keyframes ui-agm-breathe {
  50% {
    opacity: 0.35;
  }
}
@keyframes ui-agm-pulse {
  from {
    opacity: 0.45;
    transform: scale(0.6);
  }
  to {
    opacity: 0;
    transform: scale(1.8);
  }
}
@keyframes ui-agm-pop {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.97);
  }
}
@keyframes ui-agm-morph-in {
  from {
    opacity: 0;
    transform: scale(0.88);
    filter: blur(3px);
  }
}
@keyframes ui-agm-morph-out {
  to {
    opacity: 0;
    transform: scale(0.88);
    filter: blur(3px);
  }
}
@keyframes ui-agm-join {
  from {
    width: 0;
    margin-left: 0;
    opacity: 0;
    transform: scale(0.5);
  }
  40% {
    opacity: 0;
  }
}
@keyframes ui-agm-drop {
  from {
    margin-top: -30px;
    opacity: 0;
    filter: blur(2px);
  }
}
@keyframes ui-agm-open {
  from {
    opacity: 0;
    transform: scale(0.92);
  }
}
@keyframes ui-agm-in {
  from {
    opacity: 0;
    transform: translateY(70%);
    filter: blur(2px);
  }
}
@keyframes ui-agm-out {
  to {
    opacity: 0;
    transform: translateY(-70%);
    filter: blur(2px);
  }
}
@keyframes ui-agm-shine {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@keyframes ui-agm-grow {
  from {
    clip-path: inset(0 100% 0 0 round 4px);
  }
  to {
    clip-path: inset(0 0 0 0 round 4px);
  }
}
@keyframes ui-agm-sheen {
  from {
    background-position: -100% 0;
  }
  to {
    background-position: 200% 0;
  }
}
@media (pointer: coarse) {
  .ui-agm__fold,
  .ui-agm__info-close {
    width: 36px;
    height: 36px;
  }
  .ui-agm__seg-btn,
  .ui-agm__btn {
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-agm *,
  .ui-agm *::before,
  .ui-agm *::after {
    animation-duration: 1ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 1ms !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-agm {
  --ui-agm-tray: #111113;
  --ui-agm-card: #19191b;
  --ui-agm-strong: #ededed;
  --ui-agm-ink: #ededed;
  --ui-agm-text: #a1a1a1;
  --ui-agm-muted: #8b8b92;
  --ui-agm-faint: #5c5c63;
  --ui-agm-line: #2a2a2e;
  --ui-agm-edge: #2a2a2e;
  --ui-agm-lane: #232326;
  --ui-agm-fill: #2a2a2e;
  --ui-agm-accent: #5b8cff;
  --ui-agm-accent-bg: rgba(91, 140, 255, 0.14);
  --ui-agm-green: #3ecf8e;
  --ui-agm-green-bg: rgba(62, 207, 142, 0.13);
  --ui-agm-red: #ff6b6b;
  --ui-agm-red-bg: rgba(255, 107, 107, 0.12);
  --ui-agm-amber: #f5b638;
  --ui-agm-amber-bg: rgba(245, 182, 56, 0.14);
  --ui-agm-shine: rgba(255, 255, 255, 0.95);
  --ui-agm-focus: rgba(77, 141, 255, 0.8);
  --ui-agm-seg: #2c2c30;
  --ui-agm-live: 91, 140, 255;
  --ui-agm-hot: #6b6b72;
  --ui-agm-shadow: 0 0 0 1px var(--ui-agm-line), 0 1px 2px rgba(0, 0, 0, 0.3);
}
:where(.dark, [data-theme="dark"]) .ui-agm__btn--go {
  color: #111113;
}
:where(.dark, [data-theme="dark"]) .ui-agm__btn--go kbd {
  background: rgba(0, 0, 0, 0.1);
  color: rgba(0, 0, 0, 0.6);
}
:where(.dark, [data-theme="dark"]) .ui-agm__seg[data-state="running"]::before {
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    rgba(255, 255, 255, 0.22) 50%,
    transparent 100%
  );
}
`;function n(a){return i.jsx(e,{...a,clean:!1,styles:t})}export{n as A};
