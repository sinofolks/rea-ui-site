import{j as o}from"./workbench-model-BwgilGut.js";import{M as e}from"./ModelPickerView-Dos8AgX5.js";function s(r){return o.jsx(e,{...r})}export{s as M};
