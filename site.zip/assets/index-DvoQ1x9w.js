import{r as a,j as i}from"./workbench-model-BwgilGut.js";function G({groups:l,value:u,defaultValue:p={},onChange:n,defaultOpen:m,title:f="Filters",hints:b=!0,className:B}){const c=(Array.isArray(l)?l:[]).filter(e=>!!e&&typeof e=="object").map(e=>({...e,label:String(e.label??""),options:(Array.isArray(e.options)?e.options:[]).filter(o=>!!o&&typeof o=="object").map(o=>({...o,label:String(o.label??"")}))})),S=a.useId(),[H,O]=a.useState(p),v=u??H,[h,E]=a.useState(()=>new Set(m??c.slice(0,1).map(e=>e.id))),[x,k]=a.useState(null),z=a.useRef(null),M=a.useRef(null),C=T(M),R=e=>{u===void 0&&O(e),n==null||n(e)},w=e=>Array.isArray(v[e])?v[e]:[],I=(e,o)=>w(e).includes(o),y=(e,o)=>{const t=w(e);R({...v,[e]:t.includes(o)?t.filter(r=>r!==o):[...t,o]})},_=e=>E(o=>{const t=new Set(o);return t.has(e)?t.delete(e):t.add(e),t}),D=new Set,F=c.flatMap(e=>e.options.filter(o=>I(e.id,o.id)&&!D.has(`${e.id}\0${o.id}`)&&!!D.add(`${e.id}\0${o.id}`)).map(o=>({group:e,option:o,label:`${e.chipPrefix??""}${o.label}`}))),s=c.flatMap((e,o)=>[{kind:"group",group:e,gi:o},...h.has(e.id)?e.options.map((t,r)=>({kind:"option",group:e,option:t,gi:o,oi:r})):[]]),j=e=>e.kind==="group"?`g:${e.gi}`:`o:${e.gi}:${e.oi}`,$=e=>{var o,t;k(e),(t=(o=z.current)==null?void 0:o.querySelector(`[data-key="${CSS.escape(e)}"]`))==null||t.focus()},L=e=>{const o=s.findIndex(r=>j(r)===x),t=s[o];if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();const r=s[Math.max(0,Math.min(s.length-1,o+(e.key==="ArrowDown"?1:-1)))]??s[0];$(j(r))}else if(e.key==="Home"||e.key==="End")e.preventDefault(),$(j(s[e.key==="Home"?0:s.length-1]));else if(t&&(e.key==="ArrowRight"||e.key==="ArrowLeft")){e.preventDefault();const r=t.group.id;e.key==="ArrowRight"&&!h.has(r)&&_(r),e.key==="ArrowLeft"&&(h.has(r)&&_(r),$(`g:${t.gi}`))}else t&&(e.key==="Enter"||e.key===" ")&&(e.preventDefault(),t.kind==="group"?_(t.group.id):y(t.group.id,t.option.id))};return i.jsxs("div",{className:["ui-fm",B].filter(Boolean).join(" "),children:[i.jsx("style",{href:"ui-filter-menu",precedence:"default",children:U}),i.jsxs("div",{className:"ui-fm__card",children:[i.jsxs("div",{className:"ui-fm__head",children:[i.jsx("span",{className:"ui-fm__title",dir:"auto",title:f,children:f}),i.jsx("button",{type:"button",className:"ui-fm__clear",disabled:F.length===0,onClick:()=>R({}),children:"Clear all"})]}),i.jsx("div",{className:"ui-fm__chips-outer",ref:C,children:i.jsx("div",{className:"ui-fm__chips",ref:M,"aria-live":"polite",children:F.map((e,o)=>i.jsxs("span",{className:"ui-fm__chip",children:[i.jsx("span",{className:"ui-fm__chip-label",dir:"auto",title:e.label,children:e.label}),i.jsx("button",{type:"button","aria-label":`Remove ${e.label}`,onClick:()=>y(e.group.id,e.option.id),children:i.jsx("svg",{viewBox:"0 0 24 24","aria-hidden":"true",children:i.jsx("path",{d:"M6.5 6.5l11 11M17.5 6.5l-11 11"})})})]},o))})}),i.jsx("div",{className:"ui-fm__groups",ref:z,onKeyDown:L,children:c.map((e,o)=>{const t=h.has(e.id),r=new Set(w(e.id).filter(d=>e.options.some(g=>g.id===d))).size,N=`g:${o}`;return i.jsxs("section",{className:"ui-fm__group","data-open":t?"":void 0,children:[i.jsxs("button",{type:"button",className:"ui-fm__group-head","data-key":N,tabIndex:x===N||x===null&&o===0?0:-1,"aria-expanded":t,"aria-controls":`${S}-${o}`,onFocus:()=>k(N),onClick:()=>_(e.id),children:[i.jsx("svg",{className:"ui-fm__chevron",viewBox:"0 0 24 24","aria-hidden":"true",children:i.jsx("path",{d:"M6.5 9.5 12 15l5.5-5.5"})}),i.jsx("span",{className:"ui-fm__group-label",dir:"auto",title:e.label,children:e.label}),i.jsx("span",{className:"ui-fm__group-count",children:e.options.length.toLocaleString("en-US")}),i.jsx("span",{className:"ui-fm__group-picked","aria-live":"polite",children:r>0?`${r} filter${r===1?"":"s"}`:""})]}),i.jsx("div",{className:"ui-fm__panel",id:`${S}-${o}`,role:"group","aria-label":e.label,children:i.jsx("div",{className:"ui-fm__panel-inner",children:e.options.map((d,g)=>{const A=`o:${o}:${g}`,K=I(e.id,d.id);return i.jsxs("button",{type:"button",role:"checkbox","aria-checked":K,className:"ui-fm__option","data-key":A,tabIndex:t&&x===A?0:-1,onFocus:()=>k(A),onClick:()=>y(e.id,d.id),children:[i.jsx("span",{className:"ui-fm__box","aria-hidden":"true",children:i.jsx("svg",{viewBox:"0 0 24 24",children:i.jsx("path",{d:"m6 12.5 4 4 8-9"})})}),i.jsx("span",{className:"ui-fm__option-label",dir:"auto",title:d.label,children:d.label})]},`${d.id}#${g}`)})})})]},`${e.id}#${o}`)})})]}),b&&i.jsxs("div",{className:"ui-fm__hints","aria-hidden":"true",children:[i.jsxs("span",{className:"ui-fm__hint",children:[i.jsx("kbd",{children:i.jsx("svg",{viewBox:"0 0 24 24",children:i.jsx("path",{d:"M12 5v14m0 0-5-5m5 5 5-5"})})}),i.jsx("kbd",{children:i.jsx("svg",{viewBox:"0 0 24 24",children:i.jsx("path",{d:"M12 19V5m0 0-5 5m5-5 5 5"})})}),"To navigate"]}),i.jsxs("span",{className:"ui-fm__hint",children:[i.jsx("kbd",{children:i.jsx("svg",{viewBox:"0 0 24 24",children:i.jsx("path",{d:"M18 6v6.5a2 2 0 0 1-2 2H7m0 0 3.5-3.5M7 14.5 10.5 18"})})}),"To select"]})]})]})}function T(l){const u=a.useRef(null);return a.useLayoutEffect(()=>{const p=u.current,n=l.current;if(!p||!n)return;const m=()=>{p.style.height=`${n.offsetHeight}px`};m();const f=new ResizeObserver(m);f.observe(n);const b=requestAnimationFrame(()=>p.setAttribute("data-smooth",""));return()=>{f.disconnect(),cancelAnimationFrame(b)}},[l]),u}const U=`
.ui-fm {
  --ui-fm-tray: #f0f0f0;
  --ui-fm-card: #ffffff;
  --ui-fm-card-line: #e5e5e5;
  --ui-fm-ink: #171717;
  --ui-fm-text: #404040;
  --ui-fm-muted: #626873;
  --ui-fm-chip: #f3f3f3;
  --ui-fm-chip-hover: #ebebeb;
  --ui-fm-box: #f0f0f0;
  --ui-fm-box-line: #e3e3e3;
  --ui-fm-check: #ffffff;
  --ui-fm-row-hover: #f7f7f7;
  --ui-fm-kbd: #ffffff;
  --ui-fm-focus: rgba(0, 96, 226, 0.7);
  --ui-fm-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
  --ui-fm-ease: cubic-bezier(0.22, 1, 0.36, 1);
  width: 100%;
  max-width: 420px;
  padding: 6px;
  border-radius: 24px;
  background: var(--ui-fm-tray);
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color: var(--ui-fm-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-fm *, .ui-fm *::before, .ui-fm *::after { box-sizing: border-box; }
.ui-fm button { font: inherit; color: inherit; margin: 0; cursor: pointer; -webkit-tap-highlight-color: transparent; }
.ui-fm button:focus-visible { outline: 2px solid var(--ui-fm-focus); outline-offset: 2px; }

.ui-fm__card {
  padding: 16px 16px 10px;
  border: 1px solid var(--ui-fm-card-line);
  border-radius: 20px;
  background: var(--ui-fm-card);
  box-shadow: var(--ui-fm-shadow);
}

/* ---------- Header ---------- */

.ui-fm__head { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 0 2px; }
.ui-fm__title { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; text-align: start; font-size: 15px; font-weight: 600; letter-spacing: -0.01em; }
.ui-fm__clear {
  flex: none;
  padding: 4px 6px;
  margin-right: -6px !important;
  border: 0;
  border-radius: 8px;
  background: none;
  font-size: 13px;
  color: var(--ui-fm-muted) !important;
  transition: color 160ms ease, background-color 160ms ease, opacity 200ms ease;
}
.ui-fm__clear:hover:not(:disabled) { color: var(--ui-fm-ink) !important; background: var(--ui-fm-row-hover); }
.ui-fm__clear:disabled { opacity: 0.45; cursor: default; }

/* ---------- Chips ---------- */

.ui-fm__chips-outer { overflow: hidden; }
.ui-fm__chips-outer[data-smooth] { transition: height 320ms var(--ui-fm-ease); }
.ui-fm__chips { display: flex; flex-wrap: wrap; gap: 6px; padding-top: 12px; }
.ui-fm__chips:empty { padding-top: 0; }
.ui-fm__chip {
  display: inline-flex;
  min-width: 0;
  max-width: 100%;
  align-items: center;
  gap: 2px;
  height: 30px;
  padding: 0 4px 0 11px;
  border-radius: 10px;
  background: var(--ui-fm-chip);
  font-size: 13px;
  color: var(--ui-fm-text);
  white-space: nowrap;
  animation: ui-fm-chip-in 260ms var(--ui-fm-ease) both;
}
.ui-fm__chip-label { min-width: 0; overflow: hidden; text-overflow: ellipsis; }
.ui-fm__chip button {
  display: grid;
  flex: none;
  place-items: center;
  width: 22px;
  height: 22px;
  padding: 0;
  border: 0;
  border-radius: 6px;
  background: none;
  color: var(--ui-fm-muted);
  transition: background-color 160ms ease, color 160ms ease;
}
.ui-fm__chip button:hover { background: var(--ui-fm-chip-hover); color: var(--ui-fm-ink); }
.ui-fm__chip svg { width: 14px; height: 14px; fill: none; stroke: currentColor; stroke-width: 1.8; stroke-linecap: round; }

/* ---------- Groups ---------- */

.ui-fm__groups { display: grid; grid-template-columns: minmax(0, 1fr); padding-top: 6px; }
.ui-fm__group-head {
  display: flex;
  align-items: center;
  gap: 7px;
  width: calc(100% + 12px);
  height: 36px;
  margin: 2px -6px 0 !important;
  padding: 0 8px 0 6px;
  border: 0;
  border-radius: 10px;
  background: none;
  text-align: left;
  transition: background-color 160ms ease;
}
.ui-fm__group-head:hover { background: var(--ui-fm-row-hover); }
.ui-fm__chevron {
  width: 16px;
  height: 16px;
  flex: none;
  fill: none;
  stroke: var(--ui-fm-text);
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
  transform: rotate(-90deg);
  transition: transform 260ms var(--ui-fm-ease);
}
.ui-fm__group[data-open] .ui-fm__chevron { transform: none; }
.ui-fm__group-label { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; text-align: start; font-size: 14px; font-weight: 500; }
.ui-fm__group-count { flex: none; font-size: 12.5px; color: var(--ui-fm-muted); font-variant-numeric: tabular-nums; }
.ui-fm__group-picked { flex: none; margin-left: auto; white-space: nowrap; font-size: 12.5px; color: var(--ui-fm-muted); }

.ui-fm__panel {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows 320ms var(--ui-fm-ease);
}
.ui-fm__group[data-open] .ui-fm__panel { grid-template-rows: 1fr; }
.ui-fm__panel-inner {
  min-height: 0;
  overflow: hidden;
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: 1px;
  padding: 0 0 0;
  opacity: 0;
  transition: opacity 220ms ease, padding 320ms var(--ui-fm-ease);
}
.ui-fm__group[data-open] .ui-fm__panel-inner { opacity: 1; padding: 2px 0 6px; }
/* A long list scrolls inside the open group, so the card keeps a sane height */
.ui-fm__group[data-open] .ui-fm__panel-inner { max-height: 340px; overflow-x: hidden; overflow-y: auto; overscroll-behavior: contain; }

.ui-fm__option {
  display: flex;
  align-items: center;
  gap: 12px;
  width: calc(100% + 12px);
  height: 34px;
  margin: 0 -6px !important;
  padding: 0 6px;
  border: 0;
  border-radius: 10px;
  background: none;
  font-size: 14px;
  color: var(--ui-fm-text) !important;
  text-align: left;
  transition: background-color 160ms ease;
}
.ui-fm__option-label { min-width: 0; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; text-align: start; }
.ui-fm__option:hover { background: var(--ui-fm-row-hover); }
.ui-fm__option:focus-visible { outline-offset: -2px; }
.ui-fm__box {
  display: grid;
  place-items: center;
  width: 20px;
  height: 20px;
  flex: none;
  border-radius: 6px;
  background: var(--ui-fm-box);
  box-shadow: inset 0 0 0 1px var(--ui-fm-box-line);
  transition: background-color 180ms ease, box-shadow 180ms ease;
}
.ui-fm__box svg {
  width: 14px;
  height: 14px;
  fill: none;
  stroke: var(--ui-fm-check);
  stroke-width: 2.2;
  stroke-linecap: round;
  stroke-linejoin: round;
  stroke-dasharray: 20;
  stroke-dashoffset: 20;
  transition: stroke-dashoffset 260ms var(--ui-fm-ease);
}
.ui-fm__option[aria-checked="true"] .ui-fm__box { background: var(--ui-fm-ink); box-shadow: inset 0 0 0 1px var(--ui-fm-ink); }
.ui-fm__option[aria-checked="true"] .ui-fm__box svg { stroke-dashoffset: 0; }

/* ---------- Keyboard hints on the tray ---------- */

.ui-fm__hints { display: flex; justify-content: space-between; gap: 12px; padding: 10px 8px 4px; }
.ui-fm__hint { display: inline-flex; align-items: center; gap: 5px; font-size: 12.5px; color: var(--ui-fm-text); }
.ui-fm__hint kbd {
  display: grid;
  place-items: center;
  width: 22px;
  height: 22px;
  border-radius: 6px;
  background: var(--ui-fm-kbd);
  box-shadow: 0 0 0 1px var(--ui-fm-card-line), 0 1px 1px rgba(0, 0, 0, 0.04);
}
.ui-fm__hint kbd:last-of-type { margin-right: 4px; }
.ui-fm__hint svg { width: 13px; height: 13px; fill: none; stroke: var(--ui-fm-text); stroke-width: 1.9; stroke-linecap: round; stroke-linejoin: round; }

@keyframes ui-fm-chip-in { from { opacity: 0; transform: scale(0.9); } }

@media (prefers-reduced-motion: reduce) {
  .ui-fm__chips-outer[data-smooth], .ui-fm__panel, .ui-fm__panel-inner, .ui-fm__chevron, .ui-fm__box svg { transition: none; }
  .ui-fm__chip { animation: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-fm {
  --ui-fm-tray: #161618;
  --ui-fm-card: #232326;
  --ui-fm-card-line: rgba(255, 255, 255, 0.08);
  --ui-fm-ink: #ededed;
  --ui-fm-text: #c4c4c4;
  --ui-fm-muted: #8f8f8f;
  --ui-fm-chip: #2a2a2d;
  --ui-fm-chip-hover: #313135;
  --ui-fm-box: #2a2a2d;
  --ui-fm-box-line: rgba(255, 255, 255, 0.1);
  --ui-fm-check: #121213;
  --ui-fm-row-hover: rgba(255, 255, 255, 0.05);
  --ui-fm-kbd: #232326;
  --ui-fm-focus: rgba(77, 141, 255, 0.8);
  --ui-fm-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
`;export{G as F};
