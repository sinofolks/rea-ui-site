import{j as i}from"./workbench-model-BwgilGut.js";import{A as u}from"./AgentCursorsView-BU08ebRB.js";const e=`
.ui-acu {
  --ui-acu-card: #ffffff;
  --ui-acu-tray: #f0f0f0;
  --ui-acu-ink: #171717;
  --ui-acu-text: #3d3d3d;
  --ui-acu-muted: #626873;
  --ui-acu-line: #ececec;
  --ui-acu-grid: #f0f0f0;
  --ui-acu-stroke: #efefef;
  --ui-acu-gap: 18px;
  --ui-acu-chip: #f5f5f5;
  --ui-acu-shimmer: #f0f0f0;
  --ui-acu-shine: #fafafa;
  --ui-acu-code: rgba(0, 0, 0, 0.035);
  --ui-acu-focus: rgba(0, 96, 226, 0.7);
  --ui-acu-agent: #1f1f22;
  --ui-acu-flag: #141416;
  --ui-acu-flag-ink: #ffffff;
  --ui-acu-flag-soft: rgba(255, 255, 255, 0.14);
  --ui-acu-edge: linear-gradient(90deg, #ff4fa3, #8b6bff 55%, #3b8bff);
  --ui-acu-c: var(--ui-acu-agent);
  --ui-acu-glide: 560ms;
  --ui-acu-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-acu-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-acu *,
.ui-acu *::before,
.ui-acu *::after {
  box-sizing: border-box;
}
:where(.ui-acu) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-acu button:focus-visible {
  outline: 2px solid var(--ui-acu-focus);
  outline-offset: 2px;
}
.ui-acu svg {
  display: block;
  flex: none;
}
.ui-acu__stage {
  position: relative;
}
.ui-acu {
  container: agc / inline-size;
}
.ui-acu__tabs {
  display: flex;
  gap: 6px;
  margin: 0 0 6px;
}
.ui-acu__tab {
  height: 30px;
  padding: 0 12px;
  border-radius: 9px;
  background: rgba(0, 0, 0, 0.05);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-acu-muted);
  transition:
    background-color 160ms ease,
    color 160ms ease,
    box-shadow 160ms ease;
}
.ui-acu__tab:hover {
  color: var(--ui-acu-ink);
}
.ui-acu__tab[aria-selected="true"] {
  background: var(--ui-acu-card);
  box-shadow:
    inset 0 0 0 1px var(--ui-acu-stroke),
    0 1px 2px rgba(0, 0, 0, 0.05);
  color: var(--ui-acu-ink);
}
:where(.dark, [data-theme="dark"]) .ui-acu__tab {
  background: rgba(255, 255, 255, 0.06);
}
.ui-acu__text {
  animation: ui-acu-view 380ms var(--ui-acu-ease) both;
}
@keyframes ui-acu-view {
  from {
    opacity: 0;
    filter: blur(2px);
    transform: translateY(4px);
  }
}
.ui-acu__table-card {
  overflow: hidden;
  border-radius: 12px;
  box-shadow:
    inset 0 0 0 1px var(--ui-acu-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  transition: height 420ms var(--ui-acu-ease);
}
.ui-acu__table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
  font-size: 13.5px;
  line-height: 20px;
}
.ui-acu__table :is(th, td) {
  height: 40px;
  padding: 0 12px;
  border-top: 1px solid var(--ui-acu-grid);
  border-left: 1px solid var(--ui-acu-grid);
  text-align: left;
  vertical-align: middle;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-acu__table :is(th, td):first-child {
  border-left: 0;
}
.ui-acu__table th:first-child {
  width: 38%;
}
.ui-acu__table th {
  border-top: 0;
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-acu-muted);
}
.ui-acu__table td {
  color: var(--ui-acu-ink);
}
.ui-acu__table tfoot td {
  height: 44px;
  padding: 0 6px;
}
.ui-acu__add {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  height: 30px;
  padding: 0 10px;
  border-radius: 8px;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-acu-muted);
  transition:
    background-color 140ms ease,
    color 140ms ease,
    transform 140ms ease;
}
.ui-acu__add[data-hover] {
  background: rgba(0, 0, 0, 0.04);
  color: var(--ui-acu-ink);
}
.ui-acu__add[data-pressed] {
  background: rgba(0, 0, 0, 0.08);
  transform: scale(0.97);
}
:where(.dark, [data-theme="dark"]) .ui-acu__add[data-hover] {
  background: rgba(255, 255, 255, 0.06);
}
:where(.dark, [data-theme="dark"]) .ui-acu__add[data-pressed] {
  background: rgba(255, 255, 255, 0.1);
}
.ui-acu__table tbody tr {
  animation: ui-acu-row 420ms var(--ui-acu-ease) both;
}
@keyframes ui-acu-row {
  from {
    opacity: 0;
    transform: translateY(-6px);
  }
}
.ui-acu__pill {
  display: inline-flex;
  align-items: center;
  height: 22px;
  padding: 0 8px;
  border-radius: 999px;
  background: var(--ui-acu-pill-bg);
  font-size: 12px;
  font-weight: 500;
  color: var(--ui-acu-pill-fg);
}
.ui-acu__pill[data-tone="gray"] {
  --ui-acu-pill-bg: rgba(0, 0, 0, 0.05);
  --ui-acu-pill-fg: #6b6b6b;
}
.ui-acu__pill[data-tone="blue"] {
  --ui-acu-pill-bg: #eaf1ff;
  --ui-acu-pill-fg: #2456d6;
}
.ui-acu__pill[data-tone="green"] {
  --ui-acu-pill-bg: #e6f6ec;
  --ui-acu-pill-fg: #187941;
}
.ui-acu__pill[data-tone="amber"] {
  --ui-acu-pill-bg: #fff3e0;
  --ui-acu-pill-fg: #a45200;
}
:where(.dark, [data-theme="dark"]) .ui-acu__pill[data-tone="gray"] {
  --ui-acu-pill-bg: rgba(255, 255, 255, 0.08);
  --ui-acu-pill-fg: #a1a1a6;
}
:where(.dark, [data-theme="dark"]) .ui-acu__pill[data-tone="blue"] {
  --ui-acu-pill-bg: #16243f;
  --ui-acu-pill-fg: #8ab4ff;
}
:where(.dark, [data-theme="dark"]) .ui-acu__pill[data-tone="green"] {
  --ui-acu-pill-bg: #12301f;
  --ui-acu-pill-fg: #3dd68c;
}
:where(.dark, [data-theme="dark"]) .ui-acu__pill[data-tone="amber"] {
  --ui-acu-pill-bg: #3a2410;
  --ui-acu-pill-fg: #ffa057;
}
.ui-acu__sheet {
  position: relative;
  overflow: hidden;
  border-radius: 20px;
  background: var(--ui-acu-tray);
}
.ui-acu__paper {
  position: absolute;
  inset: 48px 4px 4px;
  z-index: 0;
  border-radius: 16px;
  background: var(--ui-acu-card);
  box-shadow:
    0 0 0 1px var(--ui-acu-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-acu[data-fade] .ui-acu__sheet {
  height: var(--ui-acu-height);
}
.ui-acu__shade {
  position: absolute;
  inset: -40px;
  pointer-events: none;
}
.ui-acu__shade > span {
  position: absolute;
  inset: 40px;
  border-radius: 20px;
  box-shadow:
    0 0 0 1px var(--ui-acu-stroke),
    0 1px 2px rgba(0, 0, 0, 0.05),
    0 2px 10px rgba(0, 0, 0, 0.055);
}
.ui-acu[data-fade] .ui-acu__shade {
  bottom: auto;
  height: calc(var(--ui-acu-height) + 80px);
}
.ui-acu[data-fade] .ui-acu__sheet {
  -webkit-mask: linear-gradient(
    #000 0,
    #000 calc(var(--ui-acu-height) * 0.5),
    transparent calc(var(--ui-acu-height) * 0.97)
  );
  mask: linear-gradient(
    #000 0,
    #000 calc(var(--ui-acu-height) * 0.5),
    transparent calc(var(--ui-acu-height) * 0.97)
  );
}
.ui-acu[data-fade] .ui-acu__shade {
  -webkit-mask: linear-gradient(
    #000 0,
    #000 calc(40px + var(--ui-acu-height) * 0.5),
    transparent calc(40px + var(--ui-acu-height) * 0.97)
  );
  mask: linear-gradient(
    #000 0,
    #000 calc(40px + var(--ui-acu-height) * 0.5),
    transparent calc(40px + var(--ui-acu-height) * 0.97)
  );
}
.ui-acu__bar {
  position: relative;
  z-index: 3;
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  height: 48px;
  padding: 0 12px 0 16px;
}
.ui-acu__doc {
  display: grid;
  flex: none;
  place-items: center;
  color: var(--ui-acu-muted);
}
.ui-acu__title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-acu-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-acu__sum {
  flex: none;
  font-size: 12.5px;
  color: var(--ui-acu-muted);
  font-variant-numeric: tabular-nums;
}
.ui-acu__spent {
  margin-left: 8px;
  font-weight: 600;
  color: var(--ui-acu-ink);
  transition: opacity 200ms ease;
}
.ui-acu__spent[data-zero] {
  opacity: 0.35;
}
.ui-acu__all {
  flex: none;
  height: 28px;
  padding: 0 11px;
  border-radius: 9px;
  background: var(--ui-acu-ink);
  font-size: 12.5px;
  font-weight: 500;
  color: var(--ui-acu-card);
  transition: opacity 160ms ease;
}
.ui-acu__all:hover:not(:disabled) {
  opacity: 0.86;
}
.ui-acu__all:disabled {
  opacity: 0.2;
  cursor: default;
}
.ui-acu__people {
  display: flex;
  flex: none;
  align-items: center;
}
.ui-acu__face:first-child {
  margin-left: 0;
}
.ui-acu__face {
  position: relative;
  display: grid;
  place-items: center;
  width: 28px;
  height: 28px;
  margin-left: 4px;
  border-radius: 50%;
  background: var(--ui-acu-card);
  box-shadow:
    0 0 0 2px var(--ui-acu-tray),
    inset 0 0 0 1.5px var(--ui-acu-line);
  transition:
    transform 220ms var(--ui-acu-ease),
    opacity 220ms ease,
    box-shadow 220ms ease;
}
.ui-acu__face:not([data-here]) {
  opacity: 0.4;
}
.ui-acu__face[data-here]::before {
  content: "";
  position: absolute;
  inset: 0;
  border-radius: 50%;
  background: conic-gradient(
    from 0deg,
    transparent 0deg,
    transparent 60deg,
    var(--ui-acu-c) 360deg
  );
  -webkit-mask: radial-gradient(
    farthest-side,
    transparent calc(100% - 2px),
    #000 calc(100% - 1.5px)
  );
  mask: radial-gradient(
    farthest-side,
    transparent calc(100% - 2px),
    #000 calc(100% - 1.5px)
  );
  animation: ui-acu-spin 850ms linear infinite;
}
.ui-acu__face:hover,
.ui-acu__face[aria-pressed="true"] {
  z-index: 1;
  transform: translateY(-1px);
}
.ui-acu__face[aria-pressed="true"] {
  background: var(
    --ui-acu-tint,
    color-mix(in srgb, var(--ui-acu-c) 16%, var(--ui-acu-card))
  );
}
.ui-acu__face-mark,
.ui-acu__note-mark {
  display: grid;
  place-items: center;
  width: 14px;
  height: 14px;
}
.ui-acu__face-mark svg,
.ui-acu__note-mark svg {
  width: 14px;
  height: 14px;
}
.ui-acu__face-initial {
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-acu-c);
}
.ui-acu__face-tip {
  position: absolute;
  top: calc(100% + 8px);
  right: -6px;
  z-index: 4;
  padding: 5px 9px;
  border-radius: 8px;
  background: var(--ui-acu-ink);
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-acu-card);
  white-space: nowrap;
  opacity: 0;
  transform: translateY(-2px);
  pointer-events: none;
  transition:
    opacity 140ms ease,
    transform 140ms ease;
}
.ui-acu__face-tip {
  display: grid;
  gap: 1px;
  text-align: left;
}
.ui-acu__face-tip b {
  font-weight: 600;
}
.ui-acu__face-tip > span {
  opacity: 0.75;
}
.ui-acu__face:hover .ui-acu__face-tip,
.ui-acu__face:focus-visible .ui-acu__face-tip {
  opacity: 1;
  transform: none;
}
.ui-acu__text {
  position: relative;
  z-index: 1;
  padding: 36px 48px 48px;
  font-size: 14px;
  line-height: 23px;
  color: var(--ui-acu-text);
}
.ui-acu__block {
  margin: 0;
}
.ui-acu__text > * + * {
  margin-top: var(--ui-acu-gap);
}
.ui-acu__block--title {
  font-size: 22px;
  font-weight: 650;
  line-height: 28px;
  letter-spacing: -0.022em;
  color: var(--ui-acu-ink);
}
.ui-acu__text > .ui-acu__block--title + * {
  margin-top: 12px;
}
.ui-acu__block--heading {
  font-size: 15.5px;
  font-weight: 600;
  line-height: 24px;
  letter-spacing: -0.012em;
  color: var(--ui-acu-ink);
}
.ui-acu__text > .ui-acu__block--heading:not(:first-child) {
  margin-top: calc(var(--ui-acu-gap) + 10px);
}
.ui-acu__text > .ui-acu__block--heading + * {
  margin-top: 8px;
}
.ui-acu__list {
  margin: 0;
  padding: 0 0 0 20px;
}
.ui-acu__list .ui-acu__block + .ui-acu__block {
  margin-top: 4px;
}
.ui-acu__block--item::marker {
  color: var(--ui-acu-muted);
}
.ui-acu__code {
  margin: 0;
  padding: 14px 16px;
  overflow: hidden;
  border-radius: 12px;
  background: var(--ui-acu-code);
  box-shadow: inset 0 0 0 1px var(--ui-acu-line);
  font-family:
    ui-monospace, "SF Mono", "JetBrains Mono", Menlo, Consolas, monospace;
  font-size: 12.5px;
  line-height: 20px;
  letter-spacing: 0;
  color: var(--ui-acu-ink);
  white-space: pre-wrap;
}
.ui-acu__code code {
  font: inherit;
}
.ui-acu__figure {
  margin: 0;
}
.ui-acu__text::after {
  content: "";
  display: block;
  clear: both;
}
.ui-acu__figure {
  max-width: 100%;
  transition: width 620ms var(--ui-acu-ease);
}
.ui-acu__figure[data-float="left"] {
  float: left;
  margin: var(--ui-acu-gap) 24px 8px 0;
}
.ui-acu__figure[data-float="right"] {
  float: right;
  margin: var(--ui-acu-gap) 0 8px 24px;
}
.ui-acu__text > .ui-acu__figure[data-float] {
  margin-top: var(--ui-acu-gap);
}
.ui-acu__text > :is(.ui-acu__block--heading, .ui-acu__code, .ui-acu__list) {
  clear: both;
}
.ui-acu__sheet {
  container-type: inline-size;
}
@container (max-width: 480px) {
  .ui-acu__figure[data-float] {
    float: none;
    margin: 0 0 12px;
  }
}
.ui-acu__img {
  position: relative;
  display: grid;
  width: 100%;
  border-radius: 12px;
  background: var(--ui-acu-shimmer);
  transition: box-shadow 200ms ease;
}
.ui-acu__img > img {
  width: 100%;
  height: 100%;
  border-radius: inherit;
  object-fit: cover;
  animation: ui-acu-fade 500ms ease both;
}
.ui-acu__shimmer {
  display: block;
  width: 100%;
  height: 100%;
  border-radius: inherit;
  background: linear-gradient(
      100deg,
      var(--ui-acu-shimmer) 35%,
      var(--ui-acu-shine) 50%,
      var(--ui-acu-shimmer) 65%
    )
    0 0 / 300% 100%;
  animation: ui-acu-shimmer 1600ms linear infinite;
}
.ui-acu__img[data-held] {
  box-shadow: 0 0 0 2px var(--ui-acu-c);
}
.ui-acu__handle {
  position: absolute;
  width: 10px;
  height: 10px;
  border-radius: 3px;
  background: #ffffff;
  box-shadow:
    0 0 0 1.5px var(--ui-acu-c),
    0 1px 3px rgba(0, 0, 0, 0.18);
  animation: ui-acu-fade 160ms ease both;
}
.ui-acu__handle[data-at="tl"] {
  top: -5px;
  left: -5px;
}
.ui-acu__handle[data-at="tr"] {
  top: -5px;
  right: -5px;
}
.ui-acu__handle[data-at="bl"] {
  bottom: -5px;
  left: -5px;
}
.ui-acu__handle[data-at="br"] {
  right: -5px;
  bottom: -5px;
}
.ui-acu__size {
  position: absolute;
  bottom: 10px;
  left: 50%;
  translate: -50% 0;
  padding: 0 7px;
  border-radius: 6px;
  background: var(--ui-acu-c);
  font-size: 11.5px;
  font-weight: 600;
  line-height: 20px;
  color: #ffffff;
  white-space: nowrap;
  font-variant-numeric: tabular-nums;
  animation: ui-acu-fade 160ms ease both;
}
.ui-acu__caption {
  margin-top: 8px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-acu-muted);
}
.ui-acu__ins,
.ui-acu__del {
  border-radius: 3px;
  outline: none;
  cursor: pointer;
  transition: background-color 160ms ease;
  -webkit-box-decoration-break: clone;
  box-decoration-break: clone;
}
.ui-acu__ins {
  padding: 1px 0;
  background: color-mix(in srgb, var(--ui-acu-c) 12%, transparent);
  color: var(--ui-acu-ink);
  text-decoration: underline 1.5px var(--ui-acu-c);
  text-underline-offset: 4px;
  animation: ui-acu-in 300ms ease both;
}
.ui-acu__del {
  color: var(--ui-acu-muted);
  text-decoration: line-through 1.5px var(--ui-acu-c);
}
.ui-acu__ins:hover,
.ui-acu__ins[data-open],
.ui-acu__ins:focus-visible {
  background: color-mix(in srgb, var(--ui-acu-c) 22%, transparent);
}
.ui-acu__del:hover,
.ui-acu__del[data-open],
.ui-acu__del:focus-visible {
  background: color-mix(in srgb, var(--ui-acu-c) 10%, transparent);
}
.ui-acu__marks {
  position: absolute;
  inset: 0;
  z-index: 0;
  pointer-events: none;
}
.ui-acu__mark {
  position: absolute;
  border-radius: 3px;
  background: color-mix(in srgb, var(--ui-acu-c) 20%, transparent);
  animation: ui-acu-fade 220ms ease both;
  transition: opacity 220ms ease;
}
.ui-acu__mark[data-dim] {
  opacity: 0.25;
}
.ui-acu__notes {
  position: absolute;
  inset: 0;
  z-index: 4;
  pointer-events: none;
}
.ui-acu__pin {
  position: absolute;
  width: 0;
  height: 0;
  pointer-events: auto;
  animation: ui-acu-fade 260ms ease both;
}
.ui-acu__pin {
  --ui-acu-pin: 30px;
}
.ui-acu__pin-box {
  position: absolute;
  top: calc(var(--ui-acu-pin) * -1);
  left: var(--ui-acu-pin-x, 0px);
  width: var(--ui-acu-pin);
  height: var(--ui-acu-pin);
  overflow: hidden;
  border-radius: 15px 15px 15px 3px;
  background: var(--ui-acu-flag);
  color: var(--ui-acu-flag-ink);
  box-shadow:
    0 0 0 1px var(--ui-acu-flag-soft),
    0 8px 20px -8px rgba(0, 0, 0, 0.45);
  transition:
    left 340ms var(--ui-acu-ease),
    width 340ms var(--ui-acu-ease),
    height 340ms var(--ui-acu-ease),
    border-radius 340ms var(--ui-acu-ease),
    box-shadow 340ms ease;
}
.ui-acu__pin[data-up] .ui-acu__pin-box {
  top: auto;
  bottom: 0;
}
.ui-acu__pin[data-open] {
  z-index: 1;
}
.ui-acu__pin[data-open] .ui-acu__pin-box {
  width: var(--ui-acu-pin-w, 248px);
  height: var(--ui-acu-pin-h);
  border-radius: 14px;
  box-shadow:
    0 0 0 1px var(--ui-acu-flag-soft),
    0 16px 32px -14px rgba(0, 0, 0, 0.4);
}
.ui-acu__pin-mark {
  --ui-acu-ink: var(--ui-acu-flag-ink);
}
.ui-acu__pin-mark {
  position: absolute;
  z-index: 1;
  top: 7px;
  left: 7px;
  display: grid;
  place-items: center;
  width: 16px;
  height: 16px;
  transition:
    top 340ms var(--ui-acu-ease),
    left 340ms var(--ui-acu-ease),
    width 340ms var(--ui-acu-ease),
    height 340ms var(--ui-acu-ease);
  pointer-events: none;
}
.ui-acu__pin-mark svg {
  width: 100%;
  height: 100%;
}
.ui-acu__pin[data-open] .ui-acu__pin-mark {
  top: 11px;
  left: 12px;
  width: 14px;
  height: 14px;
}
.ui-acu__pin-hit {
  position: absolute;
  inset: 0;
  z-index: 2;
  border-radius: inherit;
}
.ui-acu__pin[data-open] .ui-acu__pin-hit {
  pointer-events: none;
}
.ui-acu__pin-body {
  position: absolute;
  top: 0;
  left: 0;
  display: grid;
  gap: 4px;
  width: var(--ui-acu-pin-w, 248px);
  padding: 10px 10px 10px 12px;
  opacity: 0;
  transition: opacity 120ms ease;
}
.ui-acu__pin[data-up] .ui-acu__pin-body {
  top: auto;
  bottom: 0;
}
.ui-acu__pin[data-open] .ui-acu__pin-body {
  opacity: 1;
  transition: opacity 200ms ease 140ms;
}
.ui-acu__pin-body .ui-acu__note-head {
  padding-left: 22px;
  color: color-mix(in srgb, var(--ui-acu-flag-ink) 50%, transparent);
}
.ui-acu__pin-body .ui-acu__note-head b {
  color: var(--ui-acu-flag-ink);
}
.ui-acu__pin-body .ui-acu__note-text {
  color: color-mix(in srgb, var(--ui-acu-flag-ink) 86%, transparent);
}
.ui-acu__note-head {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-acu-muted);
}
.ui-acu__note-head b {
  font-weight: 600;
  color: var(--ui-acu-ink);
}
.ui-acu__note-head > span:last-child {
  margin-left: auto;
}
.ui-acu__note-text {
  margin: 0;
  font-size: 13px;
  line-height: 19px;
  color: var(--ui-acu-text);
}
.ui-acu__pin-actions {
  display: flex;
  gap: 6px;
  margin-top: 6px;
}
.ui-acu__reply {
  flex: 1;
  min-width: 0;
  height: 30px;
  padding: 0 10px;
  border: 0;
  border-radius: 9px;
  background: var(--ui-acu-flag-soft);
  box-shadow: inset 0 0 0 1px var(--ui-acu-flag-soft);
  font: inherit;
  font-size: 13px;
  color: var(--ui-acu-flag-ink);
  outline: none;
}
.ui-acu__reply::placeholder {
  color: color-mix(in srgb, var(--ui-acu-flag-ink) 45%, transparent);
}
.ui-acu__reply:is(:focus, :focus-visible) {
  outline: none;
  box-shadow: inset 0 0 0 1px
    color-mix(in srgb, var(--ui-acu-flag-ink) 28%, transparent);
}
.ui-acu__resolve {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  background: var(--ui-acu-flag-ink);
  color: var(--ui-acu-flag);
  transition: opacity 160ms ease;
}
.ui-acu__resolve:hover {
  opacity: 0.86;
}
.ui-acu__cursors {
  position: absolute;
  inset: 0;
  z-index: 3;
  pointer-events: none;
}
.ui-acu__cursor-in {
  transition: opacity 260ms ease;
}
.ui-acu__cursor {
  position: absolute;
  top: 0;
  left: 0;
  transition:
    transform var(--ui-acu-glide) var(--ui-acu-ease),
    opacity 260ms ease;
  will-change: transform;
}
.ui-acu__cursor[data-typing] {
  transition:
    transform 110ms linear,
    opacity 260ms ease;
}
.ui-acu__cursor[data-drag] {
  transition: opacity 260ms ease;
}
.ui-acu__cursor[data-arrive] {
  transition: none;
  opacity: 0;
}
.ui-acu__cursor:not([data-arrive]):not([data-gone]) {
  animation: ui-acu-pop 300ms var(--ui-acu-ease) both;
}
.ui-acu__cursor[data-gone] {
  opacity: 0;
}
.ui-acu__cursor[data-dim] {
  opacity: 0.22;
}
.ui-acu__cursor[data-gone][data-dim] {
  opacity: 0;
}
.ui-acu__caret {
  position: absolute;
  top: 0;
  left: -1px;
  width: 2px;
  height: var(--ui-acu-h, 18px);
  border-radius: 1px;
  background: var(--ui-acu-c);
  animation: ui-acu-blink 1100ms steps(1, end) infinite;
}
.ui-acu__cursor[data-typing] .ui-acu__caret {
  animation: none;
}
.ui-acu__cursor[data-free] .ui-acu__caret {
  display: none;
}
.ui-acu__arrow {
  position: absolute;
  z-index: 1;
  top: calc(var(--ui-acu-h, 18px) - 6px);
  left: 0;
  width: 19px;
  height: 23px;
  overflow: visible;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.22));
}
.ui-acu__cursor[data-free] .ui-acu__arrow {
  top: -0.6px;
  left: -2.3px;
}
.ui-acu__arrow {
  transform-origin: 2px 1px;
  transition: transform 140ms ease;
}
.ui-acu__cursor[data-press] .ui-acu__arrow {
  transform: scale(0.82);
}
.ui-acu__arrow path {
  fill: var(--ui-acu-c);
  stroke: #ffffff;
  stroke-width: 1.4;
  paint-order: stroke;
}
.ui-acu__flag {
  position: absolute;
  top: calc(var(--ui-acu-h, 18px) + 15px);
  left: calc(16px + var(--ui-acu-shift, 0px));
  display: grid;
  width: max-content;
  padding: 6px 10px 6px;
  border-bottom: 1px solid transparent;
  border-radius: 10px;
  background:
    linear-gradient(var(--ui-acu-flag), var(--ui-acu-flag)) padding-box,
    var(--ui-acu-edge) border-box;
  box-shadow:
    0 8px 18px -8px rgba(255, 79, 163, 0.5),
    6px 8px 18px -8px rgba(59, 139, 255, 0.5),
    0 2px 6px -2px rgba(0, 0, 0, 0.3);
  font-size: 12px;
  font-weight: 600;
  line-height: 16px;
  color: var(--ui-acu-flag-ink);
  white-space: nowrap;
}
.ui-acu__cursor[data-in-note] .ui-acu__flag {
  opacity: 0;
}
.ui-acu__cursor[data-free] .ui-acu__flag {
  top: 21px;
  left: calc(14px + var(--ui-acu-shift, 0px));
}
.ui-acu__flag-row {
  display: flex;
  align-items: center;
  gap: 12px;
}
.ui-acu__flag-tags {
  display: flex;
  gap: 4px;
  margin-left: auto;
}
.ui-acu__flag-tag {
  padding: 0 5px;
  border-radius: 5px;
  background: var(--ui-acu-flag-soft);
  font-size: 10.5px;
  font-weight: 600;
  line-height: 16px;
  font-variant-numeric: tabular-nums;
}
.ui-acu__flag-doing {
  display: block;
  max-height: 0;
  overflow: hidden;
  opacity: 0;
  transition:
    max-height 320ms var(--ui-acu-ease),
    opacity 200ms ease,
    margin-top 320ms var(--ui-acu-ease);
}
.ui-acu__flag-doing > span {
  display: block;
  width: max-content;
  font-size: 11.5px;
  font-weight: 500;
  white-space: nowrap;
}
.ui-acu__flag-doing[data-on] {
  max-height: 18px;
  margin-top: 1px;
  opacity: 0.9;
}
.ui-acu__cursor[data-dim] .ui-acu__flag-doing {
  max-height: 0;
  opacity: 0;
}
.ui-acu__pop {
  position: absolute;
  z-index: 5;
  display: grid;
  gap: 6px;
  width: 260px;
  padding: 10px;
  border-radius: 14px;
  background: var(--ui-acu-card);
  box-shadow:
    0 0 0 1px var(--ui-acu-line),
    0 16px 32px -12px rgba(0, 0, 0, 0.22);
  animation: ui-acu-rise 180ms var(--ui-acu-ease) both;
}
.ui-acu__pop-head {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-acu-muted);
}
.ui-acu__pop-head b {
  font-weight: 600;
  color: var(--ui-acu-ink);
}
.ui-acu__pop-mark {
  display: grid;
  flex: none;
  place-items: center;
  width: 14px;
  height: 14px;
}
.ui-acu__pop-mark svg {
  width: 100%;
  height: 100%;
}
.ui-acu__pop-note {
  margin: 0;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-acu-text);
}
.ui-acu__pop-actions {
  display: flex;
  justify-content: flex-end;
  gap: 6px;
  margin-top: 2px;
}
.ui-acu__btn {
  display: inline-flex;
  align-items: center;
  height: 30px;
  padding: 0 12px;
  border-radius: 9px;
  background: var(--ui-acu-card);
  box-shadow:
    0 0 0 1px var(--ui-acu-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-acu-ink);
  transition:
    background-color 160ms ease,
    opacity 160ms ease;
}
.ui-acu__btn:hover {
  background: var(--ui-acu-chip);
}
.ui-acu__btn--primary {
  background: var(--ui-acu-ink);
  box-shadow: none;
  color: var(--ui-acu-card);
}
.ui-acu__btn--primary:hover {
  background: var(--ui-acu-ink);
  opacity: 0.86;
}
.ui-acu__live {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip: rect(0 0 0 0);
  white-space: nowrap;
}
@keyframes ui-acu-blink {
  0%,
  55% {
    opacity: 1;
  }
  56%,
  100% {
    opacity: 0;
  }
}
@keyframes ui-acu-pop {
  from {
    opacity: 0;
    scale: 0.85;
  }
}
@keyframes ui-acu-fade {
  from {
    opacity: 0;
  }
}
@keyframes ui-acu-in {
  from {
    background-color: transparent;
  }
}
@keyframes ui-acu-rise {
  from {
    opacity: 0;
    transform: translateY(-4px) scale(0.98);
  }
}
@keyframes ui-acu-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ui-acu-shimmer {
  from {
    background-position: 100% 0;
  }
  to {
    background-position: 0 0;
  }
}
@media (max-width: 520px) {
  .ui-acu__text {
    padding: 26px 22px 36px;
    font-size: 14px;
    line-height: 23px;
  }
  .ui-acu__block--title {
    font-size: 20px;
    line-height: 26px;
  }
  .ui-acu__sum {
    display: none;
  }
}
@container agc (max-width: 480px) {
  .ui-acu__bar {
    gap: 6px;
    padding: 0 8px 0 12px;
  }
  .ui-acu__title {
    display: none;
  }
  .ui-acu__doc {
    margin-right: auto;
  }
  .ui-acu__face {
    width: 26px;
    height: 26px;
    margin-left: 2px;
  }
  .ui-acu__all {
    padding: 0 9px;
    font-size: 12px;
  }
  .ui-acu__text {
    padding: 24px 20px 32px;
  }
  .ui-acu__flag {
    padding: 4px 8px 4px;
    border-radius: 8px;
    font-size: 11px;
    line-height: 14px;
  }
  .ui-acu__flag-tag {
    padding: 0 4px;
    font-size: 10px;
    line-height: 14px;
  }
  .ui-acu__flag-doing > span {
    font-size: 10.5px;
  }
  .ui-acu__flag-row {
    gap: 8px;
  }
  .ui-acu__table {
    font-size: 11.5px;
    line-height: 16px;
  }
  .ui-acu__table :is(th, td) {
    height: auto;
    padding: 8px 5px;
    white-space: normal;
    text-overflow: clip;
  }
  .ui-acu__table :is(th, td):first-child {
    padding-left: 9px;
  }
  .ui-acu__table th {
    font-size: 11px;
  }
  .ui-acu__table th:first-child {
    width: 30%;
  }
  .ui-acu__pill {
    display: inline-block;
    height: auto;
    min-height: 18px;
    padding: 1px 6px;
    font-size: 10.5px;
    line-height: 16px;
    white-space: normal;
  }
}
@container agc (max-width: 340px) {
  .ui-acu__text {
    padding-right: 12px;
    padding-left: 12px;
  }
  .ui-acu__table {
    font-size: 11px;
  }
  .ui-acu__table th:first-child {
    width: 28%;
  }
}
@media (pointer: coarse) {
  .ui-acu__face {
    width: 32px;
    height: 32px;
  }
  .ui-acu__btn {
    height: 36px;
    padding: 0 14px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-acu *,
  .ui-acu *::before,
  .ui-acu *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-acu {
  --ui-acu-card: #1f1f22;
  --ui-acu-tray: #161618;
  --ui-acu-ink: #ededed;
  --ui-acu-text: #c4c4c8;
  --ui-acu-muted: #7c7c82;
  --ui-acu-line: #2e2e33;
  --ui-acu-grid: #29292d;
  --ui-acu-stroke: #2c2c31;
  --ui-acu-chip: #2a2a2e;
  --ui-acu-shimmer: #29292d;
  --ui-acu-shine: #36363b;
  --ui-acu-code: rgba(255, 255, 255, 0.04);
  --ui-acu-focus: rgba(77, 141, 255, 0.8);
  --ui-acu-agent: #e4e4e7;
  --ui-acu-flag: #f4f4f5;
  --ui-acu-flag-ink: #141416;
  --ui-acu-flag-soft: rgba(0, 0, 0, 0.08);
}
:where(.dark, [data-theme="dark"]) .ui-acu__arrow path {
  stroke: #1f1f22;
}
:where(.dark, [data-theme="dark"]) .ui-acu__handle {
  background: #1f1f22;
}
.ui-acu__text,
.ui-acu__code,
.ui-acu__note-text,
.ui-acu__pop-note {
  overflow-wrap: anywhere;
}
.ui-acu__block,
.ui-acu__caption,
.ui-acu__note-text,
.ui-acu__pop-note {
  text-align: start;
}
.ui-acu__block,
.ui-acu__note-text {
  white-space: pre-line;
}
.ui-acu__tabs {
  flex-wrap: wrap;
}
.ui-acu__tab {
  max-width: 100%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-acu__face-more {
  flex: none;
  width: auto;
  min-width: 24px;
  padding: 0 5px;
  border-radius: 999px;
  font-size: 10.5px;
  font-weight: 600;
  line-height: 1;
  color: var(--ui-acu-muted);
  font-variant-numeric: tabular-nums;
  cursor: default;
}
.ui-acu__face-tip {
  grid-template-columns: minmax(0, 1fr);
  max-width: 240px;
}
.ui-acu__face-tip > * {
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-acu__pin-body {
  grid-template-columns: minmax(0, 1fr);
}
.ui-acu__note-head b,
.ui-acu__pop-head b {
  min-width: 0;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-acu__note-head > span,
.ui-acu__pop-head > span {
  flex: none;
}
.ui-acu__flag {
  grid-template-columns: minmax(0, 1fr);
  max-width: min(260px, calc(100cqw - 16px));
}
.ui-acu__flag-row {
  min-width: 0;
}
.ui-acu__flag-name {
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
.ui-acu__flag-tags {
  flex: none;
}
.ui-acu__flag-doing > span {
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
}
`;function o(a){return i.jsx(u,{...a,clean:!1,styles:e})}export{o as A};
