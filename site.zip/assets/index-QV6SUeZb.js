import{j as a}from"./workbench-model-BwgilGut.js";import{A as e}from"./AutonomyView-BO5vsPtQ.js";const d=`
.ui-adl {
  --ui-adl-tray: #f0f0f0;
  --ui-adl-card: #ffffff;
  --ui-adl-ink: #171717;
  --ui-adl-text: #6b6b6b;
  --ui-adl-muted: #626873;
  --ui-adl-faint: #6b6b6b;
  --ui-adl-line: #ececec;
  --ui-adl-chip: #f5f5f5;
  --ui-adl-track: #f0f0f0;
  --ui-adl-accent: #2a5ee5;
  --ui-adl-warn-bg: #fff3e0;
  --ui-adl-warn-fg: #a45200;
  --ui-adl-danger-bg: #fdecea;
  --ui-adl-danger-fg: #c2331f;
  --ui-adl-focus: rgba(0, 96, 226, 0.7);
  --ui-adl-ease: cubic-bezier(0.22, 1, 0.36, 1);
  position: relative;
  box-sizing: border-box;
  width: 100%;
  max-width: 420px;
  padding: 4px;
  overflow: hidden;
  border-radius: 20px;
  background: var(--ui-adl-tray);
  container-type: inline-size;
  font-family:
    "Inter",
    ui-sans-serif,
    system-ui,
    -apple-system,
    "Segoe UI",
    Roboto,
    sans-serif;
  font-size: 14px;
  line-height: 20px;
  letter-spacing: -0.006em;
  color: var(--ui-adl-text);
  text-align: left;
  -webkit-font-smoothing: antialiased;
}
.ui-adl *,
.ui-adl *::before,
.ui-adl *::after {
  box-sizing: border-box;
}
:where(.ui-adl) button {
  margin: 0;
  padding: 0;
  border: 0;
  background: none;
  font: inherit;
  color: inherit;
  text-align: inherit;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-adl button:focus-visible {
  outline: 2px solid var(--ui-adl-focus);
  outline-offset: 2px;
}
.ui-adl ul {
  margin: 0;
  padding: 0;
  list-style: none;
}
.ui-adl h4 {
  margin: 0;
}
.ui-adl svg {
  display: block;
  flex: none;
}
.ui-adl__sr {
  position: absolute;
  width: 1px;
  height: 1px;
  overflow: hidden;
  clip-path: inset(50%);
  white-space: nowrap;
}
.ui-adl__card {
  position: relative;
  border-radius: 16px;
  background: var(--ui-adl-card);
  box-shadow:
    0 0 0 1px var(--ui-adl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-adl__head {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 16px 16px 0;
}
.ui-adl__spark {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  color: var(--ui-adl-accent);
}
.ui-adl__heading {
  display: grid;
  min-width: 0;
}
.ui-adl__title {
  overflow: hidden;
  font-weight: 600;
  color: var(--ui-adl-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-adl__sub {
  overflow: hidden;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-adl-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-adl__levels {
  padding: 14px 16px 16px;
}
.ui-adl__segmented {
  position: relative;
  display: flex;
  padding: 3px;
  border-radius: 12px;
  background: var(--ui-adl-track);
}
.ui-adl__pill {
  position: absolute;
  top: 3px;
  bottom: 3px;
  left: 0;
  width: var(--w, 0);
  border-radius: 9px;
  background: var(--ui-adl-card);
  box-shadow:
    0 1px 2px rgba(0, 0, 0, 0.08),
    0 0 0 1px rgba(0, 0, 0, 0.04);
  transform: translateX(var(--x, 0));
  transition:
    transform 320ms var(--ui-adl-ease),
    width 320ms var(--ui-adl-ease);
}
.ui-adl__level {
  position: relative;
  flex: 1;
  height: 30px;
  padding: 0 10px;
  border-radius: 9px;
  font-size: 13px;
  font-weight: 500;
  color: var(--ui-adl-muted);
  text-align: center !important;
  white-space: nowrap;
  transition: color 200ms ease;
}
.ui-adl__level[aria-checked="true"] {
  color: var(--ui-adl-ink);
}
.ui-adl__level[aria-checked="false"]:hover {
  color: var(--ui-adl-ink);
}
.ui-adl__groups {
  display: grid;
  gap: 14px;
  padding: 14px 4px 4px;
}
.ui-adl__group-head {
  display: flex;
  align-items: center;
  gap: 6px;
  margin: 0 8px 8px !important;
  font-size: 12.5px;
  font-weight: 500;
  line-height: 18px;
  color: var(--ui-adl-muted);
}
.ui-adl__count {
  display: grid;
  place-items: center;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  overflow: hidden;
  border-radius: 6px;
  background: var(--ui-adl-card);
  box-shadow:
    0 0 0 1px var(--ui-adl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
  font-size: 11px;
  color: var(--ui-adl-text);
  font-variant-numeric: tabular-nums;
}
.ui-adl__roll {
  display: block;
}
.ui-adl__roll[data-dir="up"] {
  animation: ui-adl-roll-up 360ms var(--ui-adl-ease) both;
}
.ui-adl__roll[data-dir="down"] {
  animation: ui-adl-roll-down 360ms var(--ui-adl-ease) both;
}
.ui-adl__list {
  display: grid;
  gap: 4px;
}
.ui-adl__row {
  position: relative;
  display: flex;
  align-items: center;
  gap: 12px;
  min-height: 42px;
  padding: 4px 6px 4px 14px;
  border-radius: 12px;
  background: var(--ui-adl-card);
  box-shadow:
    0 0 0 1px var(--ui-adl-line),
    0 1px 2px rgba(0, 0, 0, 0.04);
}
.ui-adl__icon {
  display: grid;
  flex: none;
  place-items: center;
  width: 16px;
  height: 16px;
  color: var(--ui-adl-muted);
}
.ui-adl__icon > svg {
  width: 16px;
  height: 16px;
}
.ui-adl__icon {
  overflow: hidden;
}
.ui-adl__icon > img {
  display: block;
  width: 16px;
  height: 16px;
  object-fit: contain;
}
.ui-adl__name {
  display: grid;
  flex: 1;
  min-width: 0;
}
.ui-adl__line {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
}
.ui-adl__label {
  overflow: hidden;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--ui-adl-ink);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-adl__detail {
  overflow: hidden;
  font-size: 12px;
  line-height: 16px;
  color: var(--ui-adl-muted);
  white-space: nowrap;
  text-overflow: ellipsis;
}
.ui-adl__risk {
  display: inline-flex;
  flex: none;
  align-items: center;
  gap: 3px;
  height: 20px;
  padding: 0 8px 0 6px;
  border-radius: 999px;
  background: var(--ui-adl-warn-bg);
  font-size: 11.5px;
  font-weight: 500;
  line-height: 16px;
  color: var(--ui-adl-warn-fg);
}
.ui-adl__risk > svg {
  width: 12px;
  height: 12px;
}
.ui-adl__risk[data-risk="destructive"] {
  background: var(--ui-adl-danger-bg);
  color: var(--ui-adl-danger-fg);
}
.ui-adl__pin {
  display: grid;
  flex: none;
  place-items: center;
  width: 30px;
  height: 30px;
  border-radius: 9px;
  color: var(--ui-adl-faint);
  opacity: 0;
  transition:
    opacity 160ms ease,
    color 160ms ease,
    background-color 160ms ease;
}
.ui-adl__row:hover .ui-adl__pin,
.ui-adl__pin:focus-visible,
.ui-adl__pin[aria-pressed="true"] {
  opacity: 1;
}
.ui-adl__pin:hover {
  background: var(--ui-adl-chip);
  color: var(--ui-adl-ink);
}
.ui-adl__pin[aria-pressed="true"] {
  color: var(--ui-adl-text);
}
.ui-adl__empty {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 42px;
  padding: 8px 12px;
  border-radius: 12px;
  background: rgba(0, 0, 0, 0.035);
  font-size: 12.5px;
  line-height: 18px;
  color: var(--ui-adl-muted);
  text-align: center;
}
@keyframes ui-adl-roll-up {
  from {
    opacity: 0;
    transform: translateY(70%);
  }
}
@keyframes ui-adl-roll-down {
  from {
    opacity: 0;
    transform: translateY(-70%);
  }
}
@container (max-width: 340px) {
  .ui-adl__detail {
    display: none;
  }
  .ui-adl__level {
    padding: 0 6px;
    font-size: 12px;
  }
}
@media (hover: none) {
  .ui-adl__pin {
    opacity: 1;
  }
}
@media (pointer: coarse) {
  .ui-adl__level {
    height: 36px;
  }
  .ui-adl__pin {
    width: 36px;
    height: 36px;
  }
}
@media (prefers-reduced-motion: reduce) {
  .ui-adl *,
  .ui-adl *::before,
  .ui-adl *::after {
    animation: none !important;
    transition: none !important;
  }
}
:where(.dark, [data-theme="dark"]) .ui-adl {
  --ui-adl-tray: #111113;
  --ui-adl-card: #19191b;
  --ui-adl-ink: #ededed;
  --ui-adl-text: #a1a1a1;
  --ui-adl-muted: #8b8b92;
  --ui-adl-faint: #5c5c63;
  --ui-adl-line: #2a2a2e;
  --ui-adl-chip: #232326;
  --ui-adl-track: #232326;
  --ui-adl-accent: #5b8cff;
  --ui-adl-warn-bg: rgba(255, 160, 87, 0.14);
  --ui-adl-warn-fg: #ffa057;
  --ui-adl-danger-bg: rgba(255, 119, 102, 0.14);
  --ui-adl-danger-fg: #ff977d;
  --ui-adl-focus: rgba(77, 141, 255, 0.8);
}
:where(.dark, [data-theme="dark"]) .ui-adl__pill {
  background: #2c2c30;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-adl__empty {
  background: rgba(255, 255, 255, 0.04);
}
`;function t(i){return a.jsx(e,{...i,styles:d,clean:!1})}export{t as A};
