import{j as e}from"./workbench-model-BwgilGut.js";function f({title:a="What's changed",period:t,icon:o,changes:s,className:d}){return e.jsxs(e.Fragment,{children:[e.jsx("style",{href:"ui-change-summary",precedence:"default",children:p}),e.jsxs("section",{className:["ui-cs",d].filter(Boolean).join(" "),"aria-label":a,children:[e.jsxs("header",{className:"ui-cs__head",children:[e.jsxs("span",{className:"ui-cs__title",children:[e.jsx("span",{className:"ui-cs__icon",children:o??e.jsx(l,{})}),e.jsx("span",{className:"ui-cs__title-text",dir:"auto",title:a,children:a})]}),t&&e.jsx("span",{className:"ui-cs__period",dir:"auto",title:t,children:t})]}),s.length>0&&e.jsx("dl",{className:"ui-cs__card",children:s.map((i,n)=>{const r=i.tone==="good"||i.tone==="bad"?i.tone:"neutral",c=i.direction??(r==="bad"?"down":"up");return e.jsxs("div",{className:"ui-cs__row",style:{animationDelay:`${120+Math.min(n,12)*70}ms`},children:[e.jsx("dt",{className:"ui-cs__label",dir:"auto",title:i.label,children:i.label}),e.jsxs("dd",{className:"ui-cs__change",children:[e.jsx("span",{className:"ui-cs__trend","data-tone":r,"aria-hidden":"true",children:r==="neutral"?e.jsx(u,{}):e.jsx(h,{down:c==="down"})}),e.jsx("span",{className:"ui-cs__text",dir:"auto",title:i.change,children:i.change})]})]},`${n}-${i.label}`)})})]})]})}const l=()=>e.jsx("svg",{viewBox:"0 0 16 16",width:"16",height:"16",fill:"none",stroke:"currentColor",strokeWidth:"1.5",strokeLinecap:"round","aria-hidden":"true",children:e.jsx("path",{d:"M2.5 4h4M2.5 8h8M6.5 12h7M9.5 4h1"})}),h=({down:a})=>e.jsx("svg",{viewBox:"0 0 12 12",width:"12",height:"12",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round","aria-hidden":"true",children:a?e.jsx("path",{d:"M6 2.5v7M3 6.5l3 3 3-3"}):e.jsx("path",{d:"M6 9.5v-7M3 5.5l3-3 3 3"})}),u=()=>e.jsx("svg",{viewBox:"0 0 12 12",width:"12",height:"12",fill:"none",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round","aria-hidden":"true",children:e.jsx("path",{d:"M3 6h6"})}),p=`
.ui-cs {
  --ui-cs-tray: #f0f0f0;
  --ui-cs-card: #ffffff;
  --ui-cs-line: #f0f0f0;
  --ui-cs-ink: #171717;
  --ui-cs-muted: #626873;
  --ui-cs-accent: #2a5ee5;
  --ui-cs-ease: cubic-bezier(0.22, 1, 0.36, 1);
  box-sizing: border-box;
  width: 100%;
  max-width: 480px;
  container-type: inline-size;
  /* Like the Chat Composer: a gray tray with the heading, the white card sits on top of it */
  background: var(--ui-cs-tray);
  /* The gray tray frames the white card on every side */
  padding: 6px;
  border-radius: 22px;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color: var(--ui-cs-ink);
  -webkit-font-smoothing: antialiased;
}
.ui-cs *, .ui-cs *::before, .ui-cs *::after { box-sizing: border-box; }

.ui-cs__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  padding: 11px 18px 10px;
  font-size: 14px;
  line-height: 20px;
}
.ui-cs__title {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  font-weight: 500;
  color: var(--ui-cs-accent);
}
.ui-cs__icon { display: grid; place-items: center; flex: none; width: 16px; height: 16px; overflow: hidden; }
/* A custom icon – an image too – fits the 16px tile */
.ui-cs__icon > :is(img, svg) { display: block; width: 16px; height: 16px; object-fit: contain; }
.ui-cs__title-text { min-width: 0; overflow-wrap: anywhere; }
/* The period shortens before it squeezes the title */
.ui-cs__period { flex: 0 1 auto; min-width: 0; max-width: 50%; overflow: hidden; font-size: 13px; white-space: nowrap; text-overflow: ellipsis; color: var(--ui-cs-muted); }

.ui-cs__card {
  margin: 0;
  overflow: hidden;
  background: var(--ui-cs-card);
  border: 1px solid #e5e5e5;
  border-radius: 16px;
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.06);
}
.ui-cs__row {
  display: grid;
  grid-template-columns: minmax(0, 0.8fr) minmax(0, 1.2fr);
  align-items: center;
  gap: 16px;
  min-height: 52px;
  padding: 0 20px;
  animation: ui-cs-in 520ms var(--ui-cs-ease) both;
  transition: background-color 140ms ease;
}
.ui-cs__row + .ui-cs__row { border-top: 1px solid var(--ui-cs-line); }
.ui-cs__row:hover { background: #fafafa; }
.ui-cs__label {
  overflow: hidden;
  font-size: 14px;
  font-weight: 500;
  line-height: 20px;
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow-wrap: anywhere;
  text-align: start;
}
.ui-cs__change {
  display: flex;
  align-items: center;
  gap: 8px;
  min-width: 0;
  margin: 0;
  font-size: 14px;
  line-height: 20px;
  color: var(--ui-cs-muted);
}
/* The change keeps its numbers: it wraps up to three lines instead of being cut off */
.ui-cs__text { display: -webkit-box; overflow: hidden; white-space: pre-line; overflow-wrap: anywhere; text-align: start; -webkit-line-clamp: 3; -webkit-box-orient: vertical; }
/* Narrow: each metric stacks above its change, so the text wraps instead of being cut off */
@container (max-width: 400px) {
  .ui-cs__row { grid-template-columns: minmax(0, 1fr); gap: 4px; padding: 11px 16px; }
  .ui-cs__label { white-space: normal; }
  .ui-cs__change { align-items: flex-start; }
}
.ui-cs__trend {
  display: grid;
  place-items: center;
  flex: none;
  width: 20px;
  height: 20px;
  border-radius: 6px;
}
.ui-cs__trend[data-tone="good"] { background: #edfaf3; color: #197840; }
.ui-cs__trend[data-tone="bad"] { background: #fff0f0; color: #bf383d; }
.ui-cs__trend[data-tone="neutral"] { background: #f5f5f5; color: #626873; }

@keyframes ui-cs-in {
  from { opacity: 0; transform: translateY(4px); }
}
@media (prefers-reduced-motion: reduce) {
  .ui-cs__row { animation: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-cs {
  --ui-cs-tray: #161618;
  --ui-cs-card: #232326;
  --ui-cs-line: rgba(255, 255, 255, 0.08);
  --ui-cs-ink: #ededed;
  --ui-cs-muted: #8f8f8f;
  --ui-cs-accent: #6b95ff;
}
:where(.dark, [data-theme="dark"]) .ui-cs__card {
  border-color: rgba(255, 255, 255, 0.08);
  box-shadow: 0 1px 2px rgba(0, 0, 0, 0.4);
}
:where(.dark, [data-theme="dark"]) .ui-cs__row:hover { background: #2a2a2d; }
:where(.dark, [data-theme="dark"]) .ui-cs__trend[data-tone="good"] { background: rgba(31, 138, 76, 0.18); color: #3fbf74; }
:where(.dark, [data-theme="dark"]) .ui-cs__trend[data-tone="bad"] { background: rgba(229, 72, 77, 0.16); color: #f2777b; }
:where(.dark, [data-theme="dark"]) .ui-cs__trend[data-tone="neutral"] { background: #2a2a2d; color: #8f8f8f; }
`;export{f as C};
