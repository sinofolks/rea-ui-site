import{r as b,j as e}from"./workbench-model-BwgilGut.js";import{t as A}from"./react-BkAXpnfr-Clok0bvh.js";import{t as D}from"./jsx-runtime-CTsRTJUX-CoXrQeBV.js";const I=[{title:"Triggered by events",hint:"Webhooks",icon:"bolt"},{title:"Grounded in your data",hint:"Context",icon:"database"},{title:"Connected to your apps",hint:"APIs",icon:"plug"},{title:"Works with any model",hint:"Routing",icon:"spark"},{title:"Traced at every step",hint:"Logs",icon:"pulse"}],l=104,E=26,T=34,Z=24,L=9,S=168,B=109;function Q({items:u=I,defaultIndex:j=0,interval:y=2600,onChange:c,className:M}){const d="ui-lyr"+b.useId().replace(/[^a-zA-Z0-9_-]/g,""),t=(u.length?u:I).slice(0,5),[a,f]=b.useState(Math.min(j,t.length-1)),[h,o]=b.useState(!1),p=b.useRef(!1);b.useEffect(()=>{if(h||p.current||t.length<2||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;const r=window.setInterval(()=>f(i=>(i+1)%t.length),y);return()=>window.clearInterval(r)},[h,y,t.length]);const v=r=>{p.current=!0,f(r),c==null||c(r)},N=t.length-1,$=r=>B+r*E-(r<a?T+Z:r===a&&a<N?T:0);return e.jsxs("div",{className:["ui-lyr",M].filter(Boolean).join(" "),onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),onFocus:()=>o(!0),onBlur:()=>o(!1),children:[e.jsx("style",{href:"ui-layer-stack",precedence:"default",children:V}),e.jsxs("svg",{className:"ui-lyr-stack",viewBox:"0 0 600 400","aria-hidden":"true",children:[e.jsx("defs",{children:e.jsx("filter",{id:`${d}-glow`,x:"-60%",y:"-120%",width:"220%",height:"340%",children:e.jsx("feGaussianBlur",{stdDeviation:"14"})})}),t.map((r,i)=>e.jsxs("g",{className:"ui-lyr-layer","data-active":i===a?"":void 0,"data-above":i<a?"":void 0,style:{transform:`translate(${S}px, ${$(i)}px)`},children:[e.jsx("ellipse",{className:"ui-lyr-glow",cx:0,cy:l/2+L+18,rx:70,ry:24,filter:`url(#${d}-glow)`}),e.jsxs("g",{transform:`translate(0 ${L}) matrix(1 0.5 -1 0.5 0 0)`,children:[e.jsx("rect",{className:"ui-lyr-side",width:l,height:l,rx:9}),e.jsx("rect",{className:"ui-lyr-side-on",width:l,height:l,rx:9})]}),e.jsxs("g",{transform:"matrix(1 0.5 -1 0.5 0 0)",children:[e.jsx("rect",{className:"ui-lyr-face",width:l,height:l,rx:9}),e.jsx("rect",{className:"ui-lyr-face-on",width:l,height:l,rx:9}),e.jsx("g",{className:"ui-lyr-icon",transform:`translate(${l/2-18} ${l/2-18}) scale(1.5)`,children:P[r.icon??"bolt"]})]})]},i)).reverse()]}),e.jsxs("div",{className:"ui-lyr-menu",role:"tablist","aria-label":"Layers","aria-orientation":"vertical",children:[e.jsx("span",{className:"ui-lyr-pill","aria-hidden":"true",style:{transform:`translateY(calc(${a} * var(--ui-lyr-row)))`}}),t.map((r,i)=>e.jsxs("button",{type:"button",role:"tab","aria-selected":i===a,tabIndex:i===a?0:-1,className:"ui-lyr-row",onClick:()=>v(i),onKeyDown:n=>{var w,x;const g=n.key==="ArrowDown"?i+1:n.key==="ArrowUp"?i-1:null;if(g===null)return;n.preventDefault();const m=(g+t.length)%t.length;v(m),(x=(w=n.currentTarget.parentElement)==null?void 0:w.children[m+1])==null||x.focus()},children:[e.jsx("span",{className:"ui-lyr-title",children:r.title}),r.hint&&e.jsx("span",{className:"ui-lyr-hint",children:r.hint})]},i))]})]})}const P={bolt:e.jsx("path",{d:"M13 3 5 13.5h6L10 21l8-10.5h-6L13 3Z"}),database:e.jsxs(e.Fragment,{children:[e.jsx("ellipse",{cx:"12",cy:"6",rx:"7",ry:"3"}),e.jsx("path",{d:"M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"})]}),plug:e.jsx("path",{d:"M9 3v5M15 3v5M6.5 8h11v3a5.5 5.5 0 0 1-11 0V8ZM12 16.5V21"}),spark:e.jsx("path",{d:"M12 3c.6 4.6 2.4 6.4 7 7-4.6.6-6.4 2.4-7 7-.6-4.6-2.4-6.4-7-7 4.6-.6 6.4-2.4 7-7ZM18.5 15.5c.2 1.5.8 2.1 2.3 2.3-1.5.2-2.1.8-2.3 2.3-.2-1.5-.8-2.1-2.3-2.3 1.5-.2 2.1-.8 2.3-2.3Z"}),pulse:e.jsx("path",{d:"M3 12h4l2.5-6 5 12 2.5-6h4"})},V=`
.ui-lyr {
  /* 1 unit of the 600 × 400 layout grid */
  --u: calc(100cqw / 600);
  --ui-lyr-row: calc(52 * var(--u));
  /* The accent blue used across the library */
  --ui-lyr-accent: #2f6bff;
  --ui-lyr-accent-deep: #2557d9;
  --ui-lyr-tint: #e9f0ff;
  --ui-lyr-glow: rgba(47, 107, 255, 0.28);
  --ui-lyr-face: rgba(255, 255, 255, 0.6);
  --ui-lyr-edge: rgba(10, 10, 10, 0.11);
  --ui-lyr-side: #ececef;
  --ui-lyr-face-above: rgba(255, 255, 255, 0.3);
  --ui-lyr-side-above: rgba(236, 236, 239, 0.55);
  --ui-lyr-panel: #f5f5f5;
  --ui-lyr-pill: #ffffff;
  --ui-lyr-pill-ring: #e5e5e5;
  --ui-lyr-text: #171717;
  --ui-lyr-muted: #8f8f8f;
  --ui-lyr-ease: cubic-bezier(0.65, 0, 0.25, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  container-type: inline-size;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, sans-serif;
  -webkit-font-smoothing: antialiased;
}
.ui-lyr *, .ui-lyr *::before, .ui-lyr *::after { box-sizing: border-box; }

/* ---------- Stack ---------- */

.ui-lyr-stack { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }
.ui-lyr-layer { transition: transform 560ms var(--ui-lyr-ease); }
.ui-lyr-glow {
  fill: var(--ui-lyr-glow);
  opacity: 0;
  transition: opacity 420ms ease;
}
.ui-lyr-layer[data-active] .ui-lyr-glow { opacity: 1; }
.ui-lyr-side-on {
  fill: var(--ui-lyr-accent-deep);
  opacity: 0;
  transition: opacity 360ms ease;
}
.ui-lyr-side {
  fill: var(--ui-lyr-side);
  stroke: var(--ui-lyr-edge);
  stroke-width: 1;
  vector-effect: non-scaling-stroke;
  transition: fill 360ms ease, stroke 360ms ease;
}
.ui-lyr-face {
  fill: var(--ui-lyr-face);
  stroke: var(--ui-lyr-edge);
  stroke-width: 1;
  vector-effect: non-scaling-stroke;
  transition: fill 360ms ease, stroke 360ms ease;
}
.ui-lyr-face-on {
  fill: var(--ui-lyr-tint);
  stroke: var(--ui-lyr-accent);
  opacity: 0;
  stroke-width: 1.6;
  vector-effect: non-scaling-stroke;
  transition: opacity 360ms ease;
}
.ui-lyr-icon {
  fill: none;
  stroke: var(--ui-lyr-accent);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
  transition: opacity 300ms ease;
}
/* Layers above the chosen one turn more glassy, so its color shows through */
.ui-lyr-layer[data-above] .ui-lyr-face { fill: var(--ui-lyr-face-above); }
.ui-lyr-layer[data-above] .ui-lyr-side { fill: var(--ui-lyr-side-above); }
.ui-lyr-layer[data-active] .ui-lyr-side-on { opacity: 1; }
.ui-lyr-layer[data-active] .ui-lyr-face-on { opacity: 1; }
.ui-lyr-layer[data-active] .ui-lyr-icon { opacity: 1; transition-delay: 120ms; }

/* ---------- Menu ---------- */

.ui-lyr-menu {
  position: absolute;
  left: calc(326 * var(--u));
  top: 50%;
  width: calc(248 * var(--u));
  padding: calc(8 * var(--u));
  transform: translateY(-50%);
  border-radius: calc(18 * var(--u));
  background: var(--ui-lyr-panel);
}
/* White card that glides behind the chosen row */
.ui-lyr-pill {
  position: absolute;
  left: calc(8 * var(--u));
  right: calc(8 * var(--u));
  top: calc(8 * var(--u));
  height: var(--ui-lyr-row);
  border-radius: calc(12 * var(--u));
  background: var(--ui-lyr-pill);
  box-shadow: 0 0 0 1px var(--ui-lyr-pill-ring), 0 1px 2px rgba(0, 0, 0, 0.05);
  transition: transform 460ms var(--ui-lyr-ease);
}
.ui-lyr-row {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: calc(10 * var(--u));
  width: 100%;
  height: var(--ui-lyr-row);
  margin: 0;
  padding: 0 calc(14 * var(--u));
  border: 0;
  border-radius: calc(12 * var(--u));
  background: transparent;
  font: inherit;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-lyr-row:focus-visible { outline: 2px solid var(--ui-lyr-accent); outline-offset: -2px; }
.ui-lyr-title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: calc(14 * var(--u));
  font-weight: 500;
  line-height: 1.3;
  letter-spacing: -0.01em;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-lyr-text);
  transition: color 300ms ease;
}
.ui-lyr-hint {
  /* The title comes first – the hint gives way and ends in … */
  flex: 0 10000 auto;
  min-width: 0;
  max-width: 45%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: calc(12 * var(--u));
  line-height: 1.3;
  color: var(--ui-lyr-muted);
}
.ui-lyr-row[aria-selected="true"] .ui-lyr-title { color: var(--ui-lyr-accent); }

@media (prefers-reduced-motion: reduce) {
  .ui-lyr-layer, .ui-lyr-glow, .ui-lyr-pill { transition: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-lyr {
  --ui-lyr-accent: #6b95ff;
  --ui-lyr-accent-deep: #2f6bff;
  --ui-lyr-tint: #1f2c4d;
  --ui-lyr-glow: rgba(47, 107, 255, 0.3);
  --ui-lyr-face: rgba(255, 255, 255, 0.04);
  --ui-lyr-edge: rgba(255, 255, 255, 0.13);
  --ui-lyr-side: #26262a;
  --ui-lyr-face-above: rgba(255, 255, 255, 0.025);
  --ui-lyr-side-above: rgba(38, 38, 42, 0.5);
  --ui-lyr-panel: #161618;
  --ui-lyr-pill: #232326;
  --ui-lyr-pill-ring: rgba(255, 255, 255, 0.08);
  --ui-lyr-text: #ededed;
  --ui-lyr-muted: #8f8f8f;
}
`;var k=A(),_=D(),z=[{title:"Triggered by events",hint:"Webhooks",icon:"bolt"},{title:"Grounded in your data",hint:"Context",icon:"database"},{title:"Connected to your apps",hint:"APIs",icon:"plug"},{title:"Works with any model",hint:"Routing",icon:"spark"},{title:"Traced at every step",hint:"Logs",icon:"pulse"}],s=104,W=26,F=34,G=9,R=168,Y=109;function K({items:u=z,defaultIndex:j=0,interval:y=2600,onChange:c,className:M}){let d="ui-lyr"+(0,k.useId)().replace(/[^a-zA-Z0-9_-]/g,""),t=(u.length?u:z).slice(0,5),[a,f]=(0,k.useState)(Math.min(j,t.length-1)),[h,o]=(0,k.useState)(!1),p=(0,k.useRef)(!1);(0,k.useEffect)(()=>{if(h||p.current||t.length<2||window.matchMedia("(prefers-reduced-motion: reduce)").matches)return;let r=window.setInterval(()=>f(i=>(i+1)%t.length),y);return()=>window.clearInterval(r)},[h,y,t.length]);let v=r=>{p.current=!0,f(r),c==null||c(r)},N=t.length-1,$=r=>Y+r*W-(r<a?58:r===a&&a<N?F:0);return e.jsxs("div",{className:["ui-lyr",M].filter(Boolean).join(" "),onMouseEnter:()=>o(!0),onMouseLeave:()=>o(!1),onFocus:()=>o(!0),onBlur:()=>o(!1),children:[e.jsx("style",{href:"ui-layer-stack",precedence:"default",children:q}),e.jsxs("svg",{className:"ui-lyr-stack",viewBox:"0 0 600 400","aria-hidden":"true",children:[e.jsx("defs",{children:e.jsx("filter",{id:`${d}-glow`,x:"-60%",y:"-120%",width:"220%",height:"340%",children:e.jsx("feGaussianBlur",{stdDeviation:"14"})})}),t.map((r,i)=>e.jsxs("g",{className:"ui-lyr-layer","data-active":i===a?"":void 0,"data-above":i<a?"":void 0,style:{transform:`translate(${R}px, ${$(i)}px)`},children:[e.jsx("ellipse",{className:"ui-lyr-glow",cx:0,cy:79,rx:70,ry:24,filter:`url(#${d}-glow)`}),e.jsxs("g",{transform:`translate(0 ${G}) matrix(1 0.5 -1 0.5 0 0)`,children:[e.jsx("rect",{className:"ui-lyr-side",width:s,height:s,rx:9}),e.jsx("rect",{className:"ui-lyr-side-on",width:s,height:s,rx:9})]}),e.jsxs("g",{transform:"matrix(1 0.5 -1 0.5 0 0)",children:[e.jsx("rect",{className:"ui-lyr-face",width:s,height:s,rx:9}),e.jsx("rect",{className:"ui-lyr-face-on",width:s,height:s,rx:9}),e.jsx("g",{className:"ui-lyr-icon",transform:`translate(${s/2-18} ${s/2-18}) scale(1.5)`,children:O[r.icon??"bolt"]})]})]},i)).reverse()]}),e.jsxs("div",{className:"ui-lyr-menu",role:"tablist","aria-label":"Layers","aria-orientation":"vertical",children:[e.jsx("span",{className:"ui-lyr-pill","aria-hidden":"true",style:{transform:`translateY(calc(${a} * var(--ui-lyr-row)))`}}),t.map((r,i)=>e.jsxs("button",{type:"button",role:"tab","aria-selected":i===a,tabIndex:i===a?0:-1,className:"ui-lyr-row",onClick:()=>v(i),onKeyDown:n=>{var w,x;let g=n.key==="ArrowDown"?i+1:n.key==="ArrowUp"?i-1:null;if(g===null)return;n.preventDefault();let m=(g+t.length)%t.length;v(m),(x=(w=n.currentTarget.parentElement)==null?void 0:w.children[m+1])==null||x.focus()},children:[e.jsx("span",{className:"ui-lyr-title",children:r.title}),r.hint&&e.jsx("span",{className:"ui-lyr-hint",children:r.hint})]},i))]})]})}var O={bolt:e.jsx("path",{d:"M13 3 5 13.5h6L10 21l8-10.5h-6L13 3Z"}),database:e.jsxs(_.Fragment,{children:[e.jsx("ellipse",{cx:"12",cy:"6",rx:"7",ry:"3"}),e.jsx("path",{d:"M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"})]}),plug:e.jsx("path",{d:"M9 3v5M15 3v5M6.5 8h11v3a5.5 5.5 0 0 1-11 0V8ZM12 16.5V21"}),spark:e.jsx("path",{d:"M12 3c.6 4.6 2.4 6.4 7 7-4.6.6-6.4 2.4-7 7-.6-4.6-2.4-6.4-7-7 4.6-.6 6.4-2.4 7-7ZM18.5 15.5c.2 1.5.8 2.1 2.3 2.3-1.5.2-2.1.8-2.3 2.3-.2-1.5-.8-2.1-2.3-2.3 1.5-.2 2.1-.8 2.3-2.3Z"}),pulse:e.jsx("path",{d:"M3 12h4l2.5-6 5 12 2.5-6h4"})},q=`
.ui-lyr {
  /* 1 unit of the 600 × 400 layout grid */
  --u: calc(100cqw / 600);
  --ui-lyr-row: calc(52 * var(--u));
  /* The accent blue used across the library */
  --ui-lyr-accent: #2f6bff;
  --ui-lyr-accent-deep: #2557d9;
  --ui-lyr-tint: #e9f0ff;
  --ui-lyr-glow: rgba(47, 107, 255, 0.28);
  --ui-lyr-face: rgba(255, 255, 255, 0.6);
  --ui-lyr-edge: rgba(10, 10, 10, 0.11);
  --ui-lyr-side: #ececef;
  --ui-lyr-face-above: rgba(255, 255, 255, 0.3);
  --ui-lyr-side-above: rgba(236, 236, 239, 0.55);
  --ui-lyr-panel: #f5f5f5;
  --ui-lyr-pill: #ffffff;
  --ui-lyr-pill-ring: #e5e5e5;
  --ui-lyr-text: #171717;
  --ui-lyr-muted: #8f8f8f;
  --ui-lyr-ease: cubic-bezier(0.65, 0, 0.25, 1);
  position: relative;
  width: 100%;
  aspect-ratio: 3 / 2;
  container-type: inline-size;
  font-family: "Inter", ui-sans-serif, system-ui, -apple-system, sans-serif;
  -webkit-font-smoothing: antialiased;
}
.ui-lyr *, .ui-lyr *::before, .ui-lyr *::after { box-sizing: border-box; }

/* ---------- Stack ---------- */

.ui-lyr-stack { position: absolute; inset: 0; width: 100%; height: 100%; overflow: visible; }
.ui-lyr-layer { transition: transform 560ms var(--ui-lyr-ease); }
.ui-lyr-glow {
  fill: var(--ui-lyr-glow);
  opacity: 0;
  transition: opacity 420ms ease;
}
.ui-lyr-layer[data-active] .ui-lyr-glow { opacity: 1; }
.ui-lyr-side-on {
  fill: var(--ui-lyr-accent-deep);
  opacity: 0;
  transition: opacity 360ms ease;
}
.ui-lyr-side {
  fill: var(--ui-lyr-side);
  stroke: var(--ui-lyr-edge);
  stroke-width: 1;
  vector-effect: non-scaling-stroke;
  transition: fill 360ms ease, stroke 360ms ease;
}
.ui-lyr-face {
  fill: var(--ui-lyr-face);
  stroke: var(--ui-lyr-edge);
  stroke-width: 1;
  vector-effect: non-scaling-stroke;
  transition: fill 360ms ease, stroke 360ms ease;
}
.ui-lyr-face-on {
  fill: var(--ui-lyr-tint);
  stroke: var(--ui-lyr-accent);
  opacity: 0;
  stroke-width: 1.6;
  vector-effect: non-scaling-stroke;
  transition: opacity 360ms ease;
}
.ui-lyr-icon {
  fill: none;
  stroke: var(--ui-lyr-accent);
  stroke-width: 1.5;
  stroke-linecap: round;
  stroke-linejoin: round;
  opacity: 0;
  transition: opacity 300ms ease;
}
/* Layers above the chosen one turn more glassy, so its color shows through */
.ui-lyr-layer[data-above] .ui-lyr-face { fill: var(--ui-lyr-face-above); }
.ui-lyr-layer[data-above] .ui-lyr-side { fill: var(--ui-lyr-side-above); }
.ui-lyr-layer[data-active] .ui-lyr-side-on { opacity: 1; }
.ui-lyr-layer[data-active] .ui-lyr-face-on { opacity: 1; }
.ui-lyr-layer[data-active] .ui-lyr-icon { opacity: 1; transition-delay: 120ms; }

/* ---------- Menu ---------- */

.ui-lyr-menu {
  position: absolute;
  left: calc(326 * var(--u));
  top: 50%;
  width: calc(248 * var(--u));
  padding: calc(8 * var(--u));
  transform: translateY(-50%);
  border-radius: calc(18 * var(--u));
  background: var(--ui-lyr-panel);
}
/* White card that glides behind the chosen row */
.ui-lyr-pill {
  position: absolute;
  left: calc(8 * var(--u));
  right: calc(8 * var(--u));
  top: calc(8 * var(--u));
  height: var(--ui-lyr-row);
  border-radius: calc(12 * var(--u));
  background: var(--ui-lyr-pill);
  box-shadow: 0 0 0 1px var(--ui-lyr-pill-ring), 0 1px 2px rgba(0, 0, 0, 0.05);
  transition: transform 460ms var(--ui-lyr-ease);
}
.ui-lyr-row {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: calc(10 * var(--u));
  width: 100%;
  height: var(--ui-lyr-row);
  margin: 0;
  padding: 0 calc(14 * var(--u));
  border: 0;
  border-radius: calc(12 * var(--u));
  background: transparent;
  font: inherit;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.ui-lyr-row:focus-visible { outline: 2px solid var(--ui-lyr-accent); outline-offset: -2px; }
.ui-lyr-title {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  font-size: calc(14 * var(--u));
  font-weight: 500;
  line-height: 1.3;
  letter-spacing: -0.01em;
  white-space: nowrap;
  text-overflow: ellipsis;
  color: var(--ui-lyr-text);
  transition: color 300ms ease;
}
.ui-lyr-hint {
  /* The title comes first – the hint gives way and ends in … */
  flex: 0 10000 auto;
  min-width: 0;
  max-width: 45%;
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  font-size: calc(12 * var(--u));
  line-height: 1.3;
  color: var(--ui-lyr-muted);
}
.ui-lyr-row[aria-selected="true"] .ui-lyr-title { color: var(--ui-lyr-accent); }

@media (prefers-reduced-motion: reduce) {
  .ui-lyr-layer, .ui-lyr-glow, .ui-lyr-pill { transition: none; }
}

/* Dark mode: follows a .dark class or data-theme="dark" on any ancestor, e.g. <html> */
:where(.dark, [data-theme="dark"]) .ui-lyr {
  --ui-lyr-accent: #6b95ff;
  --ui-lyr-accent-deep: #2f6bff;
  --ui-lyr-tint: #1f2c4d;
  --ui-lyr-glow: rgba(47, 107, 255, 0.3);
  --ui-lyr-face: rgba(255, 255, 255, 0.04);
  --ui-lyr-edge: rgba(255, 255, 255, 0.13);
  --ui-lyr-side: #26262a;
  --ui-lyr-face-above: rgba(255, 255, 255, 0.025);
  --ui-lyr-side-above: rgba(38, 38, 42, 0.5);
  --ui-lyr-panel: #161618;
  --ui-lyr-pill: #232326;
  --ui-lyr-pill-ring: rgba(255, 255, 255, 0.08);
  --ui-lyr-text: #ededed;
  --ui-lyr-muted: #8f8f8f;
}
`;function C(){return e.jsx("div",{className:"layer-stack-demo",children:e.jsx(K,{})})}const U=`.layer-stack-demo{width:100%}.stage .layer-stack-demo{width:min(100%,560px)}.card__preview .layer-stack-demo{place-items:center;width:auto;display:grid;position:absolute;inset:0}.card__preview .layer-stack-demo .ui-lyr{width:auto;height:100%}
`;function ee(){return e.jsxs(e.Fragment,{children:[e.jsx("style",{children:U}),e.jsx(C,{})]})}export{Q as LayerStack,ee as Preview,ee as default};
