import{R as t}from"./workbench-model-BwgilGut.js";const r=()=>t;export{r as t};
